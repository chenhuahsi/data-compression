#ifndef _CALC_PRINT_H
#define _CALC_PRINT_H 1

#include "calc2.h"

extern void COMM_printf(romchar *s, ...);

#ifdef _MSC_VER
#define printf(s, ...) \
  do { \
    romchar *_s = (romchar *) s; \
    COMM_printf(_s, __VA_ARGS__); \
  } while(0)
#else
#define printf(s, ...) \
  do { \
    romchar *_s = (romchar *) s; \
    COMM_printf(_s, ##__VA_ARGS__);             \
  } while(0)
#endif

#endif // _CALC_PRINT_H
