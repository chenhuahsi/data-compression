/* syna_attrs.h
 * Synaptics annotations for type definitions
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 */

#ifndef _SYNA_ATTRS_H
#define _SYNA_ATTRS_H

#ifndef __CHIMERA__
// non t100x-gcc builds
  #define ATTR_DIRECT
  #define ATTR_HIGH_DIRECT
  #define ATTR_WIDE
  #define ATTR_BYTE_ALIGNED(x)
  #define ATTR_WORD_ALIGNED(x)
  #define ATTR_LOCATION(x)
  #define ATTR_BANK(x)
  #define ATTR_ANYBANK
  #define ATTR_NEAR
  #define ATTR_FAR
  #define ATTR_CROSSPAGE
  #define ATTR_NAKED
  #define ATTR_MAIN
  #define ATTR_NOINLINE
  #define ATTR_NORETURN
#ifdef _MSC_VER
  #define ATTR_INLINE     __inline
#else
  #define ATTR_INLINE     inline
#endif
  #define ATTR_ROM
  #define ATTR_INFO
  #define ATTR_ICACHE_TAG
  #define ATTR_ICACHE_DATA
  #define ATTR_SLOW_REG
  #define ATTR_ASYNC_REG
  #define ATTR_BLOCK_MOVN
  #define ATTR_NO_BLOCK_MOVN
  #define ATTR_SAVED(x)
  #define ATTR_UNUSED
  #define ATTR_SMARTLINKAGE
  #define ATTR_CATEGORY(x)
  #define ATTR_CUSTOM_CALL(x)
  #define ATTR_CODE0
  #define ATTR_CODE1
  #define ATTR_SUBR0
  #define ATTR_SUBR1
  #define ATTR_ANYROM
  #define ATTR_STACKED
  #define ATTR_THREAD(x)
  #define ATTR_LIBRARY
  #define ATTR_NOBANK
  #define ATTR_INITIALIZED
  #define ATTR_NOINDEXWRITE
  #define ATTR_UNADDRESSABLE
  #define ATTR_IS_TPC
  #define ATTR_CODE
  #define ATTR_UICODE
  #define ATTR_BOOTSEG
  #define ATTR_EXTNDBOOTSEG
  #define ATTR_CONST
  #define ATTR_PURE
  #define ATTR_BOOTRAM
  #define ATTR_SPAN
  #define ATTR_DMA
#else // t100x-gcc, normal firmware
  #define ATTR_DIRECT         __attribute__ ((direct))
  #define ATTR_HIGH_DIRECT    __attribute__ ((high_direct))
  #define ATTR_WIDE           __attribute__ ((wide))
  #define ATTR_BYTE_ALIGNED(x) __attribute__ ((aligned (BYTES_TO_CHARS (x))))
  #define ATTR_WORD_ALIGNED(x) __attribute__ ((aligned (WORDS_TO_CHARS (x))))
  #define ATTR_LOCATION(x)    __attribute__ ((location (x)))
  #define ATTR_BANK(x)        __attribute__ ((bank (x)))
  #define ATTR_ANYBANK        __attribute__ ((anybank))
  #define ATTR_NEAR           __attribute__ ((nearcall))
  #define ATTR_FAR            __attribute__ ((farcall))
  #define ATTR_CROSSPAGE
  #define ATTR_NAKED          __attribute__ ((naked))
  #define ATTR_MAIN           __attribute__ ((main))
  #define ATTR_NOINLINE       __attribute__ ((noinline))
  #define ATTR_NORETURN       __attribute__ ((noreturn))
  #define ATTR_INLINE         inline __attribute__((always_inline))
  #define ATTR_ROM            __attribute__ ((rom))
  #define ATTR_INFO           __attribute__ ((info))
  #define ATTR_ICACHE_TAG     __attribute__ ((icache_tag))
  #define ATTR_ICACHE_DATA    __attribute__ ((icache_data))
  #define ATTR_SLOW_REG       __attribute__ ((slow_reg))
  #define ATTR_ASYNC_REG      __attribute__ ((async_reg))
  #define ATTR_SAVED(x)       __attribute__ ((call_saved (#x)))
  #define ATTR_UNUSED         __attribute__ ((unused))
  #define ATTR_SMARTLINKAGE   __attribute__ ((smartlinkage))
  #define ATTR_CATEGORY(x)    __attribute__ ((category (x)))
  #define ATTR_CUSTOM_CALL(x) __attribute__ ((custom_call (x)))

// JCJ 2/3/2015 FIXME: these are never used, they should be removed
  #if __T100X_HAS_BLOCK_MOVN__
    #define ATTR_BLOCK_MOVN     __attribute__ ((block_movn))
    #define ATTR_NO_BLOCK_MOVN  __attribute__ ((no_block_movn))
  #else
    #define ATTR_BLOCK_MOVN
    #define ATTR_NO_BLOCK_MOVN
  #endif
  
  #if __T100X_API__ > 2
   #define ATTR_ANYROM __attribute__ ((smartcall))
  #else
   #define ATTR_ANYROM __attribute__ ((anyromcall))
  #endif

  #define ATTR_STACKED        __attribute__ ((stacked))
  #define ATTR_THREAD(x)      __attribute__ ((thread (x)))

  #define ATTR_NOTINLINEABLE  __attribute__ ((literal ("notInlineable", "TRUE")))
  #define ATTR_NOBANK         __attribute__ ((nobank))

// JCJ 2/3/2015 FIXME: this is dangerous and should be removed, the
// places where OneBase uses it are actually masking bugs.
  #define ATTR_INITIALIZED    __attribute__ ((initialized))

  #define ATTR_NOINDEXWRITE   __attribute__ ((noindexwrite))
  #define ATTR_UNADDRESSABLE  __attribute__ ((unaddressable))
  #define ATTR_IS_TPC         __attribute__ ((is_tpc))

  // CODE is anywhere in the code, which could be in the bootloader or the UI.
  // If there is no bootloader this is acceptable to use anywhere, but with a
  // bootloader any UI code must use UICODE. Do *not* make this a nearcall.
  #define ATTR_CODE           __attribute__ ((section ("CODE")))

  // UICODE means *not* the bootloader. Unfortunately we must make calls to this are
  // a far call so compiler thunks will work even when bootloaders occupy all
  // available near area.
  #define ATTR_UICODE         __attribute__ ((section ("UICODE")))       __attribute__ ((farcall))

  #define ATTR_BOOTSEG        __attribute__ ((section ("BOOTSEG")))      __attribute__ ((nearcall))
  #define ATTR_EXTNDBOOTSEG   __attribute__ ((section ("EXTNDBOOTSEG"))) __attribute__ ((nearcall))

  // Many functions do not examine any values except their arguments, and have no effects except the return value.
  // Basically this is just slightly more strict class than the pure attribute below, since function is
  // not allowed to read global memory.
  #define ATTR_CONST          __attribute__ ((const))
  // Many functions have no effects except the return value and their return value depends only on the parameters
  // and/or global variables. Such a function can be subject to common subexpression elimination and loop
  // optimization just as an arithmetic operator would be
  #define ATTR_PURE           __attribute__ ((pure))

  // The vliteral attribute passes literal items to alloc and allocvar directives.
  // The ATTR_BOOTRAM is **ONLY** for use in the bootloader code to cause variables
  // to go into a separate RAM space.
  #define ATTR_BOOTRAM        __attribute__ ((vliteral ("bootram")))

  #define ATTR_SPAN           __attribute__ ((span))
  #define ATTR_DMA            __attribute__ ((dma))

#endif

#endif // _SYNA_ATTRS_H
