==============
 Syna Headers
==============

:Author: Joel Jordan
:Date: 2/11/2015

These header files provide most of the definitions previously in
silicon.h.

Every file in this directory is intended to be portable across
Chimera, Windows, and Linux targets.
