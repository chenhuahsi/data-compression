#if (defined(__TD4353__))
  #define IS_TD4353 1
#else
  #define IS_TD4353 0
#endif
#if IS_TD4353
  #define IS_KNOWN_PROCESSOR 1
#endif
#define SINCE_TD4353A0   (IS_TD4353)
