/* syna_types.h
 * Synaptics-style type definitions
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 */

#ifndef _SYNA_TYPES_H
#define _SYNA_TYPES_H 1

#ifndef SILICON_H
// silicon.h defines all this stuff also, so prevent multiple
// definitions of typedefs until we can fix silicon.h to use this
// file.

#include <stdint.h>
#include "syna_attrs.h"

  // t100x-gcc doesn't support 64 bit types
#ifdef __CHIMERA__
#  pragma GCC poison uint64
#  pragma GCC poison int64
#endif
  typedef uint32_t uint32;
  typedef int32_t  int32;
  typedef uint16_t uint16;
  typedef int16_t  int16;
#if !defined(__CHIMERA__) || defined(__T100X_VOID_ALIGNMENT__)
  typedef uint8_t  uint8;
  typedef int8_t   int8;
#endif

  // For Chimera 2.2 the use of "__attribute__ ((block_movn))" tells the compiler
  // that it can use a block-MOV operation on this variable. However, block_movn
  // is only usable if -mhas-block-movn is true. This is taken care of in the
  // definition of of ATTR_BLOCK_MOVN, which equates to nothing if we are not
  // allowed to use block_movn.
  typedef uint16 ATTR_BLOCK_MOVN ram_uint16;
  typedef int16 ATTR_BLOCK_MOVN ram_int16;

#if __T100X_HAS_SLOW_REG__ == 1
  typedef uint16 ATTR_SLOW_REG slow_uint16;
#else
  typedef uint16 slow_uint16;
#endif

  // Define a floating type so we can control the size of our floats.
  // For t100x-gcc both float and double are 32-bits.
  typedef float                  float32;

  // Special types for ROM-located values
  typedef const   char ATTR_ROM  rom_char;
  typedef const   char ATTR_INFO info_char;
  typedef const  int16 ATTR_ROM  rom_int16;
  typedef const uint16 ATTR_ROM  rom_uint16;
  typedef const  int16 ATTR_INFO info_int16;
  typedef const uint16 ATTR_INFO info_uint16;
  typedef const  int32 ATTR_ROM  rom_int32;
  typedef const uint32 ATTR_ROM  rom_uint32;
  typedef const  int32 ATTR_INFO info_int32;
  typedef const uint32 ATTR_INFO info_uint32;
  typedef const  float ATTR_ROM  rom_float;

#endif // SILICON_H

#ifdef _MSC_VER
#define INLINE __inline
#else
#define INLINE inline
#endif

// Define fixed-point types to make data structure formats
// self-documenting.

typedef uint16 uint0p16;
typedef uint16 uint1p15;
typedef uint16 uint2p14;
typedef uint16 uint3p13;
typedef uint16 uint4p12;
typedef uint16 uint5p11;
typedef uint16 uint6p10;
typedef uint16 uint7p9;
typedef uint16 uint8p8;
typedef uint16 uint9p7;
typedef uint16 uint10p6;
typedef uint16 uint11p5;
typedef uint16 uint12p4;
typedef uint16 uint13p3;
typedef uint16 uint14p2;
typedef uint16 uint15p1;

typedef int16 int0p16;
typedef int16 int1p15;
typedef int16 int2p14;
typedef int16 int3p13;
typedef int16 int4p12;
typedef int16 int5p11;
typedef int16 int6p10;
typedef int16 int7p9;
typedef int16 int8p8;
typedef int16 int9p7;
typedef int16 int10p6;
typedef int16 int11p5;
typedef int16 int12p4;
typedef int16 int13p3;
typedef int16 int14p2;
typedef int16 int15p1;

typedef uint32 uint0p32;
typedef uint32 uint1p31;
typedef uint32 uint2p30;
typedef uint32 uint3p29;
typedef uint32 uint4p28;
typedef uint32 uint5p27;
typedef uint32 uint6p26;
typedef uint32 uint7p25;
typedef uint32 uint8p24;
typedef uint32 uint9p23;
typedef uint32 uint10p22;
typedef uint32 uint11p21;
typedef uint32 uint12p20;
typedef uint32 uint13p19;
typedef uint32 uint14p18;
typedef uint32 uint15p17;
typedef uint32 uint16p16;
typedef uint32 uint17p15;
typedef uint32 uint18p14;
typedef uint32 uint19p13;
typedef uint32 uint20p12;
typedef uint32 uint21p11;
typedef uint32 uint22p10;
typedef uint32 uint23p9;
typedef uint32 uint24p8;
typedef uint32 uint25p7;
typedef uint32 uint26p6;
typedef uint32 uint27p5;
typedef uint32 uint28p4;
typedef uint32 uint29p3;
typedef uint32 uint30p2;
typedef uint32 uint31p1;

typedef int32 int0p32;
typedef int32 int1p31;
typedef int32 int2p30;
typedef int32 int3p29;
typedef int32 int4p28;
typedef int32 int5p27;
typedef int32 int6p26;
typedef int32 int7p25;
typedef int32 int8p24;
typedef int32 int9p23;
typedef int32 int10p22;
typedef int32 int11p21;
typedef int32 int12p20;
typedef int32 int13p19;
typedef int32 int14p18;
typedef int32 int15p17;
typedef int32 int16p16;
typedef int32 int17p15;
typedef int32 int18p14;
typedef int32 int19p13;
typedef int32 int20p12;
typedef int32 int21p11;
typedef int32 int22p10;
typedef int32 int23p9;
typedef int32 int24p8;
typedef int32 int25p7;
typedef int32 int26p6;
typedef int32 int27p5;
typedef int32 int28p4;
typedef int32 int29p3;
typedef int32 int30p2;
typedef int32 int31p1;

#ifndef true
#define true  1
#endif
#ifndef false
#define false 0
#endif

#endif // _SYNA_TYPES_H
