#ifndef _CALC2_H
#define _CALC2_H 1

/* -----------------------------------------------------------------
 * Calc2 - API for touch data acquisition and processing
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 *
 * This file defines the public interface to Calc2. Brief documentation
 * is given inline. For more extensive documentation, or for more
 * information about the Calc2 project, see:
 *   http://usuv-conf.synaptics.com:8090/display/DAQ2/DAQ2+Project+Space
 */

#include "calc_config.h"

/*
 * The following symbols must be defined in calc_config.h to compile
 * Calc2.
 *
 * MAX_RX: the maximum number of image receiver electrodes.
 *
 * MAX_TX: the maximum number of image transmitter electrodes.
 *
 * MAX_BUTTONS: the maximum number of buttons supported. If 0, buttons
 * are not supported and code supporting them can be removed.
 *
 * MAX_IMAGE_CLUSTERS: the maximum number of image clusters
 * supported. This is typically higher than MAX_TX to support CDM, where
 * the number of clusters is ceil(MAX_TX/(CDM order))*(CDM order).
 *
 * MAX_NOISE_BURSTS: the maximum number of noise bursts in an active
 * frame.
 *
 * MAX_TX_GUARDS: the maximum number of TX (Y-axis) guard pins for use
 * during absolute sensing.
 *
 * MAX_RX_GUARDS: the maximum number of RX (X-axis) guard pins for use
 * during absolute sensing.
 *
 * MAX_FREQUENCIES: the maximum number of sensing frequencies.
 *
 * MAX_NOISE_SCAN_BURSTS: the maximum number of bursts per frequency to
 * acquire during a noise scan.
 *
 * MAX_OBJECTS: the maximum number of objects to track.
 *
 * CONFIG_IMAGE_DELTA_IS_POSITIVE: Set to 1 to indicate that the
 * fingers increase the image signal, set to 0 to indicate that
 * fingers decrease it.
 *
 * PLATFORM_xxxx: set to 1 for the platform you are using. For
 * example, #define PLATFORM_TWOHARBORS 1 to use the Two Harbors
 * platform.
 *
 * The following are required for some but not all platforms:
 *
 * CDM_ORDER: the CDM order supported. This can be 4, 10, or 16. Each
 * build can support only one CDM order.
 *
 * CONFIG_NSM_NULL, CONFIG_NSM_GANYMEDE, CONFIG_NSM_CALLISTO,
 * CONFIG_NSM_EUROPA, CONFIG_NSM_AMALTHEA, CONFIG_NSM_HIMALIA, and
 * CONFIG_NSM_THEBE: set only one of these
 * to 1 to indicate which noise state machine to use.
 *
 */

/*
 * For PC (and other non-firmware) builds, you must force an ASIC.
 * This is done by defining a symbol specifying which ASIC like:
 *   FORCE_IS_T1327
 * A full list of the options is in syna/syna_asic.h"
 */
#if defined(__CHIMERA__) || defined(__COMMSIM__)
#include <config_all_chips.h>
#elif defined(__UNITTEST__)
#include "unittest_asic.h"
#elif defined(_MSC_VER)
#include "calc2forpc_asic.h"
#else
#include "syna/syna_asic.h"
#endif
#include "syna/syna_types.h"

/* The daqParams_t struct is defined in the platform header files
 * platform_xxxx.h. The correct one will be automatically included by
 * platform.h based on which PLATFORM_xxxx is set. */
#include "platform.h"

/* The IFP configuration structure is defined in ifp.h. This is
 * derived from ifp_common.h */
#include "ifp.h"

enum{
  DEFAULT_SESNING = 0,
  CONTINUE_MODE,
  H_BLANK_MODE, //H Blank
  LONG_H_BLANK_MODE, //Long-H Blank
  LONG_V_BLANK_MODE, //Long-V BLank
};

#ifdef __cplusplus
extern "C" {
#endif

/* To make data structures Chimera-compatible, we force the same
 * packing as used in t100x-gcc. */
#ifndef __CHIMERA__
#  pragma pack(push,2)
#endif

/**
 * Doze-specific parameters.
 */
typedef struct dozeParams_t {
  /// The time (in 10-ms units) between doze frames.
  uint16 dozeInterval;

  /// The number of bursts per cluster to acquire in doze mode.
  uint16 dozeBurstsPerCluster;

  /// The time (in 10-ms units) required to have no detected objects
  /// before doze begins.
  uint16 dozeHoldOff;

  /// The time (in 10-ms units) to remain in doze between taking
  /// single active-mode frames for touch baseline updates.
  uint16 dozeRecalibrationInterval;

  /// The signal level threshold (in ADC counts) above which the
  /// system exits doze and returns to full-power mode
  uint16 dozeWakeUpThreshold;
  uint16 dozeWakeUpThreshold0D;
} dozeParams_t;

/**
 * Loze-specific parameters.
 */
typedef struct {
  /// The time (in 10-ms units) between loze frames.
  uint16 lozeInterval;

  /// The number of bursts per cluster to acquire in loze mode.
  uint16 lozeBurstsPerCluster;

  /// The time (in 10-ms units) required to have no detected objects
  /// before loze begins.
  uint16 lozeHoldOff;

  /// The time (in 10-ms units) to remain in loze between taking
  /// single active-mode frames for touch baseline updates.
  uint16 lozeRecalibrationInterval;

  /// The signal level threshold (in ADC counts) above which the
  /// system exits loze and returns to full-power mode
  uint16 lozeWakeUpThreshold;

  // Axis selection bit that decides the sensing axis during loze.
  // 1 (select receiver axis), 0 (select transmitter axis)
  uint16 lozeAxisSelect;

  // delta ADC finger threshold for loze Object Shape Detector
  uint16 lozeFingerThreshold;

  //delta ADC glove threshold for loze Object Shape Detector
  uint16 lozeGloveThreshold;

  uint16 lozeEnablePocketReject;
} lozeParams_t;

/**
 * LPWG Mode B-specific parameters.
 */
typedef struct lpwgModeBParams_t {
  /// The time (in 0.5-ms units) between doze frames.
  uint16 lpwgInterval;
  uint16 trgtInterval;

  // The display refresh duration (in 10us units)
  uint16 displayRefreshDuration;

  // The display refresh interval (in 0.5s units)
  uint16 displayRefreshInterval;

  /// The signal level thresholds (in ADC counts) which causes the
  /// system to exit lpwg finger sensing and starts gesture processing
  uint16 lpwgWakeUpThreshold;     // max peak
  uint16 lpwgSpatialThreshold;    // max spatial difference
  uint16 lpwgEnergyThreshold;     // total energy
  uint16 lpwgEnergyLiftThreshold; // lift energy

  uint16 lpwgHistorySize;         // lpwg baseline history

  uint16 lpwgAxis;                // lpwg axis can be either Rx (0) or Tx (1)

  uint16 dozeHoldOff;             // doze holdoff duration
  uint16 dozeRecalInterval;       // doze recalibration interval
} lpwgModeBParams_t;

/**
 * Low power wakeup gesture parameters
 */
typedef struct {
  /// supporting gesture types
  uint16 gestureType;

  /// The active mode framerate to use for wakeup gestures
  uint16 frameRate;

  /// The number of false wakeups allowed before entering reject mode
  uint16 falseActivationThreshold;

  /// The length of reject mode for too many false wakeups (100-ms units)
  uint16 falseActivationTimeout;

  /// The length of active duration allowed without a gesture (500-ms units)
  uint16 maxActiveDuration;

  /// The length of reject mode for exceeding the max active duration (100-ms units)
  uint16 maxActiveDurationTimeout;

  /// The X-coordinate of corner 0 of the double-tap region
  uint16 doubleTapZoneX0;

  /// The Y-coordinate of corner 0 of the double-tap region
  uint16 doubleTapZoneY0;

  /// The X-coordinate of corner 1 of the double-tap region
  uint16 doubleTapZoneX1;

  /// The X-coordinate of corner 1 of the double-tap region
  uint16 doubleTapZoneY1;

  /// The maximum time (100-ms units) between taps for a double tap
  uint16 doubleTapMaxTapTime;

  /// The maximum distance (in 0.1-mm units) between taps for a double tap
  uint16 doubleTapMaxTapDistance;

  /// swipe zone definition
  uint16 swipeZoneX0;

  uint16 swipeZoneY0;

  uint16 swipeZoneX1;

  uint16 swipeZoneY1;

  uint16 MinimumSwipeSpeed;

  uint16 SwipeMinimumDistance;

  uint16 xUnitsPerMm;

  uint16 yUnitsPerMm;

  uint16 swipeNoLift;

  union{
    uint16 directionFilter;
    struct{
      uint16 PositiveX:1;
      uint16 NegativeX:1;
      uint16 PositiveY:1;
      uint16 NegativeY:1;
    };
  };

  uint16 xTolerance;

  uint16 yTolerance;

  uint16 swipeCurvature;

  uint16 MinimumCircleSpeed;

  uint16 circleMaxStartToEndDist;

  uint16 MinimumTriangleSpeed;

  uint16 triangleMaxStartToEndDist;

  uint16 triangleMinAngle;

  uint16 MinimumVeeSpeed;

  uint16 veeDirectionEnabled;

  uint16 veeAngleTolerance;

  uint16 veeMinStartToEndDistance;

  uint16 MinimumUnicodeSpeed;

  uint16 unicodeMaxStartToEndDist;

  uint16 unicodeSwitch;

  uint16 unicodeOrientation;

  uint16 userDefinedGestureEnabled :1;

  #if CONFIG_HAS_LPWG_MULTITAP
  uint16 BufferZoneSize;
  uint16 MultiTapFailRealTimeInterruptEnable_HIGH;
  uint16 MultiTapFailRealTimeInterruptEnable_LOW;
  uint16 MultiTapInterruptDelayTimeEnable;
  uint16 MultiTapInterruptDelayTimeConvertedIntoFrames;
  uint16 MultiTapCount;
  uint16 MultiTapMinTapTimeConvertedIntoFrames;
  uint16 MultiTapMaxTapTimeConvertedIntoFrames;
  uint16 MultiTapPressReleaseDistance;
  uint16 MultiTapInterTapDistance;
  #if CONFIG_HAS_LPWG_DUALMULTITAP
  uint16 MultiTapInterruptDelayTimeEnable_DualMultiTap;
  uint16 MultiTapCount_DualMultiTap;
  uint16 MultiTapInterruptDelayTimeConvertedIntoFrames_DualMultiTap;
  uint16 MultiTapMinTapTimeConvertedIntoFrames_DualMultiTap;
  uint16 MultiTapMaxTapTimeConvertedIntoFrames_DualMultiTap;
  uint16 MultiTapPressReleaseDistance_DualMultiTap;
  uint16 MultiTapInterTapDistance_DualMultiTap;
  #endif
  #endif  //psong
  #if CONFIG_HAS_LPWG_POWERREDUCTION
  uint16 startLPWGSensing                     : 1;
  uint16 falseActivationDueToMaxActiveTimeout : 1;
  uint16 falseActivationDueToIncompleteDoze   : 1;
  uint16 alternateDozeSensing                 : 1;
  uint16 wentToSleep                          : 1;
  uint16 resetGestureCounters                 : 1;
  uint16 AdjDoze;
  uint16 Timer1;
  uint16 falseActCounter;
  uint16 continuousActiveCounter;
  uint16 maxActiveDurationInFrames;
  uint16 ForceDozeLPWG_byObjectPresent_Trigger;
  uint16 ForceDozeLPWG_byObjectPresent_DoRepeatForceDoze;
  #endif
  #if defined(CONFIG_ACTIVE_ZONE_ENABLE) && CONFIG_ACTIVE_ZONE_ENABLE
  uint16 ActiveZoneEn;
  uint16 ActiveZoneX0;
  uint16 ActiveZoneX1;
  uint16 ActiveZoneY0;
  uint16 ActiveZoneY1;
  #endif
} lpwgParams_t;

struct touch {
  uint32 ts;
  uint16 touchFlag;
  uint16 tx; // 8.8
  uint16 rx; // 8.8
  uint16 x;
  uint16 y;
};

/**
 * User defined gesture parameters
 */
typedef struct {
  ///
  uint16 maxInterStroke;

  ///
  uint16 numTemplatesMax;

  ///
  uint16 templateSize;

  ///
  uint16 templateDisp;

  ///
  float rotationInvariance;

  ///
  float scaleInvariance;

  ///
  float thresholdFactor;

  ///
  float matchingMetricThreshold;

  ///
  uint16 xUnitsPerMm;

  ///
  uint16 yUnitsPerMm;

} udgParams_t;
/**
 * grip suppression parameters
 */
typedef struct {
  // Pink strip (see doc). In this region, finger may be suppressed based on Wy

  // Pink left strip boundary
  int16 gripInnerXmin;

  // Pink right strip boundary
  int16 gripInnerXmax;

  // Pink bottom strip boundary
  int16 gripInnerYmin;

  // Pink top strip boundary
  int16 gripInnerYmax;

  // Pink Wy limit (sets slope)
  int16 gripInnerWyThreshold;

  // Red strip (see doc) similar to pink zone, but also limit # of fingers, 1 max

  // Red left strip boundary
  int16 gripOuterXmin;

  // Red right strip boundary
  int16 gripOuterXmax;

  // Red bottom strip boundary
  int16 gripOuterYmin;

  // Red top strip boundary
  int16 gripOuterYmax;

  // Red Wy limit (sets slope)
  int16 gripOuterWyThreshold;

  int16 xMax;

  int16 yMax;

  int16 minFingersEnabled;

#if CONFIG_IFP_GRIP_SUPPRESS_GLOVE
  uint16 borderWidth;
  uint16 gloveGripEnableOnXAxis;
  uint16 gloveGripEnableOnYAxis;
#endif
}gripSupresParams_t;
#if CONFIG_IFP_ESD_ACTIVEMODE
typedef struct {
  // ESD baseline update thermal threshold
  int16 thermalThreshold;

  // ESD Mode slow speed switch to fast speed tuning params
  int16 flatTheshold;
  uint16 levelThreshold;

  // ESD Mode, Finger detection Params
  // Finger size limitation, count Tx/Rx of Tixels which
  // is higher than maxPeak/fingerWidthAmplitudeRatio
  int16 fingerWidthThresholdMin;
  int16 fingerWidthThresholdMax;
  int16 fingerWidthAmplitudeRatio;

  // Delta Max should within [fingerPeakMinThreshold, fingerPeakMaxThreshold]
  int16 fingerPeakMinThreshold;
  int16 fingerPeakMaxThreshold;

  // MaxPeak / (min in its 8C Tixels) should within [ratioPeakToMinThresholdMin, ratioPeakToMinThresholdMax]
  int16 ratioPeakToMinThresholdMin;
  int16 ratioPeakToMinThresholdMax;

  // Clean bufferTouchFlag after exit ESD MODE. (bufferTouchFlagDisableAfterEsdMode)
  uint16 touchFlagIgnoreCount;
} esdModeConfig_t;
#endif

/**
 * Values that can change only when starting or restarting sensing.
 * The static configuration includes settings that do not need to be
 * changed between frames.
 *
 * The IFP configuration is used as defined in ifp_config.h and
 * documented in the IFP guide. However, any values that are given in
 * LSB units are instead specified to Calc2 in integer fF units and
 * are converted to LSB inside Calc2. These are:
 *   ifpConfig
 *     sensorParams
 *       cSat_LSB
 *       noiseFloor_LSB
 *     mdConfig
 *       absXObjectThreshold_LSB
 *       absYObjectThreshold_LSB
 *       absXLiftThreshold_LSB
 *       absYLiftThreshold_LSB
 *     mfConfig
 *       absXPenThreshold_LSB
 *       absYPenThreshold_LSB
 *       absXFingerThreshold_LSB
 *       absYFingerThrehsold_LSB
 *     segConfig
 *       minPeak_LSB
 *     bcConfig
 *       absXNegThreshold_LSB
 *       absYNegThreshold_LSB
 *     classConfig
 *       saturationLevel_LSB
 *       absXObjectThreshold_LSB
 *       absYObjectThreshold_LSB
 *     lgmConfig
 *       absXLGMObjectThreshold_LSB
 *       absYLGMObjectThreshold_LSB
 *       transLGMObjectThreshold_LSB
 *
 * Additionally, some fields are unused and don't need to be populated:
 *   ifpConfig
 *     sensorParams
 *       fF_per_LSB
 *       LSB_per_fF
 *
 */
typedef struct calcStaticConfig_t {
  /// The number of buttons actually used. This must not exceed
  /// MAX_BUTTONS.
  //uint16 numButtons;

  /// The number of image columns actually used. This must not exceed
  /// MAX_RX. If MAX_ABS_RX > 1, then this is also the size of the RX
  /// profile.
  //uint16 numCols;

  /// The number of image rows actually used. This must not exceed
  /// MAX_TX. If MAX_ABS_TX > 1, then this is also the size of the TX
  /// profile.
  //uint16 numRows;

  daqParams_t daqParams;

#if CONFIG_LOWPOWER_DOZE
  dozeParams_t dozeParams;
#endif
#if CONFIG_LOWPOWER_LOZE
  lozeParams_t lozeParams;
#endif

  ifpConfig_t ifpConfig;

#if CONFIG_HAS_WAKEUPGESTURE
  lpwgParams_t lpwgParams;
#endif
#if CONFIG_HIC_LPWG_MODE_B
  lpwgModeBParams_t lpwgModeBParams;
#endif

#if CONFIG_HAS_LPWG_USERDEFINED
  udgParams_t udgParams;
#endif
#if CONFIG_GRIPSUPPRESSION
  gripSupresParams_t gripSupresParams;
#endif
#if CONFIG_IFP_ESD_ACTIVEMODE
  esdModeConfig_t esdModeConfig;
#endif
#if CONFIG_PER_PIXEL_CBCSCAN
  int16 perPixelLocalCBCTarget;
#endif
#if CONFIG_HYBRID_CBC_CORRECTION
  uint16 cbcCorrectionEnabled;
  uint16 gcbcSwing;
  uint16 iterations;
  uint16 upperLimit;
  uint16 lowerLimit;
  #if CONFIG_HYBRID_CBC_CORRECTION_LCBC_CONTROL
  uint16 cbcCorrection_Disable_LCBC_Rx;
  uint16 cbcCorrection_Disable_LCBC_Tx;
  #endif
#endif
#if CONFIG_OVERRIDE_REFHILO_FOR_RT20
  struct {
    uint16 reflo;
    uint16 refhi;
  } RefRT20;
#endif
#if CONFIG_HAS_RT125_ALTERNATE_PARAMETERS || CONFIG_HAS_RT125_LCBC
  struct {
  #if CONFIG_HAS_RT125_ALTERNATE_PARAMETERS
    uint16 TX_2D_RESET_WITH_GUARD_ABSX : 1;
    uint16 RX_2D_RESET_WITH_GUARD_ABSX : 1;
    uint16 RX_0D_RESET_WITH_GUARD_ABSX : 1;
  #endif
  #if CONFIG_HAS_RT125_LCBC
    uint16 LCBC                        : 1;
  #endif
  } RT125;
#endif
} calcStaticConfig_t;

/**
 * Values that can change on any frame. The dynamic configuration
 * includes any settings that need to be adjustable without restarting
 * sensing.
 */
typedef struct calcDynamicConfig_t {
  /// Set to disable doze, keeping the sensor in active mode.
  uint16 noDoze;

  /// Set to disable all noise mitigation including frequency shifting.
  uint16 disableNoiseMitigation;

  // Set to switch touchSensing Mode
  uint16 touchSensingMode;

  /// Set to force a rezero when exiting deep sleep.
  uint16 rezeroOnExitDeepSleep;

  /// Set to indicate that a charger is connected.
  uint16 chargerConnected;

  /// Set to disable automatic baseline relaxation
  uint16 noBaselineRelaxation;

  /// Set to enable super doze mode (usually when display is off)
  uint16 enableSuperDoze;

  /// Set to turn on wakeup gesture mode
  uint16 inWakeupGestureMode;

  /// Set to turn on face detect
  uint16 enableFaceDetect;

  /// Set to turn on side touch
  uint16 enableSideTouch;

  /// Set to turn on moisture detection mode
  uint16 moistureEnabled;
  uint16 moistureAMPEnabled;

  /// Set to turn on shadow remover
  uint16 shadowRemoverEnabled;
  uint16 shadowRemoverAMPEnabled;

  /// Set to turn on thick glove
  uint16 thickGloveEnabled;

  // Set to enable Hybrid Glove detection
  uint16 hybridGloveEnabled;

  // set to disable LGM correction
  uint16 noLGMCorrection;

  /// Set to turn on display noise remover
  uint16 displayNoiseRemoverEnabled;

  /// Set to turn on display noise remover
  uint16 hybridDisplayNoiseRemoverEnabled;

  /// Set to turn on user defined gesture registration.
  uint16 registrationEnable;

  /// Set to turn on user defined gesture registration.
  uint16 registrationStart;

  /// Select user defined gesture template index to register.
  uint16 registrationIndex;

  // set to enable anti-bending
  uint16 enableAntiBending;
  uint16 enableProfileAntiBending;

#if CONFIG_GRIPSUPPRESSION
  //enable, disable grip suppression
  uint16 gripSuppressionEnable;
#endif
  // set to enable adaptive LGM
  uint16 aLGMenable;
#if defined(CONFIG_CLOSED_COVER_WINDOW_DATA_ONLY) && CONFIG_CLOSED_COVER_WINDOW_DATA_ONLY
  uint16 closedCoverOperation;
#endif
  positionRepConfig_t posReportConfigParams;

  //enable, disable knuckle
  uint16 knuckleEnabled;
  //enable, disable weak object filter
  uint16 enableWeakObjectFilter;

#if CONFIG_IFP_ESD_ACTIVEMODE
  union {
    uint16 esdModeCtrl;
    struct {
      uint16 enable            : 1;
      uint16 forceEnterEsdMode : 1;
      uint16 reserved          : 6;
      uint16                   : 8;
    } esdModeCtrlField;
  };
#endif
#if CONFIG_HIC_LPWG_MODE_B
  // set to reset gestures (HIC Mode B)
  uint16 resetGestureCounters;
#endif
#if CONFIG_HAS_DOZE_DATA_REPORTING
  uint16 forceDoze;
#endif

#if CONFIG_PER_PIXEL_CBCSCAN
  int16 perPixelLocalCBCEnabled;
#endif

#if CONFIG_HAS_ALT_REPORT_RATE
  uint16 reportRate; // 0:usual, 1:alternate
#endif

} calcDynamicConfig_t;

/**
 * Indicates IFP padded image format
 */
typedef int16 deltaImage_t[(MAX_TX+2)*(MAX_RX+1)+1];

/**
 * Indicates whether reconfiguration is required or not.
 */
typedef struct {
  uint16 staticChanged;
  uint16 dynamicChanged;
} configStatus_t;

/**
 * Finger detection report.
 */
typedef struct {
  // order must match F54 DATA24
  uint16 absMaxPeak;
  uint16 absXEnergy;
  uint16 maxSpatialDiff;
} fingerDetectionReport_t;

/**
 * Low-power wakeup gesture report.
 */
typedef struct {
  union {
    uint16 gestureDetected;
    struct {
      uint16 doubleTapDetected : 1;
      uint16 unicodeDetected : 1;
      uint16 circleDetected : 1;
      uint16 triangleDetected : 1;
      uint16 veeDetected : 1;
      uint16 swipeDetected : 1;
      uint16 userDefinedGestureRegistered : 1;
      uint16 userDefinedGestureDetected : 1;
    };
  };
  uint16 gestureProperty[6];
} gestureReport_t;

/**
 * The per-frame touch report. This contains values for all the
 * registers that are expected to be updated on each frame.
 */
typedef struct {
  uint32 timeStamp;
  reportData_t touch;
  gestureReport_t gesture;
  uint16 setAttn;
  uint16 frameRate;
  uint16 powerim;
  uint16 cidim;
  uint16 railim;
#if CONFIG_NSM_CALLISTO
  uint16 varcidim;
#endif
  uint16 nsmFrequency;
  uint16 nsmState;
#if CONFIG_HIC_LPWG_MODE_B
  uint16 singleFingerTouch : 1;
#endif
} touchReport_t;

/**
 * Define commands sent from the comm thread or GUI to the calc
 * thread. Commands are used for one-shot operations, such as forcing
 * a rezero or requesting a production test.
 */
typedef enum
{
  CMD_NONE = 0,
  CMD_EXIT = 1,
  CMD_ENTER_DEEP_SLEEP = 2,
  CMD_EXIT_DEEP_SLEEP = 3,
  CMD_REZERO = 4,
  CMD_UPDATE_STATIC_CONFIG = 5,
  CMD_ABS_AUTO_SERVO = 6,
  CMD_HYBRID_AUTO_SERVO = 7,
  CMD_CHANGE_SENSING_MODE = 8,
  CMD_EXIT_ESDMODE = 9,
  CMD_PERPIXEL_AUTO_SERVO = 10,
  CMD_DO_FULL_RAW_CAP_TEST = 1000,
  CMD_DO_HIGH_RESISTANCE_TEST = 1001,
  CMD_DO_TRANS_DELTA_ADC_TEST = 1002,
  CMD_DO_TRANS_DELTA_CAP_TEST = 1003,
  CMD_DO_TRANS_RAW_ADC_TEST = 1004,
  CMD_DO_TRANS_RAW_CAP_TEST = 1005,
  CMD_DO_HYBRID_DELTA_ADC_TEST = 1006,
  CMD_DO_HYBRID_DELTA_CAP_TEST = 1007,
  CMD_DO_HYBRID_RAW_ADC_TEST = 1008,
  CMD_DO_HYBRID_RAW_CAP_TEST = 1009,
  CMD_DO_HYBRID_SATURATED_RAW_ADC_TEST = 1010,
  CMD_DO_PRE_DECONVOLVED_CAP_TEST = 1011,
  CMD_DO_STORED_IMAGE_BASELINE_TEST = 1012,
  CMD_DO_ADC_RANGE_CT_LIMITS_TEST = 1013,
  CMD_DO_SENSOR_SPEED_TEST = 1014,
  CMD_DO_TAGS_RAW_CAP_TEST = 1015,
  CMD_DO_TREX_OPEN_CONDUCTIVE_BAR_TEST = 1016,
  CMD_DO_TREX_GND_COUNDUCTIVE_BAR_TEST = 1017,
  CMD_DO_TREX_SHORT_TEST = 1018,
  CMD_DO_GPIO_SHORTS_TEST = 1019,
  CMD_DO_GPIO_OPENS_TEST = 1020,
  CMD_DO_AMP_ABS_RAW_ADC_TEST = 1021,
  CMD_DO_AMP_ABS_RAW_CAP_TEST = 1022,
  CMD_DO_AMP_ABS_DELTA_ADC_TEST = 1023,
  CMD_DO_AMP_ABS_DELTA_CAP_TEST = 1024,
  CMD_DO_ETOE_SHORT_TEST = 1025,
  CMD_DO_EXTENDED_SENSOR_SPEED_TEST = 1026,
  CMD_DO_SATURATED_RAW_AMP_ADC_TEST = 1027,
  CMD_DO_HIC_RX_RX_SHORT_TEST = 1028,
  CMD_DO_HIC_TX_TX_SHORT_TEST = 1029,
  CMD_DO_TRANS_RAW_ADC_D4_TEST = 1030,
  CMD_DO_TRANS_RAW_ADC_D6_TEST = 1031,
} commCommandType_t;

/**
 * Commands from the comm thread. Arguments arg1 and arg2 can be
 * anything but the command must be self-contained--no pointers to
 * external data are allowed.
 */
typedef struct {
  commCommandType_t cmd;
  uint16 arg1;
  uint16 arg2;
} commCommand_t;

/**
 * User defined gesture constants.
 */
#define REGISTRATION_SUCCESS                          1
#define REGISTRATION_FAILURE_NOT_MATCHED_PREV_TRY     2
#define REGISTRATION_FAILURE_MATCHED_OTHER_TEMPLATE   3
#define REGISTRATION_FAILURE_INDEX_EXCEEDED_MAXIMUM   4

/**
 * User defined gesture trace position.
 */
typedef struct
{
  uint16 x;
  uint16 y;
  uint16 seg;
} udgReportPosition_t;

/**
 * User defined gesture features.
 */
typedef struct
{
  float x;
  float y;
  uint16 seg;
} udgFeaturePosition_t;

typedef struct
{
  float x[CONFIG_LPWG_USERDEFINED_NUMFEATURES];
  float y[CONFIG_LPWG_USERDEFINED_NUMFEATURES];
  float scaling;
  uint16 segments : 8;
  uint16 valid    : 8;
} udgTemplate_t;

/**
 * The following are mostly Production Test report types that need to be
 * converted to one-time commands
 */
typedef enum
{
  REPORT_TYPE_RESERVED_0,
  REPORT_TYPE_8BIT_IMAGE,

  IMAGE_REPORT_DELTA_TRANS_CAP_RT2,
  IMAGE_REPORT_RAW_TRANS_CAP_RT3,
  IMAGE_REPORT_HIGH_RESISTANCE_RT4,

  REPORT_TYPE_TRANS_TO_TRANS_SHORT,

  IMAGE_REPORT_DELTA_TRANS_ADC_RT6,

  REPORT_TYPE_RCV_TO_RCV_FRAME1,
  REPORT_TYPE_INCELL_CAPACITANCE_IMAGE_WIDEREFCAPS,

  IMAGE_REPORT_STORED_IMAGE_BASELINE_RT9,

  REPORT_TYPE_TX_GND,
  REPORT_TYPE_JITTER_TESTING,

  IMAGE_REPORT_RAW_TRANS_ADC_RT12,

  REPORT_TYPE_CAPACITANCE_IMAGE_MAX_MIN,
  REPORT_TYPE_RCV_OPEN_GROUNDEDPLATE_FRAME1,
  REPORT_TYPE_TRANS_OPEN_GROUNDEDPLATE,
  REPORT_TYPE_TRANS_GND_WITHOUT_GROUNDEDPLATE,
  REPORT_TYPE_RCV_TO_RCV_FRAME2,
  REPORT_TYPE_RCV_OPEN_GROUNDEDPLATE_FRAME2,
  REPORT_TYPE_CAPACITANCE_IMAGE_WIDEREFCAPS,

  IMAGE_REPORT_FULL_RAW_CAP_IMAGE_RXOFFSETS_RT20,

  REPORT_TYPE_PEN,

  IMAGE_REPORT_SENSOR_SPEED_TEST_RT22,
  IMAGE_REPORT_ADC_RANGE_CT_LIMITS_RT23,
  IMAGE_REPORT_TREX_OPEN_GROUNDEDPLATE_RT24,
  IMAGE_REPORT_TREX_TO_GND_WITHOUT_GROUNDEDPLATE_RT25,
  IMAGE_REPORT_TREX_TO_TREX_SHORT_RT26,
  IMAGE_REPORT_GPIO_SHORT_RT27,
  IMAGE_REPORT_GPIO_OPEN_RT28,

  REPORT_TYPE_RESERVED_29,
  REPORT_TYPE_RESERVED_30,
  REPORT_TYPE_RESERVED_31,
  REPORT_TYPE_RESERVED_32,
  REPORT_TYPE_RESERVED_33,
  REPORT_TYPE_RESERVED_34,
  REPORT_TYPE_RESERVED_35,
  REPORT_TYPE_RESERVED_36,

  IMAGE_REPORT_RAW_PROX_ADC_RT37,
  IMAGE_REPORT_RAW_PROX_CAP_RT38,
  IMAGE_REPORT_DELTA_PROX_ADC_RT39,
  IMAGE_REPORT_DELTA_PROX_CAP_RT40,

  REPORT_TYPE_RAWADC_BASELINE_ABSCAP,
  REPORT_TYPE_ABS_CT_LIMITS,
  REPORT_TYPE_RESERVED_43,
  REPORT_TYPE_RESERVED_44,
  REPORT_TYPE_ACTIVE_STYLUS_PROFILE,
  REPORT_TYPE_ACTIVE_STYLUS_HISTORY,
  REPORT_TYPE_ACTIVE_STYLUS_SUMMED_PROFILE,
  REPORT_TYPE_RESERVED_48,
  REPORT_TYPE_RAWADC_ABS_SATURATION,
  REPORT_TYPE_RESERVED_50,
  REPORT_TYPE_RESERVED_51,
  REPORT_TYPE_RESERVED_52,
  REPORT_TYPE_RESERVED_53,
  REPORT_TYPE_RESERVED_54,
  REPORT_TYPE_RESERVED_55,
  REPORT_TYPE_RESERVED_56,
  REPORT_TYPE_RESERVED_57,

  IMAGE_REPORT_DELTA_HYBRID_ADC_RT58,
  IMAGE_REPORT_DELTA_HYBRID_CAP_RT59,

  REPORT_TYPE_RESERVED_60,
  REPORT_TYPE_RESERVED_61,

  IMAGE_REPORT_RAW_HYBRID_ADC_RT62,
  IMAGE_REPORT_RAW_HYBRID_CAP_RT63,
  IMAGE_REPORT_SATURATED_RAW_HYBRID_ADC_RT64,
  IMAGE_REPORT_PREDECONVOLVED_CDM_DATA_RT65,

  REPORT_TYPE_RESERVED_66,
  REPORT_TYPE_RESERVED_67,
  REPORT_TYPE_RESERVED_68,
  REPORT_TYPE_RESERVED_69,
  REPORT_TYPE_DELTA_TRANSCAP_ABS,
  REPORT_TYPE_DELTA_TRANSCAP_ABS_ADC,
  REPORT_TYPE_RAW_TRANSCAP_ABS,
  REPORT_TYPE_RAW_TRANSCAP_ABS_ADC,
  REPORT_TYPE_RESERVED_74,
  REPORT_TYPE_16BIT_ADC_IMAGE_LGM,

  IMAGE_REPORT_TYPE_TAGS_RT76,

  REPORT_TYPE_RESERVED_77,
  REPORT_TYPE_RESERVED_78,
  REPORT_TYPE_RESERVED_79,
  REPORT_TYPE_RESERVED_80,
  REPORT_TYPE_RESERVED_81,
  REPORT_TYPE_RESERVED_82,
  REPORT_TYPE_RESERVED_83,
  REPORT_TYPE_RESERVED_84,
  REPORT_TYPE_RESERVED_85,
  REPORT_TYPE_RESERVED_86,
  REPORT_TYPE_RESERVED_87,
  REPORT_TYPE_RESERVED_88,
  REPORT_TYPE_RESERVED_89,
  REPORT_TYPE_RESERVED_90,

  IMAGE_REPORT_RAW_ABS_ADC_RT91,
  IMAGE_REPORT_RAW_ABS_CAP_RT92,
  IMAGE_REPORT_DELTA_ABS_ADC_RT93,
  IMAGE_REPORT_DELTA_ABS_CAP_RT94,
  IMAGE_REPORT_ETOE_SHORT_RT95,
  IMAGE_REPORT_EXTENDED_SENSOR_SPEED_RT96,

  REPORT_TYPE_RESERVED_97,
  REPORT_TYPE_RESERVED_98,
  REPORT_TYPE_RESERVED_99,
  REPORT_TYPE_RESERVED_100,
  REPORT_TYPE_RESERVED_101,
  REPORT_TYPE_RESERVED_102,
  REPORT_TYPE_RESERVED_103,
  REPORT_TYPE_RESERVED_104,

  IMAGE_REPORT_SATURATED_RAW_AMP_ADC_RT105,
  REPORT_TYPE_RESERVED_106,
  REPORT_TYPE_RESERVED_107,
  REPORT_TYPE_RESERVED_108,
  REPORT_TYPE_RESERVED_109,

  REPORT_TYPE_RESERVED_110,
  REPORT_TYPE_RESERVED_111,
  REPORT_TYPE_RESERVED_112,
  REPORT_TYPE_RESERVED_113,
  REPORT_TYPE_RESERVED_114,
  REPORT_TYPE_RESERVED_115,
  REPORT_TYPE_RESERVED_116,
  REPORT_TYPE_RESERVED_117,
  REPORT_TYPE_RESERVED_118,
  REPORT_TYPE_RESERVED_119,

  REPORT_TYPE_RESERVED_120,
  REPORT_TYPE_RESERVED_121,
  REPORT_TYPE_RESERVED_122,
  REPORT_TYPE_RESERVED_123,
  REPORT_TYPE_RESERVED_124,
  IMAGE_REPORT_RX_RX_SHORT_RT125,
  IMAGE_REPORT_TX_TX_SHORT_RT126,
  REPORT_TYPE_RESERVED_127,
  REPORT_TYPE_RESERVED_128,
  REPORT_TYPE_RESERVED_129,
  REPORT_TYPE_RESERVED_130,
  REPORT_TYPE_RESERVED_131,
  REPORT_TYPE_RESERVED_132,
  REPORT_TYPE_RESERVED_133,
  REPORT_TYPE_RESERVED_134,
  REPORT_TYPE_RESERVED_135,
  IMAGE_REPORT_RAW_TRANS_ADC_RT136,
  REPORT_TYPE_RESERVED_137,
  IMAGE_REPORT_RAW_TRANS_ADC_RT138,

  IMAGE_REPORT_TYPE_NUM
} commReportType_t;

/**
 * Codes for standard debug reports. You can add your own debug
 * reports by using a number that isn't already used below. Document
 * each with information about how the data is encoded.
 */

typedef enum
{
/**
 * Zero-padded delta image report. This is an array of int16s of
 * length (MAX_TX+2)*(MAX_RX+1)+1. Using x to represent image pixels
 * and zeros to indicate zero-padding, the image is stored like this:
 *
 *   0 0 0 ... 0 0 0
 *   0 x x ... x x x
 *   ...   ...   ...
 *   0 x x ... x x x
 *   0 0 0 ... 0 0 0 0 <- note this extra zero
 *
 * where memory addresses increase by one uint16 as you move right
 * from a column to its neighbor and by MAX_TX+1 as you move down from
 * a row to its neighbor.
 */
  DBGREPORT_IMAGE_DELTA_PADDED = IMAGE_REPORT_TYPE_NUM,
  DBGREPORT_PROX_X_DELTA,            // Abs proximity X delta report. This is an array of int32s of length MAX_RX
  DBGREPORT_PROX_Y_DELTA,            // Abs proximity Y delta report. This is an array of int32s of length MAX_TX.
  DBGREPORT_HYBRID_X_DELTA,          // Abs hybrid X delta report. This is an array of int16s of length MAX_RX
  DBGREPORT_HYBRID_Y_DELTA,          // Abs hybrid Y delta report. This is an array of int16s of length
  DBGREPORT_POWER_IM,                // Power IM value. This is a single uint16.
  DBGREPORT_CID_IM,                  // CID IM value. This is a single uint16.
  DBGREPORT_VAR_CID_IM,              // CID Variance IM value. This is a single uint16.
  DBGREPORT_RAIL_IM,                 //RAIL IM value. This is a single uint16.
  DBGREPORT_NSM_STATE,               //Noise State Machine current state. This is a single uint16, with possible values: NSM_OFF_STATE, NSM_HNM_STATE, NSM_FNM_STATE, NSM_FNM_CID_STATE.
  DBGREPORT_NSM_FREQ,                //Current sense frequency. This is a single uint16. The value indicates the index into the sense frequency table that is currently being used.
  DBGREPORT_CYCLES,                  //Number of cycles used to acquire a frame. This is a single uint32.
  DBGREPORT_BUTTON_DELTA,            //Button transcap delta values. This is an array of int16s of length MAX_BUTTONS.
  DBGREPORT_IMAGE_LABELS_PADDED,     //Zero-padded object label image. This is an array of uint16s of the same size and stored the same way as the padded delta image.
  DBGREPORT_DOZE_DELTA,              //Doze delta image. This is an array of int16s of length MAX_RX*2. The first MAX_RX elements represent the first doze cluster, and thesecond MAX_RX elements represent the second doze cluster.
  DBGREPORT_IMAGE_RAW,               //Raw image. This is an array of uint16s with MAX_TX rows and MAX_RX columns, stored such that addresses change by one when you move from a column to its neighbor.
  DBGREPORT_IMAGE_BASELINE,          //Baseline image. This is an array of uint16s stored as the raw image.
  DBGREPORT_HYBRID_X_BASELINE,       //Abs Hybrid X baseline. This is an array of uint16s of length MAX_RX.
  DBGREPORT_HYBRID_Y_BASELINE,       //Abs Hybrid Y baseline. This is an array of uint16s of length MAX_TX.
  DBGREPORT_HYBRID_X_RAW,            //Abs Hybrid X raw data. This is an array of uint16s of length MAX_RX.
  DBGREPORT_HYBRID_Y_RAW,            //Abs Hybrid Y raw data. This is an array of uint16s of length MAX_TX.
  DBGREPORT_PROX_X_BASELINE,         //Abs proximity X baseline. This is an array of uint32s of length MAX_RX.
  DBGREPORT_PROX_Y_BASELINE,         //Abs proximity Y baseline. This is an array of uint32s of length MAX_TX.
  DBGREPORT_PROX_X_RAW,              //Abs proximity X raw data. This is an array of uint32s of length MAX_RX.
  DBGREPORT_PROX_Y_RAW,              //Abs proximity Y raw data. This is an array of uint32s of length MAX_TX.
  DBGREPORT_BUTTON_HYBRID_DELTA,     //Button hybrid delta. This is an array of uint16s of length MAX_BUTTONS.
  DBGREPORT_BUTTON_RAW,              //Button transcap raw values. This is an array of uint16s of length MAX_BUTTONS.
  DBGREPORT_BUTTON_HYBRID_RAW,       //Button hybrid raw values. This is an array of uint16s of length MAX_BUTTONS.
  DBGREPORT_BUTTON_BASELINE,         //Button transcap baseline values. This is an array of uint16s of length MAX_BUTTONS.
  DBGREPORT_BUTTON_HYBRID_BASELINE,  //Button hybrid baseline values. This is an array of uint16s of length MAX_BUTTONS.
  DBGREPORT_SUPERDOZE_DELTA,         //Super Doze delta image. This is an array of int16s of length 2.
  DBGREPORT_FRAME_RATE,
  DBGREPORT_CDM_IMAGE,
  DBGREPORT_CPUMONITOR,
  MAX_REPORT_TYPES,
} commDebugReportType_t;
#ifndef __CHIMERA__
#  pragma pack(pop)
#endif

/* ------------------------------------------------------------------- */

/**
 * Functions that must be implemented outside of Calc. All the COMM_*
 * functions are callbacks that Calc2 uses to communicate with the
 * outside world.
 */

/**
 * Tells whether the static or dynamic configuration has changed.
 *
 * Note--I'm thinking about deprecating this function. Static config
 * changes would be indicated through force update commands, and the
 * dynamic config would just be read fresh on each frame.
 */
configStatus_t COMM_checkForConfigChanges();

/**
 * Retrieves the static config. This function will only be called at
 * startup or when the configuration changes and is allowed to be
 * relatively expensive to execute.
 */
void COMM_getStaticConfig(calcStaticConfig_t *cfg);

/**
 * Retrieves the dynamic config. This function may be called on every
 * frame, so it should be relatively cheap to execute.
 */
void COMM_getDynamicConfig(calcDynamicConfig_t *cfg);

/**
 * Indicates that a frame has been completed and fully reported. In a
 * GUI, this will signal that the GUI can be repainted. In firmware,
 * this will signal that RMI functions such as Rmi4::newTimeEvent()
 * can be called and that the Watchdog timer can be cleared.
 */
void COMM_endFrame();

/**
 * Posts a production test report. Production test reports are
 * explicitly requested via commands. This function is allowed to
 * block, meaning it's fine if it doesn't return until after the
 * result has been consumed by the host.
 *
 * Note that unlike previous firmware, production test reports should
 * return data in the exact format that is needed by the host, and the
 * buffer sent by this function can be directly read via RMI
 * registers.
 */
void COMM_postProductionTestReport(prodTestResult_t *result);

/**
 * Posts an image report. This function is deprecated in favor of
 * postDebugReport and should no longer be used.
 */
void COMM_postImageReport(uint16 type, uint16 *data, uint16 len);

/**
 * Posts a touch report. The report should include all values in the
 * "standard" reports that the host will be reading on every frame.
 */
void COMM_postTouchReport(touchReport_t *r);

#if CONFIG_HAS_CROSSHAIR_TEST
void COMM_crosshairReport(touchReport_t *report);
#endif

/**
 * Posts a debug report.
 */
void COMM_postDebugReport(uint16 type, uint16 *data, uint16 len);

typedef const char ATTR_ROM romchar;
/**
 * Prints a message to the print buffer.
 */
void COMM_printf(romchar *s, ...);

/**
 * Pets a watch dog timer.
 */
void COMM_petWatchDog();

/**
 * Returns the highest priority pending command. Once a command is
 * complete, it must be removed from the queue with COMM_ackCommand()
 * before other commands will be seen. If there are no pending
 * commands, a CMD_NONE-type command will be returned.
 */
commCommand_t COMM_getNextCommand();

/**
 * Goes to sleep and waits for one of the specified commands. This is
 * only used when no sensing is occurring. The ASIC goes into the
 * lowest-power state until one of the commands in the list cmds is
 * received. This routine will need to clear the watchdog timer while
 * it waits. On Chimera chips, this function may borrow LST1 from the
 * acquisition thread to handle watchdog clearing only if it restores
 * the settings before returning.
 *
 * Here is a suggested firmware implementation:
 *
 *   commCommand_t COMM_waitForCommand(commCommandType_t cmds[], uint16 len)
 *   {
 *     uint16 i;
 *     commCommand_t cmd;
 *     uint16 oldINT_CTL_LST1;
 *     allowCommSoftwareInterrupt(TRUE); // tells the comm thread that it's allowed
 *                                       // to send software interrupts to the calc
 *                                       // thread
 *     THREAD_CTL.SWIEN = 1;
 *     // steal LST1 from DAQ
 *     oldINT_CTL_LST1 = INT_CTL_LST1.v;
 *     INT_CTL_LST1.INT_MAP = CALC_THREAD;
 *     INT_CTL_LST1.INT_EDGE = 0;
 *     INT_CTL_LST1.INT_EN = 1;
 *     LST_CTL.LST1_EN = 1;
 *     LST1_LIMIT.v = 0xF000; // slightly less than WDT timeout to ensure adequate margin for comm
 *     while(1)
 *     {
 *       THREAD_CTL.SWIFG = 0;
 *       cmd = COMM_getNextCommand();
 *       for (i = 0; i < len; i++)
 *       {
 *         if (cmd.cmd == cmds[i])
 *           goto done;
 *       }
 *       while (!THREAD_CTL.SWIFG) // The core deep-sleep loop, with as few instructions as possible
 *       {
 *         CLRWDT();
 *         INT_FLAGS.IFG_LST1 = 0;
 *         SLEEP;
 *       }
 *     }
 *   done:
 *     INT_CTL_LST1.v = oldINT_CTL_LST1;
 *     THREAD_CTL.SWIEN = 0;
 *     allowCommSoftwareInterrupt(FALSE);
 *     return cmd;
 *   }
 */
commCommand_t COMM_waitForCommand(commCommandType_t cmds[], uint16 len);

/**
 * Acknowledge completion of a command. RMI requires that command bits
 * in the register map be cleared *after* the command completes. The
 * host can poll this bit to figure out when it's safe to issue the
 * next command. Acknowledging a command is the only way to remove it
 * from the command queue.
 */
void COMM_ackCommand(commCommand_t cmd);

uint16 COMM_getEnterDeepSleep();
/**
 * Wakes up video thread.
 */
void COMM_wakeupVideoThread();

/**
 * Returns power status register value.
 */
uint16 COMM_getPowerStatus();

#if CONFIG_HAS_LPWG_MULTITAP
void COMM_updateMultiTapFailReason1Buffer(uint16 failedcount, uint16 failreason);
void COMM_updateActiveArea_XY(uint16 coord_x, uint16 coord_y);
void COMM_updateMultiTapFailReasonRealTimeInterrupt(uint16 failreason);
uint16 COMM_isMultiTapInterruptDelayTimeEnable();
uint16 COMM_gettenthToUnits(uint16 data, uint16 value);
uint16 COMM_getxMmToUnits(uint16 data) ;
uint16 COMM_getyMmToUnits(uint16 data) ;
#if CONFIG_LPWG_MULTITAP_FAIL_TAPCOUNT
void COMM_updateMultiTapFailOverTapCount(uint16 overtapcount);
#endif
#if CONFIG_LPWG_MULTITAP_INTRRDELAY
uint16 COMM_getMultiTapInterruptDelayTimeConvertedIntoFramesLPWG(uint16 report_rate);
#endif
uint16 COMM_getMultiTapMinTapTimeConvertedIntoFramesLPWG(uint16 report_rate);
uint16 COMM_getMultiTapMaxTapTimeConvertedIntoFramesLPWG(uint16 report_rate);

#if CONFIG_HAS_LPWG_DUALMULTITAP
void COMM_updateMultiTapFailReason2Buffer(uint16 failedcount, uint16 failreason);
#if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
uint16 COMM_getMultiTapInterruptDelayTimeConvertedIntoFramesLPWG_DualMultiTap(uint16 report_rate);
#endif
uint16 COMM_getMultiTapMinTapTimeConvertedIntoFramesLPWG_DualMultiTap(uint16 report_rate);
uint16 COMM_getMultiTapMaxTapTimeConvertedIntoFramesLPWG_DualMultiTap(uint16 report_rate);
#endif

#endif

#if CONFIG_HAS_LPWG_POWERREDUCTION
uint16 COMM_getS0ReportRateLPWG(void);
uint16 COMM_getS0FalseActivationThreshold(void);
uint16 COMM_getS0Timer1(void);
uint16 COMM_getS0MaxActiveDuration(void);
uint16 COMM_getS0MaxActiveDurationTimeout(void);
uint16 COMM_readReg_AdjDoze(void);
#endif

#if CONFIG_HIC_LPWG_MODE_B
uint16 COMM_getEnterDeepSleep(void);
uint16 COMM_getS0ReportRateModeBLPWG(void);
uint16 COMM_getS0ReportRateModeBTRGT(void);
uint16 COMM_getS0DisplayModeBdisplayRefresh(void);
uint16 COMM_getS0DisplayModeBdisplayRefreshInterval(void);
uint16 COMM_getS0ExtraBaselineFramesModeBLPWG(void);
uint16 COMM_getS0ExtraBaselineFramesModeBTRGT(void);
uint16 COMM_isForceTRGT(void);
uint16 COMM_reportFingersInTRGT(void);
uint16 COMM_getLpwgModeBState(void);

void COMM_postFingerDetectionReport(fingerDetectionReport_t *fingerDetection);
void COMM_clearResetGestureCounters();
void COMM_exitTRGT(void);
void COMM_detectGesture(uint16 detected);
#endif

uint16 COMM_getFaceDetectEnable(void);
uint16 COMM_getPsmState(void);

void COMM_setDeepSleep(uint16 enterDeepSleep);
void COMM_setReportRate(uint16 reportRate ATTR_UNUSED);

#if CONFIG_IFP_ESD_ACTIVEMODE
uint16 COMM_getFingerCnt(void);
#endif

void COMM_selectVideoTimingTable(uint16 table);
uint16 COMM_isSelectedVideoTimingTable(void);

#if CONFIG_NSM_EUROPA && CONFIG_HAS_BASELINE_COMPENSATION
void COMM_getNsmIfpStaticConfig(calcStaticConfig_t *scfg);
#endif
#if CONFIG_HAS_TDDI_ESD_HANDLER
void COMM_Issue_ESD_Self_Recovery();
void COMM_Report_ESD_Self_Recovery();
#endif
void copy2DToFrameBuffer(deltaImage_t *img, PLFrameData_t *frameBufferPtr);

#if CONFIG_LOCAL_CBCSCAN_HYBRID
void COMM_setHybridLocalCBCs(uint16 *hybridCBCArray, daqParams_t *d);
#endif
#if CONFIG_HAS_RT125_LCBC
void COMM_getHybridLocalCBCs_Logical(uint16 *hybridCBCArray);
void COMM_setHybridLocalCBCs_Logical(uint16 *hybridCBCArray);
#endif
#if CONFIG_GLOBAL_CBCSCAN_HYBRID
void COMM_setHybridGlobalCBCs(uint16 gcbcRx, uint16 gcbcTx);
#endif
void COMM_setHybridCBCAutoServo();
#if IS_TD4353
uint16 COMM_calcFramePeriod(void);
#endif
void COMM_updateHybridSingleLocalCBC(uint16 index, uint16 value);
void COMM_updateHybridTxGcbc(uint16 gcbc);
/**
 * Calc2 functions
 */
void calc_mainLoop(void);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // _CALC2_H
