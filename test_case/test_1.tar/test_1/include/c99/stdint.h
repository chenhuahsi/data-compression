/* syna_stdint.h
 * Synaptics version of stdint.h header
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 */

#ifndef _STDINT_H
#define _STDINT_H 1

#ifdef __T100X_VOID_ALIGNMENT__ // compiler supports 8-bit chars

typedef char int8_t;
typedef char int_least8_t;
typedef unsigned char uint8_t;
typedef unsigned char uint_least8_t;
typedef unsigned int uint_fast8_t;

#define INT8_MAX 127
#define INT8_MIN -128
#define UINT8_MAX 255

#define INT_LEAST8_MAX 127
#define INT_LEAST8_MIN -128
#define UINT_LEAST8_MAX 255

#else

typedef int int_least8_t;
typedef unsigned int uint_least8_t;

#define INT_LEAST8_MAX 32767
#define INT_LEAST8_MIN (-32767 - 1)
#define UINT_LEAST8_MAX 65535U

#endif // __T100X_VOID_ALIGNMENT__

typedef int int_fast8_t;

#define INT_FAST8_MAX 32767
#define INT_FAST8_MIN (-32767 - 1)
#define UINT_FAST8_MAX 65535U

// no 64-bit, 56-bit, 48-bit, 40-bit, or 24-bit types are supported.

typedef int int16_t;
typedef int int_least16_t;
typedef int int_fast16_t;
typedef unsigned int uint16_t;
typedef unsigned int uint_least16_t;
typedef unsigned int uint_fast16_t;
typedef long int32_t;
typedef long int_least32_t;
typedef long int_fast32_t;
typedef unsigned long uint32_t;
typedef unsigned long uint_least32_t;
typedef unsigned long uint_fast32_t;
typedef long intmax_t;
typedef unsigned long uintmax_t;
typedef int intptr_t;
typedef unsigned int uintptr_t;

#define INT32_MAX 2147483647
#define INT32_MIN (-2147483647 - 1)
#define INT_LEAST32_MAX 2147483647
#define INT_LEAST32_MIN (-2147483647 - 1)
#define INT_FAST32_MAX 2147483647
#define INT_FAST32_MIN (-2147483647 - 1)
#define UINT32_MAX 4294967295U
#define UINT_LEAST32_MAX 4294967295U
#define UINT_FAST32_MAX 4294967295U

#define INT16_MAX 32767
#define INT16_MIN (-32767 - 1)
#define INT_LEAST16_MAX 32767
#define INT_LEAST16_MIN (-32767 - 1)
#define INT_FAST16_MAX 32767
#define INT_FAST16_MIN (-32767 - 1)
#define UINT16_MAX 65535U
#define UINT_LEAST16_MAX 65535U
#define UINT_FAST16_MAX 65535U

#define INTPTR_MAX INT16_MAX
#define INTPTR_MIN INT16_MIN
#define UINTPTR_MAX UINT16_MAX

#define INTMAX_MAX INT32_MAX
#define INTMAX_MIN INT32_MIN
#define UINTMAX_MAX UINT32_MAX

#endif // _STDINT_H
