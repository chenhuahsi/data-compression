#ifndef _STDDEF_H
#define _STDDEF_H 1

#define NULL (0)
#define offsetof(t, m) ((size_t)(&((t *)0)->m))

typedef unsigned int size_t;
typedef int ptrdiff_t;
#ifndef __cplusplus
typedef unsigned int wchar_t;
#endif

#endif // _STDDEF_H
