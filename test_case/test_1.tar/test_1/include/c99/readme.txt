===================================
 Synaptics C99 Compatibility Layer
===================================

:Author: Joel Jordan
:Date: 2/11/2015

These header files provide basic C99 compatibility. They are intended
to make it easier to write cross-platform code targeting our ASICs.

Build code with these headers and then compile it with t100x-gcc,
using ``-mthread=64`` and ``-manyromcalls`` to build ANY_ROM
calculation-thread code.

To link your code with other firmware, you will need to provide a
header file for your code that uses the
``ATTR_THREAD(_thr_Calculation)`` and ``ATTR_ANYROM`` annotations on
all your external function declarations.
