#ifndef _STRING_H
#define _STRING_H 1

#include "stddef.h"

/* Note: these routines are not strictly standards-compliant because
 * they use uint16 * instead of void * and uint16 for lengths instead
 * of size_t. The implication is that addresses must be 16-bit
 * aligned. Also, the length arguments are given in unsigned chars but
 * are assumed to be even if sizeof(uint16) == 2. */

static inline unsigned int *_memset(unsigned int *s, unsigned int c, size_t n)
{
  unsigned int *p = s;
  unsigned int cc = c + (c << 8);
  n /= sizeof(unsigned int);
  for (; n > 0; n--)
    *p++ = cc;
  return s;
}

static inline unsigned int *_memcpy(unsigned int *s1, const unsigned int *s2, size_t n)
{
  unsigned int *p = s1;
  n /= sizeof(unsigned int);
  for (; n > 0; n--)
    *p++ = *s2++;
  return s1;
}

/* These macros are required to coax the pointers into the correct
 * format. On a Chimera, word-aligned byte pointers can be converted
 * to unsigned int *, but non-aligned byte pointers will fail
 * silently.*/

#define memcpy(s1, s2, n) _memcpy((unsigned int *)(s1), (const unsigned int *)(s2), (size_t) (n))
#define memset(s1, c, n) _memset((unsigned int *)(s1), (unsigned int) (c), (size_t) (n))

#endif // _STRING_H
