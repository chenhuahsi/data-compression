#ifndef _PLATFORM_H
#define _PLATFORM_H 1
/* -----------------------------------------------------------------
 * Platform - Defines a common interface for different sensors
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 *
 * This file defines the interface to Platform objects. Documentation
 * is given inline.
 */

#include "calc_config.h"
#include "syna/syna_types.h"
#if defined(__CHIMERA__) || defined(__COMMSIM__)
#include <config_all_chips.h>
#define IS_ANY_TDDI_HIC (IS_HYBRID_IN_CELL && IS_ANY_TDDI)
#elif defined(__UNITTEST__)
#include "unittest_asic.h"
#elif defined(_MSC_VER)
#include "calc2forpc_asic.h"
#else
#include "syna/syna_asic.h"
#endif
/* You must define a preprocessor symbol to indicate which platform
 * you are using. This will take the form of PLATFORM_xxxx. You must
 * define which ASIC is being used separately.
 *
 * Valid choices include:
 *   PLATFORM_TWOHARBORS - TH2411, TH2412, TH2421
 *   PLATFORM_WAIKIKI - T1327
 */

/* Include the platform-specific header file to define the data
 * acquisition parameters and frame types.
 */
#if PLATFORM_TD4310 == 1
#include "../src/platform/td4310/pl_configure_sensor.h"
#include "../src/platform/td4310/production_test.h"
#elif PLATFORM_TD4322 == 1
#include "../src/platform/td4322/pl_configure_sensor.h"
#include "../src/platform/td4322/production_test.h"
#elif PLATFORM_TD4328 == 1
#include "../src/platform/td4328/pl_configure_sensor.h"
#include "../src/platform/td4328/production_test.h"
#elif PLATFORM_TD4302 == 1
#include "../src/platform/td4302/pl_configure_sensor.h"
#include "../src/platform/td4302/production_test.h"
#elif PLATFORM_TD4303 == 1
#include "../src/platform/td4303/pl_configure_sensor.h"
#include "../src/platform/td4303/production_test.h"
#elif PLATFORM_TD4353 == 1
#include "../src/platform/td4353/pl_configure_sensor.h"
#include "../src/platform/td4353/production_test.h"
#elif PLATFORM_TD4100 == 1
#include "../src/platform/td4100/pl_configure_sensor.h"
#include "../src/platform/td4100/production_test.h"

/* Please put other platform definitions in front of PLATFORM_TDDI.
*   Otherwise matlab unittest will include wrong files.
*/
#elif PLATFORM_TDDI == 1
#include "../src/platform/td4300/pl_configure_sensor.h"
#include "../src/platform/td4300/production_test.h"
#else
#error "No Platform header defined"
#endif

// pure C wrapper functions of platformapi.
#ifdef __cplusplus
extern "C"{
#endif

  // Forward-declare some Calc2 structures we need pointers to. This
  // prevents us from having to include header files in a specific
  // order.
  struct calcStaticConfig_t;
  struct calcDynamicConfig_t;

  void PL_init(struct calcStaticConfig_t *scfg, struct calcDynamicConfig_t *dcfg);
  void PL_setParam(PLParam_t param_type, uint16 param_value);
  uint16 PL_isDozeTimerResetRequested();
  uint16 PL_isNSMInitialized();
  PLNSMState_t PL_getNSMState();
  uint16 PL_getNSMTransClusters();
  uint16 PL_getNSMNoiseBursts();
  uint16 PL_getNSMFreqScanBursts();
  void PL_enterMode(PLMode_t mode);
  PLFrame_t *PL_getFrame(PLFrameType_t frameType);
  void PL_releaseFrame(PLFrame_t *frame);
  void PL_convertActiveFrameToRawCap(PLFrameData_t *frame, PLCapData_t *cap);
  void PL_convertDozeFrameToRawCap(PLFrameData_t *frame , PLCapData_t *cap);
  void PL_convertActiveFrameToDeltaCap(PLFrameData_t *frame, PLCapData_t *cap);
  void PL_getTestFrame(prodTestType_t test, struct calcStaticConfig_t *scfg,
                       struct calcDynamicConfig_t *dcfg, prodTestResult_t *result);
  void PL_copy0DToFrameBuffer(uint16 isAbsBtnData ATTR_UNUSED, uint16 *btnDataPtr, PLFrameData_t *frameBufferPtr);
  void PL_0DButtonsScaling(uint16 *btnDataPtr, uint16 *btnScaleFactor);
  PLAdcLimits_t PL_getADCLimits();
  void PL_convertToIFPFormat(struct calcStaticConfig_t *scfg);
  uint16 PL_isDozeWakeUpCondition(struct dozeParams_t *dozeConfig, int16 *deltaImage, uint16 size);
  void PL_setupFreqScanFrame();
  void PL_disableFreqScanFrame();
  void PL_setupRcvrOffsetFrame();
  void PL_disableRcvrOffsetFrame();
  PLFrame_t *PL_getRcvrOffsetFrame();
  void PL_checkPowerStatus();
  void PL_calibrateButtons();
  void PL_setCurrentRate(uint16 rate);
  void PL_findBestCbcs(struct calcStaticConfig_t *scfg, PLCBCType_t cbcType);
  void PL_getCbcs(PLCBCType_t cbcType, uint16 **CBCs);
  void PL_storeCbcs();
  void PL_restoreCbcs();
  void PL_updateTestModeLCBC(uint16 *CBCs_L, uint16 *CBCs_R);
  uint16 PL_hybridCBCAutoCorrection(struct calcStaticConfig_t *cfg, uint16 objectsPresent, uint16 *rawRx, uint16 *rawTx);

#ifdef __cplusplus
} // extern "C"
#endif

#endif
