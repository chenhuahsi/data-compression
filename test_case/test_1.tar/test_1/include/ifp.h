/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

  Description: Externally visible common definitions for image processing functions.
----------------------------------------------------------------- */

#ifndef _IFP_H
#define _IFP_H

// calc_config.h contains the build parameters MAX_RX, etc.
#include "calc_config.h"
#include "syna/syna_types.h"

#ifdef __CHIMERA__
  #define ATTR_ROM  __attribute__ ((rom))
  #define IFP_STACKED __attribute__ ((stacked))
  #if !defined(_SYNA_TYPES_H) && !defined(SILICON_H)
    typedef int int16;
    typedef unsigned int uint16;
    typedef long int32;
    typedef unsigned long uint32;
    typedef const int16 ATTR_ROM rom_int16;
    typedef const uint16 ATTR_ROM rom_uint16;
  #endif
#else
  #define ATTR_ROM
  #define IFP_STACKED
  #ifndef _SYNA_TYPES_H
    typedef short int16;
    typedef unsigned short uint16;
    typedef const int16 rom_int16;
    typedef const uint16 rom_uint16;
    typedef int int32;
    typedef unsigned int uint32;
  #endif
#endif // __CHIMERA__

#ifndef _SYNA_TYPES_H
  typedef int16 int8p8;
  typedef int16 int1p15;
  typedef int16 int4p12;
  typedef int16 int14p2;
  typedef uint16 uint8p8;
  typedef uint16 uint0p16;
  typedef uint16 uint1p15;
  typedef uint16 uint4p12;
  typedef uint16 uint9p7;
  typedef uint16 uint10p6;
  typedef uint16 uint12p4;
  typedef uint16 uint14p2;
  typedef int32 int16p16;
  typedef int32 int24p8;
  typedef int32 int28p4;
  typedef uint32 uint16p16;
  typedef uint32 uint24p8;
  typedef uint32 uint26p6;
#endif

/* When building chimsim, you have to define CHIMSIM_TYPES to avoid aliasing
 * the typedefs above. However, chimsim requires an int64 for keeping track of
 * time. Note that int64 is not available within Chimera itself. */
#ifdef CHIMSIM_TYPES
  #ifndef int64
    #ifdef _MSC_VER
      #include <Windows.h>
      typedef LONGLONG int64;
    #else
      #include <stdint.h>
      typedef int64_t int64;
    #endif
  #endif
#endif

// Check configuration completeness
#ifndef MAX_RX
  #error "must define MAX_RX"
#endif
#ifndef MAX_TX
  #error "must define MAX_TX"
#endif
#ifndef MAX_ABS_RX
  #error "must define MAX_ABS_RX"
#endif
#ifndef MAX_ABS_TX
  #error "must define MAX_ABS_TX"
#endif
#ifndef MAX_OBJECTS
  #error "must define MAX_OBJECTS"
#endif
#ifndef MAX_BUTTONS
  #error "must define MAX_BUTTONS"
#endif
#ifndef CONFIG_HAS_HYBRID
  #error "must define CONFIG_HAS_HYBRID"
#endif
#ifndef CONFIG_HAS_LGM_CORRECTOR
  #error "must define CONFIG_HAS_LGM_CORRECTOR"
#endif
#ifndef CONFIG_HAS_LINEAR_SWIPE_SPLITTER
  #error "must define CONFIG_HAS_LINEAR_SWIPE_SPLITTER"
#endif
#ifndef CONFIG_HAS_SMALL_OBJECT_DETECTOR
  #error "must define CONFIG_HAS_SMALL_OBJECT_DETECTOR"
#endif
#ifndef CONFIG_HAS_0D_BUTTONS
  #error "must define CONFIG_HAS_0D_BUTTONS"
#endif
#ifndef CONFIG_IMAGE_DELTA_IS_POSITIVE
  #error "must define CONFIG_IMAGE_DELTA_IS_POSITIVE"
#endif
#ifndef CONFIG_HAS_RX_MUXING
  #error "must define CONFIG_HAS_RX_MUXING"
#endif
#ifndef CONFIG_HAS_TX_MUXING
  #error "must define CONFIG_HAS_TX_MUXING"
#endif
#ifndef CONFIG_HAS_THICK_GLOVE
  #error "must define CONFIG_HAS_THICK_GLOVE"
#endif
#ifndef CONFIG_HAS_MOISTURE
  #error "must define CONFIG_HAS_MOISTURE"
#endif
#ifndef CONFIG_HAS_SHADOW_REMOVER
  #error "must define CONFIG_HAS_SHADOW_REMOVER"
#endif
#ifndef CONFIG_HAS_FIST_REJECT
  #error "must define CONFIG_HAS_FIST_REJECT"
#endif
#ifndef CONFIG_HAS_ANTI_BENDING
  #error "must define CONFIG_HAS_ANTI_BENDING"
#endif
#ifndef CONFIG_HAS_KALMAN_FILTER
  #error "must define CONFIG_HAS_KALMAN_FILTER"
#endif

// Check configuration sanity
#if CONFIG_HAS_TX_MUXING && CONFIG_HAS_RX_MUXING
  #error "Muxing is supported only for TX or RX, not both. Set at least one between CONFIG_HAS_TX_MUXING and CONFIG_HAS_RX_MUXING to zero."
#endif
#if MAX_ABS_RX != 1 && MAX_ABS_RX != MAX_RX
   #error "MAX_ABS_RX must be 1 or MAX_RX"
#endif
#if MAX_ABS_TX != 1 && MAX_ABS_TX != MAX_TX
   #error "MAX_ABS_TX must be 1 or MAX_TX"
#endif
#if MAX_BUTTONS == 0
  #error "MAX_BUTTONS must be non-zero. Disable button support with CONFIG_HAS_0D_BUTTONS = 0."
#endif

#if MAX_OBJECTS < 16 && MAX_BUTTONS < 16
  typedef uint16 objectBitmask_t;
  #define OBJECT_BITMASK_SIZE 16
#elif MAX_OBJECTS < 32 && MAX_BUTTONS < 32
  typedef uint32 objectBitmask_t;
  #define OBJECT_BITMASK_SIZE 32
#else
  #error "MAX_OBJECTS >= 32 and MAX_BUTTONS >= 32 is not supported"
#endif

#define MAX_PEAKS 2*MAX_OBJECTS

// If we have abs on both axes, then turn on hybrid features.
// Technically, we can do hybrid baseline with one hybrid abs axis,
// but it's uncommon enough that you can just hack this and ifp_common.h if
// you need it.
#if CONFIG_HAS_HYBRID && (MAX_ABS_TX != MAX_TX || MAX_ABS_RX != MAX_RX)
  #error "CONFIG_HAS_HYBRID requires MAX_ABS_TX == MAX_TX and MAX_ABS_RX == MAX_RX"
#endif

#if !CONFIG_HAS_HYBRID
  #if CONFIG_HAS_LGM_CORRECTOR
    #error "CONFIG_HAS_LGM_CORRECTOR requires CONFIG_HAS_HYBRID"
  #endif
  #if CONFIG_HAS_THICK_GLOVE
    #error "CONFIG_HAS_THICK_GLOVE requires CONFIG_HAS_HYBRID"
  #endif
  #if CONFIG_HAS_MOISTURE
    #error "CONFIG_HAS_MOISTURE requires CONFIG_HAS_HYBRID"
  #endif
  #if CONFIG_HAS_FIST_REJECT
    #error "CONFIG_HAS_FIST_REJECT requires CONFIG_HAS_HYBRID"
  #endif
#endif

#ifndef MAX_PROFILE_SIZE
 #define MAX_PROFILE_SIZE (((MAX_ABS_RX) > (MAX_ABS_TX)) ? MAX_ABS_RX : MAX_ABS_TX)
#endif

// We would like structs to have the same layout on t100x-gcc, gcc, and VC++.
// Force struct packing to be 16-bit everywhere. Note that t100x-gcc makes an
// exception for floats and longs (32-bit), where it will force 32-bit
// alignment in structs. As we can't express this exception with the pack
// pragma, we'd just have to handle ChimSim<->mex manually for float or long
// members. Except(!), we can specify -mhas-aligned-longs=0, so at least longs
// get pack-compatible layouts and only floats are the special case.
#ifndef __CHIMERA__
  #pragma pack(push)
  #pragma pack(2)
#endif

typedef uint16 ifpTimeStamp_t;

typedef struct
{
  uint16 *rawImage;
  uint16 *rawProfileRX;
  uint16 *rawProfileTX;
  uint16 *rawTransButtons;
  uint16 *rawAbsButtons;
} ifpFrame_t;

typedef objectBitmask_t buttonsBitmask_t;

typedef struct
{
  buttonsBitmask_t state;
  uint16 freshData; // : 1;
  uint16 objectPresent; // : 1;
} buttons0DReport_t;

typedef enum
{
  dataType_abs = 0,
  dataType_trans = 1
} dataType_t;

typedef struct
{
  uint16  buttonsSaturation[MAX_BUTTONS];
  uint16  buttonsVarianceThreshold;
  uint8p8 buttonsFingerThreshold_pct;
  uint8p8 buttonsGloveThreshold_pct;
  uint8p8 buttonsBaselineRelaxationCoeff;
  uint8p8 buttonsFastBaselineRelaxationCoeff;
  uint16  reportOnlyOneButton;
  uint16  buttonsOffFor2DTouchMaxFrames;
  uint16  buttonsGloveLandingMaxFrames;
  uint16  buttonsDataType;

  uint16  buttonsThinGloveFIRCoeff;
  uint8p8 buttonsThinGloveThreshold_pct;
  uint16  buttonsGroupMask;
  uint8p8 buttonsStrongestButtonsHysteresis_pct;
  uint8p8 buttonsReleaseThreshold_pct;
  uint16  buttonsFreshDataMask;
  uint16  buttonsDebouncingFilterStrength;
  uint16  buttonsNoiseFloor                : 8;
  uint16  buttonsEnergyRatio               : 8;
  uint16  buttonsMaxIncreasedVariance      : 8;
  uint16  buttonsThermalUpdateInterval_ms  : 8;
  uint16  buttonsFastHalflife_ms           : 8;
  uint16  buttonsHoldFastTransition_ms     : 8;
  uint16  buttonsFastRelaxDuration_ms      : 8;
  uint16  buttonGloveEnable                : 1;
  uint16  reserved                         : 7;
} buttons0DConfig_t;

typedef struct
{
  uint16 col:8;
  uint16 row:8;
} pixelIndex_t;

#if CONFIG_HAS_NOTCH_CUT
#define MAX_CUT_OUTS 20
#endif

typedef enum{
    faceDetectAxesCfg_absRxTransTx = 1,
    faceDetectAxesCfg_absTxTransRx = 2,
    faceDetectAxesCfg_both         = 3, // UNUSED so far
} faceDetectAxesCfg_t;

typedef struct
{
   //
   // ATTENTION: this MUST be in sync with func_12.h F12_S0_FaceDetect struct, until the names get synched up !
   //
  uint16 enable_Face_Detect_2                       : 1 ;
  uint16 enable_Face_Detection_RX                   : 1 ;
  uint16 enable_Face_Detection_TX                   : 1 ;
  uint16 face_Detect_Display_Status                 : 1 ;
  uint16 face_Detect_Rx_primary                     : 1 ;
  uint16                reserved1 : 3;

  //Face detect filter shift coefficients
  uint16 fs_init : 8; // initialize filters with 2^(fs_init) samples [int8] (default: 5)                          Initialization_Coefficient

  //Face detect thresholds
  uint16 ft_update_rx; // threshold at/below which to flag rx as allowing slow-filter update [int32] (default: 15) Update_Threshold_RX
  uint16 ft_hover_rx;  // threshold at/above which to flag rx as hover, but less than touch [int32] (default: 40)  Hover_Threshold_RX
  uint16 ft_touch_rx;  // threshold at/above which to flag rx as touched [int32] (default: 250)                    Touch_Threshold_RX
  uint16 ft_hold_rx;   // threshold at/above which to flag rx as halting slow-filter update [int32] (default: 25)  Hold_Threshold_RX

  uint16 ft_update_tx; // threshold at/below which to flag rx as allowing slow-filter update [int32] (default: 15) Update_Threshold_TX
  uint16 ft_hover_tx;  // threshold at/above which to flag rx as hover, but less than touch [int32] (default: 40)  Hover_Threshold_TX
  uint16 ft_touch_tx;  // threshold at/above which to flag rx as touched [int32] (default: 250)                    Touch_Threshold_TX
  uint16 ft_hold_tx;   // threshold at/above which to flag rx as halting slow-filter update [int32] (default: 25)  Hold_Threshold_TX

  //Face-detect entry and exit hysteresis
  uint16 fn_set : 8;  // number of consecutive face-detect samples to set face-detect bit [uint8] (default: 15) Face_Detect_Set_Frames
  uint16 fn_unset : 8;  // number of consecutive blank samples to unset face-detect bit [uint8] (default: 25)     Face_Detect_Clear_Frames

  //Thresholds trex.counter
  uint16 fn_update_rx: 8; // number of update-flagged receivers to allow slow-filter update [uint8] (default: 1)          update_flagged_RX_to_allow_slow_filter_update
  uint16 fn_hover_rx : 8; // number of hover-flagged receivers to even consider setting face-detect [uint8] (default: 12) hover_flagged_RX_for_face_detect
  uint16 fn_touch_rx : 8; // number of touch-flagged receivers allowed when considering face-detect [uint8] (default: 0)  touch_flagged_RX_for_face_detect
  uint16 fn_hold_rx  : 8; // number of hold-flagged receivers to halt slow-filter update [uint8] (default: 2)             hold_flagged_RX_to_halt_slow_filter_update

  uint16 fn_update_tx: 8; // number of update-flagged receivers to allow slow-filter update [uint8] (default: 1)          update_flagged_TX_to_allow_slow_filter_update
  uint16 fn_hover_tx : 8; // number of hover-flagged receivers to even consider setting face-detect [uint8] (default: 12) hover_flagged_TX_for_face_detect
  uint16 fn_touch_tx : 8; // number of touch-flagged receivers allowed when considering face-detect [uint8] (default: 0)  touch_flagged_TX_for_face_detect
  uint16 fn_hold_tx  : 8; // number of hold-flagged receivers to halt slow-filter update [uint8] (default: 2)             hold_flagged_TX_to_halt_slow_filter_update

  //Filter initialization
  uint16 fn_test     : 4; // number of samples to use for filter test [int8] (default: 15) Num_samples_for_filter_test
  uint16 fn_redo     : 4; // test maximum which triggers filter reset [int8] (default: 10) Filter_Reset_Threshold

  //Edge Exclusion.
  uint16 fn_front_omit_rx : 8;   // half-count of front-edge-rx to exclude from algorithm [uint8] (default: 1) RX_Low_Edge_Exclusion_Size
  uint16 fn_end_omit_rx   : 8;   // half-count of end-edge-rx to exclude from algorithm [uint8] (default: 1)   RX_High_Edge_Exclusion_Size

  uint16 fn_front_omit_tx : 8;   // half-count of front-edge-rx to exclude from algorithm [uint8] (default: 1) TX_Low_Edge_Exclusion_Size
  uint16 fn_end_omit_tx   : 8;   // half-count of end-edge-rx to exclude from algorithm [uint8] (default: 1)   TX_High_Edge_Exclusion_Size

  uint16 txCount : 8; // # of rows
  uint16 rxCount : 8; // # of columns
} faceDetectConfig_t;

//Side Touch
#define BUF_H 3
#define BUF_W 3

typedef enum{
  stFIR_none,
  stFIR_211,
  stFIR_1111,
} sideTouchTemporalFilterType_t;

typedef enum{
  stSpatial_none,
  stSpatial_LoG,
  stSpatial_Gaussian,
} sideTouchFilterType_t;

typedef enum{
  stBufType_rawProfileBuf,
  stBufType_baselineBuf,
  stBufType_temperalFilteredProfileBuf,
} sideTouchBufferType_t;

typedef struct {
  int16 index;
  int16 positionBuf[3];
  int16 time;
  int16 swipeDownStatus;
  int16 swipeUpStatus;
  int16 tapStatus;
  int16 stillExist;
  int16 startPosition;
  int16 currentPosition;
  int16 amplitude;
  int16 filterStateFrameN;
  int16 semiTap;
  int16 prepareSemiTap;
  int16 suppressEdge;
  int16 isLargeObject;
  int16 peakPosition;
  int16 reportFlag;
  int16 maxAmplitude;
} sideFinger_t;

typedef struct
{
  int16 stColNum; //The number of side touch pixels
  int16 stRowNum;
  int16 positionDefault;
  //tuning parameters
  int16 temporalFilterType;
  int16 spatialFilterType;  //filterType
  int16 profileDiffPeakTh_pct; //swipe_profileDiffLoG_percent
  int16 profileDiffPeakTh;     //profileDiffLoG_peak_Th
  int16 profileDiffFingerLift_pct; //diff_lift_percent
  int16 negToPosDistanceTh; //swipe_neg_pos_distance_th
  int16 overshoot_pct;  //swipe_overshoot_percent
  //shared
  int16 fingerValley_pct; //obj.grip_finger_valley_percent,
  int16 noiseTh; //obj.deltaProfile_noise_th
  int16 noiseTh_pct;  //area_noise_th_scale
  int16 lastPixelValTh;
  int16 largeObjectPositionTh;
  int16 largeObjectAreaTh;
  int16 tapPositionDiffTh;   //tap_position_diff_th
  int16 tapTimeMaxTh;    //tap_time_hi_th
  int16 tapTimeMinTh;   //tap_time_lo_th
  int16 fingerTrackingDistTh; //swipe_tracking_th
  int16 swipeMinSpeedTh;  //swipe_min_speed_th
} sideTouchDifferentialConfig_t;

typedef struct {
    int16 leftSwipeUp;
    int16 leftSwipeDown;
    int16 leftSwipeLastPosition;
    int16 leftSwipeCurrentPosition;
    int16 rightSwipeUp;
    int16 rightSwipeDown;
    int16 rightSwipeLastPosition;
    int16 rightSwipeCurrentPosition;
} sideButtonsGestureReport_t;

typedef struct {
  int16 swipeUp;
  int16 swipeDown;
  int16 swipeStartPosition;
  int16 swipeCurrentPosition;
} sideTouchSwipeRecord_t;

typedef struct {
  uint16 windowSize;
  uint16 tOffset;
  uint16 sideFingerThreshold;
  uint16 staticFingerThreshold;
  uint16 neighbors;
} sideTouchTemporalFilter_t;

typedef struct
{
  uint16 enableX : 1;
  uint16 enableY : 1;
} absFilterConfig_t;

#ifndef MAX_TAGS_PUNCH_OUTS
#define MAX_TAGS_PUNCH_OUTS 50
#endif
typedef struct
{
  uint4p12 txPitch_mm;
  uint4p12 rxPitch_mm;
  uint16 cSat_LSB;
  uint8p8 fF_per_LSB;
  uint8p8 LSB_per_fF;
  int16 noiseFloor_LSB;
  uint16 txCount;
  uint16 rxCount;
  uint16 bankTxCount[2];
  uint16 buttonsCount;
  uint16 rxCountMuxSet0; // rxCountMuxSet1 = rxCount - rxCountMuxSet0
  uint16 txCountMuxSet0; // txCountMuxSet1 = txCount - txCountMuxSet0
#if CONFIG_HAS_ADAPTIVE_LGM
  float aLGMCompensationFactor;
#endif
#if CONFIG_HAS_SPLIT_GLOVE_CLUMPS
  uint16 tolerateSplitClumps                    : 1;
#endif
#if CONFIG_HAS_CORNER_SUPPRESSION
  struct {
    uint16 Enable                               : 1;
    uint16 NumPixels;
     int16 Ratio;
  } CornerSuppression;
#endif
#if CONFIG_HAS_METAL_SLUG_SUPPRESION
  struct {
    uint16 Enable : 1;
     int16 PixelThreshold;
    uint16 MaxNumPixels;
  } MetalSlug;
#endif
#if CONFIG_HAS_GRIP_SUPPRESSION_4
  struct {
    uint16 Enable                               : 1;
    uint16 MaybeInside                          : 1;
    uint16 Glove                                : 1;
    uint16 Suppressing                          : 1;
    uint16 NumFrames;
     int16 MinSignalToMeasureWidth;
    uint16 MinObjectWidth;
    uint16 MinTotalWidth;
     int16 SmallSignal;
     int16 BigPeakSignal;
     int16 BigAdjacentSignal;
     int16 UnitsMin;
     int16 UnitsMax;
     int16 NarrowUnitsMin;
     int16 NarrowUnitsMax;
    uint16 NarrowObjectWidth;
  } grip4;
#endif
#if CONFIG_HAS_LGM_DETECTOR
  struct {
    uint16 Enable                               : 1;
    uint16 LGM                                  : 1;
    struct {
       int16 Transcap;
      uint16 Ratio;
    } Start, End;
  } LGMDetector;
#endif
#if CONFIG_HAS_OBJECT_THRESHOLD_SPOILER
  struct {
    uint16 Enable                               : 1;
    uint16 EdgeTx                               : 1;
    uint16 EdgeRx                               : 1;
    uint16 HybridTx                             : 1;
    uint16 HybridRx                             : 1;
    struct {
       int16 HybridTx;
       int16 HybridRx;
    } Sufficient;
  } Spoiler;
#endif
#if CONFIG_HAS_LGM_MERGER
  struct {
    uint16 Enable                               : 1;
    uint16 Always                               : 1;
    uint16 DropWeak                             : 1;
    uint16 WeirdRow                             : 1;
    uint16 OnlyInsideClumps                     : 1;
     int16 TxValley;
     int16 RxValley;
     int16 WeakRatio;
  } LGMMerger;
#endif
#if CONFIG_HAS_PROFILE_BASELINE_CONTROL
  struct {
    uint16 Enable                               : 1;
    uint16 DisregardEdgeCols                    : 1;
     int16 TxThreshold;
     int16 RxThreshold;
  #if CONFIG_HAS_PROFILE_BASELINE_CONTROL_RATIO
    uint16 NumTx;
    uint16 NumRx;
  #endif
  } ProfileBaselineControl;
#endif
#if CONFIG_HAS_METAL_PLATE_SUPPRESSION
  struct {
    uint16 Enable                               : 1;
    uint16 Suppressing                          : 1;
    uint16 NumColsEnter;
    uint16 NumColsExit;
     int16 Noise;
     int16 Threshold;
  } MetalPlate;
#endif
#if CONFIG_HAS_CUSTOM_SPLITTER
  struct {
    uint16 Enable                               : 1;
    uint16 TakeDeeper                           : 1;
     int16 Coefficient;
    uint16 Length_U;
    uint16 Length_V;
  } Splitter;
#endif
#if CONFIG_HAS_NUM_GLOVES
  struct {
    uint16 Max;
  } NumGloves;
#endif
#if CONFIG_HAS_GLOVE_CMNR
  struct {
    uint16 Enable                               : 1;
    uint16 Noisy                                : 1;
     int16 NoisyNegativeTh;
     int16 QuietTh;
    uint16 QuietFrames;
     int16 Cap;
    uint16 numFrames;
  #if CONFIG_HAS_GLOVE_CMNR_RESTRICT
     int16 FingerTh;
  #endif
  } GloveCMNR;
#endif
#if CONFIG_HAS_GLOVE_NOISE_FLOOR
  struct {
    uint16 Enable                               : 1;
    uint16 OnlyGlove                            : 1;
    uint16 Value;
    #if CONFIG_HAS_GLOVE_NOISE_FLOOR_MINPEAK
     int16 MinPeak;
    #endif
  } GloveNF;
#endif
#if CONFIG_HAS_GLOVE_ONLY
  struct {
    uint16 Enable                               : 1;
    uint16 Suppress                             : 1;
    uint16 Early                                : 1;
  } GloveOnly;
#endif
#if CONFIG_HAS_DIRTY_GLOVE
  struct {
    uint16 Enable                               : 1;
     int16 LowerLevel;
     int16 UpperLevel;
    uint16 Ratio1;
    uint16 Ratio2;
    uint16 QuietDuration;
  } DirtyGlove;
#endif
#if CONFIG_HAS_NOISY_WIRELESS_CHARGER
  struct {
    uint16 Enable                               : 1;
    uint16 NoisyByDefault                       : 1;
    uint16 NoisyAllTheTime                      : 1;
    uint16 TakeCareOfLGMMerger                  : 1;
     int16 Transcap;
     int16 NoisyUpper;
     int16 NoisyLower;
     int16 QuietRange;
    uint16 QuietFrames;
  } NoisyWirelessCharger;
#endif
#if CONFIG_HAS_CUSTOM_ENERGY_RATIO
  struct {
    uint16 Enable                               : 1;
     int16 NoiseFloor;
    uint16 Ratio;
    uint16 MinNegSum;
  } EnergyRatio;
#endif
#if CONFIG_HAS_LGM_CORRECTOR_CORRECTOR
  struct {
    uint16 Enable                               : 1;
     int16 Ceiling;
  } LGMCorrectorCorrector;
#endif
#if CONFIG_HAS_LANDING_LARGE_FINGER_DROP
  struct {
    uint16 Enable                               : 1;
    uint16 MinW;
    uint16 MinZ;
  } LandingLargeFingerDrop;
#endif
#if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER
  struct {
    uint16 Enable                               : 1;
  } SpatialFilterNormalizer;
#endif
#if CONFIG_HAS_CUSTOM_PALM_DETECTION
  struct {
    uint16 Enable                               : 1;
  } customPalmDetection;
#endif
#if CONFIG_HAS_GLOVE_DELAY
  struct {
    uint16 NumDrops;
    uint16 Replace[4];
  } GloveDelay;
#endif
#if CONFIG_HAS_HYBRID_REZERO
  struct {
    uint16 Enable                               : 1;
     int16 Negative;
     int16 Positive;
    uint16 NumFrames;
  } HybridRezero;
#endif
#if CONFIG_HAS_NEGATIVE_REZERO
  struct {
    uint16 Enable                               : 1;
     int16 MinNeg;
     int16 MinDiff;
    uint16 NumFrames;
  } NegativeRezero;
#endif
#if CONFIG_HAS_GLOVE_SUPPRESSION
  struct {
    uint16 Enable                               : 1;
    int8p8 minY;
    int8p8 maxY;
  } GloveSuppression;
#endif
#if CONFIG_HAS_SPATIAL_CAP
  struct {
     int16 limit;
  } SpatialCap;
#endif
#if CONFIG_HAS_NOTCH_CUT
  uint16 cutOutLength;
  uint16 cutOutRows[MAX_CUT_OUTS]; // this should be uint8 once the compiler supports those pointers
  uint16 cutOutCols[MAX_CUT_OUTS]; // this should be uint8 once the compiler supports those pointers
  uint4p12 cutOutFraction[MAX_CUT_OUTS];
  int8p8 centroidOffsetRow[MAX_CUT_OUTS];
  int8p8 centroidOffsetCol[MAX_CUT_OUTS];
#endif
} sensorParams_t;

typedef struct
{
  uint16 reportedObjectTypes                    : 8;
  uint16 noiseMitigationEnabled                 : 1;
  uint16 inhibitRelaxation                      : 1;
  uint16 inhibitGainCompensation : 1;
  uint16 inhibitDisplayNoiseRemoval             : 1;
  uint16 inhibitDisplayNoiseRemovalGlobalMedian : 1;
  uint16 inhibitHybridDisplayNoiseRemoval       : 1;
  uint16 inhibitAntiBending : 1;
  uint16 inhibitProfileAntiBending : 1;
  uint16 inhibitShadowRemoval                   : 1;
  uint16 inhibitShadowRemovalAMP                : 1;
  uint16 inhibitLGMCorrection                   : 1;
  uint16 inhibitMoistureMitigation              : 1;
  uint16 inhibitMoistureMitigationAMP           : 1;
  uint16 inhibitFistReject                      : 1;
  uint16 holdLiftedIndices: 1;
  uint16 inhibitThickGlove : 1;
  uint16 inhibitWeakObjectFilter : 1;
  uint16 inhibitUnisonNoiseRemoval : 1;
  uint16 faceDetectEnable                       : 1;
  uint16 enableSideTouch                        : 1;
  uint16 thickGloveEnabled                      : 1;
  uint16 hybridGloveEnabled                     : 1;
  uint16 enableALGM                             : 1;
  uint16 inWakeupGestureMode                    : 1;
  #if defined(CONFIG_CLOSED_COVER_WINDOW_DATA_ONLY) && CONFIG_CLOSED_COVER_WINDOW_DATA_ONLY
  uint16 closedCoverOperation: 1;
  #endif
  #if defined(CONFIG_IFP_CLOSEDCOVER) && CONFIG_IFP_CLOSEDCOVER
  uint16 closedCoverEnabled : 1;
  #endif
  uint16 knuckleEnabled : 1;

} ifpMode_t;

typedef struct
{
  uint16 acquired : 1;
  uint16 modified : 1;
  uint16 estimate[MAX_RX * MAX_TX];
} imageBaseline_t;

typedef struct
{
  uint16 acquired;
  uint16 estimate[MAX_ABS_RX];
} absXBaseline_t;

typedef struct
{
  uint16 acquired;
  uint16 estimate[MAX_ABS_TX];
} absYBaseline_t;

typedef struct
{
  buttonsBitmask_t baselineAcquired;
  uint16 estimate[MAX_BUTTONS];
} buttons0DBaseline_t;

typedef enum
{
  baselineType_trans,
  baselineType_absx,
  baselineType_absy,
  baselineType_button,
} baselineType_t;

typedef enum
{
  palmFilterMode_none,
  palmFilterMode_rejectAllTouches,
  palmFilterMode_rejectNewTouches
} palmFilterMode_t;

typedef enum
{
  skinModeFilterType_none,
  skinModeFilterType_rejectAllTouches,
  skinModeFilterType_rejectNewTouches
} skinModeFilterType_t;

typedef struct
{
  uint8p8 widthPt1x;
  uint8p8 widthPt1y;
  uint8p8 widthPt2x;
  uint8p8 widthPt2y;
} fistRejectRegion_t;

typedef struct {
  int14p2 xyDist2MaxTh;
  int14p2 xyDist2MinTh;
  uint16 smallObjectPalmMergeThreshold_px;
  uint8p8 fingerMergeThdX_px;
  uint8p8 fingerMergeThdY_px;
  fistRejectRegion_t squareFistRegion;
  fistRejectRegion_t slopeFistRegion;
  uint16 peakWidthRatio;
  uint16 peakSquaredSumTh;
} fistRejectConfig_t;

typedef enum
{
  axisName_xAxis,
  axisName_yAxis
} axisName_t;

typedef struct
{
  uint16 mode;
  uint8p8 rowGain[MAX_TX];
  uint8p8 colGain[MAX_RX];
  uint4p12 edgeGain[4];
  uint4p12 cornerGain[4];
  uint16 rowCount;
  uint16 colCount;
} gainCompParams_t;

typedef enum
{
  sensorDirection_none,
  sensorDirection_rows,
  sensorDirection_cols,
  sensorDirection_rowsAndCols
} sensorDirection_t;

typedef enum
{
  shadowDirection_none,
  shadowDirection_rows,
  shadowDirection_cols,
  shadowDirection_rowsAndCols,
  shadowDirection_rowsBetweenTouchesAndCols
} shadowDirection_t;

typedef struct
{
  uint0p16 shadowFingerThreshold_pct;
  uint0p16 shadowPenThreshold_pct;
  uint16 shadowDirection;  // in C, cannot portably use enums in bitfields
} shadowRemoverConfig_t;

typedef struct
{
  uint8p8 weights[MAX_RX];
} displayNoiseRemoverConfig_t;

typedef struct
{
  uint8p8 absRxTxRatio;
  uint9p7 receiverWeights[MAX_ABS_RX];
  uint9p7 absTxWeights[MAX_ABS_TX];
  uint16  absRxMinObjectSpan_LSB;
  uint16 stddevDisplayNoiseMax_LSB;
} hybridDisplayNoiseRemoverConfig_t;

typedef struct
{
  uint8p8 absRxTxRatio;
  uint9p7 receiverWeights[MAX_ABS_RX];
  uint9p7 absTxWeights[MAX_ABS_TX];
  uint16 absRxMinObjectSpan_LSB;
  uint16 stddevDisplayNoiseMax_LSB;
} muxRXHybridDisplayNoiseRemoverConfig_t;

typedef struct
{
  uint8p8 absRxTxRatio;
  uint9p7 receiverWeights[MAX_ABS_RX];
  uint9p7 absTxWeights[MAX_ABS_TX];
  uint16 absRxMinObjectSpan_LSB;
  uint16 stddevDisplayNoiseMax_LSB;
} muxTXHybridDisplayNoiseRemoverConfig_t;

typedef struct
{
  uint0p16 tagsThreshold_LSB;
  uint12p4 tagsSumThreshold_pct;
  uint16 absXObjectThreshold_LSB;
  uint16 absYObjectThreshold_LSB;
  uint16 absXLiftThreshold_LSB;
  uint16 absYLiftThreshold_LSB;
  uint16 moistureClumpDistanceSq_px2 : 8;
  uint16 moistureClumpDensity : 8;
  uint16 absPosSumMinRatio : 8;
  uint16 escalationFrames : 8;
  uint16 deescalationFrames : 8;
  uint16 refractoryFrames : 8;
  uint16 punchoutEdgeWidth : 8;
  uint16 maxNumberNonLocalizedPunchouts : 8;
  pixelIndex_t tagsPunchOuts[MAX_TAGS_PUNCH_OUTS + 1];  // add sentinel
} moistureDetectorConfig_t;

typedef struct
{
  int16 absXPenThreshold_LSB;
  int16 absYPenThreshold_LSB;
  int16 absXFingerThreshold_LSB;
  int16 absYFingerThreshold_LSB;
  uint8p8 clumpPeakThreshold_pct;
  uint16 groundMassThresholdFactor;
} moistureFilterConfig_t;

typedef enum
{
  hostClassification_none,
  hostClassification_finger,
  hostClassification_glove,
  hostClassification_stylus,
  hostClassification_eraser,
  hostClassification_smallObject,
  hostClassification_palm,
  hostClassification_thickGlove,
  hostClassification_edgeFinger,
  hostClassification_unknown,
  NUM_HOST_CLASSIFICATIONS
} hostClassification_t;

typedef struct
{
  uint16 classification;  // hostClassification_t; in C, cannot portably use enums in bitfields
  int16 xMeas;
  int16 yMeas;
  uint16 z;
  uint16 xWidth : 8;
  uint16 yWidth : 8;
  //Unused by RMI for debug only
  int8p8 txPos; //Not used by RMI
  int8p8 rxPos; //Not used by RMI
  #if CONFIG_IFP_KNUCKLE
  uint16 trackId;
  #endif
} reportPos_t;


typedef struct
{
  uint0p16 lengthTailArea_pct;
  uint12p4 clumpLengthThreshold_mm;
  uint0p16 minPeakSplitThreshold_pct;
  uint10p6 minContrastThreshold;
  uint10p6 minContrastThresholdDiag;
  uint0p16 minContrastPeakAmp_pct;
} linearSwipeSplitterConfig_t;


typedef struct
{
  uint16 saturationLevel_LSB;
  uint0p16 normalFingerThreshold_pct;
  uint0p16 palmThreshold_pct;
  uint0p16 smallFingerThreshold_pct;
} penRecorrectorConfig_t;

typedef struct
{
  uint16 saturationLevel_LSB;
  uint0p16 normalFingerThreshold_pct;
  uint0p16 palmThreshold_pct;
  uint0p16 smallFingerThreshold_pct;
  int16 minPeak_LSB;
  uint8p8 mergeThreshold_pct;
} segmenterConfig_t;

typedef struct
{
  int16 logTouchThreshold_LSB;
  int16 deltaTouchThreshold_LSB;
  #if defined(CONFIG_IFP_ANTIBENDING_FOR_CLOSEDCOVER) && CONFIG_IFP_ANTIBENDING_FOR_CLOSEDCOVER
  int16 logTouchThreshold_closedCover_LSB;
  int16 deltaTouchThreshold_closedCover_LSB;
  #endif
  int16 xProfileLogTouchThreshold_LSB;
  int16 xProfileDeltaTouchThreshold_LSB;
  int16 yProfileLogTouchThreshold_LSB;
  int16 yProfileDeltaTouchThreshold_LSB;
  int16 xTxInv[9];
  int16 xTxInvTx[9];
} antiBendingConfig_t;

typedef struct
{
  uint8p8 prominence;
} clumpSplitterConfig_t;

typedef struct
{
  uint16 energyRatioThreshold;
  uint16 absXNegThreshold_LSB;
  uint16 absYNegThreshold_LSB;
  uint16 absPosSumMinRatio;
  uint10p6 negativeFingerThreshold_pct : 8;
  uint8p8 tagsTouchThreshold_pct : 8;
  uint16 liftBumpinessThreshold : 8;
  uint16 bumpinessScaleDownBits : 4;
  uint16 bumpinessDirection : 2;  // sensorDirection_t; in C, cannot portably use enums in bitfields
} baselineCheckerConfig_t;

typedef struct
{
  uint16 holdFastTransition_ms;
  uint16 fastHalflife_ms;
  uint16 disableDelayedRelaxation : 1;
} baselineManagerConfig_t;

typedef struct
{
  uint16 thermalUpdateInterval_ms;
  uint16 fastHalflife_ms;
  uint16 baselineUpdateSpeed;
} baselineUpdaterConfig_t;

typedef struct
{
  uint16 noiseFloorAddLevel;
  uint16 minPeakAddLevel;
  uint16 gloveFingerThresholdAddLevel;
  uint16 strongAddLevel;
  uint16 baselineUpdateSpeed;
} baselineShifterMitConfig_t;

typedef struct
{
  uint16 thermalUpdateIntervalX_ms;
  uint16 thermalUpdateIntervalY_ms;
  uint16 fastHalflife_ms;
} profileBaselineUpdaterConfig_t;

typedef struct
{
  uint16 noisePeakThreshold_pct;
} filterNoiseBlobsConfig_t;

typedef struct
{
  uint16 enable;
  uint16 smoothLoop;
  uint16 tixelTotalCntRatio;
  uint16 onePeakWeightRatio;
  uint16 onePeakMinDelta;
  uint16 multiPeakLeftPeakMinDelta;
  uint16 multiPeakWeightRatio;
  uint16 multiPeakRightPeakWeightRatio;
  uint16 multiPeakMinDelta;
  uint16 hysteresis;
} metalDetectConfig_t;

typedef struct
{
  uint8p8 maxDistPerMs_px;
  uint16 accelDrumming;
  uint16 mindistDrumming;
#if CONFIG_HAS_LESSER_BLOB_TRACKER
  uint16 mindBlobsLess;
#endif
} trackerConfig_t;

typedef struct {
  uint16 area : 8;      // 2p6
  uint16 amplitude : 8; // 0p8
} smallObjectDetectorRegion_t;

#define IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE 8

typedef struct
{
  smallObjectDetectorRegion_t region[IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE];
  smallObjectDetectorRegion_t hystRegion[IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE];
  smallObjectDetectorRegion_t stylusRegion[IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE];
  smallObjectDetectorRegion_t stylusHystRegion[IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE];
  smallObjectDetectorRegion_t eraserRegion[IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE];
  smallObjectDetectorRegion_t eraserHystRegion[IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE];
  uint16 maxSmallObjectWidth : 8;          // 2p6
  uint16 maxDiagonalSmallObjectWidth : 8;  // 2p6
  uint16 widthHysteresis : 8;              // 2p6
  uint16 eraserPerfImproveRate;
  uint16 eraserPerfImproveDelta;
} smallObjectDetectorConfig_t;

typedef struct
{
  uint16 hybridBLTxAxisEn     : 1;
  uint16 hybridBLRxAxisEn     : 1;
  uint16 wideConsistencyTx    : 1;
  uint16 wideConsistencyRx    : 1;
  uint16                      : 12;
} hybridControl_t;

typedef struct
{
  uint16 saturationLevel_LSB;
  uint0p16 normalFingerThreshold_pct;
  uint0p16 smallFingerThreshold_pct;
  uint16 smallFingerBorderSize_px;
  uint16 smallFingerMaxSize_px;
  uint0p16 negativeFingerThreshold_pct;
  uint0p16 palmThreshold_pct;
  uint16 palmArea_px;
  uint8p8 negFingerLGMThreshold;
  uint16 absXObjectThreshold_LSB;
  uint16 absYObjectThreshold_LSB;
#if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
  uint16 absXObjectThreshold_LSB_glove;
  uint16 absYObjectThreshold_LSB_glove;
#endif
  uint0p16 stabilityThreshold_pct;
  uint0p16 glovedFingerThreshold_pct;
  uint16 glovedFingerLanding_frames;
  uint0p16 avePeakRatio_pct;
  uint0p16 cdmArtifactAmplitude_pct;
  uint16 fingerLandingMaxFrames; //land-lift
  uint8p8 landingFingerMinDeltaZ;
  uint16 smallFingerLandingMaxFrames;
  uint8p8 landingSmallFingerMinDeltaZ;//end land-lift
  uint16 maxAbsAbsent : 4;
#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
  smallObjectDetectorConfig_t smallObjectDetectorConfig;
#endif
#if CONFIG_HAS_GLOVE_SUSTAINER
  struct GS_t {
    uint16 Enable            : 1;
    uint16 UseExtraFingerAmp : 1;
    uint16 UseExtraGloveAmp  : 1;
     int16 FingerAmpThreshold;
     int16 SmallFingerAmpThreshold;
     int16 ExtraFingerAmpThreshold;
     int16 ExtraGloveAmpThreshold;
  } GS;
#endif
#if CONFIG_HAS_GLOVE_STABLE_FRAMES
  struct GSF_t {
    uint16 NumFrames;
  } GSF;
#endif
} classifierConfig_t;

typedef struct
{
  uint8p8 zMinX;
  uint8p8 zMaxX;
  int1p15 ampAtZMinX;
  uint8p8 zMinY;
  uint8p8 zMaxY;
  int1p15 ampAtZMinY;
} sineCorrConfig_t;

typedef struct
{
  sineCorrConfig_t sineCorrCfg;
  uint16 gaussianWidthX;
  uint16 gaussianWidthY;
  int16 minFingerWidthX;
  int16 minFingerWidthY;
  uint16 txAxis;  // in C, cannot portably use enums in bitfields
#if CONFIG_HAS_GLOVE_MIN_SIZE
  int16 minGloveWidthX;
  int16 minGloveWidthY;
#endif
#if CONFIG_HAS_NOTCH_CUT
  uint16 circleFitEn;
  int8p8 circleCenterX;
  int8p8 circleCenterY;
  uint4p12 circleR;
  int16 peakAmplitude;
  uint4p12 sigmaR;
  uint0p16 contourPeakFrac;
#endif
} positionEstConfig_t;

typedef struct
{
  uint4p12 frameFilterStrength;
  uint8p8 snrThresholdTx;
  uint8p8 snrThresholdRx;
  uint0p16 settlingThreshold_pct;
  int8p8 jitterThreshold_px;
  uint16 edgeExclusionTx_px;
  uint16 edgeExclusionRx_px;
} thickGloveConfig_t;

typedef enum
{
  touchType_none,
  touchType_finger,
  touchType_glove,
  touchType_smallObject,
  touchType_stylus,
  touchType_eraser,
  touchType_palm,
  touchType_moisture,
  touchType_baselineError,
  touchType_noise,
  touchType_lowGroundMass,
  touchType_thickGlove,
  NUM_TOUCH_TYPES
} touchType_t;

typedef struct
{
  uint16 controlTypes;  // bitmask, where bit number is touchType_t value
  uint16 varU : 8;
  uint16 varW : 8;
  uint16 filterDelay_frames : 2;
  uint16 inhibitMF          : 1; //not use medianFilter
} kalmanFilterConfig_t;

typedef struct
{
  int8p8 noiseLengthScale;
  int8p8 noiseSuppressionFactor;
  int8p8 fingerLengthScale;
  uint16 landLockFrames;
  uint16 landLockReleaseFrames;
  uint16 landLockFastFingerReleaseFrames;
  int8p8 simpleModeStrength;
  uint16 skipTypes;  // bitmask, where bit number is touchType_t value
#if CONFIG_HAS_ALTERNATE_GLOVE_JITTER
  struct {
    int8p8 noiseLengthScale;
    int8p8 noiseSuppressionFactor;
    int8p8 fingerLengthScale;
  } altGloveJitter;
#endif
#if CONFIG_HAS_Z_JITTER_ADJUSTMENT
  struct {
    uint16 Enable                               : 1;
    uint16 SmallZ;
    uint16 LargeZ;
    struct {
      uint16 LargeValue;
       int16 a;
       int16 b;
    } NoiseLengthScale, FingerLengthScale;
  } zJitter;
#endif
#if CONFIG_HAS_W_LLJ_FILTER
  struct {
    uint16 Enable                               : 1;
    uint16 LowerW;
    uint16 UpperW;
    uint16 Coeff;
    int8p8 noiseLengthScale;
    int8p8 noiseSuppressionFactor;
    int8p8 fingerLengthScale;
    uint16 landLockFrames;
    uint16 landLockReleaseFrames;
    uint16 landLockFastFingerReleaseFrames;
    int8p8 simpleModeStrength;
    uint16 w[MAX_OBJECTS];
  } wLLJ;
#endif
#if CONFIG_HAS_LL_LIFTING_LARGE_FINGER
  struct {
    uint16 Enable                               : 1;
    int8p8 NoiseLengthScale;
    int8p8 FingerLengthScale;
    uint16 MinW;
    uint16 MinZ;
    uint16 DiffW;
    uint16 DiffZ;
  } liftingLarge;
#endif
} landLiftJitterFilterConfig_t;

typedef struct
{
  int16 edgeMinX;
  int16 edgeMinY;
  int16 edgeMaxX;
  int16 edgeMaxY;
} edgeSwipeDetectorConfig_t;

typedef struct
{
  int16 xMax;
  int16 yMax;
  int8p8 rxClipLow;
  int8p8 rxClipHigh;
  int8p8 txClipLow;
  int8p8 txClipHigh;
  uint16 txAxis;  // in C, cannot portably use enums in bitfields
  uint8p8 smallZThreshold;
  uint8p8 smallZScaleFactor;
  uint8p8 largeZScaleFactor;
  uint8p8 wxScaleFactor;
  int16 wxOffset;
  uint8p8 wyScaleFactor;
  int16 wyOffset;
  uint16 origin : 4; //2:X follows reverse order, 4:Y follows revers order, 8:both XY follows reverse order
} coordConvConfig_t;

typedef struct
{
  uint16 shadowRemoverEnable;
  uint16 minFingerThreshold;
}ampShadowRemoverConfig_t;

typedef enum
{
  hybrid_moisture_SF,
  thick_glove_SF,
  force_single_finger_SF,
  abs_TRGT_SF
} single_finger_t;

typedef struct
{
  reportPos_t    pos[2];
  uint16 freshData : 1;
  uint16 objectsPresent : 1;
  single_finger_t type : 2;
  uint16 unused    : 12;
} SFReportData_t;

typedef struct
{
  int16 x;
  int16 y;
} landPos_t;

/**
 * cover mode parameters
 */
typedef struct
{
  uint16 closedCoverXmin;
  uint16 closedCoverXmax;
  uint16 closedCoverYmin;
  uint16 closedCoverYmax;
  uint16 closedCoverThreshold : 8; // 0p8
  uint16 closedCoverEnable    : 1;
  uint16 reserved             : 7;
} closedCoverParams_t;

typedef struct
{
  uint16 deadZoneSizeX : 8;
  uint16 deadZoneSizeY : 8;
  uint16 maxReportedObjects : 8;
  uint16 maxReportedObjectsAlt : 8;
  uint16 reportedObjectTypes;  // bitmask, where bit number is hostClassification_t value
  uint16 skinModeSuppressObjectTypes; // bitmask, just like reportedObjectTypes
  uint16 forceFreshReport : 1;
  uint16 palmFilterAllowStylus : 1;
  uint16 palmFilterMode : 2;  // in C, cannot portably use enums in bitfields
  uint16 skinModeFilterType: 2; // reject new touches, reject all
  uint16 origin : 4; //2:X follows reverse order, 4:Y follows revers order, 8:both XY follows reverse order
#if CONFIG_HAS_REPORTS_GONE_BY_FORCE_UPDATE
  uint16 reportGoneByForceUpdate : 1;
#else
  uint16 : 6;
#endif
  int16 xMax;
  int16 yMax;
  uint16 edgeSuppressionDist;
  #if CONFIG_IFP_CLOSEDCOVER
  closedCoverParams_t closedCoverParams;
  #endif
} positionRepConfig_t;

typedef struct
{
  // LGM tuning knobs, these are always positive
  int16 absXLGMObjectThreshold_LSB;
  int16 absYLGMObjectThreshold_LSB;
  int16 transLGMObjectThreshold_LSB;
} lgmManagerConfig_t;

typedef struct {
  uint16 thresholdXAxis; // In ADC units
  uint16 thresholdYAxis; // In ADC units
  uint16 thickGloveKneeLowPxlPctX;
  uint16 thickGloveKneeLowPxlPctY;
  uint16 thickGloveKneeFrames;
  uint16 thickGlovePersistenceFrames;
} singleFingerConfig_t;

typedef struct
{
  int16 columnMeanThreshold;
  int16 columnApplyThreshold;
  int16 leftRowsMeanThreshold;
  int16 leftRowsApplyThreshold;
  int16 rightRowsMeanThreshold;
  int16 rightRowsApplyThreshold;
} rowColumnNoiseRemoverConfig_t;

typedef struct
{
  uint16 minCompFactor;    //Lower limit on ALGM compensation factor
  uint16 accumThresh;      //Threshold above which touch pixels are used to estimate ALGM compensation factor
  uint16 tixelsPerFinger;  //An approximation of electrodes affected by finger touch
  uint16 filterCoeff;      //IIR filter coefficient, to filter compensation factor (ALGM output)

  uint0p16 normalFingerThreshold_pct;

  #if CONFIG_IFP_ALGM_FITCURVE_ENABLE
  uint16 fitCurveEnable                   : 1;
  uint16 fitCurveTuningEnable             : 1;
  uint16 fitCurve_Reserved                : 6;
  uint16 fitCurveFactorA                  : 8;
  uint16 fitCurveFactorB                  : 8;
  uint16 fitCurveFactorT                  : 8;
  uint16 fitCurveFingerThresholdRatioPct  : 8;
  uint16 fitCurveMiniPeak                 : 8;
  #endif
}aLGMConfig_t;

typedef struct
{
  uint16 ampMoistureEnable;
  uint16 moistureConcaveThreshold;
  uint16 palmArea_px;
}ampMoistureConfig_t;

typedef struct
{
  uint16 alpha;
} extremeNoiseRemoverConfig_t;

#if CONFIG_GRIPSUPPRESSION_RULE2
typedef struct
{
  uint16 gripPinkoffset;
  uint16 gripConfig1;
  uint16 gripRedOffset;
  uint16 gripConfig2;
  uint16 gripTap;
  uint16 gripVDarkX;
  uint16 gripVDarkY;
  uint16 gripHDarkX;
} gripsuppressionrule2_t;
#endif

typedef struct
{
  uint16 enable          : 1;
  uint16                 : 15;
} hybridChargerNoiseMitigationConfig_t;

typedef struct
{
  uint8p8 peakFraction;
} weakObjectFilterConfig_t;

typedef struct
{
  uint16 refractoryPeriod : 4;
  uint16 durationThreshold : 4;
  uint16 minAbsX : 8;
  uint16 minAbsY : 8;
  uint16 nAbsXConsistencyMin : 4;
  uint16 nAbsYConsistencyMin : 4;
  uint16 minZ : 8;
  uint16 nZConsistencyMin: 4;
} touchBufferConfig_t;

typedef enum
{
  spatialFilterDelta_unpadded = 0,
  spatialFilterDelta_padded,
} spatialFilterDelta_t;
typedef enum
{
  spatialFilterType_hover = 0,
  spatialFilterType_glove,
} spatialFilterType_t;
typedef enum
{
  spatialFilterSize_3x3 = 0,
  spatialFilterSize_4x4,
  spatialFilterSize_5x5,
} spatialFilterSize_t;

typedef struct
{
  // Due to symmetry not all the coeff matrix is stored.
  // For example:
  //
  // 1,  4,  5,  4,  1
  // 4,  9, 12,  9,  4
  // 5, 12, 16, 12,  5
  // 4,  9, 12,  9,  4
  // 1,  4,  5,  4,  1
  //
  // Is specified as:
  //
  // 1, 4, 5, 4, 9, 12, 5, 12, 16
  uint16 coeffs[25];
  uint16 exitThreshold;
  uint16 enable : 1;
  uint16 size   : 2;

  #if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER_CUSTOM
  uint16 Custom : 1;
   int16 divider[25];
  #endif
} spatialFilterConfig_t;

typedef struct
{
  sensorParams_t sensorParams;
#if CONFIG_HAS_ANTI_BENDING
  antiBendingConfig_t abConfig;
#endif
  baselineCheckerConfig_t bcConfig;
  baselineManagerConfig_t bmConfig;
  baselineUpdaterConfig_t buConfig;
#if CONFIG_HAS_HYBRID
  profileBaselineUpdaterConfig_t pbuConfig;
  #if CONFIG_HAS_RX_MUXING
    muxRXHybridDisplayNoiseRemoverConfig_t mRXhdnrConfig;
  #elif CONFIG_HAS_TX_MUXING
    muxTXHybridDisplayNoiseRemoverConfig_t mTXhdnrConfig;
  #else
  hybridDisplayNoiseRemoverConfig_t hdnrConfig;
  #endif
#else
  #if !CONFIG_HAS_RX_MUXING
  displayNoiseRemoverConfig_t dnrConfig;
  #endif
#endif
#if CONFIG_HAS_MOISTURE
  moistureDetectorConfig_t mdConfig;
  moistureFilterConfig_t mfConfig;
#endif
  gainCompParams_t gainCompParams;
#if CONFIG_HAS_SHADOW_REMOVER
  shadowRemoverConfig_t srConfig;
#endif
#if CONFIG_HAS_LGM_CORRECTOR
  lgmManagerConfig_t lgmConfig;
#endif
#if CONFIG_HAS_LINEAR_SWIPE_SPLITTER
  linearSwipeSplitterConfig_t lssConfig;
#endif
#if CONFIG_HAS_FIST_REJECT
  fistRejectConfig_t frConfig;
#endif
#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
  penRecorrectorConfig_t prcConfig;
#endif
  segmenterConfig_t segConfig;
  clumpSplitterConfig_t csConfig;
  filterNoiseBlobsConfig_t fnbConfig;
  trackerConfig_t trackerConfig;
  classifierConfig_t classConfig;
  positionEstConfig_t peConfig;
#if CONFIG_HAS_THICK_GLOVE
  thickGloveConfig_t tgConfig;
#endif
#if CONFIG_HAS_KALMAN_FILTER
  kalmanFilterConfig_t kfConfig;
#endif
  landLiftJitterFilterConfig_t lljfConfig;
  coordConvConfig_t coordConvConfig;
  positionRepConfig_t posReportConfig;
#if CONFIG_HAS_0D_BUTTONS
  buttons0DConfig_t buttons0DConfig;
#endif
  weakObjectFilterConfig_t wofConfig;
  touchBufferConfig_t tbConfig;
#if CONFIG_HAS_FACE_DETECT
  faceDetectConfig_t faceDetectConfig;
#endif
#if CONFIG_HAS_THICK_GLOVE || CONFIG_HIC_LPWG_MODE_B
  singleFingerConfig_t sfConfig;
#endif
#if CONFIG_HAS_BASELINE_COMPENSATION
  baselineShifterMitConfig_t bsConfig;
#endif
#if CONFIG_HAS_ADAPTIVE_LGM
  aLGMConfig_t aLGMConfig;
#endif
#if CONFIG_HAS_ROW_COL_NOISE_REMOVER
  rowColumnNoiseRemoverConfig_t rcNoiseRemoverConfig;
#endif
#if CONFIG_HAS_TDDI_AMP_MOISTURE
  ampMoistureConfig_t ampMoistureConfig;
#endif

  uint16 advFeatureEn   : 1;
  uint16 advFeatureFW   : 1;
  uint16 reservedIFP    : 14;

#if CONFIG_HAS_SHADOW_REMOVER_AMP
  ampShadowRemoverConfig_t ampShadowRemoverConfig;
#endif
#if CONFIG_HAS_SIDE_TOUCH
  sideTouchTemporalFilter_t sideTouchTemporalFilterConfig;
#endif
#if CONFIG_HAS_EXTREME_NOISE_REMOVER
  extremeNoiseRemoverConfig_t eNoiseRemoverConfig;
#endif
#if CONFIG_GRIPSUPPRESSION_RULE2
  gripsuppressionrule2_t grip_suppressionrule2;
#endif
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
  metalDetectConfig_t metalDetectConfig;
#endif
#if CONFIG_HAS_ABS_CMNR_FILTER
  absFilterConfig_t absFilterConfig;
#endif
#if CONFIG_HAS_HYBRID_CHARGER_NOISE_MITIGATION
  hybridChargerNoiseMitigationConfig_t hybridChargerNoiseMitigationConfig;
#endif
#if CONFIG_HAS_GLOVE_SPATIAL_FILTER
  spatialFilterConfig_t spatialFilterConfig;
#endif
} ifpConfig_t;

typedef enum
{
  baselineState_noBaseline,
  baselineState_baselineAcquired
} baselineState_t;

typedef struct
{
  uint8p8 relativeAmplitude : 8;
  uint10p6 area : 8;
  uint10p6 maxXYWidth : 8;
  uint10p6 maxDiagonalWidth : 8;
} smallObjectFeatures_t;

typedef struct
{
  int8p8 xwidth;
  int8p8 ywidth;
  uint32 xy2;
  int14p2 xyDist2;
} fistFeatures_t;

typedef struct
{
  //Finger size tuning
  uint16 gaussianWidthX;
  uint16 gaussianWidthY;
  smallObjectFeatures_t smallObjectFeatures;
  fistFeatures_t fistFeatures;
  uint16 buttons0DVariances[MAX_BUTTONS];
} tuningStruct_t;

typedef struct
{
  reportPos_t pos[MAX_OBJECTS];
  landPos_t land[MAX_OBJECTS];
  uint16 freshData : 1;
  uint16 objectsPresent : 1;
  uint16 faceDetected : 1;
// CONFIG_HAS_THICK_GLOVE
  uint16 sfFreshData : 1;
  uint16 thickGlovePresent : 1;
  SFReportData_t SFReport;
//////
  tuningStruct_t tuning;
  buttons0DReport_t buttons0DReport;
  #if CONFIG_IFP_KNUCKLE
    int16 peakRow;
    int16 peakCol;
    int16 peakIdx;
    int16 fngCnt;
  #endif
} reportData_t;

// Prevent the pack pragma from infecting everything. VC++ warns about this.
#ifndef __CHIMERA__
  #pragma pack(pop)
#endif

#endif // _IFP_H
