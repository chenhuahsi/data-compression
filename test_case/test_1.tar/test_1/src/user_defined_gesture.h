#ifndef USER_DEFINED_GESTURE_H
#define USER_DEFINED_GESTURE_H

// -----------------------------------------------------------------
// User Defined Gesture Recognizer
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// $Id: func_12.h,v 1.20.18.6.4.32.2.13 2014/10/03 08:48:42 yahuic Exp $
//

#include "calc2.h"

#if CONFIG_HAS_LPWG_USERDEFINED

void userDefinedGestures_boot();
void userDefinedGestures_init(calcStaticConfig_t *cfg);
uint16 userDefinedGestures_isDataCollectionState();
void userDefinedGestures_setEnabled(uint16 enable);
//void userDefinedGestures_detect(touchReport_t *report);
void userDefinedGestures_detect(struct touch pos, gestureReport_t *pReport);
#else
static ATTR_INLINE void userDefinedGestures_boot() {};
static ATTR_INLINE void userDefinedGestures_init(ATTR_UNUSED calcStaticConfig_t *cfg) {};
static ATTR_INLINE uint16 userDefinedGestures_isDataCollectionState() {return 0;};
static ATTR_INLINE void userDefinedGestures_setEnabled(ATTR_UNUSED uint16 enable) {};
//static ATTR_INLINE void userDefinedGestures_detect(ATTR_UNUSED touchReport_t *report) {};
static ATTR_INLINE void userDefinedGestures_detect(ATTR_UNUSED struct touch pos, ATTR_UNUSED gestureReport_t *pReport) {};
#endif

#endif //#define USER_DEFINED_GESTURE_H

