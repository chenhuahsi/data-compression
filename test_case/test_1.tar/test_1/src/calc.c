/* calc2 calculation thread */

#include <string.h>
#include <stddef.h>

#include "calc2.h"
#include "platform.h"
#include "calc_print.h"

#include "low_power.h"
#include "loze.h"
#include "deep_sleep.h"
#include "lpwg_modeb.h"
#include "gesture_detector.h"

#include "ifp/image_frame_processor.h"
#include "knuckle.h"
#if CONFIG_GRIPSUPPRESSION
#include "grip_suppression.h"
#endif

#if CONFIG_IFP_ESD_ACTIVEMODE || CONFIG_HAS_TDDI_ESD_IMAGE_CHECKER || CONFIG_HAS_TDDI_ESD_DETECTOR
#include "esd.h"
#endif

#include "daq2.h"

#define LEN(x) (sizeof(x)/sizeof(x[0]))

#if CONFIG_HAS_REPORTS_GONE_BY_FORCE_UPDATE
static uint16 issuingForceUpdate;
#endif


void copy2DToFrameBuffer(deltaImage_t *img, PLFrameData_t *frameBufferPtr)
{
  int16 *srcPtr = (int16 *)img;
  int16 *dstPtr = &frameBufferPtr->image[0];
  int16 i,j;

  srcPtr = srcPtr+MAX_RX+2; //1st valid data from padded image format

  for (i = 0; i < MAX_TX; i++)
  {
    for (j = 0; j < MAX_RX; j++)
    {
      *dstPtr++ = *srcPtr++;
    }
    srcPtr++;
  }
}

static void init(calcStaticConfig_t *scfg, calcDynamicConfig_t *dcfg)
{
  COMM_getStaticConfig(scfg);
  COMM_getDynamicConfig(dcfg);

  PL_init(scfg, dcfg);

  PL_convertToIFPFormat(scfg);
  #if CONFIG_HAS_REPORTS_GONE_BY_FORCE_UPDATE
  scfg->ifpConfig.posReportConfig.reportGoneByForceUpdate = issuingForceUpdate;
  issuingForceUpdate = 0;
  #endif
  imageFrameProcessor_configure(&(scfg->ifpConfig));
  imageFrameProcessor_init();

  #if CONFIG_HAS_WAKEUPGESTURE
  gesture_init(scfg);
  #endif

  #if CONFIG_IFP_ESD_ACTIVEMODE
  esd_activemode_init(scfg,dcfg);
  #endif

  #if CONFIG_GRIPSUPPRESSION
  gripSuppression_init(scfg);
  #endif

  #if CONFIG_GRIPSUPPRESSION_RULE2
  GripInit();
  GripConfig(&(scfg->ifpConfig));
  #endif

  #if CONFIG_LOWPOWER_DOZE
  lowPower_init(&(scfg->dozeParams));
  #endif

  #if CONFIG_LOWPOWER_LOZE
  loze_init(&(scfg->lozeParams), scfg->daqParams.numRows, scfg->daqParams.numCols);
  #endif

  #if CONFIG_HIC_LPWG_MODE_B
  lowPower_lpwgModeB_init(&(scfg->lpwgModeBParams));
  #endif
  #if CONFIG_HAS_TDDI_ESD_DETECTOR || CONFIG_IFP_ESD_ACTIVEMODE
  esd_init();
  #endif
  #if CONFIG_HAS_TDDI_ESD_IMAGE_CHECKER
  esd_image_checker_init();
  esd_image_checker_configure(&(scfg->ifpConfig.sensorParams));
  #endif
  PL_setParam(PLTouchSensingMode, dcfg->touchSensingMode);
  PL_enterMode(mode_active);
  PL_calibrateButtons();
}

void calc_mainLoop(void)
{
  while(1)
  {
    // aggregate flags in a struct to save direct RAM
    struct {
      union {
        struct {
          uint16 doRezero:1;
          uint16 noDoze:1;
          uint16 resetDoze:1;
          uint16 inWakeupGestureMode:1;
          uint16 chargerConnected:1;
#if CONFIG_PER_PIXEL_CBCSCAN
          uint16 perPixelLocalCBCEnabled:1;
#endif
#if CONFIG_HAS_ALT_REPORT_RATE
          uint16 reportRate:1;
#endif
        };
        uint16 v;
      };
    } flags;
    uint32 lastTimeStamp = 0;
    uint16 commandInProgress = 0; // This cannot be made part of the 'flags' structure above as the state needs to be preserved on a calc thread restart.
    #if CONFIG_STATICFINGERUPDATE
    uint32 gripfingerduration = 0;
    #endif
    commCommandType_t prodTestRequested;

    calcDynamicConfig_t dcfg;
    calcStaticConfig_t scfg ATTR_WIDE;

  initCalcThread:
    flags.v = 0;
    init(&scfg, &dcfg);

    flags.noDoze = dcfg.noDoze;

    // set noDoze, disableHsync

    flags.doRezero = 1;
    prodTestRequested = CMD_NONE;

#if CONFIG_PER_PIXEL_CBCSCAN
    flags.perPixelLocalCBCEnabled = dcfg.perPixelLocalCBCEnabled;
#endif

    while(1)
    {
      PLFrame_t *f;
      commCommand_t cmd;

      COMM_petWatchDog();

      flags.resetDoze = 0;

      PL_checkPowerStatus();

      cmd = COMM_getNextCommand();
      if (commandInProgress == 0) // CMD already in progress from an earlier frame, needs to be completed before looking at the next one especially for force update ( updatestaticconfig and rezero )
      {
        prodTestResult_t result ATTR_WIDE;
        uint16 force_rezero;

        switch(cmd.cmd)
        {
          case CMD_EXIT:
            goto calc_done;
          case CMD_ENTER_DEEP_SLEEP:
            COMM_ackCommand(cmd);
            force_rezero = deepSleep_sleep();
            COMM_getDynamicConfig(&dcfg);  //dynamic config could be changed on deep sleep so that it needs to be loaded again
            flags.doRezero |= (dcfg.rezeroOnExitDeepSleep | force_rezero);
            #if CONFIG_HIC_LPWG_MODE_B
            if (dcfg.inWakeupGestureMode)
              PL_enterMode(mode_modeB_trgt);
            else
            #endif
            {
              PL_enterMode(mode_active);
              if (!PL_isNSMInitialized()) // FWTDDI-2313
                goto initCalcThread;
            }
            flags.resetDoze = 1;
            continue;
          case CMD_EXIT_DEEP_SLEEP:
            COMM_ackCommand(cmd);
            continue;
          case CMD_UPDATE_STATIC_CONFIG:
            commandInProgress = 1;
            #if CONFIG_HAS_REPORTS_GONE_BY_FORCE_UPDATE
            issuingForceUpdate = 1;
            #endif
            goto initCalcThread;
          case CMD_CHANGE_SENSING_MODE:
            COMM_ackCommand(cmd);
            COMM_getDynamicConfig(&dcfg);
            PL_setParam(PLTouchSensingMode,dcfg.touchSensingMode);
            flags.doRezero = 1;
            flags.resetDoze = 1;
            break;
          case CMD_REZERO:
            commandInProgress = 1;
            flags.doRezero = 1;
            flags.resetDoze = 1;
            break;
          case CMD_ABS_AUTO_SERVO:
            COMM_ackCommand(cmd);
            break;
          case CMD_HYBRID_AUTO_SERVO:
            COMM_ackCommand(cmd);
            #if CONFIG_LOCAL_CBCSCAN_HYBRID || CONFIG_GLOBAL_CBCSCAN_HYBRID
            #if CONFIG_HAS_ALTERNATE_CBCSCAN_CONTROL
            if (
              (!flags.inWakeupGestureMode && !scfg.daqParams.globalCbcHybridActiveDisable)
              || (flags.inWakeupGestureMode && !scfg.daqParams.globalCbcHybridLPWGDisable)
              )
            #endif
            {
              PL_findBestCbcs(&scfg, cbc_globalHybrid);
            }
            #if CONFIG_HAS_ALTERNATE_CBCSCAN_CONTROL
            if (
              (!flags.inWakeupGestureMode && !scfg.daqParams.localCbcHybridActiveDisable)
              || (flags.inWakeupGestureMode && !scfg.daqParams.localCbcHybridLPWGDisable)
              )
            #endif
            {
              PL_findBestCbcs(&scfg, cbc_localHybrid);
            }
            if (!dcfg.inWakeupGestureMode)
            {
              PL_setParam(PLTouchSensingMode, dcfg.touchSensingMode);
              PL_enterMode(mode_active);
            }
            flags.doRezero = 1;
            flags.resetDoze = 1;
            #endif
            break;
          case CMD_PERPIXEL_AUTO_SERVO:
            COMM_getStaticConfig(&scfg);
            PL_enterMode(mode_idle);
            PL_findBestCbcs(&scfg, cbc_perPixelLocal);
            PL_enterMode(mode_active);
            COMM_ackCommand(cmd);
            #if CONFIG_PER_PIXEL_CBCSCAN
              // Only need to re-zero if currently using per-pixel local CBCs)
              if (flags.perPixelLocalCBCEnabled)
              {
                flags.doRezero = 1;
                flags.resetDoze = 1;
              }
            #endif
            break;
          case CMD_DO_FULL_RAW_CAP_TEST:
            PL_getTestFrame(prodTestType_fullRawCap, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_HIGH_RESISTANCE_TEST:
            PL_getTestFrame(prodTestType_highResistance, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_SENSOR_SPEED_TEST:
            PL_getTestFrame(prodTestType_sensorSpeed, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_TREX_OPEN_CONDUCTIVE_BAR_TEST:
            PL_getTestFrame(prodTestType_trexOpenConductiveBar, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_TREX_GND_COUNDUCTIVE_BAR_TEST:
            PL_getTestFrame(prodTestType_trexGndConductiveBar, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_TREX_SHORT_TEST:
            PL_getTestFrame(prodTestType_trexShort, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_GPIO_SHORTS_TEST:
            PL_getTestFrame(prodTestType_gpioShort, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_GPIO_OPENS_TEST:
            PL_getTestFrame(prodTestType_gpioOpen, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_PRE_DECONVOLVED_CAP_TEST:
            PL_getTestFrame(prodTestType_preDeconvolvedCap, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            break; // FWTE-1239
          case CMD_DO_ADC_RANGE_CT_LIMITS_TEST:
            PL_getTestFrame(prodTestType_adcRangeCtLimit, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_ETOE_SHORT_TEST:
            PL_getTestFrame(prodTestType_etoeShort, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_EXTENDED_SENSOR_SPEED_TEST:
            PL_getTestFrame(prodTestType_extendedSensorSpeed, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          case CMD_DO_SATURATED_RAW_AMP_ADC_TEST:
            PL_getTestFrame(prodTestType_adcSaturation, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
        #if IS_ANY_TDDI_HIC
          case CMD_DO_HIC_RX_RX_SHORT_TEST:
          {
          #if CONFIG_HAS_RT125_LCBC
            uint16 lcbcHybrid[(MAX_RX+MAX_TX + 1) / 2];
            COMM_getHybridLocalCBCs_Logical(lcbcHybrid);
            if (scfg.RT125.LCBC)
            {
              #if CONFIG_HAS_RT125_ALTERNATE_PARAMETERS
              DAQ_writeVar(IS_RT125, 1);
              DAQ_writeVar(TX_2D_RESET_WITH_GUARD_RT125_ABSX_VAL, scfg.RT125.TX_2D_RESET_WITH_GUARD_ABSX);
              DAQ_writeVar(RX_2D_RESET_WITH_GUARD_RT125_ABSX_VAL, scfg.RT125.RX_2D_RESET_WITH_GUARD_ABSX);
              DAQ_writeVar(RX_0D_RESET_WITH_GUARD_RT125_ABSX_VAL, scfg.RT125.RX_0D_RESET_WITH_GUARD_ABSX);
              #endif
              PL_findBestCbcs(&scfg, cbc_localHybrid);
            }
          #endif
            PL_getTestFrame(prodTestType_hicRxRxShort, &scfg, &dcfg, &result);
          #if CONFIG_HAS_RT125_LCBC
            if (scfg.RT125.LCBC)
            {
              // We only need to write back to F$54 because initCalcThread will take care of it.
              COMM_setHybridLocalCBCs_Logical(lcbcHybrid);
            }
          #endif
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
          }
          case CMD_DO_HIC_TX_TX_SHORT_TEST:
            PL_getTestFrame(prodTestType_hicTxTxShort, &scfg, &dcfg, &result);
            COMM_postProductionTestReport(&result);
            goto initCalcThread;
        #endif
        #if CONFIG_IFP_ESD_ACTIVEMODE
          case CMD_EXIT_ESDMODE:
            force_exit_esdmode(1);
            COMM_ackCommand(cmd);
            break;
        #endif
          case CMD_DO_TRANS_DELTA_ADC_TEST:          // intentional fall-through
          case CMD_DO_TRANS_DELTA_CAP_TEST:          // intentional fall-through
          case CMD_DO_TRANS_RAW_ADC_TEST:            // intentional fall-through
          case CMD_DO_TRANS_RAW_ADC_D4_TEST:         // intentional fall-through
          case CMD_DO_TRANS_RAW_ADC_D6_TEST:         // intentional fall-through
          case CMD_DO_TRANS_RAW_CAP_TEST:            // intentional fall-through
          case CMD_DO_HYBRID_DELTA_ADC_TEST:         // intentional fall-through
          case CMD_DO_HYBRID_DELTA_CAP_TEST:         // intentional fall-through
          case CMD_DO_HYBRID_RAW_ADC_TEST:           // intentional fall-through
          case CMD_DO_HYBRID_RAW_CAP_TEST:           // intentional fall-through
          case CMD_DO_HYBRID_SATURATED_RAW_ADC_TEST: // intentional fall-through
          case CMD_DO_STORED_IMAGE_BASELINE_TEST:    // intentional fall-through
          case CMD_DO_TAGS_RAW_CAP_TEST:             // intentional fall-through
          case CMD_DO_AMP_ABS_RAW_ADC_TEST:          // intentional fall-through
          case CMD_DO_AMP_ABS_RAW_CAP_TEST:          // intentional fall-through
          case CMD_DO_AMP_ABS_DELTA_ADC_TEST:        // intentional fall-through
          case CMD_DO_AMP_ABS_DELTA_CAP_TEST:        // intentional fall-through
            #if CONFIG_HAS_DOZE_DATA_REPORTING
            if(dcfg.forceDoze==0)
            #endif
            {
            prodTestRequested = cmd.cmd;
            flags.resetDoze = 1;
            }
            break;
          default:
            break;
        }
      }

      COMM_getDynamicConfig(&dcfg);

      PL_setParam(PLDisableNSM,dcfg.disableNoiseMitigation);

      if (dcfg.noDoze)
      {
        flags.resetDoze = 1;
      }

      if (dcfg.chargerConnected != flags.chargerConnected)
      {
        PL_setParam(PLChargerPresent, dcfg.chargerConnected);
        flags.chargerConnected = dcfg.chargerConnected;
      }

      #if CONFIG_HAS_ALT_REPORT_RATE
      if (dcfg.reportRate != flags.reportRate)
      {
        PL_setParam(PLAltReportRate, dcfg.reportRate);
        flags.reportRate = dcfg.reportRate;
      }
      #endif

      #if CONFIG_HAS_WAKEUPGESTURE
      // check for entry/exit of wakeup gesture mode
      if (flags.inWakeupGestureMode != dcfg.inWakeupGestureMode)
      {
        uint16 framePeriod = 1;
        flags.inWakeupGestureMode = dcfg.inWakeupGestureMode;
#if CONFIG_HIC_LPWG_MODE_B
        flags.doRezero = 1;   // force new baseline on entry (TRGT profiles) and exit
        if (flags.inWakeupGestureMode == 0)
          flags.resetDoze = 1;  // restore doze settings
#endif
        if (flags.inWakeupGestureMode)
          framePeriod = gesture_getLpwgFramePeriod();
        PL_setParam(PLFramePeriod,framePeriod);
        gesture_setEnabled(flags.inWakeupGestureMode);
        gesture_lp_reinit();
      }
      #endif
      #if CONFIG_GRIPSUPPRESSION
      gripSuppression_enabled(dcfg.gripSuppressionEnable);
      #endif

      #if CONFIG_IFP_ESD_ACTIVEMODE

        esd_dynamic_params(dcfg.esdModeCtrlField.enable,dcfg.esdModeCtrlField.forceEnterEsdMode);

        if (getESDmode())
        {
            flags.resetDoze = true;
            esd_checkFirstTimeEnterESDmode();
        }
      #endif

      #if CONFIG_PER_PIXEL_CBCSCAN
        if (dcfg.perPixelLocalCBCEnabled != flags.perPixelLocalCBCEnabled)
        {
          PL_setParam(PLPerPixelLocalCBCEnabled, dcfg.perPixelLocalCBCEnabled);
          flags.perPixelLocalCBCEnabled = dcfg.perPixelLocalCBCEnabled;
          flags.doRezero = 1;
          flags.resetDoze = 1;
        }
      #endif

#if CONFIG_HIC_LPWG_MODE_B
      if (lowPower_lpwgModeB_fingerGesture())
        f = PL_getFrame(frame_modeB_trgt);
      else if (flags.inWakeupGestureMode)
        f = (PLFrame_t*)NULL;
      else
#endif
        f = PL_getFrame(frame_active);

      flags.resetDoze |= PL_isDozeTimerResetRequested();
#if CONFIG_HIC_LPWG_MODE_B
      flags.doRezero  |= lowPower_lpwgModeB_isRezeroRequested();
#endif

      if (flags.doRezero)
      {
        imageFrameProcessor_reinit();
        //workaround for TDDI baseline shift after frequency scan gear change (cfg_FreqScanGear_Transition_NoiseLevel_Modify)
        #if CONFIG_NSM
          PL_setParam(PLFreqTransCounter,0);//stop baseline compensate counter because baseline is re-calculate
        #endif
        flags.doRezero = 0;
      }

#if IS_ANY_TDDI_HIC
      if (f == (PLFrame_t*)NULL) goto skip_frame;
#endif

      {
        ifpMode_t ifpMode;
        ifpFrame_t frame;
        touchReport_t report;
        uint32 deltaTime;
        uint16 frameRate;

#if CONFIG_TDDI_AMP_BUTTONS
        int16 scaledButtons[MAX_BUTTONS];
#endif

        memset(&report, 0, sizeof(report));
        if (f->timeStamp >= lastTimeStamp)
        {
          deltaTime = f->timeStamp - lastTimeStamp;
        }
        else
        {
          deltaTime = 0xFFFFFFFF - lastTimeStamp + f->timeStamp;
        }
        lastTimeStamp = f->timeStamp;
        frameRate = 1000000/deltaTime;
        report.frameRate = frameRate;

       #if CONFIG_IFP_ESD_ACTIVEMODE
       if ( !(getESDmode()))
       {
       #endif
#if CONFIG_NSM
#if CONFIG_HIC_LPWG_MODE_B
        if (lowPower_lpwgModeB_fingerGesture() == 0)
#endif
        {
          PLNSMState_t n;
          n = PL_getNSMState();
          report.powerim = n.powerIM;  //FIXME COMM_postDebugReport of Calc2forPC should be rearranged
          report.cidim = n.cidIM;
          report.railim = n.railIM;
          report.nsmFrequency = n.frequency;
          report.nsmState = n.state;
#if CONFIG_NSM_CALLISTO
          report.varcidim = n.varCidIM;
#endif

#if CONFIG_NSM_EUROPA && !CONFIG_HAS_CPU_MONITOR
          //report.frameRate = n.frameRate;//accurancy is higher than hardware ticks.
#endif

#if CONFIG_NSM_EUROPA && CONFIG_HAS_BASELINE_COMPENSATION
          if(n.frequencyTranState == nsmTran_start || n.frequencyTranState == nsmTran_end)
          {
            COMM_getNsmIfpStaticConfig(&scfg);
            PL_convertToIFPFormat(&scfg);

            if(n.frequencyTranState == nsmTran_start)
            {
              scfg.ifpConfig.sensorParams.noiseFloor_LSB += scfg.ifpConfig.bsConfig.noiseFloorAddLevel;
              scfg.ifpConfig.segConfig.minPeak_LSB += scfg.ifpConfig.bsConfig.minPeakAddLevel;

              if(n.compLevel)
              {
                scfg.ifpConfig.sensorParams.noiseFloor_LSB += scfg.ifpConfig.bsConfig.strongAddLevel;
                scfg.ifpConfig.segConfig.minPeak_LSB += scfg.ifpConfig.bsConfig.strongAddLevel;
                scfg.ifpConfig.classConfig.glovedFingerThreshold_pct += scfg.ifpConfig.bsConfig.gloveFingerThresholdAddLevel;
              }
              scfg.ifpConfig.buConfig.baselineUpdateSpeed = scfg.ifpConfig.bsConfig.baselineUpdateSpeed;
            }
            else if(n.frequencyTranState == nsmTran_end)
            {
              scfg.ifpConfig.buConfig.baselineUpdateSpeed = 1; //default speed
            }

            imageFrameProcessor_configure(&scfg.ifpConfig);
          }
#endif
        }
#endif
       #if CONFIG_IFP_ESD_ACTIVEMODE
       }
       #endif

#if CONFIG_HIC_LPWG_MODE_B
      if (lowPower_lpwgModeB_fingerGesture())
      {
        if (dcfg.resetGestureCounters)
        {
          gesture_lp_setResetGestureCounters();
          COMM_clearResetGestureCounters();
        }

        ifpMode.inhibitMoistureMitigation = 1;
        ifpMode.holdLiftedIndices = 0;
        ifpMode.noiseMitigationEnabled = 0;
        ifpMode.inhibitRelaxation = dcfg.noBaselineRelaxation;

        frame.rawImage = f->data.image;     // NULL
        frame.rawProfileRX = (uint16 *)f->data.hybridX;
        frame.rawProfileTX = (uint16 *)f->data.hybridY;

        imageFrameProcessor_nextUltraLPWGFrame(&report.touch, &frame, (ifpTimeStamp_t) (deltaTime/1000), ifpMode);
        if (report.touch.SFReport.objectsPresent)
          flags.resetDoze = 1;

        // set flag for gesture_detect()
        // TODO: or should SFTouch.pos[] be copied to touch.pos[] here?
        report.singleFingerTouch = 1;
      }
      else
#endif
      {
        ifpMode.noiseMitigationEnabled = (report.nsmState>=nsmState_fnm);
        ifpMode.inhibitRelaxation = dcfg.noBaselineRelaxation;
        ifpMode.inhibitDisplayNoiseRemoval = !dcfg.displayNoiseRemoverEnabled;
        ifpMode.inhibitDisplayNoiseRemovalGlobalMedian = 1;
        ifpMode.inhibitHybridDisplayNoiseRemoval = !dcfg.hybridDisplayNoiseRemoverEnabled;
        ifpMode.inhibitLGMCorrection = dcfg.noLGMCorrection;
        ifpMode.inhibitMoistureMitigation = !dcfg.moistureEnabled;
        ifpMode.inhibitMoistureMitigationAMP = !dcfg.moistureAMPEnabled;
        ifpMode.holdLiftedIndices = 0;
        ifpMode.inhibitAntiBending = !dcfg.enableAntiBending;
        ifpMode.inhibitProfileAntiBending = !dcfg.enableProfileAntiBending;
        ifpMode.faceDetectEnable = dcfg.enableFaceDetect;
        ifpMode.enableSideTouch = dcfg.enableSideTouch;
        ifpMode.inhibitShadowRemoval = !dcfg.shadowRemoverEnabled;
        ifpMode.inhibitShadowRemovalAMP = !dcfg.shadowRemoverAMPEnabled;
        ifpMode.thickGloveEnabled = dcfg.thickGloveEnabled;
        ifpMode.enableALGM = dcfg.aLGMenable;

        ifpMode.hybridGloveEnabled = dcfg.hybridGloveEnabled;
        ifpMode.inWakeupGestureMode = dcfg.inWakeupGestureMode;
        #if defined(CONFIG_CLOSED_COVER_WINDOW_DATA_ONLY) && CONFIG_CLOSED_COVER_WINDOW_DATA_ONLY
        ifpMode.closedCoverOperation = dcfg.closedCoverOperation;
        #endif
        #if CONFIG_IFP_CLOSEDCOVER
        ifpMode.closedCoverEnabled = dcfg.posReportConfigParams.closedCoverParams.closedCoverEnable;
        #endif

        ifpMode.knuckleEnabled = dcfg.knuckleEnabled;
        ifpMode.inhibitWeakObjectFilter = !dcfg.enableWeakObjectFilter;

        frame.rawImage = f->data.image;
#if CONFIG_TDDI_AMP_BUTTONS
        {
          daqParams_t *daqc = &scfg.daqParams;
          uint16 i;

          for (i=0;i<daqc->numButtons;++i) {
            scaledButtons[i] = f->data.buttons[i];
          }
          PL_0DButtonsScaling (scaledButtons, scfg.daqParams.buttonScaleFactor);
          frame.rawTransButtons = NULL;
          frame.rawAbsButtons = scaledButtons;   // If using AMP buttons, treat button data as ABS buttons.
        }
#else
        frame.rawTransButtons = (uint16 *)f->data.buttons;
#endif
#if CONFIG_HAS_HYBRID
        frame.rawProfileRX = (uint16 *)f->data.hybridX;
        frame.rawProfileTX = (uint16 *)f->data.hybridY;
#endif

      #if CONFIG_IFP_ESD_ACTIVEMODE
        if (getESDmode())
        {
          if (COMM_getFingerCnt())
          {
             report.touch.freshData = 1;
          }
          esd_calculation(frame.rawImage,dcfg.esdModeCtrlField.forceEnterEsdMode);

          if(!getEsdStartStatus())    // esdstart = 0
            flags.noDoze = dcfg.noDoze;
        }
        else
      #endif // CONFIG_IFP_ESD_ACTIVEMODE
      {
        imageFrameProcessor_nextFrame(&report.touch, &frame, (ifpTimeStamp_t) (deltaTime/1000), ifpMode);
        #if CONFIG_HAS_TDDI_ESD_IMAGE_CHECKER
              esd_image_checker_rawImage(frame.rawImage);
        #endif
        #if CONFIG_IFP_ESD_ACTIVEMODE
          if ((dcfg.esdModeCtrlField.enable) && (!(getESDmode())))
          {
            esd_detection();
          }
       #endif // CONFIG_IFP_ESD_ACTIVEMODE
#if CONFIG_HIC_LPWG_MODE_B
        // clr flag for gesture_detect()
        report.singleFingerTouch = 0;
#endif
      }

#if CONFIG_IFP_KNUCKLE
        if(dcfg.knuckleEnabled && report.touch.fngCnt && report.touch.peakIdx)
        {
          knuckleRoiCollector(&report.touch);
        }
#endif

#if CONFIG_GRIPSUPPRESSION
        gripSuppression_apply(&report.touch);
#endif

#if CONFIG_GRIPSUPPRESSION_RULE2
        applyGripSuppressionRule2(&report.touch);
        #if CONFIG_STATICFINGERUPDATE
        if(report.touch.freshData)
        {
          gripfingerduration = 0;
        }
        else if(report.touch.objectsPresent)
        {
          #define REFRESH_INTERVAL 200  //> 200 ms
          gripfingerduration += deltaTime/1000;
          if(gripfingerduration > REFRESH_INTERVAL)
          {
            report.touch.freshData = 1;
            gripfingerduration = 0;
          }
        }
        #endif
#endif
      }

        report.setAttn = report.touch.freshData;
        report.timeStamp = f->timeStamp;
        #if CONFIG_HYBRID_CBC_CORRECTION
          if (scfg.cbcCorrectionEnabled)
          {
            flags.doRezero = PL_hybridCBCAutoCorrection(&scfg, report.touch.objectsPresent, frame.rawProfileRX, frame.rawProfileTX);
          }
        #endif

        // this can override setAttn if enabled
        // if (lowPower_isInActiveMode())
        gesture_detect(&report);

        COMM_postTouchReport(&report);
        PL_setParam(PLObjectPresent,   report.touch.objectsPresent);
        PL_setParam(PLGestureDetected, report.gesture.gestureDetected);
        #if CONFIG_TDDI_AMP_BUTTONS
        if (report.touch.objectsPresent || report.touch.faceDetected || report.touch.buttons0DReport.objectPresent) // if objects present
        #else
        if (report.touch.objectsPresent || report.touch.faceDetected) // if objects present
        #endif
          flags.resetDoze = 1;


        #if CONFIG_HAS_CROSSHAIR_TEST
          COMM_crosshairReport(&report);
        #endif

      }

      // reporting data to the host
      {
        PLCapData_t frameCapRawData, frameCapDeltaData;
        PLFrameData_t frameAdcDeltaData;
        uint16 *imageBaseline = imageFrameProcessor_getBaseline(baselineType_trans);
#if CONFIG_IFP_ESD_ACTIVEMODE
        int16 *imageDelta;
        if(getESDmode())
           imageDelta = ESD_getDelta();
        else
           imageDelta = imageFrameProcessor_getDelta(baselineType_trans);
#else
        int16 *imageDelta = imageFrameProcessor_getDelta(baselineType_trans);
#endif
#if CONFIG_HAS_HYBRID
        int16 *hybridXDelta = imageFrameProcessor_getDelta(baselineType_absx);
        int16 *hybridYDelta = imageFrameProcessor_getDelta(baselineType_absy);
#endif
#if CONFIG_HAS_0D_BUTTONS
#if CONFIG_TDDI_AMP_BUTTONS
        int16 *buttonTransDeltaPtr = imageFrameProcessor_getDelta(baselineType_button);
        uint16 *buttonTransBaselinePtr = imageFrameProcessor_getBaseline(baselineType_button);
#else
        int16 *buttonTransDeltaPtr = imageFrameProcessor_getDelta(baselineType_buttons0DTrans);
        uint16 *buttonTransBaselinePtr = imageFrameProcessor_getBaseline(baselineType_buttons0DTrans);
#endif
#endif

        COMM_postDebugReport(DBGREPORT_IMAGE_RAW, (uint16*)f->data.image, LEN(f->data.image));
        COMM_postDebugReport(DBGREPORT_IMAGE_BASELINE, (uint16*)imageBaseline, MAX_TX*MAX_RX);
        COMM_postDebugReport(DBGREPORT_IMAGE_DELTA_PADDED, (uint16*)imageDelta, (MAX_TX+1)*(MAX_RX+1)+1);

#if CONFIG_HAS_HYBRID
        COMM_postDebugReport(DBGREPORT_HYBRID_X_DELTA, (uint16*)hybridXDelta, LEN(hybridXDelta));
        COMM_postDebugReport(DBGREPORT_HYBRID_Y_DELTA, (uint16*)hybridYDelta, LEN(hybridYDelta));
#endif

#if CONFIG_HAS_0D_BUTTONS
        COMM_postDebugReport(DBGREPORT_BUTTON_RAW, (uint16*)f->data.buttons, LEN(f->data.buttons));
        COMM_postDebugReport(DBGREPORT_BUTTON_DELTA, (uint16*)buttonTransDeltaPtr, LEN(f->data.buttons));
        COMM_postDebugReport(DBGREPORT_BUTTON_BASELINE, (uint16*)buttonTransBaselinePtr, LEN(f->data.buttons));
#endif

        //convert rawadc to rawcap, use original frame buffer as raw adc buffer and export raw Cap result to frameCapRawData local buffer
        if ((prodTestRequested == CMD_DO_TRANS_RAW_CAP_TEST) ||
            (prodTestRequested == CMD_DO_HYBRID_RAW_CAP_TEST) ||
            (prodTestRequested == CMD_DO_AMP_ABS_RAW_CAP_TEST) ||
            (prodTestRequested == CMD_DO_STORED_IMAGE_BASELINE_TEST))
        {
          //copy Baseline image into Trans Adc Raw to convert it to CAP to report
          if (prodTestRequested == CMD_DO_STORED_IMAGE_BASELINE_TEST)
          {
            memcpy(f->data.image,imageBaseline,MAX_TX*MAX_RX*sizeof(imageBaseline[0]));
#if CONFIG_HAS_0D_BUTTONS
            //- Copy 0D baseline to cap buffer
            PL_copy0DToFrameBuffer(0, buttonTransBaselinePtr, &f->data);
#endif
          }
          PL_convertActiveFrameToRawCap(&f->data,&frameCapRawData);
        }
        else //use frameAdcDeltaData to save delta elements from ifp, convert deltaadc to deltacap, export deltaCap to frameCapDeltaData local buffer
        {
          if ((prodTestRequested == CMD_DO_HYBRID_DELTA_CAP_TEST) || (prodTestRequested == CMD_DO_HYBRID_DELTA_ADC_TEST))
          {
#if CONFIG_HAS_HYBRID
            //copy Hybrid Delta data into frame's Hybrid Delta buffer for reporting and converting
            memcpy(frameAdcDeltaData.hybridX,hybridXDelta,MAX_RX*sizeof(hybridXDelta[0]));
            memcpy(frameAdcDeltaData.hybridY,hybridYDelta,MAX_TX*sizeof(hybridYDelta[0]));
#endif
          }
          //copy Trans Delta data into frame's Trans Delta buffer for reporting and converting
          else if ((prodTestRequested == CMD_DO_TRANS_DELTA_CAP_TEST) ||
                   (prodTestRequested == CMD_DO_TRANS_DELTA_ADC_TEST) ||
                   (prodTestRequested == CMD_DO_AMP_ABS_DELTA_ADC_TEST) ||
                   (prodTestRequested == CMD_DO_AMP_ABS_DELTA_CAP_TEST))
          {
            copy2DToFrameBuffer((deltaImage_t *)imageDelta, &frameAdcDeltaData);

#if CONFIG_HAS_0D_BUTTONS
            // Copy button data to frame buffer
            PL_copy0DToFrameBuffer(0, buttonTransDeltaPtr, &frameAdcDeltaData);
#endif
          }
          //copy Moisture tag image into Trans Adc Delta to convert it to CAP and to report
          else if (CONFIG_HAS_MOISTURE  && (prodTestRequested == CMD_DO_TAGS_RAW_CAP_TEST))
          {
            int16 tagsImg[MAX_TX*MAX_RX];
            imageFrameProcessor_computeTagsImage(f->data.image, tagsImg);
            memcpy(frameAdcDeltaData.image,tagsImg,MAX_TX*MAX_RX*sizeof(tagsImg[0]));
          }

          if ((prodTestRequested == CMD_DO_TRANS_DELTA_CAP_TEST) ||
              (prodTestRequested == CMD_DO_HYBRID_DELTA_CAP_TEST) ||
              (prodTestRequested == CMD_DO_AMP_ABS_DELTA_CAP_TEST) ||
              (CONFIG_HAS_MOISTURE || (prodTestRequested == CMD_DO_TAGS_RAW_CAP_TEST)))
          {
            PL_convertActiveFrameToDeltaCap(&frameAdcDeltaData,&frameCapDeltaData);
          }
        }

        // Trans report type handling
        switch(prodTestRequested)
        {
          case CMD_DO_TRANS_RAW_ADC_TEST:
            COMM_postDebugReport(IMAGE_REPORT_RAW_TRANS_ADC_RT12, (uint16*)f->data.image, LEN(f->data.image));
            break;
          case CMD_DO_TRANS_RAW_ADC_D4_TEST:
            {
              uint16 i, j=LEN(f->data.image);
              for(i=0;i<j;i++)
                f->data.image[i] = (((f->data.image[i]+1)<<1)>>3);
              COMM_postDebugReport(IMAGE_REPORT_RAW_TRANS_ADC_RT136, (uint16*)f->data.image, LEN(f->data.image));
            }
            break;
          case CMD_DO_TRANS_RAW_ADC_D6_TEST:
            {
              uint16 i, j=LEN(f->data.image);
              for(i=0;i<j;i++)
                f->data.image[i] = (((f->data.image[i]+2001)<<1)/12);
              COMM_postDebugReport(IMAGE_REPORT_RAW_TRANS_ADC_RT138, (uint16*)f->data.image, LEN(f->data.image));
            }
            break;
          case CMD_DO_TRANS_RAW_CAP_TEST:
            COMM_postDebugReport(IMAGE_REPORT_RAW_TRANS_CAP_RT3, (uint16*)frameCapRawData.image, LEN(frameCapRawData.image));
            break;
          case CMD_DO_TRANS_DELTA_ADC_TEST:
            COMM_postDebugReport(IMAGE_REPORT_DELTA_TRANS_ADC_RT6, (uint16*)frameAdcDeltaData.image, LEN(frameAdcDeltaData.image));
            break;
          case CMD_DO_TRANS_DELTA_CAP_TEST:
            COMM_postDebugReport(IMAGE_REPORT_DELTA_TRANS_CAP_RT2, (uint16*)frameCapDeltaData.image, LEN(frameCapDeltaData.image));
            break;
          case CMD_DO_TAGS_RAW_CAP_TEST:
            if (CONFIG_HAS_MOISTURE)
            {
              int16 tagsImg[MAX_TX*MAX_RX];
              int16 *srcPtr = tagsImg;
              int16 *dstPtr = frameCapDeltaData.image;
              uint16 i;
              imageFrameProcessor_computeTagsImage(f->data.image, tagsImg);
              // recover the negative tagsValue to let the tuner know where's punchout
              for (i = 0; i < MAX_TX*MAX_RX; i++)
              {
                if(*srcPtr < 0)
                  *dstPtr = *srcPtr;
                dstPtr++;
                srcPtr++;
              }
              COMM_postDebugReport(IMAGE_REPORT_TYPE_TAGS_RT76, (uint16*)frameCapDeltaData.image, LEN(frameCapDeltaData.image));
            }
            break;
          case CMD_DO_STORED_IMAGE_BASELINE_TEST:
            COMM_postDebugReport(IMAGE_REPORT_STORED_IMAGE_BASELINE_RT9, (uint16*)frameCapRawData.image, LEN(frameCapRawData.image));
            break;
          case CMD_DO_AMP_ABS_RAW_ADC_TEST:
            COMM_postDebugReport(IMAGE_REPORT_RAW_ABS_ADC_RT91, (uint16*)f->data.image, LEN(f->data.image));
            break;
          case CMD_DO_AMP_ABS_RAW_CAP_TEST:
            COMM_postDebugReport(IMAGE_REPORT_RAW_ABS_CAP_RT92, (uint16*)frameCapRawData.image, LEN(frameCapRawData.image));
            break;
          case CMD_DO_AMP_ABS_DELTA_ADC_TEST:
            COMM_postDebugReport(IMAGE_REPORT_DELTA_ABS_ADC_RT93, (uint16*)frameAdcDeltaData.image, LEN(frameAdcDeltaData.image));
            break;
          case CMD_DO_AMP_ABS_DELTA_CAP_TEST:
            COMM_postDebugReport(IMAGE_REPORT_DELTA_ABS_CAP_RT94, (uint16*)frameCapDeltaData.image, LEN(frameCapDeltaData.image));
            break;
          default:
            break;
        }

#if CONFIG_HAS_HYBRID
        // Hybrid debug report
        COMM_postDebugReport(DBGREPORT_HYBRID_X_RAW, (uint16*)f->data.hybridX, LEN(f->data.hybridX));
        COMM_postDebugReport(DBGREPORT_HYBRID_Y_RAW, (uint16*)f->data.hybridY, LEN(f->data.hybridY));

        // Hybrid baseline report
        {
          uint16 *hybridXBaseline = imageFrameProcessor_getBaseline(baselineType_absx);
          uint16 *hybridYBaseline = imageFrameProcessor_getBaseline(baselineType_absy);
          COMM_postDebugReport(DBGREPORT_HYBRID_X_BASELINE, (uint16*)hybridXBaseline, LEN(hybridXBaseline));
          COMM_postDebugReport(DBGREPORT_HYBRID_Y_BASELINE, (uint16*)hybridYBaseline, LEN(hybridYBaseline));
        }

        // Hybrid report type handling
        switch (prodTestRequested)
        {
          case CMD_DO_HYBRID_RAW_ADC_TEST:
            {
              uint16 hybridRawAdc[MAX_RX+MAX_TX];
              memcpy(hybridRawAdc,       f->data.hybridX, MAX_RX*sizeof(hybridRawAdc[0]));
              memcpy(&hybridRawAdc[MAX_RX], f->data.hybridY, MAX_TX*sizeof(hybridRawAdc[0]));
              COMM_postDebugReport(IMAGE_REPORT_RAW_HYBRID_ADC_RT62, (uint16 *)hybridRawAdc, LEN(hybridRawAdc));
            }
            break;
          case CMD_DO_HYBRID_SATURATED_RAW_ADC_TEST:
            {
              uint16 hybridSaturatedRawAdc[MAX_RX+MAX_TX];
              uint32 adcMax = 16*(uint32)4095;  // adc from daq is divided by burst_size and converted to Q12p4
              uint16 i;
              memcpy(hybridSaturatedRawAdc,       f->data.hybridX, MAX_RX*sizeof(hybridSaturatedRawAdc[0]));
              memcpy(&hybridSaturatedRawAdc[MAX_RX], f->data.hybridY, MAX_TX*sizeof(hybridSaturatedRawAdc[0]));
              for (i = 0; i < MAX_RX+MAX_TX; i++)
              {
                hybridSaturatedRawAdc[i] = (hybridSaturatedRawAdc[i] == 0) || (hybridSaturatedRawAdc[i] == adcMax);
              }
              COMM_postDebugReport(IMAGE_REPORT_SATURATED_RAW_HYBRID_ADC_RT64, (uint16 *)hybridSaturatedRawAdc, LEN(hybridSaturatedRawAdc));
            }
            break;
          case CMD_DO_HYBRID_RAW_CAP_TEST:
            {
              uint32 hybridRawCap[MAX_RX+MAX_TX];
              memcpy(hybridRawCap,          frameCapRawData.hybridX, MAX_RX*sizeof(hybridRawCap[0]));
              memcpy(&hybridRawCap[MAX_RX], frameCapRawData.hybridY, MAX_TX*sizeof(hybridRawCap[0]));
             COMM_postDebugReport(IMAGE_REPORT_RAW_HYBRID_CAP_RT63, (uint16 *)hybridRawCap, 2*LEN(hybridRawCap));
            }
            break;
          case CMD_DO_HYBRID_DELTA_ADC_TEST:
            {
              uint16 hybridDeltaAdc[MAX_RX+MAX_TX];
              memcpy(hybridDeltaAdc,          frameAdcDeltaData.hybridX, MAX_RX*sizeof(hybridDeltaAdc[0]));
              memcpy(&hybridDeltaAdc[MAX_RX], frameAdcDeltaData.hybridY, MAX_TX*sizeof(hybridDeltaAdc[0]));
              COMM_postDebugReport(IMAGE_REPORT_DELTA_HYBRID_ADC_RT58, (uint16 *)hybridDeltaAdc, LEN(hybridDeltaAdc));
            }
            break;
          case CMD_DO_HYBRID_DELTA_CAP_TEST:
            {
              uint32 hybridDeltaCap[MAX_RX+MAX_TX];
              memcpy(hybridDeltaCap,          frameCapDeltaData.hybridX, MAX_RX*sizeof(hybridDeltaCap[0]));
              memcpy(&hybridDeltaCap[MAX_RX], frameCapDeltaData.hybridY, MAX_TX*sizeof(hybridDeltaCap[0]));
              COMM_postDebugReport(IMAGE_REPORT_DELTA_HYBRID_CAP_RT59, (uint16 *)hybridDeltaCap, 2*LEN(hybridDeltaCap));
            }
            break;
          default:
            break;
        }
#endif
        prodTestRequested = CMD_NONE;
      }

      COMM_postDebugReport(DBGREPORT_CYCLES, (uint16 *)&f->cycles, sizeof(f->cycles)/sizeof(uint16));
      COMM_endFrame();
      PL_releaseFrame(f);

#if IS_ANY_TDDI_HIC
    // Really? This generates a warning if it is not used which means an error and the build fails.
    skip_frame:
#endif

#if CONFIG_HIC_LPWG_MODE_B
      if (!lowPower_lpwgModeB_recal())
#endif
      gesture_checkPowerReductionOptions();

      {
        uint16 rejectTime ATTR_UNUSED = 0;
        uint16 objDetected ATTR_UNUSED = 0;

      #if CONFIG_HAS_WAKEUPGESTURE
        rejectTime = gesture_getDozeRejectTime();
        if (gesture_isAlternateDozeSensing())
        {
          flags.resetDoze = 0;
        }
        if (!gesture_allowLowPower())
        {
          flags.resetDoze = 1;
        }
      #endif

      #if CONFIG_HIC_LPWG_MODE_B
        if (flags.inWakeupGestureMode || lowPower_lpwgModeB_running())
          objDetected = lowPower_lpwgModeB_handler(flags.resetDoze, lastTimeStamp, rejectTime);
        else
        {
      #endif

      #if CONFIG_LOWPOWER_DOZE
        objDetected = lowPower_dozeHandler(flags.resetDoze, lastTimeStamp, rejectTime);
      #endif

      #if CONFIG_LOWPOWER_LOZE
        objDetected = loze_lozeHandler(flags.resetDoze, lastTimeStamp, rejectTime);
      #endif

      #if CONFIG_HIC_LPWG_MODE_B
        }
      #endif

      #if CONFIG_HAS_WAKEUPGESTURE
        gesture_updateState(objDetected);
      #endif
      }

      if (commandInProgress)
      {
        commandInProgress = 0;
        COMM_ackCommand(cmd);
      }
    }
  }
calc_done:
  ;
}
