#include "calc2.h"

#if CONFIG_CDM

#include "daq2.h"
#include "cdm.h"

typedef struct {
  uint16 enable;
  uint16 numClusters;
  uint16 numEnabledTX;
  uint16 numEnabledRX;
  uint16 numButtonRX;
  uint16 numButtons;
  uint16 numButtonClusters;
  uint16 concurrentButtonAcquisition;
  uint16 numBurstsPerCluster;
} cdm_t;

typedef struct {
  uint32 cs[2];
  uint32 pol[2];
} cdmRow_t;


//static data
static cdm_t cdm;

static void cdm_makeEyeMatrix(uint16 *imageTxes, uint16 len, uint16 *buttonTxes, uint16 *imageRxes, uint16 *numRxPerSet);
static void cdm_makeCDM4Matrices(uint16 *imageTxes, uint16 *imageRxes, uint16 len, uint16 *buttonTxes, uint16* numRxPerSet ATTR_UNUSED);
static void cdm_makeCDM8Matrices(uint16 *imageTxes, uint16 *imageRxes, uint16 len, uint16 *buttonTxes, uint16* numRxPerSet ATTR_UNUSED);
static void cdm_makeCDM10Matrices(uint16 *imageTxes, uint16 *imageRxes, uint16 len, uint16 *buttonTxes, uint16* numRxPerSet ATTR_UNUSED);
static void cdm_makeCDM12Matrices(uint16 *imageTxes, uint16 *imageRxes, uint16 len, uint16 *buttonTxes, uint16* numRxPerSet ATTR_UNUSED);
static void cdm_makeCDM13Matrices(uint16 *imageTxes, uint16 *imageRxes, uint16 len, uint16 *buttonTxes, uint16* numRxPerSet ATTR_UNUSED);
static void cdm_makeCDM16Matrices(uint16 *imageTxes, uint16 *imageRxes, uint16 len, uint16 *buttonTxes, uint16* numRxPerSet ATTR_UNUSED);
static void cdm_decodeCDM16(uint16 *image, uint16 imageDecode);
static void cdm_decodeCDM13(uint16 *image, uint16 imageDecode);
static void cdm_decodeCDM12(uint16 *image, uint16 imageDecode);
static void cdm_decodeCDM10(uint16 *image, uint16 imageDecode);
static void cdm_decodeCDM8(uint16 *image, uint16 imageDecode);
static void cdm_decodeCDM4(uint16 *image, uint16 imageDecode);
static uint32 sumVector(uint16 *v, uint16 stride, uint16 len);
static ATTR_INLINE void doOneCDM16Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0, uint16 i1, uint16 i2, uint16 i3, uint16 i4, uint16 i5);
static ATTR_INLINE void doOneCDM13Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 p0, uint16 p1, uint16 p2, uint16 p3, uint16 m0, uint16 m1, uint16 m2, uint16 m3, uint16 m4);
static ATTR_INLINE void doOneCDM10Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0, uint16 i1, uint16 i2, uint16 i3);
static ATTR_INLINE void doOneCDM12Block1Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0, uint16 i1, uint16 i2, uint16 i3, uint16 i4, uint16 i5);
static ATTR_INLINE void doOneCDM12Block0Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0, uint16 i1, uint16 i2, uint16 i3);
static ATTR_INLINE void doOneCDM8Block0Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0, uint16 i1);
static ATTR_INLINE void doOneCDM8Block1Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0, uint16 i1, uint16 i2, uint16 i3);
static void getCDMRow(uint16 clusterNumber, uint16* csVal, uint16* polVal, cdmRow_t* cdmCluster);
static void cdm_writeCDMMatrix(uint16 *csVal, uint16 *polVal, uint16 *imageTxes, uint16 *imageRxes, uint16 len, uint16 *buttonTxes, uint16 *numRxPerSet);
static void clearArray(uint16 *a, uint16 len);
static uint16 countSetBitsArray(uint16 *s, uint16 n);
static INLINE int16 countSetBits(uint16 v);

#if CONFIG_HAS_0D_BUTTONS
typedef struct {
  uint16 rowInd[MAX_BUTTONS];
  uint16 rowIndImage[MAX_BUTTONS];
  uint16 colInd[MAX_BUTTONS];
} buttonPositions_t;
static buttonPositions_t buttonPositions;
static void cdm_defineButtonDecoder(uint16 *imageTxes, uint16 *buttonTxes, uint16 *buttonRxes);
static void cdm_decodeButtonCDM(uint16* buttonImage);
static void cdm_write0DButtonNumArray(uint16* imageTxes, uint16* buttonTxes);
static uint32 activeButtons[2];
void cdm_copy0DToImageBuffer (uint16 *buttonData, uint16 *image)
{
  uint16 i;

  for (i = 0; i < cdm.numButtons; i++){
    //map button data into the image data for DS5 diagnostic data
    if(image && (buttonPositions.rowIndImage[i]!=0xff) && (buttonPositions.colInd[i]!=0xff) && \
        (buttonPositions.rowIndImage[i]<MAX_TX) && (cdm.numEnabledRX+buttonPositions.colInd[i]<MAX_RX)) //(need to avoid the bigger number of row and col in case of matlab )
    {
      image[buttonPositions.rowIndImage[i]*MAX_RX+cdm.numEnabledRX+buttonPositions.colInd[i]] = buttonData[i];
    }
  }
}

/*
Name: cdm_decodeButtons()
Purpose: Decode the button image buffer
Inputs: measured button image
Outputs: decoded button image
Effects: None
Notes:
*/

void cdm_decodeButtons(uint16 *buttonImage, uint16 *decodedButtons)
{
  uint16 i;
  cdm_decodeButtonCDM(buttonImage);

  for (i = 0; i < cdm.numButtons; i++){
    decodedButtons[i] = *(buttonImage + buttonPositions.rowInd[i]*MAX_BUTTONS + buttonPositions.colInd[i]);
  }
}

// static functions
static void cdm_defineButtonDecoder(uint16 *imageTxes, uint16 *buttonTxes, uint16 *buttonRxes)
{
  uint16 i, j, k;
  uint16 uniqueButtonTxes[MAX_BUTTONS], uniqueButtonRxes[MAX_BUTTONS];
  uint16 buttonXmtrValsAddr = BUTTON_XMTR_VAL_ARRAY;
  uint16 numUniqueTx = 0;
  uint16 numUniqueRx = 0;
  clearArray(uniqueButtonTxes, MAX_BUTTONS);
  clearArray(uniqueButtonRxes, MAX_BUTTONS);
  // find the unique button transmitters
  for (i = 0; i < cdm.numButtons; i++)
  {
    for (j = 0; j < numUniqueTx; j++)
    {
      if (uniqueButtonTxes[j] == buttonTxes[i])
      {  break;  }
    }
    uniqueButtonTxes[j] = buttonTxes[i];
    if (j == numUniqueTx)
      numUniqueTx += 1;
    for (j = 0; j < numUniqueRx; j++)
    {
      if (uniqueButtonRxes[j] == buttonRxes[i])
      {  break;  }
    }
    uniqueButtonRxes[j] = buttonRxes[i];
    if (j == numUniqueRx)
      numUniqueRx += 1;
  }
  cdm.numButtonClusters = numUniqueTx;
  // if separate button subframe
  if (cdm.concurrentButtonAcquisition == 0)
  {
    for (i = 0; i < cdm.numButtonClusters; i++)
    {
      uint16 xmtr_cs[CONFIG_XMTR_REGS];
      uint16 xmtr_pl[CONFIG_XMTR_REGS];
      for (j = 0; j < CONFIG_XMTR_REGS; j++) {
        xmtr_cs[j] = 0;
        xmtr_pl[j] = 0;
        if ((uniqueButtonTxes[i] >= 16*j)&&(uniqueButtonTxes[i]<16*(j+1))) {
          xmtr_cs[j] += (1 << (uniqueButtonTxes[i] - 16*j));
        }
      }
      DAQ_writeArray(buttonXmtrValsAddr, xmtr_cs, CONFIG_XMTR_REGS);
      buttonXmtrValsAddr += CONFIG_XMTR_REGS;
      DAQ_writeArray(buttonXmtrValsAddr, xmtr_pl, CONFIG_XMTR_REGS);
      buttonXmtrValsAddr += CONFIG_XMTR_REGS;
    }
  }

  for (i = 0; i < MAX_BUTTONS; i++)
  {
    buttonPositions.rowInd[i] = 0xff;
    buttonPositions.rowIndImage[i] = 0xff;
    buttonPositions.colInd[i] = 0xff;
  }

  for (i = 0; i < cdm.numButtons; i++)
  {
    for (k = 0; k < cdm.numButtonRX; k++)
    {
      if (uniqueButtonRxes[k] == buttonRxes[i])
      {
        buttonPositions.colInd[i] = k;
        break;
      }
    }

    if (cdm.concurrentButtonAcquisition == 1)
    {
      for (j = 0; j < cdm.numEnabledTX; j++)
      {
        if (imageTxes[j] == buttonTxes[i])
        {
          buttonPositions.rowInd[i] = j;
          buttonPositions.rowIndImage[i] = j;
          break;
        }
      }
    }
    else
    {
      for (j = 0; j < cdm.numButtonClusters; j++)
      {
        if (uniqueButtonTxes[j] == buttonTxes[i])
        {
          buttonPositions.rowInd[i] = j;
          buttonPositions.rowIndImage[i] = cdm.numEnabledTX + j;
          for (k = 0; k < cdm.numEnabledTX; k++)
          {
            if (imageTxes[k] == buttonTxes[i])
            {
              buttonPositions.rowIndImage[i] = k;
              break;
            }
          }
          break;
        }
      }
    }
  }

  #if CONFIG_CDM
  for (k = 0; k < cdm.numButtonClusters; k++)
  {
    if (buttonTxes[k] < 32) {
      activeButtons[0] += ((uint32) 1 << (buttonTxes[k]));
    }
    else if ((buttonTxes[k] >= 32) && (buttonTxes[k] < 64)) {
      activeButtons[1] += ((uint32) 1 << (buttonTxes[k] - 32));
    }
  }
  #endif
}


static void cdm_write0DButtonNumArray(uint16* imageTxes, uint16* buttonTxes)
{

  uint16 j, m;
  uint16 numOfRxSets;
  uint16 transXmtrValsAddr ATTR_UNUSED = TRANS_XMTR_VAL_ARRAY;
#if CONFIG_CDM
  uint32 activeTxes[2] ATTR_UNUSED;
  uint16 xmtrcs[4] ATTR_UNUSED;
#endif
#if IS_AFE2430
  uint16 buttonNumArrayRxSet0[MAX_IMAGE_CLUSTERS];
  uint16 buttonNumArrayRxSet1[MAX_IMAGE_CLUSTERS];

  uint16 numButtonRxPerSet[2];
  numButtonRxPerSet[0]  = DAQ_readVar(NUM_0D_RXSET0);
  numButtonRxPerSet[1] =  DAQ_readVar(NUM_0D_RXSET1);
  numOfRxSets = 2;

  clearArray(buttonNumArrayRxSet0, MAX_IMAGE_CLUSTERS);
  clearArray(buttonNumArrayRxSet1, MAX_IMAGE_CLUSTERS);
#endif

#if (IS_AFE2410 || IS_T1327 || IS_TH2421)
  uint16 buttonNumArray[MAX_IMAGE_CLUSTERS];
  clearArray(buttonNumArray, MAX_IMAGE_CLUSTERS);
  numOfRxSets = 1;
#endif

  if(cdm.enable == 0) ///This condition covers both a)CDM is disabled at build-time b)cdm is disabled at run-time
  {
    for(m = 0; m < cdm.numClusters; m++)
    {
      for (j = 0; j < cdm.numButtons; j++)
      {
        if (buttonTxes[j] == imageTxes[m])
        {

         #if IS_AFE2430
          //
          //Right now, the implementation works *only* if *all* button Rx belongs to EITHER Mux0/Set0 OR Mux1/Set1 BUT not both.
          //TODO: RMI registers are defined to handle both the cases. FW has to implement to handle both the cases.
          //
          if(numButtonRxPerSet[0] > 0)
          {
            buttonNumArrayRxSet0[m] = 1;
          }
          else if(numButtonRxPerSet[1] > 0)
          { //if belongs to Rx set1
            buttonNumArrayRxSet1[m] = 1;
          }
         #else
           //0D Txes that are sharing with 2D Tx
          buttonNumArray[m] = 1;
         #endif

        }
      }
    }
  }
  #if CONFIG_CDM
  else if(cdm.enable == 1)
  {
    for(m = 0; m < cdm.numClusters; m++)
    {
      for(j = 0;j < CONFIG_XMTR_REGS; j++)
      {
        xmtrcs[j] = 0;
        xmtrcs[j] = DAQ_readVar(transXmtrValsAddr + j); ///TODO: Not to use DAQ variables, instead use static config data
      }

      activeTxes[0] = ((uint32) xmtrcs[1] << 16) + xmtrcs[0];
      activeTxes[1] = ((uint32) xmtrcs[3] << 16) + xmtrcs[2];

      if ((activeButtons[0] & activeTxes[0]) || (activeButtons[1] & activeTxes[1]))
      {
       #if IS_AFE2430
        //
        //Right now, the implementation works *only* if *all* button Rx belongs to EITHER Mux0/Set0 OR Mux1/Set1 BUT not both.
        //TODO: RMI registers are defined to handle both the cases. FW has to implement to handle both the cases.
        //
        if(numButtonRxPerSet[0] > 0)
        {
          buttonNumArrayRxSet0[m] = 1;
        }
        else if(numButtonRxPerSet[1] > 0)
        { //if belongs to Rx set1
          buttonNumArrayRxSet1[m] = 1;
        }
       #else
         //0D Txes that are sharing with 2D Tx
        buttonNumArray[m] = 1;
       #endif
      }

      transXmtrValsAddr += numOfRxSets * CONFIG_XMTR_REGS * 2;

    }
  }
  #endif ///CONFIG_CDM

#if IS_AFE2430
  DAQ_writeArray(BUTTON_ADC_NUM_ARRAY_RX_SET0, buttonNumArrayRxSet0, MAX_IMAGE_CLUSTERS);
  DAQ_writeArray(BUTTON_ADC_NUM_ARRAY_RX_SET1, buttonNumArrayRxSet1, MAX_IMAGE_CLUSTERS);
#else
  DAQ_writeArray(BUTTON_ADC_NUM_ARRAY, buttonNumArray, MAX_IMAGE_CLUSTERS);
#endif
}

/*
Name: cdm_decodeButtonCDM()
Purpose: Decode the measured Button data generated by CDM drive matrix
Inputs: measured button data
Outputs: decoded image
Effects: None
Notes:
*/
static void cdm_decodeButtonCDM(uint16* buttonImage)
{
  if (cdm.enable == 1 && cdm.concurrentButtonAcquisition == 1 && cdm.numButtons > 0) {
    switch (CDM_ORDER) {
      case 4 :
        cdm_decodeCDM4(buttonImage, 0);
        break;
      case 8 :
        cdm_decodeCDM8(buttonImage, 0);
        break;
      case 10 :
        cdm_decodeCDM10(buttonImage, 0);
        break;
      case 12 :
        cdm_decodeCDM12(buttonImage, 0);
        break;
      case 16 :
        cdm_decodeCDM16(buttonImage, 0);
        break;
      default :
        return;
    }
  }
}
#endif

/*
Name: cdm_init()
Purpose: Initialize the CDM block
Inputs: enable, number of enabled transmitters, number of enabled receivers,
number of enabled button receivers.
Outputs: none
Effects: Configures the cdm order and enable
*/
void cdm_init(uint16 cdm_enable, uint16 numEnabledTX, uint16 numEnabledRX, uint16 numButtons, uint16 numButtonRX, uint16 concurrentButtonAcquisition, uint16 numBurstsPerCluster)
{
  cdm.enable = cdm_enable;
  cdm.numEnabledTX = numEnabledTX;
  cdm.numEnabledRX = numEnabledRX;
  cdm.numButtonRX = numButtonRX;
  cdm.numButtons = numButtons;
  cdm.concurrentButtonAcquisition = concurrentButtonAcquisition;
  cdm.numBurstsPerCluster = numBurstsPerCluster;
  cdm.numClusters = (cdm_enable > 0) ? (((numEnabledTX + CDM_ORDER - 1)/CDM_ORDER)*CDM_ORDER) : numEnabledTX;
}
/*
Name: cdm_defineCDMMatrix()
Purpose: Make the CDM drive matrix of specified size
Inputs: list of transmitters
Outputs: none
Effects: sensor is driven
*/
void cdm_defineCDMMatrix(uint16 *imageTxes, uint16 len, uint16 *buttonTxes, uint16 *buttonRxes ATTR_UNUSED, uint16 *imageRxes, uint16 *numRxPerSet)
{
#if CONFIG_HAS_0D_BUTTONS
  if (cdm.numButtons > 0)
    cdm_defineButtonDecoder(imageTxes, buttonTxes, buttonRxes);
#endif
  if (cdm.enable == 1) {
    switch (CDM_ORDER) {
      case 4 :
        cdm_makeCDM4Matrices(imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
        break;
      case 8 :
        cdm_makeCDM8Matrices(imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
        break;
      case 10 :
        cdm_makeCDM10Matrices(imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
        break;
      case 12 :
        cdm_makeCDM12Matrices(imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
        break;
      case 13 :
        cdm_makeCDM13Matrices(imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
        break;
      case 16 :
        cdm_makeCDM16Matrices(imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
        break;
    }
  }
  else {
    cdm_makeEyeMatrix(imageTxes, len, buttonTxes, imageRxes, numRxPerSet);
  }
}

/*
Name: cdm_decodeCDM()
Purpose: Decode the measured image generated by CDM drive matrix
Inputs: measured image
Outputs: decoded image
Effects: None
Notes:
*/
void cdm_decodeCDM(uint16* image)
{
  if (cdm.enable == 1) {
    switch (CDM_ORDER) {
      case 4 :
        cdm_decodeCDM4(image, 1);
        break;
      case 8 :
        cdm_decodeCDM8(image, 1);
        break;
      case 10 :
        cdm_decodeCDM10(image, 1);
        break;
      case 12 :
        cdm_decodeCDM12(image, 1);
        break;
      case 13 :
        cdm_decodeCDM13(image, 1);
        break;
      case 16 :
        cdm_decodeCDM16(image, 1);
        break;
      default :
        return;
    }
  }
}


void cdm_decodeCDM8(uint16 *image, uint16 imageDecode)
{
  uint16 y[8];
  uint16 *x = image;
  uint16 startCluster = 0;
  uint16 rx;
  uint16 numEnabledRX = (imageDecode > 0)? cdm.numEnabledRX : cdm.numButtonRX;
  uint16 STRIDE = (imageDecode > 0)? MAX_RX : MAX_BUTTONS;
  uint16 nextBlockIncrement = (imageDecode > 0)? (8*MAX_RX - numEnabledRX) : (8*MAX_BUTTONS - numEnabledRX);
  while(startCluster < cdm.numEnabledTX)
  {
    uint16 rows = cdm.numEnabledTX - startCluster;
    if (rows > 8)
      rows = 8;
    for (rx = 0; rx < numEnabledRX; rx++)
    {
      uint32 s;
      uint16 i;
      uint16 *src;
      uint16 *dst;

      src = x;
      dst = y;
      for (i = 0; i < 8; i++)
      {
        *dst = *src;
        dst++;
        src += STRIDE;
      }

      s = sumVector(y, 1, 8);
      s += 2; // change truncation to round-up at 0.5

      doOneCDM8Block1Pixel(s, y, &x[ 0*STRIDE], 3, 4, 5, 6);
      doOneCDM8Block1Pixel(s, y, &x[ 1*STRIDE], 2, 4, 5, 7);
      doOneCDM8Block1Pixel(s, y, &x[ 2*STRIDE], 1, 4, 6, 7);
      doOneCDM8Block1Pixel(s, y, &x[ 3*STRIDE], 0, 5, 6, 7);
      doOneCDM8Block0Pixel(s, y, &x[ 4*STRIDE], 3, 7);
      doOneCDM8Block0Pixel(s, y, &x[ 5*STRIDE], 2, 6);
      doOneCDM8Block0Pixel(s, y, &x[ 6*STRIDE], 1, 5);
      doOneCDM8Block0Pixel(s, y, &x[ 7*STRIDE], 0, 4);

      if (rows < 8)
      {
        src = &x[(8-rows)*STRIDE];
        dst = x;
        for (i = 0; i < rows; i++)
        {
          *dst = *src;
          src += STRIDE;
          dst += STRIDE;
        }
      }
      x++;
    }
    startCluster += 8;
    x += nextBlockIncrement;
  }
}

void cdm_decodeCDM10(uint16 *image, uint16 imageDecode)
{
  uint16 y[10];
  uint16 *x = image;
  uint16 startCluster = 0;
  uint16 rx;
  uint16 numEnabledRX = (imageDecode > 0)? cdm.numEnabledRX : cdm.numButtonRX;
  uint16 STRIDE = (imageDecode > 0)? MAX_RX : MAX_BUTTONS;
  uint16 nextBlockIncrement = (imageDecode > 0)? (10*MAX_RX - numEnabledRX) : (10*MAX_BUTTONS - numEnabledRX);
  while(startCluster < cdm.numEnabledTX)
  {
    uint16 rows = cdm.numEnabledTX - startCluster;
    if (rows > 10)
    {
      rows = 10;
    }
    for (rx = 0; rx < numEnabledRX; rx++)
    {
      uint32 s;
      uint16 i;
      uint16 *src;
      uint16 *dst;

      src = x;
      dst = y;
      for (i = 0; i < 10; i++)
      {
        *dst = *src;
        dst++;
        src += STRIDE;
      }

      s = sumVector(y, 1, 10);
      s += 2; // change truncation to round-up at 0.5
      s += 3*4096*cdm.numBurstsPerCluster;

      doOneCDM10Pixel(s, y, &x[ 0*STRIDE], 0, 1, 2, 3);
      doOneCDM10Pixel(s, y, &x[ 1*STRIDE], 1, 0, 8, 9);
      doOneCDM10Pixel(s, y, &x[ 2*STRIDE], 2, 0, 6, 7);
      doOneCDM10Pixel(s, y, &x[ 3*STRIDE], 3, 0, 4, 5);
      doOneCDM10Pixel(s, y, &x[ 4*STRIDE], 4, 3, 7, 9);
      doOneCDM10Pixel(s, y, &x[ 5*STRIDE], 5, 3, 6, 8);
      doOneCDM10Pixel(s, y, &x[ 6*STRIDE], 6, 2, 5, 9);
      doOneCDM10Pixel(s, y, &x[ 7*STRIDE], 7, 2, 4, 8);
      doOneCDM10Pixel(s, y, &x[ 8*STRIDE], 8, 1, 5, 7);
      doOneCDM10Pixel(s, y, &x[ 9*STRIDE], 9, 1, 4, 6);

      if (rows < 10)
      {
        src = &x[(10-rows)*STRIDE];
        dst = x;
        for (i = 0; i < rows; i++)
        {
          *dst = *src;
          src += STRIDE;
          dst += STRIDE;
        }
      }
      x++;
    }
    startCluster += 10;
    x += nextBlockIncrement;
  }
}

void cdm_decodeCDM12(uint16 *image, uint16 imageDecode)
{
  uint16 y[12];
  uint16 *x = image;
  uint16 startCluster = 0;
  uint16 rx;
  uint16 numEnabledRX = (imageDecode > 0)? cdm.numEnabledRX : cdm.numButtonRX;
  uint16 STRIDE = (imageDecode > 0)? MAX_RX : MAX_BUTTONS;
  uint16 nextBlockIncrement = (imageDecode > 0)? (12*MAX_RX - numEnabledRX) : (12*MAX_BUTTONS - numEnabledRX);
  while(startCluster < cdm.numEnabledTX)
  {
    uint16 rows = cdm.numEnabledTX - startCluster;
    if (rows > 12)
      rows = 12;
    for (rx = 0; rx < numEnabledRX; rx++)
    {
      uint32 s;
      uint16 i;
      uint16 *src;
      uint16 *dst;

      src = x;
      dst = y;
      for (i = 0; i < 12; i++)
      {
        *dst = *src;
        dst++;
        src += STRIDE;
      }

      s = sumVector(y, 1, 12);
      s += 2;

      doOneCDM12Block0Pixel(s, y, &x[ 0*STRIDE], 0, 1, 4, 9);
      doOneCDM12Block0Pixel(s, y, &x[ 1*STRIDE], 0, 3, 8, 10);
      doOneCDM12Block1Pixel(s, y, &x[ 2*STRIDE], 0, 2, 5, 9, 10, 11);
      doOneCDM12Block1Pixel(s, y, &x[ 3*STRIDE], 4, 7, 8, 9, 10, 11);
      doOneCDM12Block0Pixel(s, y, &x[ 4*STRIDE], 1, 2, 8, 11);
      doOneCDM12Block0Pixel(s, y, &x[ 5*STRIDE], 3, 4, 5, 11);
      doOneCDM12Block0Pixel(s, y, &x[ 6*STRIDE], 2, 4, 6, 10);
      doOneCDM12Block0Pixel(s, y, &x[ 7*STRIDE], 2, 3, 7, 9);
      doOneCDM12Block0Pixel(s, y, &x[ 8*STRIDE], 0, 6, 7, 11);
      doOneCDM12Block1Pixel(s, y, &x[ 9*STRIDE], 1, 3, 6, 9, 10, 11);
      doOneCDM12Block0Pixel(s, y, &x[ 10*STRIDE], 1, 5, 7, 10);
      doOneCDM12Block0Pixel(s, y, &x[ 11*STRIDE], 5, 6, 8, 9);


      if (rows < 12)
      {
        src = &x[(12-rows)*STRIDE];
        dst = x;
        for (i = 0; i < rows; i++)
        {
          *dst = *src;
          src += STRIDE;
          dst += STRIDE;
        }
      }
      x++;
    }
    startCluster += 12;
    x += nextBlockIncrement;
  }
}

void cdm_decodeCDM4(uint16 *image, uint16 imageDecode)
{
  uint16 fullClusters = cdm.numEnabledTX & 0xFFFC;
  int16 extraRows = cdm.numEnabledTX - fullClusters;
  uint16 *y = image;
  uint16 startCluster = 0;
  uint16 rx;
  uint16 numEnabledRX = (imageDecode > 0)? cdm.numEnabledRX : cdm.numButtonRX;
  uint16 STRIDE = (imageDecode > 0)? MAX_RX : MAX_BUTTONS;
  uint16 nextBlockIncrement = (imageDecode > 0)? (4*MAX_RX - numEnabledRX) : (4*MAX_BUTTONS - numEnabledRX);
  uint16 OFFSET = 4096*cdm.numBurstsPerCluster + 1; // add DC bias and round up when dividing
  while(startCluster < fullClusters)
  {
    for (rx = 0; rx < numEnabledRX; rx++, y++)
    {
      uint16 s = OFFSET;
      s += y[0*STRIDE];
      s += y[1*STRIDE];
      s += y[2*STRIDE];
      s += y[3*STRIDE];
      s >>= 1;

      y[0*STRIDE] = s - y[0*STRIDE];
      y[1*STRIDE] = s - y[1*STRIDE];
      y[2*STRIDE] = s - y[2*STRIDE];
      y[3*STRIDE] = s - y[3*STRIDE];
    }
    startCluster += 4;
    y += nextBlockIncrement;
  }
  if (extraRows > 0)
  {
    for (rx = 0; rx < numEnabledRX; rx++, y++)
    {
      uint16 s = OFFSET;
      s += y[0*STRIDE];
      s += y[1*STRIDE];
      s += y[2*STRIDE];
      s += y[3*STRIDE];
      s >>= 1;

      switch(extraRows)
      {
        case 3:
          y[0*STRIDE] = s - y[1*STRIDE];
          y[1*STRIDE] = s - y[2*STRIDE];
          y[2*STRIDE] = s - y[3*STRIDE];
          break;
        case 2:
          y[0*STRIDE] = s - y[2*STRIDE];
          y[1*STRIDE] = s - y[3*STRIDE];
          break;
        case 1:
          y[0*STRIDE] = s - y[3*STRIDE];
          break;
      }
    }
  }
}

void cdm_decodeCDM13(uint16 *image, uint16 imageDecode)
{
  uint16 y[13];
  uint16 *x = image;
  uint16 startCluster = 0;
  uint16 rx;
  uint16 numEnabledRX = (imageDecode > 0)? cdm.numEnabledRX : cdm.numButtonRX;
  uint16 STRIDE = (imageDecode > 0)? MAX_RX : MAX_BUTTONS;
  uint16 nextBlockIncrement = (imageDecode > 0)? (13*MAX_RX - numEnabledRX) : (13*MAX_BUTTONS - numEnabledRX);
  while(startCluster < cdm.numEnabledTX)
  {
    uint16 rows = cdm.numEnabledTX - startCluster;
    if (rows > 13)
    {
      rows = 13;
    }
    for (rx = 0; rx < numEnabledRX; rx++)
    {
      uint16 s;
      uint16 i;
      uint16 *src;
      uint16 *dst;

      src = x;
      dst = y;
      for (i = 0; i < 13; i++)
      {
        *dst = *src;
        dst++;
        src += STRIDE;
      }

      s = sumVector(y, 1, 13);
      s += 2; // add 2 to round division up
      s /= 3;
      s += 13653; // prevent negative result

      doOneCDM13Pixel(s, y, &x[ 0*STRIDE],  2,  5,  9, 11,  0,  7,  8, 10, 12);
      doOneCDM13Pixel(s, y, &x[ 1*STRIDE],  3,  6, 10, 12,  0,  1,  8,  9, 11);
      doOneCDM13Pixel(s, y, &x[ 2*STRIDE],  0,  4,  7, 11,  1,  2,  9, 10, 12);
      doOneCDM13Pixel(s, y, &x[ 3*STRIDE],  1,  5,  8, 12,  0,  2,  3, 10, 11);
      doOneCDM13Pixel(s, y, &x[ 4*STRIDE],  0,  2,  6,  9,  1,  3,  4, 11, 12);
      doOneCDM13Pixel(s, y, &x[ 5*STRIDE],  1,  3,  7, 10,  0,  2,  4,  5, 12);
      doOneCDM13Pixel(s, y, &x[ 6*STRIDE],  2,  4,  8, 11,  0,  1,  3,  5,  6);
      doOneCDM13Pixel(s, y, &x[ 7*STRIDE],  3,  5,  9, 12,  1,  2,  4,  6,  7);
      doOneCDM13Pixel(s, y, &x[ 8*STRIDE],  0,  4,  6, 10,  2,  3,  5,  7,  8);
      doOneCDM13Pixel(s, y, &x[ 9*STRIDE],  1,  5,  7, 11,  3,  4,  6,  8,  9);
      doOneCDM13Pixel(s, y, &x[10*STRIDE],  2,  6,  8, 12,  4,  5,  7,  9, 10);
      doOneCDM13Pixel(s, y, &x[11*STRIDE],  0,  3,  7,  9,  5,  6,  8, 10, 11);
      doOneCDM13Pixel(s, y, &x[12*STRIDE],  1,  4,  8, 10,  6,  7,  9, 11, 12);

      if (rows < 13)
      {
        src = &x[(13-rows)*STRIDE];
        dst = x;
        for (i = 0; i < rows; i++)
        {
          *dst = *src;
          src += STRIDE;
          dst += STRIDE;
        }
      }
      x++;
    }
    startCluster += 13;
    x += nextBlockIncrement;
  }
}

void cdm_decodeCDM16(uint16 *image, uint16 imageDecode)
{
  uint16 y[16];
  uint16 *x = image;
  uint16 startCluster = 0;
  uint16 rx;
  uint16 numEnabledRX = (imageDecode > 0)? cdm.numEnabledRX : cdm.numButtonRX;
  uint16 STRIDE = (imageDecode > 0)? MAX_RX : MAX_BUTTONS;
  uint16 nextBlockIncrement = (imageDecode > 0)? (16*MAX_RX - numEnabledRX) : (16*MAX_BUTTONS - numEnabledRX);
  while(startCluster < cdm.numEnabledTX)
  {
    uint16 rows = cdm.numEnabledTX - startCluster;
    if (rows > 16)
    {
      rows = 16;
    }
    for (rx = 0; rx < numEnabledRX; rx++)
    {
      uint32 s;
      uint16 i;
      uint16 *src;
      uint16 *dst;

      src = x;
      dst = y;
      for (i = 0; i < 16; i++)
      {
        *dst = *src;
        dst++;
        src += STRIDE;
      }

      s = sumVector(y, 1, 16);
      s += 2; // change truncation to round-up at 0.5
      s >>= 1;
      s += cdm.numBurstsPerCluster*6*4096/2;

      doOneCDM16Pixel(s, y, &x[ 0*STRIDE], 0, 1, 2, 3, 4, 5);
      doOneCDM16Pixel(s, y, &x[ 1*STRIDE], 0, 1, 6, 7, 8, 9);
      doOneCDM16Pixel(s, y, &x[ 2*STRIDE], 0, 2, 6,10,11,12);
      doOneCDM16Pixel(s, y, &x[ 3*STRIDE], 0, 3, 7,10,13,14);
      doOneCDM16Pixel(s, y, &x[ 4*STRIDE], 0, 4, 8,11,13,15);
      doOneCDM16Pixel(s, y, &x[ 5*STRIDE], 0, 5, 9,12,14,15);
      doOneCDM16Pixel(s, y, &x[ 6*STRIDE], 1, 2, 6,13,14,15);
      doOneCDM16Pixel(s, y, &x[ 7*STRIDE], 1, 3, 7,11,12,15);
      doOneCDM16Pixel(s, y, &x[ 8*STRIDE], 1, 4, 8,10,12,14);
      doOneCDM16Pixel(s, y, &x[ 9*STRIDE], 1, 5, 9,10,11,13);
      doOneCDM16Pixel(s, y, &x[10*STRIDE], 2, 3, 8, 9,10,15);
      doOneCDM16Pixel(s, y, &x[11*STRIDE], 2, 4, 7, 9,11,14);
      doOneCDM16Pixel(s, y, &x[12*STRIDE], 2, 5, 7, 8,12,13);
      doOneCDM16Pixel(s, y, &x[13*STRIDE], 3, 4, 6, 9,12,13);
      doOneCDM16Pixel(s, y, &x[14*STRIDE], 3, 5, 6, 8,11,14);
      doOneCDM16Pixel(s, y, &x[15*STRIDE], 4, 5, 6, 7,10,15);

      if (rows < 16)
      {
        src = &x[(16-rows)*STRIDE];
        dst = x;
        for (i = 0; i < rows; i++)
        {
          *dst = *src;
          src += STRIDE;
          dst += STRIDE;
        }
      }
      x++;
    }
    startCluster += 16;
    x += nextBlockIncrement;
  }
}

static void cdm_makeEyeMatrix(uint16* imageTxes, uint16 len, uint16* buttonTxes ATTR_UNUSED, uint16 *imageRxes ATTR_UNUSED, uint16 *numRxPerSet ATTR_UNUSED)
{
  uint16 i, j;
  uint16 m ATTR_UNUSED = 0, tmp ATTR_UNUSED = 0;
  int16 k ATTR_UNUSED = 0;
  uint16 transXmtrValsAddr = TRANS_XMTR_VAL_ARRAY;

  DAQ_writeVar(TRANS_CLUSTERS, cdm.numClusters);

  {
#if IS_AFE2430

  uint16 tmpindex;
  if(numRxPerSet[1] != 0)
  {

  for (m = 0; m < len; m++) {
    uint16 xmtr_cs[CONFIG_XMTR_REGS];
    uint16 xmtr_pl[CONFIG_XMTR_REGS];
    uint16 xmtr_pl_tx[CONFIG_XMTR_REGS];
    uint16 xmtr_pl_nmtx[CONFIG_XMTR_REGS];
    for (j = 0; j < CONFIG_XMTR_REGS; j++) {
      xmtr_cs[j] = 0;
      xmtr_pl_tx[j] = 0;
      xmtr_pl_nmtx[j] = 0;
      if ((imageTxes[m] >= 16*j) && (imageTxes[m]<16*(j+1))) {
        xmtr_cs[j] += (1 << (imageTxes[m] - 16*j));
      }
    }
    tmp = 0;
    for (k = 1; k >= 0; k--) {
      for (i = 0; i < numRxPerSet[k]; i++) {
        tmpindex = (numRxPerSet[tmp]*k) + i;
        for (j = 0; j < CONFIG_XMTR_REGS; j++) {
          if ((imageRxes[tmpindex] >= 16*j) && (imageRxes[tmpindex] < 16*(j+1))) {
            xmtr_pl_nmtx[j] += (1 << (imageRxes[tmpindex] - 16*j));
          }
        }
      }
      tmp++;
      for (j = 0; j < CONFIG_XMTR_REGS; j++) {
        xmtr_pl[j] = xmtr_pl_tx[j] | xmtr_pl_nmtx[j];
        xmtr_pl_nmtx[j] = 0;
          }
          DAQ_writeArray(transXmtrValsAddr, xmtr_cs, CONFIG_XMTR_REGS);
          transXmtrValsAddr += CONFIG_XMTR_REGS;
          DAQ_writeArray(transXmtrValsAddr, xmtr_pl, CONFIG_XMTR_REGS);
          transXmtrValsAddr += CONFIG_XMTR_REGS;
        }
      }
  }
  else
  {
    for (i = 0; i < len; i++) {
      uint16 xmtr_cs[CONFIG_XMTR_REGS];
      uint16 xmtr_pl[CONFIG_XMTR_REGS];
      for (j = 0; j < CONFIG_XMTR_REGS; j++) {
        xmtr_cs[j] = 0;
        xmtr_pl[j] = 0;
        if ((imageTxes[i] >= 16*j)&&(imageTxes[i]<16*(j+1))) {
          xmtr_cs[j] += (1 << (imageTxes[i] - 16*j));
        }
      }
      DAQ_writeArray(transXmtrValsAddr, xmtr_cs, CONFIG_XMTR_REGS);
      transXmtrValsAddr += CONFIG_XMTR_REGS;
      DAQ_writeArray(transXmtrValsAddr, xmtr_pl, CONFIG_XMTR_REGS);
      transXmtrValsAddr += CONFIG_XMTR_REGS;
    }
  }

#else // IS_AFE2430

  for (i = 0; i < len; i++) {
    uint16 xmtr_cs[CONFIG_XMTR_REGS];
    uint16 xmtr_pl[CONFIG_XMTR_REGS];
    for (j = 0; j < CONFIG_XMTR_REGS; j++) {
      xmtr_cs[j] = 0;
      xmtr_pl[j] = 0;
      if ((imageTxes[i] >= 16*j)&&(imageTxes[i]<16*(j+1))) {
        xmtr_cs[j] += (1 << (imageTxes[i] - 16*j));
      }
    }
    DAQ_writeArray(transXmtrValsAddr, xmtr_cs, CONFIG_XMTR_REGS);
    transXmtrValsAddr += CONFIG_XMTR_REGS;
    DAQ_writeArray(transXmtrValsAddr, xmtr_pl, CONFIG_XMTR_REGS);
    transXmtrValsAddr += CONFIG_XMTR_REGS;

  }

#endif
  }

#if CONFIG_HAS_0D_BUTTONS
  if (cdm.concurrentButtonAcquisition == 1)
  {
    cdm_write0DButtonNumArray(imageTxes, buttonTxes);
  }
#endif

  DAQ_writeRepeat(CBC_ENABLE_ARRAY, 1, len);
}

static void cdm_makeCDM4Matrices(uint16* imageTxes, uint16* imageRxes, uint16 len, uint16* buttonTxes, uint16* numRxPerSet)
{
  uint16 csVal[4];
  uint16 polVal[4];
  csVal[0] = 0xF000;
  csVal[1] = 0xF000;
  csVal[2] = 0xF000;
  csVal[3] = 0xF000;
  polVal[0] = 0x8000;
  polVal[1] = 0x4000;
  polVal[2] = 0x2000;
  polVal[3] = 0x1000;
  cdm_writeCDMMatrix(csVal, polVal, imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
}

static void cdm_makeCDM8Matrices(uint16* imageTxes, uint16* imageRxes, uint16 len, uint16* buttonTxes, uint16* numRxPerSet)
{
  uint16 csVal[8];
  uint16 polVal[8];
  csVal[0] = 0xFF00;
  csVal[1] = 0xFF00;
  csVal[2] = 0xFF00;
  csVal[3] = 0xFF00;
  csVal[4] = 0xFF00;
  csVal[5] = 0xFF00;
  csVal[6] = 0xFF00;
  csVal[7] = 0xFF00;
  polVal[0] = 0x1100;
  polVal[1] = 0x2200;
  polVal[2] = 0x4400;
  polVal[3] = 0x8800;
  polVal[4] = 0xE100;
  polVal[5] = 0xD200;
  polVal[6] = 0xB400;
  polVal[7] = 0x7800;
  cdm_writeCDMMatrix(csVal, polVal, imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
}

static void cdm_makeCDM10Matrices(uint16* imageTxes, uint16* imageRxes, uint16 len, uint16* buttonTxes, uint16* numRxPerSet)
{
  uint16 csVal[10];
  uint16 polVal[10];
  // define cs matrix here:
  csVal[0] = 0x7FC0;
  csVal[1] = 0xBFC0;
  csVal[2] = 0xDFC0;
  csVal[3] = 0xEFC0;
  csVal[4] = 0xF7C0;
  csVal[5] = 0xFBC0;
  csVal[6] = 0xFDC0;
  csVal[7] = 0xFEC0;
  csVal[8] = 0xFF40;
  csVal[9] = 0xFF80;
  // define pol matrix here:
  polVal[0] = 0x7000;
  polVal[1] = 0x80C0;
  polVal[2] = 0x8300;
  polVal[3] = 0x8C00;
  polVal[4] = 0x1140;
  polVal[5] = 0x1280;
  polVal[6] = 0x2440;
  polVal[7] = 0x2880;
  polVal[8] = 0x4500;
  polVal[9] = 0x4A00;
  cdm_writeCDMMatrix(csVal, polVal, imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
}

static void cdm_makeCDM12Matrices(uint16* imageTxes, uint16* imageRxes, uint16 len, uint16* buttonTxes, uint16* numRxPerSet)
{
  uint16 csVal[12];
  uint16 polVal[12];
  // define cs matrix here:
  csVal[0] = 0xFFF0;
  csVal[1] = 0xFFF0;
  csVal[2] = 0xFFF0;
  csVal[3] = 0xFFF0;
  csVal[4] = 0xFFF0;
  csVal[5] = 0xFFF0;
  csVal[6] = 0xFFF0;
  csVal[7] = 0xFFF0;
  csVal[8] = 0xFFF0;
  csVal[9] = 0xFFF0;
  csVal[10] = 0xFFF0;
  csVal[11] = 0xFFF0;
  // define pol matrix here:
  polVal[0] = 0xE080;
  polVal[1] = 0x8860;
  polVal[2] = 0x2B00;
  polVal[3] = 0x4540;
  polVal[4] = 0x9600;
  polVal[5] = 0x2430;
  polVal[6] = 0x02D0;
  polVal[7] = 0x11A0;
  polVal[8] = 0x5810;
  polVal[9] = 0xB150;
  polVal[10] = 0x7260;
  polVal[11] = 0x3CC0;
  cdm_writeCDMMatrix(csVal, polVal, imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
}

static void cdm_makeCDM13Matrices(uint16* imageTxes, uint16* imageRxes, uint16 len, uint16* buttonTxes, uint16* numRxPerSet)
{
  uint16 csVal[13];
  uint16 polVal[13];
  // define cs matrix here:
  csVal[0] = 0xFFF8;
  csVal[1] = 0xFFF8;
  csVal[2] = 0xFFF8;
  csVal[3] = 0xFFF8;
  csVal[4] = 0xFFF8;
  csVal[5] = 0xFFF8;
  csVal[6] = 0xFFF8;
  csVal[7] = 0xFFF8;
  csVal[8] = 0xFFF8;
  csVal[9] = 0xFFF8;
  csVal[10] = 0xFFF8;
  csVal[11] = 0xFFF8;
  csVal[12] = 0xFFF8;
  // define pol matrix here:
  polVal[0] =  0xD600;
  polVal[1] =  0x6B00;
  polVal[2] =  0x3580;
  polVal[3] =  0x1AC0;
  polVal[4] =  0x0D60;
  polVal[5] =  0x06B0;
  polVal[6] =  0x0358;
  polVal[7] =  0x81A8;
  polVal[8] =  0xC0D0;
  polVal[9] =  0x6068;
  polVal[10] = 0xB030;
  polVal[11] = 0x5818;
  polVal[12] = 0xAC08;
  cdm_writeCDMMatrix(csVal, polVal, imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
}

static void cdm_makeCDM16Matrices(uint16* imageTxes, uint16* imageRxes, uint16 len, uint16* buttonTxes, uint16* numRxPerSet)
{
  uint16 csVal[16];
  uint16 polVal[16];
  // define cs matrix here:
  csVal[0] = 0xFFFF;
  csVal[1] = 0xFFFF;
  csVal[2] = 0xFFFF;
  csVal[3] = 0xFFFF;
  csVal[4] = 0xFFFF;
  csVal[5] = 0xFFFF;
  csVal[6] = 0xFFFF;
  csVal[7] = 0xFFFF;
  csVal[8] = 0xFFFF;
  csVal[9] = 0xFFFF;
  csVal[10] = 0xFFFF;
  csVal[11] = 0xFFFF;
  csVal[12] = 0xFFFF;
  csVal[13] = 0xFFFF;
  csVal[14] = 0xFFFF;
  csVal[15] = 0xFFFF;
  // define pol matrix here:
  polVal[0] = 0xFC00;
  polVal[1] = 0xC3C0;
  polVal[2] = 0xA238;
  polVal[3] = 0x9126;
  polVal[4] = 0x8895;
  polVal[5] = 0x844B;
  polVal[6] = 0x6207;
  polVal[7] = 0x5119;
  polVal[8] = 0x48AA;
  polVal[9] = 0x4474;
  polVal[10] = 0x30E1;
  polVal[11] = 0x2952;
  polVal[12] = 0x258C;
  polVal[13] = 0x1A4C;
  polVal[14] = 0x1692;
  polVal[15] = 0x0F21;
  cdm_writeCDMMatrix(csVal, polVal, imageTxes, imageRxes, len, buttonTxes, numRxPerSet);
}

static void cdm_writeCDMMatrix(uint16* csVal, uint16* polVal, uint16* imageTxes, uint16* imageRxes ATTR_UNUSED, uint16 len, uint16* buttonTxes ATTR_UNUSED, uint16* numRxPerSet ATTR_UNUSED)
{
  uint16 i, j, k, m ATTR_UNUSED = 0, tmp ATTR_UNUSED = 0, tmpindex ATTR_UNUSED = 0;
  int16 n ATTR_UNUSED = 0;
  uint16 transXmtrValsAddr = TRANS_XMTR_VAL_ARRAY;
  uint16 cbcEnableArray[MAX_IMAGE_CLUSTERS];
  uint16 sel, pol;
  cdmRow_t cdmCluster;
  clearArray(cbcEnableArray, MAX_IMAGE_CLUSTERS);
  DAQ_writeVar(TRANS_CLUSTERS, cdm.numClusters);

#if IS_AFE2430
  if(numRxPerSet[1] != 0)
  {
  for (i = 0; i < cdm.numClusters; i++)
  {
    uint32 bitshiftVal = 0x80000000;
    uint16 xmtr_cs[CONFIG_XMTR_REGS];
    uint16 xmtr_pl[CONFIG_XMTR_REGS];
    uint16 xmtr_pl_tx[CONFIG_XMTR_REGS];
    uint16 xmtr_pl_nmtx[CONFIG_XMTR_REGS];
    getCDMRow(i, csVal, polVal, &cdmCluster);
    for (j = 0; j < CONFIG_XMTR_REGS; j++)
    {
      uint16 ind;
      xmtr_cs[j] = 0;
      xmtr_pl_tx[j] = 0;
      xmtr_pl_nmtx[j] = 0;
      for (k = 0; k < len; k++)
      {
        ind = k/32;
        if ((imageTxes[k] >= 16*j) && (imageTxes[k] < 16*(j+1)))
        {
          if (cdmCluster.cs[ind] & (bitshiftVal>>(k%32)))
          {
            xmtr_cs[j] += (1 << (imageTxes[k] - 16*j));
          }
          if (cdmCluster.pol[ind] & (bitshiftVal>>(k%32)))
          {
            xmtr_pl_tx[j] += (1 << (imageTxes[k] - 16*j));
          }
        }
      }
    }
    tmp = 0;
    for (n = 1; n >= 0; n--)
    {
      for (m = 0; m < numRxPerSet[n]; m++)
      {
        tmpindex = (numRxPerSet[tmp]*n) + m;
        for (j = 0; j < CONFIG_XMTR_REGS; j++)
        {
          if ((imageRxes[tmpindex] >= 16*j) && (imageRxes[tmpindex] < 16*(j+1)))
          {
            xmtr_pl_nmtx[j] += (1 << (imageRxes[tmpindex] - 16*j));
          }
        }
      }
      tmp++;
      for (j = 0; j < CONFIG_XMTR_REGS; j++)
      {
        xmtr_pl[j] = xmtr_pl_tx[j] | xmtr_pl_nmtx[j];
        xmtr_pl_nmtx[j] = 0;
      }
      sel = countSetBitsArray(xmtr_cs, CONFIG_XMTR_REGS);
      pol = countSetBitsArray(xmtr_pl, CONFIG_XMTR_REGS);
      if (pol != sel/2)
        cbcEnableArray[i] = 1;
      DAQ_writeArray(transXmtrValsAddr, xmtr_cs, CONFIG_XMTR_REGS);
      transXmtrValsAddr += CONFIG_XMTR_REGS;
      DAQ_writeArray(transXmtrValsAddr, xmtr_pl, CONFIG_XMTR_REGS);
      transXmtrValsAddr += CONFIG_XMTR_REGS;
    }
    }
  }
  else
  {
  for (i = 0; i < cdm.numClusters; i++)
  {
    uint32 bitshiftVal = 0x80000000;
    uint16 xmtr_cs[CONFIG_XMTR_REGS];
    uint16 xmtr_pl[CONFIG_XMTR_REGS];
    getCDMRow(i, csVal, polVal, &cdmCluster);
    // write the cs and pl registers for this cluster
    for (j = 0; j < CONFIG_XMTR_REGS; j++)
    {
      uint16 ind;
      xmtr_cs[j] = 0;
      xmtr_pl[j] = 0;
      // loop over tx to find which are active
      for (k = 0; k < len; k++)
      {
        ind = k/32;
        if ((imageTxes[k] >= 16*j) && (imageTxes[k] < 16*(j+1)))
        {
          if (cdmCluster.cs[ind] & (bitshiftVal>>(k%32)))
          {
            xmtr_cs[j] += (1 << (imageTxes[k] - 16*j));
          }
          if (cdmCluster.pol[ind] & (bitshiftVal>>(k%32)))
          {
            xmtr_pl[j] += (1 << (imageTxes[k] - 16*j));
          }
        }
      }
    }
    sel = countSetBitsArray(xmtr_cs, CONFIG_XMTR_REGS);
    pol = countSetBitsArray(xmtr_pl, CONFIG_XMTR_REGS);
    if (pol != sel/2)
      cbcEnableArray[i] = 1;

    DAQ_writeArray(transXmtrValsAddr, xmtr_cs, CONFIG_XMTR_REGS);
    transXmtrValsAddr += CONFIG_XMTR_REGS;
    DAQ_writeArray(transXmtrValsAddr, xmtr_pl, CONFIG_XMTR_REGS);
    transXmtrValsAddr += CONFIG_XMTR_REGS;

    }
  }
#else
  for (i = 0; i < cdm.numClusters; i++)
  {
    uint32 bitshiftVal = 0x80000000;
    uint16 xmtr_cs[CONFIG_XMTR_REGS];
    uint16 xmtr_pl[CONFIG_XMTR_REGS];
    getCDMRow(i, csVal, polVal, &cdmCluster);
    // write the cs and pl registers for this cluster
    for (j = 0; j < CONFIG_XMTR_REGS; j++)
    {
      uint16 ind;
      xmtr_cs[j] = 0;
      xmtr_pl[j] = 0;
      // loop over tx to find which are active
      for (k = 0; k < len; k++)
      {
        ind = k/32;
        if ((imageTxes[k] >= 16*j) && (imageTxes[k] < 16*(j+1)))
    {
          if (cdmCluster.cs[ind] & (bitshiftVal>>(k%32)))
      {
            xmtr_cs[j] += (1 << (imageTxes[k] - 16*j));
        }
          if (cdmCluster.pol[ind] & (bitshiftVal>>(k%32)))
          {
            xmtr_pl[j] += (1 << (imageTxes[k] - 16*j));
        }
      }
      }
    }
    sel = countSetBitsArray(xmtr_cs, CONFIG_XMTR_REGS);
    pol = countSetBitsArray(xmtr_pl, CONFIG_XMTR_REGS);
    if (pol != sel/2)
      cbcEnableArray[i] = 1;

    DAQ_writeArray(transXmtrValsAddr, xmtr_cs, CONFIG_XMTR_REGS);
    transXmtrValsAddr += CONFIG_XMTR_REGS;
    DAQ_writeArray(transXmtrValsAddr, xmtr_pl, CONFIG_XMTR_REGS);
    transXmtrValsAddr += CONFIG_XMTR_REGS;

  }
#endif

  DAQ_writeArray(CBC_ENABLE_ARRAY, cbcEnableArray, MAX_IMAGE_CLUSTERS);

#if CONFIG_HAS_0D_BUTTONS
  if (cdm.concurrentButtonAcquisition == 1)
  {
    cdm_write0DButtonNumArray(imageTxes, buttonTxes);

  }
#endif

}


static void getCDMRow(uint16 clusterNumber, uint16* csVal, uint16* polVal, cdmRow_t* cdmCluster)
{
  uint16 j, leftShift, rightShift, nettShift;
  uint16 squareVal = (cdm.numEnabledTX/CDM_ORDER)*CDM_ORDER;
  uint32 rowCS, rowPOL;

  /*figure out shifting for the tx select and pol*/
  rightShift = CDM_ORDER*(((clusterNumber + CDM_ORDER)/CDM_ORDER) - 1);
  if (clusterNumber < squareVal)
    leftShift = 0;
  else
    leftShift = cdm.numClusters % cdm.numEnabledTX;
  nettShift = (rightShift >= leftShift) ? rightShift - leftShift : 0;
  j = clusterNumber%CDM_ORDER;
  rowCS = csVal[j];
  rowPOL = polVal[j];
  rowCS =  rowCS << 16;
  rowPOL = rowPOL << 16;
  cdmCluster->cs[0] = 0;
  cdmCluster->pol[0] = 0;
  cdmCluster->cs[1] = 0;
  cdmCluster->pol[1] = 0;
  if (nettShift < 32)
  {
    cdmCluster->cs[0] = rowCS >> nettShift;
    cdmCluster->pol[0] = rowPOL >> nettShift;
  }
  if (nettShift > 32 - CDM_ORDER && nettShift < 32)
  {
    cdmCluster->cs[1] = rowCS << (32 - nettShift);
    cdmCluster->pol[1] = rowPOL << (32 - nettShift);
  }
  if ( nettShift >= 32 ) {
    nettShift -= 32;
    cdmCluster->cs[0] = 0;
    cdmCluster->pol[0] = 0;
    cdmCluster->cs[1] = rowCS >> nettShift;
    cdmCluster->pol[1] = rowPOL >> nettShift;
  }
}

static uint32 sumVector(uint16 *v, uint16 stride, uint16 len)
{
  uint16 i;
  uint32 sum = 0;
  for (i = 0; i < len; i++)
  {
    sum += *v;
    v += stride;
  }
  return sum;
}

static ATTR_INLINE void doOneCDM16Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0, uint16 i1, uint16 i2, uint16 i3, uint16 i4, uint16 i5)
{
  // This calculates (sum - i0 - i1 - i2 - i3 - i4 - i5)/2
  //
  // i0 - i5 are the columns of the -1s in each row of the CDM matrix.
  //
  // Note that sum is divided by 2 before this routine is called so
  // the net result is to divide by 4.
  uint16 y;
  uint32 t;
  t = sum;
  t -= src[i0];
  t -= src[i1];
  t -= src[i2];
  t -= src[i3];
  t -= src[i4];
  t -= src[i5];
  t >>= 1;
  y = (uint16) t;
  *dst = y;
}

static ATTR_INLINE void doOneCDM13Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 p0, uint16 p1, uint16 p2, uint16 p3, uint16 m0, uint16 m1, uint16 m2, uint16 m3, uint16 m4)
{
  // This calculates (sum/3 + p0 + p1 + p2 + p3 - m0 + m1 + m2 + m3 + m4)*sqrt(13)/10
  //
  // pX are the columns of the +4s in the inverse matrix
  // mX are the columns of the -2s in the inverse matrix
  //
  // Note that sum is divided by 3 before this routine is called.
  uint16 SCALE = 23629; // = sqrt(13)/10 (in 0.16 fixed-point)
  uint32 t;
  t = sum;
  t += src[p0];
  t += src[p1];
  t += src[p2];
  t += src[p3];
  t -= src[m0];
  t -= src[m1];
  t -= src[m2];
  t -= src[m3];
  t -= src[m4];
  t = (uint16) (((uint32) t * SCALE + SCALE/2) >> 16);
  *dst = (uint16) t;
}

static ATTR_INLINE void doOneCDM12Block0Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0,
                                   uint16 i1, uint16 i2, uint16 i3)
{
  // This calculates [(sum/2) - i0 - i1 - i2 - i3]/(3/2)
  //                = (sum - 2*i0 - 2*i1 - 2*i2 - 2*i3)/3
  //
  // i0-i3 are the columns with -1.
  // uint16 SCALE = (uint16) (65536.0 / (3.0 / 2.0) + 0.5);
  uint32 t;
  uint16 y;
  t = sum;
  t >>= 1;
  t += 2*4096*cdm.numBurstsPerCluster;
  t -= src[i0];
  t -= src[i1];
  t -= src[i2];
  t -= src[i3];
  y = (uint16) (t*2.0/3.0);
  *dst = y;
}

static ATTR_INLINE void doOneCDM12Block1Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0,
                                   uint16 i1, uint16 i2, uint16 i3, uint16 i4, uint16 i5)
{
  // This calculates [(sum/2) - i0 - i1 - i2 - i3 - i4 - i5 ]/(3/2)
  //                = (sum - 2*i0 - 2*i1 - 2*i2 - 2*i3 - 2*i4 - 2*i5)/3
  //
  // i0-i5 are the columns with -1.
  // uint16 SCALE = (uint16) (65536.0 / (3.0 / 2.0) + 0.5);
  uint32 t;
  uint16 y;
  t = sum;
  t >>= 1;
  t += 3*4096*cdm.numBurstsPerCluster;
  t -= src[i0];
  t -= src[i1];
  t -= src[i2];
  t -= src[i3];
  t -= src[i4];
  t -= src[i5];
  y = (uint16) (t*2.0/3.0);
  *dst = y;
}

static ATTR_INLINE void doOneCDM10Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0,
                                   uint16 i1, uint16 i2, uint16 i3)
{
  // This calculates [(sum - i0)/2 - i1 - i2 - i3]/(3/2)
  //                = (sum - i0 - 2*i1 - 2*i2 - 2*i3)/3
  //
  // i0 is the column of the CDM matrix with a 0. i1-i3 are the
  // columns with -1.
  // uint16 SCALE = (uint16) (65536.0 / (3.0 / 2.0) + 0.5);
  uint16 y;
  uint32 t;
  t = sum;
  t -= src[i0];
  t >>= 1;
  t -= src[i1];
  t -= src[i2];
  t -= src[i3];
  y = (uint16) (t*2.0/3.0);
  *dst = y;
}

static ATTR_INLINE void doOneCDM8Block0Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0,
                                   uint16 i1)
{
  // This calculates  ((sum/2) - i0 - i1) = (sum - 2*i0 - 2*i1)/2
  // i1-i3 are the columns with -1.
  uint16 y;
  uint32 t;
  t = sum >> 1;
  t += 4096*cdm.numBurstsPerCluster;
  t -= src[i0];
  t -= src[i1];
  y = (uint16) t;
  *dst = y;
}

static ATTR_INLINE void doOneCDM8Block1Pixel(uint32 sum, uint16 *src, uint16 *dst, uint16 i0, uint16 i1, uint16 i2, uint16 i3)
{
  // This calculates ((sum/2) - i0 - i1 - i2 - i3)
  // = (sum - 2*i0 - 2*i1 - 2*i2 - 2*i3)/2
  // i0 - i3 are the columns of the -1s in each row of the CDM matrix.
  uint16 y;
  uint32 t;
  t = sum >> 1;
  t += 2*4096*cdm.numBurstsPerCluster;
  t -= src[i0];
  t -= src[i1];
  t -= src[i2];
  t -= src[i3];
  y = (uint16) t;
  *dst = y;
}

static void clearArray(uint16 *a, uint16 len)
{
  for (; len > 0; len--)
    *(a+len-1) = 0;
}

static uint16 countSetBitsArray(uint16 *s, uint16 n)
{
  uint16 v = 0;
  for (; n > 0; n--)
    v += countSetBits(*s++);
  return v;
}

static INLINE int16 countSetBits(uint16 v)
{
  int16 c;
  #if defined(__CHIMERA__) && __T100X_HAS_POPCOUNT__ == 1
    asm("        popcount %0 " : "=ay" (c) : "0" (v) : "cc" );
  #else
    for (c = 0; v; c++)
    {
      v &= v - 1; // clear the least-significant bit set
    }
  #endif
  return c;
}
#endif
