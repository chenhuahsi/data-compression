/* -----------------------------------------------------------------
 *
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2014  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 */
// Filename: loze.h
// Description: header file for loze.c

#ifndef _LOZE_H_
#define _LOZE_H_

#include "calc2.h"

#if CONFIG_LOWPOWER_LOZE
void loze_init(lozeParams_t *lozeParams, uint16 numTx, uint16 numRx);
uint16 loze_lozeHandler(uint16 resetDoze, uint32 timeStamp, uint16 rejectTime);
uint16 loze_isInActiveMode();
#endif

#endif
