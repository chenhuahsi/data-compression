#include "calc2.h"
#define DAQ_SLURPER
#include "daq2.h"

#include <stdarg.h>

int main_thr_3A(void)
{
  calc_mainLoop();
  return 0;
}

uint16 COMM_getEnterDeepSleep(void)
{
}

void COMM_ackCommand(commCommand_t cmd ATTR_UNUSED)
{
}

commCommand_t COMM_waitForCommand(commCommandType_t cmds[] ATTR_UNUSED, uint16 len ATTR_UNUSED)
{
  commCommand_t c = { CMD_NONE, 0, 0};
  return c;
}

commCommand_t COMM_getNextCommand()
{
  commCommand_t c = { CMD_NONE, 0, 0 };
  return c;
}

void COMM_postDebugReport(uint16 type ATTR_UNUSED, uint16 *data ATTR_UNUSED, uint16 len ATTR_UNUSED)
{
}

void COMM_postTouchReport(touchReport_t *r ATTR_UNUSED)
{
}

void COMM_crosshairReport(touchReport_t *report ATTR_UNUSED)
{
}

void COMM_postImageReport(uint16 type ATTR_UNUSED, uint16 *data ATTR_UNUSED, uint16 len ATTR_UNUSED)
{
}

void COMM_postProductionTestReport(prodTestResult_t *result ATTR_UNUSED)
{
}

void COMM_endFrame()
{
}

void COMM_getDynamicConfig(calcDynamicConfig_t *cfg ATTR_UNUSED)
{
}

void COMM_getStaticConfig(calcStaticConfig_t *cfg ATTR_UNUSED)
{
}

configStatus_t COMM_checkForConfigChanges()
{
  configStatus_t c = { 0, 0 };
  return c;
}

void DAQ_startContinuousAcquisition(int16 frameType ATTR_UNUSED)
{
}

void DAQ_startSingleAcquisition(int16 frameType ATTR_UNUSED)
{
}

DAQFrame_t *DAQ_getFrame(int16 frameType ATTR_UNUSED)
{
  return (void *)0;
}

void DAQ_releaseFrame(DAQFrame_t *frame ATTR_UNUSED)
{
}

void DAQ_writeVar(DAQVarId_t addr ATTR_UNUSED, uint16 val ATTR_UNUSED)
{
}

void DAQ_writeVars(DAQVarId_t *ids ATTR_UNUSED, uint16 *vals ATTR_UNUSED, uint16 n ATTR_UNUSED)
{
}

void DAQ_writeVarAsync(DAQVarId_t id ATTR_UNUSED, uint16 val ATTR_UNUSED)
{
}

void DAQ_writeArray(DAQVarId_t addr ATTR_UNUSED, uint16 *val ATTR_UNUSED, uint16 len ATTR_UNUSED)
{
}

void DAQ_writeRepeat(DAQVarId_t id ATTR_UNUSED, uint16 val ATTR_UNUSED, uint16 len ATTR_UNUSED)
{
}

uint16 DAQ_readVar(DAQVarId_t id ATTR_UNUSED)
{
  return 0;
}

void DAQ_stopAcquisition()
{
}

DAQVersion_t DAQ_getVersion(void)
{
  DAQVersion_t v = { 0, 0, 0, 0, 0, 0 };
  return v;
}

void COMM_printf(romchar *s, ...)
{
  va_list va;
  uint16 i;
  // This function can't be empty or Chasm gets confused by the
  // variable argument list.
  va_start(va, s);
  while(*s)
  {
    if (*s =='%')
    {
      i = va_arg(va, uint16);
    }
    s++;
  }
  va_end(va);
}
