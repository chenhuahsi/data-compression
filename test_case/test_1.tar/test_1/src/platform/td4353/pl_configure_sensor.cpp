/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */
#include "calc2.h"

#if PLATFORM_TD4353

#include <string.h>
#include <stddef.h>

#include "daq2.h"
#include "platform.h"
#if CONFIG_NSM
#include "nsm2.h"
#endif

#include "calc_print.h"
#include "tac_init_auto.c"
#if CONFIG_HAS_TDDI_ESD_DETECTOR || CONFIG_HAS_TDDI_ESD_HANDLER || CONFIG_IFP_ESD_ACTIVEMODE
#include "esd.h"
#endif

#ifndef CONFIG_HIC_TSVD_WIDTH
#define CONFIG_HIC_TSVD_WIDTH 150 // in 10usec
#endif

PlatformApi_Tddi_Hic platformapi;

static PLMode_t mode;
static union {
  struct {
    uint16 disableNoiseMitigation : 1;
    uint16 objectsPresent : 1;
    uint16 chargerPresent : 1;
    uint16 resetDoze : 1;
  };
  uint16 all;
} flags;

#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define LEN(x) (sizeof(x)/sizeof(x[0]))

// this is an offset into a structure in 16-bit words
#if defined(__T100X_VOID_ALIGNMENT__) && (__T100X_VOID_ALIGNMENT__ == 16)
#  define OFFSET_16(x, y) offsetof(x, y)
#else
#  define OFFSET_16(x, y) (offsetof(x, y)/sizeof(uint16))
#endif

#define CONNECTED_MUXES (0x01FF)
#define STARTLINERX     (2)     //R2. TODO: Grab from config

// FIXME: get initialized static data working in firmware
static DAQFrame_t *lastFrame = (DAQFrame_t*) (NULL);  // Padma: Had to typecast NULL to avaoid compilation errors. Defined as (void*) in stddef.h
static uint16 power_on_init_done;
static uint16 nsm_init_done;
static uint16 was_60hz;
static uint16 discardActiveFrameCounter;

#if CONFIG_HAS_ESD_RECOVERY
uint16 NumCVItimeouts;
uint16 ESDCVItimeoutMax;
#endif

uint16 disable_sense_trans;
uint16 disable_sense_absx;
uint16 disable_sense_absy;
uint16 disable_sense_0d;

static void enableFrames(uint16 absx,
                         uint16 absy,
                         uint16 button,
                         uint16 trans,
                         uint16 noise,
                         uint16 rcvr,
                         uint16 freq)
{
  DAQVarId_t regs[] = {ABSX_ENABLED, ABSY_ENABLED, BUTTONS_ENABLED, IMAGE_ENABLED, NOISE_ENABLED, RCVROFST_ENABLED, FREQSCAN_ENABLED};
  uint16 vals[] =     {        absx,         absy,          button,         trans,         noise,             rcvr,             freq};
  DAQ_writeVars(regs, vals, LEN(regs));
}

static void enableActiveFrame(void)
{
  #if CONFIG_DISABLE_HYBRID_SENSE
    disable_sense_absx = 1;
    disable_sense_absy = 1;
  #endif
  enableFrames(CONFIG_HAS_HYBRID*(!disable_sense_absx),
               CONFIG_HAS_HYBRID*(!disable_sense_absy),
               CONFIG_TDDI_AMP_BUTTONS*(!disable_sense_0d),
               (!disable_sense_trans),
               CONFIG_NSM*(!flags.disableNoiseMitigation),
               0,
               0);
}

static void throwAwayDummyFrame(void)
{
  DAQFrame_t *f;
  enableFrames(0, 0, 0, 0, 0, 0, 0);
  f = DAQ_getFrame(0);
  DAQ_releaseFrame(f);
}

static void initDoze(dozeParams_t *dozeParams ATTR_UNUSED, uint16 *imageTxes ATTR_UNUSED, uint16 numTxes ATTR_UNUSED, uint16 *buttonTxes ATTR_UNUSED, uint16 numButtons ATTR_UNUSED)
{
  uint16 framePeriod = COMM_calcFramePeriod();
#if defined CONFIG_HAS_SCANNERDRIVE
  uint16 dozeFramePeriod = ((dozeParams->dozeInterval*1000)/framePeriod+1)*framePeriod-CONFIG_HIC_TSVD_WIDTH;
#else
  uint16 dozeFramePeriod = (dozeParams->dozeInterval*1000);
#endif
  DAQ_writeVar(DOZE_BURSTS_PER_CLUSTER, dozeParams->dozeBurstsPerCluster);
  DAQ_writeVar(DOZE_FRAME_PERIOD, dozeFramePeriod);
}

#if CONFIG_HIC_LPWG_MODE_B
static void initLpwgModeB(lpwgModeBParams_t *lpwgModeBParams)
{
  // Mode B frame periods are in 0.5ms units, FRAME_PERIODS are in 10 us units
  uint16 lpwgFramePeriod = (lpwgModeBParams->lpwgInterval*50);
  uint16 trgtFramePeriod = (lpwgModeBParams->trgtInterval*50);
  DAQ_writeVar(MODEB_LPWG_FRAME_PERIOD, lpwgFramePeriod);
  DAQ_writeVar(MODEB_TRGT_FRAME_PERIOD, trgtFramePeriod);

  // Mode B display duration is in CVITIMEOUT (1 us units)
  uint16 displayRefreshDuration = lpwgModeBParams->displayRefreshDuration;
  DAQ_writeVar(MODEB_DISPLAY_REFRESH_FRAME_DURATION, displayRefreshDuration);

}
#endif

static void indicesToBitmasks(uint16 *idxs, uint16 len, uint16 *bitmasks, uint16 words)
{
  uint16 i;
  // FIXME: make sure memset works in firmware
  memset(bitmasks, 0, sizeof(*bitmasks)*words);

  for (i = 0; i < len; i++)
  {
    uint16 idx = *idxs++;
    uint16 j;
    for (j = 0; j < words; j++)
    {
      if (idx < 16)
      {
        bitmasks[j] |= (1 << idx);
      }
      idx -= 16;
    }
  }
}

static void selectTimingTable(uint16 table, uint16 wait ATTR_UNUSED)
{
  uint16 loop = 0;
  COMM_selectVideoTimingTable(table);
  if (wait)
  {
    while (!COMM_isSelectedVideoTimingTable())
    {
      commCommand_t cmd = COMM_getNextCommand();
      if (cmd.cmd == CMD_ENTER_DEEP_SLEEP)
      {
        break;
      }
      if (++loop == 0xFFFF)
      {
        // highly possibly ddic is dead. to be handled by cvi timeout detector.
        break;
      }
    }
  }
}

static void selectTimingTableActive(uint16 is_60hz, uint16 wait)
{
  selectTimingTable(is_60hz, wait);
  was_60hz = is_60hz;
}

static void selectTimingTableDoze(uint16 wait)
{
  selectTimingTable(0x03, wait);
}

static void selectTimingTableCbcScan(uint16 wait)
{
  selectTimingTable(0x02, wait); // To select table C
}

void PlatformApi_Tddi_Hic::PL_convertToIFPFormat(struct calcStaticConfig_t *scfg ATTR_UNUSED)
{
  ifpConfig_t *ifpData = (ifpConfig_t *)&(scfg->ifpConfig);

  ifpData->sensorParams.cSat_LSB =
       convertDeltaCapacitanceToADCs(ifpData->sensorParams.cSat_LSB);
  ifpData->sensorParams.noiseFloor_LSB =
       convertDeltaCapacitanceToADCs(ifpData->sensorParams.noiseFloor_LSB);
  ifpData->bcConfig.absXNegThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->bcConfig.absXNegThreshold_LSB, conversionType_absx) << 2;//12p4
  ifpData->bcConfig.absYNegThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->bcConfig.absYNegThreshold_LSB, conversionType_absy) << 2;//12p4
#if CONFIG_HAS_LGM_CORRECTOR
  ifpData->lgmConfig.absXLGMObjectThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->lgmConfig.absXLGMObjectThreshold_LSB, conversionType_absx) >> 1; // shift from P2 to P1
  ifpData->lgmConfig.absYLGMObjectThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->lgmConfig.absYLGMObjectThreshold_LSB, conversionType_absy) >> 1; // shift from P2 to P1
  ifpData->lgmConfig.transLGMObjectThreshold_LSB =
       convertDeltaCapacitanceToADCs(ifpData->lgmConfig.transLGMObjectThreshold_LSB);
#endif
#if CONFIG_HAS_MOISTURE
  ifpData->mdConfig.tagsThreshold_LSB =
       convertDeltaCapacitanceToADCs(ifpData->mdConfig.tagsThreshold_LSB);
  ifpData->mdConfig.absXObjectThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->mdConfig.absXObjectThreshold_LSB, conversionType_absx) << 2;//100;
  ifpData->mdConfig.absYObjectThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->mdConfig.absYObjectThreshold_LSB, conversionType_absy) << 2;//100;
  ifpData->mfConfig.absXPenThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->mfConfig.absXPenThreshold_LSB, conversionType_absx) << 2;//100;
  ifpData->mfConfig.absYPenThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->mfConfig.absYPenThreshold_LSB, conversionType_absy) << 2;//100;
  ifpData->mfConfig.absXFingerThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->mfConfig.absXFingerThreshold_LSB, conversionType_absx) << 2;//100;
  ifpData->mfConfig.absYFingerThreshold_LSB =
       convertDeltaCapacitanceToHybridADCs(ifpData->mfConfig.absYFingerThreshold_LSB, conversionType_absy) << 2;//100;
#endif
  ifpData->segConfig.minPeak_LSB =
       convertDeltaCapacitanceToADCs(ifpData->segConfig.minPeak_LSB);
  ifpData->classConfig.absXObjectThreshold_LSB =
     convertDeltaCapacitanceToHybridADCs(ifpData->classConfig.absXObjectThreshold_LSB, conversionType_absx) << 2;//12p4
  ifpData->classConfig.absYObjectThreshold_LSB =
     convertDeltaCapacitanceToHybridADCs(ifpData->classConfig.absYObjectThreshold_LSB, conversionType_absy) << 2;//12p4
#if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
  ifpData->classConfig.absXObjectThreshold_LSB_glove =
     convertDeltaCapacitanceToHybridADCs(ifpData->classConfig.absXObjectThreshold_LSB_glove, conversionType_absx) << 2;//12p4
  ifpData->classConfig.absYObjectThreshold_LSB_glove =
     convertDeltaCapacitanceToHybridADCs(ifpData->classConfig.absYObjectThreshold_LSB_glove, conversionType_absy) << 2;//12p4
#endif
  ifpData->classConfig.saturationLevel_LSB =
     convertDeltaCapacitanceToADCs(ifpData->classConfig.saturationLevel_LSB);

#if CONFIG_HAS_BASELINE_COMPENSATION
  ifpData->bsConfig.noiseFloorAddLevel = convertDeltaCapacitanceToADCs(ifpData->bsConfig.noiseFloorAddLevel);
  ifpData->bsConfig.minPeakAddLevel = convertDeltaCapacitanceToADCs(ifpData->bsConfig.minPeakAddLevel);
  ifpData->bsConfig.strongAddLevel = convertDeltaCapacitanceToADCs(ifpData->bsConfig.strongAddLevel);
#endif

#if CONFIG_HAS_ANTI_BENDING
  ifpData->abConfig.logTouchThreshold_LSB   = convertDeltaCapacitanceToADCs(ifpData->abConfig.logTouchThreshold_LSB);
  ifpData->abConfig.deltaTouchThreshold_LSB = convertDeltaCapacitanceToADCs(ifpData->abConfig.deltaTouchThreshold_LSB);
  ifpData->abConfig.xProfileLogTouchThreshold_LSB   = convertDeltaCapacitanceToHybridADCs(ifpData->abConfig.xProfileLogTouchThreshold_LSB, conversionType_absx);
  ifpData->abConfig.xProfileDeltaTouchThreshold_LSB = convertDeltaCapacitanceToHybridADCs(ifpData->abConfig.xProfileDeltaTouchThreshold_LSB, conversionType_absx);
  ifpData->abConfig.yProfileLogTouchThreshold_LSB   = convertDeltaCapacitanceToHybridADCs(ifpData->abConfig.yProfileLogTouchThreshold_LSB,   conversionType_absy);
  ifpData->abConfig.yProfileDeltaTouchThreshold_LSB = convertDeltaCapacitanceToHybridADCs(ifpData->abConfig.yProfileDeltaTouchThreshold_LSB, conversionType_absy);
#endif
}

void PlatformApi_Tddi_Hic::PL_init(struct calcStaticConfig_t *scfg, struct calcDynamicConfig_t *dcfg ATTR_UNUSED)
{
  uint16 i;
  daqParams_t *d = &scfg->daqParams;
  uint16 gcbc_on[] = {0xFFFF, 0xFFFF, 0xF};
  uint16 gcbc_off[] = {0x0, 0x0, 0x0};

  flags.all = 0;
  flags.disableNoiseMitigation = dcfg->disableNoiseMitigation;
  mode = (PLMode_t)-1; // reset to invalid mode
  discardActiveFrameCounter = 0;

  if (lastFrame != NULL)
  {
    DAQ_releaseFrame(lastFrame);
    lastFrame = (DAQFrame_t*) (NULL); // Padma: Had to typecast NULL to avaoid compilation errors. Defined as (void*) in stddef.h
  }

  PL_enterMode(mode_idle);

  /* Write the miscellaneous registers */
  if (!power_on_init_done)
  {
    TAC_init_COMMON();
    power_on_init_done = 1;
  }

  /* Setup trans cap acquisition */
  {
    /* Setup miscellaneous variables */
    {
      was_60hz = d->lhbReportRate60Hz;
      DAQ_writeVar(LHB_REPORT_RATE_60HZ, d->lhbReportRate60Hz);
      DAQ_writeVar(ACTIVE_FRAME_PERIOD, 1200);
      DAQ_writeVar(NUM_TRANS_CLUSTERS, d->numRows);
      DAQ_writeVar(TRANS_BURSTS_PER_CLUSTER, d->imageBurstsPerCluster);
      DAQ_writeVar(TOTAL_TRANS_BURSTS_PER_FRAME, d->numRows*d->imageBurstsPerCluster);
////      DAQ_writeVar(CFB1_OFF_CNT_VAL, d->cfb1OffCnt);
    }

    /* Setup sensing state machine */
    {
      uint16 freqTblIdx = 0;
      uint16 fmodCtrl4 = 0;

      DAQ_writeVar(TRANS_FREQUENCY, d->frequency);
      DAQ_writeArray(TRANS_BURST_SIZE1_ARRAY, d->freqTable.burstSize1, LEN(d->freqTable.burstSize1));
      DAQ_writeArray(TRANS_FILT_BW_ARRAY, d->freqTable.filtBW, LEN(d->freqTable.filtBW));
      DAQ_writeArray(TRANS_RSTRETCH_DUR_ARRAY, d->freqTable.rstretchDur, LEN(d->freqTable.rstretchDur));
      DAQ_writeVar(INTEG_DUR_TRANS_VAL, d->imageIntegDur);
      DAQ_writeVar(RESET_DUR_TRANS_VAL, d->imageResetDur);
      DAQ_writeVar(TRIG_DELAY_DUR_TRANS_VAL, d->transTriggerDelay);     // F54_ANALOG_CTRL247(00)/00
      DAQ_writeVar(TRIG_HOLDOFF_DUR_TRANS_VAL, d->transTriggerHoldoff); // F54_ANALOG_CTRL247(00)/01

      if (d->lhbReportRate60Hz)
        freqTblIdx = 6;
      else
        freqTblIdx = 0;
      fmodCtrl4 = (d->fModeSetting.fModTouchGateEn << 3) + (d->fModeSetting.fModGateTsvdMark << 2) + (d->fModeSetting.fModLineSyncEn << 1) + (d->fModeSetting.fModDispGateEn);

      DAQ_writeVar(DEAD_DELAY_VAL, d->fModeSetting.deadDelay);
      DAQ_writeVar(FMOD_EN_VAL, d->fModeSetting.fmodEn);
      DAQ_writeVar(FMOD_MIN_VAL, d->fModeSetting.minOutput);
      DAQ_writeVar(FMOD_SSC_RST_EN_VAL, d->fModeSetting.fModeSscRstEn);
      DAQ_writeVar(FMOD_SB_RST_EN_VAL, d->fModeSetting.fModSbRstEn);
      DAQ_writeVar(FRAMP_CNT_VAL, d->freqTable.frampCount[freqTblIdx]);
      DAQ_writeVar(FRAMP_DELTA_VAL, d->freqTable.frampDelta[freqTblIdx]);
      DAQ_writeVar(FRAMP_MAX_VAL, d->fModeSetting.frampMax);
      DAQ_writeVar(FMOD_CTRL4_VAL, fmodCtrl4);
    }

    /* Setup guard DAC */
    {
      DAQ_writeVar(DELTA_V_START_STATE_VAL, d->deltaVStartState);
      DAQ_writeVar(DELVREF_DAC_VAL, d->delVrefState);
      DAQ_writeVar(DELTA_V_DUR_VAL, d->deltaVDur);
      DAQ_writeVar(DAC_IN_TRANS_VAL, d->dac_in_trans);
    }

    /* Setup receiver */
    {
      uint16 rcvr[CONFIG_RCVR_REGS];
      indicesToBitmasks(d->imageRxes, MAX_PHY_RX, rcvr, LEN(rcvr));
#if CONFIG_TDDI_AMP_BUTTONS
      {
        uint16 i;
        uint16 rxes[MAX_BUTTONS];
        uint16 rcvr_0d[CONFIG_RCVR_REGS];
        for (i = 0; i < MAX_BUTTONS; i++)
          rxes[i] = d->buttonRxes[i]+30;
        indicesToBitmasks(rxes, MAX_BUTTONS, rcvr_0d, LEN(rcvr_0d));
        for (i = 0; i < CONFIG_RCVR_REGS; i++)
          rcvr[i] |= rcvr_0d[i];
      }
#endif
      DAQ_writeArray(RCVR_EN_15_0_VAL, rcvr, LEN(rcvr));
      DAQ_writeVar(RCVR_FB_CAP_TRANS_VAL, d->imageRcvrFbCap);
      DAQ_writeVar(NUM_ENABLED_X_RECEIVERS, d->numCols);
      DAQ_writeVar(NUM_ENABLED_Y_RECEIVERS, d->numRows);
      DAQ_writeArray(X_RECEIVER_OFFSET, d->imageRxes, MAX_RX);
      DAQ_writeArray(Y_RECEIVER_OFFSET, d->imageTxes, MAX_TX);
    }

    /* Setup transmitter */
    {
    }

    /* Setup reference channel */
    {
      DAQ_writeVar(REF_FB_CAP_TRANS_VAL, d->imageRefRcvrFbCap);
      DAQ_writeVar(REF_HI_CAP_SEL_TRANS_VAL, d->imageRefHiTransCap);
      DAQ_writeVar(REF_LO_CAP_SEL_TRANS_VAL, d->imageRefLoTransCap);
      DAQ_writeVar(REF_HI_XMTR_PL_VAL, d->refHiXmtrPl);
      DAQ_writeVar(REF_LO_XMTR_PL_VAL, d->refLoXmtrPl);
    }

    /* Setup global CBC */
    {
      DAQ_writeVar(CBC_GLOBAL_PL_TRANS_VAL, d->globalCbcTransPl);            // F54_ANALOG_CTRL243(00)/00
      DAQ_writeVar(CBC_GLOBAL_CNVYR_EN_TRANS_VAL, d->globalCbcTransEnable);  // F54_ANALOG_CTRL243(00)/01
      DAQ_writeVar(CBC_GLOBAL_GAIN_TRANS_VAL, d->globalCbcTransGain);        // F54_ANALOG_CTRL243(00)/02
      DAQ_writeVar(CBC_GLOBAL_CAP_TRANS_VAL, d->globalCbcTransValue);        // F54_ANALOG_CTRL243(00)/03
      if (d->globalCbcTransEnable)
      {
        DAQ_writeArray(CBC_GLOBAL_OUT_EN15_0_TRANS_VAL, gcbc_on, 3);
      }
      else
      {
        DAQ_writeArray(CBC_GLOBAL_OUT_EN15_0_TRANS_VAL, gcbc_off, 3);
      }
    }

    /* Setup local CBC */
    {
      uint16 trans[MAX_RX];
      uint16 i, ofst;

      memset(trans, 0, LEN(trans)*sizeof(trans[0]));
      for (i = 0; i < d->numCols; i++)
      {
        uint16 index = d->imageRxes[i];
        ofst = 2 - index % 3;
        trans[(index/3)*3+ofst] = d->imageCbcs[i];
      }

      DAQ_writeArray(CBC_LOCAL_CH2_TRANS_VAL, trans, LEN(trans));
      DAQ_writeVar(CBC_LOCAL_REFLO_TRANS_VAL, d->refLoLocalCbcTransValue);     // F54_ANALOG_CTRL244(00)/00
      DAQ_writeVar(CBC_LOCAL_REFHI_TRANS_VAL, d->refHiLocalCbcTransValue);     // F54_ANALOG_CTRL244(00)/01
      DAQ_writeVar(CBC_XMTR_ON_CNT_TRANS_VAL, d->cbcTxOnCnt);
      DAQ_writeVar(CBC_RCVR_CONNECT_ON_CNT_TRANS_VAL, d->cbcRxOnCnt);
    }

    /* Setup noise measurement */
    {
      DAQ_writeVar(NOISE_BURSTS, d->noiseBursts);
      DAQ_writeVar(RCVROFST_ENABLED, 0);
      DAQ_writeVar(FREQSCAN_ENABLED, 0);
      if (CONFIG_HAS_SCANNERDRIVE)
      {
        DAQ_writeVar(FREQSCAN_BURSTS, d->noiseBursts);
      }
      else
      {
        DAQ_writeVar(FREQSCAN_BURSTS, d->noiseScanBursts);
      }
    }

    /* Setup guard ring */
    {
      DAQ_writeVar(TX_GUARD_SEL_15_0_TRANS_VAL, 0x0);
      DAQ_writeVar(TX_GUARD_SEL_19_16_TRANS_VAL, 0x0);
      DAQ_writeVar(TX_GND_SEL_15_0_TRANS_VAL, 0x0);
      DAQ_writeVar(TX_GND_SEL_19_16_TRANS_VAL, 0x0);
      DAQ_writeVar(VREF_DAC_EN_TRANS_VAL, 0x0);
      DAQ_writeVar(GUARD_AMP_EN_TRANS_VAL, 0x0);

      if (d->guardRingPin != 0xFF)
      {
        DAQ_writeVar(VREF_DAC_EN_TRANS_VAL, 0x1);
        DAQ_writeVar(GUARD_AMP_EN_TRANS_VAL, 0x1);
        if (d->guardRingPin <= 15)
        {
          uint16 mask = 0x1 << d->guardRingPin;
          DAQ_writeVar(TX_GUARD_SEL_15_0_TRANS_VAL, mask);
          DAQ_writeVar(TX_GND_SEL_15_0_TRANS_VAL, ~mask);
          DAQ_writeVar(TX_GND_SEL_19_16_TRANS_VAL, 0xF);
        }
        else
        {
          uint16 mask = (0x1 << (d->guardRingPin - 16)) & 0xF;
          DAQ_writeVar(TX_GUARD_SEL_19_16_TRANS_VAL, mask);
          DAQ_writeVar(TX_GND_SEL_15_0_TRANS_VAL, 0xFF);
          DAQ_writeVar(TX_GND_SEL_19_16_TRANS_VAL, ~mask);
        }
      }
    }
  }

#if CONFIG_HAS_HYBRID
  /* Setup hybrid abs cap acquisition */
  {
    /* Setup miscellaneous variables */
    {
      DAQ_writeVar(ABSX_BURSTS_PER_CLUSTER, d->hybridXBursts); // F54_ANALOG_CTRL145(00)/00
      DAQ_writeVar(ABSY_BURSTS_PER_CLUSTER, d->hybridYBursts); // F54_ANALOG_CTRL145(00)/01
      DAQ_writeVar(DOZE_ABSY, d->txDoze);                      // F54_ANALOG_CTRL248 bit0
    }

    /* Setup sensing state machine */
    {
      DAQ_writeVar(FILT_BW_ABSX_VAL, d->hybridFiltBW);             // F54_ANALOG_CTRL146(00)/03
      DAQ_writeVar(FILT_BW_ABSY_VAL, d->hybridFiltBWTx);           // F54_ANALOG_CTRL146(01)/03
      DAQ_writeVar(BURST_SIZE_ABSX_VAL, d->hybridBurstSize1);      // F54_ANALOG_CTRL146(00)/05
      DAQ_writeVar(BURST_SIZE_ABSY_VAL, d->hybridBurstSize1Tx);    // F54_ANALOG_CTRL146(01)/05
      DAQ_writeVar(RSTRETCH_DUR_ABSX_VAL, d->hybridRstretchDur);   // F54_ANALOG_CTRL146(00)/04
      DAQ_writeVar(RSTRETCH_DUR_ABSY_VAL, d->hybridRstretchDurTx); // F54_ANALOG_CTRL146(01)/04
      bmConfig.rStretchX = d->hybridRstretchDur;
      bmConfig.rStretchY = d->hybridRstretchDurTx;
      bmConfig.deltaRStretch = d->hybridDeltaRstretchDur;
      bmConfig.threshold = d->hybridBMThreshold;
      bmConfig.consistency = d->hybridBMConsistency;
      bmConfig.enabled = d->hybridFrequencyHoppingEnable;
      bmParam.counter = 0;
      bmParam.alternate = 0;
      bmParam.initialized = 0;

      DAQ_writeVar(INTEG_DUR_ABSX_VAL, d->hybridIntegDur);   // F54_ANALOG_CTRL146(00)/00
      DAQ_writeVar(INTEG_DUR_ABSY_VAL, d->hybridIntegDurTx); // F54_ANALOG_CTRL146(01)/00
      DAQ_writeVar(RESET_DUR_ABSX_VAL, d->hybridResetDur);   // F54_ANALOG_CTRL146(00)/02
      DAQ_writeVar(RESET_DUR_ABSY_VAL, d->hybridResetDurTx); // F54_ANALOG_CTRL146(01)/02

      DAQ_writeVar(TRIG_DELAY_DUR_ABSX_VAL, d->hybridTriggerDelayRx);     // F54_ANALOG_CTRL247(01)/00
      DAQ_writeVar(TRIG_DELAY_DUR_ABSY_VAL, d->hybridTriggerDelayTx);     // F54_ANALOG_CTRL247(02)/00
      DAQ_writeVar(TRIG_HOLDOFF_DUR_ABSX_VAL, d->hybridTriggerHoldoffRx); // F54_ANALOG_CTRL247(01)/01
      DAQ_writeVar(TRIG_HOLDOFF_DUR_ABSY_VAL, d->hybridTriggerHoldoffTx); // F54_ANALOG_CTRL247(02)/01

      // note F54_ANALOG_CTRL146(00)/9-12 and F54_ANALOG_CTRL146(01)/9-12 are not used.
    }

    /* Setup DAC */
    {
      DAQ_writeVar(DAC_IN_ABSX_VAL, d->dac_in_absx);
      DAQ_writeVar(DAC_IN_ABSY_VAL, d->dac_in_absy);
    }

    /* Setup receiver */
    {
      DAQ_writeVar(RCVR_FB_CAP_ABSX_VAL, d->hybridXRcvrFbCap);          // F54_ANALOG_CTRL143(00)/02
      DAQ_writeVar(RCVR_FB_CAP_ABSY_VAL, d->hybridYRcvrFbCap);          // F54_ANALOG_CTRL144(00)/02
      DAQ_writeVar(RCVR_FB_CAP_CFB1_ABSX_VAL, d->hybridXSubtractFbCap); // F54_ANALOG_CTRL143(00)/03
      DAQ_writeVar(RCVR_FB_CAP_CFB1_ABSY_VAL, d->hybridYSubtractFbCap); // F54_ANALOG_CTRL144(00)/03
      DAQ_writeVar(REF_FB_CAP_CFB1_ABSX_VAL, d->hybridXSubtractFbCap);  // F54_ANALOG_CTRL143(00)/03
      DAQ_writeVar(REF_FB_CAP_CFB1_ABSY_VAL, d->hybridYSubtractFbCap);  // F54_ANALOG_CTRL144(00)/03
    }

    /* Setup reference channel */
    {
      DAQ_writeVar(REF_FB_CAP_ABSX_VAL, d->hybridXRefRcvrFbCap);    // F54_ANALOG_CTRL143(00)/08
      DAQ_writeVar(REF_FB_CAP_ABSY_VAL, d->hybridYRefRcvrFbCap);    // F54_ANALOG_CTRL144(00)/08
      DAQ_writeVar(REF_HI_CAP_SEL_ABSX_VAL, d->hybridXRefHiAbsCap); // F54_ANALOG_CTRL143(00)/05
      DAQ_writeVar(REF_HI_CAP_SEL_ABSY_VAL, d->hybridYRefHiAbsCap); // F54_ANALOG_CTRL144(00)/05
      DAQ_writeVar(REF_LO_CAP_SEL_ABSX_VAL, d->hybridXRefLoAbsCap); // F54_ANALOG_CTRL143(00)/04
      DAQ_writeVar(REF_LO_CAP_SEL_ABSY_VAL, d->hybridYRefLoAbsCap); // F54_ANALOG_CTRL144(00)/04
    }

    /* Setup global CBC */
    {
      DAQ_writeVar(CBC_GLOBAL_PL_ABSX_VAL, d->globalCbcRxPl);           // F54_ANALOG_CTRL243(01)/00
      DAQ_writeVar(CBC_GLOBAL_CNVYR_EN_ABSX_VAL, d->globalCbcRxEnable); // F54_ANALOG_CTRL243(01)/01
      DAQ_writeVar(CBC_GLOBAL_GAIN_ABSX_VAL, d->globalCbcRxGain);       // F54_ANALOG_CTRL243(01)/02
      DAQ_writeVar(CBC_GLOBAL_CAP_ABSX_VAL, d->globalCbcRxValue);       // F54_ANALOG_CTRL243(01)/03
      if (d->globalCbcRxEnable)
      {
        DAQ_writeArray(CBC_GLOBAL_OUT_EN15_0_ABSX_VAL, gcbc_on, 3);
      }
      else
      {
        DAQ_writeArray(CBC_GLOBAL_OUT_EN15_0_ABSX_VAL, gcbc_off, 3);
      }

      DAQ_writeVar(CBC_GLOBAL_PL_ABSY_VAL, d->globalCbcTxPl);           // F54_ANALOG_CTRL243(02)/00
      DAQ_writeVar(CBC_GLOBAL_CNVYR_EN_ABSY_VAL, d->globalCbcTxEnable); // F54_ANALOG_CTRL243(02)/01
      DAQ_writeVar(CBC_GLOBAL_GAIN_ABSY_VAL, d->globalCbcTxGain);       // F54_ANALOG_CTRL243(02)/02
      DAQ_writeVar(CBC_GLOBAL_CAP_ABSY_VAL, d->globalCbcTxValue);       // F54_ANALOG_CTRL243(02)/03
      if (d->globalCbcTxEnable)
      {
        DAQ_writeArray(CBC_GLOBAL_OUT_EN15_0_ABSY_VAL, gcbc_on, 3);
      }
      else
      {
        DAQ_writeArray(CBC_GLOBAL_OUT_EN15_0_ABSY_VAL, gcbc_off, 3);
      }
    }

    /* Setup local CBC */
    {
      DAQ_writeVar(CBC_LOCAL_REFLO_ABSX_VAL, d->refLoLocalCbcRxValue); // F54_ANALOG_CTRL244(01)/00
      DAQ_writeVar(CBC_LOCAL_REFHI_ABSX_VAL, d->refHiLocalCbcRxValue); // F54_ANALOG_CTRL244(01)/01
      DAQ_writeVar(CBC_LOCAL_REFLO_ABSY_VAL, d->refLoLocalCbcTxValue); // F54_ANALOG_CTRL244(02)/00
      DAQ_writeVar(CBC_LOCAL_REFHI_ABSY_VAL, d->refHiLocalCbcTxValue); // F54_ANALOG_CTRL244(02)/01
      DAQ_writeVar(CBC_XMTR_ON_CNT_ABSX_VAL, d->cbcRxTxOnCnt);
      DAQ_writeVar(CBC_XMTR_ON_CNT_ABSY_VAL, d->cbcTxTxOnCnt);
      DAQ_writeVar(CBC_RCVR_CONNECT_ON_CNT_ABSX_VAL, d->cbcRxRxConnectOnCnt);
      DAQ_writeVar(CBC_RCVR_CONNECT_ON_CNT_ABSY_VAL, d->cbcTxRxConnectOnCnt);
    }

    /* Setup local CBC */
    {
      uint16 absx[MAX_CH_COUNT];
      uint16 absy[MAX_CH_COUNT];
      uint16 i, ofst;
      memset(absx, 0, LEN(absx)*sizeof(absx[0]));
      memset(absy, 0, LEN(absy)*sizeof(absy[0]));
      for (i = 0; i < d->numCols; i++)
      {
        uint16 index = d->imageRxes[i];
        ofst = 2 - index % 3;
        absx[(index/3)*3+ofst] = d->absCbcs[i];
      }
      for (i = 0; i < d->numRows; i++)
      {
        uint16 index = d->imageTxes[i];
        ofst = 2 - index % 3;
        absy[(index/3)*3+ofst] = d->absCbcs[MAX_RX+i];
      }

      DAQ_writeArray(CBC_LOCAL_CH2_ABSX_VAL, absx, LEN(absx));
      DAQ_writeArray(CBC_LOCAL_CH2_ABSY_VAL, absy, LEN(absy));
    }
  #if CONFIG_HIC_LPWG_MODE_B
    /* Setup SOUT/TOUT */
    {
      DAQ_writeVar(TCH_LPWG_L_SOUT_CTRL0_VAL, CONFIG_TCH_LPWG_L_SOUT_CTRL0);
      DAQ_writeVar(TCH_LPWG_L_SOUT_CTRL1_VAL, CONFIG_TCH_LPWG_L_SOUT_CTRL1);
      DAQ_writeVar(TCH_LPWG_L_SOUT_CTRL2_VAL, CONFIG_TCH_LPWG_L_SOUT_CTRL2);
      DAQ_writeVar(TCH_LPWG_L_MISC_CTRL_VAL,  CONFIG_TCH_LPWG_L_MISC_CTRL);

      DAQ_writeVar(TCH_LPWG_H_SOUT_CTRL0_VAL, CONFIG_TCH_LPWG_H_SOUT_CTRL0);
      DAQ_writeVar(TCH_LPWG_H_SOUT_CTRL1_VAL, CONFIG_TCH_LPWG_H_SOUT_CTRL1);
      DAQ_writeVar(TCH_LPWG_H_SOUT_CTRL2_VAL, CONFIG_TCH_LPWG_H_SOUT_CTRL2);
      DAQ_writeVar(TCH_LPWG_H_MISC_CTRL_VAL,  CONFIG_TCH_LPWG_H_MISC_CTRL);
    }
  #endif
  }
#endif

#if CONFIG_TDDI_AMP_BUTTONS
  /* Setup 0D buttons */
  {
    /* Setup sensing state machine */
    {
      DAQ_writeVar(INTEG_DUR_TRANS0D_VAL, d->imageIntegDur); // same as 2D
      DAQ_writeVar(RESET_DUR_TRANS0D_VAL, d->imageResetDur); // same as 2D
      DAQ_writeVar(TRIG_DELAY_DUR_TRANS0D_VAL, d->transTriggerDelay0D);     // F54_ANALOG_CTRL247(03)/00
      DAQ_writeVar(TRIG_HOLDOFF_DUR_TRANS0D_VAL, d->transTriggerHoldoff0D); // F54_ANALOG_CTRL247(03)/01
    }

    /* Setup DAC */
    {
      DAQ_writeVar(DAC_IN_TRANS0D_VAL, d->dac_in_0d); // F54_ANALOG_CTRL245(02)/00
    }

    /* Setup receiver */
    {
      uint16 rxes[1];
      indicesToBitmasks(d->buttonRxes, MAX_BUTTONS, rxes, LEN(rxes));
      DAQ_writeVar(RX_0D_AFE_SEL_TRANS0D_VAL, rxes[0]);
      DAQ_writeVar(RX_0D_GND_SEL_TRANS0D_VAL, ~rxes[0] & 0x3F);
      DAQ_writeVar(NUM_ENABLED_B_RECEIVERS, d->numButtons);
      DAQ_writeArray(B_RECEIVER_OFFSET, d->buttonRxes, MAX_BUTTONS);
      DAQ_writeVar(RCVR_FB_CAP_TRANS0D_VAL, d->imageRcvrFbCap); // same as 2D
    }

    /* Setup transmitter */
    {
      uint16 txes[1];
      indicesToBitmasks(d->buttonTxes, MAX_BUTTONS, txes, LEN(txes));
      DAQ_writeVar(TX_0D_CARRIER_SEL_TRANS0D_VAL, txes[0]);
      DAQ_writeVar(TX_0D_EN_TRANS0D_VAL, txes[0]);
      DAQ_writeVar(TX_0D_OUT_SEL_1_0_TRANS0D_VAL, txes[0]);
    }

    /* Setup reference channel */
    {
      DAQ_writeVar(REF_HI_CAP_SEL_TRANS0D_VAL, d->buttonRefHiCap); // F54_ANALOG_CTRL235(00)/00
      DAQ_writeVar(REF_LO_CAP_SEL_TRANS0D_VAL, d->buttonRefLoCap); // F54_ANALOG_CTRL235(00)/01
      DAQ_writeVar(REF_FB_CAP_TRANS0D_VAL, d->imageRefRcvrFbCap);  // same as 2D
    }

    /* Setup global CBC */
    {
      DAQ_writeVar(CBC_GLOBAL_PL_TRANS0D_VAL, d->globalCbc0DPl);           // F54_ANALOG_CTRL243(03)/00
      DAQ_writeVar(CBC_GLOBAL_CNVYR_EN_TRANS0D_VAL, d->globalCbc0DEnable); // F54_ANALOG_CTRL243(03)/01
      DAQ_writeVar(CBC_GLOBAL_GAIN_TRANS0D_VAL, d->globalCbc0DGain);       // F54_ANALOG_CTRL243(03)/02
      DAQ_writeVar(CBC_GLOBAL_CAP_TRANS0D_VAL, d->globalCbc0DValue);       // F54_ANALOG_CTRL243(03)/03
      if (d->globalCbc0DEnable)
      {
        DAQ_writeArray(CBC_GLOBAL_OUT_EN15_0_TRANS0D_VAL, gcbc_on, 3);
      }
      else
      {
        DAQ_writeArray(CBC_GLOBAL_OUT_EN15_0_TRANS0D_VAL, gcbc_off, 3);
      }
    }

    /* Setup local CBC */
    {
      uint16 lcbc[MAX_BUTTONS];
      uint16 i, ofst;

      for (i = 0; i < MAX_BUTTONS; i++)
      {
        ofst = 2 - i % 3;
        lcbc[(i/3)*3+ofst] = d->buttonLocalCbcs[d->buttonRxes[i]];
      }
      DAQ_writeArray(CBC_LOCAL_CH32_TRANS0D_VAL, lcbc, LEN(lcbc));
      DAQ_writeVar(CBC_LOCAL_REFLO_TRANS0D_VAL, d->refLoLocalCbcTrans0DValue); // F54_ANALOG_CTRL244(03)/00
      DAQ_writeVar(CBC_LOCAL_REFHI_TRANS0D_VAL, d->refHiLocalCbcTrans0DValue); // F54_ANALOG_CTRL244(03)/01
      DAQ_writeVar(CBC_XMTR_ON_CNT_TRANS0D_VAL, d->cbcTxOnCnt);                // same timing as 2D
      DAQ_writeVar(CBC_RCVR_CONNECT_ON_CNT_TRANS0D_VAL, d->cbcRxOnCnt);        // same timing as 2D
    }
  }
#endif

  if (COMM_getPsmState() != 6 && COMM_getPsmState() != 1)
  {
    selectTimingTableActive(d->lhbReportRate60Hz, 1);
    DAQ_startContinuousAcquisition(0);
    throwAwayDummyFrame();
  }

#if CONFIG_NSM
  {
    nsm_params_t np;
    uint16 mask;

#if CONFIG_NSM_CALLISTO
    uint16 *halfSensingPeriodPtr = np.halfSensingPeriod;
    uint16 sample_dur = DAQ_readVar(BASE_SAMPLE_DUR);
#endif

    np.powerimHighThresh = d->powerimHighThresh;
    np.powerimLowThresh = d->powerimLowThresh;
    np.powerimFnmHighThresh = d->powerimFnmHighThresh;

#if CONFIG_NSM_EUROPA
    np.fsim120Thresh        = d->fsimThresh;
    np.fsim60Thresh         = d->fsimThresh;
#else
    np.fsimThresh = d->fsimThresh;
#endif

    np.railimHighThresh = d->railimHighThresh;
    np.railimLowThresh = d->railimLowThresh;
    np.cidimHighThresh = d->cidimHighThresh;
    np.cidimLowThresh = d->cidimLowThresh;
    np.fsFnmDensity = d->fsFnmDensity;
    np.fnmTimeout = d->fnmTimeout;
    np.fsTimeout = d->fsTimeout;
    np.hnm60Timeout         = d->hnmRateShiftFrameCount;
    np.enableMultiFrameIM = 1;

#if CONFIG_NSM_CALLISTO
    np.varcidimHighThresh = d->varcidimHighThresh;
    np.varcidimLowThresh = d->varcidimLowThresh;
    np.holdoffTimeout = d->holdoffTimeout;
#endif

    np.dynamicSensingRate = d->dynamicSensingRate;

    np.inhibitFrequencyShift = d->inhibitFrequencyShift;
    np.noNoiseMitigation = d->noNoiseMitigation;
    np.disableFreq = 0;
    for (i = 0, mask = 1; i < MAX_FREQUENCIES; i++, mask <<= 1)
    {
#if CONFIG_NSM_CALLISTO
      *(halfSensingPeriodPtr++) = 3 + sample_dur +
        d->imageIntegDur + d->imageResetDur +
        d->freqTable.stretchDur[i] + d->freqTable.rstretchDur[i];
#endif
      if (d->freqTable.disableFreq[i])
        np.disableFreq |= mask;
    }

#if CONFIG_NSM_EUROPA
  np.transitionFrameCount = d->transitionFrameCount;
#endif

    np.enableChargerBit = 1;//Set: enable charger bit control

    // FWTDDI-2313: to avoid calling Rx offset measure and frequency scan during display
    // is off, which causes watchdog timeout.
    // Note HIC has external touch-only reset pin, thus touch reset can happen anytime.
    // PL_init() will be revisited and nsm_init() will be called when calc thread receives
    // sleep out command.
    if (COMM_getPsmState() != 6 && COMM_getPsmState() != 1)
    {
      nsm_init(&np);
      nsm_init_done = 1;
    }
  }
#endif

#if CONFIG_HAS_0D_BUTTONS
  initDoze(&scfg->dozeParams, d->imageTxes, d->numRows, d->buttonTxes, d->numButtons);
#else
  initDoze(&scfg->dozeParams, d->imageTxes, d->numRows, (uint16 *) NULL, d->numButtons);
#endif

#if CONFIG_HIC_LPWG_MODE_B
  initLpwgModeB(&scfg->lpwgModeBParams);
#endif

  /* Saves common production test parameters */
  pp.numRows = d->numRows;
  pp.numCols = d->numCols;
  pp.numBtns = d->numButtons;
  for (i = 0; i < MAX_RX; i++)
  {
    pp.imageRxes[i] = d->imageRxes[i];
  }
  for (i = 0; i < MAX_TX; i++)
  {
    pp.imageTxes[i] = d->imageTxes[i];
  }
  for (i = 0; i < MAX_PHY_RX; i++)
  {
    pp.imageCbcs[i] = d->imageCbcs[i];
  }

#if CONFIG_HAS_0D_BUTTONS
  pp.btnAbsTransMode = d->buttonAbsTransMode;
  pp.btnGlobalCbc = d->buttonGlobalCbc;
  for(i = 0; i < MAX_BUTTONS; i++)
  {
    pp.btnRxes[i] = d->buttonRxes[i];
    if (d->buttonTxes[i] != 0xff && d->buttonRxes[i] != 0xff)
      pp.btnTxRxMask |= (1 << i);
    pp.btnLocalCbcs[i] = d->buttonLocalCbcs[i];
  }
#endif

#if CONFIG_HAS_ESD_RECOVERY
  ESDCVItimeoutMax = 5;
  NumCVItimeouts = 0;
#endif

  /* Starts acquisition */
  enableActiveFrame();
  PL_enterMode(mode_active);
}

void PlatformApi_Tddi_Hic::PL_enterMode(PLMode_t newMode)
{
  PLMode_t oldMode = mode;
  uint16 trig;
  if (newMode == oldMode) return;

  // turn on the new mode
  DAQ_stopAcquisition();
  switch(newMode)
  {
  case mode_active:
    selectTimingTableActive(was_60hz, 0); // skip wait, as it causes 1 frame latency
    DAQ_startContinuousAcquisition(0);
    break;
  case mode_doze:
    selectTimingTableDoze(1);
    DAQ_startContinuousAcquisition(1);
    break;
  case mode_deepSleep:
    DAQ_startContinuousAcquisition(2);
    break;
#if CONFIG_HIC_LPWG_MODE_B
  case mode_modeB_lpwg:
    DAQ_startContinuousAcquisition(4);
    break;
  case mode_modeB_trgt:
    DAQ_startContinuousAcquisition(5);
    break;
  case mode_modeB_display_refresh:
    DAQ_startContinuousAcquisition(6);
    break;
#endif
  case mode_cbcScan:
    trig = DAQ_readVar(CURRENT_TRIGGER_MODE);
    if (trig == 0) //LHB
      selectTimingTableCbcScan(1);
    DAQ_startContinuousAcquisition(FTYPE_CBCSCAN_HYBRID);
    break;
  case mode_idle:
  default:
    break;
  }
  mode = newMode;
}

PLFrame_t* PlatformApi_Tddi_Hic::PL_getFrame(PLFrameType_t frameType)
{
  PLFrame_t *plFrame;
  DAQFrame_t *daqFrame;
  int16 daqFrameType = 0;
  PLMode_t oldMode = mode;
  if (lastFrame != NULL)
  {
    DAQ_releaseFrame(lastFrame);
    lastFrame = (DAQFrame_t*) (NULL); // Padma: Had to typecast NULL to avaoid compilation errors. Defined as (void*) in stddef.h
  }

  switch(frameType)
  {
  case frame_active:
    if (mode != mode_active)
      PL_enterMode(mode_active);
    daqFrameType = FTYPE_TRANS;
    break;
  case frame_doze:
    if (mode != mode_doze)
      PL_enterMode(mode_doze);
    daqFrameType = FTYPE_DOZE;
    break;
  case frame_deepsleep:
    if (mode != mode_deepSleep)
      PL_enterMode(mode_deepSleep);
    daqFrameType = FTYPE_DEEPSLEEP;
    break;
#if CONFIG_HIC_LPWG_MODE_B
  case frame_modeB_lpwg:
    if (mode != mode_modeB_lpwg)
      PL_enterMode(mode_modeB_lpwg);
    daqFrameType =  FTYPE_MODEB_LPWG;
    discardActiveFrameCounter = 1;
    break;
  case frame_modeB_trgt:
    if (mode != mode_modeB_trgt)
      PL_enterMode(mode_modeB_trgt);
    daqFrameType = FTYPE_MODEB_TRGT;
    discardActiveFrameCounter = 1;
    break;
  case frame_modeB_display_refresh:
    if (mode != mode_modeB_display_refresh)
      PL_enterMode(mode_modeB_display_refresh);
    daqFrameType = FTYPE_MODEB_DISPLAY_REFRESH;
    discardActiveFrameCounter = 1;
    break;
#endif
  case frame_cbcscan_hybrid:
    if (mode != mode_cbcScan)
      PL_enterMode(mode_cbcScan);
    daqFrameType = FTYPE_CBCSCAN_HYBRID;
    break;
  default:
    break;
  }

  // do any variable writes or mode switches necessary to set up this
  // frame (currently none).

  flags.resetDoze = 0;
  while(1)
  {
    daqFrame = DAQ_getFrame(daqFrameType);
    if (daqFrameType == FTYPE_TRANS && discardActiveFrameCounter > 0)
    {
      DAQ_releaseFrame(daqFrame);
      discardActiveFrameCounter--;
      continue;
    }

    // check for CVI timeouts, other actionable errors here
    #if CONFIG_HAS_TDDI_ESD_DETECTOR
    #if CONFIG_HAS_TDDI_ESD_CVITIMEOUT_CHECK
    esd_detector(daqFrame->errorFlags.cviTimeout);
    #else
    esd_detector();
    #endif
    #endif
    #if CONFIG_HAS_TDDI_ESD_HANDLER
    esd_handler();
    #endif

    // decode the frame
    plFrame = (PLFrame_t *)daqFrame;

#if CONFIG_HIC_LWPG_MODE_B
    // TODO: frame_doze doesn't do any error checking...remove these checks
    if (frameType == frame_modeB_lpwg)
    {
      daqErrorFlags_t daqError;
      daqError.all = plFrame->errorFlags;
      if (daqError.cviTimeout)
      {
        DAQ_releaseFrame(daqFrame);
        continue;
      }
    }

    if (frameType == frame_modeB_trgt)
    {
      daqErrorFlags_t daqError;
      daqError.all = plFrame->errorFlags;
      if (daqError.cviTimeout)
      {
        DAQ_releaseFrame(daqFrame);
        continue;
      }
    }

    if (frameType == frame_modeB_display_refresh)
    {
      // No error checking since the display refresh duration is handled
      // by using the CVITIMEOUT
    }
#endif

#if CONFIG_LOCAL_CBCSCAN_HYBRID || CONFIG_GLOBAL_CBCSCAN_HYBRID
    if (frameType == frame_cbcscan_hybrid)
    {
      daqErrorFlags_t daqError;
      daqError.all = plFrame->errorFlags;
      if (daqError.cviTimeout)
      {
        DAQ_releaseFrame(daqFrame);
        continue;
      }
    }
#endif

    if (frameType == frame_active)
    {
      daqErrorFlags_t daqError;
      daqError.all = plFrame->errorFlags;
      if (daqError.cviTimeout)
      {
        // Video thread on receiving a event_SLEEP_IN() will halt the DDIC
        // so we will always get daqError.cviTimeout set
        if (COMM_getEnterDeepSleep())
        {
          // Caller must recognize a NULL frame pointer being returned.
          DAQ_releaseFrame(daqFrame);
          return (PLFrame_t *)NULL;
        }

        #if CONFIG_HAS_ESD_RECOVERY && !defined(WIN32)
        // check for CVI timeouts to detect ESD
        if (NumCVItimeouts >= ESDCVItimeoutMax)
        {
           COMM_wakeupVideoThread(); //enable videothread
        }
        else
        {
           NumCVItimeouts++;
        }
        #endif

        DAQ_releaseFrame(daqFrame);
        continue;
      }

    #if CONFIG_HAS_ESD_RECOVERY
      // No CVI timeouts. Clear the counter
      NumCVItimeouts = 0;
    #endif

    #if CONFIG_NSM
      nsm_evalNSM(flags.disableNoiseMitigation, daqFrame);
      {
        nsm_statevars_t v = nsm_getStatevars();
        if (v.frequencyShift)
          flags.resetDoze = 1;

        if (v.abortFrame)
        {
          DAQ_releaseFrame(daqFrame);
          continue;
        }

        if (v.rateShift)
        {
          PL_setCurrentRate(v.currentRate);
        }
      }

      if (CONFIG_HAS_HYBRID_FREQ_HOPPING && !flags.disableNoiseMitigation && bmConfig.enabled)
      {
        calculateBurstSpanMetric(plFrame->data.hybridY, pp.numRows);
        if (bmConfig.threshold < bmParam.bm)
        {
          bmParam.counter++;
          if (bmConfig.consistency < bmParam.counter)
          {
            bmParam.counter = 0;
            bmParam.initialized = 0;
            if (!bmParam.alternate)
            {
              DAQ_writeVar(RSTRETCH_DUR_ABSX_VAL, bmConfig.rStretchX + bmConfig.deltaRStretch); // F54_ANALOG_CTRL146(01)/04
              DAQ_writeVar(RSTRETCH_DUR_ABSY_VAL, bmConfig.rStretchY + bmConfig.deltaRStretch); // F54_ANALOG_CTRL146(01)/04
              bmParam.alternate = 1;
            }
            else
            {
              DAQ_writeVar(RSTRETCH_DUR_ABSX_VAL, bmConfig.rStretchX); // F54_ANALOG_CTRL146(01)/04
              DAQ_writeVar(RSTRETCH_DUR_ABSY_VAL, bmConfig.rStretchY); // F54_ANALOG_CTRL146(01)/04
              bmParam.alternate = 0;
            }
          }
        }
        else
        {
          bmParam.counter = 0;
        }
      }
    #endif
    }
    break; // keep the frame if we made it this far
  }

  if (oldMode != mode)
  {
    PL_enterMode(oldMode);
  }

  // turn off special modes (none currently needed)

  plFrame->type = frameType;

  lastFrame = daqFrame;
  return plFrame;
}

void PlatformApi_Tddi_Hic::PL_releaseFrame(PLFrame_t *f)
{
  DAQ_releaseFrame((DAQFrame_t *) f);
  lastFrame = (DAQFrame_t*) (NULL); // Padma: Had to typecast NULL to avaoid compilation errors. Defined as (void*) in stddef.h
}

uint16 PlatformApi_Tddi_Hic::PL_isNSMInitialized()
{
  return nsm_init_done;
}

PLNSMState_t PlatformApi_Tddi_Hic::PL_getNSMState()
{
  PLNSMState_t nsmState;
#if CONFIG_NSM
  nsm_ims_t ims = nsm_getIms();
  nsm_statevars_t state = nsm_getStatevars();
  nsmState.powerIM = ims.powerim;
  nsmState.cidIM = ims.cidim;
  nsmState.railIM = ims.railim;
  nsmState.state = state.currentState;
  nsmState.frequency = state.currentFreq;
#if CONFIG_NSM_CALLISTO
  nsmState.varCidIM = ims.varcidim;
#endif
#if CONFIG_NSM_EUROPA
  nsmState.frameRate = state.currentRate;
  nsmState.frequencyTranState = state.frequencyTranState;
  nsmState.compLevel = (state.compLevel >= WITH_HIGH_BASELINE_COMPENSATATION);
#endif
#endif
  return nsmState;
}

uint16 PlatformApi_Tddi_Hic::PL_getNSMTransClusters()
{
  return DAQ_readVar(NUM_TRANS_CLUSTERS);
}

uint16 PlatformApi_Tddi_Hic::PL_getNSMNoiseBursts()
{
  return DAQ_readVar(NOISE_BURSTS);
}

uint16 PlatformApi_Tddi_Hic::PL_getNSMFreqScanBursts()
{
  return DAQ_readVar(FREQSCAN_BURSTS);
}

void PlatformApi_Tddi_Hic::PL_convertDozeFrameToRawCap(PLFrameData_t *frame ATTR_UNUSED, PLCapData_t *cap ATTR_UNUSED)
{
  uint16 i;
  for (i = 0; i < MAX_RX; i++)
    cap->hybridX[i] = frame->hybridX[i];
  convertHybridToRawCapacitance(&cap->hybridX[0], pp.numCols, conversionType_absx);
}

void PlatformApi_Tddi_Hic::PL_convertActiveFrameToRawCap(PLFrameData_t *frame , PLCapData_t *cap)
{
  uint16 i;

  if (!disable_sense_trans)
  {
    memcpy(&cap->image[0], &frame->image[0], MAX_TX*MAX_RX*sizeof(frame->image[0]));
    convertImageToRawCapacitance(&cap->image[0]);
  }

  if (CONFIG_HAS_HYBRID*(!disable_sense_absx))
  {
    for (i = 0; i < MAX_RX; i++)
      cap->hybridX[i] = frame->hybridX[i];
    convertHybridToRawCapacitance(&cap->hybridX[0], pp.numCols, conversionType_absx);
  }

  if (CONFIG_HAS_HYBRID*(!disable_sense_absy))
  {
    for (i = 0; i < MAX_TX; i++)
      cap->hybridY[i] = frame->hybridY[i];
    convertHybridToRawCapacitance(&cap->hybridY[0], pp.numRows, conversionType_absy);
  }

  if (CONFIG_TDDI_AMP_BUTTONS*(!disable_sense_0d))
  {
    memcpy(&cap->image[pp.numRows*MAX_RX], &frame->buttons[0], pp.numBtns*sizeof(frame->buttons[0]));
    convertButtonsToRawCapacitance(&cap->image[pp.numRows*MAX_RX]);
  }
}

void PlatformApi_Tddi_Hic::PL_convertActiveFrameToDeltaCap(PLFrameData_t *frame, PLCapData_t *cap)
{
  uint16 i;

  if (!disable_sense_trans)
  {
    memcpy(&cap->image[0], &frame->image[0], MAX_TX*MAX_RX*sizeof(frame->image[0]));
    convertImageToDeltaCapacitance((int16*)cap->image);
  }

  if (CONFIG_HAS_HYBRID*(!disable_sense_absx))
  {
    for (i = 0; i < MAX_RX; i++)
      cap->hybridX[i] = (int32)((int16)frame->hybridX[i]);
    convertHybridToDeltaCapacitance((int32*)&cap->hybridX[0], pp.numCols, conversionType_absx);
  }

  if (CONFIG_HAS_HYBRID*(!disable_sense_absy))
  {
    for (i = 0; i < MAX_TX; i++)
      cap->hybridY[i] = (int32)((int16)frame->hybridY[i]);
    convertHybridToDeltaCapacitance((int32*)&cap->hybridY[0], pp.numRows, conversionType_absy);
  }

  if (CONFIG_TDDI_AMP_BUTTONS*(!disable_sense_0d))
  {
    memcpy(&cap->image[pp.numRows*MAX_RX], &frame->buttons[0], pp.numBtns*sizeof(frame->buttons[0]));
    convertButtonsToDeltaCapacitance((int16*)&cap->image[pp.numRows*MAX_RX]);
  }
}

void PlatformApi_Tddi_Hic::PL_getTestFrame(prodTestType_t test, struct calcStaticConfig_t *scfg,
                     struct calcDynamicConfig_t *dcfg ATTR_UNUSED, prodTestResult_t *result)
{
  // Production tests here are allowed to modify any DAQ variables
  // they want. The caller is responsible for reinitializing the
  // platform object after each test.

  PL_enterMode(mode_idle);

  if (lastFrame != NULL)
  {
    DAQ_releaseFrame(lastFrame);
    lastFrame = (DAQFrame_t*) (NULL); // Padma: Had to typecast NULL to avoid compilation errors. Defined as (void*) in stddef.h
  }

  switch(test)
  {
  case prodTestType_adcSaturation:
    doAdcSaturationTest(scfg,result);
    break;
  case prodTestType_fullRawCap:
    doFullRawCapTest(scfg,result);
    break;
  case prodTestType_hicRxRxShort:
    doRxRxShortTest(scfg,result);
    break;
  case prodTestType_hicTxTxShort:
    doTxTxShortTest(scfg,result);
    break;
  case prodTestType_sensorSpeed :
    doSensorSpeedTest(scfg, result);
    break;
  default:
    break;
  }
}

void PlatformApi_Tddi_Hic::PL_setParam(PLParam_t param_type, uint16 param_value)
{
  switch(param_type)
  {
    case PLFramePeriod:
        if (1<param_value)
        {
          DAQ_writeVar(ACTIVE_FRAME_PERIOD, param_value); // [FWTE-963] writing this makes baseline shift on tddi. Substituting DAQ_writeVar with DAQ_writeVarAsync doesn't make issue.
        }
        break;
#if CONFIG_NSM
    case PLDisableNSM:
        if (flags.disableNoiseMitigation != param_value)
        {
          flags.disableNoiseMitigation = param_value;
          enableActiveFrame();
        }
        break;
    case PLObjectPresent:
        flags.objectsPresent = param_value;
        if(flags.disableNoiseMitigation == 0)
        {
          nsm_reportObjects(param_value);
        }
        break;
    case PLChargerPresent:
        nsm_setChargerPresent(param_value);
        break;
    case PLFreqTransCounter:
        nsm_resetFreqTransition();
        break;
#endif
    case PLTouchSensingMode:
        if (param_value == LONG_H_BLANK_MODE)
          DAQ_writeVarAsync(CURRENT_TRIGGER_MODE, 0);
        else if (param_value == CONTINUE_MODE)
          DAQ_writeVarAsync(CURRENT_TRIGGER_MODE, 1);
        else if (param_value == LONG_V_BLANK_MODE)
          DAQ_writeVarAsync(CURRENT_TRIGGER_MODE, 0); // power state machine sets LVB for idle mode but HIC uses LHB always.
        break;
    case PLGestureDetected:
#if CONFIG_HIC_LPWG_MODE_B
        COMM_detectGesture(param_value);
#endif
        break;
  #if CONFIG_HAS_ALT_REPORT_RATE
    case PLAltReportRate:
        DAQ_writeVar(ALT_REPORT_RATE, param_value);
        break;
  #endif
    default:
        break;
  }
}

uint16 PlatformApi_Tddi_Hic::PL_isDozeTimerResetRequested()
{
  return flags.resetDoze;
}

void PlatformApi_Tddi_Hic::PL_copy0DToFrameBuffer(uint16 isAbsBtnData ATTR_UNUSED, uint16 *btnDataPtr, PLFrameData_t *frameBufferPtr)
{
  // To match TDDI production test format: DS5 read out [(MAX_TX*MAX_RX) + MAX_BUTTONS] for 2D and 0D data
  // Here we copy button data to frameBufferPtr->buttons, which means in PLFrameData_t,
  // buttons[] array should always be declared right after image[]

  memcpy(frameBufferPtr->buttons, btnDataPtr, MAX_BUTTONS*sizeof(frameBufferPtr->buttons[0]));
}

void PlatformApi_Tddi_Hic::PL_0DButtonsScaling(uint16 *btnDataPtr, uint16 *btnScaleFactor)
{
  uint16 i;

  for (i = 0; i < MAX_BUTTONS; i++)
  {
    btnDataPtr[i] /= btnScaleFactor[i];
  }
}

uint16 PlatformApi_Tddi_Hic::PL_isDozeWakeUpCondition(dozeParams_t *dozeConfig, int16 *deltaImage, uint16 size ATTR_UNUSED)
{
  // checks 2D
  if (maxAbs(&deltaImage[0], pp.numCols) > dozeConfig->dozeWakeUpThreshold) return 1;

  // checks 0D
  if (maxAbs(&deltaImage[MAX_PHY_RX], pp.numBtns) > dozeConfig->dozeWakeUpThreshold0D) return 1;

  return 0;
}

void PlatformApi_Tddi_Hic::PL_setupFreqScanFrame()
{
  DAQ_stopAcquisition();
  enableFrames(0, 0, 0, 0, 1, 0, 1);
}

void PlatformApi_Tddi_Hic::PL_disableFreqScanFrame()
{
  enableActiveFrame();
  DAQ_startContinuousAcquisition(0);
}

void PlatformApi_Tddi_Hic::PL_setupRcvrOffsetFrame()
{
  enableFrames(0, 0, 0, 0, 1, 1, 0);
}

void PlatformApi_Tddi_Hic::PL_disableRcvrOffsetFrame()
{
  enableActiveFrame();
}

PLFrame_t *PlatformApi_Tddi_Hic::PL_getRcvrOffsetFrame()
{
  DAQFrame_t *f;

  while(1)
  {
    f = DAQ_getFrame(0);
    #if CONFIG_HAS_TDDI_ESD_DETECTOR
    #if CONFIG_HAS_TDDI_ESD_CVITIMEOUT_CHECK
    esd_detector(f->errorFlags.cviTimeout);
    #else
    esd_detector();
    #endif
    #endif
    #if CONFIG_HAS_TDDI_ESD_HANDLER
    esd_handler();
    #endif
    if(f->errorFlags.all)//the frames after display on are error. skip it.
    {
      DAQ_releaseFrame(f);
      #if !defined(WIN32)
      COMM_petWatchDog();
      #endif
    }
    else
      break;
  }
  return (PLFrame_t*)f;
}

void PlatformApi_Tddi_Hic::PL_checkPowerStatus()
{
#if CONFIG_HAS_ESD_RECOVERY && !defined(WIN32)
  if (COMM_getPowerStatus() & 0x0C)
  {
      COMM_wakeupVideoThread();
  }
#endif
}

void increaseLocalCBC(uint16 *cbc, uint16 step)
{
  if (*cbc <= 15)
  {
    *cbc += step;
  }
  else
  {
    if (step < *cbc - 16)
    {
      *cbc -= step;
      return;
    }
    else
      *cbc = step - (*cbc - 16);
  }

  if (15 < *cbc)
    *cbc = 15;
}

void decreaseLocalCBC(uint16 *cbc, uint16 step)
{
  if (17 <= *cbc)
  {
    *cbc += step;
  }
  else
  {
    if (step <= *cbc)
      *cbc -= step;
    else
      *cbc = 16 + (step - *cbc);
  }

  if (31 < *cbc)
    *cbc = 31;
}

void PlatformApi_Tddi_Hic::PL_calibrateButtons()
{
  DAQFrame_t *df;
  PLFrameData_t *f;
  uint16 raw[MAX_BUTTONS];
  uint16 distToCenter[MAX_BUTTONS];
  uint16 dist;
  uint16 i;
  uint16 retry;
  uint16 localCbcStatus;
  uint16 initLocalCbcStatus = 0;
  uint16 adjustCbc;
  int16 lastLocalCbcs[MAX_BUTTONS];

  if (!CONFIG_HAS_0D_BUTTONS || !CONFIG_TDDI_AMP_BUTTONS || !CONFIG_HAS_0D_AUTOCAL) return;
  if (COMM_getPsmState() == 6 || COMM_getPsmState() == 1) return;
  if (pp.btnAbsTransMode) return;

  for(i = 0; i < pp.numBtns; i++)
  {
    raw[i] = 0;
    distToCenter[i] = 65535;
  }
  initLocalCbcStatus = ((~pp.btnTxRxMask) & ((1<<MAX_BUTTONS)-1));
  localCbcStatus = initLocalCbcStatus;

  for(retry = 0; retry < 16; ++retry)
  {
    uint16 trans0d[MAX_BUTTONS];
    uint16 ofst;

    // write new tac settings
    DAQ_writeVar(CBC_GLOBAL_CAP_TRANS0D_VAL, pp.btnGlobalCbc);
    for(i = 0; i < pp.numBtns; i++)
    {
      ofst = 2 - i % 3;
      trans0d[(i/3)*3+ofst] = pp.btnLocalCbcs[i];
    }
    DAQ_writeArray(CBC_LOCAL_CH32_TRANS0D_VAL, trans0d, LEN(trans0d));
    #if !defined(WIN32)
    COMM_petWatchDog();  //kick watchdog to prevent timeout error
    #endif

    if((localCbcStatus & pp.btnTxRxMask) == pp.btnTxRxMask)
    {
      break;
    }

    df = DAQ_getFrame(0);    //get 2D and 0D frame
    f = (PLFrameData_t*)&df->buffer;
    for(i = 0; i < pp.numBtns; i++)
    {
      raw[i] = f->buttons[i];
    }
    DAQ_releaseFrame(df);    //release frame

    adjustCbc = 0;
    for(i = 0; i < pp.numBtns; i++)
    {
      dist = raw[i] > 2500 ? raw[i]-2500 : 2500-raw[i];
      if(localCbcStatus & (1 << (MAX_BUTTONS+i))) // in progress of searching for better local cbc
      {
        if(dist > distToCenter[i])
        {
          pp.btnLocalCbcs[i] = lastLocalCbcs[i];
          localCbcStatus &= ~(1 << (MAX_BUTTONS+i)); // no need to search more
          localCbcStatus |= (1 << i); // found the best local cbc
        }
        else
        {
          distToCenter[i] = dist;
        }
      }

      // ignore the fixed local cbc(s)
      if((localCbcStatus & pp.btnTxRxMask) == pp.btnTxRxMask)
        break;

      if(localCbcStatus & (1 << i))
        continue;

      if((raw[i] > 1500) && (raw[i] < 3500))
        localCbcStatus |= (1 << (MAX_BUTTONS+i));

      if(2500 <= raw[i]) // too high
      {
        if((pp.btnLocalCbcs[i] == 31) && ((localCbcStatus & (1 << (MAX_BUTTONS+i))) == 0)) // cannot decrease adc by decreasing local cbc
        {
          adjustCbc |= 0x1; // decrease global cbc to decrease adc
        }
        else
        {
          lastLocalCbcs[i] = pp.btnLocalCbcs[i];
          if(pp.btnLocalCbcs[i] != 31)
          {
            if(dist > 1000)
              decreaseLocalCBC(&pp.btnLocalCbcs[i], 2);
            else
              decreaseLocalCBC(&pp.btnLocalCbcs[i], 1);
            adjustCbc |=(0x1 << (2*MAX_BUTTONS+i));
          }
          else
          {
            adjustCbc |= (0x1 << MAX_BUTTONS);
          }
        }
      }
      else // too low
      {
        if((pp.btnLocalCbcs[i] == 15) && ((localCbcStatus & (1 << (MAX_BUTTONS+i))) == 0)) // cannot increase adc by increasing local cbc
        {
          adjustCbc |= 0x2; // increase global cbc to increase adc
        }
        else
        {
          lastLocalCbcs[i] = pp.btnLocalCbcs[i];
          if(pp.btnLocalCbcs[i] != 15)
          {
            if(dist > 1000)
              increaseLocalCBC(&pp.btnLocalCbcs[i], 2);
            else
              increaseLocalCBC(&pp.btnLocalCbcs[i], 1);
            adjustCbc |=(0x1 << (2*MAX_BUTTONS+i));
          }
          else
          {
            adjustCbc |= (0x2 << MAX_BUTTONS);
          }
        }
      }
    }

    if ((adjustCbc & ((1<<MAX_BUTTONS)-1)) == 0)
    {
      adjustCbc |= (adjustCbc>>MAX_BUTTONS) & ((1<<MAX_BUTTONS)-1);
    }

    if ((adjustCbc & ((1<<MAX_BUTTONS)-1)) == 0x3) // failed!
    {
      break;
    }

    if ((adjustCbc & ((1<<MAX_BUTTONS)-1)) == 0x1) // decrease global cbc
    {
      if (pp.btnGlobalCbc > 0)
      {
        pp.btnGlobalCbc--;
        localCbcStatus = initLocalCbcStatus;
      }
      else // failed
      {
        break;
      }

      for (i = 0; i < pp.numBtns; i++)
      {
        distToCenter[i] = 65535;

        if (pp.btnTxRxMask & (1<<i))
        {
          if (adjustCbc & (1<<(2*MAX_BUTTONS+i)))
          {
            increaseLocalCBC(&pp.btnLocalCbcs[i], 1);
          }
        }
      }
    }
    else if ((adjustCbc & ((1<<MAX_BUTTONS)-1)) == 0x2) // increase global cbc
    {
      if (pp.btnGlobalCbc < 15)
      {
        pp.btnGlobalCbc++;
        localCbcStatus = initLocalCbcStatus;
      }
      else // failed
      {
        break;
      }

      for (i = 0; i < pp.numBtns; i++)
      {
        distToCenter[i] = 65535;

        if (pp.btnTxRxMask & (1<<i))
        {
          if (adjustCbc & (1<<(2*MAX_BUTTONS+i)))
          {
            decreaseLocalCBC(&pp.btnLocalCbcs[i], 1);
          }
        }
      }
    }
  }
}

void PlatformApi_Tddi_Hic::PL_setCurrentRate(uint16 rate)
{
  uint16 is_60hz = (rate == 60);

  if (mode != mode_active && mode != mode_idle)
    return;

  selectTimingTableActive(is_60hz, 1);
}

#endif
