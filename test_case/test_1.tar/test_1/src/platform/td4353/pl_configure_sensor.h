#ifndef _PLATFORM_TDDI_HIC_H
#define _PLATFORM_TDDI_HIC_H 1
/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

/**
 * PLFrameData_t decodes all possible frame types. This must match the
 * DAQ program for this platform.
 */
typedef union {
  struct {
    uint16 image[MAX_TX * MAX_RX];
    uint16 buttons[MAX_RX]; // not MAX_BUTTONS as its min value is 1 in .c while 0 in .daq
    uint16 hybridX[MAX_RX];
    uint16 hybridY[MAX_TX];
    uint16 noise[MAX_NOISE_RX * MAX_NOISE_BURSTS];
  };
  uint16 noiseScan[MAX_NOISE_SCAN_BURSTS * MAX_NOISE_RX];
  uint16 doze[MAX_RX + MAX_BUTTONS];
  uint16 superdoze[2];
  #if CONFIG_LOCAL_CBCSCAN_HYBRID || CONFIG_GLOBAL_CBCSCAN_HYBRID
  uint16 cbcScanHybrid[MAX_RX + MAX_TX];
  #endif
} PLFrameData_t;

/**
 * PLCapData_t stores the active frame in femtofarads, excepting noise
 * measurements.
 */
typedef struct {
  uint16 image[MAX_TX * MAX_RX + MAX_BUTTONS];
  uint32 hybridX[MAX_RX];
  uint32 hybridY[MAX_TX];
} PLCapData_t;


/**
 * PLAdcLimits_t stores the max ADC values for different parts of the
 * active frame. This can be used to check for saturation.
 */
typedef struct {
  uint16 image;
  uint16 buttons;
} PLAdcLimits_t;

/**
 * Per-sense-frequency timing parameters. These determine the sensing
 * frequency and how long each burst is.
 */
typedef struct {
  /// The length (in sense cycles) of the first burst in each cluster.
  uint16 burstSize1[MAX_FREQUENCIES];

  /// The length (in sense cycles) of subsequent bursts in each
  /// cluster.
  uint16 burstSize2[MAX_FREQUENCIES];

  /// The FILT_BW setting.
  uint16 filtBW[MAX_FREQUENCIES];

  /// The size of the frequency modulation ramp waveform.
  uint16 frampSize[MAX_FREQUENCIES];

  /// The value for FRAMP_CNT.
  uint16 frampCount[MAX_FREQUENCIES];

  /// The value for FRAMP_DELTA.
  uint16 frampDelta[MAX_FREQUENCIES];

  /// The value for STRETCH_DUR.
  uint16 stretchDur[MAX_FREQUENCIES];

  /// The value for RSTRETCH_DUR.
  uint16 rstretchDur[MAX_FREQUENCIES];

  /// Whether this frequency is enabled or not.
  uint16 disableFreq[MAX_FREQUENCIES];
} freqTable_t;

/**
 * Fmod control parameters.
 */
typedef struct {
  uint16 deadDelay;
  uint16 minOutput;
  uint16 frampCount;
  uint16 frampDelta;
  uint16 frampMax;
  uint16 fModeSscRstEn        : 1; //FMOD_SSC_RST_EN
  uint16 fModSbRstEn          : 1; //FMOD_SB_RST_EN
  uint16 fmodEn               : 1; //FMOD_EN
  uint16 fModTouchGateEn      : 1; //FMOD_TOUCH_GATE_EN
  uint16 fModGateTsvdMark     : 1; //FMOD_GATE_TSVD_MARK
  uint16 fModLineSyncEn       : 1; //FMOD_LINE_SYNC_EN
  uint16 fModDispGateEn       : 1; //FMOD_DISP_GATE_EN
  uint16 fModCtrlModeReserved : 9;
} fModeSetting_t;

/**
 * The DAQ configuration structure. This contains values for most of
 * the variables used to configure the AFE. In the documentation for
 * each field, if the field is said to correspond to an ASIC register
 * or register field, then that field uses the same encoding as the
 * ASIC register or register field.
 *
 * Not all ASIC registers have corresponding values here. For example,
 * there is no REF_SUBTRACT_CAP value for hybrid sensing. This is to
 * mirror the RMI register map. But other omissions could be bugs.
 *
 */
typedef struct {

  /// The value for ABS_PL used throughout the frame.
  uint16 absPl;

  /// Whether to enable Y-axis charge subtraction during proximity and
  /// hybrid sensing. This is used to augment CBC.
  uint16 absYChargeSubtractionEnable;

  /// The TREX pin to use for Y-axis charge subtraction.
  uint16 absYChargeSubtractionTx;

#if CONFIG_HAS_0D_BUTTONS
  /// The value for AXIS_SENSE to use during 0-D button sensing.
  uint16 buttonAxisSense;

  /// The number of bursts per cluster to use for button sensing.
  uint16 buttonBurstsPerCluster;

  /// The value for CBC_XMTR_CARRIER_SEL to use for button sensing.
  uint16 buttonCbcXmtrCarrierSel;

  /// The value for CBC_XMTR_PL to use for button sensing.
  uint16 buttonCbcXmtrPl;

  /// The list of button receiver TREX pins. Only the first
  /// ``numButtons`` entries are used.
  uint16 buttonRxes[MAX_BUTTONS];

  /// The list of button transmitter TREX pins. Only the first
  /// ``numButtons`` entries are used.
  uint16 buttonTxes[MAX_BUTTONS];

  // 0D_ACQUISITION_MODE
  uint16 concurrentButtonAcquisition;

  // 0D_HYBRID
  uint16 buttonAbsEnable;
  uint16 buttonAbsAxis;
  uint16 hybridButtonCbc;

  //Doze Button CBC
  uint16 dozeButtonCbcs[MAX_BUTTONS];

  #if CONFIG_TDDI_AMP_BUTTONS
  /// Operation mode (1: 2D simulation mode, 2: 0D separate sensing mode)
  uint16 buttonOperationMode;

  /// abstrans mode 0: abs-cap mode, 1: trans-cap mode
  uint16 buttonAbsTransMode;

  /// The scaling factor
  uint16 buttonScaleFactor[MAX_BUTTONS];

  /// Local CBC for button Active mode
  uint16 buttonLocalCbcs[MAX_BUTTONS];

  /// Global CBC for button Active mode
  uint16 buttonGlobalCbc;

  /// Local CBC for button Doze mode
  uint16 buttonLocalCbcDoze;

  /// Global CBC for button Doze mode
  uint16 buttonGlobalCbcDoze;

  /// REF_HI_CAP_SEL for button
  uint16 buttonRefHiCap;

  /// REF_LO_CAP_SEL for button
  uint16 buttonRefLoCap;
  #endif
#endif

  //Doze CBC
  uint16 dozeCbcs[MAX_RX];

  /// Set to 0 for doze, 1 for loze.
  uint16 lowPowerMode;

  /// Set to 1 to enable CDM of order CDM_ORDER
  uint16 cdmEnable;

  /// The frequency modulation center value.
  uint16 centerFmod;

  /// Set to 1 to enable CID.
  uint16 cidEnable;

  /// The value for INTFR_DET_VSEL to use for CID.
  uint16 cidThreshold;

  /// The per-sense-frequency timing settings.
  freqTable_t freqTable;

  /// The default sense frequency.
  uint16 frequency;

  /// HW clock modulation/dithering
  fModeSetting_t fModeSetting;

#if CONFIG_NSM
  /// Set to 1 to prevent frequency shifting
  uint16 inhibitFrequencyShift;

  /// The PowerIM threshold above which the NSM moves out of the HNM
  /// state.
  uint16 powerimHighThresh;

  /// The PowerIM threshold below which the NSM can move out of the
  /// FNM state.
  uint16 powerimLowThresh;

  /// The PowerIM threshold above which a frequency scan can be called
  /// from the FNM state.
  uint16 powerimFnmHighThresh;

  /// The minimum of the FSIM vector must be below this threshold to
  /// exit the frequency scan into HNM. Otherwise, the NSM moves into
  /// FNM after a frequency scan.
  uint16 fsimThresh;

  /// The RailIM threshold above which the NSM moves into the FNM
  /// state.
  uint16 railimHighThresh;

  /// The RailIM threshold below which the NSM can move out of the FNM
  /// state.
  uint16 railimLowThresh;

  /// The CIDIM threshold above which the NSM moves out of the FNM
  /// state.
  uint16 cidimHighThresh;

  /// The CIDIM threshold below which the NSM moves out of the FNM
  /// state to the HNM state instead of the FNM_CID state.
  uint16 cidimLowThresh;

  /// The percentage of the previous 16 frames that the PowerIM
  /// exceeded the powerimFnmHightThresh required in order to start a
  /// frequency scan from the FNM.
  uint16 fsFnmDensity;

  /// The number of consecutive frames with IMs below their respective
  /// thresholds before moving out of the FNM or FNM_CID state.
  uint16 fnmTimeout;

  /// The minimum number of seconds that must elapse between
  /// consecutive frequency scans.
  uint16 fsTimeout;

  /// The number of consecutive frames with IMs below their respective
  /// thresholds before moving 60hz to 120hz
  uint16 hnmRateShiftFrameCount;

  #if CONFIG_NSM_CALLISTO
  /// The VarCIDIM threshold above which the NSM moves into
  /// the FNM state.
  uint16 varcidimHighThresh;

  /// The VarCIDIM threshold below which the NSM can move
  /// out of the FNM state.
  uint16 varcidimLowThresh;

  /// The number of frames that must be spent in the HNM state
  /// before re-entering the FNM_CID state.
  uint16 holdoffTimeout;
  #endif

  /// The number of touch rate control: manual 120hz (2), manual 60hz (1), dynamic 120hz/60hz (0)
  uint16 dynamicSensingRate;

  /// No Noise Mitigation: Dynamic Config. nsm_init() need this value to prevent frequency shifting
  uint16 noNoiseMitigation;
#endif

  /// The number of bursts per cluster for image sensing.
  uint16 imageBurstsPerCluster;

  /// The CBC_XMTR_CARRIER_SEL value for image sensing.
  uint16 imageCbcXmtrCarrierSel;

  /// The CBC_XMTR_PL value for image sensing.
  uint16 imageCbcXmtrPl;

  /// The CBC_CHn values for image sensing. These are ordered by image
  /// column. Only the first numCols values are used.
  uint16 imageCbcs[MAX_RX];
  uint16 absCbcs[MAX_RX+MAX_TX];

  /// The GAIN_CTRL value for image sensing.
  uint16 imageGainCtrl;

  /// The INTEG_DUR value for image sensing.
  uint16 imageIntegDur;

  /// The RCVR_FB_CAP value for image sensing.
  uint16 imageRcvrFbCap;

  /// The REF_GAIN_CTRL value for image sensing.
  uint16 imageRefGainCtrl;

  /// The REF_HI_TRANS_CAP value for image sensing.
  uint16 imageRefHiTransCap;

  /// The REF_LO_TRANS_CAP value for image sensing.
  uint16 imageRefLoTransCap;

  /// The REF_RCVR_FB_CAP value for image sensing.
  uint16 imageRefRcvrFbCap;

  /// The RESET_DUR value for image sensing.
  uint16 imageResetDur;

  /// The TREX pins used as the image receivers and the abs X axis.
  uint16 imageRxes[MAX_RX];

  /// The TREX pins used as the image transmitters and the abs Y axis.
  uint16 imageTxes[MAX_PHY_TX];

  /// The MASTER_BIAS_TRIM value.
  uint16 masterBiasTrim;

  /// The number of noise bursts in each frame. This must not exceed
  /// MAX_NOISE_BURSTS.
  uint16 noiseBursts;

  /// The number of bursts per frequency to use during a noise scan.
  /// This must not exceed MAX_NOISE_SCAN_BURSTS.
  uint16 noiseScanBursts;

  /// The BURST_SIZE value to use for blank bursts between subframes
  uint16 deadBurstSize;

  /// The number of buttons actually used. This must not exceed
  /// MAX_BUTTONS.
  uint16 numButtons;

  /// The number of image columns actually used. This must not exceed
  /// MAX_RX.
  uint16 numCols;

  /// The number of image rows actually used. This must not exceed
  /// MAX_TX.
  uint16 numRows;

  /// The number of guard pins on the image RX/abs X axis bank. This
  /// must not exceed MAX_RX_GUARDS.
  uint16 numRxGuards;

  /// The number of guard pins on the image TX/abs Y axis bank. This
  /// must not exceed MAX_TX_GUARDS.
  uint16 numTxGuards;

  /// The PUMP_DIV value
  uint16 pumpDiv;

  /// Set to 1 to enable rail interference detection.
  uint16 railEnable;

  /// The REF_HI_XMTR_PL value.
  uint16 refHiXmtrPl;

  /// The REF_LO_ABS_PL value.
  uint16 refLoAbsPl;

  /// The REF_LO_XMTR_PL value.
  uint16 refLoXmtrPl;

  /// The AXIS_SENSE value for X-axis and image sensing.
  uint16 xAxisSense;

  /// The AXIS_SENSE value for Y-axis sensing.
  uint16 yAxisSense;

  //DAC IN
  uint16 dac_in_trans;
  uint16 dac_in_absx;
  uint16 dac_in_absy;
  uint16 dac_in_0d;

  //CBC tx on cnt
  uint16 cbcTxOnCnt;

  //CBC RX on cnt
  uint16 cbcRxOnCnt;

  //Abs Rx CBC Tx On Count
  uint16 cbcRxTxOnCnt;
  //Abs Rx CBC Rx Connect On Count
  uint16 cbcRxRxConnectOnCnt;
  //Abs Tx CBC Tx On Count
  uint16 cbcTxTxOnCnt;
  //Abs Tx CBC Rx Connect On Count
  uint16 cbcTxRxConnectOnCnt;

  //Local CBC enable
  uint16 localCbcEnable;

  //CFB1 Off cnt
  uint16 cfb1OffCnt;

  #if CONTROL_GUARD_DAC
    uint16 deltaVStartState;
    uint16 delVrefState;
    uint16 deltaVDur;
  #endif

  //Global CBC enable
  uint16 globalCbcTransEnable : 1;
  uint16 globalCbcRxEnable    : 1;
  uint16 globalCbcTxEnable    : 1;
  uint16 globalCbc0DEnable    : 1;
  //Global CBC polarity
  uint16 globalCbcTransPl     : 1;
  uint16 globalCbcRxPl        : 1;
  uint16 globalCbcTxPl        : 1;
  uint16 globalCbc0DPl        : 1;
  #if CONFIG_HAS_ALTERNATE_CBCSCAN_CONTROL
  uint16 globalCbcHybridActiveDisable : 1;
  uint16 globalCbcHybridLPWGDisable   : 1;
  uint16 localCbcHybridActiveDisable  : 1;
  uint16 localCbcHybridLPWGDisable    : 1;
  #else
  uint16                      : 8;
  #endif

  //Global CBC gain
  uint16 globalCbcTransGain;
  uint16 globalCbcRxGain;
  uint16 globalCbcTxGain;
  uint16 globalCbc0DGain;
  //Global CBC value
  uint16 globalCbcTransValue;
  uint16 globalCbcRxValue;
  uint16 globalCbcTxValue;
  uint16 globalCbc0DValue;

  //Ref global CBC enable
  uint16 refGlobalCbcEnable;

  //Ref Local CBC value for TRANS
  uint16 refHiLocalCbcTransValue;
  uint16 refLoLocalCbcTransValue;
  //Ref Local CBC value for ABSX(==Rx)
  uint16 refHiLocalCbcRxValue;
  uint16 refLoLocalCbcRxValue;
  //Ref Local CBC value for ABSY(==Tx)
  uint16 refHiLocalCbcTxValue;
  uint16 refLoLocalCbcTxValue;
  //Ref Local CBC value for TRANS0D
  uint16 refHiLocalCbcTrans0DValue;
  uint16 refLoLocalCbcTrans0DValue;

  //Ref local CBC enable
  uint16 refLocalCbcEnable;

 #if (defined(cfg_hasTDDICBC) && cfg_hasTDDICBC) && !(defined(cfg_isAnyTDDIHIC) && cfg_isAnyTDDIHIC)
  //override local CBC, and ref local CBC enable
  uint16 overrideLocalRefLocalCbcEnable;
#endif
  //left global CBC value
  uint16 leftGlobalCbcValue;

  //right global CBC value
  uint16 rightGlobalCbcValue;

  //reference global CBC value
  uint16 refGlobalCbcValue;

  // For GPIO controls
  uint16 numGpioPins;
  uint16 gpioPinToOmitMask;

  // Panel
  uint16 panel; // TIANMA_PANEL: 1, BOE: 0

  // LHblank report rate 60Hz
  uint16 lhbReportRate60Hz;

#if CONFIG_NSM_EUROPA
  // baseline compensation
  uint16 transitionFrameCount;
#endif

  /// The ABS_GUARD value to use for hybrid sensing.
  uint16 hybridAbsGuard;

  /// The length (in sense cycles) of the first burst in each hybrid
  /// sensing axis.
  uint16 hybridBurstSize1;

  /// The length (in sense cycles) of subsequent bursts in each hybrid
  /// sensing axis.
  uint16 hybridBurstSize2;

  /// The FILT_BW setting for hybrid sensing.
  uint16 hybridFiltBW;

  /// The FRAMP_CNT setting for hybrid sensing.
  uint16 hybridFrampCnt;

  /// The FRAMP_DELTA setting for hybrid sensing.
  uint16 hybridFrampDelta;

  /// The size of the frequency modulation ramp waveform.
  uint16 hybridFrampSize;

  /// The INTEG_DUR value for hybrid sensing.
  uint16 hybridIntegDur;

  /// The RESET_DUR value for hybrid sensing.
  uint16 hybridResetDur;

  /// The RSTRETCH_DUR value for hybrid sensing.
  uint16 hybridRstretchDur;

  /// The STRETCH_DUR value for hybrid sensing.
  uint16 hybridStretchDur;

  /// The number of X-axis bursts for hybrid sensing.
  uint16 hybridXBursts;

  /// The CBC_XMTR_CARRIER_SEL value for X-axis hybrid sensing.
  uint16 hybridXCbcXmtrCarrierSel;

  /// The GAIN_CTRL value for X-axis hybrid sensing.
  uint16 hybridXGainCtrl;

  /// The RCVR_FB_CAP value for X-axis hybrid sensing.
  uint16 hybridXRcvrFbCap;

  /// The REF_GAIN_CTRL value for X-axis hybrid sensing.
  uint16 hybridXRefGainCtrl;

  /// The REF_HI_ABS_CAP value for X-axis hybrid sensing.
  uint16 hybridXRefHiAbsCap;

  /// The REF_HI_TRANS_CAP value for X-axis hybrid sensing.
  uint16 hybridXRefHiTransCap;

  /// The REF_LO_ABS_CAP value for X-axis hybrid sensing.
  uint16 hybridXRefLoAbsCap;

  /// The REF_LO_TRANS_CAP value for X-axis hybrid sensing.
  uint16 hybridXRefLoTransCap;

  /// The REF_RCVR_FB_CAP value for X-axis hybrid sensing.
  uint16 hybridXRefRcvrFbCap;

  /// The REF_SUBTRACT_FB_CAP value for X-axis hybrid sensing.
  uint16 hybridXRefSubtractFbCap;

  /// The SUBTRACT_FB_CAP value for X-axis hybrid sensing.
  uint16 hybridXSubtractFbCap;

  /// The VREF_MOD_AMP value for X-axis hybrid sensing.
  uint16 hybridXVrefModAmp;

  /// The number of Y-axis bursts for hybrid sensing.
  uint16 hybridYBursts;

  /// The CBC_YMTR_CARRIER_SEL value for Y-axis hybrid sensing.
  uint16 hybridYCbcXmtrCarrierSel;

  /// The GAIN_CTRL value for Y-axis hybrid sensing.
  uint16 hybridYGainCtrl;

  /// The RCVR_FB_CAP value for Y-axis hybrid sensing.
  uint16 hybridYRcvrFbCap;

  /// The REF_GAIN_CTRL value for Y-axis hybrid sensing.
  uint16 hybridYRefGainCtrl;

  /// The REF_HI_ABS_CAP value for Y-axis hybrid sensing.
  uint16 hybridYRefHiAbsCap;

  /// The REF_HI_TRANS_CAP value for Y-axis hybrid sensing.
  uint16 hybridYRefHiTransCap;

  /// The REF_LO_ABS_CAP value for Y-axis hybrid sensing.
  uint16 hybridYRefLoAbsCap;

  /// The REF_LO_TRANS_CAP value for Y-axis hybrid sensing.
  uint16 hybridYRefLoTransCap;

  /// The REF_RCVR_FB_CAP value for Y-axis hybrid sensing.
  uint16 hybridYRefRcvrFbCap;

  /// The REF_SUBTRACT_FB_CAP value for Y-axis hybrid sensing.
  uint16 hybridYRefSubtractFbCap;

  /// The SUBTRACT_FB_CAP value for Y-axis hybrid sensing.
  uint16 hybridYSubtractFbCap;

  /// The VREF_MOD_AMP value for Y-axis hybrid sensing.
  uint16 hybridYVrefModAmp;

  /// HW clock modulation/dithering
  uint16 hybridFmodEnable;

  // For HIC
  /// The INTEG_DUR value for hybrid sensing.
  uint16 hybridIntegDurTx;
  /// The RESET_DUR value for hybrid sensing.
  uint16 hybridResetDurTx;
  /// The FILT_BW setting for hybrid sensing.
  uint16 hybridFiltBWTx;
  /// The RSTRETCH_DUR value for hybrid sensing.
  uint16 hybridRstretchDurTx;
  /// The length (in sense cycles) of the first burst in each hybrid
  /// sensing axis.
  uint16 hybridBurstSize1Tx;
  /// The length (in sense cycles) of subsequent bursts in each hybrid
  /// sensing axis.
  uint16 hybridBurstSize2Tx;
  /// The STRETCH_DUR value for hybrid sensing.
  uint16 hybridStretchDurTx;
  /// The FRAMP_CNT setting for hybrid sensing.
  uint16 hybridFrampCntTx;
  /// The size of the frequency modulation ramp waveform.
  uint16 hybridFrampSizeTx;
  /// The FRAMP_DELTA setting for hybrid sensing.
  uint16 hybridFrampDeltaTx;
  // hybrid frequency hopping.
  uint16 hybridDeltaRstretchDur;
  uint16 hybridBMThreshold;
  uint16 hybridBMConsistency;
  uint16 hybridFrequencyHoppingEnable;

  // Trigger Control
  uint16 transTriggerDelay;
  uint16 transTriggerHoldoff;
  uint16 hybridTriggerDelayRx;
  uint16 hybridTriggerHoldoffRx;
  uint16 hybridTriggerDelayTx;
  uint16 hybridTriggerHoldoffTx;
  uint16 transTriggerDelay0D;
  uint16 transTriggerHoldoff0D;

  // Misc Sensing Control
  uint16 txDoze;
  uint16 guardRingPin;

  uint16 lpwgSoutCtrl0;
  uint16 lpwgSoutCtrl1;

  uint16 numBitsPerCBC;
} daqParams_t;

#include "../platform_base.h"

// Forward-declare some Calc2 structures we need pointers to. This
// prevents us from having to include header files in a specific
// order.
struct calcStaticConfig_t;
struct calcDynamicConfig_t;
struct dozeParams_t;

#ifdef __cplusplus
class PlatformApi_Tddi_Hic : public PlatformApi
{
public:
  void PL_convertToIFPFormat(struct calcStaticConfig_t *scfg ATTR_UNUSED);
  void PL_init(struct calcStaticConfig_t *scfg, struct calcDynamicConfig_t *dcfg ATTR_UNUSED);
  void PL_enterMode(PLMode_t newMode);
  PLFrame_t *PL_getFrame(PLFrameType_t frameType);
  void PL_releaseFrame(PLFrame_t *f);
  uint16 PL_isNSMInitialized();
  PLNSMState_t PL_getNSMState();
  uint16 PL_getNSMTransClusters();
  uint16 PL_getNSMNoiseBursts();
  uint16 PL_getNSMFreqScanBursts();
  void PL_convertDozeFrameToRawCap(PLFrameData_t *frame , PLCapData_t *cap);
  void PL_convertActiveFrameToRawCap(PLFrameData_t *frame , PLCapData_t *cap);
  void PL_convertActiveFrameToDeltaCap(PLFrameData_t *frame, PLCapData_t *cap);
  void PL_getTestFrame(prodTestType_t test, struct calcStaticConfig_t *scfg,
                     struct calcDynamicConfig_t *dcfg ATTR_UNUSED, prodTestResult_t *result);
  void PL_setParam(PLParam_t param_type, uint16 param_value);
  uint16 PL_isDozeTimerResetRequested();
  void PL_copy0DToFrameBuffer(uint16 isAbsBtnData ATTR_UNUSED, uint16 *btnDataPtr, PLFrameData_t *frameBufferPtr);
  void PL_0DButtonsScaling(uint16 *btnDataPtr, uint16 *btnScaleFactor);
  uint16 PL_isDozeWakeUpCondition(struct dozeParams_t *dozeConfig, int16 *deltaImage, uint16 size);
  void PL_setupFreqScanFrame();
  void PL_disableFreqScanFrame();
  void PL_setupRcvrOffsetFrame();
  void PL_disableRcvrOffsetFrame();
  PLFrame_t *PL_getRcvrOffsetFrame();
  void PL_checkPowerStatus();
  void PL_calibrateButtons();
  void PL_setCurrentRate(uint16 rate);
  void PL_findBestCbcs(struct calcStaticConfig_t *scfg, PLCBCType_t cbcType);
  void PL_getCbcs(PLCBCType_t cbcType, uint16 **CBCs);
  void PL_storeCbcs();
  void PL_restoreCbcs();
  uint16 PL_hybridCBCAutoCorrection(struct calcStaticConfig_t *cfg, uint16 objectsPresent, uint16 *rawRx, uint16 *rawTx);

};

extern PlatformApi_Tddi_Hic platformapi;

#endif

#endif
