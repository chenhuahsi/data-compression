/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include <string.h>
#include <stddef.h>
#include "calc2.h"

#if PLATFORM_TD4353 == 1        /* if not bypass this file completely */
#include "platform.h"

#if CONFIG_LOCAL_CBCSCAN_HYBRID || CONFIG_GLOBAL_CBCSCAN_HYBRID
  #include "../platform_cbc.h"
#endif

uint16 cbc_global_x, cbc_global_y, cbc_local_x[MAX_CH_COUNT], cbc_local_y[MAX_CH_COUNT];

void PlatformApi_Tddi_Hic::PL_findBestCbcs(struct calcStaticConfig_t *scfg ATTR_UNUSED, PLCBCType_t cbcType)
{
  if (cbcType == cbc_perPixelLocal)
  {
    #if CONFIG_PER_PIXEL_CBCSCAN
      findBestPerPixelLocalCbcs(scfg);
    #endif
  }
  #if CONFIG_HAS_HYBRID
  else if (cbcType == cbc_globalHybrid)
  {
    #if CONFIG_GLOBAL_CBCSCAN_HYBRID
      findBestGlobalCbcsHybrid(scfg);
    #endif
  }
  else if (cbcType == cbc_localHybrid)
  {
    #if CONFIG_LOCAL_CBCSCAN_HYBRID
      findBestLocalCbcsHybrid(scfg);
    #endif
  }
  #endif
}

void PlatformApi_Tddi_Hic::PL_getCbcs(PLCBCType_t cbcType, uint16 **CBCs ATTR_UNUSED)
{
  if (cbcType == cbc_perPixelLocal)
  {
    #if CONFIG_PER_PIXEL_CBCSCAN
      getPerPixelLocalCbcs(CBCs);
    #endif
  }
}

uint16 PlatformApi_Tddi_Hic::PL_hybridCBCAutoCorrection(struct calcStaticConfig_t *cfg ATTR_UNUSED, uint16 objectsPresent ATTR_UNUSED, uint16 *rawRx ATTR_UNUSED, uint16 *rawTx ATTR_UNUSED)
{
  #if CONFIG_HYBRID_CBC_CORRECTION
    return hybridCBCAutoCorrection(cfg, objectsPresent, rawRx, rawTx);
  #else
    return 0;
  #endif
}

void PlatformApi_Tddi_Hic::PL_storeCbcs()
{
#if CONFIG_GLOBAL_CBCSCAN_HYBRID || CONFIG_LOCAL_CBCSCAN_HYBRID
  uint16 i;

  cbc_global_x = DAQ_readVar(CBC_GLOBAL_CAP_ABSX_VAL);
  cbc_global_y = DAQ_readVar(CBC_GLOBAL_CAP_ABSY_VAL);
  for (i = 0; i < MAX_CH_COUNT; i++)
  {
    cbc_local_x[i] = DAQ_readVar(CBC_LOCAL_CH2_ABSX_VAL+i);
    cbc_local_y[i] = DAQ_readVar(CBC_LOCAL_CH2_ABSY_VAL+i);
  }
#endif
}

void PlatformApi_Tddi_Hic::PL_restoreCbcs()
{
#if CONFIG_GLOBAL_CBCSCAN_HYBRID || CONFIG_LOCAL_CBCSCAN_HYBRID
  uint16 i;

  DAQ_writeVar(CBC_GLOBAL_CAP_ABSX_VAL, cbc_global_x);
  DAQ_writeVar(CBC_GLOBAL_CAP_ABSY_VAL, cbc_global_y);
  for (i = 0; i < MAX_CH_COUNT; i++)
  {
    DAQ_writeVar(CBC_LOCAL_CH2_ABSX_VAL+i, cbc_local_x[i]);
    DAQ_writeVar(CBC_LOCAL_CH2_ABSY_VAL+i, cbc_local_y[i]);
  }
#endif
}

#endif // PLATFORM_TD4353 == 1        /* if not bypass this file completely */
