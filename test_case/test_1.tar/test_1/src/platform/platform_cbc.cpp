/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */
#include <string.h>
#include <stddef.h>

#include "calc2.h"
#include "daq2.h"
#include "platform_cbc.h"

#define HYBRID_GLOBAL_CBC_SCAN_RX_ENABLE (d->globalCbcRxEnable && !CONFIG_REDUCE_GLOBAL_CBC_SCAN_RX)
#define HYBRID_GLOBAL_CBC_SCAN_TX_ENABLE (d->globalCbcTxEnable && !CONFIG_REDUCE_GLOBAL_CBC_SCAN_TX)
#define HYBRID_LOCAL_CBC_SCAN_RX_ENABLE  (!CONFIG_REDUCE_LOCAL_CBC_SCAN_RX)
#define HYBRID_LOCAL_CBC_SCAN_TX_ENABLE  (!CONFIG_REDUCE_LOCAL_CBC_SCAN_TX)

#if CONFIG_PER_PIXEL_CBCSCAN

#define LEN(x)   (sizeof(x)/sizeof(x[0]))
#define abs(x)   (((x) >= 0) ? (x) : -(x))
#define MAX(a,b) (((a) > (b)) ? (a) : (b))

#if PLATFORM_TDDI || PLATFORM_TD4302 || PLATFORM_TD4310 || PLATFORM_TD4322 || PLATFORM_TD4100
  #define NUM_MUXES 2
#else
  #define NUM_MUXES 1
#endif

// If there are more than one bank of transmitters then the data is stored in
// separate left/right banks.  Otherwise the data is stored in one bank.
#if (NUM_MUXES == 2)
  static uint16 lcbcArray_L[(MAX_TX/NUM_MUXES)*MAX_RX];
  static uint16 lcbcArray_R[(MAX_TX/NUM_MUXES)*MAX_RX];
  static uint16 lcbcArray_L_logical[(MAX_TX/NUM_MUXES)*MAX_RX];
  static uint16 lcbcArray_R_logical[(MAX_TX/NUM_MUXES)*MAX_RX];
#else
  static uint16 lcbcArray[MAX_TX*MAX_RX];
  static uint16 lcbcArray_logical[MAX_TX*MAX_RX];
#endif

static void addS16ScalarToU16Array(uint16 *dst, uint16 len, int16 scalar)
{
  for (; len > 0; len--)
  {
    *dst++ += scalar;
  }
}

static int16 valToPos(uint16 *idxs, uint16 idx, uint16 max)
{
  uint16 i;
  int16  pos;

  for (i = 0, pos = 0; i < max; i++, idxs++)
  {
      if (*idxs == idx)
      {
        return pos;
      }
      pos++;
  }
  return -1;
}

#if (NUM_MUXES == 1)
static void mapTDDILogicalToPhysical(daqParams_t *dcfg, uint16* muxSensingOrder, uint16* logicalOrder)
{
  uint16 i,j;

  for (i = 0; i < dcfg->muxSize; i++) //row
  {
    for (j = 0; j < dcfg->numCols; j++)//col
    {
      uint16 selectCol = dcfg->imageRxes[j];
      muxSensingOrder[(i * MAX_RX) + selectCol] = logicalOrder[(i * MAX_RX) + j];
    }
  }
}
#else
//map logical to physical before setting CBC's
  /*
  Eg: MAX_RX = 32, MAX_TX = 20
      numCols = 30, numRows = 9
      Mux Sensing Order 8,7,6,5,4,3,2,1,0 with Swirl 0,1,2,3,4,5,6,7,8
    swap axis = 0

LT0 |_ _ _ _ _ _ _ _ _|
    |_ _ _ _ _ _ _ _ _|
    |_ _ _ _ _ _ _ _ _|
LT8 |_ _ _ _ _ _ _ _ _|
RT0 |_ _ _ _ _ _ _ _ _|
    :                 :
    |_ _ _ _ _ _ _ _ _|
RT8 |_ _ _ _ _ _ _ _ _|
   *LRX              LRXX
    RRX              RRXX

    swap axis = 1

RT0 |_ _ _ _ _ _ _ _ _|
    |_ _ _ _ _ _ _ _ _|
    |_ _ _ _ _ _ _ _ _|
RT8 |_ _ _ _ _ _ _ _ _|
LT0 |_ _ _ _ _ _ _ _ _|
    :                 :
    |_ _ _ _ _ _ _ _ _|
LT8 |_ _ _ _ _ _ _ _ _|
   *LRX            LRXX
    RRX            RRXX

* - Logical Origin (0,0), f->image[0]

*/
static void mapTDDILogicalToPhysical(daqParams_t *dcfg, uint16* nRows, uint16** muxSensingOrder, uint16** logicalSensingOrder)
{
  uint16 i,j;
  uint16 selectCol;
  uint16 selectRow;

  #if CONFIG_LEFT_RIGHT_MIRROR
    /*
     _________________________
    |            |            |
    |            |            |
    |            |            |
    |            |            |
    |            |            |
    |    L       |    R       |
    |            |            |
    |----------->|<-----------|
    |            |            |
    |            |            |
    |____________|____________|
    Mux Sensing order from Outside to Inside.
    Left -> 0 - MUXSIZE0
    Right -> MUXSIZE1 - 0
    */
    for (i = 0; i < nRows[0]; i++) //row
    {
      selectRow = valToPos(dcfg->muxSenseOrder, dcfg->imageTxes[i], nRows[0]);
      selectRow = (dcfg->swapSensorSide == 0) ? (nRows[0] - 1 - selectRow) : selectRow;
      for (j = 0; j < dcfg->numCols; j++)//col
      {
        selectCol = dcfg->imageRxes[j];
        muxSensingOrder[0][(selectRow * MAX_RX) + selectCol] = logicalSensingOrder[0][(i * MAX_RX) + j];
      }
    }
    for (i = 0; i < nRows[1]; i++) //row
    {
      selectRow = valToPos(dcfg->muxSenseOrder, dcfg->imageTxes[i], nRows[1]);
      selectRow = (dcfg->swapSensorSide == 1) ? (nRows[1] - 1 - selectRow) : selectRow;
      for (j = 0; j < dcfg->numCols; j++)//col
      {
        selectCol = dcfg->imageRxes[j];
        muxSensingOrder[1][(selectRow * MAX_RX) + selectCol] = logicalSensingOrder[1][(i * MAX_RX) + j];
      }
    }
  #else
    for (i = 0; i < nRows[0]; i++) //row
    {
      selectRow = valToPos(dcfg->muxSenseOrder, dcfg->imageTxes[i], nRows[0]);
      for (j = 0; j < dcfg->numCols; j++)//col
      {
        selectCol = dcfg->imageRxes[j];
        muxSensingOrder[0][((selectRow) * MAX_RX) + selectCol] = logicalSensingOrder[0][(i * MAX_RX) + j];
      }
    }
    for (i = 0; i < nRows[1]; i++) //row
    {
      selectRow = valToPos(dcfg->muxSenseOrder, dcfg->imageTxes[i], nRows[1]);
      for (j = 0; j < dcfg->numCols; j++)//col
      {
        selectCol = dcfg->imageRxes[j];
        muxSensingOrder[1][((selectRow) * MAX_RX) + selectCol] = logicalSensingOrder[1][(i * MAX_RX) + j];
      }
    }
  #endif
}
#endif

void findBestPerPixelLocalCbcs(struct calcStaticConfig_t *scfg)
{
  int16 mask;

  int16 target = scfg->perPixelLocalCBCTarget;
  daqParams_t *daqc = &scfg->daqParams;
  uint16 lcbcBits = daqc->numBitsPerCBC;

  // When servo'ing per-pixel local CBCs we need to make sure they are enabled
  // so save current state and explicitly enable use of local CBCs and
  // per-pixel CBCs
  uint16 localCBCEnabled = DAQ_readVar(CBC_LOCAL_ENABLE_VAL);
  uint16 perPixelCBCEnabled = DAQ_readVar(PER_PIXEL_CBC);
  DAQ_writeVar(CBC_LOCAL_ENABLE_VAL, 1);
  DAQ_writeVar(PER_PIXEL_CBC, 1);

  #if (NUM_MUXES == 2)
    uint16 muxSize[NUM_MUXES];
    uint16* muxSensingOrder[NUM_MUXES];
    uint16* logicalSensingOrder[NUM_MUXES];

    // This is the layout of muxes vs left/right
    //  * daqc->muxSize[0] = AfeLSize
    //  * daqc->muxSize[1] = AfeRSize
    muxSize[0] = (daqc->swapSensorSide) ? daqc->muxSize[0] : daqc->muxSize[1];
    muxSize[1] = (daqc->swapSensorSide) ? daqc->muxSize[1] : daqc->muxSize[0];
    muxSensingOrder[0] = (daqc->swapSensorSide) ? lcbcArray_L : lcbcArray_R;
    muxSensingOrder[1] = (daqc->swapSensorSide) ? lcbcArray_R : lcbcArray_L;
    logicalSensingOrder[0] = (daqc->swapSensorSide) ? lcbcArray_L_logical : lcbcArray_R_logical;
    logicalSensingOrder[1] = (daqc->swapSensorSide) ? lcbcArray_R_logical : lcbcArray_L_logical;
    uint16 count = MAX(muxSize[0], muxSize[1])*MAX_RX;
  #else
    uint16 count = daqc->muxSize*MAX_RX;
  #endif

  //initialize
  #if (NUM_MUXES == 2)
    memset(lcbcArray_L, 0, sizeof(lcbcArray_L));
    memset(lcbcArray_R, 0, sizeof(lcbcArray_R));
    memset(lcbcArray_L_logical, 0, sizeof(lcbcArray_L_logical));
    memset(lcbcArray_R_logical, 0, sizeof(lcbcArray_R_logical));
  #else
    memset(lcbcArray, 0, sizeof(lcbcArray));
    memset(lcbcArray_logical, 0, sizeof(lcbcArray_logical));
  #endif

  for (mask = (1 << (lcbcBits-1)); mask > 0; mask >>= 1)
  {
    // NOTE: The order of accessing lcbcArray[] for multiple muxes is not always
    // '0' then '1'. So we cannot flatten the following code into a single 'for
    // each mux' loop!!!

    // Stage 1: Setup mask, backup current local CBC values.
    #if (NUM_MUXES == 2)
      addS16ScalarToU16Array(lcbcArray_L, count, mask);
      addS16ScalarToU16Array(lcbcArray_R, count, mask);

      memcpy(lcbcArray_L_logical, lcbcArray_L, count*sizeof(uint16));
      memcpy(lcbcArray_R_logical, lcbcArray_R, count*sizeof(uint16));
      memset(lcbcArray_L, 0, sizeof(lcbcArray_L));
      memset(lcbcArray_R, 0, sizeof(lcbcArray_R));
    #else
      addS16ScalarToU16Array(lcbcArray, count, mask);

      memcpy(lcbcArray_logical, lcbcArray, count*sizeof(uint16));
      memset(lcbcArray, 0, sizeof(lcbcArray));
    #endif

    // Stage 2: The order of the muxSensingOrder (lcbcArray[]s)
    #if (NUM_MUXES == 2)
      mapTDDILogicalToPhysical(daqc, muxSize, muxSensingOrder, logicalSensingOrder);
    #else
      mapTDDILogicalToPhysical(daqc, lcbcArray, lcbcArray_logical);
    #endif

    // Stage 3: Update DAQ LCBC settings
    #if (NUM_MUXES == 2)
      DAQ_writeArray(CBC_L_LOCAL_ARRAY, lcbcArray_L, count);
      DAQ_writeArray(CBC_R_LOCAL_ARRAY, lcbcArray_R, count);

      PL_updateTestModeLCBC(lcbcArray_L, lcbcArray_R);
    #else
      DAQ_writeArray(CBC_LOCAL_ARRAY, lcbcArray, count);
    #endif


    // Stage 4: Restore lcbc
    #if (NUM_MUXES == 2)
      memset(lcbcArray_L, 0, sizeof(lcbcArray_L));
      memset(lcbcArray_R, 0, sizeof(lcbcArray_R));
      memcpy(lcbcArray_L, lcbcArray_L_logical, count*sizeof(uint16));
      memcpy(lcbcArray_R, lcbcArray_R_logical, count*sizeof(uint16));
    #else
      memset(lcbcArray, 0, sizeof(lcbcArray));
      memcpy(lcbcArray, lcbcArray_logical, count*sizeof(uint16));
    #endif

    // Stage 5: Get frame with ADC values based upon current per-pixel local
    // CBC values
    PLFrame_t *f = PL_getFrame(frame_active);
    uint16 j;

    // Stage 6: Update per-pixel local CBCs based upon desired threshold
    #if (NUM_MUXES == 2)
      uint16 sizeBottom = muxSize[0]*MAX_RX;
      uint16 sizeTop = muxSize[1]*MAX_RX;
      // Bottom half
      for (j = 0; j < sizeBottom; j++)
      {
        if ((int16)(f->data.image[j]) <= target)
        {
          muxSensingOrder[0][j] -= mask;
        }
      }
      // Top half
      for (j = 0; j < sizeTop; j++)
      {
        if ((int16)(f->data.image[j+sizeBottom]) <= target)
        {
          muxSensingOrder[1][j] -= mask;
        }
      }
    #else
      for (j = 0; j < count; j++)
      {
        if ((int16)f->data.image[j] <= target)
        {
          lcbcArray[j] -= mask;
        }
      }
    #endif

    PL_releaseFrame(f);
  }

  // Set the final CBC servo results.
  #if (NUM_MUXES == 2)
    //copy to temp array.
    memcpy(lcbcArray_L_logical, lcbcArray_L, count*sizeof(uint16));
    memcpy(lcbcArray_R_logical, lcbcArray_R, count*sizeof(uint16));
    memset(lcbcArray_L, 0, sizeof(lcbcArray_L));
    memset(lcbcArray_R, 0, sizeof(lcbcArray_R));

    mapTDDILogicalToPhysical(daqc, muxSize, muxSensingOrder, logicalSensingOrder);

    DAQ_writeArray(CBC_L_LOCAL_ARRAY, lcbcArray_L, count);
    DAQ_writeArray(CBC_R_LOCAL_ARRAY, lcbcArray_R, count);

    PL_updateTestModeLCBC(lcbcArray_L, lcbcArray_R);
  #else
    //copy to temp array.
    memcpy(lcbcArray_logical, lcbcArray, count*sizeof(uint16));
    memset(lcbcArray, 0, sizeof(lcbcArray));

    mapTDDILogicalToPhysical(daqc, lcbcArray, lcbcArray_logical);

    DAQ_writeArray(CBC_LOCAL_ARRAY, lcbcArray, count);
  #endif

  // Restore original local CBC enable and per-pixel local CBC enabled state.
  DAQ_writeVar(CBC_LOCAL_ENABLE_VAL, localCBCEnabled);
  DAQ_writeVar(PER_PIXEL_CBC, perPixelCBCEnabled);
}

void getPerPixelLocalCbcs(uint16 **CBCs)
{
  #if (NUM_MUXES == 2)
    CBCs[0] = lcbcArray_L_logical;
    CBCs[1] = lcbcArray_R_logical;
  #else
    *CBCs = lcbcArray_logical;
  #endif
}

#endif // #if CONFIG_PER_PIXEL_CBCSCAN

#if CONFIG_LOCAL_CBCSCAN_HYBRID || CONFIG_GLOBAL_CBCSCAN_HYBRID

#define TARGET_ADC  CONFIG_CBCSCAN_TARGETADC_HYBRID
#define MAX_ADC     4095

#define diff_abs(x1, x2)  ((x1 >= x2) ? (x1 - x2) : (x2 - x1))
#define SIZE(x) (sizeof(x)/sizeof(x[0]))

static inline void memset16(uint16 *p, uint16 c, uint16 len)
{
  uint16 i;
  for (i = 0; i < len; i++)
  {
    *p++ = c;
  }
}

#if CONFIG_LOCAL_CBCSCAN_HYBRID
static void updateLocalCBCs(uint16 *cbcs, daqParams_t *daqParams)
{
  uint16 absx[MAX_CH_COUNT];
  uint16 absy[MAX_CH_COUNT];
  uint16 ch, ofst;
  uint16 rx_max = daqParams->numCols;
  uint16 tx_max = daqParams->numRows;
  memset16(absx, 0, SIZE(absx));
  memset16(absy, 0, SIZE(absy));

  // set local CBCs
  for (ch = 0; ch < rx_max; ch++)
  {
    uint16 index = daqParams->imageRxes[ch];
    ofst = 2 - index % 3;
    absx[(index/3)*3+ofst] = cbcs[ch];
  }
  for (ch = 0; ch < tx_max; ch++)
  {
    uint16 index = daqParams->imageTxes[ch];
    ofst = 2 - index % 3;
    absy[(index/3)*3+ofst] = cbcs[MAX_RX+ch];
  }
  DAQ_writeArrayAsync(CBC_LOCAL_CH2_ABSX_VAL, absx, SIZE(absx));
  DAQ_writeArrayAsync(CBC_LOCAL_CH2_ABSY_VAL, absy, SIZE(absy));
}
#endif

static inline void getHybridAbsFrame(uint16 *adcs)
{
  PLFrame_t *f;
  uint16 trig;

  // kick watchdog to prevent timeout error
#if !defined(WIN32)
  COMM_petWatchDog();
#endif

  // get current hybrid X/Y raw adc counts
  trig = DAQ_readVar(CURRENT_TRIGGER_MODE);
  if (trig == 0)
  {
    PL_enterMode(mode_cbcScan);
    f = PL_getFrame(frame_cbcscan_hybrid);
    memcpy(adcs, f->data.cbcScanHybrid, (MAX_RX+MAX_TX)*sizeof(adcs[0]));
  }
  else
  {
    PL_enterMode(mode_modeB_trgt);
    f = PL_getFrame(frame_modeB_trgt);
    memcpy(adcs,        f->data.hybridX, MAX_RX*sizeof(adcs[0]));
    memcpy(adcs+MAX_RX, f->data.hybridY, MAX_TX*sizeof(adcs[0]));
  }
  PL_releaseFrame(f);
}

#if CONFIG_GLOBAL_CBCSCAN_HYBRID

#define MAX_AXIS  2

typedef struct {
  uint16 found;      // count when found the best gcbc
  uint16 best_cap;   // the best global CBC CAP
  uint16 worst_raw;  // the worst raw adc
  uint16 worst_diff; // |raw - target|
  uint16 gcapMin;    // min range of gcap value, dynamically changes...
  uint16 gcapCurr;   // current gcap value. start from 12.75pF in middle of range.
  uint16 gcapMax;    // max range of gcap value, dynamically changes...
}gcbc_t;
gcbc_t gcbcHybrid[MAX_AXIS];

static inline void updateGlobalCBCs(daqParams_t *d, uint16 gCbcX, uint16 gCbcY)
{
  if (HYBRID_GLOBAL_CBC_SCAN_RX_ENABLE)
    DAQ_writeVarAsync(CBC_GLOBAL_CAP_ABSX_VAL, gCbcX);
  if (HYBRID_GLOBAL_CBC_SCAN_TX_ENABLE)
    DAQ_writeVarAsync(CBC_GLOBAL_CAP_ABSY_VAL, gCbcY);
}

/* -----------------------------------------------------------
Name:    findBestGlobalCbcsHybrid()
Purpose: Find the best global CBCs. (linear search)
Notes: <5 bits> CBC_GLOBAL_CAP (0.75[0] to 24pF[31], steps = 0.75pF)
- CBC_GLOBAL_GAIN should be controlled by manual.(necessary...??)
- Find the most minimum gap from target value(about max_adc/2)
- During the scanning, local CBCs set to 0pF and recover original value when finished.
- First, scan with 0x10(12.75pF) in middle of range to reduce scan time.
- Do binary search...
  : If (best_raw != 0) && (best_raw < target), go to up-direction.
  : Else go to down-direction
- MAX loop is 6
- RX and TX can go to different direction
----------------------------------------------------------- */
void findBestGlobalCbcsHybrid(struct calcStaticConfig_t *scfg)
{
  uint16 pos, axis, lp_s, lp_e;
  uint16 rawCurr[MAX_RX+MAX_TX];
  const uint16 max_adc = MAX_ADC;
  const uint16 target_val = TARGET_ADC;
  uint16 worst_diff[MAX_AXIS], worst_raw[MAX_AXIS];
  uint16 loopCount = 0;
  uint16 loopMax = 6;
  daqParams_t *d = &scfg->daqParams;
  gcbc_t gcbc[MAX_AXIS] = {{0, 0, 0, max_adc, 0, 16, 31}, {0, 0, 0, max_adc, 0, 16, 31}};
  uint16 savedBurstsX, savedBurstsY;

  if (!HYBRID_GLOBAL_CBC_SCAN_RX_ENABLE && !HYBRID_GLOBAL_CBC_SCAN_TX_ENABLE) return;

  PL_enterMode(mode_idle);

  savedBurstsX = DAQ_readVar(ABSX_BURSTS_PER_CLUSTER);
  savedBurstsY = DAQ_readVar(ABSY_BURSTS_PER_CLUSTER);
  DAQ_writeVarAsync(ABSX_BURSTS_PER_CLUSTER, 1);
  DAQ_writeVarAsync(ABSY_BURSTS_PER_CLUSTER, 1);
  gcbc[0].best_cap = DAQ_readVar(CBC_GLOBAL_CAP_ABSX_VAL);
  gcbc[1].best_cap = DAQ_readVar(CBC_GLOBAL_CAP_ABSY_VAL);

  // scan and update max/min range, candidate gcbc
  do {
    updateGlobalCBCs(d, gcbc[0].gcapCurr, gcbc[1].gcapCurr);
    getHybridAbsFrame(rawCurr);

    // inits variables for this scan.
    memset16(worst_diff, 0x00, MAX_AXIS);
    memset16(worst_raw, target_val, MAX_AXIS);

    // looks for the worst diff in this scan.
    lp_s = !HYBRID_GLOBAL_CBC_SCAN_RX_ENABLE ? MAX_RX : 0;
    lp_e = !HYBRID_GLOBAL_CBC_SCAN_TX_ENABLE ? d->numCols : MAX_RX+d->numRows;
    for (pos = lp_s; pos < lp_e; pos++)
    {
      uint16 diff_raw;
      axis = (pos < MAX_RX) ? 0 : 1;

      if (d->numCols <= pos && pos < MAX_RX)
        continue;
      else if (target_val*2 < max_adc)
        rawCurr[pos] = (target_val*2 < rawCurr[pos]) ? target_val*2 : rawCurr[pos];
      else
        rawCurr[pos] = (rawCurr[pos] < target_val*2 - max_adc) ? target_val*2 - max_adc : rawCurr[pos];

      diff_raw = diff_abs(rawCurr[pos], target_val);
      if (worst_diff[axis] < diff_raw)
      {
        worst_diff[axis] = diff_raw;
        worst_raw[axis] = rawCurr[pos];
      }
    }

    // records gcbc value for 'better' worst diff.
    lp_s = !HYBRID_GLOBAL_CBC_SCAN_RX_ENABLE ? 1 : 0;
    lp_e = !HYBRID_GLOBAL_CBC_SCAN_TX_ENABLE ? 1 : MAX_AXIS;
    for (axis = lp_s; axis < lp_e; axis++)
    {
      if (worst_diff[axis] <= gcbc[axis].worst_diff)
      {
        gcbc[axis].worst_diff = worst_diff[axis];
        gcbc[axis].worst_raw = worst_raw[axis];
        gcbc[axis].best_cap = gcbc[axis].gcapCurr;
        gcbc[axis].found++;
      }
    }

    // decides direction for next scan.
    lp_s = !HYBRID_GLOBAL_CBC_SCAN_RX_ENABLE ? 1 : 0;
    lp_e = !HYBRID_GLOBAL_CBC_SCAN_TX_ENABLE ? 1 : MAX_AXIS;
    for (axis = lp_s; axis < lp_e; axis++)
    {
      if (worst_raw[axis] < target_val)
        gcbc[axis].gcapMax = gcbc[axis].gcapCurr;
      else
        gcbc[axis].gcapMin = gcbc[axis].gcapCurr;

      if (gcbc[axis].gcapMax == 1)
        gcbc[axis].gcapCurr = 0;
      else
        gcbc[axis].gcapCurr = (gcbc[axis].gcapMax + gcbc[axis].gcapMin + 1) / 2;
    }
  }
  while(++loopCount < loopMax);

  lp_s = !HYBRID_GLOBAL_CBC_SCAN_RX_ENABLE ? 1 : 0;
  lp_e = !HYBRID_GLOBAL_CBC_SCAN_TX_ENABLE ? 1 : MAX_AXIS;
  for (axis = lp_s; axis < lp_e; axis++)
  {
    // If we don't find the best gcbc in valid min/max range, we need to set the final gcap value.
    if (gcbc[axis].found == 0)
      gcbc[axis].best_cap = gcbc[axis].gcapCurr;

    // for debugging by RAM backdoor on DS5
    memcpy((uint16*)gcbcHybrid, gcbc, MAX_AXIS*sizeof(gcbc_t));
  }

  updateGlobalCBCs(d, gcbc[0].best_cap, gcbc[1].best_cap);
  COMM_setHybridGlobalCBCs(gcbc[0].best_cap, gcbc[1].best_cap);

  DAQ_writeVarAsync(ABSX_BURSTS_PER_CLUSTER, savedBurstsX);
  DAQ_writeVarAsync(ABSY_BURSTS_PER_CLUSTER, savedBurstsY);
}
#endif // #if CONFIG_GLOBAL_CBCSCAN_HYBRID

#if CONFIG_LOCAL_CBCSCAN_HYBRID
/* -----------------------------------------------------------
Name:    findBestLocalCbcsHybrid()
Purpose: Find the best local CBCs.
Notes:
  <5 bits> per channel CBC control (0 to 4pF, steps = 0.267pF)
  CBC_CH[3:0]    CBC_CAP       Mode
  0x1F           4.000pF        Charge subtraction
  ...
  0x11           0.267pF        Charge subtraction
  0x10           [RESERVED]
  0x0F           4.000pF        Charge addition
  ...
  0x01           0.267pF        Charge addition
  0x00           0.000pF        [OFF]
Example:
                            0x10 0x00
  |---------------------------|   |---------------------------|
  0x1F  0x1C  0x18  0x14  0x11     0x01  0x04  0x08  0x0C  0x0F

To find the optimun per-channel local CBCs, the algorithm uses binary and linear search.
The maximum iteration is 'six' as below examples.

Ex) Iteration number will be
  1) To find 0x1F --> 0x00, 0x18, 0x1C, 0x1D, 0x1E, 0x1F
  2) To find 0x19 --> 0x00, 0x18, 0x1C, 0x1B, 0x1A, 0x19
  3) To find 0x17 --> 0x00, 0x18, 0x14, 0x15, 0x16, 0x17
  4) To find 0x11 --> 0x00, 0x18, 0x14, 0x13, 0x12, 0x11
  5) To find 0x01 --> 0x00, 0x08, 0x04, 0x03, 0x02, 0x01
  6) To find 0x07 --> 0x00, 0x08, 0x04, 0x05, 0x06, 0x07
  7) To find 0x09 --> 0x00, 0x08, 0x0C, 0x0B, 0x0A, 0x09
  8) To find 0x0F --> 0x00, 0x08, 0x0C, 0x0D, 0x0E, 0x0F
----------------------------------------------------------- */
static uint16 lcbcHybrid[MAX_RX+MAX_TX];
static uint16 lcbcRawHybrid[MAX_RX+MAX_TX];

void findBestLocalCbcsHybrid(struct calcStaticConfig_t *scfg)
{
  uint16 stepCount = 0;
  uint16 *bestCbcs = lcbcHybrid;
  uint16 *rawBest = lcbcRawHybrid;
  uint16 localCbcs[MAX_RX+MAX_TX];
  uint16 rawCurr[MAX_RX+MAX_TX];
  uint16 cbcPos[MAX_RX+MAX_TX];
  uint16 isChargeSubtraction[MAX_RX+MAX_TX];
  daqParams_t *d = &scfg->daqParams;
  uint16 savedBurstsX, savedBurstsY;
  const uint16 maxStep = 6;
  const uint16 target_val = TARGET_ADC;
  const uint16 max_adc = MAX_ADC;
  //                    stepCount:  1     2     3     4     5      // cbcPos
  const uint16 CbcVals[9][5] = { {0x18, 0x1C, 0x1D, 0x1E, 0x1F},   // 0  Charge Subtraction
                                 {0x18, 0x1C, 0x1B, 0x1A, 0x19},   // 1        ^
                                 {0x18, 0x14, 0x15, 0x16, 0x17},   // 2        |
                                 {0x18, 0x14, 0x13, 0x12, 0x11},   // 3        |
                                 {0x00, 0x00, 0x00, 0x00, 0x00},   // 4        |
                                 {0x08, 0x04, 0x03, 0x02, 0x01},   // 5        |
                                 {0x08, 0x04, 0x05, 0x06, 0x07},   // 6        |
                                 {0x08, 0x0C, 0x0B, 0x0A, 0x09},   // 7        v
                                 {0x08, 0x0C, 0x0D, 0x0E, 0x0F} }; // 8  Charge Addition

  PL_enterMode(mode_idle);

  savedBurstsX = DAQ_readVar(ABSX_BURSTS_PER_CLUSTER);
  savedBurstsY = DAQ_readVar(ABSY_BURSTS_PER_CLUSTER);
  DAQ_writeVarAsync(ABSX_BURSTS_PER_CLUSTER, 1);
  DAQ_writeVarAsync(ABSY_BURSTS_PER_CLUSTER, 1);

  // start from the middle position in CbcVals array
  memset16(localCbcs, 0x00, (MAX_RX+MAX_TX));
  if (!HYBRID_LOCAL_CBC_SCAN_RX_ENABLE)
    memcpy(&localCbcs[0], &d->absCbcs[0], MAX_RX*sizeof(localCbcs[0]));
  if (!HYBRID_LOCAL_CBC_SCAN_TX_ENABLE)
    memcpy(&localCbcs[MAX_RX], &d->absCbcs[MAX_RX], MAX_TX*sizeof(localCbcs[0]));
  memcpy(bestCbcs, localCbcs, (MAX_RX+MAX_TX)*sizeof(localCbcs[0]));
  memset16(cbcPos, 4, (MAX_RX+MAX_TX));
  memset16(rawBest, max_adc, (MAX_RX+MAX_TX));
  memset16(isChargeSubtraction, 0x00, (MAX_RX+MAX_TX));

  do {
    uint16 i;

    updateLocalCBCs(localCbcs, d);
    getHybridAbsFrame(rawCurr);

    for (i = 0; i < MAX_RX + MAX_TX; i++)
    {
      if ((i < MAX_RX  && !HYBRID_LOCAL_CBC_SCAN_RX_ENABLE) ||
          (MAX_RX <= i && !HYBRID_LOCAL_CBC_SCAN_TX_ENABLE))
        continue;

      uint16 bestDiff = diff_abs(rawBest[i], target_val);
      uint16 currDiff = diff_abs(rawCurr[i], target_val);

      // update the best CBCs and set the last value if it is same.
      if (target_val*2 < max_adc) // 0-----target-----|max_diff---max_adc|
      {
        uint16 max_diff = target_val*2;
        if ((currDiff <= bestDiff) ||
            ((rawCurr[i] > max_diff) && (rawCurr[i] < max_adc) && (rawBest[i] == 0)))
        {
          bestCbcs[i] = localCbcs[i];
          rawBest[i] = rawCurr[i];
        }
      }
      else // |0--low_diff|---target-----max_adc
      {
        uint16 low_diff = target_val*2 - max_adc;
        if ((currDiff <= bestDiff) ||
            ((rawCurr[i] > 0) && (rawCurr[i] < low_diff) && (rawBest[i] == max_adc)))
        {
          bestCbcs[i] = localCbcs[i];
          rawBest[i] = rawCurr[i];
        }
      }

      // Choose next CBCs to scan
      if (rawCurr[i] > target_val)
      { // charge subtraction
        if (stepCount == 0) // cbcPos[i] == 4
        {
          cbcPos[i] -= 2;
          isChargeSubtraction[i] = 1;
        }
        else if (stepCount == 1)
        {
          cbcPos[i]--;
        }
        else if (stepCount == 2)
        {
          if (isChargeSubtraction[i]) {
            cbcPos[i]--;
          }
        }
        else
        { // high clipped adc
          if (isChargeSubtraction[i] && (rawCurr[i] == max_adc) && (rawBest[i] == max_adc) && (cbcPos[i] > 0))
          {
            cbcPos[i]--;
          }
        }
      }
      else
      { // charge addition
        if (stepCount == 0) // cbcPos[i] == 4
        {
          cbcPos[i] += 2;
          isChargeSubtraction[i] = 0;
        }
        else if (stepCount == 1)
        {
          cbcPos[i]++;
        }
        else if (stepCount == 2)
        {
          if (isChargeSubtraction[i] == 0) {
            cbcPos[i]++;
          }
        }
        else
        { // low clipped adc.
          if (!isChargeSubtraction[i] && (rawCurr[i] == 0) && (rawBest[i] == 0) && (cbcPos[i] < 8))
          {
            cbcPos[i]++;
          }
        }
      }
      localCbcs[i] = CbcVals[cbcPos[i]][stepCount];
    }
  }while(++stepCount < maxStep);
  // update the best CBCs for each mode (active and mode B)
  updateLocalCBCs(bestCbcs, d);
  COMM_setHybridLocalCBCs(bestCbcs, d);

  DAQ_writeVarAsync(ABSX_BURSTS_PER_CLUSTER, savedBurstsX);
  DAQ_writeVarAsync(ABSY_BURSTS_PER_CLUSTER, savedBurstsY);
}
#endif // #if CONFIG_LOCAL_CBCSCAN_HYBRID

#endif // #if CONFIG_LOCAL_CBCSCAN_HYBRID || CONFIG_GLOBAL_CBCSCAN_HYBRID

#if CONFIG_HYBRID_CBC_CORRECTION
enum{
  NONE,
  NEED_TO_INCREASE_CBC,
  NEED_TO_REDUCE_CBC
};
uint16 consistentNoFingerFrames;

static uint16 doLCbcScanNext, powerOn, origGcbc;
uint16 ajdustLocal(uint16 cbcVal, uint16 finalDecision)
{
 if (cbcVal & 0x10)
 {
    // Treat it as negative value
    cbcVal &= 0x0F;
    cbcVal *= (int16) -1;
  }
  if (finalDecision == NEED_TO_INCREASE_CBC)
  {
    cbcVal += 1;
  } else if (finalDecision == NEED_TO_REDUCE_CBC)
  {
    cbcVal -= 1;
  }
  if ((int16) cbcVal < 0)
  {
    cbcVal *= (int16) -1;
    cbcVal |= 0x10;
  }
  return cbcVal;
}

uint16 adjustGlobal(uint16 cbcVal, uint16 finalDecision, uint16 swing)
{
  cbcVal++;
  if (finalDecision == NEED_TO_REDUCE_CBC)
  {
    cbcVal -= 2;
  }
  if ((int16) cbcVal > (int16) (origGcbc + swing))
  {
    cbcVal = origGcbc + swing;
  } else if ((int16) cbcVal < (int16) (origGcbc - swing))
  {
    cbcVal = origGcbc - swing;
  }

  if ((int16) cbcVal > 31)
  {
    cbcVal = 31;
  } else if ((int16) cbcVal < 0)
  {
    cbcVal = 0;
  }
  return cbcVal;
}

static struct
{
  uint16 cbcChangedRx[(MAX_RX + 1)/ 2];
  uint16 cbcChangedTx[(MAX_TX + 1)/ 2];
  uint16 txGcbc;
}number;

uint16 hybridCBCAutoCorrection(calcStaticConfig_t *cfg, uint16 objectsPresent, uint16 *rawRx, uint16 *rawTx)
{
  uint16 *p = rawRx;
  uint16 returnVal = 0;
  // Check for raw ADC outside of clip boundary
  uint16 i, outsideOfBoundary, correctionMade;
  outsideOfBoundary = 0;
  uint16 numTX = cfg->daqParams.numRows;
  uint16 numRX = cfg->daqParams.numCols;

  #if CONFIG_HYBRID_CBC_CORRECTION_LCBC_CONTROL
  if (!cfg->cbcCorrection_Disable_LCBC_Rx)
  #endif
  {
    for (i = 0; i < numRX; i++)
    {

      if (*p > cfg->upperLimit || *p < cfg->lowerLimit)
      {
        // Outside of the range, flag this pixel
        outsideOfBoundary = 1;
        correctionMade = number.cbcChangedRx[(i/2)];
        correctionMade = (i % 2) ? ((correctionMade & 0xFF00) >> 8) : (correctionMade & 0x00FF);
        if (consistentNoFingerFrames > 16 && (correctionMade < cfg->iterations))
        {
          uint16 ofst, finalDecision, cbcVal;
          uint16 index = cfg->daqParams.imageRxes[i];

          ofst = (2 - index % 3) + ((index/3) * 3);
          cbcVal = DAQ_readVar(CBC_LOCAL_CH2_ABSX_VAL + ofst);

          finalDecision = *p < cfg->lowerLimit ? NEED_TO_INCREASE_CBC : NEED_TO_REDUCE_CBC;
          cbcVal = ajdustLocal(cbcVal, finalDecision);
          DAQ_writeVar(CBC_LOCAL_CH2_ABSX_VAL + ofst, cbcVal);

          correctionMade++;
          number.cbcChangedRx[(i/2)] &= (i % 2) ? 0x00FF : 0xFF00;
          number.cbcChangedRx[(i/2)] |= (i % 2) ? (correctionMade << 8) : correctionMade;
          COMM_updateHybridSingleLocalCBC(i, cbcVal);
          returnVal = 1;
        }
      }
      p++;
    }
  }
  p = rawTx;
  for (i = 0; i < numTX; i++)
  {
    if (*p > cfg->upperLimit || *p < cfg->lowerLimit)
    {
      // Outside of the range, flag this pixel
      outsideOfBoundary = 1;
      correctionMade = number.txGcbc;
      if (consistentNoFingerFrames > 16 /*&& (correctionMade < cfg->iterations)*/)
      {
        if (doLCbcScanNext)
        {
          uint16 ofst, finalDecision, cbcVal;
          uint16 index = cfg->daqParams.imageTxes[i];

          ofst = (2 - index % 3) + ((index/3) * 3);
          cbcVal = DAQ_readVar(CBC_LOCAL_CH2_ABSY_VAL + ofst);

          finalDecision = *p < cfg->lowerLimit ? NEED_TO_INCREASE_CBC : NEED_TO_REDUCE_CBC;
          cbcVal = ajdustLocal(cbcVal, finalDecision);
          DAQ_writeVar(CBC_LOCAL_CH2_ABSY_VAL + ofst, cbcVal);

          correctionMade++;
          number.cbcChangedTx[(i/2)] &= (i % 2) ? 0x00FF : 0xFF00;
          number.cbcChangedTx[(i/2)] |= (i % 2) ? (correctionMade << 8) : correctionMade;
          COMM_updateHybridSingleLocalCBC(MAX_RX + i, cbcVal);
          returnVal = 1;
        } else
        {
          uint16 finalDecision, cbcVal;

          cbcVal = DAQ_readVar(CBC_GLOBAL_CAP_ABSY_VAL);
          if (!powerOn)
          {
            powerOn = 1; origGcbc = cbcVal;
          }
          finalDecision = *p < cfg->lowerLimit ? NEED_TO_REDUCE_CBC : NEED_TO_INCREASE_CBC;

          cbcVal = adjustGlobal(cbcVal, finalDecision, cfg->gcbcSwing);
          DAQ_writeVar(CBC_GLOBAL_CAP_ABSY_VAL, cbcVal);
          correctionMade++;
          number.txGcbc = correctionMade;
          COMM_updateHybridTxGcbc(cbcVal);
        #if CONFIG_HYBRID_CBC_CORRECTION_LCBC_CONTROL
          if (!cfg->cbcCorrection_Disable_LCBC_Tx)
        #endif
          {
            doLCbcScanNext = 1;
          }
          returnVal = 1;
          break;
        }
      }
    }
    p++;
    if ((i == (numTX - 1)) && doLCbcScanNext && (consistentNoFingerFrames > 16))
    {
      doLCbcScanNext = 0;
    }
  }

  if (outsideOfBoundary && (objectsPresent == 0))
  {
    if (consistentNoFingerFrames > 16)
    {
      consistentNoFingerFrames = 0;
    } else
    {
      consistentNoFingerFrames++;
    }
  } else
  {
    consistentNoFingerFrames = 0;
  }
  return returnVal;
}
#endif
