#ifndef _PLATFORM_BASE_H
#define _PLATFORM_BASE_H 1
/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

/**
 * PLFrameData_t decodes all possible frame types. This must match the
 * DAQ program for this platform.
 */

/**
 * PLMode_t defines all possible acquisition modes. If you add a new
 * mode on your platform, you must add it here. Not every sensor will
 * support all acquisition modes.
 */
typedef enum {
  /// No sensing, acquisition state machine halted. Not necessarily low power
  mode_idle,
  /// Sensing at full power
  mode_active,
  /// Sensing reduced data at a low frame rate
  mode_doze,
  /// Sensing with even less data than doze at a low frame rate.
  mode_superdoze,
  /// Sensing reduced data at a low frame rate, with higher sensitivity
  mode_loze,
  /// No sensing, acquisition state machine halted, AFE turned off.
  mode_deepSleep,
  /// Mode B LPWG finger detection
  mode_modeB_lpwg,
  /// Mode B LPWG gesture detection
  mode_modeB_trgt,
  /// Mode B Display refresh
  mode_modeB_display_refresh,
  /// CBC Scan
  mode_cbcScan,
} PLMode_t;

/**
 * PLFrameType_t defines all frame types supported by all platforms.
 * These correspond to the PLMode_t values, but not all modes have
 * corresponding frames.
 */
typedef enum {
  frame_active,
  frame_doze,
  frame_deepsleep,
  frame_restore,
  frame_superdoze,
  frame_loze,
  frame_modeB_lpwg,
  frame_modeB_trgt,
  frame_modeB_display_refresh,
  frame_cbcscan_hybrid,
} PLFrameType_t;

typedef enum {
  PLFramePeriod,
  PLDisableNSM,
  PLObjectPresent,
  PLChargerPresent,
  PLFreqTransCounter,
  PLTouchSensingMode,
  PLESDMode,
  PLGestureDetected,
#if CONFIG_PER_PIXEL_CBCSCAN
  PLPerPixelLocalCBCEnabled,
#endif
#if CONFIG_HAS_ALT_REPORT_RATE
  PLAltReportRate,
#endif
} PLParam_t;

/**
 * PLFrame_t defines a touch data frame. This matches DAQFrame_t in
 * all details except that the frame type is a PLFrameType_t and the
 * buffer is decoded for each frame type.
 */
#ifndef __CHIMERA__
  #pragma pack(push, 2)
#endif
typedef struct {
  /// Time in microseconds when the frame was acquired.
  uint32 timeStamp;

  /// Number of CPU cycles spent acquiring this frame (populated in Slurper only).
  uint32 cycles;

  /// Owning thread, don't mess with this.
  uint16 owner;

  /// The frame number.
  uint16 sequence;

  /// Frame type, as a PLFrameType_t value but stored in a uint16
  uint16 type;

  /// Length of the frame data in 16-bit words.
  uint16 length;

  /// DAQ error flags, don't mess with this.
  uint16 errorFlags;

  /// Decoded frame data.
  PLFrameData_t data;
} PLFrame_t;
#ifndef __CHIMERA__
  #pragma pack(pop)
#endif

/**
 * nsmStateName_t defines the different noise state machine states.
 * All states on all platforms must be included here.
 */
typedef enum {
  /// NSM is disabled.
  nsmState_off,
  /// Hardware noise mitigation only, no firmware help is requested.
  nsmState_hnm,
  /// Firmware noise mitigation, help is requested from firmware to reduce noise.
  nsmState_fnm,
  /// Broadband interference detected, help is requested from firmware to reduce noise.
  nsmState_fnmcid,
} nsmStateName_t;

#if CONFIG_NSM_EUROPA
/**
 */
typedef enum {
  ///
  nsmTran_off,
  ///
  nsmTran_start,
  ///
  nsmTran_on,
  ///
  nsmTran_end,
} nsmTranState_t;

#endif

/**
 * PLNSMState_t reports the noise state machine's current state and
 * noise measurements to the host.
 */
typedef struct {
  /// Power of in-band noise.
  uint16 powerIM;
  /// Indicator of out-of-band noise.
  uint16 cidIM;
  /// Indicator of high-amplitude noise that causes the AFE to clip.
  uint16 railIM;
  /// The current state of the state machine.
  uint16 state;
  /// The current sense frequency index.
  uint16 frequency;
#if CONFIG_NSM_CALLISTO
  /// Indicator of broadband noise.
  uint16 varCidIM;
#endif
#if CONFIG_NSM_EUROPA
  // The current frame rate: 120Hz or 60Hz
  uint16 frameRate;
  // Parameters for baseline shift mitigation
  uint16 frequencyTranState;
  uint16 compLevel;
#endif
} PLNSMState_t;

typedef enum {
  cbc_perPixelLocal,
  cbc_localHybrid,
  cbc_globalHybrid,
} PLCBCType_t;

#if PLATFORM_TD4310 == 1
#include "td4310/production_test.h"
#elif PLATFORM_TD4322 == 1
#include "td4322/production_test.h"
#elif PLATFORM_TD4328 == 1
#include "td4328/production_test.h"
#elif PLATFORM_TD4302 == 1
#include "td4302/production_test.h"
#elif PLATFORM_TD4303 == 1
#include "td4303/production_test.h"
#elif PLATFORM_TD4353 == 1
#include "td4353/production_test.h"
#elif PLATFORM_TD4100 == 1
#include "td4100/production_test.h"

/* Please put other platform definitions in front of PLATFORM_TDDI.
*   Otherwise matlab unittest will include wrong files.
*/
#elif PLATFORM_TDDI == 1
#include "td4300/production_test.h"
#else
#error "No Platform header defined"
#endif

#ifdef __cplusplus
class PlatformApi
{
  public:
  /**
   * Initialize the sensor with the specified dynamic and static
   * configurations.
   */
  void PL_init(struct calcStaticConfig_t *scfg, struct calcDynamicConfig_t *dcfg);

  /**
   * Set Platform parameters from calc
   */
  void PL_setParam(PLParam_t param_type, uint16 param_value);

  /**
   * Call once per frame before entering doze/loze to find out if the
   * doze/loze timer should be reset.
   */
  // FIXME: is this function necessary? Do we have to reset doze when a frequency scan occurs?
  uint16 PL_isDozeTimerResetRequested();

  /**
   * Returns if NSM was initialized or not.
   */
  uint16 PL_isNSMInitialized();

  /**
   * Returns the current noise state machine state and measurements.
   */
  PLNSMState_t PL_getNSMState();

  /**
   * Returns the current # of clusters.
   */
  uint16 PL_getNSMTransClusters();

  /**
   * Returns the current # of noise bursts.
   */
  uint16 PL_getNSMNoiseBursts();

  /**
   * Returns the current # of freqency scan bursts.
   */
  uint16 PL_getNSMFreqScanBursts();

  /**
   * Enters the requested sensing mode. This will perform any side
   * effects required to exit the previous mode and enter the new mode.
   * If already in the requested mode, it will return immediately.
   */
  void PL_enterMode(PLMode_t mode);

  /**
   * Gets a frame of the desired type. If a frame of the requested type
   * has already been acquired, it can be returned immediately. If the
   * requested type is not currently being acquired, data acquisition
   * will stop the current frame, acquire the requested frame, and
   * return to acquiring the previous type. If the requested frame type
   * does not exist, an empty frame will be returned.
   *
   * If the previous frame was not released, it will be released
   * automatically when PL_getFrame() is called.
   */
  PLFrame_t *PL_getFrame(PLFrameType_t frameType);

  /**
   * Releases the previous frame. This is optional becuase PL_getFrame()
   * can automatically release the previous frame. However, calling this
   * explicitly can allow smoother acquisition if any work occurs
   * between processing a frame and calling PL_getFrame() again.
   */
  void PL_releaseFrame(PLFrame_t *frame);

  /**
  * Converts a doze or LPWG mode frame from ADC units to raw capacitance in femtofarads.
  */
  void PL_convertDozeFrameToRawCap(PLFrameData_t *frame, PLCapData_t *cap);

  /**
   * Converts an active-mode frame from ADC units to raw capacitance in femtofarads.
   */
  void PL_convertActiveFrameToRawCap(PLFrameData_t *frame, PLCapData_t *cap);

  /**
   * Converts an active-mode delta frame from ADC units to delta
   * capacitance in femtofarads.
   *
   * Though the PLFrameData_t structure is used with unsigned data
   * types, the actual delta data is stored in signed format.
   */
  void PL_convertActiveFrameToDeltaCap(PLFrameData_t *frame, PLCapData_t *cap);

  /**
   * Acquires a production test frame. The static and dynamic
   * configurations are inputs. The result is an output.
   */
  void PL_getTestFrame(prodTestType_t test, struct calcStaticConfig_t *scfg,
                       struct calcDynamicConfig_t *dcfg, prodTestResult_t *result);

  /**
   * Copy0D button data to image frame buffer for production tests
   * configurations are inputs. The result is an output.
   */
  void PL_copy0DToFrameBuffer(uint16 isAbsBtnData ATTR_UNUSED, uint16 *btnDataPtr, PLFrameData_t *frameBufferPtr);

  /**
   * Scale 0D button response to target range
   * configurations are inputs. The result is an output.
   */
  void PL_0DButtonsScaling (uint16 *btnDataPtr, uint16 *btnScaleFactor);

  /**
   * Checks if doze wakeup threshold is met or not.
   */
  uint16 PL_isDozeWakeUpCondition(struct dozeParams_t *dozeConfig, int16 *deltaImage, uint16 size);

  /**
   * Retrieves the max ADC value for each portion of the active frame.
   * This allows outside code to test for ADC saturation.
   *
   * PLAdcLimits_t is defined in platform_xxxx.h for each platform.
   */
  PLAdcLimits_t PL_getADCLimits();

  /**
   * Convert IFP prarameters from cap to adc
   */
  void PL_convertToIFPFormat(struct calcStaticConfig_t *scfg);

  /**
   * Sets up frequency scan frame
   */
  void PL_setupFreqScanFrame();

  /**
   * Disables up frequency scan frame
   */
  void PL_disableFreqScanFrame();

  /**
   * Sets up receiver offset frame
   */
  void PL_setupRcvrOffsetFrame();

  /**
   * Disables up receiver offset frame
   */
  void PL_disableRcvrOffsetFrame();

  /**
   * Returns receiver offset frame
   */
  PLFrame_t* PL_getRcvrOffsetFrame();

  /**
   * Checks power status and takes appropriate action if necessary
   */
  void PL_checkPowerStatus();

  /**
   * Calibrates button CBCs.
   */
  void PL_calibrateButtons();

  /**
   * Sets touch frame rate.
   */
  void PL_setCurrentRate(uint16 rate);

  /**
   * Returns max abs value in given array.
   */
  uint16 maxAbs(int16 *v, uint16 len);

  /**
   * Perform CBC scans.
   */
  void PL_findBestCbcs(struct calcStaticConfig_t *scfg, PLCBCType_t cbcType);

  /**
   * Retrieve results of CBC scans.
   */
  void PL_getCbcs(PLCBCType_t cbcType, uint16 **CBCs);

  /**
   * Stores/restores active CBC value for LPWG CBC scans.
   */
  void PL_storeCbcs();
  void PL_restoreCbcs();

  /**
   * Update Test Mode LCBCs. For 1 bit LCBC auto servo. (TD4310, TD4100, etc.)
   */
  void PL_updateTestModeLCBC(uint16 *CBCs_L, uint16 *CBCs_R);

};
#endif
#endif
