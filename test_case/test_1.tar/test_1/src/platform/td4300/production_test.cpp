/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */
#include "calc2.h"

#if PLATFORM_TDDI

#include <string.h>
#include <stddef.h>

#include "daq2.h"
#include "calc_print.h"

#include "production_test.h"

formulaVar_t cv;
populateParam_t pp;

typedef struct {
  DAQVarId_t var;
  uint16 val;
} DAQVarStruct_t;

// This is a helper function for writing large groups of variables all
// at once. It's a bit easier to read inline struct definitions than
// a long list of vars followed by a long list of values.
void DAQ_writeVarsStruct(DAQVarStruct_t *s, int16 len)
{
  int16 i, j;
  uint16 vars[8];
  uint16 vals[8];
  DAQVarStruct_t *p = s;
  for (i = len; i > 0; i-=8)
  {
    for (j = 0; j < 8 && j < i; j++)
    {
      vars[j] = p->var;
      vals[j] = p->val;
      p++;
    }
    DAQ_writeVars(vars, vals, j);
  }
}

void loadConvParams(conversionType_t type)
{
  if (type == conversionType_2D)
  {
    cv.rcvrCfb1Enable         = DAQ_readVar(RCVR_CFB1_ENABLE_VAL);
    cv.rcvrFbCapCfb1          = DAQ_readVar(RCVR_FB_CAP_CFB1_VAL);
    cv.refCbMode              = DAQ_readVar(REF_CB_MODE_VAL);
    cv.refRcvrPl              = DAQ_readVar(REF_RCVR_PL_VAL);
    cv.dacIn                  = DAQ_readVar(DAC_IN_VAL);
    cv.refHiCapSel            = (float)(((float)DAQ_readVar(REF_HI_CAP_SEL_VAL)+1.)/2.);
    cv.refLoCapSel            = (float)(((float)DAQ_readVar(REF_LO_CAP_SEL_VAL)+1.)/2.);
  }
  else
  {
    cv.rcvrCfb1Enable         = DAQ_readVar(RCVR_CFB1_ENABLE_0D_VAL);
    cv.rcvrFbCapCfb1          = DAQ_readVar(RCVR_FB_CAP_CFB1_0D_VAL);
    cv.refCbMode              = DAQ_readVar(REF_CB_MODE_0D_VAL);
    cv.refRcvrPl              = DAQ_readVar(REF_RCVR_PL_0D_VAL);
    cv.dacIn                  = DAQ_readVar(BUTTON_DAC_IN_VAL);
    cv.refHiCapSel            = (float)(((float)DAQ_readVar(REF_HI_CAP_SEL_0D_VAL)+1.)/2.);
    cv.refLoCapSel            = (float)(((float)DAQ_readVar(REF_LO_CAP_SEL_0D_VAL)+1.)/2.);
  }
  cv.cbcGlobalEnable          = DAQ_readVar(CBC_GLOBAL_ENABLE_VAL);
  cv.cbcLocalEnable           = DAQ_readVar(CBC_LOCAL_ENABLE_VAL);
  cv.cbcLocalPullBotDisable   = DAQ_readVar(CBC_LOCAL_PULL_BOT_DISABLE_VAL);
  cv.cbcLocalPullBotPl        = DAQ_readVar(CBC_LOCAL_PULL_BOT_PL_VAL);
  cv.cbcLocalXmtrCarrierSel   = DAQ_readVar(CBC_LOCAL_XMTR_CARRIER_SEL_VAL);
  cv.cbcLocalXmtrPl           = DAQ_readVar(CBC_LOCAL_XMTR_PL_VAL);
  cv.dacXmtrStates            = DAQ_readVar(DAC_XMTR_STATES_VAL);
  cv.rcvrCfb1ModeLookup       = DAQ_readVar(RCVR_FB_CAP_MODE_VAL)&DAQ_readVar(RCVR_FB_CAP_VAL)&cv.rcvrFbCapCfb1;
  cv.rcvrCfb1Lookup           = cv.rcvrFbCapCfb1&DAQ_readVar(RCVR_FB_CAP_VAL)&((~cv.rcvrCfb1ModeLookup)&0xF);
  cv.rcvrCfb1Pl               = DAQ_readVar(RCVR_CFB1_PL_VAL);
  cv.refCfb1ModeLookup        = DAQ_readVar(REF_FB_CAP_MODE_VAL)&DAQ_readVar(REF_FB_CAP_VAL)&DAQ_readVar(REF_FB_CAP_CFB1_VAL);
  cv.refCfb1Lookup            = DAQ_readVar(REF_FB_CAP_CFB1_VAL)&DAQ_readVar(REF_FB_CAP_VAL)&((~cv.refCfb1ModeLookup)&0xF);
  cv.refCbcGlobalEnable       = DAQ_readVar(REF_CBC_GLOBAL_ENABLE_VAL);
  cv.refCbcLocalEnable        = DAQ_readVar(REF_CBC_LOCAL_ENABLE_VAL);
  cv.refCbcPullBotDisable     = DAQ_readVar(REF_CBC_LOCAL_PULL_BOT_DISABLE_VAL);
  cv.refCbcPullBootPl         = DAQ_readVar(REF_CBC_LOCAL_PULL_BOT_PL_VAL);
  cv.refCbcXmtrCarrierSel     = DAQ_readVar(REF_CBC_LOCAL_XMTR_CARRIER_SEL_VAL);
  cv.refCbcXmtrPl             = DAQ_readVar(REF_CBC_XMTR_PL_VAL);
  cv.refCfb1Pl                = DAQ_readVar(REF_CFB1_PL_VAL);
  cv.rcvrFbCap                = (float)(DAQ_readVar(RCVR_FB_CAP_VAL)+1.);
  cv.refFbCap                 = (float)(DAQ_readVar(REF_FB_CAP_VAL)+1.);
  cv.refCbcGlobalCapAdj       = (float)(((float)DAQ_readVar(REF_CBC_GLOBAL_CAP_ADJ_VAL)+1.)/2.);
  cv.refHiCbcCapAdj           = (float)(((float)DAQ_readVar(REF_HI_CBC_LOCAL_CAP_ADJ_VAL)+1.)/4.);
  cv.refLoCbcCapAdj           = (float)(((float)DAQ_readVar(REF_LO_CBC_LOCAL_CAP_ADJ_VAL)+1.)/4.);
  cv.refHiCbcCapAdjSum        = (float)(((cv.refCbcGlobalEnable==1)?1.:0.)*cv.refCbcGlobalCapAdj+((cv.refCbcLocalEnable==1)?1.:0.)*cv.refHiCbcCapAdj);
  cv.refLoCbcCapAdjSum        = (float)(((cv.refCbcGlobalEnable==1)?1.:0.)*cv.refCbcGlobalCapAdj+((cv.refCbcLocalEnable==1)?1.:0.)*cv.refLoCbcCapAdj);
  cv.CparasticRcvr            = (float)1.32;
  cv.CparasticRef             = 1.5;
  cv.Vdd                      = 5.5;

  cv.vrefHiCb                 = 0.;
  cv.vrefLoCb                 = 0.;

  if (cv.refCbMode == 1) // 1 == abs cap
  {
    cv.dV                     = (float)(cv.Vdd*(float)cv.dacIn/32.);
    cv.rcvrCfb1ChargeInjected = (float)(cv.rcvrCfb1Enable*((cv.rcvrCfb1Pl==0)?-1.:1.)*(cv.Vdd*cv.rcvrCfb1Lookup+cv.rcvrCfb1ModeLookup*(((cv.dacXmtrStates==1)?(cv.Vdd-cv.dV)/2.:(cv.Vdd+cv.dV)/2.))));

    cv.RefCfb1ChargeInjected  = (float)(((cv.refCfb1Pl==0)?-1.:1.)*(cv.Vdd*cv.refCfb1Lookup+cv.refCfb1ModeLookup*((cv.dacXmtrStates==1)?((cv.Vdd-cv.dV)/2.):((cv.Vdd+cv.dV)/2.))));
    cv.refHiCbcChargeInjected = (float)(cv.refHiCbcCapAdjSum*((((cv.refCbcPullBotDisable == 0) ? 1. : 0.)*((cv.refCbcPullBootPl == 0) ? -1. : 1.)*(cv.Vdd - cv.dV) / 2.) + ((cv.refCbcXmtrCarrierSel == 1) ? 1. : 0.)*((cv.refCbcXmtrPl == 0) ? -1. : 1.)*cv.Vdd + ((cv.refCbcPullBotDisable == 1) ? 1. : 0.)*cv.dV));
    cv.refLoCbcChargeInjected = (float)(cv.refLoCbcCapAdjSum*((((cv.refCbcPullBotDisable == 0) ? 1. : 0.)*((cv.refCbcPullBootPl == 0) ? -1. : 1.)*(cv.Vdd - cv.dV) / 2.) + ((cv.refCbcXmtrCarrierSel == 1) ? 1. : 0.)*((cv.refCbcXmtrPl == 0) ? -1. : 1.)*cv.Vdd + ((cv.refCbcPullBotDisable == 1) ? 1. : 0.)*cv.dV));

    cv.vrefHiAbs              = (float)((cv.Vdd/2.)+((cv.refRcvrPl==1)?1.:-1.)*((cv.dV/2.)*cv.refFbCap+(cv.refHiCapSel+cv.CparasticRef)*cv.dV + cv.RefCfb1ChargeInjected + cv.refHiCbcChargeInjected)/cv.refFbCap);
    cv.vrefLoAbs              = (float)((cv.Vdd/2.)-((cv.refRcvrPl==1)?1.:-1.)*((cv.dV/2.)*cv.refFbCap+(cv.refLoCapSel+cv.CparasticRef)*cv.dV + cv.RefCfb1ChargeInjected + cv.refLoCbcChargeInjected)/cv.refFbCap);
    cv.vrefHiCb               = cv.vrefHiAbs;
    cv.vrefLoCb               = cv.vrefLoAbs;
  }
  else // trans cap
  {
    cv.dV                     = (pp.btnAbsTransMode == BUTTON_MODE_ABS) ? ((float)(cv.Vdd*(float)cv.dacIn/32.)) : cv.Vdd; // assuming trans cap is used only for 0D...
    cv.rcvrCfb1ChargeInjected = (float)(cv.rcvrCfb1Enable*((cv.rcvrCfb1Pl==0)?-1.:1.)*(cv.Vdd*cv.rcvrCfb1Lookup+cv.rcvrCfb1ModeLookup*(((cv.dacXmtrStates==1)?(cv.Vdd-cv.dV)/2.:(cv.Vdd+cv.dV)/2.))));

    cv.CparasticRef           = (float)0.8;
    cv.refModSel              = DAQ_readVar(REF_MOD_SEL_VAL);
    cv.refHiXmtrPl            = ((cv.refModSel==0)?0:1)*DAQ_readVar(REF_HI_XMTR_PL_VAL);
    cv.refLoXmtrPl            = ((cv.refModSel==0)?0:1)*DAQ_readVar(REF_LO_XMTR_PL_VAL);
    cv.vTransmit              = (float)(cv.Vdd*((cv.refModSel==0)?1.:0.)+cv.dV*((cv.refModSel==1)?1.:0.));

    cv.vRefHiTrans            = (float)((cv.Vdd/2.)+((cv.refHiXmtrPl==cv.refRcvrPl)?1.:-1.)*cv.vTransmit*(cv.refHiCapSel+cv.CparasticRef)/cv.refFbCap);
    cv.vRefLoTrans            = (float)((cv.Vdd/2.)-((cv.refLoXmtrPl==cv.refRcvrPl)?1.:-1.)*cv.vTransmit*(cv.refLoCapSel+cv.CparasticRef)/cv.refFbCap);
    cv.vrefHiCb               = cv.vRefHiTrans;
    cv.vrefLoCb               = cv.vRefLoTrans;
  }
}

#if CONFIG_BRING_UP_SIMPLIFICATION //no formula when bring up
void convertImageToDeltaCapacitance(int16 *image ATTR_UNUSED)
{
}
#else
void convertImageToDeltaCapacitance(int16 *image)
{
  float ADC;
  uint16 i, j;

  loadConvParams(conversionType_2D);

  for (i = 0; i < pp.numRows; i++)
  {
    for (j = 0; j < pp.numCols; j++)
    {
      ADC = image[i*MAX_RX+j];
      image[i*MAX_RX+j] = (int16)((ADC/4095.)*(cv.vrefHiCb-cv.vrefLoCb)*(cv.rcvrFbCap/cv.dV)*1000.);
    }
  }
}
#endif

void convertButtonsToDeltaCapacitance(int16 *image ATTR_UNUSED)
{
#if CONFIG_TDDI_AMP_BUTTONS
  float ADC;
  uint16 i;

  loadConvParams(conversionType_0D);

  for(i = 0; i < pp.numBtns; i++)
  {
    ADC = image[i];
    image[i] = (int16)((ADC/4095.)*(cv.vrefHiCb-cv.vrefLoCb)*(cv.rcvrFbCap/cv.dV)*1000.);
  }
#endif
}

uint16 convertDeltaCapacitancetoDeltaADCs(uint16 data)
{
  #if CONFIG_BRING_UP_SIMPLIFICATION //no formula when bring up
  return data;
  #else
  uint16 deltaADC;
  float a;

  loadConvParams(conversionType_2D);

  a = (float)(4095.*cv.dV / (float)(1000.*(cv.vrefHiCb - cv.vrefLoCb)*cv.rcvrFbCap));
  deltaADC = (uint16)((float)data*a);

  return deltaADC;
  #endif
}

#if CONFIG_BRING_UP_SIMPLIFICATION //no formula when bring up
void convertImageToRawCapacitance(uint16 *image ATTR_UNUSED)
{
}
#else
void convertImageToRawCapacitance(uint16 *image)
{
  uint16 i, j;
  float adc;
  float cbcCapAdjSum;
  float cbcGlobalCapAdj;
  float cbcLocalCapAdj;
  float rcvrCbcChargeInjected;
  #if CONFIG_PER_PIXEL_CBCSCAN
    uint16 perPixelCBCEnabled = DAQ_readVar(PER_PIXEL_CBC);
    uint16 *leftCBCs = NULL;
    uint16 *rightCBCs = NULL;

    if (perPixelCBCEnabled)
    {
      uint16 *CBCs[2];

      PL_getCbcs(cbc_perPixelLocal, CBCs);
      leftCBCs = CBCs[0];
      rightCBCs = CBCs[1];
    }
  #endif

  loadConvParams(conversionType_2D);

  for (i = 0; i < pp.numRows; i++)
  {
    uint16 isLeft = ((pp.swapSensorSide == 1) && (i < pp.muxSize[0])) || ((pp.swapSensorSide == 0) && (pp.muxSize[1] <= i));
    cbcGlobalCapAdj = (isLeft) ? (float)DAQ_readVar(L_CBC_GLOBAL_CAP_ADJ_VAL) : (float)DAQ_readVar(R_CBC_GLOBAL_CAP_ADJ_VAL);
    cbcGlobalCapAdj = (float)((cbcGlobalCapAdj + 1.) / 2.);

    for (j = 0; j < pp.numCols; j++)
    {
      #if CONFIG_PER_PIXEL_CBCSCAN
      if (perPixelCBCEnabled)
      {
        if(isLeft)
        {
          uint16 row = (pp.swapSensorSide == 1) ? i : (i - pp.muxSize[1]);
          uint16 offset = row * MAX_RX + j;
          cbcLocalCapAdj = ((float)(leftCBCs[offset])+1.)/4.;
        }
        else
        {
          uint16 row = (pp.swapSensorSide == 1) ? (i - pp.muxSize[0]): i;
          uint16 offset = row * MAX_RX + j;
          cbcLocalCapAdj = ((float)(rightCBCs[offset])+1.)/4.;
        }
      }
      else
      #endif
      {
        cbcLocalCapAdj = (float)((DAQ_readVar(CBC_CAP_ADJ_OVERRIDE_VAL) & 0x0100) ? DAQ_readVar(CBC_CAP_ADJ_OVERRIDE_VAL) & 0xF : ((isLeft) ? DAQ_readVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[j]) : DAQ_readVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[j])));
        cbcLocalCapAdj = (float)((cbcLocalCapAdj + 1.) / 4.);
      }
      cbcCapAdjSum = (float)(((cv.cbcGlobalEnable == 1) ? 1. : 0.)*cbcGlobalCapAdj + ((cv.cbcLocalEnable == 1) ? 1. : 0.)*cbcLocalCapAdj);
      rcvrCbcChargeInjected = (float)(cbcCapAdjSum*((((cv.cbcLocalPullBotDisable == 0) ? 1. : 0.)*((cv.cbcLocalPullBotPl == 0) ? -1. : 1.)*(cv.Vdd - cv.dV) / 2) + ((cv.cbcLocalXmtrCarrierSel == 1) ? 1. : 0.)*((cv.cbcLocalXmtrPl == 0) ? -1. : 1.)*cv.Vdd + ((cv.cbcLocalPullBotDisable == 1) ? 1. : 0.)*cv.dV));

      adc = image[i*MAX_RX+j];
      image[i*MAX_RX+j] = (int16)((((adc/4095.)*(cv.vrefHiCb-cv.vrefLoCb)+cv.vrefLoCb)-(cv.Vdd/2.0)-(cv.dV/2.0)-(rcvrCbcChargeInjected/cv.rcvrFbCap)-(cv.rcvrCfb1ChargeInjected/cv.rcvrFbCap)-(cv.dV*cv.CparasticRcvr/cv.rcvrFbCap))*(cv.rcvrFbCap/cv.dV)*1000.0);
    }
  }
}
#endif

void convertButtonsToRawCapacitance(uint16 *image ATTR_UNUSED)
{
#if CONFIG_TDDI_AMP_BUTTONS
  uint16 i;
  float adc;
  float cbcCapAdjSum;
  float cbcGlobalCapAdj;
  float cbcLocalCapAdj;
  float rcvrCbcChargeInjected;

  loadConvParams(conversionType_0D);

  for(i=0;i<pp.numBtns;++i){
    cbcGlobalCapAdj = (float)(((float)DAQ_readVar(BUTTON_CBC_GLOBAL_CAP_ADJ_VAL)+1.)/2.);
    cbcLocalCapAdj = (float)((DAQ_readVar(CBC_CAP_ADJ_OVERRIDE_VAL) & 0x0100) ? DAQ_readVar(CBC_CAP_ADJ_OVERRIDE_VAL) & 0xF : DAQ_readVar(BUTTON_CBC_VAL_ARRAY + i));
    cbcLocalCapAdj = (float)((cbcLocalCapAdj+1.)/4.);
    cbcCapAdjSum = (float)(((cv.cbcGlobalEnable==1)?1.:0.)*cbcGlobalCapAdj+((cv.cbcLocalEnable==1)?1.:0.)*cbcLocalCapAdj);
    rcvrCbcChargeInjected = (float)(cbcCapAdjSum*((((cv.cbcLocalPullBotDisable==0)?1.:0.)*((cv.cbcLocalPullBotPl==0)?-1.:1.)*(cv.Vdd-cv.dV)/2) + ((cv.cbcLocalXmtrCarrierSel==1)?1.:0.)*((cv.cbcLocalXmtrPl==0)?-1.:1.)*cv.Vdd+((cv.cbcLocalPullBotDisable==1)?1.:0.)*cv.dV));

    adc = image[i];
    image[i] = (int16)((((adc/4095.)*(cv.vrefHiCb-cv.vrefLoCb)+cv.vrefLoCb)-(cv.Vdd/2.)-(cv.dV/2.)-(rcvrCbcChargeInjected/cv.rcvrFbCap)-(cv.rcvrCfb1ChargeInjected/cv.rcvrFbCap)-(cv.dV*cv.CparasticRcvr/cv.rcvrFbCap))*(cv.rcvrFbCap/cv.dV)*1000.);
  }
#endif
}

uint16 convertAbsCapacitanceToADCs(uint16 fF, uint16 isX ATTR_UNUSED, uint16 proxABS ATTR_UNUSED)
{
  return fF;
}

int16 abs16(int16 x) { return (x < 0) ? -x : x; }

uint16 RT95_lcbc_l_15_0[6], RT95_lcbc_l_31_16[6], RT95_lcbc_r_15_0[6], RT95_lcbc_r_31_16[6];
static void setCbcForEtoEShortTest(uint16 steps, uint16* l_cbc,uint16 *r_cbc)
{
#define CBC_ADJ_STEP 6 //per spec
  uint16 step ;
  uint16 i;
  uint16 rxIdx, rxIdx1;
  uint16 l_rx = 0;
  uint16 r_rx = 0;

  uint16 segMax = (pp.numCols+1)/2;
  uint16 subsegMax = segMax/2;
  uint16 l_val;
  uint16 r_val;
  uint16 lcbc_l_15_0 = 0;
  uint16 lcbc_l_31_16 = 0;
  uint16 lcbc_r_15_0 = 0;
  uint16 lcbc_r_31_16 = 0;

  step =  steps;
  switch (step)
  {
    case 1:
      for (rxIdx = 0; rxIdx < segMax; rxIdx++)
      {
        // Set CBC for test
        l_rx = rxIdx;
        r_rx = rxIdx + segMax;
        if(pp.numCols <= r_rx)
           r_rx = pp.numCols - 1;
        {
          l_val = (l_cbc[l_rx] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx] + CBC_ADJ_STEP : l_cbc[l_rx] - CBC_ADJ_STEP;
          r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;

          // Set the adjusted CBC
          DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx], l_val);
          DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
          if(pp.imageRxes[l_rx] < 16)
            lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx]);
          else
            lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx]-16));
          if(pp.imageRxes[r_rx] < 16)
            lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
          else
            lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));
        }
      }
      break;

    case 2:
      for (rxIdx = 0; rxIdx < subsegMax; rxIdx++)
      {
        // Set CBC for test
        l_rx = rxIdx;
        r_rx = rxIdx + subsegMax;
        {
          l_val = (l_cbc[l_rx] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx] + CBC_ADJ_STEP : l_cbc[l_rx] - CBC_ADJ_STEP;
          r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;

          // Set the adjusted CBC
          DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx], l_val);
          DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
          if(pp.imageRxes[l_rx] < 16)
            lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx]);
          else
            lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx]-16));
          if(pp.imageRxes[r_rx] < 16)
            lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
          else
            lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));
        }
      }

      for (l_rx = subsegMax*2, r_rx = segMax+subsegMax; l_rx < segMax+subsegMax; l_rx++, r_rx++)
      {
        // Set CBC for test
        if(r_rx >= pp.numCols)
          r_rx = pp.numCols - 1;
        {
          l_val = (l_cbc[l_rx] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx] + CBC_ADJ_STEP : l_cbc[l_rx] - CBC_ADJ_STEP;
          r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;

          // Set the adjusted CBC
          DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx], l_val);
          DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
          if(pp.imageRxes[l_rx] < 16)
            lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx]);
          else
            lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx]-16));
          if(pp.imageRxes[r_rx] < 16)
            lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
          else
            lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));
        }
      }
      break;

    case 3:
      //left side
      for (rxIdx = 0; rxIdx < subsegMax/2; rxIdx++) //>3
      {
        // Set CBC for test
        l_rx = rxIdx;
        l_val = (l_cbc[l_rx] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx] + CBC_ADJ_STEP : l_cbc[l_rx] - CBC_ADJ_STEP;
        // Set the adjusted CBC
        DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx], l_val);
        if(pp.imageRxes[l_rx] < 16)
          lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx]);
        else
          lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx]-16));

        l_val= (l_cbc[l_rx+subsegMax] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx+subsegMax] + CBC_ADJ_STEP : l_cbc[l_rx+subsegMax] - CBC_ADJ_STEP;
        DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx+ subsegMax], l_val);
        if(pp.imageRxes[l_rx+ subsegMax] < 16)
          lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx+ subsegMax]);
        else
          lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx+ subsegMax]-16));
      }
      for (rxIdx = subsegMax*2, rxIdx1=segMax+subsegMax; rxIdx < subsegMax/2+segMax; rxIdx++, rxIdx1++) //>4
      {
        // Set CBC for test
        l_rx = rxIdx;
        l_val = (l_cbc[l_rx] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx] + CBC_ADJ_STEP : l_cbc[l_rx] - CBC_ADJ_STEP;
        DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx], l_val);
        if(pp.imageRxes[l_rx] < 16)
          lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx]);
        else
          lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx]-16));

        // Set the adjusted CBC
        l_rx = rxIdx1;
        l_val  = (l_cbc[l_rx] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx] + CBC_ADJ_STEP : l_cbc[l_rx] - CBC_ADJ_STEP;
        DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx], l_val);
        if(pp.imageRxes[l_rx] < 16)
          lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx]);
        else
          lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx]-16));
      }
      //right side
      for (rxIdx = subsegMax/2; rxIdx < subsegMax; rxIdx++)
      {
        // Set CBC for test
        r_rx = rxIdx;
        r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;
        DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
        if(pp.imageRxes[r_rx] < 16)
          lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
        else
          lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));

        // Set CBC for test
        r_rx = rxIdx + subsegMax;  //offset + 7
        r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;
        DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
        if(pp.imageRxes[r_rx] < 16)
          lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
        else
          lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));

        // Set CBC for test
        r_rx = rxIdx + segMax;  //offset +15
        r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;
        DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
        if(pp.imageRxes[r_rx] < 16)
          lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
        else
          lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));
      }
      for (rxIdx = (segMax*2)-subsegMax+(subsegMax/2); rxIdx < pp.numCols; rxIdx++)
      {
        // Set the adjusted CBC
        r_rx = rxIdx;
        r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;
        DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
        if(pp.imageRxes[r_rx] < 16)
          lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
        else
          lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));
      }
      break;

    case 4:
      {
        uint16 seqgNode[9] = {0, subsegMax/2, subsegMax, subsegMax+(subsegMax/2), subsegMax*2, segMax+(subsegMax/2), segMax+subsegMax, ((segMax*2)-subsegMax+(subsegMax/2)), pp.numCols};
        uint16 segLength;
        for (i = 0; i < 8; i++)
        {
          segLength = (seqgNode[i+1] - seqgNode[i])/2;
          //left side
          for (rxIdx = seqgNode[i]; rxIdx < (seqgNode[i] + segLength); rxIdx++)
          {
            l_rx = rxIdx;
            l_val = (l_cbc[l_rx] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx] + CBC_ADJ_STEP : l_cbc[l_rx] - CBC_ADJ_STEP;
            DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx], l_val);
            if(pp.imageRxes[l_rx] < 16)
              lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx]);
            else
              lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx]-16));
          }
          //right side
          for (rxIdx = (seqgNode[i] + segLength); rxIdx < seqgNode[i+1]; rxIdx++)
          {
            r_rx = rxIdx;
            r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;
            DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
            if(pp.imageRxes[r_rx] < 16)
              lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
            else
              lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));
          }
        }
      }
      break;

    case 5:
      for (rxIdx = 0; rxIdx < segMax; rxIdx++)
      {
        // Set CBC for test
        l_rx = rxIdx*2;
        l_val = (l_cbc[l_rx] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx] + CBC_ADJ_STEP : l_cbc[l_rx] - CBC_ADJ_STEP;
        // Set the adjusted CBC
        DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx], l_val);
        if(pp.imageRxes[l_rx] < 16)
          lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx]);
        else
          lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx]-16));

        r_rx = rxIdx*2 + 1;
        if(pp.numCols > r_rx)
        {
          r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;
          // Set the adjusted CBC
          DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
          if(pp.imageRxes[r_rx] < 16)
            lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
          else
            lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));
        }
      }
      break;

    case 6:
      for (rxIdx = 0; rxIdx < segMax; rxIdx++)
      {
        // Set CBC for test
        l_rx = rxIdx*2 +1;
        if(pp.numCols > l_rx)
        {
          l_val = (l_cbc[l_rx] + CBC_ADJ_STEP) < 15 ? l_cbc[l_rx] + CBC_ADJ_STEP : l_cbc[l_rx] - CBC_ADJ_STEP;
          // Set the adjusted CBC
          DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[l_rx], l_val);
          if(pp.imageRxes[l_rx] < 16)
            lcbc_l_15_0 |= (0x01 << pp.imageRxes[l_rx]);
          else
            lcbc_l_31_16 |= (0x01 << (pp.imageRxes[l_rx]-16));
        }

        r_rx = rxIdx*2;
        r_val = (r_cbc[r_rx] + CBC_ADJ_STEP) < 15 ? r_cbc[r_rx] + CBC_ADJ_STEP : r_cbc[r_rx] - CBC_ADJ_STEP;
        // Set the adjusted CBC
        DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[r_rx], r_val);
        if(pp.imageRxes[r_rx] < 16)
          lcbc_r_15_0 |= (0x01 << pp.imageRxes[r_rx]);
        else
          lcbc_r_31_16 |= (0x01 << (pp.imageRxes[r_rx]-16));
      }
      break;

    default:
      break;
   }

   if(step >=1 && step <=6)
   {
     RT95_lcbc_l_15_0[step-1] = lcbc_l_15_0;
     RT95_lcbc_l_31_16[step-1] = lcbc_l_31_16;
     RT95_lcbc_r_15_0[step-1] = lcbc_r_15_0;
     RT95_lcbc_r_31_16[step-1] = lcbc_r_31_16;
   }
}

void doEtoeShortTest(struct calcStaticConfig_t *scfg ATTR_UNUSED, prodTestResult_t *result)
{
  uint16 i, j;
  PLFrame_t *f;
  uint16 delta;
  uint16 *b_rslt = result->data.etoeShort;
  uint16 b_base[MAX_TX*MAX_RX];

  // initialization
  memset(&b_rslt[0], 0, MAX_TX*MAX_RX *sizeof(b_rslt[0]));
  memset(&b_rslt[MAX_TX*MAX_RX], 0xFFFF, MAX_TX*MAX_RX*sizeof(b_rslt[0]));

  // Captures a frame with default setting
  f = PL_getFrame(frame_active);
  memcpy(b_base, &f->data.image[0], MAX_TX*MAX_RX*sizeof(f->data.image[0]));
  PL_releaseFrame(f);

  // Based on the value of rxInQ1, calc which CBC needs to be changed
  #define MAX_TURN 6
  uint16 step = 0;

  for (step = 1; step <= MAX_TURN; step++)
  {
    // Set CBC for test
    DAQ_stopAcquisition();
    setCbcForEtoEShortTest(step, &pp.imageCbcs[0], &pp.imageCbcs[MAX_RX]);
    DAQ_startContinuousAcquisition(0);

    // Captures frames with CBC changes
    f = PL_getFrame(frame_active);

    // Calculates result matrixes
    uint16 boundary  = (pp.swapSensorSide) ? pp.muxSize[0] : pp.muxSize[1];
    uint16 l_reg = (pp.swapSensorSide) ? CBC_L_LOCAL_CAP_ADJ_0_VAL : CBC_R_LOCAL_CAP_ADJ_0_VAL;
    uint16 r_reg = (pp.swapSensorSide) ? CBC_R_LOCAL_CAP_ADJ_0_VAL : CBC_L_LOCAL_CAP_ADJ_0_VAL;
    uint16 *l_ptr = (pp.swapSensorSide) ? &pp.imageCbcs[0] : &pp.imageCbcs[MAX_RX];
    uint16 *r_ptr = (pp.swapSensorSide) ? &pp.imageCbcs[MAX_RX] : &pp.imageCbcs[0];

    // Left side
    for (j = 0; j < pp.numCols; j++)
    {
      for (i = 0; i < boundary; i++)
      {
        // Calculates delta
        delta = abs16((int16)(b_base[i*MAX_RX+j] - f->data.image[i*MAX_RX+j]));

        // [1-1] Calculates result matrixes for Max delta of all iterations
        if (DAQ_readVar(l_reg + pp.imageRxes[j]) == l_ptr[j])
        {
          if (delta > b_rslt[i*MAX_RX+j])
          {
            b_rslt[i*MAX_RX+j] = delta;
          }
        }
        // [2-1] Calculates result matrixes for Delta raw cap values of the AFE with CBC adjusted of all iterations
        else
        {
          if (delta < b_rslt[(MAX_TX*MAX_RX) + (i*MAX_RX+j)] )
            b_rslt[(MAX_TX*MAX_RX) + (i*MAX_RX+j)] = delta;
        }
      }
    }

    // Right side
    for (j = 0; j < pp.numCols; j++)
    {
      for (i = boundary; i < pp.numRows; i++)
      {
        // Calculates delta
        delta = abs16((int16)(b_base[i*MAX_RX+j] - f->data.image[i*MAX_RX+j]));

        // [1-2] Calculates result matrixes for Max delta of all iterations
        if (DAQ_readVar(r_reg + pp.imageRxes[j]) == r_ptr[j])
        {
          if (delta > b_rslt[i*MAX_RX+j])
          {
            b_rslt[i*MAX_RX+j] = delta;
          }
        }
        // [2-2] Calculates result matrixes for Delta raw cap values of the AFE with CBC adjusted of all iterations
        else
        {
          if(delta < b_rslt[(MAX_TX*MAX_RX) + (i*MAX_RX+j)] )
            b_rslt[(MAX_TX*MAX_RX) + (i*MAX_RX+j)] = delta;
        }
      }
    }

    // Restore the original CBC
    DAQ_stopAcquisition();
    for (j = 0; j < pp.numCols; j++)
    {
      DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[j], pp.imageCbcs[j]);
      DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + pp.imageRxes[j], pp.imageCbcs[MAX_RX+j]);
    }

    DAQ_startContinuousAcquisition(0);
  }

  // Convert reports results to delta capacitance image from delta ADCs
  convertImageToDeltaCapacitance((int16*)&b_rslt[0]);
  convertImageToDeltaCapacitance((int16*)&b_rslt[MAX_TX*MAX_RX]);

  // reports result
  result->type = IMAGE_REPORT_ETOE_SHORT_RT95;
  result->length = 2*MAX_TX*MAX_RX;
}

int16 calculateMedian(int16 *vals, uint16 num)
{
  int16  buf[MAX_PHY_TX];
  uint16 i, j;
  uint16 tmp;

  for (i = 0; i < num; i++)
  {
    buf[i] = vals[i];
  }

  // slow alorithm...
  for (i = 0; i < num - 1; i++)
  {
    for (j = i + 1; j < num; j++)
    {
      if (buf[j] < buf[i])
      {
        tmp = buf[i];
        buf[i] = buf[j];
        buf[j] = tmp;
      }
    }
  }
  return buf[num / 2];
}

#if !defined(cfg_ESSTest_Integ1)
#define cfg_ESSTest_Integ1 110
#endif
#if !defined(cfg_ESSTest_Integ2)
#define cfg_ESSTest_Integ2 70
#endif
#if !defined(cfg_ESSTest_TxRxOnCount1)
#define cfg_ESSTest_TxRxOnCount1 4
#endif
#if !defined(cfg_ESSTest_TxRxOnCount2)
#define cfg_ESSTest_TxRxOnCount2 4
#endif
void doExtendedSensorSpeedTest(struct calcStaticConfig_t *scfg ATTR_UNUSED, prodTestResult_t *result)
{
  PLFrame_t *f;
  uint16 integ_dur, integ_dur_new, on_cnt_new;
  uint16 i, j;
  uint16 base[MAX_TX*MAX_RX+MAX_BUTTONS];
  int16 *pDelta = result->data.extendedSensorSpeed;

  integ_dur = scfg->daqParams.imageIntegDur;

  // Captures a frame with 110% integration time
  integ_dur_new = (integ_dur * cfg_ESSTest_Integ1) / 100;
  on_cnt_new = integ_dur_new - cfg_ESSTest_TxRxOnCount1;
  {
    DAQVarStruct_t vars[] = {
      { INTEG_DUR_VAL, integ_dur_new },
      { CBC_XMTR_ON_CNT_VAL, on_cnt_new },
      { CBC_RCVR_CONNECT_ON_CNT_VAL, on_cnt_new },
    };
    DAQ_writeVarsStruct(vars, sizeof(vars)/sizeof(vars[0]));
  }
  f = PL_getFrame(frame_active);

  // save base frame on buffer
  memcpy(&base[0], &f->data.image[0], MAX_TX*MAX_RX*sizeof(f->data.image[0]));
  memcpy(&base[MAX_TX*MAX_RX], &f->data.buttons[0], pp.numBtns*sizeof(f->data.buttons[0]));

  PL_releaseFrame(f);

  // captures a frame with 70% integration time
  integ_dur_new = (integ_dur * cfg_ESSTest_Integ2) / 100;
  on_cnt_new = integ_dur_new - cfg_ESSTest_TxRxOnCount2;
  {
    DAQVarStruct_t vars[] = {
      { INTEG_DUR_VAL, integ_dur_new },
      { CBC_XMTR_ON_CNT_VAL, on_cnt_new },
      { CBC_RCVR_CONNECT_ON_CNT_VAL, on_cnt_new },
    };
    DAQ_writeVarsStruct(vars, sizeof(vars)/sizeof(vars[0]));
  }
  f = PL_getFrame(frame_active);

  // calculates ratio
  convertImageToRawCapacitance(&base[0]);
  convertImageToRawCapacitance(f->data.image);
  for (i = 0; i < pp.numRows; i++)
  {
    for (j = 0; j < pp.numCols; j++)
    {
      if (base[i*MAX_RX+j])
        pDelta[i*MAX_RX+j] = (uint16)((uint32)f->data.image[i*MAX_RX+j]*1000 / base[i*MAX_RX+j]);
    }
  }

  convertButtonsToRawCapacitance(&base[MAX_TX*MAX_RX]);
  convertButtonsToRawCapacitance(f->data.buttons);
  for (i = 0; i < pp.numBtns; i++)
  {
    if (base[MAX_TX*MAX_RX+i])
      pDelta[MAX_TX*MAX_RX+i] = (int16)(((uint32)f->data.buttons[i])*100 / base[MAX_TX*MAX_RX+i]);
  }

  // normalizes 2D
  {
    int16 buf[MAX_PHY_TX];
    int16 median;
    uint16 boundary = (scfg->daqParams.swapSensorSide) ? scfg->daqParams.muxSize[0] : scfg->daqParams.muxSize[1];

    //2D processing
    convertImageToDeltaCapacitance(pDelta);
    for (j = 0; j < pp.numCols; j++)
    {
      // left side
      for (i = 0; i < boundary; i++)
      {
        buf[i] = pDelta[i*MAX_RX+j];
      }
      median = calculateMedian(buf, boundary);
      if (median)
      {
        for (i = 0; i < boundary; i++)
        {
          pDelta[i*MAX_RX+j] = abs16((int16)((int32)pDelta[i*MAX_RX+j]*100 / median));
        }
      }
      else
      {
        for (i = 0; i < boundary; i++)
        {
          pDelta[i*MAX_RX+j] = 0;
        }
      }

      // right side
      for (i = boundary; i < pp.numRows; i++)
      {
        buf[i - boundary] = pDelta[i*MAX_RX+j];
      }
      median = calculateMedian(buf, pp.numRows - boundary);
      if (median)
      {
        for (i = boundary; i < pp.numRows; i++)
        {
          pDelta[i*MAX_RX+j] = abs16((int16)((int32)pDelta[i*MAX_RX+j]*100 / median));
        }
      }
      else
      {
        for (i = boundary; i < pp.numRows; i++)
        {
          pDelta[i*MAX_RX+j] = 0;
        }
      }
    }
  }

  PL_releaseFrame(f);

  result->type = IMAGE_REPORT_EXTENDED_SENSOR_SPEED_RT96;
  result->length = MAX_TX*MAX_RX+CONFIG_TDDI_AMP_BUTTONS*MAX_RX;
}

void doAdcSaturationTest(struct calcStaticConfig_t *scfg ATTR_UNUSED, prodTestResult_t *result)
{
  PLFrame_t *f;
  uint16 i, j;
  uint16 max = DAQ_readVar(TRANS_BURSTS_PER_CLUSTER) * 4096 - 1;

  // Captures a frame with default setting
  f = PL_getFrame(frame_active);

  // Checks 2D data
  for (i = 0; i < pp.numRows; i++)
  {
    for (j = 0; j < pp.numCols; j++)
    {
      uint16 val = f->data.image[i*MAX_RX+j];
      result->buffer[i*MAX_RX+j] = (val == 0) || (val == max);
    }
  }

  // Checks 0D data
  for(i = 0; i < pp.numBtns; i++)
  {
    uint16 val = f->data.image[MAX_TX*MAX_RX+i];
    result->buffer[MAX_TX*MAX_RX+i] = (val == 0) || (val == max);
  }

  PL_releaseFrame(f);

  result->type = IMAGE_REPORT_SATURATED_RAW_AMP_ADC_RT105;
  result->length = MAX_TX*MAX_RX+CONFIG_TDDI_AMP_BUTTONS*MAX_RX;
}

#endif //PLATFORM_TDDI
