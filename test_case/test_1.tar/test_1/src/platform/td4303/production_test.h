#ifndef _PRODUCTION_TEST_H
#define _PRODUCTION_TEST_H 1
/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

// This file defines how production test reports are stored. The
// generic test report type is a tagged union with three fields: type,
// length, and data. The data member is as large as the largest
// production test so it can hold the data for any test.

// ALL platforms use the same production test formats. If a production
// test reports different data on a some platform, it should be
// assigned a new type for that platform.

#include "syna/syna_types.h"
#include "calc_config.h"

// production test implementations
typedef enum {
  conversionType_trans,
  conversionType_absx,
  conversionType_absy,
  conversionType_trans0d
} conversionType_t;
typedef struct {
  float refHiCapSel;
  float refLoCapSel;
  float refRcvrFbCap;
  float refRcvrFbCapCfb1;
  float rcvrFbCap;
  float rcvrFbCapCfb1;
  float cbcGlobalGain;
  float cbcGlobalCap;
  float cbcGlobalPl;
  float cbcGlobalEn;
  float cbcLocalRefHi;
  float cbcLocalRefLo;
  float vrefHi;
  float vrefLo;
  float vlsb;
  float tvsp;
  float vref;
  float vmodHi;
  float vmodLo;
  float alpha;
  float dac_in;
  float gain;
  float refGain;
  float cancel;
  float refCancel;
  float cbc;
  uint16 refRcvrFbCapMode;
  uint16 refRcvrPl;
  uint16 refHiXmtrPl;
  uint16 refLoXmtrPl;
  uint16 rcvrFbCapMode;
  uint16 rcvrPl;
}formulaVar_t ;
typedef struct {
  uint16 numRows;
  uint16 numCols;
  uint16 numBtns;
  uint16 imageRxes[MAX_RX];
  uint16 imageTxes[MAX_TX];
  uint16 imageCbcs[MAX_RX];
  uint16 btnAbsTransMode;
  uint16 btnRxes[MAX_BUTTONS];
  uint16 btnGlobalCbc;
  uint16 btnLocalCbcs[MAX_BUTTONS];
  uint16 btnTxRxMask;
} populateParam_t;
typedef struct {
  uint16 rStretchX;
  uint16 rStretchY;
  uint16 deltaRStretch;
  uint16 threshold;
  uint16 consistency;
  uint16 enabled;
} bmConfig_t;
typedef struct {
  uint16 bm;
  uint16 counter;
  uint16 alternate;
  uint16 initialized;
  uint16 lastProfile[MAX_TX];
} bmParam_t;

typedef union {
  uint16 fullRawCap[MAX_TX * MAX_RX];
  int16 highResistance[2*MAX_TX * MAX_RX];
  int16 sensorSpeed[MAX_IMAGE_CLUSTERS * MAX_RX];
  uint16 trexOpenConductiveBar[CONFIG_XMTR_REGS];
  uint16 trexGndConductiveBar[CONFIG_XMTR_REGS];
  uint16 trexShort[CONFIG_XMTR_REGS];
  uint16 gpioOpen[1];
  uint16 gpioShort[1];
  uint16 preDeconvolvedCap[MAX_IMAGE_CLUSTERS * MAX_RX];
  uint16 adcRangeCtLimit[MAX_IMAGE_CLUSTERS * MAX_RX];
  uint16 etoeShort[(MAX_RX * MAX_TX) * 2];
  int16 extendedSensorSpeed[MAX_RX * MAX_TX + MAX_BUTTONS];
  int16 rxRxShort[MAX_RX * MAX_RX];
  int16 txTxShort[MAX_TX * MAX_TX];
} prodTestData_t;

typedef enum {
  prodTestType_fullRawCap,
  prodTestType_highResistance,
  prodTestType_sensorSpeed,
  prodTestType_trexOpenConductiveBar,
  prodTestType_trexGndConductiveBar,
  prodTestType_trexShort,
  prodTestType_gpioShort,
  prodTestType_gpioOpen,
  prodTestType_preDeconvolvedCap,
  prodTestType_adcRangeCtLimit,
  prodTestType_etoeShort,
  prodTestType_extendedSensorSpeed,
  prodTestType_adcSaturation,
  prodTestType_hicRxRxShort,
  prodTestType_hicTxTxShort
} prodTestType_t;

#define TEST_LENGTH_WORDS(x) (sizeof(((ProdTestData_t *)0)->x)/sizeof(uint16))

#define prodTestLength_fullRawCap TEST_LENGTH_WORDS(fullRawCap)
#define prodTestLength_highResistance TEST_LENGTH_WORDS(highResistance)

#define BUTTON_SIMULATE_MODE           1
#define BUTTON_SEPERATE_MODE           2
#define BUTTON_ABS_MODE                0
#define BUTTON_TRANS_MODE              1

typedef struct {
  uint16 type; // must be prodTestType_t
  uint16 length;
  union {
    uint16 buffer[sizeof(prodTestData_t)/sizeof(uint16)];
    prodTestData_t data;
  };
} prodTestResult_t;

extern formulaVar_t cv;
extern populateParam_t pp;
extern bmConfig_t bmConfig;
extern bmParam_t bmParam;

struct calcStaticConfig_t;

void doFullRawCapTest(struct calcStaticConfig_t *scfg, prodTestResult_t *result);
void doAdcSaturationTest(struct calcStaticConfig_t *scfg, prodTestResult_t *result);
void doRxRxShortTest(struct calcStaticConfig_t *scfg, prodTestResult_t *result);
void doTxTxShortTest(struct calcStaticConfig_t *scfg, prodTestResult_t *result);
void convertImageToDeltaCapacitance(int16 *image);
void convertHybridToDeltaCapacitance(int32 *image, uint16 len, conversionType_t type);
void convertButtonsToDeltaCapacitance(int16 *btnData);
void convertImageToRawCapacitance(uint16 *image);
void convertHybridToRawCapacitance(uint32 *image, uint16 len, conversionType_t type);
void convertButtonsToRawCapacitance(uint16 *btnData);
uint16 convertDeltaCapacitanceToADCs(uint16 fF);
uint16 convertDeltaCapacitanceToHybridADCs(uint16 fF, conversionType_t type);
void calculateBurstSpanMetric(uint16 *profile, uint16 size);
void doSensorSpeedTest(struct calcStaticConfig_t *scfg ATTR_UNUSED, prodTestResult_t *result);
#endif // _PRODUCTION_TEST_H
