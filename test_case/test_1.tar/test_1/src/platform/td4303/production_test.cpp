/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */
#include "calc2.h"

#if PLATFORM_TD4303

#include <string.h>
#include <stddef.h>

#include "daq2.h"
#include "calc_print.h"

#include "production_test.h"

#define LEN(x) (sizeof(x)/sizeof(x[0]))
#define ABS(x) ((int16) (x) < 0 ? -(x) : (x))
formulaVar_t cv;
populateParam_t pp;
bmConfig_t bmConfig;
bmParam_t bmParam;

typedef struct {
  DAQVarId_t var;
  uint16 val;
} DAQVarStruct_t;

// This is a helper function for writing large groups of variables all
// at once. It's a bit easier to read inline struct definitions than
// a long list of vars followed by a long list of values.
void DAQ_writeVarsStruct(DAQVarStruct_t *s, int16 len)
{
  int16 i, j;
  uint16 vars[8];
  uint16 vals[8];
  DAQVarStruct_t *p = s;
  for (i = len; i > 0; i-=8)
  {
    for (j = 0; j < 8 && j < i; j++)
    {
      vars[j] = p->var;
      vals[j] = p->val;
      p++;
    }
    DAQ_writeVars(vars, vals, j);
  }
}

inline float lookupLocalCbc(uint16 var)
{
  float rslt = (float)DAQ_readVar(var);
  if (rslt<16)
  {
    rslt = rslt*4./15.;
  }
  else
  {
    rslt = (rslt-16.)*(-4.)/15;
  }
  return rslt;
}

void loadConvParams(conversionType_t type ATTR_UNUSED)
{
  float tmpH;
  float tmpL;

  cv.tvsp = 5.5;
  cv.vref = cv.tvsp/2.;
  cv.refRcvrFbCapMode = DAQ_readVar(REF_FB_CAP_MODE_VAL);
  cv.rcvrFbCapMode = DAQ_readVar(RCVR_FB_CAP_MODE_VAL);
  cv.refHiXmtrPl = DAQ_readVar(REF_HI_XMTR_PL_VAL);
  cv.refLoXmtrPl = DAQ_readVar(REF_HI_XMTR_PL_VAL);

  switch (type)
  {
  case conversionType_trans:
    cv.dac_in = (float)DAQ_readVar(DAC_IN_TRANS_VAL)/32.;

    cv.refHiCapSel = (DAQ_readVar(REF_HI_CAP_SEL_TRANS_VAL)+1.)/2.;
    cv.refLoCapSel = (DAQ_readVar(REF_LO_CAP_SEL_TRANS_VAL)+1.)/2.;
    cv.refRcvrFbCap = DAQ_readVar(REF_FB_CAP_TRANS_VAL)+1.;
    cv.refRcvrFbCapCfb1 = (float)DAQ_readVar(REF_FB_CAP_CFB1_TRANS_VAL);
    cv.refRcvrPl = DAQ_readVar(REF_RCVR_PL_TRANS_VAL);
    cv.rcvrFbCap = DAQ_readVar(RCVR_FB_CAP_TRANS_VAL)+1.;
    cv.rcvrFbCapCfb1 = (float)DAQ_readVar(RCVR_FB_CAP_CFB1_TRANS_VAL);
    cv.rcvrPl = DAQ_readVar(RCVR_PL_TRANS_VAL);

    cv.cbcGlobalGain = DAQ_readVar(CBC_GLOBAL_GAIN_TRANS_VAL)+1.;
    cv.cbcGlobalCap = (DAQ_readVar(CBC_GLOBAL_CAP_TRANS_VAL)+1.)*.75;
    cv.cbcGlobalPl = (float)DAQ_readVar(CBC_GLOBAL_PL_TRANS_VAL);
    cv.cbcGlobalPl = (cv.cbcGlobalPl) ? (-1.):(1.);
    cv.cbcGlobalEn = (float)DAQ_readVar(CBC_GLOBAL_CNVYR_EN_TRANS_VAL);

    cv.cbcLocalRefHi = lookupLocalCbc(CBC_LOCAL_REFHI_TRANS_VAL);
    cv.cbcLocalRefLo = lookupLocalCbc(CBC_LOCAL_REFLO_TRANS_VAL);

    cv.vrefHi = cv.vref;
    cv.vrefLo = cv.vref;
    tmpH = cv.tvsp*(cv.refHiCapSel-1.5*cv.cbcLocalRefHi)/cv.rcvrFbCap;
    tmpL = cv.tvsp*(cv.refLoCapSel-1.5*cv.cbcLocalRefLo)/cv.rcvrFbCap;
    cv.vrefHi += (cv.refHiXmtrPl ^ cv.refRcvrPl)? -tmpH:+tmpH;
    cv.vrefLo += (cv.refLoXmtrPl ^ cv.refRcvrPl)? +tmpL:-tmpL;
    cv.vlsb = (cv.vrefHi-cv.vrefLo)/4096.;
    break;

  case conversionType_absx:
    cv.dac_in = (float)DAQ_readVar(DAC_IN_ABSX_VAL)/32.;

    cv.refHiCapSel = (DAQ_readVar(REF_HI_CAP_SEL_ABSX_VAL)+1.)/2.;
    cv.refLoCapSel = (DAQ_readVar(REF_LO_CAP_SEL_ABSX_VAL)+1.)/2.;
    cv.refRcvrFbCap = DAQ_readVar(REF_FB_CAP_ABSX_VAL)+1.;
    cv.refRcvrFbCapCfb1 = (float)DAQ_readVar(REF_FB_CAP_CFB1_ABSX_VAL);
    cv.refRcvrPl = DAQ_readVar(REF_RCVR_PL_ABSX_VAL);
    cv.rcvrFbCap = DAQ_readVar(RCVR_FB_CAP_ABSX_VAL)+1.;
    cv.rcvrFbCapCfb1 = (float)DAQ_readVar(RCVR_FB_CAP_CFB1_ABSX_VAL);
    cv.rcvrPl = DAQ_readVar(RCVR_PL_ABSX_VAL);

    cv.cbcGlobalGain = DAQ_readVar(CBC_GLOBAL_GAIN_ABSX_VAL)+1.;
    cv.cbcGlobalCap = ((float)DAQ_readVar(CBC_GLOBAL_CAP_ABSX_VAL)+1.)*.75;
    cv.cbcGlobalPl = (float)DAQ_readVar(CBC_GLOBAL_PL_ABSX_VAL);
    cv.cbcGlobalPl = (cv.cbcGlobalPl) ? (1.):(-1.);
    cv.cbcGlobalEn = (float)DAQ_readVar(CBC_GLOBAL_CNVYR_EN_ABSX_VAL);

    cv.cbcLocalRefHi = lookupLocalCbc(CBC_LOCAL_REFHI_ABSX_VAL);
    cv.cbcLocalRefLo = lookupLocalCbc(CBC_LOCAL_REFLO_ABSX_VAL);
    break;

  case conversionType_absy:
    cv.dac_in = (float)DAQ_readVar(DAC_IN_ABSY_VAL)/32.;

    cv.refHiCapSel = (DAQ_readVar(REF_HI_CAP_SEL_ABSY_VAL)+1.)/2.;
    cv.refLoCapSel = (DAQ_readVar(REF_LO_CAP_SEL_ABSY_VAL)+1.)/2.;
    cv.refRcvrFbCap = DAQ_readVar(REF_FB_CAP_ABSY_VAL)+1.;
    cv.refRcvrFbCapCfb1 = (float)DAQ_readVar(REF_FB_CAP_CFB1_ABSY_VAL);
    cv.refRcvrPl = DAQ_readVar(REF_RCVR_PL_ABSY_VAL);
    cv.rcvrFbCap = DAQ_readVar(RCVR_FB_CAP_ABSY_VAL)+1.;
    cv.rcvrFbCapCfb1 = (float)DAQ_readVar(RCVR_FB_CAP_CFB1_ABSY_VAL);
    cv.rcvrPl = DAQ_readVar(RCVR_PL_ABSY_VAL);

    cv.cbcGlobalGain = DAQ_readVar(CBC_GLOBAL_GAIN_ABSY_VAL)+1.;
    cv.cbcGlobalCap = ((float)DAQ_readVar(CBC_GLOBAL_CAP_ABSY_VAL)+1.)*.75;
    cv.cbcGlobalPl = (float)DAQ_readVar(CBC_GLOBAL_PL_ABSY_VAL);
    cv.cbcGlobalPl = (cv.cbcGlobalPl) ? (1.):(-1.);
    cv.cbcGlobalEn = (float)DAQ_readVar(CBC_GLOBAL_CNVYR_EN_ABSY_VAL);

    cv.cbcLocalRefHi = lookupLocalCbc(CBC_LOCAL_REFHI_ABSY_VAL);
    cv.cbcLocalRefLo = lookupLocalCbc(CBC_LOCAL_REFLO_ABSY_VAL);
    break;

  case conversionType_trans0d:
#if CONFIG_TDDI_AMP_BUTTONS
    cv.dac_in = (float)DAQ_readVar(DAC_IN_TRANS0D_VAL)/32.;

    cv.refHiCapSel = (DAQ_readVar(REF_HI_CAP_SEL_TRANS0D_VAL)+1.)/2.;
    cv.refLoCapSel = (DAQ_readVar(REF_LO_CAP_SEL_TRANS0D_VAL)+1.)/2.;
    cv.refRcvrFbCap = DAQ_readVar(REF_FB_CAP_TRANS0D_VAL)+1.;
    cv.refRcvrFbCapCfb1 = (float)DAQ_readVar(REF_FB_CAP_CFB1_TRANS0D_VAL);
    cv.refRcvrPl = DAQ_readVar(REF_RCVR_PL_TRANS0D_VAL);
    cv.rcvrFbCap = DAQ_readVar(RCVR_FB_CAP_TRANS0D_VAL)+1.;
    cv.rcvrFbCapCfb1 = (float)DAQ_readVar(RCVR_FB_CAP_CFB1_TRANS0D_VAL);
    cv.rcvrPl = DAQ_readVar(RCVR_PL_TRANS0D_VAL);

    cv.cbcGlobalGain = DAQ_readVar(CBC_GLOBAL_GAIN_TRANS0D_VAL)+1.;
    cv.cbcGlobalCap = (DAQ_readVar(CBC_GLOBAL_CAP_TRANS0D_VAL)+1.)*.75;
    cv.cbcGlobalPl = (float)DAQ_readVar(CBC_GLOBAL_PL_TRANS0D_VAL);
    cv.cbcGlobalEn = (float)DAQ_readVar(CBC_GLOBAL_CNVYR_EN_TRANS0D_VAL);

    cv.cbcLocalRefHi = lookupLocalCbc(CBC_LOCAL_REFHI_TRANS0D_VAL);
    cv.cbcLocalRefLo = lookupLocalCbc(CBC_LOCAL_REFLO_TRANS0D_VAL);

    cv.vrefHi = cv.vref;
    cv.vrefLo = cv.vref;
    tmpH = cv.tvsp*(cv.refHiCapSel-1.5*cv.cbcLocalRefHi)/cv.rcvrFbCap;
    tmpL = cv.tvsp*(cv.refLoCapSel-1.5*cv.cbcLocalRefLo)/cv.rcvrFbCap;
    cv.vrefHi += (cv.refHiXmtrPl ^ cv.refRcvrPl)? -tmpH:+tmpH;
    cv.vrefLo += (cv.refLoXmtrPl ^ cv.refRcvrPl)? +tmpL:-tmpL;
    cv.vlsb = (cv.vrefHi-cv.vrefLo)/4096.;
#endif
    break;
  }

  cv.vmodHi = cv.vref*(1.+cv.dac_in);
  cv.vmodLo = cv.vref*(1.-cv.dac_in);
  cv.alpha = (cv.vmodHi-cv.vmodLo)/cv.tvsp;

  cv.gain = cv.alpha*cv.tvsp/cv.rcvrFbCap;
  cv.refGain = cv.alpha*cv.tvsp/cv.refRcvrFbCap;
  cv.cancel = (!cv.rcvrFbCapMode)? cv.rcvrFbCapCfb1/cv.alpha-cv.rcvrFbCap/2. : (cv.rcvrFbCapCfb1*(1/cv.alpha-1.)-cv.rcvrFbCap)/2.;
  cv.refCancel = (!cv.refRcvrFbCapMode)? cv.refRcvrFbCapCfb1/cv.alpha-cv.refRcvrFbCap/2. : (cv.refRcvrFbCapCfb1*(1/cv.alpha-1.)-cv.refRcvrFbCap)/2.;
}

#if CONFIG_HAS_HYBRID
void calcHybridConvParams(conversionType_t type, uint16 pos)
{
  float cbcLocalCap;
  float coeff;
  float refCoeff;
  float tmpH;
  float tmpL;

  if (type == conversionType_absx)
  {
    cbcLocalCap = lookupLocalCbc(CBC_LOCAL_CH2_ABSX_VAL+(pp.imageRxes[pos]/3)*3+(2-pp.imageRxes[pos]%3));
  }
  else
  {
    cbcLocalCap = lookupLocalCbc(CBC_LOCAL_CH2_ABSY_VAL+(pp.imageTxes[pos]/3)*3+(2-pp.imageTxes[pos]%3));
  }

  if (cv.alpha != 0.)
  {
    coeff = (cbcLocalCap<0)? (-3.+cv.alpha)/2./cv.alpha : (-3.-cv.alpha)/2./cv.alpha;
    refCoeff = (cv.cbcLocalRefHi<0)? (-3.+cv.alpha)/2./cv.alpha : (-3.-cv.alpha)/2./cv.alpha;
  }
  else
  {
    coeff = -1.;
    refCoeff = -1.;
  }

  cv.vrefHi = cv.vref;
  cv.vrefLo = cv.vref;
  tmpH = cv.refGain*(cv.refHiCapSel-cv.refCancel-cv.cbcLocalRefHi*refCoeff);
  tmpL = cv.refGain*(cv.refLoCapSel-cv.refCancel-cv.cbcLocalRefLo*refCoeff);
  if (cv.refRcvrPl)
  {
    cv.vrefHi += tmpH;
    cv.vrefLo -= tmpL;
  }
  else
  {
    cv.vrefHi -= tmpH;
    cv.vrefLo += tmpL;
  }
  cv.vlsb = (cv.vrefHi-cv.vrefLo)/4096.;
  cv.cbc = cbcLocalCap*coeff+((cv.alpha)? cv.cbcGlobalEn*cv.cbcGlobalCap*cv.cbcGlobalGain/cv.alpha:0.)*cv.cbcGlobalPl*(-1.);
}
#endif

void convertImageToDeltaCapacitance(int16 *image)
{
  uint16 i, j;

  loadConvParams(conversionType_trans);
  for (i = 0; i < pp.numRows; i++)
  {
    for (j = 0; j < pp.numCols; j++)
    {
      image[i*MAX_RX+j] = (int16)(image[i*MAX_RX+j]*cv.vlsb*cv.rcvrFbCap/cv.tvsp*1000.);
    }
  }
}

void convertHybridToDeltaCapacitance(int32 *image ATTR_UNUSED, uint16 len ATTR_UNUSED, conversionType_t type ATTR_UNUSED)
{
#if CONFIG_HAS_HYBRID
  uint16 i;

  loadConvParams(type);
  for (i = 0; i < len; i++)
  {
    calcHybridConvParams(type, i);
    image[i] = (int32)((((float)image[i])*cv.vlsb)/cv.gain*1000.);
  }
#endif
}

void convertButtonsToDeltaCapacitance(int16 *image ATTR_UNUSED)
{
#if CONFIG_TDDI_AMP_BUTTONS
  uint16 i;

  loadConvParams(conversionType_trans0d);
  for(i = 0; i < pp.numBtns; i++)
  {
    image[i] = (int16)(image[i]*cv.vlsb*cv.rcvrFbCap/cv.tvsp*1000.);
  }
#endif
}

uint16 convertDeltaCapacitanceToADCs(uint16 fF)
{
  uint16 deltaADC;

  loadConvParams(conversionType_trans);
  deltaADC = (uint16)((float)fF/1000.*cv.tvsp/cv.vlsb/cv.rcvrFbCap);

  return deltaADC;
}

void convertImageToRawCapacitance(uint16 *image ATTR_UNUSED)
{
  float cbcLocalCap;
  float vadc;
  float tmp;
  uint16 i, j;

  loadConvParams(conversionType_trans);
  for (i = 0; i < pp.numRows; i++)
  {
    for (j = 0; j < pp.numCols; j++)
    {
      cbcLocalCap = lookupLocalCbc(CBC_LOCAL_CH2_TRANS_VAL+(pp.imageRxes[j]/3)*3+(2-pp.imageRxes[j]%3));
      vadc = image[i*MAX_RX+j]*cv.vlsb+cv.vrefLo;
      tmp = (cv.rcvrPl)? (cv.vref-vadc):(cv.vref+vadc);
      image[i*MAX_RX+j] = (int16)((cv.rcvrFbCap*tmp+cv.tvsp*cbcLocalCap*1.5+cv.tvsp*cv.cbcGlobalEn*cv.cbcGlobalCap*cv.cbcGlobalGain)/cv.tvsp*1000.);
    }
  }
}

void convertHybridToRawCapacitance(uint32 *image ATTR_UNUSED, uint16 len ATTR_UNUSED, conversionType_t type ATTR_UNUSED)
{
#if CONFIG_HAS_HYBRID
  float tmp;
  uint16 i;

  loadConvParams(type);
  for (i = 0; i < len; i++)
  {
    calcHybridConvParams(type, i);
    tmp = (cv.rcvrPl)? (((float)image[i])*cv.vlsb+cv.vrefLo-cv.vref):(cv.vref-((float)image[i])*cv.vlsb-cv.vrefLo);
    image[i] = (int32)((tmp/cv.gain+cv.cancel+cv.cbc)*1000.);
  }
#endif
}

void convertButtonsToRawCapacitance(uint16 *image ATTR_UNUSED)
{
#if CONFIG_TDDI_AMP_BUTTONS
  float cbcLocalCap;
  float vadc;
  float tmp;
  uint16 i;

  loadConvParams(conversionType_trans0d);
  for(i=0;i<pp.numBtns;++i){
    cbcLocalCap = lookupLocalCbc(CBC_LOCAL_CH32_TRANS_VAL+(pp.btnRxes[i]/3)*3+(2-pp.btnRxes[i]%3));
    vadc = image[i]*cv.vlsb+cv.vrefLo;
    tmp = (cv.rcvrPl)? (cv.vref-vadc):(cv.vref+vadc);
    image[i] = (int16)((cv.rcvrFbCap*tmp+cv.tvsp*cbcLocalCap*1.5+cv.tvsp*cv.cbcGlobalEn*cv.cbcGlobalCap*cv.cbcGlobalGain)/cv.tvsp*1000.);
  }
#endif
}

uint16 convertDeltaCapacitanceToHybridADCs(uint16 fF, conversionType_t type ATTR_UNUSED)
{
  uint16 deltaADC = fF;
  float gain ATTR_UNUSED;
  float vlsb ATTR_UNUSED;

#if CONFIG_HAS_HYBRID
  loadConvParams(type);
  calcHybridConvParams(type, 0 /* rx independent*/);
  gain = (cv.gain < 0)? -cv.gain:cv.gain;
  vlsb = (cv.vlsb < 0)? -cv.vlsb:cv.vlsb;
  deltaADC = (uint16)(((float)fF)*gain/vlsb/1000.);
#endif

  return deltaADC;
}

void doAdcSaturationTest(struct calcStaticConfig_t *scfg ATTR_UNUSED, prodTestResult_t *result)
{
  PLFrame_t *f;
  uint16 i, j;
  uint16 max = DAQ_readVar(TRANS_BURSTS_PER_CLUSTER) * 4096 - 1;

  // Captures a frame with default setting
  f = PL_getFrame(frame_active);

  // Checks 2D data
  for (i = 0; i < pp.numRows; i++)
  {
    for (j = 0; j < pp.numCols; j++)
    {
      uint16 val = f->data.image[i*MAX_RX+j];
      result->buffer[i*MAX_RX+j] = (val == 0) || (val == max);
    }
  }

  // Checks 0D data
  for(i = 0; i < pp.numBtns; i++)
  {
    uint16 val = f->data.image[MAX_TX*MAX_RX+i];
    result->buffer[MAX_TX*MAX_RX+i] = (val == 0) || (val == max);
  }

  PL_releaseFrame(f);

  result->type = IMAGE_REPORT_SATURATED_RAW_AMP_ADC_RT105;
  result->length = MAX_TX*MAX_RX+CONFIG_TDDI_AMP_BUTTONS*MAX_RX;
}

void doFullRawCapTest(struct calcStaticConfig_t *scfg ATTR_UNUSED, prodTestResult_t *result)
{
    PLFrame_t *f;
    int16 rxOffsets[MAX_RX];
    uint16 i, j;
    uint16 noiseBursts;
    uint16 transBurstsPerCluster;
    uint16 refhi = 15;
    uint16 reflo = 15;

    PL_enterMode(mode_idle);
    DAQ_writeVar(REF_HI_CAP_SEL_TRANS_VAL, refhi);
    DAQ_writeVar(REF_LO_CAP_SEL_TRANS_VAL, reflo);
    {
      // changes them as well, because REF_HI/LO_CAP_SEL are not double-buffered.
      // this is necessary especially when dummy burst between trans/abs doesn't exist.
      DAQ_writeVar(REF_HI_CAP_SEL_ABSX_VAL, refhi);
      DAQ_writeVar(REF_LO_CAP_SEL_ABSX_VAL, reflo);
      DAQ_writeVar(REF_HI_CAP_SEL_ABSY_VAL, refhi);
      DAQ_writeVar(REF_LO_CAP_SEL_ABSY_VAL, reflo);
    }
    DAQ_writeVar(REF_FB_CAP_TRANS_VAL, 15);
    DAQ_writeVar(RCVR_FB_CAP_TRANS_VAL, 15);
    DAQ_writeVar(RCVROFST_ENABLED, 1);
    PL_enterMode(mode_active);

    f = PL_getFrame(frame_active);
    PL_enterMode(mode_idle);

    noiseBursts = scfg->daqParams.noiseBursts;
    transBurstsPerCluster = scfg->daqParams.imageBurstsPerCluster;

    memset(rxOffsets, 0, sizeof(rxOffsets));

    for (i = 0; i < noiseBursts; i++)
    {
      for (j = 0; j < MAX_RX; j++)
      {
        rxOffsets[j] += f->data.noise[i*MAX_RX + j] - 2048;
      }
    }

    for (i = 0; i < MAX_RX; i++)
    {
      int32 t;
      t = (int32) rxOffsets[i] * transBurstsPerCluster;
      t += noiseBursts/2;
      t /= noiseBursts;
      rxOffsets[i] = t;
    }
    PL_releaseFrame(f);
    DAQ_writeVar(RCVROFST_ENABLED, 0);
    PL_enterMode(mode_active);
    f = PL_getFrame(frame_active);
    PL_enterMode(mode_idle);

    for (j = 0; j < MAX_RX; j++)
    {
      for (i = 0; i < MAX_TX; i++)
      {
        f->data.image[i*MAX_RX + j] -= rxOffsets[j];
      }
    }

    convertImageToRawCapacitance(&(f->data.image[0]));

    memcpy(result->data.fullRawCap, f->data.image, MAX_RX*MAX_TX*sizeof(f->data.image[0]));
    PL_releaseFrame(f);

    result->type = IMAGE_REPORT_FULL_RAW_CAP_IMAGE_RXOFFSETS_RT20;
    result->length = MAX_RX*MAX_TX;

}

void doRxRxShortTest(struct calcStaticConfig_t *scfg ATTR_UNUSED, prodTestResult_t *result)
{
  PLFrame_t *f;
  uint16 baseline[MAX_RX];
  uint16 i, j;
  uint16 ofst;
  uint16 refhi = 15;
  uint16 reflo = 15;

  PL_enterMode(mode_idle);
  PL_setParam(PLDisableNSM, 1);

  // wide opens hybrid abs references for both tx and rx
  DAQ_writeVar(REF_HI_CAP_SEL_ABSX_VAL, refhi);
  DAQ_writeVar(REF_LO_CAP_SEL_ABSX_VAL, reflo);
  {
    // changes them as well, because REF_HI/LO_CAP_SEL are not double-buffered.
    // this is necessary especially when dummy burst between trans/abs doesn't exist.
    DAQ_writeVar(REF_HI_CAP_SEL_TRANS_VAL, refhi);
    DAQ_writeVar(REF_LO_CAP_SEL_TRANS_VAL, reflo);
    DAQ_writeVar(REF_HI_CAP_SEL_ABSY_VAL, refhi);
    DAQ_writeVar(REF_LO_CAP_SEL_ABSY_VAL, reflo);
  }
  DAQ_writeVar(REF_FB_CAP_ABSX_VAL,     15);

  // gets baseline
  {
    // gets hybrid abs adc data
    PL_enterMode(mode_active);
    f = PL_getFrame(frame_active);
    memcpy(baseline, f->data.hybridX, MAX_RX*sizeof(baseline[0]));
    PL_releaseFrame(f);
    PL_enterMode(mode_idle);
  }

  // gets delta
  for (j = 0; j < pp.numCols; j++)
  {
    uint16 cbcVal, origVal;
    ofst = (2 - j % 3) + ((j/3) * 3);

    origVal = DAQ_readVar(CBC_LOCAL_CH2_ABSX_VAL + ofst);
    cbcVal = origVal;
    if (cbcVal & 0x0010)
    {
      cbcVal &= 0x0F;
      cbcVal *= -1;
    }
    cbcVal += 6;
    if ((int16) cbcVal < 0)
    {
      cbcVal *= -1;
      cbcVal |= 0x0010;
    } else if (cbcVal > 0x0F)
    {
      cbcVal = origVal - 6;
    }
    DAQ_writeVar(CBC_LOCAL_CH2_ABSX_VAL + ofst, cbcVal);

    // gets hybrid abs adc data
    PL_enterMode(mode_active);
    f = PL_getFrame(frame_active);
    for (i = 0; i < pp.numCols; i++)
    {
      result->data.rxRxShort[MAX_RX*j+i] = ABS((int16)(f->data.hybridX[i] - baseline[i]));
    }
    // Restore CBC
    DAQ_writeVar(CBC_LOCAL_CH2_ABSX_VAL + ofst, origVal);
    PL_releaseFrame(f);
    PL_enterMode(mode_idle);
  }

  // reports data
  result->type = IMAGE_REPORT_RX_RX_SHORT_RT125;
  result->length = MAX_RX*MAX_RX;
}

void doTxTxShortTest(struct calcStaticConfig_t *scfg ATTR_UNUSED, prodTestResult_t *result)
{
  PLFrame_t *f;
  uint16 baseline[MAX_TX];
  uint16 i, j;
  uint16 ofst;
  uint16 refhi = 15;
  uint16 reflo = 15;

  PL_enterMode(mode_idle);
  PL_setParam(PLDisableNSM, 1);

  // wide opens hybrid abs references for both tx and rx
  DAQ_writeVar(REF_HI_CAP_SEL_ABSX_VAL, refhi);
  DAQ_writeVar(REF_LO_CAP_SEL_ABSX_VAL, reflo);
  {
    // changes them as well, because REF_HI/LO_CAP_SEL are not double-buffered.
    // this is necessary especially when dummy burst between trans/abs doesn't exist.
    DAQ_writeVar(REF_HI_CAP_SEL_TRANS_VAL, refhi);
    DAQ_writeVar(REF_LO_CAP_SEL_TRANS_VAL, reflo);
    DAQ_writeVar(REF_HI_CAP_SEL_ABSY_VAL, refhi);
    DAQ_writeVar(REF_LO_CAP_SEL_ABSY_VAL, reflo);
  }
  DAQ_writeVar(REF_FB_CAP_ABSY_VAL,     15);

  // gets baseline
  {
    // gets hybrid abs adc data
    PL_enterMode(mode_active);
    f = PL_getFrame(frame_active);
    memcpy(baseline, f->data.hybridY, MAX_TX*sizeof(baseline[0]));
    PL_releaseFrame(f);
    PL_enterMode(mode_idle);
  }

  // gets delta
  for (j = 0; j < pp.numRows; j++)
  {
    uint16 origVal,cbcVal;
    ofst = (2 - j % 3) + ((j/3) * 3);

    origVal = DAQ_readVar(CBC_LOCAL_CH2_ABSY_VAL + ofst);
    cbcVal = origVal;
    if (cbcVal & 0x0010)
    {
      cbcVal &= 0x0F;
      cbcVal *= -1;
    }
    cbcVal += 8;
    if ((int16) cbcVal < 0)
    {
      cbcVal *= -1;
      cbcVal |= 0x0010;
    } else if (cbcVal > 0x0F)
    {
      cbcVal = origVal - 8;
    }
    DAQ_writeVar(CBC_LOCAL_CH2_ABSY_VAL + ofst, cbcVal);

    // gets hybrid abs adc data
    PL_enterMode(mode_active);
    f = PL_getFrame(frame_active);
    for (i = 0; i < pp.numRows; i++)
    {
      result->data.txTxShort[MAX_TX*j+i] = ABS((int16)(f->data.hybridY[i] - baseline[i]));
    }
    // Restore CBC
    DAQ_writeVar(CBC_LOCAL_CH2_ABSY_VAL + ofst, origVal);
    PL_releaseFrame(f);
    PL_enterMode(mode_idle);
  }

  // reports data
  result->type = IMAGE_REPORT_TX_TX_SHORT_RT126;
  result->length = MAX_TX*MAX_TX;
}

void doSensorSpeedTest(struct calcStaticConfig_t *scfg ATTR_UNUSED, prodTestResult_t *result)
{
  uint16 row,col, buff1[MAX_RX*MAX_TX];
  PLFrame_t *f;
  PL_enterMode(mode_active);
  f = PL_getFrame(frame_active);
  memcpy(buff1, f->data.image, (MAX_TX * MAX_RX) * sizeof(buff1[0]));

  PL_releaseFrame(f);
  PL_enterMode(mode_idle);
  //Reduce integration to 80%
  {
    uint16 temp = (uint16)(((uint32) scfg->daqParams.imageIntegDur * 8) / 10);
    // Hope 'temp' is not 0, it shouldn't be
    DAQ_writeVar(INTEG_DUR_TRANS_VAL, temp);
    DAQ_writeVar(CBC_XMTR_ON_CNT_TRANS_VAL, (temp - 4));
    DAQ_writeVar(CBC_RCVR_CONNECT_ON_CNT_TRANS_VAL, (temp - 4));
  }
  PL_enterMode(mode_active);
  f = PL_getFrame(frame_active);
  // Now calculate the difference
  for (row = 0; row < pp.numRows; row++)
  {
    for (col = 0; col < pp.numCols; col++)
    {
      buff1[MAX_RX*row + col] = buff1[MAX_RX * row + col] - f->data.image[MAX_RX * row + col];
    }
  }
  PL_releaseFrame(f);
  PL_enterMode(mode_idle);

  convertImageToDeltaCapacitance((int16*) &buff1[0]);
  memcpy(result->data.sensorSpeed, buff1, (MAX_TX * MAX_RX) * sizeof(buff1[0]));
  result->type = IMAGE_REPORT_SENSOR_SPEED_TEST_RT22;
  result->length = MAX_TX*MAX_RX;
}
void calculateBurstSpanMetric(uint16 *profile, uint16 size)
{
  uint16 diff;
  uint16 pos;
  uint16 *ptr;

  bmParam.bm = 0;

  // calculates bm for this frame.
  if (bmParam.initialized)
  {
    ptr = profile;
    for (pos = 0; pos < size; pos++, ptr++)
    {
      if (bmParam.lastProfile[pos] < *ptr)
      {
        diff = *ptr - bmParam.lastProfile[pos];
      }
      else
      {
        diff = bmParam.lastProfile[pos] - *ptr;
      }
      if (bmParam.bm < diff)
        bmParam.bm = diff;
    }
  }

  // stores current profile for next frame.
  ptr = profile;
  for (pos = 0; pos < size; pos++, ptr++)
  {
    bmParam.lastProfile[pos] = *ptr;
  }
  bmParam.initialized = 1;
}


#endif //PLATFORM_TD4303
