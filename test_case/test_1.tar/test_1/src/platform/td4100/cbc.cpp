/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2017  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include <string.h>
#include <stddef.h>
#include "calc2.h"

#if PLATFORM_TD4100 == 1        /* if not bypass this file completely */

/*
 * Empty source file so that we can always specify it is a platform file that
 * needs building
 */

#endif // PLATFORM_TD4100 == 1        /* if not bypass this file completely */
