#ifndef _PLATFORM_CBC_H_
#define _PLATFORM_CBC_H_
/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include "daq2.h"
#include "platform.h"

struct calcStaticConfig_t;

#ifdef __cplusplus
extern "C"{
#endif
void findBestPerPixelLocalCbcs(struct calcStaticConfig_t *scfg);
void getPerPixelLocalCbcs(uint16 **CBCs);
void findBestGlobalCbcsHybrid(struct calcStaticConfig_t *scfg);
void findBestLocalCbcsHybrid(struct calcStaticConfig_t *scfg);
#if CONFIG_HYBRID_CBC_CORRECTION
uint16 hybridCBCAutoCorrection(struct calcStaticConfig_t *cfg, uint16 objectsPresent, uint16 *rawRx, uint16 *rawTx);
#endif
#ifdef __cplusplus
}
#endif

#endif
