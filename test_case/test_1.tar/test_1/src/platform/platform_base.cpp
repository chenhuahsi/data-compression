/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include "platform.h"
#include "calc2.h"

// fill this with default implementations of functions. The rule is
// that if you implement a function, you set
// "PLATFORM_IMPLEMENTED_XXXXX" to 1 for the function named XXXXX in
// your platform's header file. This will get included via platform.h.

void PlatformApi::PL_init(struct calcStaticConfig_t *scfg ATTR_UNUSED, struct calcDynamicConfig_t *dcfg ATTR_UNUSED)
{
}

void PlatformApi::PL_enterMode(PLMode_t newMode ATTR_UNUSED)
{
}

PLFrame_t* PlatformApi::PL_getFrame(PLFrameType_t frameType ATTR_UNUSED)
{
  return 0;
}

void PlatformApi::PL_releaseFrame(PLFrame_t *f ATTR_UNUSED)
{
}

uint16 PlatformApi::PL_isNSMInitialized()
{
  return 1;
}

PLNSMState_t PlatformApi::PL_getNSMState()
{
  PLNSMState_t state;
  uint16* pstate = (uint16*)&state;
  uint16 i;

  for (i = 0; i< sizeof(PLNSMState_t)/sizeof(uint16); i++)
  {
    *pstate++ = 0;
  }

  return state;
}

uint16 PlatformApi::PL_getNSMTransClusters()
{
  return 0;
}

uint16 PlatformApi::PL_getNSMNoiseBursts()
{
  return 0;
}

uint16 PlatformApi::PL_getNSMFreqScanBursts()
{
  return 0;
}

void PlatformApi::PL_convertDozeFrameToRawCap(PLFrameData_t *frame ATTR_UNUSED, PLCapData_t *cap ATTR_UNUSED)
{
}

void PlatformApi::PL_convertActiveFrameToRawCap(PLFrameData_t *frame ATTR_UNUSED, PLCapData_t *cap ATTR_UNUSED)
{
  // FIXME: implement
}

void PlatformApi::PL_convertActiveFrameToDeltaCap(PLFrameData_t *frame ATTR_UNUSED, PLCapData_t *cap ATTR_UNUSED)
{
  // FIXME: implement
}

void PlatformApi::PL_getTestFrame(prodTestType_t test ATTR_UNUSED, struct calcStaticConfig_t *scfg ATTR_UNUSED,
                     struct calcDynamicConfig_t *dcfg ATTR_UNUSED, prodTestResult_t *result ATTR_UNUSED)
{
  // FIXME: implement
}

PLAdcLimits_t PlatformApi::PL_getADCLimits()
{
  PLAdcLimits_t v;
  uint16* pv = (uint16*)&v;
  uint16 i;

  for (i = 0; i< sizeof(PLAdcLimits_t)/sizeof(uint16); i++)
  {
    *pv++ = 0;
  }

  return v;
}

void PlatformApi::PL_setParam(PLParam_t param_type ATTR_UNUSED, uint16 param_value ATTR_UNUSED)
{
}

uint16 PlatformApi::PL_isDozeTimerResetRequested()
{
  return 0;
}

void PlatformApi::PL_convertToIFPFormat(calcStaticConfig_t *scfg ATTR_UNUSED)
{
}

void PlatformApi::PL_copy0DToFrameBuffer(uint16 isAbsBtnData ATTR_UNUSED, uint16 *btnDataPtr ATTR_UNUSED, PLFrameData_t *frameBufferPtr ATTR_UNUSED)
{
}

void PlatformApi::PL_0DButtonsScaling(uint16 *btnDataPtr ATTR_UNUSED, uint16 *btnScaleFactor ATTR_UNUSED)
{
}

uint16 PlatformApi::PL_isDozeWakeUpCondition(dozeParams_t *dozeConfig, int16 *deltaImage, uint16 size ATTR_UNUSED)
{
  return (maxAbs(&deltaImage[0], size) > dozeConfig->dozeWakeUpThreshold);
}

void PlatformApi::PL_setupFreqScanFrame()
{
}

void PlatformApi::PL_disableFreqScanFrame()
{
}

void PlatformApi::PL_setupRcvrOffsetFrame()
{
}

void PlatformApi::PL_disableRcvrOffsetFrame()
{
}

PLFrame_t *PlatformApi::PL_getRcvrOffsetFrame()
{
  return PL_getFrame(frame_active);
}

void PlatformApi::PL_checkPowerStatus()
{
}

void PlatformApi::PL_calibrateButtons()
{
}

void PlatformApi::PL_setCurrentRate(uint16 rate ATTR_UNUSED)
{
}

void PlatformApi::PL_findBestCbcs(struct calcStaticConfig_t *scfg ATTR_UNUSED, PLCBCType_t cbcType ATTR_UNUSED)
{
}

void PlatformApi::PL_getCbcs(PLCBCType_t cbcType ATTR_UNUSED, uint16 **CBCs ATTR_UNUSED)
{
}

void PlatformApi::PL_storeCbcs()
{
}

void PlatformApi::PL_restoreCbcs()
{
}

void PlatformApi::PL_updateTestModeLCBC(uint16 *CBCs_L ATTR_UNUSED, uint16 *CBCs_R ATTR_UNUSED)
{
}

uint16 PlatformApi::maxAbs(int16 *v, uint16 len)
{
  uint16 max = 0;
  uint16 x;
  while(len--)
  {
    x = (*v < 0) ? -*v : *v;
    max = (x > max) ? x : max;
    v++;
  }
  return max;
}

/*
*  pure C wrapper functions for platformapis
*/
extern "C" void PL_init(struct calcStaticConfig_t *scfg, struct calcDynamicConfig_t *dcfg)
{
  platformapi.PL_init(scfg, dcfg);
}
extern "C" void PL_setParam(PLParam_t param_type, uint16 param_value)
{
  platformapi.PL_setParam(param_type, param_value);
}
extern "C" uint16 PL_isDozeTimerResetRequested()
{
  return platformapi.PL_isDozeTimerResetRequested();
}
extern "C" uint16 PL_isNSMInitialized()
{
  return platformapi.PL_isNSMInitialized();
}
extern "C" PLNSMState_t PL_getNSMState()
{
  return platformapi.PL_getNSMState();
}
extern "C" uint16 PL_getNSMTransClusters()
{
  return platformapi.PL_getNSMTransClusters();
}
extern "C" uint16 PL_getNSMNoiseBursts()
{
  return platformapi.PL_getNSMNoiseBursts();
}
extern "C" uint16 PL_getNSMFreqScanBursts()
{
  return platformapi.PL_getNSMFreqScanBursts();
}
extern "C" void PL_enterMode(PLMode_t mode)
{
  platformapi.PL_enterMode(mode);
}
extern "C" PLFrame_t *PL_getFrame(PLFrameType_t frameType)
{
  return platformapi.PL_getFrame(frameType);
}
extern "C" void PL_releaseFrame(PLFrame_t *frame)
{
  platformapi.PL_releaseFrame(frame);
}
extern "C" void PL_convertDozeFrameToRawCap(PLFrameData_t *frame, PLCapData_t *cap)
{
  platformapi.PL_convertDozeFrameToRawCap(frame, cap);
}
extern "C" void PL_convertActiveFrameToRawCap(PLFrameData_t *frame, PLCapData_t *cap)
{
  platformapi.PL_convertActiveFrameToRawCap(frame, cap);
}
extern "C" void PL_convertActiveFrameToDeltaCap(PLFrameData_t *frame, PLCapData_t *cap)
{
  platformapi.PL_convertActiveFrameToDeltaCap(frame, cap);
}
extern "C" void PL_getTestFrame(prodTestType_t test, struct calcStaticConfig_t *scfg,
                     struct calcDynamicConfig_t *dcfg, prodTestResult_t *result)
{
  platformapi.PL_getTestFrame(test, scfg, dcfg, result);
}
extern "C" void PL_copy0DToFrameBuffer(uint16 isAbsBtnData, uint16 *btnDataPtr, PLFrameData_t *frameBufferPtr)
{
  platformapi.PL_copy0DToFrameBuffer(isAbsBtnData, btnDataPtr, frameBufferPtr);
}
extern "C" void PL_0DButtonsScaling(uint16 *btnDataPtr, uint16 *btnScaleFactor)
{
  platformapi.PL_0DButtonsScaling(btnDataPtr, btnScaleFactor);
}
extern "C" uint16 PL_isDozeWakeUpCondition(struct dozeParams_t *dozeConfig, int16 *deltaImage, uint16 size)
{
  return platformapi.PL_isDozeWakeUpCondition(dozeConfig, deltaImage, size);
}
extern "C" PLAdcLimits_t PL_getADCLimits()
{
  return platformapi.PL_getADCLimits();
}
extern "C" void PL_convertToIFPFormat(struct calcStaticConfig_t *scfg)
{
  platformapi.PL_convertToIFPFormat(scfg);
}
extern "C" void PL_setupFreqScanFrame()
{
  return platformapi.PL_setupFreqScanFrame();
}
extern "C" void PL_disableFreqScanFrame()
{
  return platformapi.PL_disableFreqScanFrame();
}
extern "C" void PL_setupRcvrOffsetFrame()
{
  return platformapi.PL_setupRcvrOffsetFrame();
}
extern "C" void PL_disableRcvrOffsetFrame()
{
  return platformapi.PL_disableRcvrOffsetFrame();
}
extern "C" PLFrame_t *PL_getRcvrOffsetFrame()
{
  return platformapi.PL_getRcvrOffsetFrame();
}
extern "C" void PL_checkPowerStatus()
{
  return platformapi.PL_checkPowerStatus();
}
extern "C" void PL_calibrateButtons()
{
  return platformapi.PL_calibrateButtons();
}
extern "C" void PL_setCurrentRate(uint16 rate)
{
  return platformapi.PL_setCurrentRate(rate);
}
extern "C" void PL_findBestCbcs(struct calcStaticConfig_t *scfg, PLCBCType_t cbcType)
{
  platformapi.PL_findBestCbcs(scfg, cbcType);
}
extern "C" void PL_getCbcs(PLCBCType_t cbcType, uint16 **CBCs)
{
  platformapi.PL_getCbcs(cbcType, CBCs);
}
extern "C" void PL_storeCbcs()
{
  platformapi.PL_storeCbcs();
}
extern "C" void PL_restoreCbcs()
{
  platformapi.PL_restoreCbcs();
}
extern "C" void PL_updateTestModeLCBC(uint16 *CBCs_L, uint16 *CBCs_R)
{
  platformapi.PL_updateTestModeLCBC(CBCs_L, CBCs_R);
}
extern "C" uint16 PL_hybridCBCAutoCorrection(struct calcStaticConfig_t *cfg ATTR_UNUSED, uint16 objectsPresent ATTR_UNUSED, uint16 *rawRx ATTR_UNUSED, uint16 *rawTx ATTR_UNUSED)
{
  #if CONFIG_HYBRID_CBC_CORRECTION
    return platformapi.PL_hybridCBCAutoCorrection(cfg, objectsPresent, rawRx, rawTx);
  #else
    return 0;
  #endif
}
