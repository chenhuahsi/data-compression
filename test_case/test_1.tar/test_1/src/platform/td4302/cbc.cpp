/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include <string.h>
#include <stddef.h>
#include "calc2.h"

#if PLATFORM_TD4302 == 1        /* if not bypass this file completely */
#include "platform.h"

#if CONFIG_PER_PIXEL_CBCSCAN
  #include "../platform_cbc.h"
#endif

void PlatformApi_td4302::PL_findBestCbcs(struct calcStaticConfig_t *scfg ATTR_UNUSED, PLCBCType_t cbcType)
{
  if (cbcType == cbc_perPixelLocal)
  {
    #if CONFIG_PER_PIXEL_CBCSCAN
      findBestPerPixelLocalCbcs(scfg);
    #endif
  }
}

void PlatformApi_td4302::PL_getCbcs(PLCBCType_t cbcType, uint16 **CBCs ATTR_UNUSED)
{
  if (cbcType == cbc_perPixelLocal)
  {
    #if CONFIG_PER_PIXEL_CBCSCAN
      getPerPixelLocalCbcs(CBCs);
    #endif
  }
}

#endif // PLATFORM_TD4302 == 1        /* if not bypass this file completely */
