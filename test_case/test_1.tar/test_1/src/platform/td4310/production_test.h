#ifndef _PRODUCTION_TEST_H
#define _PRODUCTION_TEST_H 1
/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

// This file defines how production test reports are stored. The
// generic test report type is a tagged union with three fields: type,
// length, and data. The data member is as large as the largest
// production test so it can hold the data for any test.

// ALL platforms use the same production test formats. If a production
// test reports different data on a some platform, it should be
// assigned a new type for that platform.

#include "syna/syna_types.h"
#include "calc_config.h"

typedef union {
  uint16 fullRawCap[MAX_TX * MAX_RX];
  int16 highResistance[2*MAX_TX * MAX_RX];
  int16 sensorSpeed[MAX_IMAGE_CLUSTERS * MAX_RX];
  uint16 trexOpenConductiveBar[CONFIG_XMTR_REGS];
  uint16 trexGndConductiveBar[CONFIG_XMTR_REGS];
  uint16 trexShort[CONFIG_XMTR_REGS];
  uint16 gpioOpen[1];
  uint16 gpioShort[1];
  uint16 preDeconvolvedCap[MAX_IMAGE_CLUSTERS * MAX_RX];
  uint16 adcRangeCtLimit[MAX_IMAGE_CLUSTERS * MAX_RX];
  uint16 etoeShort[(MAX_RX * MAX_TX) * 2];
  int16 extendedSensorSpeed[MAX_RX * MAX_TX + MAX_BUTTONS];
} prodTestData_t;

typedef enum {
  prodTestType_fullRawCap,
  prodTestType_highResistance,
  prodTestType_sensorSpeed,
  prodTestType_trexOpenConductiveBar,
  prodTestType_trexGndConductiveBar,
  prodTestType_trexShort,
  prodTestType_gpioShort,
  prodTestType_gpioOpen,
  prodTestType_preDeconvolvedCap,
  prodTestType_adcRangeCtLimit,
  prodTestType_etoeShort,
  prodTestType_extendedSensorSpeed,
  prodTestType_adcSaturation,
} prodTestType_t;

#define TEST_LENGTH_WORDS(x) (sizeof(((ProdTestData_t *)0)->x)/sizeof(uint16))

#define prodTestLength_fullRawCap TEST_LENGTH_WORDS(fullRawCap)
#define prodTestLength_highResistance TEST_LENGTH_WORDS(highResistance)

typedef struct {
  uint16 type; // must be prodTestType_t
  uint16 length;
  union {
    uint16 buffer[sizeof(prodTestData_t)/sizeof(uint16)];
    prodTestData_t data;
  };
} prodTestResult_t;

typedef enum {
  conversionType_2D,
  conversionType_0D
} conversionType_t;

typedef struct {
  uint16 cbcGlobalEnable;
  uint16 cbcGlobalPullBotDisable;
  uint16 cbcGlobalPullBotPl;
  uint16 cbcGlobalXmtrCarrierSel;
  uint16 cbcGlobalXmtrPl;
  uint16 dacIn;
  uint16 dacXmtrStates;
  uint16 rcvrCfb1Enable;
  uint16 rcvrFbCapCfb1;
  uint16 rcvrCfb1ModeLookup;
  uint16 rcvrCfb1Lookup;
  uint16 rcvrCfb1Pl;
  uint16 refCfb1ModeLookup;
  uint16 refCfb1Lookup;
  uint16 refCbMode;
  uint16 refCfb1Pl;
  uint16 refRcvrPl;
  float rcvrFbCap;
  float refFbCap;
  float refHiCapSel;
  float refLoCapSel;
  float CparasticRcvr;
  float CparasticRef;
  float Vdd;
  float dV;
  float rcvrCfb1ChargeInjected;
  float RefCfb1ChargeInjected;
  float refHiCbcChargeInjected;
  float refLoCbcChargeInjected;
  float vrefHiAbs;
  float vrefLoAbs;
  float vrefHiCb;
  float vrefLoCb;
  uint16 refModSel;
  uint16 refHiXmtrPl;
  uint16 refLoXmtrPl;
  float vTransmit;
  float vRefHiTrans;
  float vRefLoTrans;
  float cref;
  float cfb;
  uint16 refHiCapSelTACsetting;
  uint16 refLoCapSelTACsetting;
  float alpha;
  float gain;
  float refFbCapCfb1;
  float ccancel;
  float kHi;
  float kLo;
  float crefHiK;
  float crefLoK;
}formulaVar_t;

typedef struct {
  uint16 numRows;
  uint16 numCols;
  uint16 numBtns;
  uint16 swapSensorSide;
  uint16 muxSize[2];
  uint16 imageRxes[MAX_RX];
  uint16 imageCbcs[MAX_RX*2];
  uint16 btnAbsTransMode;
  uint16 btnGlobalCbc;
  uint16 btnLocalCbcs[MAX_BUTTONS];
  uint16 btnTxMask;
} populateParam_t;

extern formulaVar_t cv;
extern populateParam_t pp;

struct calcStaticConfig_t;
struct calcDynamicConfig_t;

void doEtoeShortTest(struct calcStaticConfig_t *scfg, prodTestResult_t *result);
void doExtendedSensorSpeedTest(struct calcStaticConfig_t *scfg, prodTestResult_t *result);
void doAdcSaturationTest(struct calcStaticConfig_t *scfg, prodTestResult_t *result);
void convertImageToDeltaCapacitance(int16 *image);
void convertButtonsToDeltaCapacitance(int16 *btnData);
void convertImageToRawCapacitance(uint16 *image);
void convertButtonsToRawCapacitance(uint16 *btnData);
uint16 convertDeltaCapacitancetoDeltaADCs(uint16 data);
uint16 convertAbsCapacitanceToADCs(uint16 fF, uint16 isX, uint16 proxABS);
void loadConvParams(conversionType_t type);

#endif // _PRODUCTION_TEST_H
