/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include <string.h>
#include <stddef.h>
#include "calc2.h"

#if PLATFORM_TD4310 == 1        /* if not bypass this file completely */
#include "platform.h"

#if CONFIG_PER_PIXEL_CBCSCAN
  #include "../platform_cbc.h"

void PlatformApi_td4310::PL_findBestCbcs(struct calcStaticConfig_t *scfg ATTR_UNUSED, PLCBCType_t cbcType)
{
  if (cbcType == cbc_perPixelLocal)
  {
      //td4310 1bit LCBC is ADC_TEST_MODE. It must works with GCBC enabled
      uint16 globalCBCEnabled = DAQ_readVar(CBC_GLOBAL_ENABLE_VAL);
      DAQ_writeVar(CBC_GLOBAL_ENABLE_VAL, 1);

      findBestPerPixelLocalCbcs(scfg);

      // Restore original local CBC enable and per-pixel local CBC enabled state.
      DAQ_writeVar(CBC_GLOBAL_ENABLE_VAL, globalCBCEnabled);
  }
}

void PlatformApi_td4310::PL_getCbcs(PLCBCType_t cbcType, uint16 **CBCs ATTR_UNUSED)
{
  if (cbcType == cbc_perPixelLocal)
  {
      getPerPixelLocalCbcs(CBCs);
  }
}

void PlatformApi_td4310::PL_updateTestModeLCBC(uint16 *CBCs_L, uint16 *CBCs_R)
{
  uint16 lcbc_l_15_0, lcbc_l_31_16, lcbc_r_15_0, lcbc_r_31_16;
  uint16 i,j;
  for(j = 0; j < (MAX_TX/2); j++)
  {
    lcbc_l_15_0 = 0;
    lcbc_l_31_16 = 0;
    lcbc_r_15_0 = 0;
    lcbc_r_31_16 = 0;
    for(i = 0; i < (MAX_RX/2); i++)
    {
      if(*CBCs_L++ > 0)
        lcbc_l_15_0 |= (0x01 << i);
      if(*CBCs_R++ > 0)
        lcbc_r_15_0 |= (0x01 << i);
    }
    for(i = 0; i < (MAX_RX/2); i++)
    {
      if(*CBCs_L++ > 0)
        lcbc_l_31_16 |= (0x01 << i);
      if(*CBCs_R++ > 0)
        lcbc_r_31_16 |= (0x01 << i);
    }
    DAQ_writeVar(L_RCVR_EN_15_0_ARRAY + j, lcbc_l_15_0);
    DAQ_writeVar(L_RCVR_EN_31_16_ARRAY + j, lcbc_l_31_16);
    DAQ_writeVar(R_RCVR_EN_15_0_ARRAY + j, lcbc_r_15_0);
    DAQ_writeVar(R_RCVR_EN_31_16_ARRAY + j, lcbc_r_31_16);
  }
}
#else
void PlatformApi_td4310::PL_findBestCbcs(struct calcStaticConfig_t *scfg ATTR_UNUSED, PLCBCType_t cbcType ATTR_UNUSED)
{

}

void PlatformApi_td4310::PL_getCbcs(PLCBCType_t cbcType ATTR_UNUSED, uint16 **CBCs ATTR_UNUSED)
{

}

void PlatformApi_td4310::PL_updateTestModeLCBC(uint16 *CBCs_L ATTR_UNUSED, uint16 *CBCs_R ATTR_UNUSED)
{

}
#endif
#endif // PLATFORM_TD4310 == 1        /* if not bypass this file completely */
