#ifndef _PLATFORM_TD4310_H
#define _PLATFORM_TD4310_H 1
/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

#define BUTTON_MODE_SIMULATE           1
#define BUTTON_MODE_SEPERATE           2
#define BUTTON_MODE_ABS                0
#define BUTTON_MODE_TRANS              1

/**
 * PLFrameData_t decodes all possible frame types. This must match the
 * DAQ program for this platform.
 */
typedef union {
  struct {
    uint16 image[MAX_TX * MAX_RX];
    uint16 buttons[MAX_RX];
    uint16 noise[MAX_NOISE_RX * MAX_NOISE_BURSTS];
  };
  #if !(defined(cfg_daqLess))
  uint16 noiseScan[MAX_NOISE_SCAN_BURSTS * MAX_NOISE_RX];
  #else
  uint16 noiseScan[1];
  #endif
  uint16 doze[2 * (MAX_RX + MAX_BUTTONS)];
  uint16 superdoze[2];
} PLFrameData_t;

/**
 * PLCapData_t stores the active frame in femtofarads, excepting noise
 * measurements.
 */
typedef struct {
  uint16 image[MAX_TX * MAX_RX + MAX_BUTTONS];
} PLCapData_t;


/**
 * PLAdcLimits_t stores the max ADC values for different parts of the
 * active frame. This can be used to check for saturation.
 */
typedef struct {
  uint16 image;
  uint16 buttons;
} PLAdcLimits_t;

/**
 * Per-sense-frequency timing parameters. These determine the sensing
 * frequency and how long each burst is.
 */
typedef struct {
  /// The length (in sense cycles) of the first burst in each cluster.
  uint16 burstSize1[MAX_FREQUENCIES];

  /// The length (in sense cycles) of subsequent bursts in each
  /// cluster.
  uint16 burstSize2[MAX_FREQUENCIES];

  /// The FILT_BW setting.
  uint16 filtBW[MAX_FREQUENCIES];

  /// The size of the frequency modulation ramp waveform.
  uint16 frampSize[MAX_FREQUENCIES];

  /// The value for FRAMP_CNT.
  uint16 frampCount[MAX_FREQUENCIES];

  /// The value for FRAMP_DELTA.
  uint16 frampDelta[MAX_FREQUENCIES];

  /// The value for STRETCH_DUR.
  uint16 stretchDur[MAX_FREQUENCIES];

  /// The value for RSTRETCH_DUR.
  uint16 rstretchDur[MAX_FREQUENCIES];

  /// Whether this frequency is enabled or not.
  uint16 disableFreq[MAX_FREQUENCIES];
} freqTable_t;

/**
 * The DAQ configuration structure. This contains values for most of
 * the variables used to configure the AFE. In the documentation for
 * each field, if the field is said to correspond to an ASIC register
 * or register field, then that field uses the same encoding as the
 * ASIC register or register field.
 *
 * Not all ASIC registers have corresponding values here. For example,
 * there is no REF_SUBTRACT_CAP value for hybrid sensing. This is to
 * mirror the RMI register map. But other omissions could be bugs.
 *
 */
typedef struct {

  /// The value for ABS_PL used throughout the frame.
  uint16 absPl;

  /// Whether to enable Y-axis charge subtraction during proximity and
  /// hybrid sensing. This is used to augment CBC.
  uint16 absYChargeSubtractionEnable;

  /// The TREX pin to use for Y-axis charge subtraction.
  uint16 absYChargeSubtractionTx;

#if CONFIG_HAS_0D_BUTTONS
  /// The value for AXIS_SENSE to use during 0-D button sensing.
  uint16 buttonAxisSense;

  /// The number of bursts per cluster to use for button sensing.
  uint16 buttonBurstsPerCluster;

  /// The value for CBC_XMTR_CARRIER_SEL to use for button sensing.
  uint16 buttonCbcXmtrCarrierSel;

  /// The value for CBC_XMTR_PL to use for button sensing.
  uint16 buttonCbcXmtrPl;

  /// The list of button receiver TREX pins. Only the first
  /// ``numButtons`` entries are used.
  uint16 buttonRxes[MAX_BUTTONS];

  /// The list of button transmitter TREX pins. Only the first
  /// ``numButtons`` entries are used.
  uint16 buttonTxes[MAX_BUTTONS];

  // 0D_ACQUISITION_MODE
  uint16 concurrentButtonAcquisition;

  // 0D_HYBRID
  uint16 buttonAbsEnable;
  uint16 buttonAbsAxis;
  uint16 hybridButtonCbc;

  //Doze Button CBC
  uint16 dozeButtonCbcs[MAX_BUTTONS];

  #if CONFIG_TDDI_AMP_BUTTONS
  /// Operation mode (1: 2D simulation mode, 2: 0D separate sensing mode)
  uint16 buttonOperationMode;

  /// abstrans mode 0: abs-cap mode, 1: trans-cap mode
  uint16 buttonAbsTransMode;

  /// The scaling factor
  uint16 buttonScaleFactor[MAX_BUTTONS];

  /// Local CBC for button Active mode
  uint16 buttonLocalCbcs[MAX_BUTTONS];

  /// Global CBC for button Active mode
  uint16 buttonGlobalCbc;

  /// Local CBC for button Doze mode
  uint16 buttonLocalCbcDoze;

  /// Global CBC for button Doze mode
  uint16 buttonGlobalCbcDoze;

  /// REF_HI_CAP_SEL for button
  uint16 buttonRefHiCap;

  /// REF_LO_CAP_SEL for button
  uint16 buttonRefLoCap;
  #endif
#endif

  //Doze CBC
  uint16 dozeCbcs[MAX_RX];

  /// Set to 0 for doze, 1 for loze.
  uint16 lowPowerMode;

  /// Set to 1 to enable CDM of order CDM_ORDER
  uint16 cdmEnable;

  /// The frequency modulation center value.
  uint16 centerFmod;

  /// Set to 1 to enable CID.
  uint16 cidEnable;

  /// The value for INTFR_DET_VSEL to use for CID.
  uint16 cidThreshold;

  /// The per-sense-frequency timing settings.
  freqTable_t freqTable;

  /// The default sense frequency.
  uint16 frequency;

  /// HW clock modulation/dithering
  uint16 imageFmodEnable;

#if CONFIG_NSM
  /// Set to 1 to prevent frequency shifting
  uint16 inhibitFrequencyShift;

  /// The PowerIM threshold above which the NSM moves out of the HNM
  /// state.
  uint16 powerimHighThresh;

  /// The PowerIM threshold below which the NSM can move out of the
  /// FNM state.
  uint16 powerimLowThresh;

  /// The PowerIM threshold above which a frequency scan can be called
  /// from the FNM state.
  uint16 powerimFnmHighThresh;

  /// The minimum of the FSIM vector must be below this threshold to
  /// exit the frequency scan into HNM. Otherwise, the NSM moves into
  /// FNM after a frequency scan.
  uint16 fsimThresh;

  /// The RailIM threshold above which the NSM moves into the FNM
  /// state.
  uint16 railimHighThresh;

  /// The RailIM threshold below which the NSM can move out of the FNM
  /// state.
  uint16 railimLowThresh;

  /// The CIDIM threshold above which the NSM moves out of the FNM
  /// state.
  uint16 cidimHighThresh;

  /// The CIDIM threshold below which the NSM moves out of the FNM
  /// state to the HNM state instead of the FNM_CID state.
  uint16 cidimLowThresh;

  /// The percentage of the previous 16 frames that the PowerIM
  /// exceeded the powerimFnmHightThresh required in order to start a
  /// frequency scan from the FNM.
  uint16 fsFnmDensity;

  /// The number of consecutive frames with IMs below their respective
  /// thresholds before moving out of the FNM or FNM_CID state.
  uint16 fnmTimeout;

  /// The minimum number of seconds that must elapse between
  /// consecutive frequency scans.
  uint16 fsTimeout;

  /// The number of consecutive frames with IMs below their respective
  /// thresholds before moving 60hz to 120hz
  uint16 hnmRateShiftFrameCount;

  #if CONFIG_NSM_CALLISTO
  /// The VarCIDIM threshold above which the NSM moves into
  /// the FNM state.
  uint16 varcidimHighThresh;

  /// The VarCIDIM threshold below which the NSM can move
  /// out of the FNM state.
  uint16 varcidimLowThresh;

  /// The number of frames that must be spent in the HNM state
  /// before re-entering the FNM_CID state.
  uint16 holdoffTimeout;
  #endif

  /// The number of touch rate control: manual 120hz (2), manual 60hz (1), dynamic 120hz/60hz (0)
  uint16 dynamicSensingRate;

  /// No Noise Mitigation: Dynamic Config. nsm_init() need this value to prevent frequency shifting
  uint16 noNoiseMitigation;
#endif

  /// The number of bursts per cluster for image sensing.
  uint16 imageBurstsPerCluster;

  /// The CBC_XMTR_CARRIER_SEL value for image sensing.
  uint16 imageCbcXmtrCarrierSel;

  /// The CBC_XMTR_PL value for image sensing.
  uint16 imageCbcXmtrPl;

  /// The CBC_CHn values for image sensing. These are ordered by image
  /// column. Only the first numCols values are used.
  uint16 imageCbcs[MAX_PHY_RX];//Left and Right

  /// The GAIN_CTRL value for image sensing.
  uint16 imageGainCtrl;

  /// The INTEG_DUR value for image sensing.
  uint16 imageIntegDur;

  /// The RCVR_FB_CAP value for image sensing.
  uint16 imageRcvrFbCap;

  /// The REF_GAIN_CTRL value for image sensing.
  uint16 imageRefGainCtrl;

  /// The REF_HI_TRANS_CAP value for image sensing.
  uint16 imageRefHiTransCap;

  /// The REF_LO_TRANS_CAP value for image sensing.
  uint16 imageRefLoTransCap;

  /// The REF_RCVR_FB_CAP value for image sensing.
  uint16 imageRefRcvrFbCap;

  /// The RESET_DUR value for image sensing.
  uint16 imageResetDur;

  /// The TREX pins used as the image receivers and the abs X axis.
  uint16 imageRxes[MAX_RX];

  /// The TREX pins used as the image transmitters and the abs Y axis.
  uint16 imageTxes[MAX_PHY_TX];

  /// The MASTER_BIAS_TRIM value.
  uint16 masterBiasTrim;

  /// The number of noise bursts in each frame. This must not exceed
  /// MAX_NOISE_BURSTS.
  uint16 noiseBursts;

  /// The number of bursts per frequency to use during a noise scan.
  /// This must not exceed MAX_NOISE_SCAN_BURSTS.
  uint16 noiseScanBursts;

  /// The BURST_SIZE value to use for blank bursts between subframes
  uint16 deadBurstSize;

  /// The number of buttons actually used. This must not exceed
  /// MAX_BUTTONS.
  uint16 numButtons;

  /// The number of image columns actually used. This must not exceed
  /// MAX_RX.
  uint16 numCols;

  /// The number of image rows actually used. This must not exceed
  /// MAX_TX.
  uint16 numRows;

  /// The number of guard pins on the image RX/abs X axis bank. This
  /// must not exceed MAX_RX_GUARDS.
  uint16 numRxGuards;

  /// The number of guard pins on the image TX/abs Y axis bank. This
  /// must not exceed MAX_TX_GUARDS.
  uint16 numTxGuards;

  /// The PUMP_DIV value
  uint16 pumpDiv;

  /// Set to 1 to enable rail interference detection.
  uint16 railEnable;

  /// The REF_HI_XMTR_PL value.
  uint16 refHiXmtrPl;

  /// The REF_LO_ABS_PL value.
  uint16 refLoAbsPl;

  /// The REF_LO_XMTR_PL value.
  uint16 refLoXmtrPl;

#if CONFIG_GUARD
  /// The TREX numbers of the X-axis guard pins.
  uint16 rxGuardPins[MAX_RX_GUARDS];

  /// The TREX numbers of the Y-axis guard pins.
  uint16 txGuardPins[MAX_TX_GUARDS];
#endif

  /// The AXIS_SENSE value for X-axis and image sensing.
  uint16 xAxisSense;

  /// The AXIS_SENSE value for Y-axis sensing.
  uint16 yAxisSense;

  //DAC IN
  uint16 dac_in;
  uint16 dac_in_0d;
  uint16 dac_in_0d_doze;

  //CBC tx on cnt
  uint16 cbcTxOnCnt;

  //CBC RX on cnt
  uint16 cbcRxOnCnt;

  #if CONFIG_HAS_CFB1_CTRL
  //receiver CFB1 Enable
  uint16 rcvrCFB1Enable;

  //reference CFB1 Enable
  uint16 refCFB1Enable;

  //CFB1 Off cnt
  uint16 cfb1OffCnt;

  //Reference Receiver Feedback Cap Mode For CFB1
  uint16 cfb1RefFBCapMode;

  //Reference Receiver Feedback Caps For CFB1
  uint16 cfb1RefFBCaps;

  //Receiver Feedback Cap Mode For CFB1
  uint16 cfb1RcvrFBCapMode;

  //Receiver Feedback Caps For CFB1
  uint16 cfb1RcvrFBCaps;
  #endif

  //Local CBC enable
  uint16 localCbcEnable;

  #if CONTROL_GUARD_DAC
    uint16 deltaVStartState;
    uint16 delVrefState;
    uint16 deltaVDur;
  #endif

  //Global CBC enable
  uint16 globalCbcEnable;

  //Global CBC value
  uint16 globalCbcValue;

  //Ref global CBC enable
  uint16 refGlobalCbcEnable;

  //Ref local CBC enable
  uint16 refLocalCbcEnable;

  //override local CBC, and ref local CBC enable
  uint16 overrideLocalRefLocalCbcEnable;

  //left global CBC value
  uint16 leftGlobalCbcValue;

  //right global CBC value
  uint16 rightGlobalCbcValue;

  //reference global CBC value
  uint16 refGlobalCbcValue;

  //Ref Hi Local CBC value
  uint16 refHiLocalCbcValue;

  //Ref Lo Local CBC value
  uint16 refLoLocalCbcValue;
  #if defined(cfg_TrigDelayExpand) && cfg_TrigDelayExpand
  //TRIG_DELAY_DUR control
  uint16 TrigDelayDur;
  #endif

  // For GPIO controls
  uint16 numGpioPins;
  uint16 gpioPinToOmitMask;

  // Panel
  uint16 panel; // TIANMA_PANEL: 1, BOE: 0

  // LHblank report rate 60Hz
  uint16 lhbReportRate60Hz;

#if CONFIG_NSM_EUROPA
  // baseline compensation
  uint16 transitionFrameCount;
#endif

  //AFE block layout
  uint16 swapSensorSide;
  uint16 muxSize[2];

  //MUX sensing order
  uint16 muxSenseOrder[MAX_PHY_TX];

  uint16 lpwgSoutCtrl0;
  uint16 lpwgSoutCtrl1;
  #if CONFIG_LPWG_TIMING_CTRL
  uint16 noTouchLpwgSoutCtrl0;
  uint16 noTouchLpwgSoutCtrl1;
  uint16 lpwgSoutCtrlEnable;
  #endif

  #if CONFIG_LPWG_TOUCHCONFIG_CTRL
  uint16 lpwgTouchConfigCtrlEn;
  uint16 lpwgIntegrationDur;
  uint16 lpwgCbcTxOnCnt;
  uint16 lpwgCbcRxOnCnt;
  uint16 lpwgCfb1RcvrFbCaps;
  uint16 lpwgTrigDelayDur;
  #endif

  uint16 numBitsPerCBC;
} daqParams_t;

#include "../platform_base.h"

// Forward-declare some Calc2 structures we need pointers to. This
// prevents us from having to include header files in a specific
// order.
struct calcStaticConfig_t;
struct calcDynamicConfig_t;
struct dozeParams_t;

#ifdef __cplusplus
class PlatformApi_td4310 : public PlatformApi
{
public:
  void PL_convertToIFPFormat(struct calcStaticConfig_t *scfg ATTR_UNUSED);
  void PL_init(struct calcStaticConfig_t *scfg, struct calcDynamicConfig_t *dcfg ATTR_UNUSED);
  void PL_enterMode(PLMode_t newMode);
  PLFrame_t *PL_getFrame(PLFrameType_t frameType);
  void PL_releaseFrame(PLFrame_t *f);
  PLNSMState_t PL_getNSMState();
  uint16 PL_getNSMTransClusters();
  uint16 PL_getNSMNoiseBursts();
  uint16 PL_getNSMFreqScanBursts();
  void PL_convertActiveFrameToRawCap(PLFrameData_t *frame , PLCapData_t *cap);
  void PL_convertActiveFrameToDeltaCap(PLFrameData_t *frame, PLCapData_t *cap);
  void PL_getTestFrame(prodTestType_t test, struct calcStaticConfig_t *scfg,
                     struct calcDynamicConfig_t *dcfg ATTR_UNUSED, prodTestResult_t *result);
  void PL_setParam(PLParam_t param_type, uint16 param_value);
  uint16 PL_isDozeTimerResetRequested();
  void PL_copy0DToFrameBuffer(uint16 isAbsBtnData ATTR_UNUSED, uint16 *btnDataPtr, PLFrameData_t *frameBufferPtr);
  void PL_0DButtonsScaling(uint16 *btnDataPtr, uint16 *btnScaleFactor);
  uint16 PL_isDozeWakeUpCondition(struct dozeParams_t *dozeConfig, int16 *deltaImage, uint16 size);
  void PL_setupFreqScanFrame();
  void PL_disableFreqScanFrame();
  void PL_setupRcvrOffsetFrame();
  void PL_disableRcvrOffsetFrame();
  PLFrame_t *PL_getRcvrOffsetFrame();
  void PL_calibrateButtons();
  void PL_setCurrentRate(uint16 rate);
  void PL_findBestCbcs(struct calcStaticConfig_t *scfg, PLCBCType_t cbcType);
  void PL_getCbcs(PLCBCType_t cbcType, uint16 **CBCs);
  void PL_updateTestModeLCBC(uint16 *CBCs_L, uint16 *CBCs_R);

};

extern PlatformApi_td4310 platformapi;

#endif

#endif
