/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */
#include "calc2.h"

#if PLATFORM_TD4328

#include <string.h>
#include <stddef.h>

#include "daq2.h"
#include "platform.h"
#if CONFIG_NSM
#include "nsm2.h"
#endif

#include "calc_print.h"
#include "tac_init_auto.c"

PlatformApi_td4328 platformapi;

static PLMode_t mode;
static union {
  struct {
    uint16 disableNoiseMitigation : 1;
    uint16 objectsPresent : 1;
    uint16 chargerPresent : 1;
    uint16 resetDoze : 1;
  };
  uint16 all;
} flags;

#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define LEN(x) (sizeof(x)/sizeof(x[0]))

// this is an offset into a structure in 16-bit words
#if defined(__T100X_VOID_ALIGNMENT__) && (__T100X_VOID_ALIGNMENT__ == 16)
#  define OFFSET_16(x, y) offsetof(x, y)
#else
#  define OFFSET_16(x, y) (offsetof(x, y)/sizeof(uint16))
#endif

#define CONNECTED_MUXES (0x01FF)

// FIXME: get initialized static data working in firmware
static DAQFrame_t *lastFrame = NULL;
static uint16 power_on_init_done;

static void throwAwayDummyFrame(void)
{
  DAQFrame_t *f;
  //DAQVarId_t regs[] = {PROX_ENABLED, HYBRID_ENABLED, BUTTONS_ABS_ENABLED, BUTTONS_ENABLED, IMAGE_ENABLED, NOISE_ENABLED};
  //uint16 vals[] =     {           0,              0,                   0,               0,             0,             0};
  //DAQ_writeVars(regs, vals, LEN(regs));

  //CONFIG_HAS_0D_BUTTONS: use BUTTON_ENABLED, BUTTON_BKP_ENABLED now
  //PROX_ENABLED, HYBRID_ENABLED, BUTTONS_ABS_ENABLED, BUTTONS_ENABLED, IMAGE_ENABLED: were never used in frame program
  DAQ_writeVar(NOISE_ENABLED, 0);

  f = DAQ_getFrame(0);
  DAQ_releaseFrame(f);
}

static void initDoze(dozeParams_t *dozeParams, uint16 *imageTxes ATTR_UNUSED, uint16 numTxes ATTR_UNUSED, uint16 *buttonTxes ATTR_UNUSED, uint16 numButtons ATTR_UNUSED)
{
  uint16 dozeFramePeriod = (dozeParams->dozeInterval*1000);
  //DAQ_writeVar(DOZE_BURSTS_PER_CLUSTER, dozeParams->dozeBurstsPerCluster); //not implement
  DAQ_writeVar(DOZE_FRAME_PERIOD, dozeFramePeriod);
}

static int16 valToPos(uint16 *idxs, uint16 idx, uint16 max)
{
  uint16 i;
  int16  pos;

  for (i = 0, pos = 0; i < max; i++, idxs++)
  {
      if (*idxs == idx)
      {
        return pos;
      }
      pos++;
  }
  return -1;
}

void PlatformApi_td4328::PL_convertToIFPFormat(struct calcStaticConfig_t *scfg ATTR_UNUSED)
{
  ifpConfig_t *ifpData = (ifpConfig_t *)&(scfg->ifpConfig);

  ifpData->sensorParams.cSat_LSB =
       convertDeltaCapacitancetoDeltaADCs(ifpData->sensorParams.cSat_LSB);
  ifpData->sensorParams.noiseFloor_LSB =
       convertDeltaCapacitancetoDeltaADCs(ifpData->sensorParams.noiseFloor_LSB);
  ifpData->bcConfig.absXNegThreshold_LSB =
       convertAbsCapacitanceToADCs(ifpData->bcConfig.absXNegThreshold_LSB, 1, 0) << 2;//12p4
  ifpData->bcConfig.absYNegThreshold_LSB =
       convertAbsCapacitanceToADCs(ifpData->bcConfig.absYNegThreshold_LSB, 0, 0) << 2;//12p4
  ifpData->segConfig.minPeak_LSB =
       convertDeltaCapacitancetoDeltaADCs(ifpData->segConfig.minPeak_LSB);
  ifpData->classConfig.absXObjectThreshold_LSB =
     convertAbsCapacitanceToADCs(ifpData->classConfig.absXObjectThreshold_LSB, 1, 0) << 2;//12p4
  ifpData->classConfig.absYObjectThreshold_LSB =
     convertAbsCapacitanceToADCs(ifpData->classConfig.absYObjectThreshold_LSB, 0, 0) << 2;//12p4
  ifpData->classConfig.saturationLevel_LSB =
     convertDeltaCapacitancetoDeltaADCs(ifpData->classConfig.saturationLevel_LSB);

#if CONFIG_HAS_BASELINE_COMPENSATION
  ifpData->bsConfig.noiseFloorAddLevel = convertDeltaCapacitancetoDeltaADCs(ifpData->bsConfig.noiseFloorAddLevel);
  ifpData->bsConfig.minPeakAddLevel = convertDeltaCapacitancetoDeltaADCs(ifpData->bsConfig.minPeakAddLevel);
  ifpData->bsConfig.strongAddLevel = convertDeltaCapacitancetoDeltaADCs(ifpData->bsConfig.strongAddLevel);
#endif
}

void PlatformApi_td4328::PL_init(struct calcStaticConfig_t *scfg, struct calcDynamicConfig_t *dcfg ATTR_UNUSED)
{
  uint16 i;
  daqParams_t *d = &scfg->daqParams;

  flags.all = 0;

  mode = (PLMode_t)-1; // reset to invalid mode

  if (lastFrame != NULL)
  {
    DAQ_releaseFrame(lastFrame);
    lastFrame = NULL;
  }

  PL_enterMode(mode_idle);

  /* Write the miscellaneous registers */
  if (!power_on_init_done)
  {
    TAC_init_ACTIVE();
    power_on_init_done = 1;
  }

  DAQ_writeVar(SYNC_VAR, 1);
  DAQ_writeVar(ACTIVE_FRAME_PERIOD, 1200);

  DAQ_writeVar(TRANS_BURSTS_PER_CLUSTER, d->imageBurstsPerCluster);
  DAQ_writeVar(CBC_GLOBAL_XMTR_CARRIER_SEL_VAL, d->imageCbcXmtrCarrierSel);
  DAQ_writeVar(CBC_GLOBAL_XMTR_PL_VAL, d->imageCbcXmtrPl);
  DAQ_writeVar(REF_HI_XMTR_PL_VAL, d->refHiXmtrPl);
  DAQ_writeVar(REF_LO_XMTR_PL_VAL, d->refLoXmtrPl);
  DAQ_writeVar(TRANS_FREQUENCY, d->frequency);
  if (d->lhbReportRate60Hz || d->frequency >= MAX_FREQUENCIES/2)
  {
    PL_setCurrentRate(60);
  }
  else
  {
    PL_setCurrentRate(120);
  }
  DAQ_writeVar(INTEG_DUR_VAL, d->imageIntegDur);

  DAQ_writeVar(RCVR_FB_CAP_VAL, d->imageRcvrFbCap);
  DAQ_writeVar(REF_HI_CAP_SEL_2D_VAL, d->imageRefHiTransCap);
  DAQ_writeVar(REF_LO_CAP_SEL_2D_VAL, d->imageRefLoTransCap);
  DAQ_writeVar(REF_HI_CAP_SEL_VAL, d->imageRefHiTransCap);
  DAQ_writeVar(REF_LO_CAP_SEL_VAL, d->imageRefLoTransCap);
  DAQ_writeVar(REF_FB_CAP_VAL, d->imageRefRcvrFbCap);
  DAQ_writeVar(RESET_DUR_VAL, d->imageResetDur);
  #if CONFIG_HAS_ANALOG_DEMOD_SAMPLE_DUR_TUNING_ENABLED
  DAQ_writeVar(DEMOD_SAMPLE_DUR_VAL, d->imageDemodSampleDur);
  #endif

  /* Fill in some constant values that are not in the RMI register map */
  DAQ_writeVar(NOISE_MEASURE_OFFSETS, 0);
  DAQ_writeVar(NOISE_SCAN_FLAG, 0);

  /* Configure all ADC channels */
  DAQ_writeVar(NUM_ENABLED_X_RECEIVERS, d->numCols);  //separate to Right and Left
  DAQ_writeVar(TRANS_BURSTS_PER_CLUSTER, 1);
  DAQ_writeVar(TRANS_OFFSET, 0);
  DAQ_writeVar(NOISE_BURSTS,      d->noiseBursts);
  DAQ_writeVar(NOISE_SCAN_BURSTS, d->noiseScanBursts);
  DAQ_writeVar(FMOD_ENABLE, d->imageFmodEnable);

  /* Set up frequency table */
  {
    DAQ_writeArray(TRANS_BURST_SIZE1_ARRAY, d->freqTable.burstSize1, LEN(d->freqTable.burstSize1));
    DAQ_writeArray(TRANS_BURST_SIZE2_ARRAY, d->freqTable.burstSize2, LEN(d->freqTable.burstSize2));
    DAQ_writeArray(TRANS_FILT_BW_ARRAY, d->freqTable.filtBW, LEN(d->freqTable.filtBW));
    DAQ_writeArray(TRANS_FRAMP_CNT_ARRAY, d->freqTable.frampCount, LEN(d->freqTable.frampCount));
    DAQ_writeArray(TRANS_FRAMP_DELTA_ARRAY, d->freqTable.frampDelta, LEN(d->freqTable.frampDelta));
    DAQ_writeArray(TRANS_STRETCH_DUR_ARRAY, d->freqTable.stretchDur, LEN(d->freqTable.stretchDur));
    DAQ_writeArray(TRANS_RSTRETCH_DUR_ARRAY, d->freqTable.rstretchDur, LEN(d->freqTable.rstretchDur));
    if(d->imageFmodEnable)
    {
      DAQ_writeArray(TRANS_FRAMP_MAX_ARRAY,    d->freqTable.frampSize, LEN(d->freqTable.frampSize));
    }
  }

  {
    uint16 j, k;
    uint16 fireClusterNum;
    int16 p = 0;
    uint16 dozeMaxAFE_L = 0;
    uint16 dozeMaxAFE_R = 0;
    #if CONFIG_MUX_START
    p= RIGHT_MUX_START - LEFT_MUX_START;
    #endif
    fireClusterNum = 0;
    for(j = 0; j < MAX_PHY_TX; j++)
    {
      k = (d->muxSenseOrder[j] < MAX_PHY_TX) ? (0x1<<(d->muxSenseOrder[j])): 0;
      DAQ_writeVar(TRANS_L_XMTR_VAL_ARRAY + j, k | (0x01 << 12));  //set RESET_WITH_GUARD = 1
      DAQ_writeVar(TRANS_L_XMTR_GUARD_ARRAY + j, CONNECTED_MUXES & (~k));
      dozeMaxAFE_L |= k;
      k = (d->muxSenseOrder[j] < MAX_PHY_TX) ? (0x1<<(d->muxSenseOrder[j]+p)): 0;
    #if CONFIG_LEFT_RIGHT_MIRROR
      DAQ_writeVar(TRANS_R_XMTR_VAL_ARRAY + MUX_RIGHT_TX - 1 - j, k | (0x01 << 12));
      DAQ_writeVar(TRANS_R_XMTR_GUARD_ARRAY + MUX_RIGHT_TX - 1 - j, CONNECTED_MUXES & (~k));
    #else
      DAQ_writeVar(TRANS_R_XMTR_VAL_ARRAY + j, k | (0x01 << 12));  //set RESET_WITH_GUARD = 1
      DAQ_writeVar(TRANS_R_XMTR_GUARD_ARRAY + j, CONNECTED_MUXES & (~k));
    #endif
      dozeMaxAFE_R |= k;
      if(k != 0)
        fireClusterNum++;
    }
#if !CONFIG_SWITCH_RESPSEL_12060
    if (!d->lhbReportRate60Hz)
    {
      uint16 total_burst_number;
      #if CONFIG_NSM
      total_burst_number = fireClusterNum + MAX_NOISE_BURSTS;
      #else
      total_burst_number = fireClusterNum;
      #endif
      if(total_burst_number % 2)
        fireClusterNum++;
    }
#endif
    DAQ_writeVar(TRANS_CLUSTERS, fireClusterNum);
    DAQ_writeVar(DOZE_L_AFE_SEL_VAL, dozeMaxAFE_L);
    DAQ_writeVar(DOZE_R_AFE_SEL_VAL, dozeMaxAFE_R);
    DAQ_writeVar(DOZE_L_GUARD_SEL_VAL, 0x1FF & (~dozeMaxAFE_L));
    DAQ_writeVar(DOZE_R_GUARD_SEL_VAL, 0x1FF & (~dozeMaxAFE_R));
#if CONFIG_HAS_RX_MIRROR
    for (i = 0; i < MAX_RX; i++)
    {
      DAQ_writeVar(L_RX_RECEIVER_OFFSETS + i, d->imageRxes[i]);
      DAQ_writeVar(R_RX_RECEIVER_OFFSETS + i, MAX_RX - 1 - d->imageRxes[i]); //berkerley panel tx9~tx17 is reverse to other txs
    }
#else
    for (i = 0; i < MAX_RX; i++)
    {
      DAQ_writeVar(L_RX_RECEIVER_OFFSETS + i, d->imageRxes[i]);
      DAQ_writeVar(R_RX_RECEIVER_OFFSETS + i, d->imageRxes[i]);
    }
#endif
  }
  DAQ_writeVar(DAC_IN_VAL, d->dac_in);
  DAQ_writeVar(CBC_XMTR_ON_CNT_VAL, d->cbcTxOnCnt);
  DAQ_writeVar(CBC_RCVR_CONNECT_ON_CNT_VAL, d->cbcRxOnCnt);
  #if CONFIG_HAS_CFB1_CTRL
  DAQ_writeVar(REF_CFB1_ENABLE_VAL, d->refCFB1Enable);
  DAQ_writeVar(RCVR_CFB1_ENABLE_VAL, d->rcvrCFB1Enable);
  DAQ_writeVar(CFB1_OFF_CNT_VAL, d->cfb1OffCnt);
  DAQ_writeVar(REF_FB_CAP_MODE_VAL, d->cfb1RefFBCapMode);
  DAQ_writeVar(REF_FB_CAP_CFB1_VAL, d->cfb1RefFBCaps);
  DAQ_writeVar(RCVR_FB_CAP_MODE_VAL, d->cfb1RcvrFBCapMode);
  DAQ_writeVar(RCVR_FB_CAP_CFB1_VAL, d->cfb1RcvrFBCaps);
  #endif
  DAQ_writeVar(DELTA_V_START_STATE_VAL, d->deltaVStartState);
  DAQ_writeVar(DELVREF_DAC_VAL, d->delVrefState);
  DAQ_writeVar(DELTA_V_DUR_VAL, d->deltaVDur);
  DAQ_writeVar(REF_CBC_GLOBAL_CAP_ADJ_VAL, d->refGlobalCbcValue);
  DAQ_writeVar(CBC_GLOBAL_ENABLE_VAL, d->globalCbcEnable);
  DAQ_writeVar(CBC_LOCAL_ENABLE_VAL, d->localCbcEnable);
  DAQ_writeVar(REF_CBC_GLOBAL_ENABLE_VAL, d->refGlobalCbcEnable);
  DAQ_writeVar(REF_CBC_LOCAL_ENABLE_VAL, d->refLocalCbcEnable);
  DAQ_writeVar(OVERRIDE_REF_CBC_LOCAL_CAP_ADJ_VAL, d->overrideLocalRefLocalCbcEnable);
  DAQ_writeVar(OVERRIDE_CBC_LOCAL_CAP_ADJ_VAL, d->overrideLocalRefLocalCbcEnable);
  DAQ_writeVar(L_CBC_GLOBAL_CAP_ADJ_VAL, d->leftGlobalCbcValue);
  DAQ_writeVar(R_CBC_GLOBAL_CAP_ADJ_VAL, d->rightGlobalCbcValue);
  DAQ_writeVar(REF_HI_CBC_LOCAL_CAP_ADJ_VAL, d->refHiLocalCbcValue);
  DAQ_writeVar(REF_LO_CBC_LOCAL_CAP_ADJ_VAL, d->refLoLocalCbcValue);
  {
    uint16 l_offset = (d->swapSensorSide) ? 0 : d->muxSize[1];
    uint16 r_offset = (d->swapSensorSide) ? d->muxSize[0] : 0;
#if CONFIG_LEFT_RIGHT_MIRROR
    uint16 offsetArray_right[MAX_PHY_TX];
    uint16 enableNum_right = 0;
    uint16 fireClusterNum = DAQ_readVar(TRANS_CLUSTERS);
    for (i = 0; i < fireClusterNum; i++)//initial array value: 0xFF
    {
      DAQ_writeVar(AFE_L_OFFSET_ARRAY + i, 0xFF);
      DAQ_writeVar(AFE_R_OFFSET_ARRAY + i, 0xFF);
    }
    for (i = 0; i < MAX_PHY_TX; i++)
    {
      int16 pos;
      pos = valToPos(d->imageTxes, d->muxSenseOrder[i], d->muxSize[0]);
      DAQ_writeVar(AFE_L_OFFSET_ARRAY + i, (0 <= pos) ? (pos + l_offset) * MAX_RX : 0xFF);
      pos = valToPos(d->imageTxes, d->muxSenseOrder[i], d->muxSize[1]);
      offsetArray_right[i] = (0 <= pos) ? (pos + r_offset) * MAX_RX : 0xFF;
      if(offsetArray_right[i] != 0xFF)
        enableNum_right++;
    }
    for (i = 0; i < enableNum_right; i++)
    {
      DAQ_writeVar(AFE_R_OFFSET_ARRAY + enableNum_right - 1 - i, offsetArray_right[i]);
    }
#else
    uint16 fireClusterNum = DAQ_readVar(TRANS_CLUSTERS);
    for (i = 0; i < fireClusterNum; i++)//initial array value: 0xFF
    {
      DAQ_writeVar(AFE_L_OFFSET_ARRAY + i, 0xFF);
      DAQ_writeVar(AFE_R_OFFSET_ARRAY + i, 0xFF);
    }
    for (i = 0; i < MAX_PHY_TX; i++)
    {
      int16 pos;
      pos = valToPos(d->imageTxes, d->muxSenseOrder[i], d->muxSize[0]);
      DAQ_writeVar(AFE_L_OFFSET_ARRAY + i, (0 <= pos) ? (pos + l_offset) * MAX_RX : 0xFF);
      pos = valToPos(d->imageTxes, d->muxSenseOrder[i], d->muxSize[1]);
      DAQ_writeVar(AFE_R_OFFSET_ARRAY + i, (0 <= pos) ? (pos + r_offset) * MAX_RX : 0xFF);
    }
#endif
    DAQ_writeVar(AFE_OFFSET_PNTR, 0);
  }
  for (i = 0; i < MAX_RX; i++)
  {
    DAQ_writeVar(CBC_L_LOCAL_CAP_ADJ_0_VAL + d->imageRxes[i],  d->imageCbcs[i]);
    DAQ_writeVar(CBC_R_LOCAL_CAP_ADJ_0_VAL + d->imageRxes[i],  d->imageCbcs[MAX_RX+i]);
  }

#if CONFIG_TDDI_AMP_BUTTONS
  #define BTN_RESET_GUARD_ENABLE (0x1000)  // RX_0D_RESET_WITH_GUARD
  #define BTN_GUARD_MUXES (0x0F00)

  DAQ_writeVar(BUTTON_BKP_ENABLED,(d->buttonOperationMode == BUTTON_MODE_SEPERATE ? 1 : 0));
  DAQ_writeVar(BUTTON_ABSTRANS_MODE,d->buttonAbsTransMode);  //0: abs-cap mode, 1: trans-cap mode
  DAQ_writeVar(BUTTON_NUM_ENABLED_X_RECEIVERS, 1);
  DAQ_writeVar(REF_HI_CAP_SEL_0D_VAL,d->buttonRefHiCap);
  DAQ_writeVar(REF_LO_CAP_SEL_0D_VAL,d->buttonRefLoCap);

  {
    uint16 i, afe_sel;

    DAQ_writeVar(BUTTON_CBC_GLOBAL_CAP_ADJ_VAL, d->buttonGlobalCbc);
    afe_sel = 0x0;
    for(i = 0; i < MAX_BUTTONS; i++)
    {
      uint16 tx = d->buttonTxes[i];
      uint16 afe = (tx < MAX_BUTTONS) ? 0 : 1;      // 0:afe_l, 1:afe_r
      DAQ_writeVar(BUTTON_RECEIVER_OFFSETS + i, 0);
      if (tx != 0xFF)
      {
        tx -= (afe * MAX_BUTTONS);
        afe_sel |= (0x01<<tx);
        if(d->buttonAbsTransMode == BUTTON_MODE_ABS)
        {
          //all remaining unsensed pins are used as guarding pins
          DAQ_writeVar(BUTTON_RCVR_VAL_ARRAY + i, ((0x1<<tx)<<4) | ((0x0F & (~(0x01<<tx)))<<8) | 0x1000);
        }
        else
        { //dcfg->buttonAbsTransMode == BUTTON_MODE_TRANS
          //all remaining unsensed pins are used as gnd pins
          DAQ_writeVar(BUTTON_RCVR_VAL_ARRAY + i, (0x0F & (~(0x01<<tx))) | ((0x1<<tx)<<4));
        }
        DAQ_writeVar(BUTTON_CBC_VAL_ARRAY + i, d->buttonLocalCbcs[i]);
        DAQ_writeVar(BUTTON_BANK_ARRAY + i, afe);
      }
      else
      {
        if(d->buttonAbsTransMode == BUTTON_MODE_ABS)
        {
          DAQ_writeVar(BUTTON_RCVR_VAL_ARRAY + i, 0x1F00);
        }
        else
        {  //dcfg->buttonAbsTransMode == BUTTON_MODE_TRANS
          DAQ_writeVar(BUTTON_RCVR_VAL_ARRAY + i, 0x000F);
        }
        DAQ_writeVar(BUTTON_CBC_VAL_ARRAY + i, 0);
        DAQ_writeVar(BUTTON_BANK_ARRAY + i, 0xFF);
      }
    }
    if(d->buttonAbsTransMode == BUTTON_MODE_ABS)
    {
      DAQ_writeVar(BUTTON_DAC_IN_VAL, d->dac_in_0d); //no dac in for abs-cap mode 0D
      //all remaining unsensed pins are used as guarding pins
      DAQ_writeVar(BUTTON_DOZE_RX_0D_MUX_VAL, ((0xF & afe_sel)<<4) | ((0xF & (~afe_sel))<<8) | 0x1000);
    }
    else
    {  //dcfg->buttonAbsTransMode == BUTTON_MODE_TRANS
      DAQ_writeVar(BUTTON_DAC_IN_VAL, 0);   //no dac in for trans-mode 0D
      //all remaining unsensed pins are used as gnd pins
      DAQ_writeVar(BUTTON_DOZE_RX_0D_MUX_VAL, (0xF & (~afe_sel)) | ((0xF & afe_sel)<<4));
    }
    DAQ_writeVar(BUTTON_DOZE_CBC_GLOBAL_CAP_ADJ_VAL,d->buttonGlobalCbcDoze);
    DAQ_writeVar(BUTTON_DOZE_CBC_LOCAL_CAP_ADJ_VAL,d->buttonLocalCbcDoze);
  }
#endif

  DAQ_writeVar(TOUCH_LPWG_SOUT_CTRL0_VAL, d->lpwgSoutCtrl0);
  DAQ_writeVar(TOUCH_LPWG_SOUT_CTRL1_VAL, d->lpwgSoutCtrl1);
#if CONFIG_LPWG_TIMING_CTRL
  DAQ_writeVar(LPWG_TIMING_CTRL_ENABLED, d->lpwgSoutCtrlEnable);
  DAQ_writeVar(NOTOUCH_LPWG_SOUT_CTRL0_VAL, d->noTouchLpwgSoutCtrl0);
  DAQ_writeVar(NOTOUCH_LPWG_SOUT_CTRL1_VAL, d->noTouchLpwgSoutCtrl1);
#endif

  throwAwayDummyFrame();

#if CONFIG_NSM
  {
    nsm_params_t np;
    uint16 mask;

#if CONFIG_NSM_CALLISTO
    uint16 *halfSensingPeriodPtr = np.halfSensingPeriod;
    uint16 sample_dur = DAQ_readVar(BASE_SAMPLE_DUR);
#endif

    np.powerimHighThresh = d->powerimHighThresh;
    np.powerimLowThresh = d->powerimLowThresh;
    np.powerimFnmHighThresh = d->powerimFnmHighThresh;

#if CONFIG_NSM_EUROPA
    np.fsim120Thresh        = d->fsimThresh;
    np.fsim60Thresh         = d->fsimThresh;
#else
    np.fsimThresh = d->fsimThresh;
#endif

    np.railimHighThresh = d->railimHighThresh;
    np.railimLowThresh = d->railimLowThresh;
    np.fsFnmDensity = d->fsFnmDensity;
    np.fnmTimeout = d->fnmTimeout;
    np.fsTimeout = d->fsTimeout;
    np.hnm60Timeout         = d->hnmRateShiftFrameCount;
    np.enableMultiFrameIM = 1;

#if CONFIG_NSM_CALLISTO
    np.varcidimHighThresh = d->varcidimHighThresh;
    np.varcidimLowThresh = d->varcidimLowThresh;
    np.holdoffTimeout = d->holdoffTimeout;
#endif

    np.dynamicSensingRate = d->dynamicSensingRate;

    np.inhibitFrequencyShift = d->inhibitFrequencyShift;
    np.noNoiseMitigation = d->noNoiseMitigation;
    np.disableFreq = 0;
    for (i = 0, mask = 1; i < MAX_FREQUENCIES; i++, mask <<= 1)
    {
#if CONFIG_NSM_CALLISTO
      *(halfSensingPeriodPtr++) = 3 + sample_dur +
        d->imageIntegDur + d->imageResetDur +
        d->freqTable.stretchDur[i] + d->freqTable.rstretchDur[i];
#endif
      if (d->freqTable.disableFreq[i])
        np.disableFreq |= mask;
    }

#if CONFIG_NSM_EUROPA
  np.transitionFrameCount = d->transitionFrameCount;
#endif

    np.enableChargerBit = 1;//Set: enable charger bit control

    nsm_init(&np);
  }
#endif

#if CONFIG_HAS_0D_BUTTONS
  initDoze(&scfg->dozeParams, d->imageTxes, d->numRows, d->buttonTxes, d->numButtons);
#else
  initDoze(&scfg->dozeParams, d->imageTxes, d->numRows, (uint16 *) NULL, d->numButtons);
#endif

  {
    //DAQVarId_t regs[] = {BUTTONS_ABS_ENABLED, BUTTONS_ENABLED, IMAGE_ENABLED, NOISE_ENABLED};
    //uint16 vals[] =     {CONFIG_HAS_0D_BUTTONS,CONFIG_HAS_0D_BUTTONS,   1,       CONFIG_NSM};
    //DAQ_writeVars(regs, vals, LEN(regs));

    //CONFIG_HAS_0D_BUTTONS: use BUTTON_ENABLED, BUTTON_BKP_ENABLED now
    //BUTTONS_ABS_ENABLED, BUTTONS_ENABLED, IMAGE_ENABLED: were never used in frame program
    DAQ_writeVar(NOISE_ENABLED, CONFIG_NSM);
  }

  PL_enterMode(mode_active);

  /* Saves common production test parameters */
  pp.numRows = d->numRows;
  pp.numCols = d->numCols;
  pp.numBtns = d->numButtons;
  pp.swapSensorSide = d->swapSensorSide;
  for (i = 0; i < 2; i++)
  {
    pp.muxSize[i] = d->muxSize[i];
  }
  for (i = 0; i < MAX_RX; i++)
  {
    pp.imageRxes[i] = d->imageRxes[i];
  }
  for (i = 0; i < MAX_PHY_RX; i++)
  {
    pp.imageCbcs[i] = d->imageCbcs[i];
  }
#if CONFIG_HAS_0D_BUTTONS
  pp.btnAbsTransMode = d->buttonAbsTransMode;
  pp.btnAutoCalibration = d->buttonAutoCalibration;
  pp.btnGlobalCbc = d->buttonGlobalCbc;
  for(i = 0; i < MAX_BUTTONS; i++)
  {
    if (d->buttonTxes[i] != 0xff)
    {
      pp.btnTxMask |= (1 << i);
    }
    pp.btnLocalCbcs[i] = d->buttonLocalCbcs[i];
  }
  pp.btnDeltaDozeCbc = (int16)(d->buttonGlobalCbcDoze) - (int16)(d->buttonGlobalCbc);
#endif
}

void PlatformApi_td4328::PL_enterMode(PLMode_t newMode)
{
  PLMode_t oldMode = mode;
  if (newMode == oldMode) return;
  #if defined (PASSTHROUGH_FORCE_CONTINUES_MODE) && (PASSTHROUGH_FORCE_CONTINUES_MODE == 1)
  DAQ_writeVar(CURRENT_TRIGGER_MODE, 1); // Force to continues mode
  #endif
  // switch out of the old mode to a neutral place
  // (currently no actions here)

  // turn on the new mode
  switch(newMode)
  {
  case mode_active:
  {
    DAQ_startContinuousAcquisition(0);
    break;
  }
  case mode_doze:
    DAQ_startContinuousAcquisition(1);
    break;
  case mode_deepSleep:
  {
    DAQ_startContinuousAcquisition(2);
    break;
  }
  case mode_idle:
    DAQ_stopAcquisition();
    break;
  default:
    break;
  }
  mode = newMode;
}

PLFrame_t* PlatformApi_td4328::PL_getFrame(PLFrameType_t frameType)
{
  PLFrame_t *plFrame;
  DAQFrame_t *daqFrame;
  int16 daqFrameType = 0;
  if (lastFrame != NULL)
  {
    DAQ_releaseFrame(lastFrame);
    lastFrame = NULL;
  }

  switch(frameType)
  {
  case frame_active:
    daqFrameType = 0;
    break;
  case frame_doze:
    daqFrameType = 1;
    break;
  case frame_deepsleep:
    daqFrameType = 2;
    break;
  case frame_restore:
    daqFrameType = 3;
    break;
  default:
    break;
  }

  // do any variable writes or mode switches necessary to set up this
  // frame (currently none).

  flags.resetDoze = 0;
  while(1)
  {
    daqFrame = DAQ_getFrame(daqFrameType);
    // check for CVI timeouts, other actionable errors here

    // decode the frame
    plFrame = (PLFrame_t *)daqFrame;

    if (frameType == frame_active)
    {
      daqErrorFlags_t daqError;
      daqError.all = plFrame->errorFlags;
      if ( (!COMM_getEnterDeepSleep())&& daqError.cviTimeout)
      {
        DAQ_releaseFrame(daqFrame);
        continue;
      }

    #if CONFIG_NSM
      nsm_evalNSM(flags.disableNoiseMitigation, daqFrame);
      {
        nsm_statevars_t v = nsm_getStatevars();
        if (v.frequencyShift)
          flags.resetDoze = 1;

        if (v.abortFrame)
        {
          continue;
        }
      }
    #endif
    }
    break; // keep the frame if we made it this far
  }

  // turn off special modes (none currently needed)

  plFrame->type = frameType;

  lastFrame = daqFrame;
  return plFrame;
}

void PlatformApi_td4328::PL_releaseFrame(PLFrame_t *f)
{
  DAQ_releaseFrame((DAQFrame_t *) f);
  lastFrame = NULL;
}

PLNSMState_t PlatformApi_td4328::PL_getNSMState()
{
  PLNSMState_t nsmState;
#if CONFIG_NSM
  nsm_ims_t ims = nsm_getIms();
  nsm_statevars_t state = nsm_getStatevars();
  nsmState.powerIM = ims.powerim;
  nsmState.railIM = ims.railim;
  nsmState.state = state.currentState;
  nsmState.frequency = state.currentFreq;
#if CONFIG_NSM_CALLISTO
  nsmState.varCidIM = ims.varcidim;
#endif
#if CONFIG_NSM_EUROPA
  nsmState.frameRate = state.currentRate;
  nsmState.frequencyTranState = state.frequencyTranState;
  nsmState.compLevel = (state.compLevel >= WITH_HIGH_BASELINE_COMPENSATATION);
#endif
#endif
  return nsmState;
}

void PlatformApi_td4328::PL_convertActiveFrameToRawCap(PLFrameData_t *frame , PLCapData_t *cap)
{
  memcpy(&cap->image[0], &frame->image[0], MAX_TX*MAX_RX*sizeof(frame->image[0]));
  convertImageToRawCapacitance(&cap->image[0]);

  memcpy(&cap->image[MAX_TX*MAX_RX], &frame->buttons[0], pp.numBtns*sizeof(frame->buttons[0]));
  convertButtonsToRawCapacitance(&cap->image[MAX_TX*MAX_RX]);
}

void PlatformApi_td4328::PL_convertActiveFrameToDeltaCap(PLFrameData_t *frame, PLCapData_t *cap)
{
  memcpy(&cap->image[0], &frame->image[0], MAX_TX*MAX_RX*sizeof(frame->image[0]));
  convertImageToDeltaCapacitance((int16*)cap->image);

  memcpy(&cap->image[MAX_TX*MAX_RX], &frame->buttons[0], pp.numBtns*sizeof(frame->buttons[0]));
  convertButtonsToDeltaCapacitance((int16*)&cap->image[MAX_TX*MAX_RX]);
}

void PlatformApi_td4328::PL_getTestFrame(prodTestType_t test, struct calcStaticConfig_t *scfg,
                     struct calcDynamicConfig_t *dcfg ATTR_UNUSED, prodTestResult_t *result)
{
  // Production tests here are allowed to modify any DAQ variables
  // they want. The caller is responsible for reinitializing the
  // platform object after each test.

  PL_enterMode(mode_idle);

  if (lastFrame != NULL)
  {
    DAQ_releaseFrame(lastFrame);
    lastFrame = NULL;
  }

  switch(test)
  {
  case prodTestType_etoeShort:
    doEtoeShortTest(scfg,result);
    break;
  case prodTestType_extendedSensorSpeed:
    doExtendedSensorSpeedTest(scfg,result);
    break;
  case prodTestType_adcSaturation:
    doAdcSaturationTest(scfg,result);
    break;
  #if CONFIG_EXTENDED_HIGH_RESISTENCE_TEST
  case prodTestType_extendedHighResistance:
    doExtendedHighResistanceTest(scfg,result);
    break;
  #endif
  #if CONFIG_REPORT_RAW_ADC_IMAGE_WITH_VCOM_DRIVE
  case prodTestType_rawADCWithVcomDrive:
    doRawADCWithVcomDriveTest(scfg,result);
    break;
  #endif
  #if CONFIG_OPEN_TEST_WITH_VCOM_DRIVE
  case prodTestType_openTestWithVcomDrive:
    doOpenTestWithVcomDriveTest(scfg,result);
    break;
  #endif
  default:
    break;
  }
}

void PlatformApi_td4328::PL_setParam(PLParam_t param_type, uint16 param_value)
{
  switch(param_type)
  {
    case PLFramePeriod:
        if (1<param_value)
        {
          DAQ_writeVar(ACTIVE_FRAME_PERIOD, param_value); // [FWTE-963] writing this makes baseline shift on tddi. Substituting DAQ_writeVar with DAQ_writeVarAsync doesn't make issue.
        }
        break;
#if CONFIG_NSM
    case PLDisableNSM:
        flags.disableNoiseMitigation = param_value;
        break;
    case PLObjectPresent:
        flags.objectsPresent = param_value;
        if(flags.disableNoiseMitigation == 0)
        {
          nsm_reportObjects(param_value);
        }
        break;
    case PLChargerPresent:
        nsm_setChargerPresent(param_value);
        break;
    case PLFreqTransCounter:
        nsm_resetFreqTransition();
        break;
#endif
    case PLTouchSensingMode:
        if (param_value == LONG_H_BLANK_MODE)
          DAQ_writeVarAsync(CURRENT_TRIGGER_MODE, 0);
        else if (param_value == CONTINUE_MODE)
          DAQ_writeVarAsync(CURRENT_TRIGGER_MODE, 1);
        else if (param_value == LONG_V_BLANK_MODE)
          DAQ_writeVarAsync(CURRENT_TRIGGER_MODE, 2);
        break;
#if CONFIG_IFP_ESD_ACTIVEMODE
   case PLESDMode:
        if (param_value == 0)
        {
           DAQ_writeVarAsync(PSEUDO_VB_MODE, 0);
           DAQ_writeVar(ESD_MODE, 0);
        }
        else if (param_value == 1)
        {
           DAQ_writeVarAsync(PSEUDO_VB_MODE, 1);
           DAQ_writeVar(ESD_MODE, 1);
        }
        break;
#endif
#if CONFIG_HAS_AUDIBLE_NOISE_MODE
   case PLBigObjectPresent:
        if (param_value == 1)
        {
           // [FWTDDI-1953] writing this makes abnormal noise burst sensing on tddi. Substituting DAQ_writeVar with DAQ_writeVarAsync doesn't make issue.
           DAQ_writeVarAsync(PSEUDO_VB_MODE, 1);
        }
        else
        {
           // [FWTDDI-1953] writing this makes abnormal noise burst sensing on tddi. Substituting DAQ_writeVar with DAQ_writeVarAsync doesn't make issue.
           DAQ_writeVarAsync(PSEUDO_VB_MODE, 0);
        }
        break;
#endif
    default:
        break;
  }
}

uint16 PlatformApi_td4328::PL_isDozeTimerResetRequested()
{
  return flags.resetDoze;
}

void PlatformApi_td4328::PL_copy0DToFrameBuffer(uint16 isAbsBtnData ATTR_UNUSED, uint16 *btnDataPtr, PLFrameData_t *frameBufferPtr)
{
  // To match TDDI production test format: DS5 read out [(MAX_TX*MAX_RX) + MAX_BUTTONS] for 2D and 0D data
  // Here we copy button data to frameBufferPtr->buttons, which means in PLFrameData_t,
  // buttons[] array should always be declared right after image[]

  memcpy(frameBufferPtr->buttons, btnDataPtr, MAX_BUTTONS*sizeof(frameBufferPtr->buttons[0]));
}

void PlatformApi_td4328::PL_0DButtonsScaling(uint16 *btnDataPtr, uint16 *btnScaleFactor)
{
  uint16 i;

  for (i = 0; i < MAX_BUTTONS; i++)
  {
    btnDataPtr[i] /= btnScaleFactor[i];
  }
}

uint16 PlatformApi_td4328::PL_isDozeWakeUpCondition(dozeParams_t *dozeConfig, int16 *deltaImage, uint16 size ATTR_UNUSED)
{
  // checks 2D
  if (maxAbs(&deltaImage[0], MAX_PHY_RX) > dozeConfig->dozeWakeUpThreshold) return 1;

  // checks 0D
  if (maxAbs(&deltaImage[MAX_PHY_RX], 1) > dozeConfig->dozeWakeUpThreshold0D) return 1;

  return 0;
}

PLFrame_t *PlatformApi_td4328::PL_getRcvrOffsetFrame()
{
  DAQFrame_t *f;

  while(1)
  {
    f = DAQ_getFrame(0);
    if(f->errorFlags.all)//the frames after display on are error. skip it.
    {
      DAQ_releaseFrame(f);
      #if !defined(WIN32)
      COMM_petWatchDog();
      #endif
    }
    else
      break;
  }
  return (PLFrame_t*)f;
}

void PlatformApi_td4328::PL_checkPowerStatus()
{
#if CONFIG_HAS_ESD_RECOVERY && !defined(WIN32)
  if (COMM_getPowerStatus() & 0x0C) //PWR_STATUS's bit2 and bit3 to indicate APO event
  {
      COMM_wakeupVideoThread();
  }
#endif
}

void PlatformApi_td4328::PL_calibrateButtons()
{
  #if (CONFIG_HAS_0D_BUTTONS && CONFIG_TDDI_AMP_BUTTONS && CONFIG_HAS_0D_AUTOCAL)
  DAQFrame_t *df;
  PLFrameData_t *f;
  uint16 raw[MAX_BUTTONS];
  uint16 distToCenter[MAX_BUTTONS];
  uint16 dist;
  uint16 i;
  uint16 retry;
  uint16 localCbcStatus;
  uint16 initLocalCbcStatus = 0;
  uint16 adjustCbc;
  uint16 lastLocalCbcs[MAX_BUTTONS], max_local_cbc = 0;
  int16 doze_global_cbc;
  uint16 vars[] = {BUTTON_CBC_GLOBAL_CAP_ADJ_VAL, BUTTON_CBC_VAL_ARRAY, BUTTON_CBC_VAL_ARRAY+1, BUTTON_CBC_VAL_ARRAY+2, BUTTON_CBC_VAL_ARRAY+3};

  if (!pp.btnAutoCalibration) return;

  for(i = 0; i < MAX_BUTTONS; i++)
  {
    raw[i] = 0;
    distToCenter[i] = 65535;
  }
  initLocalCbcStatus = ((~pp.btnTxMask) & ((1<<MAX_BUTTONS)-1));
  localCbcStatus = initLocalCbcStatus;

  for(retry = 0; retry < 16; ++retry)
  {
    // write new tac settings
    DAQ_writeVars(vars, &pp.btnGlobalCbc, MAX_BUTTONS+1);
    #if !defined(WIN32)
    COMM_petWatchDog();  //kick watchdog to prevent timeout error
    #endif

    if((localCbcStatus & pp.btnTxMask) == pp.btnTxMask)
    {
      break;
    }

    df = DAQ_getFrame(0);    //get 2D and 0D frame
    f = (PLFrameData_t*)&df->buffer;
    for(i = 0; i < MAX_BUTTONS; i++)
    {
      raw[i] = f->buttons[i];
    }
    DAQ_releaseFrame(df);    //release frame

    adjustCbc = 0;
    for(i = 0; i < MAX_BUTTONS; i++)
    {
      dist = raw[i] > 2500 ? raw[i]-2500 : 2500-raw[i];
      if(localCbcStatus & (1 << (MAX_BUTTONS+i))) // in progress of searching for better local cbc
      {
        if(dist > distToCenter[i])
        {
          pp.btnLocalCbcs[i] = lastLocalCbcs[i];
          localCbcStatus &= ~(1 << (MAX_BUTTONS+i)); // no need to search more
          localCbcStatus |= (1 << i); // found the best local cbc
        }
        else
        {
          distToCenter[i] = dist;
        }
      }

      // ignore the fixed local cbc(s)
      if((localCbcStatus & pp.btnTxMask) == pp.btnTxMask)
        break;

      if(localCbcStatus & (1 << i))
        continue;

      if((raw[i] > 1500) && (raw[i] < 3500))
        localCbcStatus |= (1 << (MAX_BUTTONS+i));

      if(raw[i] < 2500) // too low
      {
        if((pp.btnLocalCbcs[i] == 0) && ((localCbcStatus & (1 << (MAX_BUTTONS+i))) == 0)) // cannot increase adc by decreasing local cbc
        {
          adjustCbc |= 0x1; // decrease global cbc to increase adc
        }
        else
        {
          lastLocalCbcs[i] = pp.btnLocalCbcs[i];
          if(pp.btnLocalCbcs[i] > 0)
          {
            if(dist > 1000 && pp.btnLocalCbcs[i] > 1)
              pp.btnLocalCbcs[i] -= 2;
            else
              pp.btnLocalCbcs[i]--; // decrease local cbc to increase adc
            adjustCbc |=(0x1 << (2*MAX_BUTTONS+i));
          }
          else
          {
            adjustCbc |= (0x1 << MAX_BUTTONS);
          }
        }
      }
      else // too high
      {
        if((pp.btnLocalCbcs[i] == 15) && ((localCbcStatus & (1 << (MAX_BUTTONS+i))) == 0)) // cannot decrease adc by increasing local cbc
        {
          adjustCbc |= 0x2; // increase global cbc to decrease adc
        }
        else
        {
          lastLocalCbcs[i] = pp.btnLocalCbcs[i];
          if(pp.btnLocalCbcs[i] < 15)
          {
            if(dist > 1000 && pp.btnLocalCbcs[i] < 14)
              pp.btnLocalCbcs[i] += 2;
            else
              pp.btnLocalCbcs[i]++; // increase local cbc to decrease adc
            adjustCbc |=(0x1 << (2*MAX_BUTTONS+i));
          }
          else
          {
            adjustCbc |= (0x2 << MAX_BUTTONS);
          }
        }
      }
    }

    if((adjustCbc & ((1<<MAX_BUTTONS)-1)) == 0)
    {
      adjustCbc |= (adjustCbc>>MAX_BUTTONS) & ((1<<MAX_BUTTONS)-1);
    }

    if((adjustCbc & ((1<<MAX_BUTTONS)-1)) == 0x3) // failed!
    {
      break;
    }

    if((adjustCbc & ((1<<MAX_BUTTONS)-1)) == 0x1) // decrease global cbc
    {
      if(pp.btnGlobalCbc > 0)
      {
        pp.btnGlobalCbc--;
        localCbcStatus = initLocalCbcStatus;
      }
      else // failed
      {
        break;
      }

      for(i = 0; i < MAX_BUTTONS; i++)
      {
        distToCenter[i] = 65535;

        if(pp.btnTxMask & (1<<i))
        {
          if(adjustCbc & (1<<(2*MAX_BUTTONS+i)))
          {
            if(pp.btnLocalCbcs[i] < 15)
              pp.btnLocalCbcs[i]++;
          }
        }
      }
    }
    else if((adjustCbc & ((1<<MAX_BUTTONS)-1)) == 0x2) // increase global cbc
    {
      if(pp.btnGlobalCbc < 15)
      {
        pp.btnGlobalCbc++;
        localCbcStatus = initLocalCbcStatus;
      }
      else // failed
      {
        break;
      }

      for(i = 0; i < MAX_BUTTONS; i++)
      {
        distToCenter[i] = 65535;

        if(pp.btnTxMask & (1<<i))
        {
          if(adjustCbc & (1<<(2*MAX_BUTTONS+i)))
          {
            if(pp.btnLocalCbcs[i] > 0)
              pp.btnLocalCbcs[i]--;
          }
        }
      }
    }
  }

  max_local_cbc = pp.btnLocalCbcs[0];
  for (i = 1; i < MAX_BUTTONS; i++)
  {
    if (max_local_cbc < pp.btnLocalCbcs[i])
      max_local_cbc = pp.btnLocalCbcs[i];
  }
  doze_global_cbc = (int16)(pp.btnGlobalCbc) + pp.btnDeltaDozeCbc;
  if (doze_global_cbc < 0) doze_global_cbc = 0;
  else if (doze_global_cbc > 15) doze_global_cbc = 15;
  DAQ_writeVar(BUTTON_DOZE_CBC_GLOBAL_CAP_ADJ_VAL, doze_global_cbc);
  DAQ_writeVar(BUTTON_DOZE_CBC_LOCAL_CAP_ADJ_VAL, max_local_cbc);
  #endif
}

void PlatformApi_td4328::PL_setCurrentRate(uint16 rate ATTR_UNUSED)
{
  COMM_setReportRate((rate == 60)? 0x1 : 0x0);
}

#endif
