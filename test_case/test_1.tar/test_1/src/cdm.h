// Filename: cdm.h
// Description: header file for cdm.c
#ifndef _CDM_H_
#define _CDM_H_

#include "syna/syna_types.h"
#ifdef __cplusplus
extern "C"{
#endif
void cdm_init(uint16 cdm_enable, uint16 numEnabledTX, uint16 numEnabledRX, uint16 numButtons, uint16 numButtonRX, uint16 concurrentButtonAcquisition, uint16 numBurstsPerCluster);
void cdm_defineCDMMatrix(uint16 *imageTxes, uint16 len, uint16 *buttonTxes, uint16 *buttonRxes, uint16 *imageRxes, uint16 *numRxPerSet);
void cdm_decodeCDM(uint16 *image);
void cdm_decodeButtons(uint16 *buttonImage, uint16 *decodedButtons);
void cdm_copy0DToImageBuffer (uint16 *buttonData, uint16 *image);
#ifdef __cplusplus
}
#endif

#endif // _CDM_H_
