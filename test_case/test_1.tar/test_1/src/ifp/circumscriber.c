// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: circumscriber.c
// Description: Dilates clumps by 1 pixel
// $Id: circumscribe_clumps.c,v 1.5.8.1.4.1 2012/12/12 09:42:53 jjordan Exp $

#include "ifp_common.h"
#include "circumscriber.h"

static int16 isSameSign(int16 x, int16 y);
static int16 isOnEdge(uint16 row, uint16 col, uint16 maxRow, uint16 maxCol);
static int16 isBelowNoiseFloor(int16 v, int16 noiseFloor);

static int16 isSameSign(int16 x, int16 y)
{
  return (x^y) >= 0;
}

static int16 isOnEdge(uint16 row, uint16 col, uint16 maxRow, uint16 maxCol)
{
  return (row == 0) || (row >= maxRow) || (col == 0) || (col >= maxCol);
}

static int16 isBelowNoiseFloor(int16 v, int16 noiseFloor)
{
  int16 absv = (v < 0) ? (-v) : (v);
  return (absv <= noiseFloor);
}

/* ----------------------------------------------------------------------------
  Name: circumscriber_circumscribeClumps
  Purpose: The purpose of this routine is to draw a contour around a pixel group
  Inputs: clumps, delta image, sensor parameters
  Outputs: modified clumps structure
  Effects: None.
  Notes: - This routine will increase the bit clump border by one pixel.
         - Four-connectivity logic is used to define connected pixels.
           In other words, if a pixel is 0, then it will be relabeled to
           match its neighbor if either its north, south, east or west
           neighbor is set.
         - Neighbors of opposite sign will be ignored, so positive
           clumps will continue to only have positive pixels.
         - Pixels above the noise floor will not be added to any clumps
           so that pixels between split clumps will remain unassigned.
         - Implementation note: If one empty pixel has two differently
           labeled neighbors of the correct sign, it will be assigned
           the lower of the two labels.
---------------------------------------------------------------------------- */
void circumscriber_circumscribeClumps(clumps_t *clumps, int16 *deltaImage, sensorParams_t *sensorParams)
{
  uint16 i;
  uint16 maxRow;
  uint16 maxCol;

  pixelIndex_t *listImage;
  uint16 *labelImage;

  int16 rowOffsets[] = {-1, 0, 0, 1};
  int16 colOffsets[] = {0, -1, 1, 0};

  int16 noiseFloor = sensorParams->noiseFloor_LSB;

  listImage = clumps->listImage;
  labelImage = clumps->labelImage;

  maxRow = sensorParams->txCount + 1;
  maxCol = sensorParams->rxCount + 1;

  for (i = 0; i < MAX_OBJECTS; i++)
  {
    clumpInfo_t *clumpInfo;
    uint16 row;
    uint16 col;

    clumpInfo = &clumps->info[i];

    /*
     * The layout of each clump's pixel list is like this:
     * [add pixels here] [firstpixel] ... [peaklocation]
     *
     * We scan from firstPixel to peakLocation and add
     * new pixels to the front of the list. That way,
     * we do not end up visiting the newly added pixels and
     * only circumscribe the original clump.
     */

    row = clumpInfo->firstPixel.row;
    col = clumpInfo->firstPixel.col;

    while(row != 0)
    {
      uint16 addr;
      int16 pixelValue;
      int16 j;

      addr = row * (MAX_RX+1) + col;
      pixelValue = deltaImage[addr];

      for (j = 0; j < 4; j++)
      {
        uint16 neighborRow, neighborCol;
        uint16 neighborOffset;
        int16 neighborValue;

        neighborRow = row + rowOffsets[j];
        neighborCol = col + colOffsets[j];
        neighborOffset = neighborRow * (MAX_RX+1) + neighborCol;
        neighborValue = deltaImage[neighborOffset];

        /*
         * To add to the clump, the pixel must be
         * 1) unlabeled
         * 2) below the noise floor
         * 3) the same sign as the clump's peak
         * 4) not in the padding region
         */

        if ((labelImage[neighborOffset] == 0) &&
            isBelowNoiseFloor(neighborValue, noiseFloor) &&
            isSameSign(neighborValue, pixelValue) &&
            !isOnEdge(neighborRow, neighborCol, maxRow, maxCol))
        {
          labelImage[neighborOffset] = i+1;
          listImage[neighborOffset] = clumpInfo->firstPixel;
          clumpInfo->firstPixel.row = neighborRow;
          clumpInfo->firstPixel.col = neighborCol;
        }
      }
      row = listImage[addr].row;
      col = listImage[addr].col;
    }
  }
  return;
}
