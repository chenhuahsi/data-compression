//-----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//-----------------------------------------------------------------
// Filename: metal_detection_histogram.c
// Description: Header file is metal_detection.h

/* -------------------------------- Overview --------------------------------
                      Histogram Metal Detection Algorithm
  Background:
    Metal on AMP sensor more like to generate signal at very similar value. But
    the max value may keep changing depends on
      1. contacted area of TP.
      2. high/low ground mass (HGM/LGM) condition.
    It will be hard to tune algorithm using thresholds to distinguish following
    scenarios:
      1. bending vs LGM metal
      2. 10 fingers vs metal
      3. moisture vs metal
      4. palm vs metal

  Histogram:
    Histogram is basic image processing algorithm, which is light weighted
    algorithm to get basic info of current delta frame. Histogram is generated
    by counting all the tixels with same/similar value and map to a 1 dimension
    graph (1-D array).

    If interested, please refer to (https://en.wikipedia.org/wiki/Histogram) for
    more details.

      Histogram examples:

      1. Finger(s)
           =
          ===
          ===
          ====
          =====     =          =
        __=======_=_=_=__=_=_ ===__
        0 NF       200        400
          left peak        right peak

      2. Fully covered palm:
           =
          ===
          ===                =
          ====              ===
          =====     =      ====
        __=======_=_=_=__=======__
        0 NF       200        400
        left       mid      right

      3. Fully covered flat metal:
                             =
                             ==
                            ===
                            ===
                           =====
        __________________=======__
        0 NF       200        400
        left       mid      right

      4. Fully covered flat metal (LGM):
                   =
                   ==
                  ===
                  ===
                 =====
        ________=======___________
        0 NF       200        400
        left       mid      right

      5. Fully covered bumpy metal:
                   =        =
                 ============ =
        _______=================_____
        0 NF       200        400
        left       mid      right

  Solution:
    When placing metal board, all tixels will have higher value than noise floor.
    By mapping them to histogram, most points will shift from left to right. This
    is different to normal finger which will always have many points lands on
    left peak. So we calculate the weight of left and right peaks to check if it
    is more like metal or finger(s).

  Knowing issue:
    1. Hard coded parameters:
       a. buffer size of histogram is 32.
       b. min unit to divide the delta ADC value is 2.
       c. max delta is 1.5 * satuation capacitance.

    2. Fully covered palm may not have too much difference to metal.

  Debug enable:
    Enable RamBackdoor debug register:
      a. set "cfg_metal_detection_debug" 1 in cfg
      b. disable anti-bending or other delta artifact remover to see input delta
         array of metal detection.
------------------------------------------------------------------*/

/* =================================================================
   MODULE INCLUDES
==================================================================*/
#include "metal_detection.h"
#include "ifp_string.h"

#if CONFIG_IFP_SUPPRESS_METAL_HISTO
/* =================================================================
   MODULE MACRO
==================================================================*/
#define abs(A) ((A<0)?(-(A)):(A))
#if defined(cfg_metal_detection_debug) && (cfg_metal_detection_debug == 1)
# define METAL_DEBUG_ON 1
#else
# define METAL_DEBUG_ON 0
#endif

//* -------------------------
//  For collecting data
//---------------------------
// buffer size of histogram
#define METAL_HISTO_SIZE            32

// min unit to divide the delta ADC value.
#define METAL_HISTO_MIN_UNIT        2

/* =================================================================
   MODULE VARIABLES
==================================================================*/
/*
typedef struct
{
  uint16 enable;
  uint16 smoothLoop;
  uint16 tixelTotalCntRatio;
  uint16 onePeakWeightRatio;
  uint16 onePeakMinDelta;
  uint16 multiPeakLeftPeakMinDelta;
  uint16 multiPeakWeightRatio;
  uint16 multiPeakRightPeakWeightRatio;
  uint16 multiPeakMinDelta;
  uint16 hysteresis;
  //  uint16 * 10
} metalDetectConfig_t;
*/

// metal detection run-time params
typedef struct
{
  uint16 tixelTotal;
  int16 deltaMin;
  int16 deltaMax;
  uint16 tixelTotalCntThre;
  uint16 onePeakTixelCntThre;
  uint16 multiPeakTixelCntThre;
  uint16 multiPeakRightPeakTixelCntThre;
  uint16 hysteresisCnt;
  //  uint16 * 8
} metalDetectParams_t;

// Using ADCMetalxxx for compatiability with other metal detecion algorithom.
int16 ADCMetalState = 0; // 0: not detected, 1+: metal detected.
uint16 ADCMetalEnable; // 0: disable, 1: enable.

// mdh = metal detection histogram
static sensorParams_t * mdhSensorParams;
static metalDetectConfig_t mdhConfig; // metal detection config params
static metalDetectParams_t mdhParams;

static uint16 mdhPreHysteresis; // Hysteresis count before enter ESD_MODE
static uint16 mdhPreHysteresisCnt; // Hysteresis count before enter ESD_MODE

// Debug Vars
#if METAL_DEBUG_ON
// Histogram Array (1-D)
//   debug on - global; debug off - local
uint16 mdhHistrogramOri[METAL_HISTO_SIZE + 2];
uint16 mdhHistrogram[METAL_HISTO_SIZE + 2];
int16  mdhHistrogramPeakValley[METAL_HISTO_SIZE + 2];
//   debug on Only
uint16 mdhHistrogramLastDetected[METAL_HISTO_SIZE + 2];
uint16 metalDebug[34];
#endif

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/

//* -------------------------
//  Private functions
//---------------------------

//* -------------------------
//  Public functions
//---------------------------
// config
void metal_detect_configure(metalDetectConfig_t *metalDetectConfig ATTR_UNUSED)
{
  mdhConfig.enable                        = metalDetectConfig->enable;
  mdhConfig.smoothLoop                    = metalDetectConfig->smoothLoop;
  mdhConfig.tixelTotalCntRatio            = metalDetectConfig->tixelTotalCntRatio;
  mdhConfig.onePeakWeightRatio            = metalDetectConfig->onePeakWeightRatio;
  mdhConfig.onePeakMinDelta               = metalDetectConfig->onePeakMinDelta;
  mdhConfig.multiPeakLeftPeakMinDelta     = metalDetectConfig->multiPeakLeftPeakMinDelta;
  mdhConfig.multiPeakWeightRatio          = metalDetectConfig->multiPeakWeightRatio;
  mdhConfig.multiPeakRightPeakWeightRatio = metalDetectConfig->multiPeakRightPeakWeightRatio;
  mdhConfig.multiPeakMinDelta             = metalDetectConfig->multiPeakMinDelta;
  mdhConfig.hysteresis                    = metalDetectConfig->hysteresis;
#if 0
  // Hack for rambackdoor tuning
  mdhConfig.enable                        = 1;
  mdhConfig.smoothLoop                    = 3;
  mdhConfig.tixelTotalCntRatio            = 200;
  mdhConfig.onePeakWeightRatio            = 133;
  mdhConfig.onePeakMinDelta               = 30;
  mdhConfig.multiPeakLeftPeakMinDelta     = 150;
  mdhConfig.multiPeakWeightRatio          = 171;
  mdhConfig.multiPeakRightPeakWeightRatio = 128; // 50%
  mdhConfig.multiPeakMinDelta             = 30;
  mdhConfig.hysteresis                    = 15;
#endif
}

// initialization for metal parameters
void metal_detection_init(sensorParams_t *sensorParams)
{
  ADCMetalEnable = mdhConfig.enable;

  mdhSensorParams = sensorParams;

  mdhParams.tixelTotal = (mdhSensorParams->txCount) * (mdhSensorParams->rxCount);
  mdhParams.deltaMin = mdhSensorParams->noiseFloor_LSB / 2;
  mdhParams.deltaMax = mdhSensorParams->cSat_LSB + (mdhSensorParams->cSat_LSB >> 1); // cSat x 1.5

  mdhParams.tixelTotalCntThre =
    (uint16)((uint32) mdhConfig.tixelTotalCntRatio * mdhParams.tixelTotal / 256);
  mdhParams.onePeakTixelCntThre =
    (uint16)((uint32) mdhConfig.onePeakWeightRatio * mdhParams.tixelTotal / 256);
  mdhParams.multiPeakTixelCntThre =
    (uint16)((uint32) mdhConfig.multiPeakWeightRatio * mdhParams.tixelTotal / 256);
  mdhParams.hysteresisCnt = 0;

  ADCMetalState = 0;
  mdhPreHysteresis = mdhPreHysteresis?mdhPreHysteresis:10;
  mdhPreHysteresisCnt = 0;
}


// return metal detected state.
int16 metal_detection_getState(void)
{
  // Disabled?
  if (ADCMetalEnable == 0) { return 0; }

  // Hysteresis
  if (ADCMetalState)
  {
    mdhParams.hysteresisCnt = mdhConfig.hysteresis;
    return 1;
  }
  else if (mdhParams.hysteresisCnt > 0)
  {
    mdhParams.hysteresisCnt--;
    return 1;
  }

  return 0;
}

// return metal detected state for ESD Mode.
int16 metal_detection_getEsdState(void)
{
  // Disabled?
  if (ADCMetalEnable == 0) { return 0; }

  // Hysteresis
  if (ADCMetalState)
  {
    mdhPreHysteresisCnt++;
  }
  else
  {
    mdhPreHysteresisCnt = 0;
  }

  if (mdhPreHysteresisCnt >= mdhPreHysteresis)
  {
    return 1;
  }

  return 0;
}

/**************************************
  Function:
    metal_detection_detect()

  Steps:
    1. Create histogram
    2. Histogram smooth
    3. Calculate left/right peak weight
    4. Compare to thresholds
**************************************/
void metal_detection_detect(int16 *mDeltaImage)
{
  uint16 i, j;
  int16 value;
  int16 maxVal = 0, minVal = 0;
  int16 unitVal;
  int16 metalBumpiness;

  uint16 index, maxIndex = 0;
  uint16 nPeak = 0, lPeakIdx = 0, rPeakIdx = 0;
  uint16 nTixel = 0, rightArea = 0;

#if METAL_DEBUG_ON == 0
  uint16 mdhHistrogramOri[METAL_HISTO_SIZE + 2];
  uint16 mdhHistrogram[METAL_HISTO_SIZE + 2];
  int16 mdhHistrogramPeakValley[METAL_HISTO_SIZE + 2];
#endif

  ADCMetalState = 0;

  // Feature disabled?
  if (ADCMetalEnable == 0) { return; }

  /********************************************
    Step 0. Calculate Bumpiness
  ********************************************/
  // Check [1, -1] bumpiness.
  metalBumpiness = 0;
  for (i = 1; i <= mdhSensorParams->txCount; i++)
  {
    for (j = 2; j <= mdhSensorParams->rxCount - 2; j++) // skip first and last columns
    {
      int16 bump = abs(mDeltaImage[i * (MAX_RX + 1) + j] - mDeltaImage[i * (MAX_RX + 1) + j + 1]); // current - right pixel
      metalBumpiness = (bump < metalBumpiness)?metalBumpiness:bump;
      if (i < mdhSensorParams->txCount) // skip bottom edge
      {
        bump = abs(mDeltaImage[i * (MAX_RX + 1) + j] - mDeltaImage[(i + 1) * (MAX_RX + 1) + j + 1]); // current - bottom pixel
        metalBumpiness = (bump < metalBumpiness)?metalBumpiness:bump;
      }
    }
  }

  /********************************************
    Step 1. Create histogram
  ********************************************/
  memset16(mdhHistrogramOri, 0, sizeof(mdhHistrogramOri) / sizeof(uint16));

  // Find max delta, ignore small and negtive value and edge tixels
  for (i = 1; i <= mdhSensorParams->txCount; i++)
  {
    for (j = 1; j <= mdhSensorParams->rxCount; j++)
    {
      value = mDeltaImage[i * (MAX_RX + 1) + j];

      // skip small and negtive value
      if (value >= mdhParams.deltaMin)
      //if (abs(value) >= mdhParams.deltaMin)
      {
        // Overflow?
        if (value > mdhParams.deltaMax)
        {
          value = mdhParams.deltaMax;
        }

        // Save max
        if (value > maxVal)
        {
          maxVal = value;
        }

        nTixel++;
      }
    }
  }

  // Has enough tixels?
  if (nTixel < mdhParams.tixelTotalCntThre)
  {
    return;
  }

  // bumpiness is higher than metal, it is more like finger.
  // TODO: make bumpiness threshold tunable
  if (metalBumpiness > (((maxVal / 4) > 40) ? (maxVal / 4) : 40))
  {
    return;
  }

  // calculate min histogram unit
  minVal = (maxVal / 16 > mdhParams.deltaMin) ? (maxVal / 16) : mdhParams.deltaMin;
  if ((maxVal - minVal) <= (METAL_HISTO_MIN_UNIT * METAL_HISTO_SIZE))
  {
    unitVal = METAL_HISTO_MIN_UNIT;
    maxIndex = ((maxVal - minVal) + unitVal - 1) / unitVal;
  }
  else
  {
    unitVal = (maxVal - minVal + METAL_HISTO_SIZE - 1) / METAL_HISTO_SIZE;
    maxIndex = METAL_HISTO_SIZE;
  }

  // map the pixels' delta range in minVal ~ maxVal, ignore the edge pixels
  for (i = 1; i <= mdhSensorParams->txCount; i++)
  {
    for (j = 1; j <= mdhSensorParams->rxCount; j++)
    {
      value = mDeltaImage[i * (MAX_RX + 1) + j];

      // Skip small value
      if (value < minVal) { continue; }

      // Overflow?
      if (value > mdhParams.deltaMax)
      {
        value = mdhParams.deltaMax;
      }

      value -= minVal;

      // Calc index
      index = value / unitVal;
      if (index >= maxIndex)
      {
        index = maxIndex - 1;
      }

      mdhHistrogramOri[index + 1]++;
    }
  }
  maxIndex++;

  /********************************************
    Step 2. Histogram smooth
  ********************************************/
  // Histogram smooth, skip 0
  mdhHistrogram[0] = mdhHistrogramOri[0];
  mdhHistrogram[maxIndex] = mdhHistrogramOri[maxIndex];
  for (j = 0; j < mdhConfig.smoothLoop; j++)
  {
    for (i = 1; i < maxIndex; i++)
    {
      mdhHistrogram[i] = mdhHistrogramOri[i] + mdhHistrogramOri[i - 1] + mdhHistrogramOri[i + 1];
      mdhHistrogram[i] /= 3;
    }
    memcpy16(mdhHistrogramOri, mdhHistrogram, sizeof(mdhHistrogramOri)/sizeof(mdhHistrogramOri[0]));
  }

#if METAL_DEBUG_ON
  // clean the rest of the buffer
  for (; i < (int16)(sizeof(mdhHistrogram) / sizeof(uint16)); i++)
  {
    mdhHistrogram[i] = 0;
  }
#endif


  /********************************************
    Step 3. Calculate left/right peak weight
  ********************************************/
  // Number of peaks/valleys of histogram
  memset16(mdhHistrogramPeakValley, 0, sizeof(mdhHistrogramPeakValley) / sizeof(uint16));
  for (i = 1; i < maxIndex; i++)
  {
    // Peak?
    if ((mdhHistrogram[i] > mdhHistrogram[i - 1])
        && (mdhHistrogram[i] >= mdhHistrogram[i + 1]))
    {
      mdhHistrogramPeakValley[i] = mdhHistrogram[i];
      nPeak++;
    }
    // Valley?
    else if ((mdhHistrogram[i] < mdhHistrogram[i - 1])
             && mdhHistrogram[i] <= mdhHistrogram[i + 1])
    {
      mdhHistrogramPeakValley[i] = -1 * mdhHistrogram[i];
      //nValley++;
    }
  }

  if (nPeak == 1)
  {
    for (i = 0, lPeakIdx = 0, rPeakIdx = 0; i < maxIndex; i++)
    {
      if ((mdhHistrogramPeakValley[i] > 0) &&
          (mdhHistrogramPeakValley[i] > mdhHistrogramPeakValley[lPeakIdx]))
      {
        rPeakIdx = lPeakIdx = i;
      }
    }
    //leftArea = rightArea = metalArea;
  }
  else
  {
    // Search for left peak.
    for (i = 0, lPeakIdx = 0; i < maxIndex; i++)
    {
      if ((mdhHistrogramPeakValley[i] > 0)
          && (mdhHistrogramPeakValley[i] > mdhHistrogramPeakValley[lPeakIdx]))
      {
        lPeakIdx = i;
        break;
      }
    }

    // Search for highest right peak.
    for (i = (maxIndex - 1), rPeakIdx = (maxIndex - 1); i > lPeakIdx; i--)
    {
      if ((mdhHistrogramPeakValley[i] > 0)
          && (mdhHistrogramPeakValley[i] > mdhHistrogramPeakValley[rPeakIdx]))
      {
        rPeakIdx = i;
      }
    }

    // Accumulate right area
    // From (lPeakIdx + rPeakIdx)/2 to rPeakIdx. (Any better way?)
    for (j = rPeakIdx; (j > i) && (mdhHistrogram[j] > mdhHistrogram[(rPeakIdx + lPeakIdx) / 2]); j--)
    {
      rightArea += mdhHistrogram[j];
    }
    for (j = rPeakIdx + 1; (j < maxIndex); j++)
    {
      rightArea += mdhHistrogram[j];
    }
  }

  /********************************************
    Step 4. Compare to thresholds
  ********************************************/
  mdhParams.multiPeakRightPeakTixelCntThre =
    (uint16)((uint32) mdhConfig.multiPeakRightPeakWeightRatio * nTixel / 256);

  // peak count == 1, avoid bending.
  if (nPeak == 1
    && (nTixel >= mdhParams.onePeakTixelCntThre)
    && (rPeakIdx * unitVal + minVal) > (mdhConfig.onePeakMinDelta))
  {
    ADCMetalState = 1;
  }
  // peak count > 1, but left peak is too high, still consider as one peak.
  else if (nPeak > 1
   && (nTixel >= mdhParams.onePeakTixelCntThre)
   && (lPeakIdx * unitVal + minVal) > (mdhConfig.multiPeakLeftPeakMinDelta))
  {
   ADCMetalState = 2;
  }
  // peak count > 1, metal plate or LGM fingers?
  else if (nPeak > 1
    && (nTixel >= mdhParams.multiPeakTixelCntThre)
    && (rightArea > mdhParams.multiPeakRightPeakTixelCntThre)
    && (rPeakIdx * unitVal + minVal) > (mdhConfig.multiPeakMinDelta))
  {
    ADCMetalState = 3;
  }

  /********************************************
    Debug registers, feel free to modify.
  ********************************************/
#if METAL_DEBUG_ON
  // current frame
  metalDebug[0]  = ADCMetalState;
  metalDebug[1]  = unitVal;
  metalDebug[2]  = lPeakIdx;
  metalDebug[3]  = rPeakIdx;
  metalDebug[4]  = rightArea;
  metalDebug[5]  = nTixel;
  metalDebug[6]  = minVal;
  metalDebug[7]  = maxVal;
  metalDebug[8]  = mdhParams.multiPeakRightPeakTixelCntThre;

  // stable params
  metalDebug[9]  = mdhParams.deltaMin;
  metalDebug[10] = mdhParams.deltaMax;
  metalDebug[11] = mdhParams.onePeakTixelCntThre;
  metalDebug[12] = mdhConfig.onePeakMinDelta;
  metalDebug[13] = mdhParams.multiPeakTixelCntThre;
  metalDebug[14] = mdhConfig.multiPeakMinDelta;
  metalDebug[15] = mdhParams.hysteresisCnt;

  // last metal detected frame
  if (ADCMetalState != 0)
  {
    metalDebug[16] = ADCMetalState;
    metalDebug[17] = unitVal;
    metalDebug[18] = lPeakIdx;
    metalDebug[19] = rPeakIdx;
    metalDebug[20] = rightArea;
    metalDebug[21] = nTixel;
    metalDebug[22] = minVal;
    metalDebug[23] = maxVal;
    metalDebug[24] = mdhParams.multiPeakRightPeakTixelCntThre;
    memcpy16(mdhHistrogramLastDetected, mdhHistrogram, 34);
  }
  // last metal not detected frame
  else
  {
    metalDebug[25] = ADCMetalState;
    metalDebug[26] = unitVal;
    metalDebug[27] = lPeakIdx;
    metalDebug[28] = rPeakIdx;
    metalDebug[29] = rightArea;
    metalDebug[30] = nTixel;
    metalDebug[31] = minVal;
    metalDebug[32] = maxVal;
    metalDebug[33] = mdhParams.multiPeakRightPeakTixelCntThre;
  }
#endif
  return;
}
#endif
