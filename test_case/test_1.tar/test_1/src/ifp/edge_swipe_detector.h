#ifndef _edge_swipe_detector_H_
#define _edge_swipe_detector_H_
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: position_reporter.h
   Description: Header for calling the position reporter module.

  $Id: position_reporter.h,v 1.5 2012/07/21 19:34:04 mposadas Exp $
----------------------------------------------------------------- */

#include "ifp_common.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

/* =================================================================
   MODULE TYPES
==================================================================*/

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* -----------------------------------------------------------
Name: edgeSwipeDetector_init()
Purpose: Initializes the edge swipe detector
Inputs: none
Outputs: none
Effects: Resets internal state, as at power-on.
Notes: This function must be called before using the module.
Example: none
----------------------------------------------------------- */
void edgeSwipeDetector_init(void);

/* -----------------------------------------------------------
Name: edgeSwipeDetector_reinit()
Purpose: Reinitializes the edge swipe detector
Inputs: none
Outputs: none
Effects: Resets internal state, as at a host rezero.
Notes: This function must be called if the host sends a rezero
       command.
Example: none
----------------------------------------------------------- */
void edgeSwipeDetector_reinit(void);

/* -----------------------------------------------------------
Name: edgeSwipeDetector_configure()
Purpose: Set host-defined parameters
Inputs: edgeMinX, edgeMinY, edgeMaxX, edgeMaxY: the edges of the touch
          region for the purposes of edge swipe entry
Outputs: none
Effects: none
Notes:   none
Example: none
----------------------------------------------------------- */
void edgeSwipeDetector_configure(edgeSwipeDetectorConfig_t* config);

/* -----------------------------------------------------------
Name: edgeSwipeDetector_detectEdgeSwipe()
Purpose: adds touches at edge of screen for swipes
Inputs: inReport - the report data structure
Outputs: outReport - the report data structure, possibly with added touches
           to ensure swipes begin at edge
Effects: The internal deque of the edge swipe detector is rotated
Notes:   none
Example: none
----------------------------------------------------------- */
void edgeSwipeDetector_detectEdgeSwipe(reportData_t *reportIn,
                                       reportData_t *reportOut);

#endif /* matches #ifndef _position_reporter_H_ */
