/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2015 - 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 *
 */

#ifndef _EXTREME_NOISE_REMOVER_H_
#define _EXTREME_NOISE_REMOVER_H_

#include "ifp_common.h"

#if CONFIG_HAS_EXTREME_NOISE_REMOVER
void initDeltaIIR(int16 *deltaCur);
void updateDeltaIIR(int16 *deltaCur);
void updateAlphaIIR(void);
void extreme_noise_remover_configure(segmenterConfig_t *sgConfig, classifierConfig_t *clsConfig, sensorParams_t *sensorParams, extremeNoiseRemoverConfig_t *eNoiseRemoverConfig);
void setSegmenterParams(uint16 noiseStateCurr);
void rephraseTouchType(trackedObject_t *tObjs, classification_t *cObjs, uint16 touchType, uint16 *originalTouchType);
#else
static ATTR_INLINE void initDeltaIIR(ATTR_UNUSED int16 *deltaCur) {};
static ATTR_INLINE void updateDeltaIIR(ATTR_UNUSED int16 *deltaCur) {};
static ATTR_INLINE void updateAlphaIIR(void) {};
static ATTR_INLINE void extreme_noise_remover_configure(ATTR_UNUSED segmenterConfig_t *sgConfig,
                                                        ATTR_UNUSED classifierConfig_t *clsConfig,
                                                        ATTR_UNUSED sensorParams_t *sensorParams,
                                                        ATTR_UNUSED extremeNoiseRemoverConfig_t eNoiseRemoverConfig) {};
static ATTR_INLINE void setSegmenterParams(ATTR_UNUSED uint16 noiseStateCurr) {};
static ATTR_INLINE void rephraseTouchType(ATTR_UNUSED trackedObject_t *tObjs,
                                          ATTR_UNUSED classification_t *cObjs,
                                          ATTR_UNUSED uint16 touchType,
                                          ATTR_UNUSED uint16 *originalTouchType) {};
#endif // CONFIG_HAS_EXTREME_NOISE_REMOVER

#endif // _EXTREME_NOISE_REMOVER_H_
