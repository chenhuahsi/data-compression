#ifndef _SIDE_TOUCH_H_
#define _SIDE_TOUCH_H_
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100
----------------------------------------------------------------- */
#include "ifp_common.h"

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

//2D frame
typedef struct
{
  int singleFrame[4][MAX_RX];
} frameData;

typedef struct
{
  frameData rawProfile2D [20]; //[40]; //[16]; //[T_OFFSET + 1];
} frameBuffer;

typedef struct
{
  int maxInd; //Integer index
  int firstNeighborInd;
  int lastNeighborInd;
  float sensorVal; //Averaged sensor response
  float precisePos; //Precise index
} fingerParams;

#if CONFIG_HAS_SIDE_TOUCH
  void sideTouch_run(uint16* rawImage);
  void sideTouch_init(void);
  void sideTouch_reinit(void);
  void sideTouch_configure(sideTouchTemporalFilter_t *sideTouchTemporalFilterConfig);

  void calculateTemporalDifference(uint16* rawImage);
  void detectFingers(void);
  fingerParams findFingerParams (int edge, int maxInd, int temporalDiff[4][MAX_RX]);
  void differentialFingerTracking(int16 *posPositionGau, int16 posNum, sideFinger_t *fingerList, int16 *peakPosition, int16 *isLargeObject);
  void differentialSwipeDetection(sideFinger_t *fingerList, int16 *posPosition, int16 posNum);
  void reportSwipe(sideFinger_t *fingerList,sideTouchSwipeRecord_t *swipeRecord);
#else
  static ATTR_INLINE void sideTouch_run(uint16* rawImage ATTR_UNUSED) {}
  static ATTR_INLINE void sideTouch_init(void) {}
  static ATTR_INLINE void sideTouch_reinit(void) {}
  static ATTR_INLINE void sideTouch_configure(sideTouchTemporalFilter_t *sideTouchTemporalFilterConfig ATTR_UNUSED) {}
#endif

#endif /* matches #ifndef _SIDE_TOUCH_H_ */
