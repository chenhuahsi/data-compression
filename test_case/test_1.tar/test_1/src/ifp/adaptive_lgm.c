/* -----------------------------------------------------------------
   Description: Dynamically compensate for LGM condition by
                adjusting finger threshold.
                ALGM takes mSensorParams.cSat_LSB as input,
                and adjusts it based on the algorithm csat_lsb
                (saturation constant) is re-assigned back to
                mSensorParams.cSat_LSB before baseline check

   $Id: adaptive_lgm.c
----------------------------------------------------------------- */

#include "ifp_common.h"

#if CONFIG_HAS_ADAPTIVE_LGM

#include "ifp_string.h"
#include "adaptive_lgm.h"

#if CONFIG_IFP_ALGM_FITCURVE_ENABLE
#define LGM_EXP_FITTING  1

// Workaroud to fix the issue that when there are two or more glove fingers in HGM, sometimes the gloveFigners are classified as fingers
// The reason is that the gloveFiners in HGM are classified as LGM Fingers.
#define DIV_HGMGLOVE_LGMFINGER 1

// area = accumChange/maxDelta;
//fingerAmplitudeThreshold (LGM) = 205 * e^(-(area/19)) + 35   =  factorA * e^(-(area/factorT)) + factorB
#define EXP_X_MAX   4.95
#define EXP_X_STEP  0.05
#define EXP_X_STEP_INVERSE (1/EXP_X_STEP)
#define EXP_NUM_MAX 100

static uint16 factorA;  // 205
static uint16 factorT;  // 19
static uint16 factorB;  // 35
static uint16 minPeak_10Fingers;
static uint16 fingerThresholdRatioPct;
static uint16 smallObjectPeak;

//lookup table for e^(-x), x rang[0~ 4.95], step 0.05
static rom_float expTable[EXP_NUM_MAX] = {
  1.000000,  0.951229,  0.904837,  0.860708,  0.818731,  0.778801,  0.740818,  0.704688,  0.670320,  0.637628,
  0.606531,  0.576950,  0.548812,  0.522046,  0.496585,  0.472367,  0.449329,  0.427415,  0.406570,  0.386741,
  0.367879,  0.349938,  0.332871,  0.316637,  0.301194,  0.286505,  0.272532,  0.259240,  0.246597,  0.234570,
  0.223130,  0.212248,  0.201897,  0.192050,  0.182684,  0.173774,  0.165299,  0.157237,  0.149569,  0.142274,
  0.135335,  0.128735,  0.122456,  0.116484,  0.110803,  0.105399,  0.100259,  0.095369,  0.090718,  0.086294,
  0.082085,  0.078082,  0.074274,  0.070651,  0.067206,  0.063928,  0.060810,  0.057844,  0.055023,  0.052340,
  0.049787,  0.047359,  0.045049,  0.042852,  0.040762,  0.038774,  0.036883,  0.035084,  0.033373,  0.031746,
  0.030197,  0.028725,  0.027324,  0.025991,  0.024724,  0.023518,  0.022371,  0.021280,  0.020242,  0.019255,
  0.018316,  0.017422,  0.016573,  0.015764,  0.014996,  0.014264,  0.013569,  0.012907,  0.012277,  0.011679,
  0.011109,  0.010567,  0.010052,  0.009562,  0.009095,  0.008652,  0.008230,  0.007828,  0.007447,  0.007083
};

//collect LGM data via Stylus Tool
static uint16 lgmMaxDeltaValTest;
static uint16 lgmRelatedAreaTest;
static uint16 lgmFingerPredictMaxValTest;
static uint16 lgmRealFingerThresholdTest;

#if DIV_HGMGLOVE_LGMFINGER
// div HGM glove and LGM finger
static uint16 gloveHGMPeakMin;
static uint16 gloveHGMValAveMin;
static uint16 gloveHGMValAveMax;
static uint16 gloveHGMValAveRatioMin;
static uint16 gloveHGMValAveRatioMax;
static uint16 gloveHGMRelatedAreaMin;
static uint16 gloveHGMRelatedAreaMax;
static uint16 gloveHGMAveRaitoOffsetMin;
static uint16 gloveHGMAveRaitoOffsetMax;
//collect Glove data via RAM Back Door.
static uint16 lgmGloveDebugData[10];
#endif

static uint16 debugLGMParams[10];  // for debug
#endif
static float prevK;
static float accumChange;

static uint16 initCSat;

static struct
{
  aLGMConfig_t scfg;
  uint16 enabled;
}params;

void ALGM_init()
{
  prevK = 1.0;
}

void ALGM_reinit()
{
  ALGM_init();
}

void setAlgmEnabled (uint16 enable)
{
  params.enabled = enable;
}

void aLGM_configure(aLGMConfig_t *config)
{
  memcpy16(&params.scfg, config, sizeof(aLGMConfig_t) / sizeof(uint16));
#if LGM_EXP_FITTING
  factorA = params.scfg.fitCurveFactorA;
  factorT = params.scfg.fitCurveFactorT;
  factorB = params.scfg.fitCurveFactorB;
  minPeak_10Fingers = factorB;
  fingerThresholdRatioPct = params.scfg.fitCurveFingerThresholdRatioPct;
  smallObjectPeak = params.scfg.fitCurveMiniPeak;

#if DIV_HGMGLOVE_LGMFINGER
  gloveHGMPeakMin = 35;
  gloveHGMValAveMin = 20;
  gloveHGMValAveMax = 35;
  gloveHGMValAveRatioMin = 40; // 40%
  gloveHGMValAveRatioMax = 65; // 65%
  gloveHGMRelatedAreaMin = 15;
  gloveHGMRelatedAreaMax = 150;
  gloveHGMAveRaitoOffsetMin = 15;
  gloveHGMAveRaitoOffsetMax = 40;

  // gloveHGMValAveMin < valAve < gloveHGMValAveMax
  // gloveHGMValAveRatioMin < aveRatio < gloveHGMValAveRatioMax
  // valAve + gloveHGMAveRaitoOffsetMin < vaeRatio < valAve + gloveHGMAveRaitoOffsetMax
#endif

  // For debug
  debugLGMParams[0] = params.scfg.fitCurveEnable;           // 1
  debugLGMParams[1] = params.scfg.fitCurveTuningEnable;     // 1
  debugLGMParams[2] = params.scfg.fitCurveFactorA;          // 205
  debugLGMParams[3] = params.scfg.fitCurveFactorB;          // 35
  debugLGMParams[4] = params.scfg.fitCurveFactorT;          // 19
  debugLGMParams[5] = params.scfg.fitCurveFingerThresholdRatioPct;  // 70%
  debugLGMParams[6] = params.scfg.fitCurveMiniPeak;         // 28
  debugLGMParams[7] = params.scfg.filterCoeff;              // 10%
  debugLGMParams[8] = params.scfg.accumThresh;
  debugLGMParams[9] = params.scfg.minCompFactor;
#endif
}
#if LGM_EXP_FITTING
// This algorithm is from branch td4300_dev_OEMDemo_20151113
// For more information, see FWTDDI-794(Find a best curve to change the ALGM parameter for TD4300)

static float expCalc(uint16 x)
{
  // e^x =~ 1 + x + x^2/2 + x^3/6
  //return (float)(1.0 + x + x*x/2 + x*x*x/6);

  // Get the value via lookup table.
  x = (x < EXP_NUM_MAX) ? x : (EXP_NUM_MAX-1);
  return expTable[x];
}

uint16 getALGMTuningEnableStatus()
{
  return (params.scfg.fitCurveTuningEnable);
}

void collectLGMData(uint16 *pLGMMaxDeltaValTest,
                         uint16 *pLGMRelatedAreaTest,
                         uint16 *pLGMFingerPredictMaxValTest,
                         uint16 *pLGMRealFingerThresholdTest)
{
  *pLGMMaxDeltaValTest = lgmMaxDeltaValTest;
  *pLGMRelatedAreaTest = lgmRelatedAreaTest;
  *pLGMFingerPredictMaxValTest = lgmFingerPredictMaxValTest;
  *pLGMRealFingerThresholdTest = lgmRealFingerThresholdTest;
}
/* -----------------------------------------------------------------
Name:  adaptive_LGM_compensate
Purpose: calculate ALGM coefficient K
Inputs: pointer to Delta Image, sensor parameters struct
Outputs: K
Effects: None
Notes: None
Example: None.
Notes: this module is not optimized.
One way it can be optimized by limiting float multiplications and divisions

For more information, see FWTDDI-794(Find a best curve to change the ALGM parameter for TD4300)
-----------------------------------------------------------------*/
void adaptive_LGM_compensate(int16 *pDeltaImage, sensorParams_t *mSensorParams)
{
  uint16 xVal;  // input parameter for e^(-x) to lookup table.
  uint16 realFingerThreshold;
  uint16 predictLGMFingerMaxDeltaVal;
  uint16 aveRatio;
  uint16 numElectrodesValid;
  float valAve;
  float normalFingerThreshold;
  float cSat, noiseFloor;
  float maxDelta;
  float k=prevK;
  float alpha;
  float relatedArea;
  uint16 kVal;
  if (!params.enabled)
  {
     k = 1;
     prevK = k;
  }
  else
  {
      cSat = (float)mSensorParams->cSat_LSB;

  noiseFloor = (float)mSensorParams->noiseFloor_LSB;
  alpha = (float)params.scfg.filterCoeff/100;
  normalFingerThreshold = ((uint32)cSat*params.scfg.normalFingerThreshold_pct) >> 16;

  maxDelta = (float)getMaxTixelDeltaImage_ALGM(pDeltaImage, mSensorParams);  //find maximum value over the delta image
  numElectrodesValid = estimateElectrodesAccumDelta(pDeltaImage, noiseFloor, mSensorParams);
  relatedArea = accumChange/maxDelta;

#if DIV_HGMGLOVE_LGMFINGER
  if(numElectrodesValid > 0)
  {
    valAve = accumChange/numElectrodesValid;
  }
  else
  {
    valAve = 0;
  }

  if(maxDelta > 0)
  {
    aveRatio = valAve/maxDelta * 100;
  }
  else
  {
    aveRatio = 0;
  }
#endif

  if (maxDelta > noiseFloor)
  {
    // area = accumChange/maxDelta;
    //fingerAmplitudeThreshold (LGM) =  factorA * e^(-(area/factorT)) + factorB
    // put these code here to collect data.
    float valTemp;
    valTemp = relatedArea/factorT;
    xVal = (uint16)((valTemp + EXP_X_STEP/2)*EXP_X_STEP_INVERSE);
    xVal = (xVal < EXP_NUM_MAX) ? xVal : (EXP_NUM_MAX-1);
    valTemp = factorA * expCalc(xVal) + factorB;
    predictLGMFingerMaxDeltaVal = (uint16)(valTemp + ((valTemp > 0) ? 0.5 : (-0.5)));
    predictLGMFingerMaxDeltaVal = (predictLGMFingerMaxDeltaVal > minPeak_10Fingers) ? predictLGMFingerMaxDeltaVal : minPeak_10Fingers;

    if((uint16)maxDelta > (uint16)(normalFingerThreshold * 2))
    {
      //assume it is in HGM
      k = 1.0;
    }
    else if((uint16)maxDelta < smallObjectPeak)
    {
      //assume it is small object, do not adjust
      k = 1.0;
    }
    else
    {
       //adjust based on current maxDeltaVal
       uint16 fingerTh = predictLGMFingerMaxDeltaVal;
       uint16 maxDataVal = (uint16)maxDelta;
       if(maxDataVal > (fingerTh*11/10))
       {
          fingerTh =(maxDataVal + fingerTh)/2;
          //fingerTh = (fingerTh < maxDataVal) ? fingerTh : maxDataVal;
       }

       //realFingerThreshold = fingerTh*70/100; // assume the minpeak is more than 0.7 * predictFingerThreshold
       realFingerThreshold = fingerTh*fingerThresholdRatioPct/100; // assume the minpeak is more than 0.7 * predictFingerThreshold

       k = (float)realFingerThreshold / normalFingerThreshold;

       kVal = (uint16)(k*100);
       if(kVal >= 100)
       {
         k = 1.0;
       }
#if DIV_HGMGLOVE_LGMFINGER
       else if((maxDataVal > gloveHGMPeakMin) && (maxDataVal < normalFingerThreshold))
       {
          if((relatedArea < gloveHGMRelatedAreaMax) && (relatedArea > gloveHGMRelatedAreaMin))
          {
            // gloveHGMValAveMin < valAve < gloveHGMValAveMax
            // gloveHGMValAveRatioMin < aveRatio < gloveHGMValAveRatioMax
            // valAve + gloveHGMAveRaitoOffsetMin < vaeRatio < valAve + gloveHGMAveRaitoOffsetMax
            if((valAve > gloveHGMValAveMin) && (valAve < gloveHGMValAveMax) && \
               (aveRatio > gloveHGMValAveRatioMin) && (aveRatio < gloveHGMValAveRatioMax) && \
               (aveRatio > (valAve + gloveHGMAveRaitoOffsetMin)) && (aveRatio < (valAve + gloveHGMAveRaitoOffsetMax)))
            {  // assume it is glove in HGM.
               k = 1.0;
            }
          }
       }
#endif
       else
       {
          // do nothing.
       }
    }
      k = filterAlgmCoeff(alpha, k);
      prevK = k;
    // debug, collect data
    realFingerThreshold = (uint16)(normalFingerThreshold * k);
    lgmMaxDeltaValTest = (uint16)(maxDelta + ((maxDelta > 0) ? 0.5 : (-0.5)));       // debug, collect data
    lgmRelatedAreaTest = (uint16)(relatedArea + ((relatedArea > 0) ? 0.5 : (-0.5))); // debug, collect data
    lgmRealFingerThresholdTest = realFingerThreshold;              // debug, collect data
    lgmFingerPredictMaxValTest = predictLGMFingerMaxDeltaVal;  // debug, collect data

    #if DIV_HGMGLOVE_LGMFINGER
    lgmGloveDebugData[0] = lgmRelatedAreaTest;
    lgmGloveDebugData[1] = lgmMaxDeltaValTest;
    lgmGloveDebugData[2] = lgmRealFingerThresholdTest;
    lgmGloveDebugData[3] = lgmFingerPredictMaxValTest;
    lgmGloveDebugData[4] = valAve;
    lgmGloveDebugData[5] = numElectrodesValid;
    lgmGloveDebugData[6] = aveRatio;
    #endif
    }
    else
    {
      prevK = filterAlgmCoeff(alpha, 1);
//      k = prevK;
//      if (k < worstCaseCoeff || k > 1.0)
//      {
//         k = worstCaseCoeff;
//         prevK = k;
//      }
    }

    //- Update latest compensation factor to mSensorParams
    //- Update cStat_LSB.
    if (prevK <= 1.0)
    {
      mSensorParams->aLGMCompensationFactor = prevK;
      mSensorParams->cSat_LSB *= prevK;
    }
  }
}
#else
// This algorithm is from branch td4300_dev
/* -----------------------------------------------------------------
Name:  adaptive_LGM_compensate
Purpose: calculate ALGM coefficient K
Inputs: pointer to Delta Image, sensor parameters struct
Outputs: K
Effects: None
Notes: None
Example: None.
Notes: this module is not optimized.
One way it can be optimized by limiting float multiplications and divisions
When N=x*n, equation for K simplifies too
-----------------------------------------------------------------*/
void adaptive_LGM_compensate(int16 *pDeltaImage, sensorParams_t *mSensorParams)
{
  float worstCaseCoeff, compVal2Pct;
  float cSat;
  float compVal, compVal1, compVal2;
  float numElectrodesScaled, maxDelta, numElectrodes;
  float k=prevK;
  float alpha;

  if (!params.enabled)
  {
     k = 1;
     prevK = k;
  }
  else
  {
    worstCaseCoeff = (float)params.scfg.minCompFactor/100;
    compVal2Pct = (float)params.scfg.accumThresh/100;
    alpha = (float)params.scfg.filterCoeff/100;

    cSat = (float)mSensorParams->cSat_LSB;
    compVal1 = worstCaseCoeff*cSat;
    maxDelta = (float)getMaxTixelDeltaImage_ALGM(pDeltaImage, mSensorParams);  //find maximum value over the delta image
    compVal2 =  compVal2Pct*maxDelta;
    compVal = (compVal1 > compVal2) ? compVal1 : compVal2;

    numElectrodes = estimateElectrodesAccumDelta(pDeltaImage, compVal, mSensorParams);

    numElectrodesScaled = numElectrodes*params.scfg.tixelsPerFinger;
    //numElectrodesScaled = (numElectrodesScaled > min_num_electrodes) ? numElectrodesScaled : min_num_electrodes;

//    if (numElectrodes > 0)
    if (numElectrodes > 7) //hack to prevent ALGM adjusting thresholds for 'small objects only' case
    {                      //tuned for minCompFactor = 15, and accumThresh = 60
      k = (numElectrodesScaled*numElectrodes*cSat - numElectrodesScaled*accumChange)/(accumChange*numElectrodes);
      if (k < 0.0)
       k = k*-1.0;
      k = 1.0/(1.0 + k);
      k = filterAlgmCoeff(alpha, k);

      if (k < worstCaseCoeff)
        k = worstCaseCoeff;

      prevK = k;
    }
    else
    {
      prevK = filterAlgmCoeff(alpha, 1);
//      k = prevK;
//      if (k < worstCaseCoeff || k > 1.0)
//      {
//         k = worstCaseCoeff;
//         prevK = k;
//      }
    }

    //- Update latest compensation factor to mSensorParams
    //- Update cStat_LSB.
    if (prevK <= 1.0)
    {
      mSensorParams->aLGMCompensationFactor = prevK;
      mSensorParams->cSat_LSB *= prevK;
    }
  }
}
#endif
/* -----------------------------------------------------------------
Name:  findMaxOverDeltaImage_ALGM
Purpose: Find the maximum value of pixel in the delta image
Inputs: pointer to Delta Image, sensor parameters struct
Outputs: max tixel in delta image
Effects: None
Notes: None
Example: None.
-----------------------------------------------------------------*/

uint16 getMaxTixelDeltaImage_ALGM(int16 *pDeltaImage, sensorParams_t *mSensorParams)
{
  uint16 i, j;
  int16 *p16Delta = pDeltaImage + (MAX_RX + 1) + 1; //account for border
  int16 i16DeltaTmp;
  uint16 imgRowNum = mSensorParams->txCount;
  uint16 imgColNum = mSensorParams->rxCount;
  uint16 rowSkip = MAX_RX - imgColNum;
  int16 max;

  max = 0;
  for (i = 0; i < imgRowNum; i++, p16Delta += rowSkip + 1)
  {
    for (j = 0; j < imgColNum; j++)
    {
      i16DeltaTmp = *p16Delta++;
      if(i16DeltaTmp > 0)
      {
        max = (i16DeltaTmp > max) ? i16DeltaTmp : max;
      }
    }
  }

  return max;
}

/* -----------------------------------------------------------------
Name:  estimateElectrodesAccumDelta
Purpose: Find the electrodes that are above a threshold
Inputs: pointer to Delta Image, threshold, sensor parameters struct
Outputs: numElectrodes, accumchange
Effects: None
Notes: None
Example: None.
-----------------------------------------------------------------*/
uint16 estimateElectrodesAccumDelta(int16 *pDeltaImage, int16 threshold, sensorParams_t *mSensorParams)
{
    uint16 i, j;
    int16 *p16Delta = pDeltaImage + (MAX_RX + 1) + 1; //account for border
    int16 i16DeltaTmp;
    uint16 imgRowNum = mSensorParams->txCount;
    uint16 imgColNum = mSensorParams->rxCount;
    uint16 rowSkip = MAX_RX - imgColNum;
    uint16 numElectrodes;

    accumChange = 0;
    numElectrodes = 0;

    for (i = 0; i < imgRowNum; i++, p16Delta += rowSkip + 1)
    {
      for (j = 0; j < imgColNum; j++)
      {
        i16DeltaTmp = *p16Delta++;
        if(i16DeltaTmp >  threshold)
        {
          numElectrodes++;
          accumChange += i16DeltaTmp;
        }
      }
    }

   return numElectrodes;
}

float filterAlgmCoeff(float alpha, float tempk)
{

 tempk = alpha*tempk + (1-alpha)*prevK;

 return tempk;
}

void adaptive_lgm_initCSat (uint16 cSat_LSB)
{
  initCSat = cSat_LSB;
}

void adaptive_lgm_recoverCSat (uint16 *cSat_LSB)
{
  *cSat_LSB = initCSat;
}

#endif   // CONFIG_HAS_ADAPTIVE_LGM
