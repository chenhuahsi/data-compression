/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

----------------------------------------------------------------- */

#ifndef _WEAK_OBJECT_FILTER_H
#define _WEAK_OBJECT_FILTER_H

#if CONFIG_HAS_WEAK_OBJECT_FILTER
void weakObjectFilter_configure(weakObjectFilterConfig_t *wofConfig);
void weakObjectFilter_filter(classification_t *classifications,
                             trackedObject_t *trackedObjects,
                             clumps_t *clumps,
                             int16 *deltaImage);
#else
static ATTR_INLINE void weakObjectFilter_configure(ATTR_UNUSED weakObjectFilterConfig_t *wofConfig){};
static ATTR_INLINE void weakObjectFilter_filter(ATTR_UNUSED classification_t *classifications,
                             ATTR_UNUSED trackedObject_t *trackedObjects,
                             ATTR_UNUSED clumps_t *clumps,
                             ATTR_UNUSED int16 *deltaImage){};
#endif
#endif  // _WEAK_OBJECT_FILTER_H
