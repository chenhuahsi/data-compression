/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Description: Internal data structures for the tracker
   $Id: $
----------------------------------------------------------------- */

#ifndef _TRACKER_INTERNAL_H
#define _TRACKER_INTERNAL_H

#include "ifp_common.h"

/* =================================================================
   MODULE TYPES
==================================================================*/

#define TRACKER_NUM_MERGE_PAIRS 3

typedef struct
{
  uint8p8 x;
  uint8p8 y;
  uint8p8 z;
  uint8p8 xMin;
  uint8p8 xMax;
  uint8p8 yMin;
  uint8p8 yMax;
  uint16 blobId : 8;
  uint16 clumpId : 8;
  uint16 pixelCount : 8;
  uint16 polarity : 1;
} blobStats_t;

typedef struct
{
  uint8p8 x;
  uint8p8 y;
  uint16 z;
} centerOfMass_t;

typedef struct
{
  uint8p8 minAccelSquared;
  uint8p8 minDistSquared;
  uint16 palmSize;
} drummingParams_t;

typedef struct
{
  // matrix of squared distances, where rows correspond to tracks
  // and columns corresond to blobs
  uint8p8 matrix[MAX_OBJECTS*MAX_OBJECTS];
  uint8p8 mergeMatrix[MAX_OBJECTS*TRACKER_NUM_MERGE_PAIRS];
  int16 mergeTrackIdx1[MAX_OBJECTS*TRACKER_NUM_MERGE_PAIRS];
  int16 mergeTrackIdx2[MAX_OBJECTS*TRACKER_NUM_MERGE_PAIRS];
  objectBitmask_t usedBlobsBits;
  objectBitmask_t usedTracksBits;
} dists_t;

#endif
