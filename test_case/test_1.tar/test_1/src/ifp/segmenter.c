/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Dr.
   San Jose, CA 95131
   (408) 904-1100

   Description: Segments an image into distinct touch points
   $Id: segmenter.c,v 1.10.2.7.2.20 2013/01/31 22:48:25 jjordan Exp $
----------------------------------------------------------------- */

/* Segmentation Algorithm Overview ---------------------------------

   The segmenter is essentially a flood fill, where each peak is
   assigned a different color. The flood fill starts at the peaks and
   then proceeds in order of pixel amplitude. This means that higher
   amplitudes are filled first, then lower amplitudes, all the way
   down to the noise floor.

   When two or more different colors meet, the segmenter decides
   whether to merge them into a single color or to keep them separate
   by putting a barrier of uncolored pixels between them.

   The segmenter first looks for "positive" peaks, and then if it has
   any room left in the clumps data structure, it inverts the image and
   looks for "negative" peaks. If there are more than MAX_OBJECTS
   positive peaks, then only those with the highest amplitude are
   returned. This is achieved by sorting the local maxima before flood
   filling.

   Because some fingers may produce more than 1 peak that will be
   merged, the segmenter needs MAX_OBJECTS to be set to a value
   somewhat higher than the maximum number of fingers that will be
   reported.

------------------------------------------------------------------*/

#include "ifp_common.h"
#include "ifp_string.h"
#include "ifp_bit_manipulation.h"
#include "segmenter.h"
#if (defined(CONFIG_IFP_CLOSEDCOVER_MINPEAK) && CONFIG_IFP_CLOSEDCOVER_MINPEAK)
#include "position_reporter.h"
#endif
/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

// CONTOUR_LEVELS defines the number of capacitance levels at which the
// image is discretized. The minimum level is the noise floor, and the
// maximum level is the saturation capacitance. CONTOUR_LEVELS specifies
// the number of levels between these two extremes.
#define CONTOUR_LEVELS 64

#define NO_FIRST_PIXEL 0

/* =================================================================
   MODULE TYPES
==================================================================*/
typedef struct
{
  uint16 heads[CONTOUR_LEVELS];
  uint16 tails[CONTOUR_LEVELS];
  uint16 alreadyQueued[(((MAX_RX+1)*(MAX_TX+2)+1)+15)/16];
  int16 noiseFloor_LSB;
  int4p12 scaleFactor;
  objectBitmask_t preventMerge[MAX_OBJECTS];
} priorityQueue_t;

// This type must match the clumps_t type in ifp_common.h, except
// that it uses uint16 linear offsets in the info struct and
// listImage.
  typedef struct {
    struct offsetClumpInfo_t {
      uint16 firstPixelOffset;
      uint16 peakOffset;
#if MAX_OBJECTS <= 16
      uint16 peakCount : 4;
      uint16 splitCount : 4;
      uint16 firstSplit : 4;
#else
      uint16 peakCount : 5;
      uint16 splitCount : 5;
      uint16 : 6;
      uint16 firstSplit : 5;
#endif
      uint16 splitAxis : 2;
      uint16 polarity : 1;
      uint16 preventSplit : 1;
      uint16 suspectMoisture : 1;
    } info[MAX_OBJECTS];
    uint16 labelImage[(MAX_TX+2)*(MAX_RX+1)+1];
    uint16 listImage[(MAX_TX+2)*(MAX_RX+1)+1];
    uint16 splits[MAX_OBJECTS-1];
  } offsetClumps_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static uint8p8 mergeThreshold_pct;
static int16 minPeak_LSB;
#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
static int16 penCeiling_LSB;
static int16 smallFingerThreshold_LSB;
#endif
#if (defined(CONFIG_IFP_CLOSEDCOVER_MINPEAK) && CONFIG_IFP_CLOSEDCOVER_MINPEAK)
static int16 minPeak_LSB_bak;
#endif

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/
static void initStructures(offsetClumps_t *clumps, priorityQueue_t *pq);
static uint16 isLocalMin(int16 *deltaPtr);
static uint16 findNextFreeLabel(offsetClumps_t *clumps, int16 lastLabel);
static void findHighestLocalMaxima(int16 *deltaImage, int16 noiseFloor_LSB, int16 minPeak_LSB, uint16 rxCount, uint16 txCount, offsetClumps_t *clumps, uint16 *peakCount);
#ifdef FIND_NEGATIVE_CLUMP
static void findLowestLocalMinima(int16 *deltaImage, int16 minPeak_LSB, uint16 txCount, offsetClumps_t *clumps, uint16 *peakCount);
#endif
static void enqueuePixel(offsetClumps_t *clumps, priorityQueue_t *priorityQueue, int16 v, uint16 offset);
static void enqueuePeakNeighbors(int16 *deltaImage, offsetClumps_t *clumps, priorityQueue_t *priorityQueue);
static int16 isQueueEmpty(priorityQueue_t *priorityQueue, int16 contour);
static uint16 dequeuePixel(priorityQueue_t *priorityQueue, int16 contour, uint16 *listImage);
static objectBitmask_t getNeighborLabels(uint16 *labelImage, uint16 offset);
static void reassignInLabelImage(offsetClumps_t *clumps, uint16 oldLabel, uint16 newLabel);
static int16 walkThroughQueue(int16 *deltaImage, offsetClumps_t *clumps, priorityQueue_t *priorityQueue, uint8p8 mergeThreshold_pct);
static void offsetToPixelIndex(uint16 offset, uint16 *rowLengthTimes256, pixelIndex_t *result);
static void convertOffsetClumpsToRowColumn(clumps_t *clumps);

uint16 isLocalMax(int16 *deltaPtr);
void addPeak(sortedPeakList_t *sortedPeaks, uint16 offset, uint16 amplitude);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: initStructures
Purpose: Clear clumps and priorityQueue datastructures
Inputs: empty clumps & priorityQueue
Outputs: same
Effects: None.
Notes: This assumes that both structures should be cleared
       to all zeros. It also assumes that there are no other
       variables hiding in padding. So far as I can tell, GCC
       and Visual Studio only use empty space for padding, so
       this will not cause problems on these platforms.
----------------------------------------------------------- */
void initStructures(offsetClumps_t *clumps, priorityQueue_t *priorityQueue)
{
  memset16(priorityQueue, 0, sizeof(*priorityQueue) / sizeof(uint16));
  memset16(clumps, 0, sizeof(*clumps) / sizeof(uint16));
}

/* -----------------------------------------------------------
Name: isLocalMax
Purpose: Determines whether the pixel is a local maximum
Inputs: pointer to a pixel in the delta image
Outputs: true/false
Effects: None.
Notes: Relative to the center pixel, the comparisons are:
              <= <= <=
              <=    <
              <  <  <
       The mix of strict and non-strict comparisons is to
       deal with flat surfaces. It will prevent every pixel
       from being labeled a local maximum, but allow at least
       one bottom-right corner pixel to be labeled a maximum.

       This routine does no bounds checking, so you cannot
       pass in pixels that are part of the padding around the
       deltaImage.
Example: None.
----------------------------------------------------------- */
uint16 isLocalMax(int16 *deltaPtr)
{
  int16 v;
  v = *deltaPtr;

  deltaPtr -= MAX_RX+2;

  return (deltaPtr[0]          <= v) && \
         (deltaPtr[1]          <= v) && \
         (deltaPtr[2]          <= v) && \
         (deltaPtr[MAX_RX+1]   <= v) && \
         (deltaPtr[MAX_RX+3]   <  v) && \
         (deltaPtr[2*MAX_RX+2] <  v) && \
         (deltaPtr[2*MAX_RX+3] <  v) && \
         (deltaPtr[2*MAX_RX+4] <  v);
}

/* -----------------------------------------------------------
Name: isLocalMin
Purpose: Determines whether the pixel is a local minimum
Inputs: pointer to a pixel in the delta image
Outputs: true/false
Effects: None.
Notes: see isLocalMax
Example: None.
----------------------------------------------------------- */
uint16 isLocalMin(int16 *deltaPtr)
{
  int16 v;
  v = *deltaPtr;

  deltaPtr -= MAX_RX+2;

  return (deltaPtr[0]          >= v) && \
         (deltaPtr[1]          >= v) && \
         (deltaPtr[2]          >= v) && \
         (deltaPtr[MAX_RX+1]   >= v) && \
         (deltaPtr[MAX_RX+3]   >  v) && \
         (deltaPtr[2*MAX_RX+2] >  v) && \
         (deltaPtr[2*MAX_RX+3] >  v) && \
         (deltaPtr[2*MAX_RX+4] >  v);
}

/* -----------------------------------------------------------
Name: findNextFreeLabel
Purpose: Returns the next available unused label
Inputs: clumps structure, the last label used.
Outputs: number of next free label
Effects: None.
Notes: lastLabel is here to avoid redundant scanning. However,
       you can always pass zero if you don't care about
       efficiency and the function will still work.
----------------------------------------------------------- */
uint16 findNextFreeLabel(offsetClumps_t *clumps, int16 lastLabel)
{
  int16 nextLabel = 0;
  uint16 i;

  for (i = lastLabel+1; i <= MAX_OBJECTS; i++)
  {
    if (clumps->info[i-1].firstPixelOffset == NO_FIRST_PIXEL)
    {
      nextLabel = i;
      break;
    }
  }
  return nextLabel;
}

/* -----------------------------------------------------------
Name: addPeak
Purpose: Adds a peak to the sorted list of peaks
Inputs: sorted peaks structure; peak offset; peak amplitude
Outputs: sorted peaks structure
Effects: None.
Notes: Peak list is ordered largest to smallest. If the peak
       passed in does not fit on the list, it will be dropped.
       If the list is already full but this is a larger peak
       than the minimum on the list, then the minimum on the
       list will be dropped to make room for the new peak.
----------------------------------------------------------- */
void addPeak(sortedPeakList_t *sortedPeaks, uint16 offset, uint16 amplitude)
{

  uint16 i;
  uint16 newPeakIdx;

  if (amplitude < sortedPeaks->minAmplitude)
  {
    return;
  }

  // This loop terminates either at the end of the list or at the
  // desired insertion point in the middle of the list
  for (i = 0; i < sortedPeaks->peakCount; i++)
  {
    if (sortedPeaks->peakList[i].amplitude < amplitude)
    {
      break;
    }
  }
  newPeakIdx = i;

  if (newPeakIdx < MAX_PEAKS)
  {
    // make a hole for the new element
    if (sortedPeaks->peakCount >= MAX_PEAKS)
    {
      sortedPeaks->peakCount = MAX_PEAKS-1;
    }
    for (i = sortedPeaks->peakCount; i > newPeakIdx; i--)
    {
      sortedPeaks->peakList[i] = sortedPeaks->peakList[i-1];
      sortedPeaks->peakList[i].amplitude = sortedPeaks->peakList[i-1].amplitude;
    }
    // add the new element
    sortedPeaks->peakList[newPeakIdx].offset = offset;
    sortedPeaks->peakList[newPeakIdx].amplitude = amplitude;
    sortedPeaks->peakCount++;
    if (sortedPeaks->peakCount >= MAX_PEAKS)
    {
      sortedPeaks->minAmplitude = sortedPeaks->peakList[MAX_PEAKS-1].amplitude;
    }
  }
}

/* -----------------------------------------------------------
Name: findHighestLocalMaxima
Purpose: Finds the MAX_PEAKS highest peaks in the image
Inputs: delta image, noise floor, minimum peak amplitude,
        enabled receiver count, enabled transmitter count,
        clumps structure.
Outputs: peakCount: number of maxima found,
         updated clumps structure
Effects: None.
Notes: 1) If the clumps structure is already populated, this will
       only fill the unused indices.
       2) This function expects pixels outside the enabled TX
       and RX channels to be zero.
       3) This implementation is highly optimized to use only
       5 cycles per below-threshold pixel on T1324. Changes
       made to this function can dramatically increase the
       MIPS load of the processor.
----------------------------------------------------------- */
void findHighestLocalMaxima(int16 *deltaImage, int16 noiseFloor_LSB, int16 minPeak_LSB, ATTR_UNUSED uint16 rxCount, uint16 txCount, offsetClumps_t *clumps, uint16 *peakCount)
{
  int16 lastLabel = 0;
  int16 *startDelta;
  int16 *endDelta;

  int16 *deltaPtr;

  uint16 i;
  int16 v;
  sortedPeakList_t sortedPeaks;
  sortedPeakList_t resortedPeaks;

  int16 minPeakSplit2x1_LSB = (int16)(((uint32) minPeak_LSB * 46341 + 16384) >> 15);
  int16 minPeakSplit2x2_LSB = 2*minPeak_LSB;

  #if CONFIG_HAS_SMALL_OBJECT_DETECTOR
  int16 smallFingerHalfThreshold_LSB = (smallFingerThreshold_LSB + 1) >> 1;
  uint32 SDPThreshold = (uint32)3*smallFingerThreshold_LSB*smallFingerThreshold_LSB;
  uint32 SDPQuarterThreshold = (SDPThreshold + 2) >> 2;
  #endif

  startDelta = &deltaImage[MAX_RX+2];
  endDelta = &deltaImage[(MAX_RX+1)*(txCount+1)+1];

  sortedPeaks.minAmplitude = 0;
  sortedPeaks.peakCount = 0;
  resortedPeaks.minAmplitude = 0;
  resortedPeaks.peakCount = 0;

  *peakCount = 0;

  for (deltaPtr = startDelta; deltaPtr < endDelta;)
  {
    if (*deltaPtr++ > noiseFloor_LSB)
    {
      if (isLocalMax(deltaPtr-1))
      {
        uint16 offset;
        v = *(--deltaPtr); // can't use deltaPtr-1 or common subexpression elimination balloons
                           // isLocalMax to twice its optimal size
        offset = (uint16)(deltaPtr - deltaImage);
        addPeak(&sortedPeaks, offset, (uint16)v);
        deltaPtr = &deltaImage[offset+1]; // must restore Y's value since it was clobbered in subroutines
      }
    }
  }

  for (i = 0; i < sortedPeaks.peakCount; i++)
  {
    uint16 newOffset = sortedPeaks.peakList[i].offset;
    uint16 keepFlag = 0;
    int16 priority = deltaImage[newOffset];

    keepFlag = (deltaImage[newOffset] > minPeak_LSB);

    {
      int16 s_NW, s_EN, s_WS, s_SE; // variables to store sums
      int16 v_NW, v_N, v_NE, v_W, v_E, v_SW, v_S, v_SE; // 8 pixels values from around center

      if (!keepFlag)
      {
        // check 2x1 pixel sums including peak
        int16 maxSplitPeak = 0;
        v_N  = deltaImage[newOffset - MAX_RX - 1];
        v_S  = deltaImage[newOffset + MAX_RX + 1];
        v_W  = deltaImage[newOffset - 1];
        v_E  = deltaImage[newOffset + 1];

        s_NW = s_EN = s_WS = s_SE = deltaImage[newOffset];

        // add the first noncentral pixel to the peak
        s_NW += v_N;
        s_SE += v_S;
        s_WS += v_W;
        s_EN += v_E;

        maxSplitPeak = s_NW;
        maxSplitPeak = (s_SE > maxSplitPeak) ? s_SE : maxSplitPeak;
        maxSplitPeak = (s_WS > maxSplitPeak) ? s_WS : maxSplitPeak;
        maxSplitPeak = (s_EN > maxSplitPeak) ? s_EN : maxSplitPeak;

        keepFlag = (maxSplitPeak > minPeakSplit2x1_LSB);
        priority = (keepFlag) ? maxSplitPeak : priority;
      }

      if (!keepFlag)
      {
        //check 2x2 pixel sums including peak
        int16 maxSplitPeak = 0;
        v_NW = deltaImage[newOffset - MAX_RX - 1 - 1];
        v_NE = deltaImage[newOffset - MAX_RX - 1 + 1];
        v_SW = deltaImage[newOffset + MAX_RX + 1 - 1];
        v_SE = deltaImage[newOffset + MAX_RX + 1 + 1];

        // add the other two pixels noncentral pixels to the existing sums
        s_NW += v_NW + v_W;
        s_EN += v_N + v_NE;
        s_WS += v_SW + v_S;
        s_SE += v_E + v_SE;

        maxSplitPeak = s_NW;
        maxSplitPeak = (s_SE > maxSplitPeak) ? s_SE : maxSplitPeak;
        maxSplitPeak = (s_WS > maxSplitPeak) ? s_WS : maxSplitPeak;
        maxSplitPeak = (s_EN > maxSplitPeak) ? s_EN : maxSplitPeak;

        keepFlag = (maxSplitPeak > minPeakSplit2x2_LSB);
        priority = (keepFlag) ? maxSplitPeak : priority;
      }
    }

    #if CONFIG_HAS_SMALL_OBJECT_DETECTOR
    if (smallFingerThreshold_LSB && !(deltaImage[newOffset] > penCeiling_LSB))
    {
      uint16 row = newOffset / (MAX_RX+1);
      uint16 col = newOffset % (MAX_RX+1);
      uint32 ds2 = 0;
      int16 ddc = 0;
      int16 ddr = 0;
      deltaPtr = deltaImage + newOffset;

      if (col == 1)
      {
        ddc = *deltaPtr + *(deltaPtr + 1) - 2*(*(deltaPtr + 2));
      }
      else if (col == rxCount)
      {
        ddc = *deltaPtr + *(deltaPtr - 1) - 2*(*(deltaPtr - 2));
      }
      else
      {
        ddc = 2*(*deltaPtr) - *(deltaPtr - 1) - *(deltaPtr + 1);
      }


      if (row == 1)
      {
        ddr = *deltaPtr + *(deltaPtr + (MAX_RX+1)) - 2*(*(deltaPtr + 2*(MAX_RX+1)));
      }
      else if (row == txCount)
      {
        ddr = *deltaPtr + *(deltaPtr - (MAX_RX+1)) - 2*(*(deltaPtr - 2*(MAX_RX+1)));
      }
      else
      {
        ddr = 2*(*deltaPtr) - *(deltaPtr - (MAX_RX+1)) - *(deltaPtr + (MAX_RX+1));
      }


      if (ddc >= smallFingerHalfThreshold_LSB && ddr > 0)
      {
        ds2 = (uint32)ddc * ddr;
        if (ds2 > SDPQuarterThreshold)
        {
          int16 ddc2 = 0;
          int16 ddr2 = 0;

          if (col == rxCount)
          {
            ddc2 = 2*(*deltaPtr - *(deltaPtr - 1));
          }
          else if (col > 2)
          {
            ddc2 = *deltaPtr + *(deltaPtr - 1) - *(deltaPtr + 1) - *(deltaPtr - 2);
          }
          else if (col == 2)
          {
            ddc2 = *deltaPtr + *(deltaPtr - 1) - 2*(*(deltaPtr + 1));
          }
          ddc = (ddc2 > ddc) ? ddc2 : ddc;


          if (col == 1)
          {
            ddc2 = 2*(*deltaPtr - *(deltaPtr + 1));
          }
          else if (col < rxCount - 1)
          {
            ddc2 = *deltaPtr + *(deltaPtr + 1) - *(deltaPtr - 1) - *(deltaPtr + 2);
          }
          else if (col == rxCount - 1)
          {
            ddc2 = *deltaPtr + *(deltaPtr + 1) - 2*(*(deltaPtr - 1));
          }
          ddc = (ddc2 > ddc) ? ddc2 : ddc;


          if (row == txCount)
          {
            ddr2 = 2*(*deltaPtr - *(deltaPtr - (MAX_RX+1)));
          }
          else if (row > 2)
          {
            ddr2 = *deltaPtr + *(deltaPtr - (MAX_RX+1)) - *(deltaPtr + (MAX_RX+1)) - *(deltaPtr - 2*(MAX_RX+1));
          }
          else if (row == 2)
          {
            ddr2 = *deltaPtr + *(deltaPtr - (MAX_RX+1)) - 2*(*(deltaPtr + (MAX_RX+1)));
          }
          ddr = (ddr2 > ddr) ? ddr2 : ddr;


          if (row == 1)
          {
            ddr2 = 2*(*deltaPtr - *(deltaPtr + (MAX_RX+1)));
          }
          else if (row < txCount - 1)
          {
            ddr2 = *deltaPtr + *(deltaPtr + (MAX_RX+1)) - *(deltaPtr - (MAX_RX+1)) - *(deltaPtr + 2*(MAX_RX+1));
          }
          else if (row == txCount - 1)
          {
            ddr2 = *deltaPtr + *(deltaPtr + (MAX_RX+1)) - 2*(*(deltaPtr - (MAX_RX+1)));
          }
          ddr = (ddr2 > ddr) ? ddr2 : ddr;

          ds2 = (uint32)ddc * ddr;
          if (ds2 > SDPThreshold)
          {
            priority = ds2;
            keepFlag = 1;
          }
        }
      }
    }
    #endif

    if (keepFlag)
    {
      addPeak(&resortedPeaks, newOffset, (uint16)priority);
    }
  }

  for (i = 0; i < resortedPeaks.peakCount && *peakCount < MAX_OBJECTS; i++)
  {
    uint16 newLabel;
    newLabel = findNextFreeLabel(clumps, lastLabel);
    if (newLabel > 0)
    {
      uint16 newOffset = resortedPeaks.peakList[i].offset;
      *peakCount = *peakCount + 1;
      clumps->info[newLabel-1].firstPixelOffset = newOffset;
      clumps->info[newLabel-1].peakOffset = newOffset;
      clumps->info[newLabel-1].peakCount = 1;
      clumps->info[newLabel-1].polarity = clumpPolarity_positive;
      clumps->labelImage[newOffset] = newLabel;
      lastLabel = newLabel;
    }
  }
}

/* -----------------------------------------------------------
Name: findLowestLocalMinima
Purpose: Finds up to MAX_OBJECTS highest peaks in the image
Inputs: delta image, minimum peak amplitude,
        enabled transmitter count,
        clumps structure.
Outputs: peakCount: number of minima found,
         updated clumps structure
Effects: None.
Notes: 1) If the clumps structure is already populated, this will
       only fill the unused indices.
       2) This function expects pixels outside the enabled TX
       and RX channels to be zero.
       3) This implementation is highly optimized to use only
       5 cycles per below-threshold pixel on T1324. Changes
       made to this function can dramatically increase the
       MIPS load of the processor.
----------------------------------------------------------- */
void findLowestLocalMinima(int16 *deltaImage, int16 minPeak_LSB, uint16 txCount, offsetClumps_t *clumps, uint16 *peakCount)
{
  int16 lastLabel = 0;
  int16 *startDelta;
  int16 *endDelta;

  int16 *deltaPtr;

  uint16 i;
  int16 v;
  sortedPeakList_t sortedPeaks;

  startDelta = &deltaImage[MAX_RX+2];
  endDelta = &deltaImage[(MAX_RX+1)*(txCount+1)+1];

  sortedPeaks.minAmplitude = 0;
  sortedPeaks.peakCount = 0;

  *peakCount = 0;

  for (deltaPtr = startDelta; deltaPtr < endDelta;)
  {
    if (*deltaPtr++ < minPeak_LSB)
    {
      if (isLocalMin(deltaPtr-1))
      {
        uint16 offset;
        v = *(--deltaPtr);
        offset = (uint16)(deltaPtr - deltaImage);
        addPeak(&sortedPeaks, offset, (uint16)(-v));
        deltaPtr = &deltaImage[offset+1]; // must restore Y's value since it was clobbered in subroutines
      }
    }
  }

  for (i = 0; i < sortedPeaks.peakCount; i++)
  {
    uint16 newLabel;
    newLabel = findNextFreeLabel(clumps, lastLabel);
    if (newLabel > 0)
    {
      uint16 newOffset;
      *peakCount = *peakCount + 1;
      newOffset = sortedPeaks.peakList[i].offset;
      clumps->info[newLabel-1].firstPixelOffset = newOffset;
      clumps->info[newLabel-1].peakOffset = newOffset;
      clumps->info[newLabel-1].peakCount = 1;
      clumps->info[newLabel-1].polarity = clumpPolarity_negative;
      clumps->labelImage[newOffset] = newLabel;
      lastLabel = newLabel;
    }
  }
}

/* -----------------------------------------------------------
Name: enqueuePixel
Purpose: Adds a pixel to the flood fill priority queue
Inputs: clumps structure; priority queue;
        pixel value, pixel offset
Outputs: updated priority queue and clumps structure
Effects: None.
Notes: If the pixel amplitude is too low, the pixel will
       be dropped.
----------------------------------------------------------- */
void enqueuePixel(offsetClumps_t *clumps, priorityQueue_t *priorityQueue, int16 v, uint16 offset)
{
  v = v - priorityQueue->noiseFloor_LSB;
  v = (int16) (((int32)v*priorityQueue->scaleFactor + 4095)/4096);
  if (v > CONTOUR_LEVELS)
  {
    v = CONTOUR_LEVELS;
  }
  if (v > 0)
  {
    v -= 1;

    clumps->listImage[offset] = 0;

    if (priorityQueue->heads[v] == NO_FIRST_PIXEL)
    {
      priorityQueue->heads[v] = offset;
      priorityQueue->tails[v] = offset;
    }
    else
    {
      uint16 oldTail;

      oldTail = priorityQueue->tails[v];
      clumps->listImage[oldTail] = offset;
      priorityQueue->tails[v] = offset;
    }
  }
}

/* -----------------------------------------------------------
Name: enqueuePeakNeighbors
Purpose: Adds all neighbors of peaks to the flood fill queue
Inputs: delta image; clumps structure; priority queue
Outputs: updated priority queue and clumps structure
Effects: None.
Notes: Peaks are marked as already queued so they will
       not be considered again
----------------------------------------------------------- */
void enqueuePeakNeighbors(int16 *deltaImage, offsetClumps_t *clumps, priorityQueue_t *priorityQueue)
{
  uint16 i;
  uint16 j;
  uint16 peakOffset;
  int16 inc[] = {-(MAX_RX+1)-1, 1, 1, MAX_RX-1, 2, MAX_RX-1, 1, 1};

  for (i = 0; i < MAX_OBJECTS; i++)
  {
    peakOffset = clumps->info[i].peakOffset;
    if (peakOffset != NO_FIRST_PIXEL)
    {
      uint16 neighborOffset;
      uint16 mask;

      mask = powerOfTwo(peakOffset & 0xF);
      if ((priorityQueue->alreadyQueued[peakOffset/16] & mask) == 0)
      {
        priorityQueue->alreadyQueued[peakOffset/16] |= mask;
        neighborOffset = peakOffset;

        // Scan over a 3x3 block centered at the peak
        for (j = 0; j < 8; j++)
        {
          uint16 label;
          neighborOffset += inc[j];
          label = clumps->labelImage[neighborOffset];
          if (label == 0)
          {
            mask = powerOfTwo(neighborOffset & 0xF);
            if ((priorityQueue->alreadyQueued[neighborOffset/16] & mask) == 0)
            {
              int16 v;
              v = deltaImage[neighborOffset];
              priorityQueue->alreadyQueued[neighborOffset/16] |= mask;
              enqueuePixel(clumps, priorityQueue, v, neighborOffset);
            }
          }
        }
      }
    }
  }
}

/* -----------------------------------------------------------
Name: isQueueEmpty
Purpose: Determines whether the queue has more values at a
         particular contour.
Inputs: priority queue, contour to check
Outputs: true/false
Effects: None.
Notes: None.
----------------------------------------------------------- */
int16 isQueueEmpty(priorityQueue_t *priorityQueue, int16 contour)
{
  return priorityQueue->heads[contour] == NO_FIRST_PIXEL;
}

/* -----------------------------------------------------------
Name: dequeuePixel
Purpose: returns the next pixel from the queue
Inputs: priority queue, contour to check, list image
Outputs: offset of the next pixel
Effects: None.
Notes: if there is no next pixel, this returns a pixel
       with row set to NO_FIRST_PIXEL.
----------------------------------------------------------- */
uint16 dequeuePixel(priorityQueue_t *priorityQueue, int16 contour, uint16 *listImage)
{
  uint16 elementOffset;

  elementOffset = priorityQueue->heads[contour];
  if (elementOffset != NO_FIRST_PIXEL)
  {
    uint16 nextElement;
    nextElement = listImage[elementOffset];
    priorityQueue->heads[contour] = nextElement;
    if (nextElement == 0)
    {
      priorityQueue->tails[contour] = nextElement;
    }
  }
  return elementOffset;
}

/* -----------------------------------------------------------
Name: getNeighborLabels
Purpose: Returns the labels of all neighboring pixels
Inputs: label image, row and column of pixel to check
Outputs: Bitmask of labels
Effects: None.
Notes: None.
----------------------------------------------------------- */
objectBitmask_t getNeighborLabels(uint16 *labelImage, uint16 offset)
{
  objectBitmask_t labelMask;
  uint16 currentLabel;

  offset -= MAX_RX+2;
  currentLabel = labelImage[offset];
  labelMask = powerOfTwo(currentLabel);
  currentLabel = labelImage[offset+1];
  labelMask |= powerOfTwo(currentLabel);
  currentLabel = labelImage[offset+2];
  labelMask |= powerOfTwo(currentLabel);
  currentLabel = labelImage[offset+MAX_RX+1];
  labelMask |= powerOfTwo(currentLabel);
  currentLabel = labelImage[offset+MAX_RX+3];
  labelMask |= powerOfTwo(currentLabel);
  currentLabel = labelImage[offset+2*MAX_RX+2];
  labelMask |= powerOfTwo(currentLabel);
  currentLabel = labelImage[offset+2*MAX_RX+3];
  labelMask |= powerOfTwo(currentLabel);
  currentLabel = labelImage[offset+2*MAX_RX+4];
  labelMask |= powerOfTwo(currentLabel);

  return (labelMask & 0xFFFE);
}

/* -----------------------------------------------------------
Name: reassignInLabelImage
Purpose: Rewrites an old label with a new value
Inputs: clumps structure, old label to overwrite,
        new label to overwrite with.
Outputs: updated clumps structure
Effects: None.
Notes: None.
----------------------------------------------------------- */
void reassignInLabelImage(offsetClumps_t *clumps, uint16 oldLabel, uint16 newLabel)
{
  uint16 elementOffset;

  elementOffset = clumps->info[oldLabel-1].firstPixelOffset;
  while(elementOffset != 0)
  {
    clumps->labelImage[elementOffset] = newLabel;
    elementOffset = clumps->listImage[elementOffset];
  }
}

/* -----------------------------------------------------------
Name: walkThroughQueue
Purpose: Performs flood fill, walking through and updating the
         queue of pixels until it is exhausted.
Inputs: delta image, clumps structure, priority queue,
        merge threshold
Outputs: Updated clumps structure, empty queue
         Returns the number of peaks merged
Effects: None.
Notes: See algorithm description at the top of this file.
----------------------------------------------------------- */
int16 walkThroughQueue(int16 *deltaImage, offsetClumps_t *clumps, priorityQueue_t *priorityQueue, uint8p8 mergeThreshold_pct)
{
  int16 contour;
  int16 merges = 0;
  int16 inc[] = {-(MAX_RX+1)-1, 1, 1, MAX_RX-1, 2, MAX_RX-1, 1, 1};

  for (contour = CONTOUR_LEVELS-1; contour >= 0; contour--)
  {
    while(!isQueueEmpty(priorityQueue, contour))
    {
      uint16 elementOffset;
      objectBitmask_t labelMask;
      int16 neighborLabelCount;
      uint16 neighborOffset;

      elementOffset = dequeuePixel(priorityQueue, contour, clumps->listImage);

      labelMask = getNeighborLabels(clumps->labelImage, elementOffset);
      neighborLabelCount = countSetBits(labelMask);

      if (neighborLabelCount == 1)
      {
        // if we only found one label among the neighbors, then that
        // is the label we will use for this pixel as well.
        uint16 label;
        int16 peakSign;
        int16 deltaSign;
        label = findLowestSetBit(labelMask);
        peakSign = (clumps->info[label-1].polarity == clumpPolarity_positive);
        deltaSign = (deltaImage[elementOffset] > 0);
        if (0 == (peakSign ^ deltaSign))
        {
          clumps->labelImage[elementOffset] = label;
          // put the new pixel on the front of the list for its clump
          clumps->listImage[elementOffset] = clumps->info[label-1].firstPixelOffset;
          clumps->info[label-1].firstPixelOffset = elementOffset;
        }
      }
      else if (neighborLabelCount == 0)
      {
        // no labels were found. This condition can occur if all the
        // neighbors were dam pixels, which do not get labeled. In
        // this case, since all the neighbors were dam pixels, this
        // will be a dam pixel, too, and we can leave it unlabeled
      }
      else
      {
        // this is a "dam" pixel between two or more labeled regions.
        // check to see if the regions should be merged.

        uint16 forceNoMerge = FALSE;
        uint16 tempLabelMask;
        uint16 mergeNeeded = FALSE;
        uint16 highestPeakLabel = 0;

        // do not merge if we have already decided not to merge
        // any subset of the neighboring clumps
        for (tempLabelMask = labelMask; tempLabelMask; tempLabelMask &= tempLabelMask - 1)
        {
          uint16 label;
          label = findLowestSetBit(tempLabelMask);
          if (priorityQueue->preventMerge[label-1] & labelMask)
          {
            forceNoMerge = TRUE;
          }
        }

        if (forceNoMerge == FALSE)
        {
          // determine merge threshold by the height of the highest peak
          // amongst the neighboring clumps.

          int16 highestPeak = 0;
          int4p12 mergeScale;
          int32 highestMergeLevel = 0;

          for (tempLabelMask = labelMask; tempLabelMask; tempLabelMask &= tempLabelMask - 1)
          {
            uint16 label;
            int16 peakValue;
            uint16 peakOffset;

            label = findLowestSetBit(tempLabelMask);
            peakOffset = clumps->info[label-1].peakOffset;
            // Multiply by scaleFactor to ensure the sign of the comparison
            // is right for positive and negative peaks
            peakValue = deltaImage[peakOffset];
            peakValue -= priorityQueue->noiseFloor_LSB;
            peakValue = (int16)(((int32)priorityQueue->scaleFactor * peakValue + 4095) / 4096);
            if (peakValue > highestPeak)
            {
              highestPeak = peakValue;
              highestPeakLabel = label;
            }
          }

          mergeScale = 0x800 + (int4p12) (((int32)((highestPeak<<12)/CONTOUR_LEVELS - 0x800) * 0x3547) >> 12);
          if (mergeScale > 0x1800) // max mergeScale is 1.5
          {
            mergeScale = 0x1800;
          }
          if (mergeScale < 0x00)  // min mergeScale is 0.0
          {
            mergeScale = 0x00;
          }

          mergeScale = (int4p12) (((int32) mergeScale * mergeThreshold_pct) >> 8);
          mergeScale = (int4p12) (((int32) mergeScale * priorityQueue->scaleFactor) >> 12);

          // determine the merge level based on the second-highest peak amongst the
          // neighboring clumps.

          for (tempLabelMask = labelMask; tempLabelMask; tempLabelMask &= tempLabelMask - 1)
          {
            uint16 label;
            int32 mergeLevel;
            int16 peakValue;
            uint16 peakOffset;

            label = findLowestSetBit(tempLabelMask);
            if (label == highestPeakLabel)
            {
              continue;
            }

            peakOffset = clumps->info[label-1].peakOffset;
            peakValue = deltaImage[peakOffset];
            peakValue -= priorityQueue->noiseFloor_LSB;
            mergeLevel = ((int32) mergeScale * peakValue) + 0x1000;
            if (mergeLevel > highestMergeLevel)
            {
              highestMergeLevel = mergeLevel;
            }
          }

          if (((int32)(contour+1)<<12) > highestMergeLevel)
          {
            mergeNeeded = TRUE;
          }
        }

        if (mergeNeeded == FALSE)
        {
          // prevent any of these clumps from ever being considered for
          // merging again
          for (tempLabelMask = labelMask; tempLabelMask; tempLabelMask &= tempLabelMask - 1)
          {
            uint16 label;
            label = findLowestSetBit(tempLabelMask);
            priorityQueue->preventMerge[label-1] |= labelMask;
            priorityQueue->preventMerge[label-1] &= ~powerOfTwo(label);
          }
        }

        // note that dam pixels are not added to any clump unless a merge occurs.

        if ((mergeNeeded == TRUE) && (0 != highestPeakLabel))
        {
          // assign the current pixel to the desired label
          clumps->labelImage[elementOffset] = highestPeakLabel;
          clumps->listImage[elementOffset] = clumps->info[highestPeakLabel-1].firstPixelOffset;
          clumps->info[highestPeakLabel-1].firstPixelOffset = elementOffset;

          // assign all merging pixels to the desired label
          for (tempLabelMask = labelMask; tempLabelMask; tempLabelMask &= tempLabelMask - 1)
          {
            uint16 label;
            label = findLowestSetBit(tempLabelMask);
            if (label != highestPeakLabel)
            {
              uint16 oldHead;
              uint16 oldTail;
              uint16 newHead;

              // fix the label image
              reassignInLabelImage(clumps, label, highestPeakLabel);
              // concatenate the lists, using the fact that
              // peakLocation is always the last pixel in the list
              oldHead = clumps->info[highestPeakLabel-1].firstPixelOffset;
              oldTail = clumps->info[label-1].peakOffset;
              clumps->listImage[oldTail] = oldHead;
              newHead = clumps->info[label-1].firstPixelOffset;
              clumps->info[highestPeakLabel-1].firstPixelOffset = newHead;
              // clear the old label out
              clumps->info[label-1].firstPixelOffset = 0;
              clumps->info[label-1].peakOffset = 0;

              clumps->info[highestPeakLabel-1].peakCount += clumps->info[label-1].peakCount;
              clumps->info[label-1].peakCount = 0;

              // fix the preventMerge values
              priorityQueue->preventMerge[highestPeakLabel-1] |= priorityQueue->preventMerge[label-1];

              merges++;
            }
          }
        }
      }

      // add all neighboring pixels to the priority queue
      {
        uint16 i;
        neighborOffset = elementOffset;

        for (i = 0; i < 8; i++)
        {
          neighborOffset += inc[i];
          if ((priorityQueue->alreadyQueued[neighborOffset/16] & powerOfTwo(neighborOffset & 0xF)) == 0)
          {
            int16 v;
            v = deltaImage[neighborOffset];
            priorityQueue->alreadyQueued[neighborOffset/16] |= powerOfTwo(neighborOffset & 0xF);
            enqueuePixel(clumps, priorityQueue, v, neighborOffset);
          }
        }
      }
    }
  }
  return merges;
}

/* -----------------------------------------------------------
Name: offsetToPixelIndex
Purpose: Converts a linear index to a row/column pixelIndex
Inputs: offset - linear index
        rowLengthTimes256 - the length of a row, stored
           in the high 8 bits of the word
Outputs: result - the row/column value
Effects: None.
Notes: 1) This assumes a particular layout for the pixelIndex_t
       type when compiled for Chimera. It also assumes that
       the __CHIMERA__ compiler symbol is synonymous with
       having the UDIV8 instruction, since I can find no
       symbol that gives the existence of this instruction.
       2) The reason for the odd formatting of the arguments
       is to produce slightly more efficient T1324 code.
----------------------------------------------------------- */
ATTR_INLINE static void offsetToPixelIndex(uint16 offset, uint16 *rowLengthTimes256, pixelIndex_t *result)
{
  #if defined(__CHIMERA__) && !__T100X_HAS_DIV16__
    uint16 r, c;
    // a single UDIV8 opcode divides the value in Y by the high 8 bits
    // of the other operand. The quotient is returned in the low 8 bits
    // of A and the remainder in the high 8 bits of Y. Even if it's a
    // little awkward, this is faster than a 16-cycle 32-by-16-bit UDIV.
    asm("        udiv8 ya, %[size]\n" :
        "=a" (r), "=y" (c) :
        "y" (offset), [size] "m" (*rowLengthTimes256) :
        "cc");
    result->col = c >> 8;
    result->row = r & 0xFF;
  #else
    result->row = offset / (*rowLengthTimes256>>8);
    result->col = offset % (*rowLengthTimes256>>8);
  #endif
}

/* -----------------------------------------------------------
Name: convertOffsetClumpsToRowColumn
Purpose: Converts the clumps data structure from the internal
         format, using linear offsets, to the external format,
         using row/column pointers.
Inputs: clumps structure
Outputs: Updated clumps structure
Effects: None.
Notes: This is highly tuned for T1324 to use 16 cycles per
       pixel. Small changes may dramatically affect the runtime.
----------------------------------------------------------- */
static void convertOffsetClumpsToRowColumn(clumps_t *clumps)
{
  uint16 rowLength = 256*(MAX_RX+1);
  uint16 idx;
  pixelIndex_t *listImage = clumps->listImage;
  for (idx = 0; idx < MAX_OBJECTS; idx++)
  {
    uint16 elementOffset;
    pixelIndex_t *indexPtr;
    uint16 *offsetPtr;

    indexPtr = &(clumps->info[idx].peakLocation);
    offsetPtr = (uint16 *) indexPtr;
    elementOffset = *offsetPtr;
    offsetToPixelIndex(elementOffset, &rowLength, indexPtr);

    indexPtr = &(clumps->info[idx].firstPixel);
    offsetPtr = (uint16 *) indexPtr;
    elementOffset = *offsetPtr;
    offsetToPixelIndex(elementOffset, &rowLength, indexPtr);

    while(indexPtr->row != 0)
    {
      indexPtr = &(listImage[elementOffset]);
      offsetPtr = (uint16 *)indexPtr;
      elementOffset = *offsetPtr;
      offsetToPixelIndex(elementOffset, &rowLength, indexPtr);
    }
  }
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: segmenter_init
Purpose: Initializes segmenter
Inputs: None
Outputs: None.
Effects: None.
Notes: Segmenter has no internal state, so this function
       does nothing.
----------------------------------------------------------- */
void segmenter_init(void)
{
}

/* -----------------------------------------------------------
Name: segmenter_reinit
Purpose: Reinitializes segmenter on rezero
Inputs: None
Outputs: None.
Effects: None.
Notes: Segmenter has no internal state, so this function
       does nothing.
----------------------------------------------------------- */
void segmenter_reinit(void)
{
  segmenter_init();
  #if (defined(CONFIG_IFP_CLOSEDCOVER_MINPEAK) && CONFIG_IFP_CLOSEDCOVER_MINPEAK)
  // if closed cover enabled, use different minPeak
  if(getClosedCoverStatus())
    minPeak_LSB = 25; // TODO: define F51 RMI register and use cfg_closedCover_hasCustomized_minPeak in cfg file.
  else
    minPeak_LSB = minPeak_LSB_bak;
  #endif
}

/* -----------------------------------------------------------
Name: segmenter_configure
Purpose: Configures segmenter parameters
Inputs: segmenter configuration struct
Outputs: None.
Effects: sets minPeak_LSB and mergeThreshold_pct.
         Also sets smallFingerThreshold_LSB
         when CONFIG_HAS_SMALL_OBJECT_DETECTOR is enabled
Notes: None.
----------------------------------------------------------- */
void segmenter_configure(segmenterConfig_t *config)
{
  #if CONFIG_HAS_SMALL_OBJECT_DETECTOR
  uint16 csat = config->saturationLevel_LSB;
  uint16 penCeiling_pct = (config->normalFingerThreshold_pct > config->palmThreshold_pct) ? config->palmThreshold_pct : config->normalFingerThreshold_pct;
  penCeiling_LSB = ((uint32)csat*penCeiling_pct + 32768) >> 16;
  smallFingerThreshold_LSB = ((uint32)csat*config->smallFingerThreshold_pct + 32768) >> 16;
  #endif
  minPeak_LSB = config->minPeak_LSB;
  #if (defined(CONFIG_IFP_CLOSEDCOVER_MINPEAK) && CONFIG_IFP_CLOSEDCOVER_MINPEAK)
  minPeak_LSB_bak = minPeak_LSB;
  #endif
  mergeThreshold_pct = config->mergeThreshold_pct;
}

/* -----------------------------------------------------------
Name: segmenter_segment
Purpose: Runs segmentation on a delta image
Inputs: delta image, noise floor, sensor parameters structure
Outputs: clumps structure
Effects: None.
Notes: The clumps structure is overwritten by this routine, so if
       it's not empty, anything already in it will be dropped.
----------------------------------------------------------- */
void segmenter_segment(int16 *deltaImage, int16 noiseFloor_LSB, sensorParams_t *sensorParams, clumps_t *clumps)
{
#if CONFIG_HAS_GLOVE_NOISE_FLOOR
  #if CONFIG_HAS_GLOVE_NOISE_FLOOR_MINPEAK
  int16 minPeak_LSB_org = minPeak_LSB;
  #endif
  if (sensorParams->GloveNF.OnlyGlove)
  {
    noiseFloor_LSB = sensorParams->GloveNF.Value;
    #if CONFIG_HAS_GLOVE_NOISE_FLOOR_MINPEAK
    if (sensorParams->GloveNF.MinPeak)
    {
      minPeak_LSB = sensorParams->GloveNF.MinPeak;
    }
    #endif
  }
#endif

  priorityQueue_t priorityQueue IFP_STACKED;
  int4p12 scaleFactor;
  uint16 peakCount;
  offsetClumps_t *offsetClumps = (offsetClumps_t *)clumps;

  {
    // We have to use a temporary here to support older compiler
    // versions, but the underlying bug (http://jira/browse/TL-37739) was fixed in
    // t100x-gcc v2013-01-21
    int32 tmp;

    tmp = CONTOUR_LEVELS;
    tmp *= 4096;
    scaleFactor = (sensorParams->cSat_LSB > 0) ? tmp/sensorParams->cSat_LSB : tmp;
  }

  initStructures(offsetClumps, &priorityQueue);

  priorityQueue.scaleFactor = scaleFactor;
  priorityQueue.noiseFloor_LSB = noiseFloor_LSB;

  // Find positive peaks
  findHighestLocalMaxima(deltaImage, noiseFloor_LSB, minPeak_LSB, sensorParams->rxCount, sensorParams->txCount, offsetClumps, &peakCount);
  enqueuePeakNeighbors(deltaImage, offsetClumps, &priorityQueue);
  peakCount -= walkThroughQueue(deltaImage, offsetClumps, &priorityQueue, mergeThreshold_pct);

  #ifdef FIND_NEGATIVE_CLUMP
  if (MAX_OBJECTS > peakCount)
  {
    // Find negative peaks
    // First reinitialize the priorityQueue
    {
      uint16 idx;
      objectBitmask_t clumpMask = 0;
      objectBitmask_t posClumps = 0;
      uint16 *pqHeads = priorityQueue.heads;
      uint16 *pqTails = priorityQueue.tails;
      uint16 *aq = priorityQueue.alreadyQueued;

      for (idx = 0, clumpMask = 2; idx < MAX_OBJECTS; idx++, clumpMask <<= 1)
      {
        if ((offsetClumps)->info[idx].firstPixelOffset != 0)
        {
          posClumps |= clumpMask;
        }
      }

      for (idx = 0; idx < CONTOUR_LEVELS; idx++)
      {
        *pqHeads++ = NO_FIRST_PIXEL;
      }

      for (idx = 0; idx < CONTOUR_LEVELS; idx++)
      {
        *pqTails++ = NO_FIRST_PIXEL;
      }

      priorityQueue.scaleFactor = -scaleFactor;
      priorityQueue.noiseFloor_LSB = -noiseFloor_LSB;
      for (idx = 0; idx < MAX_OBJECTS; idx++)
      {
        priorityQueue.preventMerge[idx] = posClumps;
      }
      for (idx = 0; idx < sizeof(priorityQueue.alreadyQueued)/sizeof(uint16); idx++)
      {
        *aq++ = 0;
      }
      for (idx = 0; idx < MAX_OBJECTS; idx++)
      {
        if ((offsetClumps)->info[idx].firstPixelOffset != 0)
        {
          uint16 offset;
          offset = (offsetClumps)->info[idx].peakOffset;
          priorityQueue.alreadyQueued[offset/16] |= powerOfTwo(offset & 0xF);
        }
      }
    }

    findLowestLocalMinima(deltaImage, -minPeak_LSB, sensorParams->txCount, offsetClumps, &peakCount);
    enqueuePeakNeighbors(deltaImage, offsetClumps, &priorityQueue);
    walkThroughQueue(deltaImage, offsetClumps, &priorityQueue, mergeThreshold_pct);
  }
  #endif

  convertOffsetClumpsToRowColumn(clumps);

#if CONFIG_HAS_GLOVE_NOISE_FLOOR && CONFIG_HAS_GLOVE_NOISE_FLOOR_MINPEAK
  minPeak_LSB = minPeak_LSB_org;
#endif
}
