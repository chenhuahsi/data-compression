#ifndef _CLUMP_SPLITTER_H
#define _CLUMP_SPLITTER_H

// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: clump_splitter.h
// Description: Header file for clump_splitter.c
//
// $Id: position_estimator.h,v 1.6.8.1.4.2 2012/12/05 02:47:44 jjordan Exp $

#include "ifp_common.h"

#if !CONFIG_HAS_LINEAR_SWIPE_SPLITTER
void clumpSplitter_split(int16 *deltaImage, uint16 cSat_LSB,
                        clumps_t *clumps);
void clumpSplitter_configure(clumpSplitterConfig_t *pcsConfig);
#else
static ATTR_INLINE void clumpSplitter_split(ATTR_UNUSED int16 *deltaImage,
                                       ATTR_UNUSED uint16 cSat_LSB,
                                       ATTR_UNUSED clumps_t *clumps) {};
static ATTR_INLINE void clumpSplitter_configure(ATTR_UNUSED clumpSplitterConfig_t *pcsConfig) {};

#endif // !CONFIG_HAS_LINEAR_SWIPE_SPLITTER

#endif //_CLUMP_SPLITTER_H
