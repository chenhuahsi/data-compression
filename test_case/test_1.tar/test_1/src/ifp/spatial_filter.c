// -----------------------------------------------------------------
// Spatial Filter
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2014  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// $Id: spatial_filter.c,v 1.1.2.2 2014/06/16 18:13:04 izhong Exp $
//

#include "ifp_common.h"
#include "spatial_filter.h"
#include "ifp_string.h"
#define SPATIAL_FILTER_N 5
// TODO:  Make this a generic NxN spatial filter class

#if CONFIG_HAS_GLOVE_SPATIAL_FILTER

#define ZERO_PADDING      ((SPATIAL_FILTER_N-1)/2)

// #if defined(cfg_f54_hasSpatialFilter) && cfg_f54_hasSpatialFilter
// uint16 spatialFilterEnable;
// uint16 spatialFilterCoeffs[SPATIAL_FILTER_N][SPATIAL_FILTER_N];
// #endif

#if CONFIG_HAS_GLOVE_SPATIAL_FILTER
uint16 gloveSpatialFilterEnable;
uint16 gloveSpatialFilterCoeffs[SPATIAL_FILTER_N][SPATIAL_FILTER_N];
uint16 exitThreshold;
#endif
#if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER
static int16 gloveSpatialFilterNormalizer[SPATIAL_FILTER_N][SPATIAL_FILTER_N];
#endif

// Duplicate of C++ routines
inline void spatialFilter_clearArray(uint16 *p, uint16 size) {
  // It is invalid to call this routine with a size of 0
  // One reason we do this instead of calling the Assembly routine clearMemoryUI like
  // used to is so the compiler can make use of ZLOOP for T1323 when this is in the
  // Calculation thread.
  if (p == NULL) return;
  do {
    *p = 0;
    p++;
  } while (--size);
}

inline void spatialFilter_copyMemoryUI(uint16* src, uint16* dst, uint16 size) {
  // Testing for size=0 on entry makes this routine 10 instructions larger, so
  // we don't do it.  Note that this means that size=0 tries to copy 64K words.
  do {
    *dst++ = *src++;
  } while (--size != 0);
}

void spatialFilter_configure(spatialFilterConfig_t *config, spatialFilterType_t type)
{
  uint16 *filter = NULL;
  exitThreshold = config->exitThreshold;
  if(type == spatialFilterType_glove)
  {
    #if CONFIG_HAS_GLOVE_SPATIAL_FILTER
      gloveSpatialFilterEnable = config->enable;
      filter = &gloveSpatialFilterCoeffs[0][0];
    #endif
  }
  else
  {
    // #if defined(cfg_f54_hasSpatialFilter) && cfg_f54_hasSpatialFilter
      // spatialFilterEnable = config->enable;
      // filter = &spatialFilterCoeffs[0][0];
    // #endif
  }

  // Copy coefficient.  Due to symmetry not all the matrix need to be stored.
  // For example:
  //
  // 1,  4,  5,  4,  1
  // 4,  9, 12,  9,  4
  // 5, 12, 16, 12,  5
  // 4,  9, 12,  9,  4
  // 1,  4,  5,  4,  1
  //
  // Is passed as:
  //
  // 1, 4, 5, 4, 9, 12, 5, 12, 16

  // TODO: Hard-coded.  Can this be replaced with loops?
  if (config->size == spatialFilterSize_5x5)
  {
    filter[0]  = config->coeffs[0];
    filter[4]  = config->coeffs[0];
    filter[20] = config->coeffs[0];
    filter[24] = config->coeffs[0];

    filter[1]  = config->coeffs[1];
    filter[3]  = config->coeffs[1];
    filter[21] = config->coeffs[1];
    filter[23] = config->coeffs[1];

    filter[2]  = config->coeffs[2];
    filter[22] = config->coeffs[2];

    filter[5]  = config->coeffs[3];
    filter[9]  = config->coeffs[3];
    filter[15] = config->coeffs[3];
    filter[19] = config->coeffs[3];

    filter[6]  = config->coeffs[4];
    filter[8]  = config->coeffs[4];
    filter[16] = config->coeffs[4];
    filter[18] = config->coeffs[4];

    filter[7]  = config->coeffs[5];
    filter[17] = config->coeffs[5];

    filter[10] = config->coeffs[6];
    filter[14] = config->coeffs[6];

    filter[11] = config->coeffs[7];
    filter[13] = config->coeffs[7];

    filter[12] = config->coeffs[8];
  }
  else if (config->size == spatialFilterSize_4x4)
  {
    spatialFilter_clearArray(filter, 25);

    filter[6]  = config->coeffs[0];
    filter[9]  = config->coeffs[0];
    filter[21] = config->coeffs[0];
    filter[24] = config->coeffs[0];

    filter[7]  = config->coeffs[1];
    filter[8]  = config->coeffs[1];
    filter[22] = config->coeffs[1];
    filter[23] = config->coeffs[1];

    filter[11] = config->coeffs[2];
    filter[14] = config->coeffs[2];
    filter[16] = config->coeffs[2];
    filter[19] = config->coeffs[2];

    filter[12] = config->coeffs[3];
    filter[13] = config->coeffs[3];
    filter[17] = config->coeffs[3];
    filter[18] = config->coeffs[3];
  }
  else if (config->size == spatialFilterSize_3x3)
  {
    spatialFilter_clearArray(filter, 25);

    filter[6]  = config->coeffs[0];
    filter[8]  = config->coeffs[0];
    filter[16] = config->coeffs[0];
    filter[18] = config->coeffs[0];

    filter[7]  = config->coeffs[1];
    filter[17] = config->coeffs[1];

    filter[11] = config->coeffs[2];
    filter[13] = config->coeffs[2];

    filter[12] = config->coeffs[3];
  }
  else
  {
    // Unsupported size, best disable the filter

    if(type == spatialFilterType_glove)
    {
      #if CONFIG_HAS_GLOVE_SPATIAL_FILTER
        gloveSpatialFilterEnable = 0;
      #endif
    }
    else
    {
      // #if defined(cfg_f54_hasSpatialFilter) && cfg_f54_hasSpatialFilter
        // spatialFilterEnable = 0;
      // #endif
    }

  }

#if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER
  if(type == spatialFilterType_glove)
  {
  #if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER_CUSTOM
    if (config->Custom)
    {
      memcpy16(&gloveSpatialFilterNormalizer[0][0], config->divider, 25);
    }
    else
  #endif
    {
      memset16(&gloveSpatialFilterNormalizer[0][0], 0, sizeof(gloveSpatialFilterNormalizer) / sizeof(uint16));
      int16 row, col, r, c;
      int16 *value = filter;
      for (row = -2; row <= 2; row++)
      {
        for (col = -2; col <= 2; col++)
        {
          int16 *normalizer = &gloveSpatialFilterNormalizer[0][0];
          for (r = -2; r <= 2; r++)
          {
            for (c = -2; c <= 2; c++)
            {
              if (
                  ((r == -2 &&  0 <= row     )
                || (r == -1 && -1 <= row     )
                || (r ==  0                  )
                || (r ==  1 &&       row <= 1)
                || (r ==  2 &&       row <= 0))
                &&
                  ((c == -2 &&  0 <= col     )
                || (c == -1 && -1 <= col     )
                || (c ==  0                  )
                || (c ==  1 &&       col <= 1)
                || (c ==  2 &&       col <= 0))
              )
              {
                *normalizer += *value;
              }
              normalizer++;
            }
          }
          value++;
        }
      }

      int16 center = gloveSpatialFilterNormalizer[2][2];
      int16 *normalizer = &gloveSpatialFilterNormalizer[0][0];
      uint16 i;
      for (i = 0; i < SPATIAL_FILTER_N * SPATIAL_FILTER_N; i++)
      {
        *normalizer = ((int32)*normalizer * 0x100) / center;
        normalizer++;
      }
    }
  }
#endif
}

int16 spatialFilter_filterPixel(int16 *src, uint16 row0, spatialFilterType_t type
          #if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER
          , int16 divider
          #endif
)
{
  uint16 i;

  // src points to the input rows circular buffer (by row), src[row0] points to the top left pixel

  // coefficients are Q8.8
  uint16 *filter = NULL;

  int32 res = 0;

  if(type == spatialFilterType_glove)
  {
    #if CONFIG_HAS_GLOVE_SPATIAL_FILTER
      filter = &gloveSpatialFilterCoeffs[0][0];
    #endif
  }
  else
  {
    // #if defined(cfg_f54_hasSpatialFilter) && cfg_f54_hasSpatialFilter
      // filter = &spatialFilterCoeffs[0][0];
    // #endif
  }

#if CONFIG_HAS_MAGIC_GLOVE_FILTER
  filter[6]  = 16;
  filter[8]  = 16;
  filter[16] = 16;
  filter[18] = 16;

  filter[7]  = 32;
  filter[17] = 32;

  filter[11] = 32;
  filter[13] = 32;

  filter[12] = 64;
#endif

  for (i=0; i<SPATIAL_FILTER_N; i++)
  {
    uint16 j;
    int16 *row = src + (row0 * (MAX_RX+2*ZERO_PADDING));
    if (++row0 == SPATIAL_FILTER_N)
    {
      row0 = 0;
    }

    for (j=0; j<SPATIAL_FILTER_N; j++)
    {
      res += (int32)(*row) * (int16)(*filter);
      row++;
      filter++;
    }
  }

  // Assumption is there is no overflow after the shift operation.
  // This is a reasonable assumption for reasonable filters but
  // we allow RMI control so it is possible that all coefficients
  // will be 1.0 so we end up with a 25 (5x5) increase if all
  // pixels are the same delta.  To be safe that we don't exceed
  // 16-bits we saturate.  If we find that the deltas do not
  // exceed 32767/25 then we do not need to check for saturation.
#if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER
  if (divider)
  {
    res /= divider;
  }
  else
#endif
  {
    res >>= 8;
  }
  if (res > 32767) {
    res = 32767;
  }
  else if (res < -32768) {
    res = -32768;
  }

  return ((int16)res);
}

void spatialFilter_processFrame(sensorParams_t *params, int16 *image, spatialFilterDelta_t mode, spatialFilterType_t type)
{
  #if CONFIG_HAS_GLOVE_ONLY
  if (params->GloveOnly.Suppress)
  {
    return;
  }
  #endif

  uint16 filterEnable = 0;
  
  if(spatialFilterType_glove)
  {
    filterEnable = gloveSpatialFilterEnable;
    int16 *p = image;
    uint16 i,j;
    uint16 stride = 0;
    uint16 numRows = params->txCount;
    uint16 numCols = params->rxCount;
    if (mode == spatialFilterDelta_padded)
    {
      p+= MAX_RX + 1 + 1;
      stride = MAX_RX - numCols  + 1;
    }
    for (i = 0; i < numRows; i++)
    {
      for (j = 0; j < numCols; j++)
      {
        if (*p > (int16)exitThreshold)
        {
          filterEnable = 0;
          break;
        }
        p++;
      }
      p += stride;
    }
  }
  else
  {
    // Not enabled for normal mode
    filterEnable = 0;
  }

  if (filterEnable)
  {
    uint16 row, srcRow;

    // Each pixel in the image data is processed using a 5x5 matrix with the pixel at the center.
    // So the image is viewed as if it is surrounded by 2 ((SPATIAL_FILTER_N-1)/2) rows and columns of zeros.

    uint16 numRows = params->txCount;
    uint16 numCols = params->rxCount;

    // Image pointers for src and dest
    int16 *imgSrc  = image;
    int16 *imgDest = image;
    uint16 stride = MAX_RX;

    if (mode == spatialFilterDelta_padded)
    {
      // account for border
      imgSrc += ((MAX_RX + 1) + 1);
      imgDest += ((MAX_RX + 1) + 1);
      stride += 1;
    }

    // Holds our input data with the current processed image row at the "center".  Each row is padded To re-use data we use
    // an index to indicate the "0th" row, the pixel row being processed will be this index+2
    int16 inputRows[SPATIAL_FILTER_N][MAX_RX + (2*ZERO_PADDING)];
    uint16 inputRowsIdx = 0;

    // Setup our initial input - clear our inputRows, then copy over 3 rows.
    spatialFilter_clearArray((uint16*)inputRows, (sizeof(inputRows) / sizeof(uint16)));
    inputRowsIdx += ZERO_PADDING;

    for (srcRow=0; srcRow<(SPATIAL_FILTER_N-ZERO_PADDING); srcRow++)
    {
      spatialFilter_copyMemoryUI((uint16*)imgSrc, (uint16*)&inputRows[inputRowsIdx][ZERO_PADDING], numCols);
      imgSrc += stride;
      inputRowsIdx++;
      if (inputRowsIdx == SPATIAL_FILTER_N)
      {
        inputRowsIdx = 0;
      }
    }

  #if CONFIG_HAS_SPATIAL_CAP
    int16 max = 0;
  #endif
    // Process each row
    for (row=0; row<numRows; row++)
    {
      uint16 col;

      // Apply filter and store result back into image
      int16* destPtr = imgDest;
      #if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER
      int16 *normalizer = params->SpatialFilterNormalizer.Enable ? &gloveSpatialFilterNormalizer[(row < 2) ? (row == 0 ? 0 : 1) : ((numRows - 2 <= row) ? (numRows - 1 == row ? 4 : 3) : 2)][0] : NULL;
      #endif
      for (col=0; col<numCols; col++)
      {
      #if CONFIG_HAS_SPATIAL_CAP
        int16 value=
      #endif
        *destPtr++ = spatialFilter_filterPixel((int16*)&inputRows[0][col], inputRowsIdx, type
          #if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER
          , normalizer ? normalizer[(col < 2) ? (col == 0 ? 0 : 1) : ((numCols - 2 <= col) ? (numCols - 1 == col ? 4 : 3) : 2)] : 0
          #endif
        );
      #if CONFIG_HAS_SPATIAL_CAP
        if (max < value)
        {
          max = value;
        }
      #endif
      }

      // Update output
      imgDest += stride;

      // Update input
      if (srcRow++ < numRows)
      {
        // Copy next image row
        spatialFilter_copyMemoryUI((uint16*)imgSrc, (uint16*)&inputRows[inputRowsIdx][ZERO_PADDING], numCols);
        imgSrc += stride;
      }
      else
      {
        // Near end, clear padding rows
        spatialFilter_clearArray((uint16*)&inputRows[inputRowsIdx][ZERO_PADDING], numCols);
      }
      inputRowsIdx++;
      if (inputRowsIdx == SPATIAL_FILTER_N)
      {
        inputRowsIdx = 0;
      }
    }

  #if CONFIG_HAS_SPATIAL_CAP
    if (params->SpatialCap.limit && params->SpatialCap.limit < max)
    {
      int16 coeff = ((int32)params->SpatialCap.limit << 8) / max;
      for (row=0; row<numRows; row++)
      {
        int16 *delta= &image[(MAX_RX + 1) * (row + 1) + 1];
        uint16 col;
        for (col=0; col<numCols; col++, delta++)
        {
          *delta = ((int32)*delta * coeff) >> 8;
        }
      }
    }
  #endif

  }
}

#endif // cfg_f54_hasSpatialFilter
