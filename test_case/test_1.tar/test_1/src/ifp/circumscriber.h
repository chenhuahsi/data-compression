#ifndef _CIRCUMSCRIBER_H
#define _CIRCUMSCRIBER_H

// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2013  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: circumscriber.h
// Description: Header file for circumscriber.c
// $Id$

#include "ifp_common.h"

/* ----------------------------------------------------------------------------
  Name: circumscriber_circumscribeClumps
  Purpose: The purpose of this routine is to draw a contour around a pixel group
  Inputs: clumps structure, delta image, sensor parameters
  Outputs: modified clumps structure
  Effects: None.
  Notes: - This routine will increase the bit clump border by one pixel.
         - Four-connectivity logic is used to define connected pixels.
           In other words, if a pixel is 0, then it will be relabeled to
           match its neighbor if either its north, south, east or west
           neighbor is set.
         - Neighbors of opposite sign will be ignored, so positive
           clumps will continue to only have positive pixels.
         - Pixels above the noise floor will not be added to any clumps
           so that pixels between split clumps will remain unassigned.
         - Implementation note: If one empty pixel has two differently
           labeled neighbors of the correct sign, it will be assigned
           the lower of the two labels.
---------------------------------------------------------------------------- */
void circumscriber_circumscribeClumps(clumps_t *clumps, int16 *deltaImage,
                                      sensorParams_t *sensorParams);

#endif //_CIRCUMSCRIBER_H
