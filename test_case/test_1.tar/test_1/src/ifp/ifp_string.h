/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

  Description: Provide memory management utilities, typically found in string.h
----------------------------------------------------------------- */

#ifndef _IFP_STRING_H
#define _IFP_STRING_H

/* -----------------------------------------------------------------
Name: memset16
Purpose: Set each 16-bit word of a block of memory to a particular value
Inputs: Pointer to start of memory, value to set, how many 16-bit words to set
Outputs: None
Note: This routine will not accept byteptrs.
------------------------------------------------------------------ */
static INLINE void memset16(void *dst, uint16 value, uint16 size)
{
  uint16 i;
  uint16 *memset_dstPtr = (uint16 *) dst;
  for (i = 0; i < size; i++)
  {
    *memset_dstPtr++ = value;
  }
}

static INLINE void memcpy16(void *dst, void *src, uint16 size)
{
  uint16 i;
  uint16 *memcpy_dstPtr = (uint16 *) dst;
  uint16 *memcpy_srcPtr = (uint16 *) src;
  for (i = 0; i < size; i++)
  {
    *memcpy_dstPtr++ = *memcpy_srcPtr++;
  }
}

#endif // _IFP_STRING_H
