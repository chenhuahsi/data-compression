#ifndef _touch_buffer_H_
#define _touch_buffer_H_
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2013  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: touch_buffer.h
   Description: Header file for using the touch buffer module.
----------------------------------------------------------------- */
// $Id: touch_buffer.h,v 1.1.2.11.2.4.20.1 2013/10/01 22:42:03 rfreeze Exp $

#include "ifp_common.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

// #if defined(cfg_TOUCH_BUFFER_SIZE)
//   #define TOUCH_BUFFER_SIZE cfg_TOUCH_BUFFER_SIZE
// #else
//   #define TOUCH_BUFFER_SIZE 9
// #endif

// #define TOUCH_BUFFER_SIZE 7 //As defined in typical build config //_DS_TODO: Define these in .c

// #if MAX_OBJECTS > 10
//   #define N_TOUCHES_PER_FRAME 10
// #else
//   #define N_TOUCHES_PER_FRAME MAX_OBJECTS
// #endif

typedef enum
{
  touchBuffer_normal = 0,
  touchBuffer_noiseMitigation,
  touchBuffer_moisture,
} touchBuffer_t;

/* =================================================================
   MODULE TYPES
==================================================================*/

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/
/* -----------------------------------------------------------
Name:    touchBuffer_init()
Purpose: Initializes the touch buffer
Inputs:  none
Outputs: none
Effects: Resets internal state of touch buffer, as at
         power-on.
Notes:   This function must be called before using the touch
         buffer module.
Example: none
----------------------------------------------------------- */
void touchBuffer_init(void);


/* -----------------------------------------------------------
Name:    touchBuffer_reinit()
Purpose: Reinitializes the touch buffer
Inputs:  none
Outputs: none
Effects: Resets internal state of touch buffer, as at a host rezero.
Notes:   This function must be called if the host sends a rezero
         command.
Example: none
----------------------------------------------------------- */
void touchBuffer_reinit(void);

/* -----------------------------------------------------------
Name:    touchBuffer_configure(sensorParams_t *sensorParams,
                               coordConvConfig_t *config)
                               IFP_ATTR_ANYROM ATTR_THREAD(_thr_Calculation);
Purpose: Set host-defined parameters
Inputs:  Sensor and Coordinate conversion parameters
         used to properly convert from sensor to hose units.
Outputs: none
Effects: Resets internal state of touch buffer, as at a
         host rezero.
Notes:   This function must be called if the host sends a rezero
         command.
Example: none
----------------------------------------------------------- */
void touchBuffer_configure(sensorParams_t *sensorParams,
                           coordConvConfig_t *config,
                           uint16 forceFreshReportFlag);


/* -----------------------------------------------------------
Name:    touchBuffer_update()
Purpose: enqueues the current report in the buffer
Inputs:  report - the position which was going to be reported
                 to the host if not for buffering
         useHighNoiseState - boolean indicating whether to use the
                             delay and filtering or not
Outputs: buffered report - the position data to be reported
                           from the buffer.
Effects: none
Notes:   none
Example: none
----------------------------------------------------------- */
void touchBuffer_update(reportData_t *report,
                        uint16 useHighNoiseState);

// /* -----------------------------------------------------------
// Name:    touchBuffer_getSwapAxisFlag
// Purpose: Used to indicate if tx is on x or y. Used in calculation
//          thread for single finger mode
// Inputs:  None
// Outputs: Integer which returns indicates if the tx is on x or y
// Effects: none
// Notes:   none
// Example: none
// ----------------------------------------------------------- */
// uint16  touchBuffer_getSwapAxisFlag()
//                  IFP_ATTR_ANYROM ATTR_THREAD(_thr_Calculation);

// /* -----------------------------------------------------------
// Name:    touchBuffer_getSensorX
// Purpose: Takes a host position and converts it into a sensor
//          position. Used by the single finger mode to compute
//          missing data fields
// Inputs:  Position in host units
// Outputs: Position in sensor units
// Effects: none
// Notes:   none
// Example: none
// ----------------------------------------------------------- */
// int8p8 touchBuffer_getSensorX(int16 hostX)
//                  IFP_ATTR_ANYROM ATTR_THREAD(_thr_Calculation);

// /* -----------------------------------------------------------
// Name:    touchBuffer_getSensorY
// Purpose: Takes a host position and converts it into a sensor
//          position. Used by the single finger mode to compute
//          missing data fields
// Inputs:  Position in host units
// Outputs: Position in sensor units
// Effects: none
// Notes:   none
// Example: none
// ----------------------------------------------------------- */
// int8p8 touchBuffer_getSensorY(int16 hostY)
//                  IFP_ATTR_ANYROM ATTR_THREAD(_thr_Calculation);


// int16 touchBuffer_applyHoverPositionFilter(int16 position, uint16 hoverIndex, uint16 isX)
//                  IFP_ATTR_ANYROM ATTR_THREAD(_thr_Calculation);
// #if defined(cfg_HAS_HOVER_POSITION_BUFFER_JUMP_FIX) && cfg_HAS_HOVER_POSITION_BUFFER_JUMP_FIX
// void touchBuffer_resetHoverPositionFilter(int16 position, uint16 hoverIndex, uint16 isX)
//                  IFP_ATTR_ANYROM ATTR_THREAD(_thr_Calculation);
// #endif
#endif /* matches #ifndef _touch_buffer_H_ */
