/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Dr.
   San Jose, CA 95131
   (408) 904-1100

   Description: Recorrect pen signals that have been mutilated by other
                correction algorithms
=----------------------------------------------------------------- */

/* Recorrection Algorithm Overview ---------------------------------



------------------------------------------------------------------*/

#include "ifp_common.h"

#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
#include "ifp_string.h"
#include "pen_recorrector.h"
#include "baseline_updater.h"
#include "ifp_vector_util.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/
#define PEN_RECORRECTOR_MAX_DIST 5
#define PEN_RECORRECTOR_MAX_PEAKS 41

/* =================================================================
   MODULE TYPES
==================================================================*/

typedef struct
{
 uint16 hasPalm;
 uint16 hasPenTarget;
 uint16 penTargetRow;
 uint16 penTargetCol;
} penTarget_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static int16 penCeiling_LSB;
static int16 smallFingerThreshold_LSB;
static penTarget_t penTarget;

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

// use these functions from the segmenter
extern uint16 isLocalMax(int16 *deltaPtr);
extern void addPeak(sortedPeakList_t *sortedPeaks, uint16 offset, uint16 amplitude);
static int16 sumBorder(int16 *deltaUncorr, int16 startRow, int16 endRow, int16 startCol, int16 endCol);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: sumBorder()
Purpose: Sum the border of a region with a delta image
Inputs: Delta image, Box coordinates
Outputs: The sum of the delta image along the outer edge of the box
Effects: None
Example:

  Delta image:

      0 0 0 0 0 0 0 0
      0 0 0 1 3 5 7 0
      0 0 0 3 2 5 2 0
      0 0 0 2 3 4 5 0
      0 0 0 0 0 0 0 0

  sumBorder(deltaImage, 2, 4, 3, 6) would sum the outer-most
  non-zero values to yield 35.
----------------------------------------------------------------- */
static int16 sumBorder(int16 *deltaPtr, int16 startRow, int16 endRow, int16 startCol, int16 endCol)
{
  int16 sum = 0;
  int16 row;
  deltaPtr += startRow * (MAX_RX + 1) + startCol;  // Start at top-left corner
  sum += (int16) sum16(deltaPtr, endCol - startCol + 1);  // Top row
  sum += (int16) sum16(deltaPtr + (endRow - startRow) * (MAX_RX + 1), endCol - startCol + 1);  // Bottom row

  // Left column minus corners
  for (row = 1; row < endRow - startRow; row++)
  {
    sum += deltaPtr[row * (MAX_RX + 1)];
  }

  // Right column minus corners
  deltaPtr += endCol - startCol;
  for (row = 1; row < endRow - startRow; row++)
  {
    sum += deltaPtr[row * (MAX_RX + 1)];
  }
  return sum;
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: penRecorrector_init()
Purpose: Initialize the pen recorrector module.
Inputs: None.
Outputs: None.
Effects: Resets internal state of the target pen detection variables, as at power-on.
Notes: This function must be called before using the pen recorrector module.
Example: None.
----------------------------------------------------------------- */
void penRecorrector_init(void)
{
  penTarget.hasPalm = 0;
  penTarget.hasPenTarget = 0;
  penTarget.penTargetRow = 0;
  penTarget.penTargetCol = 0;
}

/* -----------------------------------------------------------------
Name: penRecorrector_init()
Purpose: Reinitialize the pen recorrector module.
Inputs: None.
Outputs: None.
Effects: Resets internal state of the target pen detection variables, as at host rezero.
Notes: This function must be called if the host sends a rezero command.
Example: None.
----------------------------------------------------------------- */

void penRecorrector_reinit(void)
{
  penRecorrector_init();
}

/* -----------------------------------------------------------
Name: penRecorrector_configure
Purpose: Configures pen recorrector parameters
Inputs: pen recorrector configuration struct
Outputs: None.
Effects: sets penCeiling_LSB and smallFingerThreshold_LSB
Notes: None.
----------------------------------------------------------- */
void penRecorrector_configure(penRecorrectorConfig_t *config)
{
  uint16 csat = config->saturationLevel_LSB;
  uint16 penCeiling_pct = (config->normalFingerThreshold_pct > config->palmThreshold_pct) ? config->palmThreshold_pct : config->normalFingerThreshold_pct;
  penCeiling_LSB = ((uint32)csat*penCeiling_pct + 32768) >> 16;
  smallFingerThreshold_LSB = ((uint32)csat*config->smallFingerThreshold_pct + 32768) >> 16;
}

/* -----------------------------------------------------------
Name: penRecorrector_setPenTarget
Purpose: Sets the pen target parameters if a pen, eraser, or small object has been found
Inputs: trackedObjects, clumps, and classifications.
Outputs: None.
Effects: detects when a pen, eraser, or small object has been found and sets the Targeted
         Pen Detection variables appropriately.
Notes: None.
----------------------------------------------------------- */
void penRecorrector_setPenTarget(trackedObject_t *trackedObjects, clumps_t *clumps, classification_t *classifications)
{
  int16 penClumpId = 0;
  int16 palmClumpId = 0;
  uint16 penNumFrames = 0;
  uint16 i;
  classification_t *classificationsPtr = classifications;
  trackedObject_t *trackedObjectsPtr = trackedObjects;

  for (i = 0; i < MAX_OBJECTS; i++, classificationsPtr++, trackedObjectsPtr++)
  {
    if (trackedObjectsPtr->clumpId > 0)
    {
      if (classificationsPtr->touchType == touchType_stylus || classificationsPtr->touchType == touchType_eraser || classificationsPtr->touchType == touchType_smallObject)
      {
        if (penClumpId == 0 || trackedObjectsPtr->trackedFrames > penNumFrames)
        {
          penClumpId = trackedObjectsPtr->clumpId;
          penNumFrames = trackedObjectsPtr->trackedFrames;
        }
      }

      if (classificationsPtr->touchType == touchType_palm)
      {
        palmClumpId = trackedObjectsPtr->clumpId;
      }
    }
  }

  if (penClumpId > 0)
  {
    penTarget.hasPenTarget = 1;
    penTarget.penTargetRow = clumps->info[penClumpId-1].peakLocation.row;
    penTarget.penTargetCol = clumps->info[penClumpId-1].peakLocation.col;
  }
  else
  {
    penTarget.hasPenTarget = 0;
    penTarget.penTargetRow = 0;
    penTarget.penTargetCol = 0;
  }

  if (palmClumpId > 0)
  {
    penTarget.hasPalm = 1;
  }
  else
  {
    penTarget.hasPalm = 0;
  }
}

/* -----------------------------------------------------------
Name: penRecorrector_recorrectPen
Purpose: Recorrects a delta image around the most pen-like signal in the target region.
Inputs:  sensor parameters, uncorrected delta image, corrected delta image
Outputs: delta image with pen region recorrected
Effects: finds a pen signal in the target region of the uncorrected delta image and recorrects it for the corrected delta image
----------------------------------------------------------- */
void penRecorrector_recorrectPen(sensorParams_t *sensorParams, uint16 *rawImage, imageBaseline_t *baseline, int16 *deltaImage)
{
  uint16 rxCount = sensorParams->rxCount;
  uint16 txCount = sensorParams->txCount;

  int16 deltaImageUncorr[(MAX_TX+2)*(MAX_RX+1)+1] IFP_STACKED;

  int16 *deltaPtr;
  int16 *deltaUncorrPtr;

  uint16 i;
  int16 v;
  sortedPeakList_t sortedPeaks;

  uint16 peakIdx;
  uint32 peakDs2;

  int16 maxDist = PEN_RECORRECTOR_MAX_DIST;

  if (!(penTarget.hasPenTarget || penTarget.hasPalm))
  {
    return;
  }

  if (!penTarget.hasPenTarget)
  {
    maxDist = (MAX_RX > MAX_TX) ? MAX_RX : MAX_TX;
  }

  // Grab snapshot of pen target region before corrections
  memset16_large(deltaImageUncorr, 0, (MAX_TX+2)*(MAX_RX+1)+1);
  baselineUpdater_remove(sensorParams, rawImage, baseline, deltaImageUncorr);

  // remove DC display noise
  {
    int16 displayNoiseOffsets[MAX_TX];
    int16 *displayNoiseOffsetsPtr;
    uint16 row;
    uint16 numCols;

    int16 startRow = (int16)penTarget.penTargetRow - (maxDist+2);
    int16 endRow = (int16)penTarget.penTargetRow + (maxDist+2);
    int16 startCol = (int16)penTarget.penTargetCol - (maxDist+2);
    int16 endCol = (int16)penTarget.penTargetCol + (maxDist+2);

    startRow = (startRow < 1) ? 1 : startRow;
    endRow = (endRow > (int16)txCount) ? (int16)txCount : endRow;
    startCol = (startCol < 1) ? 1 : startCol;
    endCol = (endCol > (int16)rxCount) ? (int16)rxCount : endCol;

    memset16(displayNoiseOffsets, 0, MAX_TX);
    for (row = startRow; row <= (uint16)endRow; row++)
    {
      int16 displayNoiseOffset;
      int16 displayNoiseSign;

      deltaPtr = deltaImage + (MAX_RX+1)*row + 1;
      deltaUncorrPtr = deltaImageUncorr + (MAX_RX+1)*row + 1;
      displayNoiseOffsetsPtr = displayNoiseOffsets + row - 1;
      for (i = 0; i < MAX_RX; i++)
      {
        *(displayNoiseOffsetsPtr) +=  *(deltaUncorrPtr++) - *(deltaPtr++);
      }

      displayNoiseOffset = *(displayNoiseOffsetsPtr);
      displayNoiseSign = (displayNoiseOffset < 0) ? -1 : 1;
      displayNoiseOffset *= displayNoiseSign;
      displayNoiseOffset += (rxCount + 1) >> 1;
      displayNoiseOffset /= rxCount;
      *(displayNoiseOffsetsPtr) = displayNoiseSign * displayNoiseOffset;
    }

    numCols = endCol - startCol + 1;
    for (row = startRow; row <= (uint16)endRow; row++)
    {
      deltaUncorrPtr = deltaImageUncorr + (MAX_RX+1)*row + startCol;
      displayNoiseOffsetsPtr = displayNoiseOffsets + row - 1;
      for (i = 0; i < numCols; i++)
      {
        *deltaUncorrPtr++ -= *(displayNoiseOffsetsPtr);
      }
    }
  }


  // find positive peaks peaks in target region
  {
    int16 *startDelta;
    int16 *endDelta;
    uint16 rowSkip;
    int16 startRow = (int16)penTarget.penTargetRow - maxDist;
    int16 endRow = (int16)penTarget.penTargetRow + maxDist;
    int16 startCol = (int16)penTarget.penTargetCol - maxDist;
    int16 endCol = (int16)penTarget.penTargetCol + maxDist;

    startRow = (startRow < 1) ? 1 : startRow;
    startCol = (startCol < 1) ? 1 : startCol;
    endRow = (endRow > (int16)txCount) ? (int16)txCount : endRow;
    endCol = (endCol > (int16)rxCount) ? (int16)rxCount : endCol;
    rowSkip = (MAX_RX+1) - (endCol - startCol) - 1;

    startDelta = &deltaImageUncorr[(MAX_RX+1)*startRow + startCol];
    endDelta = &deltaImageUncorr[(MAX_RX+1)*endRow+endCol+1];

    sortedPeaks.minAmplitude = 0;
    sortedPeaks.peakCount = 0;

    for (deltaUncorrPtr = startDelta; deltaUncorrPtr < endDelta;)
    {
      if (*deltaUncorrPtr++ > 0)
      {
        if (isLocalMax(deltaUncorrPtr-1))
        {
          uint16 offset;
          v = *(--deltaUncorrPtr);
          offset = (uint16)(deltaUncorrPtr - deltaImageUncorr);
          addPeak(&sortedPeaks, offset, (uint16)v);
          deltaUncorrPtr = &deltaImageUncorr[offset+1];
        }
      }
      if (((int16)(deltaUncorrPtr - deltaImageUncorr) % (MAX_RX+1)) > endCol)
      {
        deltaUncorrPtr += rowSkip;
      }
    }
  }

  // find pen peak from positive peaks
  {
    int16 smallFingerHalfThreshold_LSB = (smallFingerThreshold_LSB + 1) >> 1;
    uint32 SDPThreshold = (uint32)3*smallFingerThreshold_LSB*smallFingerThreshold_LSB;
    uint32 SDPQuarterThreshold = (SDPThreshold + 2) >> 2;
    peakIdx = 0;
    peakDs2 = 0;
    for (i = 0; i < sortedPeaks.peakCount; i++)
    {
      uint16 newOffset = sortedPeaks.peakList[i].offset;

      if(deltaImage[newOffset] > penCeiling_LSB)
      {
        continue;
      }

      {
        uint16 row = newOffset / (MAX_RX+1);
        uint16 col = newOffset % (MAX_RX+1);
        int16 dc = 0;
        int16 dr = 0;
        int16 ddc = 0;
        int16 ddr = 0;
        uint32 ds2 = 0;
        deltaUncorrPtr = deltaImageUncorr + newOffset;


        if (col == 1)
        {
          dc = *deltaUncorrPtr - *(deltaUncorrPtr + 1);
          ddc = *deltaUncorrPtr + *(deltaUncorrPtr + 1) - 2*(*(deltaUncorrPtr + 2));
        }
        else if (col == rxCount)
        {
          dc = *deltaUncorrPtr - *(deltaUncorrPtr - 1);
          ddc = *deltaUncorrPtr + *(deltaUncorrPtr - 1) - 2*(*(deltaUncorrPtr - 2));
        }
        else
        {
          ddc = *deltaUncorrPtr - *(deltaUncorrPtr + 1);
          dc = *deltaUncorrPtr - *(deltaUncorrPtr - 1);
          dc = (dc > ddc) ? dc : ddc;
          ddc = 2*(*deltaUncorrPtr) - *(deltaUncorrPtr - 1) - *(deltaUncorrPtr + 1);
        }

        if (ddc < smallFingerHalfThreshold_LSB || dc < smallFingerHalfThreshold_LSB)
        {
          continue;
        }


        if (row == 1)
        {
          dr = *deltaUncorrPtr - *(deltaUncorrPtr + (MAX_RX+1));
          ddr = *deltaUncorrPtr + *(deltaUncorrPtr + (MAX_RX+1)) - 2*(*(deltaUncorrPtr + 2*(MAX_RX+1)));
        }
        else if (row == txCount)
        {
          dr = *deltaUncorrPtr - *(deltaUncorrPtr - (MAX_RX+1));
          ddr = *deltaUncorrPtr + *(deltaUncorrPtr - (MAX_RX+1)) - 2*(*(deltaUncorrPtr - 2*(MAX_RX+1)));
        }
        else
        {
          ddr = *deltaUncorrPtr - *(deltaUncorrPtr + (MAX_RX+1));
          dr = *deltaUncorrPtr - *(deltaUncorrPtr - (MAX_RX+1));
          dr = (dr > ddr) ? dr : ddr;
          ddr = 2*(*deltaUncorrPtr) - *(deltaUncorrPtr - (MAX_RX+1)) - *(deltaUncorrPtr + (MAX_RX+1));
        }

        if (ddr <= 0 || dr < smallFingerHalfThreshold_LSB)
        {
          continue;
        }


        ds2 = (uint32)ddc * ddr;
        if (ds2 > SDPQuarterThreshold)
        {
          int16 ddc2 = 0;
          int16 ddr2 = 0;

          if (col == rxCount)
          {
            ddc2 = 2*(*deltaUncorrPtr - *(deltaUncorrPtr - 1));
          }
          else if (col > 2)
          {
            ddc2 = *deltaUncorrPtr + *(deltaUncorrPtr - 1) - *(deltaUncorrPtr + 1) - *(deltaUncorrPtr - 2);
          }
          else if (col == 2)
          {
            ddc2 = *deltaUncorrPtr + *(deltaUncorrPtr - 1) - 2*(*(deltaUncorrPtr + 1));
          }
          ddc = (ddc2 > ddc) ? ddc2 : ddc;


          if (col == 1)
          {
            ddc2 = 2*(*deltaUncorrPtr - *(deltaUncorrPtr + 1));
          }
          else if (col < rxCount - 1)
          {
            ddc2 = *deltaUncorrPtr + *(deltaUncorrPtr + 1) - *(deltaUncorrPtr - 1) - *(deltaUncorrPtr + 2);
          }
          else if (col == rxCount - 1)
          {
            ddc2 = *deltaUncorrPtr + *(deltaUncorrPtr + 1) - 2*(*(deltaUncorrPtr - 1));
          }
          ddc = (ddc2 > ddc) ? ddc2 : ddc;


          if (row == txCount)
          {
            ddr2 = 2*(*deltaUncorrPtr - *(deltaUncorrPtr - (MAX_RX+1)));
          }
          else if (row > 2)
          {
            ddr2 = *deltaUncorrPtr + *(deltaUncorrPtr - (MAX_RX+1)) - *(deltaUncorrPtr + (MAX_RX+1)) - *(deltaUncorrPtr - 2*(MAX_RX+1));
          }
          else if (row == 2)
          {
            ddr2 = *deltaUncorrPtr + *(deltaUncorrPtr - (MAX_RX+1)) - 2*(*(deltaUncorrPtr + (MAX_RX+1)));
          }
          ddr = (ddr2 > ddr) ? ddr2 : ddr;


          if (row == 1)
          {
            ddr2 = 2*(*deltaUncorrPtr - *(deltaUncorrPtr + (MAX_RX+1)));
          }
          else if (row < txCount - 1)
          {
            ddr2 = *deltaUncorrPtr + *(deltaUncorrPtr + (MAX_RX+1)) - *(deltaUncorrPtr - (MAX_RX+1)) - *(deltaUncorrPtr + 2*(MAX_RX+1));
          }
          else if (row == txCount - 1)
          {
            ddr2 = *deltaUncorrPtr + *(deltaUncorrPtr + (MAX_RX+1)) - 2*(*(deltaUncorrPtr - (MAX_RX+1)));
          }
          ddr = (ddr2 > ddr) ? ddr2 : ddr;


          ds2 = (uint32)ddc * ddr;
        }
        if (ds2 > SDPThreshold && ds2 > peakDs2)
        {
          peakIdx = i;
          peakDs2 = ds2;
        }
      }
    }
  }

  // remove DC and linear slopes from around +- 2 electrodes around pen peak
  if (peakDs2 > 0)
  {
    uint16 newOffset = sortedPeaks.peakList[peakIdx].offset;
    uint16 peakRow = newOffset / (MAX_RX+1);
    uint16 peakCol = newOffset % (MAX_RX+1);
    uint16 row, col;
    uint16 txFirst;

    int16 startRow = (int16)peakRow - 3;
    int16 endRow = (int16)peakRow + 3;
    int16 startCol = (int16)peakCol - 3;
    int16 endCol = (int16)peakCol + 3;

    startRow = (startRow < 1) ? 1 : startRow;
    startCol = (startCol < 1) ? 1 : startCol;
    endRow = (endRow > (int16)txCount) ? (int16)txCount : endRow;
    endCol = (endCol > (int16)rxCount) ? (int16)rxCount : endCol;

    {
      int16 dr = 0;
      int16 dc = 0;
      if (startRow == (int16)peakRow-3)
      {
        row = startRow;
        for (col = (uint16)startCol; col <= (uint16)endCol-1; col++)
        {
          int16 tmpdc = deltaImageUncorr[(MAX_RX+1)*row + col] - deltaImageUncorr[(MAX_RX+1)*row + col + 1];
          tmpdc = (tmpdc < 0) ? -tmpdc : tmpdc;
          dc = (tmpdc > dc) ? tmpdc : dc;
        }
      }
      if (endRow == (int16)peakRow+3)
      {
        row = endRow;
        for (col = (uint16)startCol; col <= (uint16)endCol-1; col++)
        {
          int16 tmpdc = deltaImageUncorr[(MAX_RX+1)*row + col] - deltaImageUncorr[(MAX_RX+1)*row + col + 1];
          tmpdc = (tmpdc < 0) ? -tmpdc : tmpdc;
          dc = (tmpdc > dc) ? tmpdc : dc;
        }
      }
      if (startCol == (int16)peakCol-3)
      {
        col = startCol;
        for (row = (uint16)startRow; row <= (uint16)endRow-1; row++)
        {
          int16 tmpdr = deltaImageUncorr[(MAX_RX+1)*row + col] - deltaImageUncorr[(MAX_RX+1)*row + col + 1];
          tmpdr = (tmpdr < 0) ? -tmpdr : tmpdr;
          dr = (tmpdr > dr) ? tmpdr : dr;
        }
      }
      if (endCol == (int16)peakCol+3)
      {
        col = startCol;
        for (row = (uint16)startRow; row <= (uint16)endRow-1; row++)
        {
          int16 tmpdr = deltaImageUncorr[(MAX_RX+1)*row + col] - deltaImageUncorr[(MAX_RX+1)*row + col + 1];
          tmpdr = (tmpdr < 0) ? -tmpdr : tmpdr;
          dr = (tmpdr > dr) ? tmpdr : dr;
        }
      }

      txFirst = (dr >= dc);
    }

    if (txFirst)
    {
      for (row = (uint16)startRow; row <= (uint16)endRow; row++)
      {
        int16 dcOffset ;
        int16 slopeTimes6 = 0;

        if (peakCol > 3)
        {
          dcOffset = deltaImageUncorr[(MAX_RX+1)*row + peakCol - 3];
          if (peakCol < (MAX_RX+1) - 3)
          {
            slopeTimes6 = deltaImageUncorr[(MAX_RX+1)*row + peakCol + 3] - deltaImageUncorr[(MAX_RX+1)*row + peakCol - 3];
          }
        }
        else
        {
          dcOffset = deltaImageUncorr[(MAX_RX+1)*row + peakCol + 3];
        }

        if (startCol == (int16)peakCol - 3)
        {
          startCol++;
        }
        if (endCol == (int16)peakCol + 3)
        {
          endCol--;
        }
        for (col = (uint16)startCol; col <= (uint16)endCol; col++)
        {
          int16 correctionFactor = slopeTimes6*((int16)col - (int16)peakCol + 3);
          int16 correctionSign = (correctionFactor < 0) ? -1 : 1;
          correctionFactor *= correctionSign;
          correctionFactor += 3;
          correctionFactor /= 6;
          deltaImageUncorr[(MAX_RX+1)*row + col] -= correctionSign*correctionFactor + dcOffset;
        }
      }

      // increment/decrement start/end values so only
      // correcting +-2 electrodes from peak
      if (startRow == (int16)peakRow - 3)
      {
        startRow++;
      }
      if (endRow == (int16)peakRow + 3)
      {
        endRow--;
      }
      for (col = (uint16)startCol; col <= (uint16)endCol; col++)
      {
        int16 dcOffset ;
        int16 slopeTimes6 = 0;

        if (peakRow > 3)
        {
          dcOffset = deltaImageUncorr[(MAX_RX+1)*(peakRow - 3) + col];
          if (peakRow < (MAX_TX+1) - 3)
          {
            slopeTimes6 = deltaImageUncorr[(MAX_RX+1)*(peakRow + 3) + col] - deltaImageUncorr[(MAX_RX+1)*(peakRow - 3) + col];
          }
        }
        else
        {
          dcOffset = deltaImageUncorr[(MAX_RX+1)*(peakRow + 3) + col];
        }

        for (row = (uint16)startRow; row <= (uint16)endRow; row++)
        {
          int16 correctionFactor = slopeTimes6*((int16)row - (int16)peakRow + 3);
          int16 correctionSign = (correctionFactor < 0) ? -1 : 1;
          correctionFactor *= correctionSign;
          correctionFactor += 3;
          correctionFactor /= 6;
          deltaImageUncorr[(MAX_RX+1)*row + col] -= correctionSign*correctionFactor + dcOffset;
        }
      }
    }
    else
    {
      for (col = (uint16)startCol; col <= (uint16)endCol; col++)
      {
        int16 dcOffset ;
        int16 slopeTimes6 = 0;

        if (peakRow > 3)
        {
          dcOffset = deltaImageUncorr[(MAX_RX+1)*(peakRow - 3) + col];
          if (peakRow < (MAX_TX+1) - 3)
          {
            slopeTimes6 = deltaImageUncorr[(MAX_RX+1)*(peakRow + 3) + col] - deltaImageUncorr[(MAX_RX+1)*(peakRow - 3) + col];
          }
        }
        else
        {
          dcOffset = deltaImageUncorr[(MAX_RX+1)*(peakRow + 3) + col];
        }

        if (startRow == (int16)peakRow - 3)
        {
          startRow++;
        }
        if (endRow == (int16)peakRow + 3)
        {
          endRow--;
        }
        for (row = (uint16)startRow; row <= (uint16)endRow; row++)
        {
          int16 correctionFactor = slopeTimes6*((int16)row - (int16)peakRow + 3);
          int16 correctionSign = (correctionFactor < 0) ? -1 : 1;
          correctionFactor *= correctionSign;
          correctionFactor += 3;
          correctionFactor /= 6;
          deltaImageUncorr[(MAX_RX+1)*row + col] -= correctionSign*correctionFactor + dcOffset;
        }
      }

      // increment/decrement start/end values so only
      // correcting +-2 electrodes from peak
      if (startCol == (int16)peakCol - 3)
      {
        startCol++;
      }
      if (endCol == (int16)peakCol + 3)
      {
        endCol--;
      }
      for (row = (uint16)startRow; row <= (uint16)endRow; row++)
      {
        int16 dcOffset ;
        int16 slopeTimes6 = 0;

        if (peakCol > 3)
        {
          dcOffset = deltaImageUncorr[(MAX_RX+1)*row + peakCol - 3];
          if (peakCol < (MAX_RX+1) - 3)
          {
            slopeTimes6 = deltaImageUncorr[(MAX_RX+1)*row + peakCol + 3] - deltaImageUncorr[(MAX_RX+1)*row + peakCol - 3];
          }
        }
        else
        {
          dcOffset = deltaImageUncorr[(MAX_RX+1)*row + peakCol + 3];
        }

        for (col = (uint16)startCol; col <= (uint16)endCol; col++)
        {
          int16 correctionFactor = slopeTimes6*((int16)col - (int16)peakCol + 3);
          int16 correctionSign = (correctionFactor < 0) ? -1 : 1;
          correctionFactor *= correctionSign;
          correctionFactor += 3;
          correctionFactor /= 6;
          deltaImageUncorr[(MAX_RX+1)*row + col] -= correctionSign*correctionFactor + dcOffset;
        }
      }
    }

    // Abort correction is corrected peak is greater than pen ceiling or non-positive
    if (deltaImageUncorr[(MAX_RX+1)*peakRow + peakCol] > penCeiling_LSB || deltaImageUncorr[(MAX_RX+1)*peakRow + peakCol] <= 0)
    {
      return;
    }

    // Conditionally apply correction
    {
      int16 newBorderSum = sumBorder(deltaImageUncorr, startRow, endRow, startCol, endCol);
      int16 origBorderSum = sumBorder(deltaImage, startRow, endRow, startCol, endCol);
      if (newBorderSum < 0) newBorderSum = -newBorderSum;
      if (origBorderSum < 0) origBorderSum = -origBorderSum;

      if (2 * newBorderSum >= 3 * origBorderSum || origBorderSum == 0)
      {
        // Abort correction
        return;
      }
      else if (2 * newBorderSum >= origBorderSum)
      {
        // Blend
        int8p8 blendFrac = 384 - (int8p8) (((int32) newBorderSum << 8) / origBorderSum);  // 1.5 - new / orig
        int8p8 cBlendFrac = 256 - blendFrac;
        for (row = (uint16)startRow; row <= (uint16)endRow; row++)
        {
          deltaPtr = deltaImage + (MAX_RX+1)*row + startCol;
          deltaUncorrPtr = deltaImageUncorr + (MAX_RX+1)*row + startCol;
          for (col = (uint16)startCol; col <= (uint16)endCol; col++)
          {
            *deltaPtr = (int16) (((int24p8) cBlendFrac * *deltaPtr + (int24p8) blendFrac * *deltaUncorrPtr++) >> 8);
            // FIXME: Save a 32-bit add with this optimization?
            // *deltaPtr = (int16) (((int24p8) cBlendFrac * *deltaPtr) >> 8);
            // *deltaPtr += (int16) (((int24p8) blendFrac * *deltaUncorrPtr++) >> 8);
            deltaPtr++;
          }
        }
      }
      else
      {
        // Full correction
        for (row = (uint16)startRow; row <= (uint16)endRow; row++)
        {
          deltaPtr = deltaImage + (MAX_RX+1)*row + startCol;
          deltaUncorrPtr = deltaImageUncorr + (MAX_RX+1)*row + startCol;
          memcpy16(deltaPtr, deltaUncorrPtr, endCol - startCol + 1);
        }
      }
    }
  }
}
#endif // CONFIG_HAS_SMALL_OBJECT_DETECTOR
