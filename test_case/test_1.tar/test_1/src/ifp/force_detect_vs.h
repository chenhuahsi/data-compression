#ifndef _FORCE_DETECT_VS_H_
#define _FORCE_DETECT_VS_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: baseline_checker.h
// Description: Interface for baseline checker
// $Id: baseline_checker.h,v 1.6.44.1 2012/10/25 00:18:31 mposadas Exp $
#include    <stdio.h>
FILE* outputLog;
FILE* outputAfterShadowRemove;
FILE* deltaImageFile;

void initFilePointers()
{
    outputLog = fopen("log.csv", "w+");
    outputAfterShadowRemove = fopen("image_after_shadow.csv", "w+");
    deltaImageFile = fopen("original_image.csv", "w+");
}

void logImage(FILE* fp, img_t *dImage)
{
    int row, col;

    for (col = 0; col< dImage->height; col++)
    {
        for (row = 0; row < dImage->width; row++)
        {
            float* value = getValueFromDeltaImage(dImage, col, row);
            fprintf(fp, "%f,", *value);
        }
        fprintf(fp, "\n");
    }
    fprintf(fp, "\n");
}

#endif  //_FORCE_DETECT_VS_H_
