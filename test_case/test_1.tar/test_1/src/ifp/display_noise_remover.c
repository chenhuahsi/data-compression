// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: display_noise_remover.c
// Description:
//
// $Id:$

#include "ifp_common.h"

#if CONFIG_HAS_DISPLAY_NOISE_REMOVER

#include "ifp_vector_util.h"
#include "display_noise_remover.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

/* =================================================================
   MODULE TYPES
==================================================================*/
typedef struct
{
  int16 rxQuantile_idx;
  int16 pxQuantile_idx;
  uint8p8 weights[MAX_RX];
  uint8p8 invWeights[MAX_RX];
} dnrConfig_t; // keep this in sync with displayNoiseRemoverConfig_t in ifp_common.h

/* =================================================================
   LOCAL VARIABLES
==================================================================*/
static dnrConfig_t dnrConfig;

/* =================================================================
   INTERNAL FUNCTION DECLARATIONS
==================================================================*/
static void swap(int16 *x, int A, int B);
static int nthSortedEntry16(int16 *x, int start, int end, int n);

/* =================================================================
   INTERNAL FUNCTION DEFINITIONS
==================================================================*/
static void swap(int16 *x, int A, int B)
{
  int tmp = x[A];
  x[A] = x[B];
  x[B] = tmp;
}

static int nthSortedEntry16(int16 *x, int start, int end, int n)
{
  int lPtr = start;
  int rPtr = end;
  while (lPtr < rPtr)
  {
    int xPivot = x[n];
    int i = lPtr;
    int j = rPtr;
    while (n < j && i < n)
    {
      while(x[i] < xPivot)
      {
        i++;
      }
      while(xPivot < x[j])
      {
        j--;
      }
      swap(x, i, j);
      i++;
      j--;
    }

    if (i < n)
    {
      lPtr = i;
    }
    if (n < j)
    {
      rPtr = j;
    }
    while(i <= end && x[i] == xPivot)
    {
      i++;
    }
    while(j >= start && x[j] == xPivot)
    {
      j--;
    }
    if (i > n && j < n)
    {
      break;
    }
  }
  return x[n];
}

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: displayNoiseRemover_configure()
Purpose: Configure the Display Noise Remover module.
Inputs: sensorParams - sensor params struct ptr
        extConfig - displayNoiseRemoverConfig_t struct ptr
Outputs: None.
Effects: None.
Notes: Configure the percentile index and the weights
Example: None.
----------------------------------------------------------------- */
void displayNoiseRemover_configure(sensorParams_t *sensorParams, displayNoiseRemoverConfig_t *extConfig)
{
  int i;
  uint8p8 *extConfigWeightsPtr, *dnrWeightsPtr, *dnrInvWeightsPtr;

  dnrConfig.rxQuantile_idx = sensorParams->rxCount/2;
  dnrConfig.pxQuantile_idx = sensorParams->rxCount*sensorParams->txCount/2;

  dnrWeightsPtr = dnrConfig.weights;
  extConfigWeightsPtr = extConfig->weights;
  for (i = 0; i < MAX_RX; i++)
  {
    *dnrWeightsPtr++ = *extConfigWeightsPtr++; // 0p8 since range [0 , 1]
  }

  dnrInvWeightsPtr = dnrConfig.invWeights;
  dnrWeightsPtr = dnrConfig.weights;
  for (i = 0; i < MAX_RX; i++)
  {
    if (*dnrWeightsPtr == 0)
    {
      *dnrInvWeightsPtr = 65535;
    }
    else
    {
      *dnrInvWeightsPtr = 65536 / *dnrWeightsPtr; // 8p8
    }
    dnrInvWeightsPtr++;
    dnrWeightsPtr++;
  }
}

/* -----------------------------------------------------------------
Name: displayNoiseRemover_remove()
Purpose: Apply the Display Noise Remover to the delta image
Inputs: sensorParams - sensor params struct ptr
        inhibitGlobalMedian - flag disabling global median correction
        deltaImage - deltaImage as int16 array
Outputs:
Effects: Modifies in place the deltaImage by removing display noise
Notes: Currently does nothing.
Example: None.
----------------------------------------------------------------- */
void displayNoiseRemover_remove(sensorParams_t *sensorParams, uint16 inhibitGlobalMedian, int16 *deltaImage)
{
  int i;
  int j;
  int ROWS;
  int COLS;
  uint16 rowSkip;
  uint16 rowSize;
  int16 displayNoiseOffsets[MAX_TX];

  ROWS = sensorParams->txCount;
  COLS = sensorParams->rxCount;
  rowSize = MAX_RX + 1;
  rowSkip = rowSize - COLS;

  displayNoiseOffsets[0] = 0;

  // computed median of weighted differences
  {
    int16 weightedRowDifferences[2*MAX_RX];
    int16 *weightedRowDifferencesPtr;
    uint8p8 *invWeightsPtr;

    weightedRowDifferencesPtr = weightedRowDifferences;//FIXME: This can be optimized
    invWeightsPtr = dnrConfig.invWeights;
    for (i = 0; i < MAX_RX; i++)
    {
      *(weightedRowDifferencesPtr + MAX_RX) = (int16) *invWeightsPtr;
      weightedRowDifferencesPtr++;
      invWeightsPtr++;
    }

    {
      int16 *deltaImagePtr = deltaImage + rowSize + 1;
      int16 *displayNoiseOffsetsPtr = displayNoiseOffsets + 1;
      for (i = 1; i < ROWS; i++)
      {
        weightedRowDifferencesPtr = weightedRowDifferences;
        for (j = 0; j < COLS; j++)
        {
          int32 weightedRowDifference = (int32) (*(deltaImagePtr + rowSize) - (*deltaImagePtr)) * (*(weightedRowDifferencesPtr + MAX_RX)); // s15p0 * 8p8 -> s23p8
          if (weightedRowDifference > 0)
          {
            weightedRowDifference = (weightedRowDifference > 8388479) ? 8388479 : weightedRowDifference; // clip so (x + 128) >> 8 is at most 2^15-1, 8388479 = 8388608 - 129
          }
          else
          {
            weightedRowDifference = (weightedRowDifference > -8388608) ? weightedRowDifference : -8388608; // clip  so (x + 128) >> 8 is at least -2^15
          }
          *weightedRowDifferencesPtr++ = (int16) ((weightedRowDifference + 128) >> 8); // s23p8 -> s15p0
          deltaImagePtr++;
        }
        *displayNoiseOffsetsPtr = nthSortedEntry16(weightedRowDifferences, 0, COLS-1, dnrConfig.rxQuantile_idx);
        if (!(COLS%2))
        {
          // average center two pixels when array length is even
          int32 displayNoiseOffsets32 = (int32) *displayNoiseOffsetsPtr;
          displayNoiseOffsets32 += nthSortedEntry16(weightedRowDifferences, 0, COLS-1, dnrConfig.rxQuantile_idx+1);
          *displayNoiseOffsetsPtr = (int16) ((displayNoiseOffsets32 + 1) >> 1);
        }
        displayNoiseOffsetsPtr++;
        deltaImagePtr += rowSkip;
      }
    }
  }

  // cumsum offsets
  {
    int16 *displayNoiseOffsetsPtr = displayNoiseOffsets + 2; // first entry 0 so cumsum starts from third
    for (i = 2; i < ROWS; i++)
    {
      *displayNoiseOffsetsPtr += *(displayNoiseOffsetsPtr - 1);
      displayNoiseOffsetsPtr++;
    }
  }

  // subtract mean
  {
    int16 meanNoiseOffsets;
    int16 *displayNoiseOffsetsPtr = displayNoiseOffsets;

    meanNoiseOffsets = calculateMean(displayNoiseOffsetsPtr, ROWS);

    for (i = 0; i < ROWS; i++)
    {
      *displayNoiseOffsetsPtr++ -= meanNoiseOffsets;
    }
  }

  // subtract weighted offsets
  {
    uint8p8 *weightsPtr;
    int16 weightedOffsets[MAX_RX];
    int16 *weightedOffsetsPtr;

    int16 *deltaImagePtr = deltaImage + rowSize + 1;
    int16 *displayNoiseOffsetsPtr = displayNoiseOffsets;
    for (i = 0; i < ROWS; i++)
    {
      weightedOffsetsPtr = weightedOffsets;
      weightsPtr = dnrConfig.weights;
      for (j = 0; j < COLS; j++)
      {
        *weightedOffsetsPtr++ = *weightsPtr++;
      }
      weightedOffsetsPtr = weightedOffsets;
      for (j = 0; j < COLS; j++)
      {
        *weightedOffsetsPtr = (int16)(((int32) (*weightedOffsetsPtr) * (*displayNoiseOffsetsPtr) + 128) >> 8); // 0p8 * s15p0 -> s15p0
        weightedOffsetsPtr++;
      }

      weightedOffsetsPtr = weightedOffsets;
      for (j = 0; j < COLS; j++)
      {
        int16 delta = *deltaImagePtr - *weightedOffsetsPtr;
        uint16 deltaClipped = (*deltaImagePtr == 32767 || *deltaImagePtr == -32768);
        if (!deltaClipped) // clipping treated as sticky
        {
          if (*deltaImagePtr >= *weightedOffsetsPtr++)
          {
            *deltaImagePtr = (delta < 0) ? 32767 : delta; // clip high
          }
          else
          {
            *deltaImagePtr = (delta < 0) ? delta : -32768; // clip low
          }
        }
        deltaImagePtr++;
      }
      displayNoiseOffsetsPtr++;
      deltaImagePtr += rowSkip;
    }
  }

  // computed median of image
  if (!inhibitGlobalMedian)
  {
    int16 weightedImage[MAX_TX*MAX_RX];
    int16 *weightedImagePtr;
    int16 *deltaImagePtr;
    uint8p8 *invWeightsPtr;
    uint8p8 *weightsPtr;
    int16 noiseOffset;

    weightedImagePtr = weightedImage;
    for (i = 0; i < ROWS; i++)
    {
      invWeightsPtr = dnrConfig.invWeights;
      for (j = 0; j < COLS; j++)
      {
        *weightedImagePtr = (int16) *invWeightsPtr;
        weightedImagePtr++;
        invWeightsPtr++;
      }
    }

    weightedImagePtr = weightedImage;
    deltaImagePtr = deltaImage + rowSize + 1;
    for (i = 0; i < ROWS; i++)
    {
      for (j = 0; j < COLS; j++)
      {
        int32 weightedImagePxl;
        weightedImagePxl = (int32) (*weightedImagePtr) * (*deltaImagePtr); // s15p0 * 8p8 -> s23p8
        if (weightedImagePxl > 0)
        {
          weightedImagePxl = (weightedImagePxl > 8388479) ? 8388479 : weightedImagePxl; // clip so (x + 128) >> 8 is at most 2^15-1, 8388479 = 8388608 - 129
        }
        else
        {
          weightedImagePxl = (weightedImagePxl > -8388608) ? weightedImagePxl : -8388608; // clip  so (x + 128) >> 8 is at least -2^15
        }
        *weightedImagePtr = (int16) ((weightedImagePxl + 128) >> 8); // s23p8 -> s15p0
        weightedImagePtr++;
        deltaImagePtr++;
      }
      deltaImagePtr += rowSkip;
    }
    noiseOffset = nthSortedEntry16(weightedImage, 0, ROWS*COLS-1, dnrConfig.pxQuantile_idx);
    if (!((ROWS*COLS)%2))
    {
      // average center two pixels when array length is even
      int32 noiseOffset32 = (int32) noiseOffset;
      noiseOffset32 += nthSortedEntry16(weightedImage, 0, ROWS*COLS-1, dnrConfig.pxQuantile_idx+1);
      noiseOffset = (int16) ((noiseOffset32 + 1) >> 1);
    }

    {
      int16 *deltaImagePtr = deltaImage + rowSize + 1;
      for (i = 0; i < ROWS; i++)
      {
        weightsPtr = dnrConfig.weights;
        for (j = 0; j < COLS; j++)
        {
          int16 weightedOffset = (int16) (((int32) (*weightsPtr) * noiseOffset + 128) >> 8); // s15p0 * 8p8 -> s23p8 -> s15p0
          int16 delta = *deltaImagePtr - weightedOffset;
          uint16 deltaClipped = (*deltaImagePtr == 32767 || *deltaImagePtr == -32768);
          if (!deltaClipped) // clipping treated as sticky
          {
            if (*deltaImagePtr >= weightedOffset)
            {
              *deltaImagePtr = (delta < 0) ? 32767 : delta; // clip high
            }
            else
            {
              *deltaImagePtr = (delta < 0) ? delta : -32768; // clip low
            }
          }
          weightsPtr++;
          deltaImagePtr++;
        }
        deltaImagePtr += rowSkip;
      }
    }
  }
}

#endif // CONFIG_HAS_DISPLAY_NOISE_REMOVER
