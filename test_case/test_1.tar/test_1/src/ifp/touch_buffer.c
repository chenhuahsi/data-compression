/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 904-1100

   Filename: touch_buffer.c
   Description: The Touch Buffer stores touch reports and delays their
                output to the host. This allows for filtering before
                reporting.
----------------------------------------------------------------- */

#include "ifp_common.h"
#include "ifp_string.h"
#include "touch_buffer.h"
#include "position_reporter.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

#define MAX_DEQUEUE_INDEX (TOUCH_BUFFER_SIZE / 2)
#define ENQUEUE_INDEX 0
#define DURATION_THRESHOLD MAX_DEQUEUE_INDEX //_DS_TODO: used to be 3
#define REFRACTORY_PERIOD 10
#define DRUMMING_DISTANCE 16 //_DS_TODO: What unit is this?
#define TOUCH_BUFFER_SIZE 7 //As defined in typical build config

#if MAX_OBJECTS > 10
  #define N_TOUCHES_PER_FRAME 10
#else
  #define N_TOUCHES_PER_FRAME MAX_OBJECTS
#endif

//Although these are declared as variables, they should be set only
//once by the configuration step and then never changed. Thus they
//should be thought of more as constants.
static uint16 swapAxesFlag; //_DS_TODO: Refactor this. Any config params should go into the config struct.
static int24p8 xScale;
static int8p8 xOffset;
static int16 xMax;
static int24p8 yScale;
static int8p8 yOffset;
static int16 yMax;
static uint16 origin;

/* =================================================================
   MODULE TYPES
==================================================================*/

/* =================================================================
   MODULE VARIABLES
==================================================================*/

//BASIC FUNCTIONALITY VARIABLES
static bufferedReport_t reports[TOUCH_BUFFER_SIZE][N_TOUCHES_PER_FRAME];
static uint16 freshDataFlags[TOUCH_BUFFER_SIZE];
static uint16 objectsPresentFlags[TOUCH_BUFFER_SIZE]; //_DS_TODO: Added. Uses 7 more works of RAM. These can probably be packed into bit flags.
//_DS_TODO: Should I be tracking objectsPresent flags too? I see no reason
// why they should be treated differently than freshdata.

static int16 dequeueIndex;
static bufferedReport_t workingReport[N_TOUCHES_PER_FRAME];
static bufferedReport_t previousReport[N_TOUCHES_PER_FRAME];
static uint16 touchBufferHistory[N_TOUCHES_PER_FRAME];
static uint16 currentReportCorrected;
static uint16 previousReportCorrected;

//TESTING VARIABLES
static uint16 forceFreshReport;
static uint16 debugFrameCount; //_DS_TODO: Debug variable.

/* ================================================================= %_DS_TODO: Re-arrange function declarations into their correct spot.
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

/* ================================================================= //_DS_TODO: Bah. All functions are written as non-static functions.
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/*----------------------------------------------------------------
Name    : touchBuffer_shiftBuffer
Purpose : shift the contents of the touch buffer from the front
          to the back of the buffer
Inputs  : None
Outputs : None
Effects : Shifts the contents of the touch and data flags
          buffers from the front to the back of the buffers
Notes   : None
Example : None
----------------------------------------------------------------*/
static void touchBuffer_shiftBuffer();

/*----------------------------------------------------------------
Name    : touchBuffer_enqueueTouches()
Purpose : Adds touches from IFP to the touch buffer
Inputs  : IFP touch report
Outputs : None
Effects : Adds touches from IFP to the touch buffer. Adds the
          fresh data flag to the fresh data flags buffer.
Notes   : None
Example : None
----------------------------------------------------------------*/
static void touchBuffer_enqueueTouches(reportData_t *report);

/*----------------------------------------------------------------
Name    : touchBuffer_applyTemporalScreening()
Purpose : Corrects some of the ill effects of noise
Inputs  : The touch report about to be sent out to the IFP from
          the buffer.
Outputs : The filtered version of the input report
Effects : Removes some ghost fingers by preventing new fingers from
          arriving on receivers with fingers already on them.
          Replaces dropped fingers
          Averages positions to reduce jitter.
Notes   : None
Example : None
----------------------------------------------------------------*/
static void touchBuffer_applyTemporalScreening(bufferedReport_t *result, int16 durationThreshold, int16 touchBufferSize);

/*----------------------------------------------------------------
Name    : touchBuffer_applyPositionFilter
Purpose : Reduce jitter and position jumps under noise
Inputs  : The touch report about to be sent out to the IFP from
          the buffer.
Outputs : The input report with the positions filtered
Effects : Dampens position movements by averaginp the positions in
          the buffer after the extremes have been removed.
Notes   : None
Example : None
----------------------------------------------------------------*/
static void touchBuffer_applyPositionFilter(bufferedReport_t *result);

/*----------------------------------------------------------------
Name    : touchBuffer_fillInDroppedFingers
Purpose : Replace fingers which have been temporarily lost due
          to noise
Inputs  : The touch report about to be sent out to the IFP from
          the buffer.
Outputs : The input report with the dropped fingers replaced
Effects : Adds in fingers which are not present in the current
          frame which reappear in the buffer nearer to the
          enqueue index
Notes   : None
Example : None
----------------------------------------------------------------*/
static void touchBuffer_fillInDroppedFingers(bufferedReport_t *bufferedReport);

/*----------------------------------------------------------------
Name    : touchBuffer_getFullReport
Purpose : Decompress a buffered report into a full touch report
Inputs  : The buffered report to be decompressed
Outputs : The uncompressed IFP report generated from the input report
Effects : None
Notes   : None
Example : None
----------------------------------------------------------------*/
static void touchBuffer_getFullReport(bufferedReport_t *bufferedReport, reportData_t *report);

/*----------------------------------------------------------------
Name    : touchBuffer_getDequeueIndex
Purpose : Returns the current dequeue index
Inputs  : None
Outputs : The current dequeue index
Effects : None
Notes   : Dequeue index changes with noise state
Example : None
----------------------------------------------------------------*/
static int16 touchBuffer_getDequeueIndex();

/*----------------------------------------------------------------
Name    : touchBuffer_getReport
Purpose : Returns a pointer to the requested buffered report
Inputs  : Buffer (frame) index and finger index
Outputs : A pointer to the specified buffered report
Effects : None
Notes   : None
Example : None
----------------------------------------------------------------*/
static bufferedReport_t *touchBuffer_getReport(int16 bufferIdx, int16 touchIdx);

static uint16 touchBuffer_getDistance(bufferedReport_t *touch0, bufferedReport_t *touch1);

static uint16 touchBuffer_sqrt(uint16 x);

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name   : touchBuffer_init()
Purpose: Initializes the touch buffer
Inputs : none
Outputs: none
Effects: Resets internal state of touch buffer, as at
         power-on.
Notes  : This function must be called before using the touch
         buffer module.
Example: none
----------------------------------------------------------- */
void touchBuffer_init(void)
{
  dequeueIndex = ENQUEUE_INDEX;
  memset16(reports[0], 0, TOUCH_BUFFER_SIZE * N_TOUCHES_PER_FRAME * sizeof(reports[0][0]) / sizeof(uint16));
  memset16(freshDataFlags, 0, TOUCH_BUFFER_SIZE);
  memset16(objectsPresentFlags, 0, TOUCH_BUFFER_SIZE);
  memset16(previousReport, 0, N_TOUCHES_PER_FRAME * sizeof(*previousReport) / sizeof(uint16));
  debugFrameCount = 0;
}

/* -----------------------------------------------------------
Name: touchBuffer_reinit()
Purpose: Reinitializes the touch buffer
Inputs: none
Outputs: none
Effects: Resets internal state of touch buffer, as at a
         host rezero.
Notes: This function must be called if the host sends a rezero
       command.
Example: none
----------------------------------------------------------- */
void touchBuffer_reinit(void)
{
  touchBuffer_init();
}

/* -----------------------------------------------------------
Name   : touchBuffer_configure()
Purpose: Set host-defined parameters
Inputs : none
Outputs: none
Effects: Resets internal state of touch buffer, as at a host rezero.
Notes  : This function must be called if the host sends a rezero
         command.
Example: none
----------------------------------------------------------- */
void touchBuffer_configure(sensorParams_t *sensorParams, //_DS_TODO: This is interesting. It seems touchBuffer has no specific knobs, just internal variables that need to be calculated based on other modules' knobs.
                           coordConvConfig_t *coordConvConfig, //_DS_TODO: How to handle? Do we need tbConfig? touchBufParams?
                           uint16 forceFreshReportFlag)
{
  uint8p8 xPitch_mm;
  uint8p8 yPitch_mm;
  uint16 xPixels;
  uint16 yPixels;
  uint16 xClipHigh, yClipHigh;
  int8p8 xBLCorner_px;
  int8p8 xTRCorner_px;
  int8p8 yBLCorner_px;
  int8p8 yTRCorner_px;

  forceFreshReport = forceFreshReportFlag;

  switch(coordConvConfig->txAxis)
  {
    default:
    case axisName_xAxis:
      swapAxesFlag = TRUE;
      xPitch_mm    = sensorParams->txPitch_mm;
      xPixels      = sensorParams->txCount;
      yPitch_mm    = sensorParams->rxPitch_mm;
      yPixels      = sensorParams->rxCount;
      xBLCorner_px = coordConvConfig->txClipLow;
      yBLCorner_px = coordConvConfig->rxClipLow;
      xClipHigh = coordConvConfig->txClipHigh;
      yClipHigh = coordConvConfig->rxClipHigh;
      break;
    case axisName_yAxis:
      swapAxesFlag = FALSE;
      xPitch_mm = sensorParams->rxPitch_mm;
      xPixels   = sensorParams->rxCount;
      yPitch_mm = sensorParams->txPitch_mm;
      yPixels   = sensorParams->txCount;
      xBLCorner_px = coordConvConfig->rxClipLow;
      yBLCorner_px = coordConvConfig->txClipLow;
      xClipHigh = coordConvConfig->rxClipHigh;
      yClipHigh = coordConvConfig->txClipHigh;
      break;
  }

  xTRCorner_px = (xPixels<<8) - xClipHigh;
  yTRCorner_px = (yPixels<<8) - yClipHigh;

  xOffset = xBLCorner_px;
  yOffset = yBLCorner_px;

  xScale = (((int32)coordConvConfig->xMax)<<16)/(xTRCorner_px - xBLCorner_px);
  yScale = (((int32)coordConvConfig->yMax)<<16)/(yTRCorner_px - yBLCorner_px);

  xMax = coordConvConfig->xMax;
  yMax = coordConvConfig->yMax;
  origin = coordConvConfig->origin;
}


/* -----------------------------------------------------------
Name   : touchBuffer_update()
Purpose: enqueues the given report
         returns the dequeue report
Inputs : src - the report to be copied
Outputs: dst - the report into which the src is copied
Effects: none
Notes  : none
Example: none
----------------------------------------------------------- */
void touchBuffer_update(reportData_t *report,
                        uint16 useHighNoiseState)
{
  bufferedReport_t *bufferedReport = &(workingReport[0]); // _DS_TODO: This is confusing, having two variable names for the same memory space.
  uint16 enablePositionFilter = 0;
  int16 maxDequeueIdx = MAX_DEQUEUE_INDEX;
  int16 touchBufferSize = TOUCH_BUFFER_SIZE;

  if(useHighNoiseState == touchBuffer_moisture)
  {
    maxDequeueIdx--;
    touchBufferSize -= 2;
  }

  touchBuffer_shiftBuffer(touchBufferSize);

  if (useHighNoiseState != touchBuffer_normal)
  {
    if(dequeueIndex < maxDequeueIdx)
    {
      dequeueIndex++;
    }
    else
    {
      enablePositionFilter = 1;
    }
  }
  else
  {
    dequeueIndex = ENQUEUE_INDEX;
  }

  touchBuffer_enqueueTouches(report);

  memcpy16(bufferedReport, &reports[dequeueIndex], N_TOUCHES_PER_FRAME * sizeof(bufferedReport[0]) / sizeof(uint16));

  if (useHighNoiseState != touchBuffer_normal)
  {
    touchBuffer_applyTemporalScreening(bufferedReport, DURATION_THRESHOLD, touchBufferSize);
    touchBuffer_fillInDroppedFingers(bufferedReport);
    if (enablePositionFilter)
    {
      touchBuffer_applyPositionFilter(bufferedReport);
    }
    touchBuffer_getFullReport(bufferedReport, report);
  }

  memcpy16(previousReport, bufferedReport, N_TOUCHES_PER_FRAME * sizeof(bufferedReport[0]) / sizeof(uint16));
  debugFrameCount++; //_DS_TODO: 0-based frame counter
}

/* -----------------------------------------------------------
Name   : touchBuffer_getFullReport
Purpose: uncompresses the buffered report into a full touch report
Inputs : bufferedReport - the buffered report to be expanded
         report         - the full report to be filled in
Outputs: none
Effects: none
Notes  : none
Example: none
----------------------------------------------------------- */
void touchBuffer_getFullReport(bufferedReport_t *bufferedReport,
                               reportData_t *report)
{
  int16 i;
  uint16 nTouchesThisFrame;
  uint16 nTouchesPreviousFrame;

  for(i = 0; i < N_TOUCHES_PER_FRAME; i++)
  {
    if (bufferedReport[i].classification != hostClassification_none)
    {
      int8p8 x;
      int8p8 y;
      int16 xDst;
      int16 yDst;

      if (swapAxesFlag == FALSE)
      {
        x = bufferedReport[i].rxPos;
        y = bufferedReport[i].txPos;
      }
      else
      {
        x = bufferedReport[i].txPos;
        y = bufferedReport[i].rxPos;
      }

      xDst = (int16)((((int32)(x - xOffset))*xScale + 0x8000L) / 0x10000L); //_DS_TODO: This math comes out wrong.
      xDst = (xDst < 0 ? 0 : xDst);
      xDst = (xDst > xMax ? xMax : xDst);
      yDst = (int16)((((int32)(y - yOffset))*yScale + 0x8000L) / 0x10000L);
      yDst = (yDst < 0 ? 0 : yDst);
      yDst = (yDst > yMax ? yMax : yDst);

      (report->pos)[i].classification = bufferedReport[i].classification;
      if(origin == 0x04) //top right
      {
        (report->pos)[i].xMeas = xDst;
        (report->pos)[i].yMeas = yMax - yDst;
      }
      else if(origin == 0x02) // bottom left
      {
        (report->pos)[i].xMeas = xMax - xDst;
        (report->pos)[i].yMeas = yDst;
      }
      else if(origin == 0x01) // bottom right
      {
        (report->pos)[i].xMeas = xDst;
        (report->pos)[i].yMeas = yDst;
      }
      else //top left and default
      {
        (report->pos)[i].xMeas = xMax - xDst;
        (report->pos)[i].yMeas = yMax - yDst;
      }
      (report->pos)[i].xWidth         = bufferedReport[i].xWidth;
      (report->pos)[i].yWidth         = bufferedReport[i].yWidth;
      (report->pos)[i].txPos          = bufferedReport[i].txPos;
      (report->pos)[i].rxPos          = bufferedReport[i].rxPos;
      (report->pos)[i].z              = bufferedReport[i].z;
    }
    else
    {
      memset16(&report->pos[i], 0, sizeof(report->pos[0]) / sizeof(uint16));
    }
  }
  memset16(&report->pos[N_TOUCHES_PER_FRAME], 0, (MAX_OBJECTS - N_TOUCHES_PER_FRAME) * sizeof(report->pos[0]) / sizeof(uint16));

//_DS_TODO: Why do we want to set fresh data based on previous frame?
//_DS_TODO: I re-wrote this section to make it clearer. Review to make sure I didn't make a logic mistake.
// _DS_TODO: This first section can be improved. No need to count all of them, we just want a bool.
  nTouchesThisFrame = 0;
  nTouchesPreviousFrame = 0;
  for (i = 0; i < N_TOUCHES_PER_FRAME; i++)
  {
    if (bufferedReport[i].z > 0)  //_DS_TODO: Should this check for z value? Or classifications != none?
    {
      nTouchesThisFrame++;
    }
    if (previousReport[i].z > 0)
    {
      nTouchesPreviousFrame++;
    }
  }

  // If previous or current reports had fresh data, and fingers were seen, set this report's freshData.
  // forceFD || ( (lastFD || currFD) && (nTLast>0 || nTCurr>0) )
  if (forceFreshReport == 1 ||
      ((freshDataFlags[dequeueIndex+1] == 1 ||
        freshDataFlags[dequeueIndex] == 1) &&
        (nTouchesThisFrame > 0 ||
        nTouchesPreviousFrame > 0 || previousReportCorrected || currentReportCorrected)))
  {
    report->freshData = 1;
  }
  else
  {
    report->freshData = 0;
  }

  // Set objectsPresent based on associated report. Override if fingers are definitely seen.
  //report->objectsPresent = objectsPresentFlags[dequeueIndex];
  if(nTouchesThisFrame > 0)
    report->objectsPresent = 1;
  else
    report->objectsPresent = 0;


  //_DS_TODO: This logic seems wrong. Shouldn't forceFreshReport always set the freshData flag, rather than prevent it from being disabled?
  // if((nTouchesThisFrame == 0) && (nTouchesPreviousFrame == 0) && (forceFreshReport == 0)){
  //   report->freshData = 0;
  // }


}

/* -----------------------------------------------------------
Name   : touchBuffer_applyTemporalScreening
Purpose: Remove any spurious touches, that are probably ghosts
Inputs : result - the filtered buffered report
Outputs: none
Effects: none
Notes  : none
Example: none
----------------------------------------------------------- */
void touchBuffer_applyTemporalScreening(bufferedReport_t *result, int16 durationThreshold, int16 touchBufferSize)
{
  int16  bufferIndex;
  int16  touchIndex;
  int16  duration[N_TOUCHES_PER_FRAME];
  int16  continuous[N_TOUCHES_PER_FRAME];
  int16  totalDurationCheck = 0;

  for (touchIndex = 0; touchIndex < N_TOUCHES_PER_FRAME; touchIndex++)
  {
    int16 totalDuration = 0;
    duration[touchIndex] = 0;
    continuous[touchIndex] = 0;
    for (bufferIndex = 0; bufferIndex < touchBufferSize; bufferIndex++)
    {
      bufferedReport_t *currentReport = touchBuffer_getReport(bufferIndex, touchIndex);
      if (bufferIndex == 0)
        touchBufferHistory[touchIndex] = (touchBufferHistory[touchIndex] << 1) | ((currentReport->z > 0) ? 1 : 0);
      if (currentReport->z > 0)
      {
        duration[touchIndex]++;
        totalDuration++;
        if((continuous[touchIndex] == 0) || (continuous[touchIndex] == 2))
          continuous[touchIndex]++;
      }
      else if (duration[touchIndex] < durationThreshold)
      {
        duration[touchIndex] = 0;
        if(continuous[touchIndex] == 1)
          continuous[touchIndex]++;
      }//touch z > 0
    }//for buffer index
    if (totalDuration != 0 && totalDuration != 5)
      totalDurationCheck++;
  }// for touch index
  previousReportCorrected = currentReportCorrected;
  currentReportCorrected = 0;
  for (touchIndex = 0; touchIndex < N_TOUCHES_PER_FRAME; touchIndex++)
  {
    if ((result[touchIndex].classification == hostClassification_none) || (result[touchIndex].z == 0))
    {
      // do nothing!
    }
    else if ((duration[touchIndex] < durationThreshold) && ((totalDurationCheck > 1) || (continuous[touchIndex] > 2) || (touchBufferHistory[touchIndex] & 0x7F)))
    {
      result[touchIndex].classification = hostClassification_none;
      result[touchIndex].z = 0;
      currentReportCorrected = 1; // fix dead finger report problem
    }
  }// for touch index
}//end mitigate noise

 /*****************************************************
  * FILL IN DROPPED TOUCHES
  // This function is dependent on the tracker filling
  //   in the finger indices properly. There is some
  //   help built in by the drumming check.
  ******************************************************/
void touchBuffer_fillInDroppedFingers(bufferedReport_t *result)
{
  int16 bufferIndex;
  int16 touchIndex;
  uint16 repeatFingers[N_TOUCHES_PER_FRAME];
  bufferedReport_t *currentReport;
  uint16 distance;

  for (touchIndex = 0; touchIndex < N_TOUCHES_PER_FRAME; touchIndex++)
  {
    repeatFingers[touchIndex] = 0;
    if (result[touchIndex].z == 0)
    {//is not a touch now
      if (previousReport[touchIndex].z > 0)
      { //was a touch last frame
        for(bufferIndex = 0; bufferIndex < touchBuffer_getDequeueIndex(); bufferIndex++)
        {
          currentReport = touchBuffer_getReport(bufferIndex, touchIndex);
          if (currentReport->z > 0)
          { // will be a touch again
            distance = touchBuffer_getDistance(&previousReport[touchIndex], &currentReport[0]);
            if (distance < DRUMMING_DISTANCE)
            {
              repeatFingers[touchIndex] = 1;
            }
          }
        }
      }
    }
  }
  for (touchIndex = 0; touchIndex < N_TOUCHES_PER_FRAME; touchIndex++)
  {
    if (repeatFingers[touchIndex] == 1)
    {
      result[touchIndex] = previousReport[touchIndex];
    }
  }
}


/*****************************************************
* AVERAGE PREVIOUS POSITIONS
******************************************************/
void touchBuffer_applyPositionFilter(bufferedReport_t *result)
{
  int16 bufferIndex;
  int16 touchIndex;
  bufferedReport_t *currentReport;

  uint16 i;
  int32 sum_y = 0;
  int32 sum_x = 0 ;
  int16 n_points;

  int32 rxPos;
  int32 txPos;

  int16 fillTxPosPrev;
  int16 fillRxPosPrev;
  int16 fillTxPosNext;
  int16 fillRxPosNext;
  uint16 loopMax;

  //These are the weights  from a gaussian kernel function
  //{16, 14, 9, 5, 2}
  //The w used below are solved for using a locally weighted
  //linear regression for x(t) and y(t) with the weights
  //derived from the ones given above.
  int16 w[5] = {13, 12, 8, 4, 2};

  bufferIndex = touchBuffer_getDequeueIndex();
  switch(bufferIndex)
  {
    case 1:
      n_points = w[0] + (w[1]*2);
      break;
    case 2:
      n_points = w[0] + (w[1]*2) + (w[2]*2);
      break;
    case 3:
      n_points = w[0] + (w[1]*2) + (w[2]*2) + (w[3]*2);
      break;
    default:
      n_points = w[0] + (w[1]*2) + (w[2]*2) + (w[3]*2) + (w[4]*2);
      break;
  }
  loopMax = (uint16)(touchBuffer_getDequeueIndex());
  if (loopMax >= sizeof(w) / sizeof(int16))
  {
    loopMax = sizeof(w) / sizeof(int16) - 1;
  }

  for (touchIndex = 0; touchIndex < N_TOUCHES_PER_FRAME; touchIndex++)
  {
    if (result[touchIndex].z > 0 && result[touchIndex].classification == hostClassification_finger)
    { //_DS_TODO: Why check for both conditions here? What's special about each condition?

      bufferIndex = touchBuffer_getDequeueIndex();
      currentReport = touchBuffer_getReport(bufferIndex, touchIndex);
      sum_y = (int32)(result[touchIndex].txPos);
      sum_y = w[0] * sum_y;
      sum_x = (int32)(result[touchIndex].rxPos);
      sum_x = w[0] * sum_x;

      fillTxPosPrev = fillTxPosNext = result[touchIndex].txPos;
      fillRxPosPrev = fillRxPosNext = result[touchIndex].rxPos;

      for(i = 1; i <= loopMax; i++)
      {
        bufferIndex = touchBuffer_getDequeueIndex() + i;
        currentReport = touchBuffer_getReport(bufferIndex, touchIndex);

        if (currentReport->z > 0 &&
            currentReport->classification == hostClassification_finger)
        {
          fillRxPosPrev = rxPos = (int32)(currentReport->rxPos);
          fillTxPosPrev = txPos = (int32)(currentReport->txPos);
        }
        else
        {
          rxPos = (int32)(fillRxPosPrev);
          txPos = (int32)(fillTxPosPrev);
        }//end if is finger

        sum_x    += w[i] * rxPos;
        sum_y    += w[i] * txPos;

        bufferIndex = touchBuffer_getDequeueIndex() - i;
        currentReport = touchBuffer_getReport(bufferIndex, touchIndex);
        if (currentReport->z > 0 &&
            currentReport->classification == hostClassification_finger)
        {
          fillRxPosNext = rxPos = (int32)(currentReport->rxPos);
          fillTxPosNext = txPos = (int32)(currentReport->txPos);
        }
        else
        {
          rxPos = (int32)(fillRxPosNext);
          txPos = (int32)(fillTxPosNext);
        }// end if is finger

        sum_x += w[i] * rxPos;
        sum_y += w[i] * txPos;
      }//end for buffer index < dequeue index
      result[touchIndex].rxPos = (int16)(sum_x / n_points);
      result[touchIndex].txPos = (int16)(sum_y / n_points);
    }//end if z > 0
  }//end for touchIndex
}

/* -----------------------------------------------------------
Name:    touchBuffer_shiftBuffer()
Purpose: shift the contents of the touch buffer from the
         beginning (index 0) to the end.
Inputs:  none
Outputs: none
Effects: none
Notes:   none
Example: none
----------------------------------------------------------- */
void touchBuffer_shiftBuffer(int16 touchBufferSize)
{
  int16 bufferIndex;

  for (bufferIndex = (touchBufferSize-1); bufferIndex > 0; bufferIndex--)
  {
    memcpy16(reports[bufferIndex], reports[bufferIndex-1], N_TOUCHES_PER_FRAME * sizeof(reports[0][0]) / sizeof(uint16));
    freshDataFlags[bufferIndex] = freshDataFlags[bufferIndex-1];
    objectsPresentFlags[bufferIndex] = objectsPresentFlags[bufferIndex-1];
  }
}



/* -----------------------------------------------------------
Name   : touchBuffer_getReport()
Purpose: returns the address of the requested touch report
Inputs : buffer index - the frame number of the requested report
         touch index  - the index of the touch object requested
Outputs: address of the touch object requested
Effects: none
Notes  : none
Example: none
----------------------------------------------------------- */
bufferedReport_t* touchBuffer_getReport(int16 bufferIdx, int16 touchIdx)
{
  return &(reports[bufferIdx][touchIdx]);
}

/* -----------------------------------------------------------
Name   : touchBuffer_getDequeueIndex()
Purpose: returns the dequeue index
Inputs : none
Outputs: the dequeue index
Effects: none
Notes  : none
Example: none
----------------------------------------------------------- */
int16 touchBuffer_getDequeueIndex()
{
  return dequeueIndex;
}

/* -----------------------------------------------------------
Name:    touchBuffer_enqueueTouches
Purpose: copy a report from the calc. thread into the buffer
         Before the report is copied in, the touches are sorted
         to match what was in the previously enqueued frame
Inputs:  workingReport - the input report
Outputs: none
Effects: none
Notes:   none
Example: none
----------------------------------------------------------- */
void touchBuffer_enqueueTouches(reportData_t *report)
{
  int16 touchIndex;
  for (touchIndex = 0; touchIndex < N_TOUCHES_PER_FRAME; touchIndex++)
  {
    workingReport[touchIndex].classification = (report->pos)[touchIndex].classification;
    workingReport[touchIndex].xWidth         = (report->pos)[touchIndex].xWidth;
    workingReport[touchIndex].yWidth         = (report->pos)[touchIndex].yWidth;
    workingReport[touchIndex].txPos          = (report->pos)[touchIndex].txPos;
    workingReport[touchIndex].rxPos          = (report->pos)[touchIndex].rxPos;
    workingReport[touchIndex].z              = (report->pos)[touchIndex].z;
  }

  memcpy16(reports[ENQUEUE_INDEX], workingReport, N_TOUCHES_PER_FRAME * sizeof(workingReport[0]) / sizeof(uint16));
  freshDataFlags[ENQUEUE_INDEX] = report->freshData;
  objectsPresentFlags[ENQUEUE_INDEX] = report->objectsPresent;
}

/* -----------------------------------------------------------
Name:    touchBuffer_getDistance
Purpose: Computes the euclidean distane between two touches
Inputs:  touch0 - first touch
         touch1 - second touch
Outputs: the distance (uint16) from touch0 to touch1
Effects: none
Notes:   none
Example: none
----------------------------------------------------------- */
uint16 touchBuffer_getDistance(bufferedReport_t *touch0, bufferedReport_t *touch1)
{
  uint16 distance;
  int16 tx0;
  int16 tx1;
  int16 rx0;
  int16 rx1;
  uint32 sum;

  if (touch0->classification != hostClassification_none && touch1->classification != hostClassification_none)
  {
    distance = 0;
    tx0 = (int16)(touch0->txPos); //this is 8.8 format but the upper 8 bits are bound by 0-32 so 5.8
    tx1 = (int16)(touch1->txPos);
    rx0 = (int16)(touch0->rxPos);
    rx1 = (int16)(touch1->rxPos);

    sum  = (uint32)(tx0-tx1)*(tx0-tx1); //10.16
    sum += (uint32)(rx0-rx1)*(rx0-rx1); //11.16

    sum >>= 12; //12.4
    distance = (uint16)(sum);

    distance = touchBuffer_sqrt(distance); //6.2
  }
  else
  {
    distance = (32767 >> 1); //_DS_TODO: What is special about uint12p4 = 16383? 1023.9375
  }
  return distance;
}

/* -----------------------------------------------------------
Name:    touchBuffer_sqrt
Purpose: Computes the square root
Inputs:  x - the square of the result
Outputs: the square root of x
Effects: none
Notes:   none
Example: none
----------------------------------------------------------- */
uint16 touchBuffer_sqrt(uint16 x)
{
  uint16 result;
  uint16 bit;

  result = 0;
  bit = (1 << 14);

  while (bit > x)
  {
    bit >>= 2;
  }
  while (bit != 0)
  {
    if (x >= result + bit)
    {
      x -= (result + bit);
      result = (result >> 1) + bit;
    }
    else
    {
      result >>= 1;
    }
    bit >>= 2;
  }
  return result;
}

uint16 touchBuffer_getSwapAxisFlag()
{
  return swapAxesFlag;
}
