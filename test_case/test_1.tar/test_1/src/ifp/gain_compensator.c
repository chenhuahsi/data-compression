// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: gain_compensator.c
// Description: Adjusts gain on specific portions of the image to
//              compensate for insensitive pixels or variation over
//              a sensor

#include "ifp_common.h"
#include "gain_compensator.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/
#define NO_GAIN       0x00
#define ROW_GAIN      0x01
#define COL_GAIN      0x02
#define ROW_COL_GAIN  0x03  // not being used, maybe should be removed
#define EDGE_GAIN     0x04
#define CORNER_GAIN   0x08

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static gainCompParams_t mGCParams;

/* =================================================================
   MODULE STATIC FUNCTION DECLARATIONS
==================================================================*/
static ATTR_INLINE void compensateArray(int16 *img, uint4p12 gain, uint16 numCorrections, uint16 stride);

/* =================================================================
   MODULE STATIC FUNCTION DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Purpose: Apply gain to part or all of an array
Inputs: pointer to start of array, gain to apply, how many pixels to compensate, and stride between pixels
Outputs: None.
Effects: Updates array in-place.
----------------------------------------------------------------- */
static ATTR_INLINE void compensateArray(int16 *img, uint4p12 gain, uint16 numCorrections, uint16 stride)
{
  uint16 i;
  for (i = 0; i < numCorrections; i++, img += stride)
  {
    *img = (int16) (((int32) *img * gain + 2048) >> 12);
  }
}

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: gainCompensator_configure()
Purpose: Configure the Gain Compensator module.
Inputs: mode - Mode for the gain, comprising of bitfields associated
               with different gain types.
               bit 1 (0x1) - Apply gain to rows
               bit 2 (0x2) - Apply gain to columns
               bit 3 (0x4) - Apply gain to edges
               bit 4 (0x8) - Apply gain to corners
        rowGain - Pointer to array of row gain values in Q8.8 format
        colGain - Pointer to array of column gain values in Q8.8 format
        edgeGains - Pointer to array of edge gain values in Q4.12 format; the order is left, right, top, bottom (RX0, RXn-1, TX0, TXn-1)
        cornerGains - Pointer to array of corner gain values in Q4.12 format; the order is clockwise from the upper left: upper left, upper right, lower right, lower left
Outputs: Status
Effects: None.
Example: None.
----------------------------------------------------------------- */
void gainCompensator_configure(gainCompParams_t *gcParams)
{
  mGCParams = *gcParams;
}

/* -----------------------------------------------------------------
Name: gainCompensator_compensateGain
Purpose: Apply gain to Raw Image
Inputs: sensor params, delta image - delta image to apply gain to based on gain mode.
Outputs: None.
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void gainCompensator_compensateGain(sensorParams_t *sensorParams, int16 *deltaImage)
{
  uint16 rowColResult;
  uint16 edgeResult;
  uint16 cornerResult;
  int16 cornerVals[4];
  uint16 cornerOffsets[] = {
    (MAX_RX + 1) + 1,  // upper-left
    (MAX_RX + 1) + sensorParams->rxCount,  // upper-right
    sensorParams->txCount * (MAX_RX + 1) + sensorParams->rxCount,  // lower-right
    sensorParams->txCount * (MAX_RX + 1) + 1  // lower-left
  };

  if (NO_GAIN == mGCParams.mode)
  {
    return;
  }

  rowColResult = mGCParams.mode & (ROW_GAIN | COL_GAIN);
  edgeResult = mGCParams.mode & EDGE_GAIN;
  cornerResult = mGCParams.mode & CORNER_GAIN;

  // save the corner values so that we can restore them if we
  // overwrite them in row/col or edge compensation modes
  if (cornerResult)
  {
    uint16 i;
    for (i = 0; i < 4; i++)
      {
      cornerVals[i] = deltaImage[(uint16) cornerOffsets[i]];
    }
  }

  switch(rowColResult)
  {
    case ROW_GAIN:
    {
      uint16 row;
      uint8p8 *rowGain = mGCParams.rowGain;
      int16 *deltaPtr = deltaImage + MAX_RX + 2;  // skip zero-padding
      for (row = 0; row < sensorParams->txCount; row++, deltaPtr += MAX_RX + 1)
      {
        uint4p12 gain = (uint4p12) (*rowGain++ << 4);
        compensateArray(deltaPtr, gain, sensorParams->rxCount, 1);
      }
      break;
    }
    case COL_GAIN:
    {
      uint16 col;
      uint8p8 *colGain = mGCParams.colGain;
      int16 *deltaPtr = deltaImage + MAX_RX + 2;  // skip zero-padding
      for (col = 0; col < sensorParams->rxCount; col++, deltaPtr++)
      {
        uint4p12 gain = (uint4p12) (*colGain++ << 4);
        compensateArray(deltaPtr, gain, sensorParams->txCount, MAX_RX + 1);
      }
      break;
    }
    case (ROW_GAIN | COL_GAIN):
    {
      int16 *deltaPtr = deltaImage + MAX_RX + 2;  // skip zero-padding
      uint16 rowSkip = MAX_RX - sensorParams->rxCount + 1;

      uint16 row, col;
      uint8p8 *rowGainPtr = mGCParams.rowGain;
      for (row = 0; row < sensorParams->txCount; row++, deltaPtr += rowSkip)
      {
        uint8p8 rowGain = *rowGainPtr++;
        uint8p8 *colGainPtr = mGCParams.colGain;
        for (col = 0; col < sensorParams->rxCount; col++)
        {
          uint8p8 colGain = *colGainPtr++;
          uint4p12 gain = (uint8p8) ((((uint24p8) rowGain * colGain) + 8) >> 4);  // outer product of row and col gains
          compensateArray(deltaPtr++, gain, 1, 1);
        }
      }
      break;
    }
  }

  if (edgeResult)
  {
    compensateArray(deltaImage + cornerOffsets[0], mGCParams.edgeGain[0], sensorParams->txCount, MAX_RX + 1);  // left col
    compensateArray(deltaImage + cornerOffsets[1], mGCParams.edgeGain[1], sensorParams->txCount, MAX_RX + 1);  // right col
    compensateArray(deltaImage + cornerOffsets[0], mGCParams.edgeGain[2], sensorParams->rxCount, 1);  // top row
    compensateArray(deltaImage + cornerOffsets[3], mGCParams.edgeGain[3], sensorParams->rxCount, 1);  // bottom row
  }

  // Apply corner gains on original (saved) corner values.
  if (cornerResult)
  {
    uint16 i;
    for (i = 0; i < 4; i++)
      {
      deltaImage[cornerOffsets[i]] = (((int32) cornerVals[i] * mGCParams.cornerGain[i] + 2048) >> 12);
    }
  }
}
