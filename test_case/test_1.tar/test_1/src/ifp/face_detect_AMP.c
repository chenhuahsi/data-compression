/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: Removes blobs that are likely to be noise. This should
                be considered a temporary fix while we work around
                problems in the tracker design
   $Id: face_detect.cpp,v 1.1.4.4.14.2 2013/11/13 22:43:05 swilliam Exp $
----------------------------------------------------------------- */

/* =================================================================
   MODULE INCLUDES
==================================================================*/
#include "ifp_common.h"
#include "face_detect.h"
#include "calc2.h"

/* =================================================================
   MODULE VARIABLES
==================================================================*/
uint16 face_detected;
int16 face_detect_baseline[14][15];
uint16 raw_image_copy[MAX_RX*MAX_TX];
uint16 face_detect_image[14][15];
int16 face_detect_delta[14][15];
int16 face_detect_transpose[15][14];
int16 face_detect_row_sum[15];
int16 face_detect_threerow_sum[5];
uint16 FaceDetectInitBaselineCaptured;
int16 FACE_DETECT_3ROW_SUM_DETECT_THRESHOLD;
int16 FACE_DETECT_3ROW_SUM_REMOVAL_THRESHOLD;
#define FACE_DETECT_3ROW_SUM_DETECT_THRESHOLD_VAL 60
#define FACE_DETECT_3ROW_SUM_REMOVAL_THRESHOLD_VAL 40
#define FACE_DETECT_REMOVE_CTR_THRSH 5
int16 FACE_DETECT_LPWG_3ROW_SUM_DETECT_THRESHOLD;
int16 FACE_DETECT_LPWG_3ROW_SUM_REMOVAL_THRESHOLD;
#define FACE_DETECT_LPWG_3ROW_SUM_DETECT_THRESHOLD_VAL -250
#define FACE_DETECT_LPWG_3ROW_SUM_REMOVAL_THRESHOLD_VAL -300
uint16 face_detected_3rows[5];
int16 face_detected_rows_sum;
int16 face_detected_rows_average;
uint16 face_detected_before_LPWG;

//LPWG
uint16 FaceDetectLPWGInitBaselineCaptured;
int16 face_detect_LPWG_baseline[14][15];
int16 face_detect_LPWG_delta[14][15];
int16 face_detect_LPWG_transpose[15][14];
int16 face_detect_LPWG_row_sum[15];
int16 face_detect_LPWG_threerow_sum[5];
uint16 FaceDetect_LPWG_entryDelayCounter;
uint16 FaceDetect_LPWG_logic_entered;

// sensor params
static uint16 txCount;
static uint16 rxCount;
static uint16 sideCount;
static uint16 topCount;
static uint16 bottomCount;

#if CONFIG_HAS_FACE_DETECT
/* -----------------------------------------------------------------
Name: faceDetect_configure()
Purpose: Configure the internal variables
Inputs:  None.
Outputs: None.
Effects: None.
Notes:   None.
Example: None.
----------------------------------------------------------------- */
void faceDetect_configure(faceDetectConfig_t *faceDetectConfig ATTR_UNUSED)
{
  txCount     = faceDetectConfig->txCount;
  rxCount     = faceDetectConfig->rxCount;
  sideCount   = 2;
  topCount    = 2;
  bottomCount = 13;
}

/* -----------------------------------------------------------------
Name: faceDetect_init()
Purpose: Initialize the noise peak filter variable, as at
         ASIC power-on.
Inputs:  None.
Outputs: None.
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void faceDetect_init(void)
{
    uint16 index_i;

    FACE_DETECT_3ROW_SUM_DETECT_THRESHOLD = FACE_DETECT_3ROW_SUM_DETECT_THRESHOLD_VAL;
    FACE_DETECT_3ROW_SUM_REMOVAL_THRESHOLD = FACE_DETECT_3ROW_SUM_REMOVAL_THRESHOLD_VAL;
    FACE_DETECT_LPWG_3ROW_SUM_DETECT_THRESHOLD = FACE_DETECT_LPWG_3ROW_SUM_DETECT_THRESHOLD_VAL;
    FACE_DETECT_LPWG_3ROW_SUM_REMOVAL_THRESHOLD = FACE_DETECT_LPWG_3ROW_SUM_REMOVAL_THRESHOLD_VAL;
    for (index_i=0; index_i<5; index_i++)
    {
       face_detected_3rows[index_i] = 0;
    }
    face_detected_before_LPWG = 0;
}

/* -----------------------------------------------------------------
Name: faceDetect_reinit()
Purpose: Re-initialize the noise peak filter variable at rezero command
Inputs:  None.
Outputs: None.
Effects: None.
Notes:   None.
Example: None.
----------------------------------------------------------------- */
void faceDetect_reinit()
{
  faceDetect_init();
}
#endif

void storeFaceDetectBaseline(uint16* rawProfileRX)
{
      uint16 index_i;
      uint16* tmp_profileIndex;
      uint16 index_it, index_ir;

      // Create a local copy of the image frame
      tmp_profileIndex = rawProfileRX;
      for (index_i=0; index_i<MAX_RX*MAX_TX; index_i++)
      {
          raw_image_copy[index_i] = (uint16)*tmp_profileIndex;
          tmp_profileIndex++;
      }

      // Store the row values from raw image data from the tixels in the face detect window
      for (index_it=sideCount; index_it<txCount-sideCount; index_it++)
      {
          for (index_ir=topCount; index_ir<rxCount-bottomCount; index_ir++)
          {
             face_detect_baseline[index_it-sideCount][index_ir-topCount] = (int16)raw_image_copy[(index_it*MAX_RX)+index_ir];
          }
      }
}

void storeFaceDetectLPWGBaseline(uint16* rawProfileRX)
{
      uint16 index_i;
      uint16* tmp_profileIndex;
      uint16 index_it, index_ir;

      // Create a local copy of the image frame
      tmp_profileIndex = rawProfileRX;
      for (index_i=0; index_i<MAX_RX*MAX_TX; index_i++)
      {
          raw_image_copy[index_i] = (uint16)*tmp_profileIndex;
          tmp_profileIndex++;
      }

      // Store the row values from raw image data from the tixels in the face detect window
      for (index_it=sideCount; index_it<txCount-sideCount; index_it++)
      {
          for (index_ir=topCount; index_ir<rxCount-bottomCount; index_ir++)
          {
             face_detect_LPWG_baseline[index_it-sideCount][index_ir-topCount] = (int16)raw_image_copy[(index_it*MAX_RX)+index_ir];
          }
      }
}

void computeFaceDetectDeltaImage(uint16* rawProfileRX)
{
      uint16 index_i;
      uint16* tmp_profileIndex;
      uint16 index_it, index_ir;

      // Create a local copy of the image frame
      tmp_profileIndex = rawProfileRX;
      for (index_i=0; index_i<MAX_RX*MAX_TX; index_i++)
      {
          raw_image_copy[index_i] = (uint16)*tmp_profileIndex;
          tmp_profileIndex++;
      }

      // Store the row values from raw image data from the tixels in the face detect window
      for (index_it=sideCount; index_it<txCount-sideCount; index_it++)
      {
          for (index_ir=topCount; index_ir<rxCount-bottomCount; index_ir++)
          {
              face_detect_image[index_it-sideCount][index_ir-topCount] = raw_image_copy[(index_it*MAX_RX)+index_ir];
          }
      }

      //Compute the delta from the baseline
      for (index_it=0; index_it<txCount-sideCount*2; index_it++)
      {
          for (index_ir=0; index_ir<rxCount-topCount-bottomCount; index_ir++)
          {
              face_detect_delta[index_ir][index_it] = (int16)face_detect_image[index_it][index_ir] - face_detect_baseline[index_it][index_ir];
          }
      }
}

void computeFaceDetectLPWGDeltaImage(uint16* rawProfileRX)
{
      uint16 index_i;
      uint16* tmp_profileIndex;
      uint16 index_it, index_ir;

      // Create a local copy of the image frame
      tmp_profileIndex = rawProfileRX;
      for (index_i=0; index_i<MAX_RX*MAX_TX; index_i++)
      {
          raw_image_copy[index_i] = (uint16)*tmp_profileIndex;
          tmp_profileIndex++;
      }

      // Store the row values from raw image data from the tixels in the face detect window
      for (index_it=sideCount; index_it<txCount-sideCount; index_it++)
      {
          for (index_ir=topCount; index_ir<txCount-bottomCount; index_ir++)
          {
              face_detect_image[index_it-sideCount][index_ir-topCount] = raw_image_copy[(index_it*MAX_RX)+index_ir];
          }
      }

      //Compute the delta from the baseline
      for (index_it=0; index_it<txCount-sideCount*2; index_it++)
      {
          for (index_ir=0; index_ir<rxCount-topCount-bottomCount; index_ir++)
          {
              face_detect_LPWG_delta[index_ir][index_it] = (int16)face_detect_image[index_it][index_ir] - face_detect_baseline[index_it][index_ir];
          }
      }
}

#if CONFIG_HAS_FACE_DETECT
uint16 new_face_detected, new_face_removed;
uint16 dummy_newfaceremoved;
uint16 new_face_detected_three_row_cntr;
uint16 new_face_removed_three_row_cntr;
int16 removal_thrsh_after_detectction;

uint16 isFaceDetected(uint16* rawProfileRX)
{

  uint16 index_it, index_ir, index_i;
  static uint16 new_face_removed_counter;


  dummy_newfaceremoved = 0;

  // Capture Bsaelines
  if (COMM_getFaceDetectEnable() == 1)
  {
    if (COMM_getPsmState() == 6)
    {
      if (FaceDetectLPWGInitBaselineCaptured != 1)
      {
        // Capture LPWG baseline
        storeFaceDetectLPWGBaseline(rawProfileRX);
        FaceDetectLPWGInitBaselineCaptured = 1;
        FaceDetect_LPWG_entryDelayCounter = 0;
        FaceDetect_LPWG_logic_entered = 0;
      }
    }
    else
    {
      if (FaceDetectInitBaselineCaptured != 1)
      {
        //Capture Display ON baseline
        storeFaceDetectBaseline(rawProfileRX);
        FaceDetectInitBaselineCaptured = 1;
        FaceDetect_LPWG_entryDelayCounter = 0;
        FaceDetect_LPWG_logic_entered = 0;
      }
    }
  }
  else
  {
      // Face detect is not enabled. Clear the parameters.
      for (index_i=0; index_i<5; index_i++)
      {
        face_detected_3rows[index_i] = 0;
      }
      face_detected = 0;
      FaceDetect_LPWG_entryDelayCounter = 0;
      FaceDetect_LPWG_logic_entered = 0;
  }

  if (FaceDetectInitBaselineCaptured == 1)
  {
    if ((COMM_getPsmState() == 6) && (FaceDetectLPWGInitBaselineCaptured == 1))
    {
      // ******** LPWG mode ***********
      if (FaceDetect_LPWG_entryDelayCounter > 100)
      {
        FaceDetect_LPWG_logic_entered = 1;
        computeFaceDetectLPWGDeltaImage(rawProfileRX);
        // Take the transpose
        for (index_it=0; index_it<14; index_it++)
        {
          for (index_ir=0; index_ir<15; index_ir++)
          {
            face_detect_LPWG_transpose[index_ir][index_it] = face_detect_LPWG_delta[index_it][index_ir];
          }
        }

        // Compute the sum of the rows
        // First, clear the sum matrix
        for (index_ir=0; index_ir<15; index_ir++)
        {
          face_detect_LPWG_row_sum[index_ir] = 0;
        }
        // then, compute the sum
        for (index_ir=0; index_ir<15; index_ir++)
        {
          for (index_it=0; index_it<14; index_it++)
          {
             face_detect_LPWG_row_sum[index_ir] += face_detect_LPWG_transpose[index_ir][index_it];
          }
        }

        // take the sum of 3 row's sums
        // First, clear the sum matrix
        for (index_ir=0; index_ir<5; index_ir++)
        {
          face_detect_LPWG_threerow_sum[index_ir] = 0;
        }
        // then, compute the sum
        for (index_ir=0; index_ir<5; index_ir++)
        {
          face_detect_LPWG_threerow_sum[index_ir] = face_detect_LPWG_row_sum[index_ir*3];
          face_detect_LPWG_threerow_sum[index_ir] += face_detect_LPWG_row_sum[(index_ir*3)+1];
          face_detect_LPWG_threerow_sum[index_ir] += face_detect_LPWG_row_sum[(index_ir*3)+2];
        }

        //face detection
        // Check if there are enough rows where the face signal is detected
        new_face_detected = 0; // initialize the flag
        new_face_detected_three_row_cntr = 0; // initialize counter
        for (index_ir=0; index_ir<=4; index_ir++)
        {
          if (face_detect_LPWG_threerow_sum[index_ir] > FACE_DETECT_LPWG_3ROW_SUM_DETECT_THRESHOLD)
          {
             new_face_detected_three_row_cntr ++;
          }
        }
        if (new_face_detected_three_row_cntr >=3)
        {
           new_face_detected = 1;
        }

        //face removal
        // Check if there are enough rows where the face removal is detected
        new_face_removed = 0; // initialize the flag
        new_face_removed_three_row_cntr = 0; // initialize counter

        removal_thrsh_after_detectction = 250;

        for (index_ir=0; index_ir<=4; index_ir++)
        {
          if ((face_detected_before_LPWG == 1) && (face_detect_LPWG_threerow_sum[index_ir] < -(removal_thrsh_after_detectction)))
          {
             new_face_removed_three_row_cntr ++;
          }
          else if ((face_detected_before_LPWG == 0) && (face_detect_LPWG_threerow_sum[index_ir] < FACE_DETECT_LPWG_3ROW_SUM_REMOVAL_THRESHOLD))
          {
             new_face_removed_three_row_cntr ++;
          }
        }
        if (new_face_removed_three_row_cntr >=3)
        {
           new_face_removed = 1;
        }
      }
      else
      {
         FaceDetect_LPWG_entryDelayCounter++;
      }

    }
    else
    {
      // ********* Normal Display On mode ************
      computeFaceDetectDeltaImage(rawProfileRX);

      // Take the transpose
      for (index_it=0; index_it<14; index_it++)
      {
        for (index_ir=0; index_ir<15; index_ir++)
        {
          face_detect_transpose[index_ir][index_it] = face_detect_delta[index_it][index_ir];
        }
      }

      // Compute the sum of the rows
      // First, clear the sum matrix
      for (index_ir=0; index_ir<15; index_ir++)
      {
        face_detect_row_sum[index_ir] = 0;
      }
      // then, compute the sum
      for (index_ir=0; index_ir<15; index_ir++)
      {
        for (index_it=0; index_it<14; index_it++)
        {
         face_detect_row_sum[index_ir] += face_detect_transpose[index_ir][index_it];
        }
      }

      // take the sum of 3 row's sums
      // First, clear the sum matrix
      for (index_ir=0; index_ir<5; index_ir++)
      {
        face_detect_threerow_sum[index_ir] = 0;
      }
      // then, compute the sum
      for (index_ir=0; index_ir<5; index_ir++)
      {
        face_detect_threerow_sum[index_ir] = face_detect_row_sum[index_ir*3];
        face_detect_threerow_sum[index_ir] += face_detect_row_sum[(index_ir*3)+1];
        face_detect_threerow_sum[index_ir] += face_detect_row_sum[(index_ir*3)+2];
      }

      //face detection
      // Check if there are enough rows where the face signal is detected
      new_face_detected = 0; // initialize the flag
      new_face_detected_three_row_cntr = 0; // initialize counter
      for (index_ir=0; index_ir<=4; index_ir++)
      {
        if (face_detect_threerow_sum[index_ir] > FACE_DETECT_3ROW_SUM_DETECT_THRESHOLD)
        {
           new_face_detected_three_row_cntr ++;
           face_detected_3rows[index_ir] = 1;
        }
        else
        {
           face_detected_3rows[index_ir] = 0;
        }
      }
      if (new_face_detected_three_row_cntr >=3)
      {
         new_face_detected = 1;
         //Compute face detected rows average
         //First clear the detected rows sum and average
         face_detected_rows_sum = 0;
         face_detected_rows_average = 0;

         for (index_ir=0; index_ir<=4; index_ir++)
         {
           if (face_detected_3rows[index_ir] == 1)
           {
              face_detected_rows_sum += face_detect_threerow_sum[index_ir];
           }
         }
         face_detected_rows_average = face_detected_rows_sum / new_face_detected_three_row_cntr;
         face_detected_before_LPWG = 1;
      }

      //face removal
      // Check if there are enough rows where the face removal is detected
      new_face_removed = 0; // initialize the flag
      new_face_removed_three_row_cntr = 0; // initialize counter
      for (index_ir=0; index_ir<=4; index_ir++)
      {
        if (face_detect_threerow_sum[index_ir] < FACE_DETECT_3ROW_SUM_REMOVAL_THRESHOLD)
        {
           new_face_removed_three_row_cntr ++;
        }
      }
      if (new_face_removed_three_row_cntr >=3)
      {
         dummy_newfaceremoved = 1;
      }
    }

    if (face_detected)
    {
       //Check for face removal count down
       if (new_face_removed == 1 || dummy_newfaceremoved == 1)
       {
          new_face_removed_counter ++;
          if (new_face_removed_counter >= FACE_DETECT_REMOVE_CTR_THRSH)
          {
             face_detected = 0;
             new_face_removed_counter = FACE_DETECT_REMOVE_CTR_THRSH;
             face_detected_rows_sum = 0;
             face_detected_rows_average = 0;
             face_detected_before_LPWG = 0;
          }
       }
    }
    else
    {
      if (new_face_detected == 1)
      {
          face_detected = 1;
          new_face_removed_counter = 0;
      }
    }

  }

  #if 0 // crosshair for debugging
    if(face_detected)
    {
      *((volatile uint16 *)(0xE0EF)) |= 0x1; //DISP.CMR_STATUS = 1;//OTP/FLASH data is loading now.
      //*((volatile uint16 *)(0xE9B3)) |= 0xFF; //DISP.NVMLD = 0xFF;//The data loaded from OTP/FLASH is written to the display registers
      *((volatile uint16 *)(0xE330)) |= 0xFF; //DISP.CROSS_EN = 1;

      *((volatile uint16 *)(0xE331)) |= 0x00; //DISP.CROSS_HAIR_P2 = tempXMeas & 0xFF;          // [7:0]  X
      *((volatile uint16 *)(0xE332)) |= 0x01; //CROSS_HAIR_P3.v = (tempXMeas >> 8) & 0xFF; //(8 >> report.pos[0].xMeas) & 0xFF;  // [10:8] X
      *((volatile uint16 *)(0xE333)) |= 0x00; //DISP.CROSS_HAIR_P4 = tempYMeas & 0xFF;         // [7:0]  Y
      *((volatile uint16 *)(0xE334)) |= 0x0F; //CROSS_HAIR_P5.v = (tempYMeas >> 8) & 0xFF; //(8 >> report.pos[0].yMeas) & 0xFF;  // [10:8] Y


      *((volatile uint16 *)(0xE0EF)) = 0x0; //DISP.CMR_STATUS = 0;
      //*((volatile uint16 *)(0xE9B3)) = 0x0;//DISP.NVMLD = 0;
    }
    else
    {
      *((volatile uint16 *)(0xE0EF)) |= 0x1; //DISP.CMR_STATUS = 1;//OTP/FLASH data is loading now.
      //*((volatile uint16 *)(0xE9B3)) |= 0xFF; //DISP.NVMLD = 0xFF;
      *((volatile uint16 *)(0xE330)) &= 0x00; //CROSS_HAIR_P1.v = 0; // width[4:1], enable[0]
      *((volatile uint16 *)(0xE0EF)) = 0x0; //DISP.CMR_STATUS = 0;
      //*((volatile uint16 *)(0xE9B3)) = 0x0;//DISP.NVMLD = 0;
    }
  #endif

  return face_detected;
}
#endif

