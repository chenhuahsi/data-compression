// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2014  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100
//
// $Id$
// -----------------------------------------------------------------
//
//
// Filename: land_lift_jitter_filter.c
// Description:
//

#include "ifp_common.h"
#include "ifp_string.h"
#include "land_lift_jitter_filter.h"
#include "coordinate_converter.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/
#define LL_min(X, Y)  ((X) < (Y) ? (X) : (Y))
#define LL_max(X, Y)  ((X) > (Y) ? (X) : (Y))
#define LL_mul8p8(X, Y) ((int8p8) ((((int32) (X)) * (Y) + 128) >> 8))
#define LL_div8p8(X, Y) ((int8p8) ((((int32) (X)) << 8 ) / (Y)))

/* =================================================================
   MODULE TYPES
==================================================================*/
typedef struct
{
  sensorPosition_t pos;
  uint16 frameNumber:8;
  uint16 previouslyReported:1;
  uint16 previouslyBuffered:1;
  uint16 unlocked:1;
#if CONFIG_HAS_LL_LIFTING_LARGE_FINGER
  uint16 wasBig : 1;
  uint16 lastW;
  uint16 lastZ;
#endif
} lljfPosition_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static landLiftJitterFilterConfig_t lljfConfig;
static lljfPosition_t landLiftJitterFilterState[MAX_OBJECTS];

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/

static uint16 skipFilter(touchType_t touch_type);

#if CONFIG_HAS_W_LLJ_FILTER
static int16 correctByW_signed(uint16 w, int16 small, int16 big)
{
  if (!lljfConfig.wLLJ.Enable || w <= lljfConfig.wLLJ.LowerW)
  {
    return small;
  }
  if (lljfConfig.wLLJ.UpperW <= w)
  {
    return big;
  }
  return (((int32)(w - lljfConfig.wLLJ.LowerW)) * (big - small) / (int16)(lljfConfig.wLLJ.UpperW - lljfConfig.wLLJ.LowerW)) + small;
}
static uint16 correctByW_unsigned(uint16 w, uint16 small, uint16 big)
{
  return correctByW_signed(w, small, big);
}
#else
#define correctByW_signed(w, small, big) (small)
#define correctByW_unsigned(w, small, big) (small)
#endif

/* -----------------------------------------------------------------
Name: landLiftJitterFilter_init()
Purpose: Initialize the Land-Lift Jitter Filter module.
Inputs: None.
Outputs: None.
Effects: Resets internal state of the filter, as at power-on.
Notes: This function must be called before using the filter module.
Example: None.
----------------------------------------------------------------- */
void landLiftJitterFilter_init(void)
{
  memset16(landLiftJitterFilterState, 0, sizeof(landLiftJitterFilterState) / sizeof(uint16));
}

/* -----------------------------------------------------------------
Name: landLiftJitterFilter_reinit()
Purpose: Re-initialize the Land-Lift Jitter Filter module.
Inputs: None.
Outputs: None.
Effects: Resets internal state of jitter filter, as at a host rezero.
Notes: This function must be called if the host sends a rezero command.
Example: None.
----------------------------------------------------------------- */
void landLiftJitterFilter_reinit(void)
{
  landLiftJitterFilter_init();
}

/* -----------------------------------------------------------------
Name: landLiftJitterFilter_configure()
Purpose: Configure the Land-Lift Jitter Filter module.
Inputs: extConfig - landLiftJitterFilterConfig_t struct ptr
Outputs: None.
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void landLiftJitterFilter_configure(landLiftJitterFilterConfig_t *extConfig)
{
  lljfConfig = *extConfig;
  //lljfConfig.landLockReleaseFrames = LL_max(1, lljfConfig.landLockReleaseFrames); //optional bound checks ~10 words of ROM
  //lljfConfig.landLockFastFingerReleaseFrames = LL_max(1, lljfConfig.landLockFastFingerReleaseFrames);
}

/* -----------------------------------------------------------------
Name: landLiftJitterFilter_filterPositions()
Purpose: Apply the Land-Lift Jitter Filter to the position reporting
Inputs:
Outputs:
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void landLiftJitterFilter_filterPositions(sensorPosition_t *sensorPositions, classification_t *classifications, uint16 simpleMode)
{

  lljfPosition_t *lljfState = landLiftJitterFilterState;
  sensorPosition_t *pos = sensorPositions;
  classification_t *cla = classifications;

  int16 i;
  for (i = 0; i < MAX_OBJECTS; i++)
  {
    if (pos->z == 0 || cla->recoverTouchFlag || !cla->touchFlag) // clear the state & recover if necessary
    {
      #if CONFIG_HAS_W_LLJ_FILTER
      lljfConfig.wLLJ.w[i] = 0;
      #endif

      if (cla->recoverTouchFlag)
      {
        if (lljfState->previouslyBuffered && lljfState->pos.z != 0 && lljfState->pos.xWidth != 0 && lljfState->pos.yWidth != 0)
        {
          *pos = lljfState->pos; //recover
        }
        else
        {
          cla->touchFlag = 0; //recovery request for unbuffered/corrupted touch, something is wrong, set touchFlag to 0 just in case.
        }
      };
      memset16(lljfState, 0, sizeof(*lljfState) / sizeof(uint16)); //clear
    }
    else if (cla->bufferTouchFlag || !lljfState->previouslyReported || cla->newTouchFlag) //store current position
    {
      lljfState->previouslyBuffered = 0;
      lljfState->previouslyReported = 0;
      lljfState->unlocked = 0;
      if (cla->bufferTouchFlag)
      {
        lljfState->previouslyBuffered = 1;
      }
      else
      {
        lljfState->previouslyReported = 1;
      };
      lljfState->pos = *pos; //store
      lljfState->frameNumber = 1;
    }
    else if ((lljfConfig.noiseLengthScale != 0 && lljfConfig.fingerLengthScale != 0 && !skipFilter((touchType_t)cla->touchType)) || simpleMode) //filter //add a condition !(cla->touchType == touchType_smallObject) if you want filtering to be classification dependent
    {

      int8p8 x, y, oldx, oldy;
      int8p8 dx, dy, absdx, absdy;
      int8p8 dr;

      x = pos->xPosition;
      y = pos->yPosition;
      oldx = lljfState->pos.xPosition;
      oldy = lljfState->pos.yPosition;
      dx = x - oldx;
      absdx = (dx < 0) ? (-dx) : dx;
      dy = y - oldy;
      absdy = (dy < 0) ? (-dy) : dy;
      dr = LL_max( absdx , absdy );

      if (dr > 0) //filter only if object actually moved
      {
        int8p8 norm_ratio;
        int8p8 newdx, newdy;
      #if CONFIG_HAS_W_LLJ_FILTER
        uint16 w = coordConv_computeW(pos);
        if (lljfConfig.wLLJ.w[i] <= w)
        {
          lljfConfig.wLLJ.w[i] = w;
        }
        else
        {
          lljfConfig.wLLJ.w[i] = (lljfConfig.wLLJ.w[i] * lljfConfig.wLLJ.Coeff + w * (0x100 - lljfConfig.wLLJ.Coeff)) >> 8;
        }
        w = lljfConfig.wLLJ.w[i];
      #endif

        if (simpleMode) //moisture
        {
          norm_ratio = 256 - correctByW_signed(w, lljfConfig.simpleModeStrength, lljfConfig.wLLJ.simpleModeStrength);
        }
        else //standard filtering: compute the norm ratio between actual displacement vector and reported displacement vector
        {
          //int8p8 z, oldz, dz;
          int8p8 norm;
          int8p8 y1, y2, y2_min, y2_max;
          int8p8 L1, L2, L3;
          int8p8 slope12, slope13, slope23;
          int8p8 noiseSuppressionFactor;
          int8p8 affineCoeff1, affineCoeff2;

          if (lljfState->frameNumber > correctByW_unsigned(w, lljfConfig.landLockFrames, lljfConfig.wLLJ.landLockFrames) && !lljfState->unlocked)
          {
            lljfState->unlocked = 1;
            lljfState->frameNumber = 1;
          };

          if (pos->z > 0 && !(cla->touchType == touchType_smallObject || cla->touchType == touchType_stylus || cla->touchType == touchType_eraser)) //change to lock only for large z; // add a condition !(cla->touchType == touchType_smallObject) if you want locking to be classification dependent
          {
            if (lljfState->unlocked)
            {
              affineCoeff1 = LL_min( 256 , (uint8p8)((((int32) lljfState->frameNumber) << 8) / correctByW_unsigned(w, lljfConfig.landLockReleaseFrames,           lljfConfig.wLLJ.landLockReleaseFrames) ));
              affineCoeff2 = LL_min( 256 , (uint8p8)((((int32) lljfState->frameNumber) << 8) / correctByW_unsigned(w, lljfConfig.landLockFastFingerReleaseFrames, lljfConfig.wLLJ.landLockFastFingerReleaseFrames) ));
            }
            else
            {
              affineCoeff1 = 0;
              affineCoeff2 = 0;
            }
          }
          else
          {
            lljfState->frameNumber = 255;
            affineCoeff1 = 256;
            affineCoeff2 = 256;
            lljfState->unlocked = 1;
          };

          //z = pos->z;
          //oldz = lljfState->pos.z;
          //dz = z - oldz;    //lifting: it duplicates a test in the classifier, useful only when filter is used in isolation
          //if (LL_div8p8( dz, z ) < -100) //empirically estimated, one should check on a phone
          //{
          //  affineCoeff2 = 0;
          //};

          L1 = correctByW_signed(w, lljfConfig.noiseLengthScale, lljfConfig.wLLJ.noiseLengthScale);
          L2 = LL_max( correctByW_signed(w, lljfConfig.fingerLengthScale, lljfConfig.wLLJ.fingerLengthScale), 2 * correctByW_signed(w, lljfConfig.noiseLengthScale, lljfConfig.wLLJ.noiseLengthScale) ); //One could make this dynamical (z dependent)
          #if CONFIG_HAS_Z_JITTER_ADJUSTMENT
          if (lljfConfig.zJitter.Enable && 0 < pos->z && cla->touchType == touchType_finger)
          {
            int8p8 fingerLengthScale = lljfConfig.fingerLengthScale;
            uint16 z = coordConv_computeZ(pos);
            if (lljfConfig.zJitter.LargeZ <= z)
            {
              L1                = lljfConfig.zJitter.NoiseLengthScale .LargeValue;
              fingerLengthScale = lljfConfig.zJitter.FingerLengthScale.LargeValue;
            }
            else if (lljfConfig.zJitter.SmallZ <= z)
            {
              L1                = (((int32)lljfConfig.zJitter.NoiseLengthScale .a * (int16)z) >> 8) + lljfConfig.zJitter.NoiseLengthScale .b;
              fingerLengthScale = (((int32)lljfConfig.zJitter.FingerLengthScale.a * (int16)z) >> 8) + lljfConfig.zJitter.FingerLengthScale.b;
            }
            L2 = LL_max( fingerLengthScale, 2 * L1);
          }
          #endif
          #if CONFIG_HAS_LL_LIFTING_LARGE_FINGER
          if (lljfConfig.liftingLarge.Enable)
          {
            uint16 w = coordConv_computeW(pos);
            uint16 z = coordConv_computeZ(pos);
            if (lljfConfig.liftingLarge.MinW <= w || lljfConfig.liftingLarge.MinZ <= z)
            {
              lljfState->wasBig = 1;
            }
            if (lljfState->wasBig && (w + lljfConfig.liftingLarge.DiffW < lljfState->lastW || z  + lljfConfig.liftingLarge.DiffZ < lljfState->lastZ))
            {
              L1 = lljfConfig.liftingLarge.NoiseLengthScale;
              L2 = LL_max(lljfConfig.liftingLarge.FingerLengthScale ?: lljfConfig.fingerLengthScale, 2 * L1);
            }
            lljfState->lastW = w;
            lljfState->lastZ = z;
          }
          #endif
          L3 = LL_mul8p8( L2 , 512 ); //Controls how smooth is the first release for space-unlock
          noiseSuppressionFactor = LL_mul8p8( correctByW_signed(w, lljfConfig.noiseSuppressionFactor, lljfConfig.wLLJ.noiseSuppressionFactor) , affineCoeff1 );

          #if CONFIG_HAS_ALTERNATE_GLOVE_JITTER
          if (cla->touchType == touchType_glove)
          {
            L1 = lljfConfig.altGloveJitter.noiseLengthScale;
            L2 = LL_max( lljfConfig.altGloveJitter.fingerLengthScale, 2 * lljfConfig.altGloveJitter.noiseLengthScale );
            L3 = LL_mul8p8( L2 , 512 );
            noiseSuppressionFactor = LL_mul8p8( lljfConfig.altGloveJitter.noiseSuppressionFactor , affineCoeff1 );
          }
          #endif

          y1 = LL_mul8p8( noiseSuppressionFactor , L1 );
          slope13 = LL_div8p8( L3 - y1 , L3 - L1 );
          y2_min = LL_mul8p8( noiseSuppressionFactor , L2 );
          y2_max = y1 + LL_mul8p8( slope13 , L2 - L1 );
          y2 = LL_mul8p8( 256 - affineCoeff2 , y2_min ) + LL_mul8p8( affineCoeff2 , y2_max );

          if (dr <= (int32)L1)
          {
            norm_ratio = noiseSuppressionFactor;
          }
          else
          {
            if (dr <= (int32)L2)
            {
              slope12 = LL_div8p8( y2 - y1 , L2 - L1 );
              norm = y1 + LL_mul8p8( dr - L1 , slope12 );
              norm_ratio = LL_div8p8( norm , dr );
            }
            else
            {
              if (lljfState->frameNumber <= correctByW_unsigned(w, lljfConfig.landLockFrames, lljfConfig.wLLJ.landLockFrames) && !lljfState->unlocked)
              {
                lljfState->unlocked = 1;
                lljfState->frameNumber = 1; //space unlock
              };
              if (dr <= (int32)L3)
              {
                slope23 = LL_div8p8( L3 - y2 , L3 - L2);
                norm =  y2 + LL_mul8p8( dr - L2 , slope23 );
                norm_ratio = LL_div8p8( norm , dr );
              }
              else
              {
                norm_ratio = 256;
              };
            };
          };
        };
        newdx = (dx > 0) ? LL_mul8p8( norm_ratio, absdx ) : -LL_mul8p8( norm_ratio, absdx );
        newdy = (dy > 0) ? LL_mul8p8( norm_ratio, absdy ) : -LL_mul8p8( norm_ratio, absdy );
#if CONFIG_HAS_JITTER_SUPPRESSION_LENGTH_FOR_SIMPLE_MODE
        if (simpleMode) //moisture 
        {
          int8p8 absnewdx, absnewdy;
      
          absnewdx = (newdx < 0) ? (-newdx) : newdx;
          absnewdy = (newdy < 0) ? (-newdy) : newdy;
          
          newdx = ((absnewdx > CONFIG_HAS_JITTER_SUPPRESSION_LENGTH_FOR_SIMPLE_MODE) ? newdx : 0);
          newdy = ((absnewdy > CONFIG_HAS_JITTER_SUPPRESSION_LENGTH_FOR_SIMPLE_MODE) ? newdy : 0);
        }
#endif
        x = oldx + newdx;
        y = oldy + newdy;

        pos->xPosition = x; //update position
        pos->yPosition = y;
        lljfState->pos = *pos;  //update state
      };

      if (lljfState->frameNumber < 255)
      {
        lljfState->frameNumber++;
      }
    }
    lljfState++;
    pos++;
    cla++;
  }
}

uint16 skipFilter(touchType_t touch_type)
{
  return lljfConfig.skipTypes & (1 << touch_type);
}
