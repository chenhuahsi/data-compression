// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: kalman_filter.c
// Description:
//

#include "ifp_common.h"

#if CONFIG_HAS_KALMAN_FILTER
#if defined(__CHIMERA__) && (__CHIMERA_VERSION__ < 31 || !__T100X_HAS_FPU__)
  #error "Kalman filter requires an FPU; skipping build"
#else

#include "ifp_string.h"
#include "kalman_filter.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

/* =================================================================
   MODULE TYPES
==================================================================*/
typedef struct
{
  float velX;
  float velY;
  float m11;
  float m12;
  float m22;
  int8p8 posX_0_0;
  int8p8 posY_0_0;
  int8p8 posX_1_0;
  int8p8 posY_1_0;
  int8p8 posX_0_1;
  int8p8 posY_0_1;
  int8p8 posX_0_2;
  int8p8 posY_0_2;
  uint8p8 z;
} kalmanFilterState_t;

typedef struct
{
  int8p8 xs[3];
  int8p8 ys[3];
  uint16 n : 2;
  uint16 i : 2;
} medianFilterState_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static kalmanFilterConfig_t kfConfig;
static kalmanFilterState_t kalmanFilterState[MAX_OBJECTS];
static medianFilterState_t medianFilterState[MAX_OBJECTS];
static classification_t kalmanFilterClassifications[MAX_OBJECTS];

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/
static uint16 outsideSensor(kalmanFilterState_t *kfState, int8p8 xMax, int8p8 yMax);
static void medianFilter(medianFilterState_t *mfState, sensorPosition_t *sensorPositionsPtr);
static void filterInit(kalmanFilterState_t *kfState, sensorPosition_t *sensorPositionsPtr);
static void filterPredictMatrix(kalmanFilterState_t *kfState);
static void filterPredictPosition(kalmanFilterState_t *kfState);
static void filterPredictPositionOnEdge(kalmanFilterState_t *kfState, int8p8 xMax, int8p8 yMax);
static void filterUpdate(kalmanFilterState_t *kfState, sensorPosition_t *sensorPositionsPtr);
ATTR_INLINE static uint16 doKalman(touchType_t touch_type, uint16 controlTypes);
ATTR_INLINE static int16 median3(int16 a, int16 b, int16 c);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

uint16 outsideSensor(kalmanFilterState_t *kfState, int8p8 xMax, int8p8 yMax)
{
  return ((kfState->posX_0_0 > 0 && kfState->posX_0_0 < xMax && kfState->posY_0_0 > 0 && kfState->posY_0_0 < yMax) && (kfState->posX_1_0 < 0 || kfState->posX_1_0 > xMax || kfState->posY_1_0 < 0 || kfState->posY_1_0 > yMax));
}

void medianFilter(medianFilterState_t *mfState, sensorPosition_t *sensorPositionsPtr)
{

  if(mfState->n > 0)
  {
    uint16 i = mfState->i;
    int16 dx = sensorPositionsPtr->xPosition - mfState->xs[i];
    int16 dy = sensorPositionsPtr->yPosition - mfState->ys[i];
    if (dx >= 256 || dx <= -256 || dy >= 256 || dy <= -256)
    {
      mfState->n = 0;
    }
  }

  switch (mfState->n)
  {
    case 0:
    {
      mfState->n = 1;
      mfState->i = 0;
      mfState->xs[0] = sensorPositionsPtr->xPosition;
      mfState->ys[0] = sensorPositionsPtr->yPosition;
      break;
    }
    case 1:
    {
      mfState->n = 2;
      mfState->i = 1;
      mfState->xs[1] = sensorPositionsPtr->xPosition;
      mfState->ys[1] = sensorPositionsPtr->yPosition;
      sensorPositionsPtr->xPosition = (mfState->xs[0] + mfState->xs[1] + 1) >> 1;
      sensorPositionsPtr->yPosition = (mfState->ys[0] + mfState->ys[1] + 1) >> 1;
      break;
    }
    default:
    {
      uint16 i;

      mfState->n = 3;
      mfState->i += 1;
      mfState->i %= 3;
      i = mfState->i;

      mfState->xs[i] = sensorPositionsPtr->xPosition;
      mfState->ys[i] = sensorPositionsPtr->yPosition;

      sensorPositionsPtr->xPosition = median3(mfState->xs[0], mfState->xs[1], mfState->xs[2]);
      sensorPositionsPtr->yPosition = median3(mfState->ys[0], mfState->ys[1], mfState->ys[2]);
    }
  }
}

void filterInit(kalmanFilterState_t *kfState, sensorPosition_t *sensorPositionsPtr)
{
  kfState->posX_0_0 = sensorPositionsPtr->xPosition;
  kfState->posY_0_0 = sensorPositionsPtr->yPosition;
  kfState->posX_1_0 = kfState->posX_0_0;
  kfState->posY_1_0 = kfState->posY_0_0;
  kfState->posX_0_1 = kfState->posX_0_0;
  kfState->posY_0_1 = kfState->posY_0_0;
  kfState->posX_0_2 = kfState->posX_0_0;
  kfState->posY_0_2 = kfState->posY_0_0;
  kfState->velX = 0.f;
  kfState->velY = 0.f;
  kfState->m11  = kfConfig.varW;
  kfState->m12  = 0.f;
  kfState->m22  = kfConfig.varU;
  kfState->z    = sensorPositionsPtr->z;
}

void filterPredictMatrix(kalmanFilterState_t *kfState)
{
  kfState->m11 += 2.f*kfState->m12 + kfState->m22;
  kfState->m12 += kfState->m22;
  kfState->m22 += kfConfig.varU;
}

void filterPredictPosition(kalmanFilterState_t *kfState)
{
  kfState->posX_1_0 =  kfState->posX_0_0 + (int8p8) kfState->velX;
  kfState->posY_1_0 =  kfState->posY_0_0 + (int8p8) kfState->velY;
}

void filterPredictPositionOnEdge(kalmanFilterState_t *kfState, int8p8 xMax, int8p8 yMax)
{
  int8p8 posX = kfState->posX_1_0;
  int8p8 posY = kfState->posY_1_0;
  float velX = kfState->velX;
  float velY = kfState->velY;

  float dtX = 0;
  float dtY = 0;
  float dt;

  if (posX < 0 && velX < 0.f)
  {
    dtX = posX / velX;
  }
  else if (posX > xMax && velX > 0.f)
  {
    dtX = (posX-xMax) / velX;
  }

  if (posY < 0 && velY < 0.f)
  {
    dtY = posY / velY;
  }
  else if (posY > yMax && velY > 0.f)
  {
    dtY = (posY-yMax) / velY;
  }

  if (dtX > dtY)
  {
    dt = dtX;
  }
  else
  {
    dt = dtY;
  }

  posX -= (int8p8) (dt * velX);
  posY -= (int8p8) (dt * velY);

  if (posX < 0)
  {
    posX = 0;
  }
  if (posX > xMax)
  {
    posX = xMax;
  }
  if (posY < 0)
  {
    posY = 0;
  }
  if (posY > yMax)
  {
    posY = yMax;
  }

  kfState->posX_1_0 = posX;
  kfState->posY_1_0 = posY;
}

void filterUpdate(kalmanFilterState_t *kfState, sensorPosition_t *sensorPositionsPtr)
{
  float m11 = kfState->m11;
  float m12 = kfState->m12;
  float invAlpha = 1.f / (kfConfig.varW + m11);
  int8p8 deltaX = sensorPositionsPtr->xPosition - kfState->posX_1_0;
  int8p8 deltaY = sensorPositionsPtr->yPosition - kfState->posY_1_0;

  {
    float gain_0_2 = ((m11 + 2 * m12) * kfConfig.varW * kfConfig.varW + m11 * m12 * (2 * kfConfig.varW - m12) - kfConfig.varW * m12 * m12) * invAlpha * invAlpha * invAlpha;
    kfState->posX_0_2 = (int8p8) (kfState->posX_0_1 + deltaX * gain_0_2);
    kfState->posY_0_2 = (int8p8) (kfState->posY_0_1 + deltaY * gain_0_2);
  }
  {
    float gain_0_1 = ((m11 + m12) * kfConfig.varW + m11 * m12) * invAlpha * invAlpha;
    kfState->posX_0_1 = (int8p8) (kfState->posX_0_0 + deltaX * gain_0_1);
    kfState->posY_0_1 = (int8p8) (kfState->posY_0_0 + deltaY * gain_0_1);
  }
  kfState->posX_0_0 = (int8p8) (kfState->posX_1_0 + deltaX * m11 * invAlpha);
  kfState->posY_0_0 = (int8p8) (kfState->posY_1_0 + deltaY * m11 * invAlpha);
  kfState->velX     += deltaX * m12 * invAlpha;
  kfState->velY     += deltaY * m12 * invAlpha;

  kfState->m22  -= m12 * m12 * invAlpha;
  kfState->m11   = m11 * kfConfig.varW * invAlpha;
  kfState->m12   = m12 * kfConfig.varW * invAlpha;

  kfState->z     = sensorPositionsPtr->z;
}

uint16 doKalman(touchType_t touch_type, uint16 controlTypes)
{
  return controlTypes & (1 << touch_type);
}

/* -----------------------------------------------------------------
Name: median3
Purpose: Find the median of three numbers
Inputs: The three int16 values
Outputs: The median
Effects: None
Notes: This function is optimized on Chimera to use the single-cycle
       SMED instruction.
----------------------------------------------------------------- */
ATTR_INLINE static int16 median3(int16 a, int16 b, int16 c)
{
  int16 dest;
#ifdef __CHIMERA__
  asm("        smed a, y, x\n" :
      "=a" (dest) :
      "a" (a), "x" (b), "y" (c) :
      "cc");
#else
  if ((a <= b && b <= c) || (c <= b && b <= a))
  {
    dest = b;
  }
  else if ((a <= c && c <= b) || (b <= c && c <= a))
  {
    dest = c;
  }
  else
  {
    dest = a;
  }
#endif
  return dest;
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: kalmanFilter_init()
Purpose: Initialize the Kalman Filter module.
Inputs: None.
Outputs: None.
Effects: Resets internal state of the filter, as at power-on.
Notes: This function must be called before using the filter module.
Example: None.
----------------------------------------------------------------- */
void kalmanFilter_init(void)
{
  memset16(kalmanFilterState, 0, sizeof(kalmanFilterState) / sizeof(uint16));
  memset16(medianFilterState, 0, sizeof(medianFilterState) / sizeof(uint16));
}

/* -----------------------------------------------------------------
Name: kalmanFilter_reinit()
Purpose: Re-initialize the Kalman Filter module.
Inputs: None.
Outputs: None.
Effects: Resets internal state of kalman filter, as at a host rezero.
Notes: This function must be called if the host sends a rezero command.
Example: None.
----------------------------------------------------------------- */
void kalmanFilter_reinit(void)
{
  kalmanFilter_init();
}

/* -----------------------------------------------------------------
Name: kalmanFilter_configure()
Purpose: Configure the Kalman Filter module.
Inputs: extConfig - kalmanFilterConfig_t struct ptr
Outputs: None.
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void kalmanFilter_configure(kalmanFilterConfig_t *extConfig)
{
  kfConfig = *extConfig;
}

/* -----------------------------------------------------------------
Name: kalmanFilter_filterPositions()
Purpose: Apply the Kalman Filter to the position reporting
Inputs:
Outputs:
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void kalmanFilter_filterPositions(sensorParams_t *sensorParams, sensorPosition_t *sensorPositions, classification_t *classifications)
{
  int8p8 xMax = sensorParams->rxCount << 8;
  int8p8 yMax = sensorParams->txCount << 8;
  kalmanFilterState_t *kfState = kalmanFilterState;
  medianFilterState_t *mfState = medianFilterState;
  sensorPosition_t *sensorPositionsPtr = sensorPositions;
  classification_t *classificationsPtr = classifications;

  int16 i;
  for (i = 0; i < MAX_OBJECTS; i++, kfState++, mfState++, sensorPositionsPtr++, classificationsPtr++)
  {
    if (kfState->z)
    {
      if (!classificationsPtr->newTouchFlag && (sensorPositionsPtr->z == 0 || (doKalman((touchType_t) classificationsPtr->touchType, kfConfig.controlTypes) && !classificationsPtr->touchFlag)))
      {
        filterPredictPosition(kfState);
        if (outsideSensor(kfState, xMax, yMax))
        {
          filterPredictPositionOnEdge(kfState, xMax, yMax);
          sensorPositionsPtr->xPosition = kfState->posX_1_0;
          sensorPositionsPtr->yPosition = kfState->posY_1_0;
          sensorPositionsPtr->z         = kfState->z;
          memcpy16(classificationsPtr, &kalmanFilterClassifications[i], sizeof(kalmanFilterClassifications[i])/sizeof(uint16));
          classificationsPtr->newTouchFlag = 0;
        }
        memset16(kfState, 0, sizeof(*kfState) / sizeof(uint16));
        memset16(mfState, 0, sizeof(*mfState) / sizeof(uint16));
        continue;
      }
    }

    if (sensorPositionsPtr->z == 0 || classificationsPtr->newTouchFlag || !doKalman((touchType_t) classificationsPtr->touchType, kfConfig.controlTypes))
    {
      memset16(kfState, 0, sizeof(*kfState) / sizeof(uint16));
      memset16(mfState, 0, sizeof(*mfState) / sizeof(uint16));
      continue;
    }

    if (doKalman((touchType_t) classificationsPtr->touchType, kfConfig.controlTypes))
    {
      memcpy16(&kalmanFilterClassifications[i], classificationsPtr, sizeof(kalmanFilterClassifications[i])/sizeof(uint16));
      if ( !kfConfig.inhibitMF )
      {
      medianFilter(mfState, sensorPositionsPtr);
      }
      if (kfState->z == 0)
      {
        filterInit(kfState, sensorPositionsPtr);
      }
      else
      {
        filterPredictPosition(kfState);
        filterPredictMatrix(kfState);
        filterUpdate(kfState, sensorPositionsPtr);
        if (kfConfig.filterDelay_frames == 2)
        {
          sensorPositionsPtr->xPosition = kfState->posX_0_2;
          sensorPositionsPtr->yPosition = kfState->posY_0_2;
        }
        else if(kfConfig.filterDelay_frames == 1)
        {
          sensorPositionsPtr->xPosition = kfState->posX_0_1;
          sensorPositionsPtr->yPosition = kfState->posY_0_1;
        }
        else
        {
          sensorPositionsPtr->xPosition = kfState->posX_0_0;
          sensorPositionsPtr->yPosition = kfState->posY_0_0;
        }
      }
    }
  }
}

#endif //hasFPU
#endif //CONFIG_HAS_KALMAN_FILTER
