// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100
//
// $Id$
// -----------------------------------------------------------------
//
//
// Filename: buttons_0D.c
// Description:
//

#include "ifp_common.h"
#include "buttons_0D.h"

#if CONFIG_HAS_0D_BUTTONS

#include "ifp_string.h"
#include "ifp_bit_manipulation.h"
#include "position_reporter.h"
/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

#ifndef BUTTONS_HISTORY_LENGTH
  #define BUTTONS_HISTORY_LENGTH 32
#endif

#if (BUTTONS_HISTORY_LENGTH & (BUTTONS_HISTORY_LENGTH - 1)) != 0 || BUTTONS_HISTORY_LENGTH < 2
  #error "buttons_0D.c: BUTTONS_HISTORY_LENGTH must be a power of 2 bigger than 1"
#endif

#ifndef BUTTONS_HISTORY_LENGTH_MASK
  #define BUTTONS_HISTORY_LENGTH_MASK (BUTTONS_HISTORY_LENGTH-1)
#else
  #if BUTTONS_HISTORY_LENGTH_MASK != (BUTTONS_HISTORY_LENGTH-1)
    #error "buttons_0D.c: BUTTONS_HISTORY_LENGTH_MASK must equal to BUTTONS_HISTORY_LENGTH-1"
  #endif
#endif

#define B_min(X, Y)  ((X) < (Y) ? ((X)) : ((Y)))
#define B_max(X, Y)  ((X) > (Y) ? ((X)) : ((Y)))
#define B_abs(X)  ((X) > (0) ? ((X)) : (-(X)))

/* =================================================================
   MODULE TYPES
==================================================================*/

typedef enum
{
  class_none = 0,
  class_saturatedFinger,
  class_liftingSaturatedFinger,
  class_glovedFinger,
  class_thinGlovedFinger
} buttons0DClass_t;

typedef enum
{
  state_start,
  state_rezero,
  state_fast,
  state_thermal,
  state_frozen
}btnBaselineState_t;

typedef struct
{
  uint16 saturatedFinger:1;
  uint16 glovedFinger:1;
  uint16 thinGlovedFinger:1;
} buttons0DResults_t;


/* =================================================================
   MODULE VARIABLES
==================================================================*/
static buttons0DConfig_t btnconfig;
static uint16 buttonsCount; //number of active buttons
static buttonsBitmask_t buttonsState; //on-off in the previous frame
static buttons0DClass_t buttonsClass[MAX_BUTTONS]; //finger, glove etc
static buttons0DBaseline_t buttonBaseline;
static uint8p8 btnStartupBaselineVariance;
static int16 buttonDelta[MAX_BUTTONS];
static uint16 variances[MAX_BUTTONS];
static uint8p8 gain[MAX_BUTTONS];
static int16 gloveDeltas[MAX_BUTTONS];
static uint16 gloveTouchState[MAX_BUTTONS];
static uint16 gloveEventCounter[MAX_BUTTONS];
static uint16 debouncingFilterCounter[MAX_BUTTONS];
static uint16 history[MAX_BUTTONS][BUTTONS_HISTORY_LENGTH];
static uint16 historyIndex;
static uint16 FIRBufferLength;
static uint16 btnNoiseFloor;
static uint8p8 btnEnergyRatio;
static uint16 btnthermal_update_ms;
static uint16 btnthermal_update_speed;
static uint16 btnthermalUpdateInterval_ms;
static uint16 btnfastHalflife_ms;
static uint16 btnholdFastTransition_ms;
static uint16 btnfastRelaxDuration_ms;
static uint8p8 bntMaxIncreasedVariance;
static btnBaselineState_t btnBaselineState;
static uint16 btntimer_ms;
static uint16 gloveEventState;
static int16 touch2DCounter;
static buttonsBitmask_t blackList;
static buttonsBitmask_t gloveBlacklist;  //gloves blacklisted after finger touch
static buttonsBitmask_t singleGloveBlacklist; //other glove blacklisted after 1st glove touch

//store internal state of individual buttons for debugging
static buttonsBitmask_t fingerReportsState, gloveReportsState;
static buttonsBitmask_t fingerTestsState, gloveTestsState;

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/
static void transitionMatrix(buttons0DResults_t *results, buttons0DClass_t *state);
static void makeReport(int16 *deltas, int16 *touch2D, buttons0DReport_t *buttons0DReport);
static void computeMeansAndVariances(uint16 *means, uint16 *variances, uint16 *thinGloveFIR);
static buttonsBitmask_t debouncingFilter(buttonsBitmask_t state);
static void btnbaselineChecker_check(uint16 *btnFrame,buttons0DBaseline_t *btnBaseline,buttons0DClass_t *btnClass,uint16 *objectsPresent,uint16 *errorsPresent);
static relaxCommand_t btnbaselineManager_manage(uint16 objectsPresent,uint16 errorsPresent,uint16 forceFastRelax,uint16 relaxationDisabled,uint16 frameTime_ms);
static void btnbaselineUpdater_update(relaxCommand_t relaxCommand,uint16 frameTime_ms,uint16 *btnFrame,buttons0DBaseline_t *btnBaseline);
static uint8p8 calculateBaselineVariance(uint16 *btnBaseline);

/* get deltas and baselines */
int16 *buttons0D_getDelta(void)
{
  if (buttonBaseline.baselineAcquired)
  {
    return buttonDelta;
  }
  else
  {
    return NULL;
  }
}

uint16 *buttons0D_getBaseline(void)
{
  if (buttonBaseline.baselineAcquired)
  {
    return buttonBaseline.estimate;
  }
  else
  {
    return NULL;
  }
}

baselineState_t buttons0D_getBaselineState(void)
{
  if (buttonBaseline.baselineAcquired)
  {
    return baselineState_baselineAcquired;
  }
  else
  {
    return baselineState_noBaseline;
  }
}

uint16 *buttons0D_getVariance(void)
{
    return variances;
}

/* -----------------------------------------------------------------
Name: buttons0D_init()
Purpose: Initialize the buttons0D module.
Inputs: None.
Outputs: None.
Effects: Resets internal state of the module, as at power-on.
Notes: This function must be called before using the module.
Example: None.
----------------------------------------------------------------- */
void buttons0D_init(void)
{
  buttonsState = 0;
  memset16(&buttonBaseline, 0, sizeof(buttonBaseline) / sizeof(uint16));
  memset16(&buttonDelta, 0, sizeof(buttonDelta) / sizeof(uint16));
  memset16(history, 0, sizeof(history) / sizeof(uint16));
  historyIndex = 0;
  memset16(buttonsClass, 0, sizeof(buttonsClass) / sizeof(uint16));
  gloveEventState = 0;
  memset16(gloveTouchState, 0, sizeof(gloveTouchState) / sizeof(uint16));
  memset16(variances, 0, sizeof(variances) / sizeof(uint16));
  memset16(gloveEventCounter, 32767, sizeof(gloveEventCounter) / sizeof(uint16));
  memset16(debouncingFilterCounter, 0, sizeof(debouncingFilterCounter) / sizeof(uint16));
  blackList = 0;
  gloveBlacklist = 0;
  singleGloveBlacklist = 0;
  touch2DCounter = 0;

  btntimer_ms = 0;
  btnthermal_update_ms = 0;
  btnthermal_update_speed = 1;
  btnBaselineState = state_start;
}

/* -----------------------------------------------------------------
Name: buttons0D_reinit()
Purpose: Re-initialize the buttons0D module.
Inputs: None.
Outputs: None.
Effects: Resets internal state of buttons0D, as at a host rezero.
Notes: This function must be called if the host sends a rezero command.
Example: None.
----------------------------------------------------------------- */
void buttons0D_reinit(void)
{
  buttons0D_init();
}

/* -----------------------------------------------------------------
Name: buttons0D_configure()
Purpose: Configure the buttons0D module.
Inputs: extConfig - buttons0DConfig_t struct ptr
Outputs: None.
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void buttons0D_configure(sensorParams_t *sensorParameters, buttons0DConfig_t *extConfig)
{
  memcpy16(&btnconfig, extConfig, sizeof(buttons0DConfig_t) / sizeof(uint16));

  buttonsCount = sensorParameters->buttonsCount;
  {
    uint16 i, maxSat = 0;
    for (i = 0; i < buttonsCount; i++)
    {
      if (btnconfig.buttonsSaturation[i] > maxSat)
      {
        maxSat = btnconfig.buttonsSaturation[i];
      }
    }
    memset16(gain, 0, sizeof(gain) / sizeof(uint16));
    for (i = 0; i < buttonsCount; i++)
    {
      if (btnconfig.buttonsSaturation[i] > 0)
      {
        gain[i] = (uint8p8)((((uint32)maxSat) << 8) / btnconfig.buttonsSaturation[i]);
      }
    }
  }
  FIRBufferLength = B_min(BUTTONS_HISTORY_LENGTH, B_max(1 , btnconfig.buttonsThinGloveFIRCoeff));

  btnNoiseFloor = btnconfig.buttonsNoiseFloor;
  btnEnergyRatio = btnconfig.buttonsEnergyRatio<<4; //uint8p8
  btnthermalUpdateInterval_ms = btnconfig.buttonsThermalUpdateInterval_ms;
  btnfastHalflife_ms = btnconfig.buttonsFastHalflife_ms;
  btnholdFastTransition_ms = btnconfig.buttonsHoldFastTransition_ms;
  btnfastRelaxDuration_ms = btnconfig.buttonsFastRelaxDuration_ms;
  bntMaxIncreasedVariance = btnconfig.buttonsMaxIncreasedVariance;
}


/* -----------------------------------------------------------------
Name: buttons0D_analyzeData()
Purpose: Generate a final report based on the incoming data and the state of the module.
Inputs:
Outputs:
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void buttons0D_analyzeData(uint16 *buttonsRaw, classification_t *classifications, buttons0DReport_t *buttons0DReport, ifpTimeStamp_t timeSinceLast_ms, uint16 inhibitRelaxation)
{
  classification_t *cla = classifications;
  uint16 i;
  uint16 means[MAX_BUTTONS];
  uint16 thinGloveFIR[MAX_BUTTONS];
  uint16 touch2D;
  uint16 saturation;
  int16 fingerThreshold;
  int16 gloveThreshold;
  int16 thinGloveThreshold;
  uint16 gloveEvent;
  buttons0DClass_t previousClass;
  buttons0DResults_t results;
  uint16 gloveReportEnable;

  memset16(buttons0DReport, 0, sizeof(buttons0DReport_t) / sizeof(uint16));

  //Get btndeltaimage
  if(buttonBaseline.baselineAcquired)
  {
    if(btnconfig.buttonsDataType == dataType_abs)
    {
      for (i = 0; i < buttonsCount; i++)
      {
        buttonDelta[i] = buttonsRaw[i] - buttonBaseline.estimate[i];
      }
    } else
    { //btnconfig.buttonsDataType == dataType_trans
      for (i = 0; i < buttonsCount; i++)
      {
        buttonDelta[i] =  buttonBaseline.estimate[i] - buttonsRaw[i];
      }
    }
  } else
  {
    for(i=0;i<buttonsCount;++i)
    {
      buttonDelta[i] = 0;
      memset16(history[i],buttonsRaw[i],sizeof(history[i])/sizeof(uint16));
    }
  }

  touch2D = 0;
  for (i = 0; i < MAX_OBJECTS; i++)
  {
    if (cla->touchFlag == 1)
    {
      touch2D = 1;
      break;
    }
    cla++;
  }

  if (touch2D == 1)
  {
    touch2DCounter = btnconfig.buttonsOffFor2DTouchMaxFrames;
  }
  else
  {
    if (touch2DCounter != 0)
    {
      --touch2DCounter;
    }
  }

  //Store button rawdata
  for (i = 0; i < buttonsCount; i++){
    history[i][historyIndex] = buttonsRaw[i];
  }
  historyIndex = (historyIndex + 1) & BUTTONS_HISTORY_LENGTH_MASK;

  computeMeansAndVariances(means, variances, thinGloveFIR);

  fingerTestsState = 0;
  gloveTestsState = 0;
  gloveReportEnable = btnconfig.buttonGloveEnable;

  for (i = 0; i < buttonsCount; i++)
  {
    memset16(&results, 0, sizeof(results) / sizeof(uint16));

    //thresholds
    previousClass = buttonsClass[i];
    saturation = btnconfig.buttonsSaturation[i];
    fingerThreshold = (uint16) ((uint32)btnconfig.buttonsFingerThreshold_pct * saturation >> 8);
    gloveThreshold =  (uint16) (((uint32)fingerThreshold * btnconfig.buttonsGloveThreshold_pct) >> 8);
    thinGloveThreshold = (uint16) (((uint32)fingerThreshold * btnconfig.buttonsThinGloveThreshold_pct) >> 8);

     //hysteresis
     if (previousClass == class_saturatedFinger)
     {
       fingerThreshold = (int16) (((int32)fingerThreshold * btnconfig.buttonsReleaseThreshold_pct) >> 8);
     }

     if (previousClass == class_thinGlovedFinger)
     {
      thinGloveThreshold = (int16) (((int32)thinGloveThreshold * btnconfig.buttonsReleaseThreshold_pct) >> 8);
     }

    //saturated finger tests
    if (buttonDelta[i] > fingerThreshold)
    {
      results.saturatedFinger = 1;
    }

    //thin glove tests
    if (btnconfig.buttonsDataType == dataType_abs)
    {
      if ((int32)thinGloveFIR[i] - ((int32)buttonBaseline.estimate[i]) > thinGloveThreshold)
      {
        results.thinGlovedFinger = 1;
      }
    } else
    { //btnconfig.buttonsDataType == dataType_trans
      if ((int32)thinGloveFIR[i] - ((int32)buttonBaseline.estimate[i]) > thinGloveThreshold)
      {
        results.thinGlovedFinger = 1;
      }
    }

    //gloved finger tests
    gloveEvent = (variances[i] > btnconfig.buttonsVarianceThreshold);

    if (gloveEvent > isBitSet(gloveEventState , i) && gloveTouchState[i] == 0)
    {
      gloveEventCounter[i] = 0;
    }

    if (gloveEventCounter[i] < 65535)
    {
      gloveEventCounter[i]++;
    }

    if(btnconfig.buttonsDataType == dataType_abs)
    {
      gloveDeltas[i] = (int16)((int32)means[i] - ((int32)buttonBaseline.estimate[i]));
    }
    else
    { //btnconfig.buttonsDataType == dataType_trans
      gloveDeltas[i] = (int16)(((int32)buttonBaseline.estimate[i]) - (int32)means[i]);
    }

    //if (gloveEvent < isBitSet(gloveEventState , i))
    if (gloveEvent == 0)
    {
      if (gloveDeltas[i] > gloveThreshold
           && gloveEventCounter[i] < btnconfig.buttonsGloveLandingMaxFrames + BUTTONS_HISTORY_LENGTH)
      {
        gloveTouchState[i] = 1;
      }
    }

    if (gloveTouchState[i] == 1)
    {
      gloveThreshold = (int16) (((int32)gloveThreshold * btnconfig.buttonsReleaseThreshold_pct) >> 8);
      if (gloveDeltas[i] < gloveThreshold)
      {
        gloveTouchState[i]  = 0;
      }
    }

    if (gloveEvent == 1)
    {
      gloveEventState = setBit(gloveEventState, i);
    }
    else
    {
      gloveEventState = clearBit(gloveEventState, i);
    }
    results.glovedFinger = gloveTouchState[i];

    //store test results
    if (results.saturatedFinger)
    {
      fingerTestsState = setBit(fingerTestsState, i);
    }
    if (results.glovedFinger) {
      gloveTestsState = setBit(gloveTestsState, i);
    }

    //transition matrix
    if(0 == gloveReportEnable)
    {
      results.glovedFinger = 0;
      results.thinGlovedFinger = 0;
    }
    transitionMatrix(&results, &buttonsClass[i]);
  }

  makeReport(buttonDelta, &touch2DCounter, buttons0DReport);
  {
    uint16 objectsPresent,errorsPresent;
    relaxCommand_t relaxCommand;
    btnbaselineChecker_check(buttonsRaw,&buttonBaseline,buttonsClass,&objectsPresent,&errorsPresent);
    relaxCommand = btnbaselineManager_manage(objectsPresent,errorsPresent,0, inhibitRelaxation || touch2D,timeSinceLast_ms);
    btnbaselineUpdater_update(relaxCommand, timeSinceLast_ms, buttonsRaw, &buttonBaseline);
  }
}

/* -----------------------------------------------------------------
Name: buttons0D_computeMeanAndVariance()
Purpose: compute running mean and variance for each button
Inputs:
Outputs:
Effects: None.
Notes: None.
Example: None.
Notes: Internal to this file only.
----------------------------------------------------------------- */
void computeMeansAndVariances(uint16 *means, uint16 *variances, uint16 *thinGloveFIR)
{
  uint16 i, j;
  int32 btnMean,btnVariance,btnThinGloveFIR;
  uint16 index;

  for (i = 0; i < buttonsCount; i++)
  {
    btnMean = 0;
    btnVariance = 0;
    btnThinGloveFIR = 0;

    for (j = 0; j < BUTTONS_HISTORY_LENGTH; j++)
    {
      btnMean += history[i][j];
    }
    btnMean = btnMean / BUTTONS_HISTORY_LENGTH;

    for (j = 0; j < BUTTONS_HISTORY_LENGTH; j++)
    {
      if(history[i][j] > btnMean)
      {
        btnVariance += history[i][j] - btnMean;
      } else
      {
        btnVariance += btnMean - history[i][j];
      }
    }
    btnVariance = btnVariance / BUTTONS_HISTORY_LENGTH;

    for (j = 0; j < FIRBufferLength; j++)
    {
      index = (historyIndex + BUTTONS_HISTORY_LENGTH - FIRBufferLength + j) & BUTTONS_HISTORY_LENGTH_MASK;
      btnThinGloveFIR += history[i][index];
    }
    btnThinGloveFIR = btnThinGloveFIR / (int16)FIRBufferLength;
    *means = (uint16) btnMean;
    *variances = (uint16) btnVariance;
    *thinGloveFIR = (uint16)btnThinGloveFIR;

    means++;
    variances++;
    thinGloveFIR++;
  }
}


/* -----------------------------------------------------------------
Name: transitionMatrix
Purpose: Determines the next classification for the current object
Inputs: results structure, state structure
Outputs: state structure
Effects:
Notes: Internal to this file only.
------------------------------------------------------------------ */
static void transitionMatrix(buttons0DResults_t *results,
                                      buttons0DClass_t *state)
{
  buttons0DClass_t nextClass = class_none;

  switch(*state)
  {
    case class_saturatedFinger:
      if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else
      {
        nextClass = class_liftingSaturatedFinger;
      }
      break;
    case class_liftingSaturatedFinger:
      if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->thinGlovedFinger == 1)
      {
        nextClass = class_liftingSaturatedFinger;
      }
      else if (results->glovedFinger == 1)
      {
        nextClass = class_liftingSaturatedFinger;
      }
      else
      {
        nextClass = class_none;
      }
      break;
    case class_glovedFinger:
    case class_thinGlovedFinger: // intentional fall-through
    case class_none: // intentional fall-through
    default:         // intentional fall-through
      if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->thinGlovedFinger == 1)
      {
        nextClass = class_thinGlovedFinger;
      }
      else if (results->glovedFinger == 1)
      {
        nextClass = class_glovedFinger;
      }
      else
      {
        nextClass = class_none;
      }
      break;
  }

  *state = nextClass;
}

/* -----------------------------------------------------------------
Name: makeReport
Purpose: prepare a final report based on the per-button results and
any extra information available.
Inputs:
Outputs:
Effects:
Notes: Internal to this file only.
------------------------------------------------------------------ */
static void makeReport(int16 *deltas, int16 *touch2D, buttons0DReport_t *buttons0DReport)
{
  uint16 i;
  int32 maxDelta = -2147483647, secondMaxDelta = -2147483647;
  uint16 strongestButton = 0, secondStrongestButton = 0, clearWinner, buttonsReport = 0, gloveReports = 0, fingerReports = 0;

  memset16(buttons0DReport, 0, sizeof(buttons0DReport_t) / sizeof(uint16));

  for (i = 0; i < buttonsCount; i++) //computing max deltas and clearWinner
  {
    int32 delta; //local rescaled delta for buttons comparisons

    if (isBitSet(btnconfig.buttonsGroupMask, i)) //rescaling
    {
      delta = (((int32)gain[i] * deltas[i])>>8); //apply gain
      delta = isBitSet(buttonsState , i) ? ((int32)delta)<<8 : ((int32)delta) * btnconfig.buttonsStrongestButtonsHysteresis_pct;
    }
    else
    {
      delta = -2147483647;
    }

    if (delta >= maxDelta) //max delta for strongest button
    {
      secondMaxDelta = maxDelta;
      maxDelta = delta;
      secondStrongestButton = strongestButton;
      strongestButton = i;
    }
    else if (delta > secondMaxDelta)
    {
      secondMaxDelta = delta;
      secondStrongestButton = i;
    }

    if (buttonsClass[i] == class_saturatedFinger) //compute fingers and glove reports bitmasks
    {
      fingerReports = setBit(fingerReports, i);
    }
    else if (buttonsClass[i] == class_glovedFinger || buttonsClass[i] == class_thinGlovedFinger)
    {
      gloveReports = setBit(gloveReports, i);
    }
  }

  fingerReportsState = fingerReports; //store individual button reports for diagnostics and debugging
  gloveReportsState = gloveReports;

  clearWinner = (uint16)(((int32)maxDelta - (int32)secondMaxDelta) > B_abs(((int32)maxDelta >> 1)));

  //compute objectPresent Flag
  for (i = 0; i < buttonsCount; i++)
  {
    if (buttonsClass[i] != class_none)
    {
      buttons0DReport->objectPresent = 1;
      break;
    }
  }

  // gloves are blackListed if there are fingers around
  if (fingerReports > 0)
  {
    gloveBlacklist = ~(uint16)0;
  }
  else
  {
    gloveBlacklist = gloveBlacklist & gloveReports;
  }
  gloveReports = gloveReports & ~gloveBlacklist;

  // only one glove is allowed
  if (buttonsState == 0 && gloveReports > 0) //should we use a gloveReport state instead of a button state?
  {
    singleGloveBlacklist = btnconfig.buttonsGroupMask;
    if (clearWinner == 1 && isBitSet(gloveReports, strongestButton))
    {
      singleGloveBlacklist = clearBit(singleGloveBlacklist , strongestButton);
    }
  }
  else
  {
    singleGloveBlacklist = singleGloveBlacklist * buttons0DReport->objectPresent;
  }
  gloveReports = gloveReports & ~singleGloveBlacklist;

  //only strongest button reported also for fingers
  #if CONFIG_IFP_ESD_BUTTONS_NOT_REPORT_ENABLE
    // SWTDDI-932,For ESD testing, it won't report when multi buttons are pressed.
    uint16 countbits, tempvalue;
    countbits = 0;
    tempvalue = fingerReports;

    while(tempvalue)
    {
       if((tempvalue & 0x01) == 1)
          countbits++;

       tempvalue >>= 1;
    }

    fingerReports = (countbits > 1)? 0: fingerReports;
  #endif

  if (btnconfig.reportOnlyOneButton == 1)
  {
    fingerReports = (fingerReports & ~btnconfig.buttonsGroupMask) | (powerOfTwo(strongestButton) & fingerReports);
  }
  buttonsReport = fingerReports | gloveReports;

  //all buttons are blackListed if there is a 2D touch unless they are already on
  if (*touch2D > 0)
  {
    //mark it if we want to report 2D with 0D/glove simultaneously.
    //blackList = ~buttonsState;
  }
  else
  {
    blackList = blackList & buttonsReport;
  }
  buttonsReport = buttonsReport & ~blackList;

  //apply debouncing filter
  buttonsReport = debouncingFilter(buttonsReport);

  //complete building external report
  buttons0DReport->state = buttonsReport;
  buttons0DReport->freshData = (uint16) ((buttons0DReport->state & btnconfig.buttonsFreshDataMask) != (buttonsState & btnconfig.buttonsFreshDataMask));

  buttonsState = buttons0DReport->state; //save report in the internal state

}

/* -----------------------------------------------------------------
Name: debouncingFilter
Purpose: change report only if the change persists for at least N frames
Inputs:  reports
Outputs: reports
Effects:
Notes:
------------------------------------------------------------------ */
buttonsBitmask_t debouncingFilter(buttonsBitmask_t report)
{
  uint16 i;
  for (i = 0; i < buttonsCount; i++)
  {
    if (isBitSet(report,i) == isBitSet(buttonsState,i))
    {
      debouncingFilterCounter[i] = 0;
    }
    else
    {
      debouncingFilterCounter[i]++;
    }
  }
  for (i = 0; i < buttonsCount; i++)
  {
    if (debouncingFilterCounter[i] <= btnconfig.buttonsDebouncingFilterStrength)
    {
      report = isBitSet(buttonsState, i) ? setBit(report,i) : clearBit(report, i);
    }
  }
  return report;
}


/* -----------------------------------------------------------------
Name: buttons0D_getButtons0DDiagnostics
Purpose: collects data regarding the current state of 0D buttons
Inputs:
Outputs: buttons0DDiagnostics_t struct
Effects:
Notes:
------------------------------------------------------------------ */
void buttons0D_getButtons0DDiagnostics(ATTR_UNUSED buttons0DDiagnostics_t *buttons0DDiagnostics)
{
  uint16 means[MAX_BUTTONS];
  uint16 thinGloveFIR[MAX_BUTTONS];
  uint16 i,index;
  computeMeansAndVariances(means, variances, thinGloveFIR);
  for (i = 0; i < buttonsCount; i++)
  {
    index = (historyIndex + BUTTONS_HISTORY_LENGTH - 1) & BUTTONS_HISTORY_LENGTH_MASK;
    buttons0DDiagnostics->data[i] = history[i][index];
    buttons0DDiagnostics->baseline[i] = (uint16)(buttonBaseline.estimate[i]);
    buttons0DDiagnostics->runningMeanButton[i] = means[i];
    buttons0DDiagnostics->runningVarButton[i] = variances[i];
    buttons0DDiagnostics->fingerReports = fingerReportsState; //individual button reports for diagnostics and debugging
    buttons0DDiagnostics->gloveReports = gloveReportsState;
    buttons0DDiagnostics->fingerTests = fingerTestsState; //individual button tests for diagnostics and debugging
    buttons0DDiagnostics->gloveTests = gloveTestsState;
  }
}

static void btnbaselineChecker_check(uint16 *btnFrame,buttons0DBaseline_t *btnBaseline,buttons0DClass_t *btnClass,uint16 *objectsPresent,uint16 *errorsPresent)
{
  uint16 hasObject = 0;
  uint16 hasError = 0;
  uint16 i;
  uint32 posSum=0;
  uint32 negSum=0;
  uint16 *blImage;
  int16 delta;
  static uint8p8 btnbaselineVariance;

  /* see what the classifier says is on the sensor */
  for(i=0;i<buttonsCount;++i){
    hasObject |= (btnClass[i] == class_saturatedFinger ||
                  btnClass[i] == class_liftingSaturatedFinger ||
                  btnClass[i] == class_glovedFinger ||
                  btnClass[i] == class_thinGlovedFinger);
  }

  if (btnBaseline->baselineAcquired && (btnFrame != NULL) && !hasError){
    //Energy Ratio Check
    blImage = btnBaseline ->estimate;
    for(i = 0;i <buttonsCount;++i){
      if(btnconfig.buttonsDataType == dataType_abs){
        delta = *btnFrame - *blImage;
      }else{  //btnconfig.buttonsDataType == dataType_trans
        delta = *blImage - *btnFrame;
      }
      ++btnFrame;
      ++blImage;
      if(delta >0){
        posSum += (uint16)delta;
      }else{
        negSum += (uint16)(-delta);
      }
    }
    if((negSum + posSum > buttonsCount * btnNoiseFloor) &&
       (negSum > (btnEnergyRatio * posSum >>8)))
      hasError = 1;
    //Baseline Variance Check, usually btnStartupBaselineVariance should be 0
    btnbaselineVariance = calculateBaselineVariance(btnBaseline->estimate);
    if(btnbaselineVariance > btnStartupBaselineVariance + bntMaxIncreasedVariance){
      hasError = 1;
    }
  }
  *objectsPresent = hasObject;
  *errorsPresent = hasError;
}

static relaxCommand_t btnbaselineManager_manage(uint16 objectsPresent,uint16 errorsPresent,uint16 forceFastRelax,uint16 relaxationDisabled,uint16 frameTime_ms)
{
  relaxCommand_t relaxCommand;

  switch (btnBaselineState)
  {
    case state_thermal:
      if (errorsPresent){
        btntimer_ms += frameTime_ms;
        if (btntimer_ms >= btnholdFastTransition_ms){
          btnBaselineState = state_fast;
          btntimer_ms = 0;
        }
      }else{
        btntimer_ms = 0;
      }
      if ((btnBaselineState != state_fast) && objectsPresent){
        btnBaselineState = state_frozen;
      }
      break;
    case state_frozen:
      if (!objectsPresent){
        btnBaselineState = state_thermal;
        btntimer_ms = 0;
      }else if (errorsPresent){
        btntimer_ms += frameTime_ms;
        if (btntimer_ms >= btnholdFastTransition_ms){
          btnBaselineState = state_fast;
          btntimer_ms = 0;
        }
      }else{
        btntimer_ms = 0;
      }
      break;
    case state_fast:
      if(objectsPresent && !errorsPresent){
        btnBaselineState = state_frozen;
        btntimer_ms = 0;
      }else if(btntimer_ms >= btnfastRelaxDuration_ms){
        btnBaselineState = objectsPresent ? state_frozen : state_thermal;
        btntimer_ms = 0;
      }else{
        btntimer_ms += frameTime_ms;  // time in fast
      }
      break;
    case state_rezero:
      btnBaselineState = state_fast;
      btntimer_ms = 0;  // time in fast
      break;
    case state_start:
      btnBaselineState = state_rezero;
      break;
  }
  if (forceFastRelax){
    btnBaselineState = state_fast;
    btntimer_ms = 0;
  }
  switch (btnBaselineState){
    case state_thermal:
      relaxCommand = relaxCommand_thermal;
      break;
    case state_frozen:
      relaxCommand = relaxCommand_frozen;
      break;
    case state_fast:
      relaxCommand = relaxCommand_fast;
      break;
    case state_rezero:
      relaxCommand = relaxCommand_rezero;
      break;
    default:
      relaxCommand = relaxCommand_fast;
      break;
  }
  if (relaxationDisabled && (relaxCommand == relaxCommand_thermal || relaxCommand == relaxCommand_fast)){
    relaxCommand = relaxCommand_frozen;
  }
  return relaxCommand;
}

static void btnbaselineUpdater_update(relaxCommand_t relaxCommand,uint16 frameTime_ms,uint16 *btnFrame,buttons0DBaseline_t *btnBaseline)
{
  uint16 i;
  uint16 nMax;
  uint16 *blImage;
  int16 delta;
  uint32 gain;
  uint16 correction;
  switch (relaxCommand){
    case relaxCommand_thermal:
      btnthermal_update_ms += frameTime_ms * btnthermal_update_speed;
      if (btnthermal_update_ms >= btnthermalUpdateInterval_ms){
        nMax = (btnthermal_update_speed * btnthermal_update_ms) / btnthermalUpdateInterval_ms;
        blImage = btnBaseline->estimate;
        for(i=0;i<buttonsCount;++i){
          delta = *blImage - *btnFrame;
          if(delta > 0){
            *blImage -= B_min(nMax,(uint16)delta);
          }else{
            *blImage += B_min(nMax,(uint16)(-delta));
          }
          ++blImage;
          ++btnFrame;
        }
        btnthermal_update_ms %= btnthermalUpdateInterval_ms;
      }
      break;
    case relaxCommand_frozen:
      btnthermal_update_ms = 0;
      break;
    case relaxCommand_fast:
      /* approximate ln(2) / btnfastHalflife_ms as 0p16
      http://www.wolframalpha.com/input/?i=Log%5B2%5D+*+2%5E16 */
      gain = 45426u * (uint32) frameTime_ms / btnfastHalflife_ms;  // 16p16
      if (gain >= 0xFFFF){
        gain = 0xFFFF;
      }
      blImage = btnBaseline->estimate;
      for(i=0;i<buttonsCount;++i){
        delta = *blImage - *btnFrame;
        if(delta > 0){
          correction = ((uint32) gain * (uint16) delta + 0xFFFF) >> 16; // 0p16 * 16p0 -> 16p0
          *blImage -= correction;
        }else{
          correction = ((uint32) gain * (uint16) (-delta) + 0xFFFF) >> 16; // 0p16 * 16p0 -> 16p0
          *blImage += correction;
        }
        ++blImage;
        ++btnFrame;
      }
      btnthermal_update_ms = 0;
      break;
    case relaxCommand_rezero:
      btnBaseline->baselineAcquired = 1;
      for(i=0;i<buttonsCount;++i){
        btnBaseline->estimate[i] = btnFrame[i];
      }
      btnStartupBaselineVariance = calculateBaselineVariance(btnBaseline->estimate);
      btnthermal_update_ms = 0;
      break;
  }
}

uint8p8 calculateBaselineVariance(uint16 *btnBaseline)
{
  uint16 i;
  uint16 min,max;
  uint8p8 stdVariance;

  min = btnBaseline[0];
  max = btnBaseline[0];
  for(i=1;i<buttonsCount;++i){
    if(btnBaseline[i]<min){
      min = btnBaseline[i];
    }
    if(btnBaseline[i]>max){
      max = btnBaseline[i];
    }
  }
  stdVariance = ((uint32)(max-min)<<8)/(max+min);
  return stdVariance;
}

#endif // CONFIG_AMP_BUTTON
