// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: baseline_updater.c
// Description: Adjusts the baseline to compensate for thermal drift and slow
//              environmental changes, and also to remove false artefacts caused
//              by baseline acquisition with moisture or object on the sensor
// $Id:$

/* =================================================================
   MODULE INCLUDES
==================================================================*/

#include "ifp_common.h"
#include "ifp_string.h"
#include "baseline_updater.h"
#include "ifp_vector_util.h"

/* =================================================================
   MODULE MACROS
==================================================================*/

#define MAX_GAIN 64881u  // 0.99 * (1 << 16)

#define min(a, b) (((a) > (b)) ? (b) : (a))

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static uint16 thermal_update_ms;  //  time in thermal mode modulo update interval
static uint16 thermal_update_speed;

// configuration knobs
static baselineUpdaterConfig_t buConfig;

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* local function prototypes */
static void relaxNCounts(sensorParams_t *sensorParams, uint16 *rawImage, uint16 nMax, imageBaseline_t *baseline);
static void applyExponentialDamping(sensorParams_t *sensorParams, uint16 frameTime_ms, uint16 *rawImage, imageBaseline_t *baseline);
static void _applyExponentialDamping(uint16 rxCount, uint16 txCount, uint16 clippedGain, uint16 *rawImage, imageBaseline_t *baseline);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* ---------------------------------------------------------------------
Name: relaxNCounts
Purpose: Clip the delta image to max magnitude nMax, then subtract from blEstimate
Inputs: raw image, baseline image
Outputs: None
Effects: Modifies baseline estimate in-place
Note: Internal to this file only.
---------------------------------------------------------------------- */
static void relaxNCounts(sensorParams_t *sensorParams, uint16 *rawImage, uint16 nMax, imageBaseline_t *baseline)
{
  uint16 *blImage = baseline->estimate;
  uint16 rowSkip = MAX_RX - sensorParams->rxCount;
  uint16 i = sensorParams->txCount;

  do
  {
    uint16 j = sensorParams->rxCount;
    do
    {
      int16 delta = *blImage - *rawImage;
      if (delta > 0)
      {
        *blImage -= min(nMax, (uint16) delta);
      }
      else
      {
        *blImage += min(nMax, (uint16) -delta);
      }
      blImage++;
      rawImage++;
    } while(--j);

    blImage += rowSkip;
    rawImage += rowSkip;
  } while(--i);
}

/* ---------------------------------------------------------------------
Name: applyExponentialDamping
Purpose: Clip the delta image to max magnitude 1, then subtract from blEstimate
Inputs: frameTime, raw image, baseline image
Outputs: None
Effects: Modifies blEstimate in-place
Note: Internal to this file only.
---------------------------------------------------------------------- */
void applyExponentialDamping(sensorParams_t *sensorParams, uint16 frameTime_ms, uint16 *rawImage, imageBaseline_t *baseline)
{
  /* approximate ln(2) / fastHalflife_ms as 0p16
     http://www.wolframalpha.com/input/?i=Log%5B2%5D+*+2%5E16 */
  uint32 gain = 45426u * (uint32) frameTime_ms / buConfig.fastHalflife_ms;  // 16p16
  /* clip gain below unity to prevent amplification */
  uint16 clippedGain;
  if (gain >= 0xFFFF)
  {
    gain = 0xFFFF;
  }
  clippedGain = gain;
  _applyExponentialDamping(sensorParams->rxCount, sensorParams->txCount, clippedGain, rawImage, baseline);
}

/* ---------------------------------------------------------------------
Name: _applyExponentialDamping
Purpose: Subtracts the clipped gain from baseline estimate image.
Inputs: clipped gain, raw image, baseline image
Outputs: None
Effects: Modifies blEstimate in-place
Note: This helper function ensures good register allocation for applyExponentialDamping()
      inner loop.
---------------------------------------------------------------------- */
void _applyExponentialDamping(uint16 rxCount, uint16 txCount, uint16 clippedGain, uint16 *rawImage, imageBaseline_t *baseline)
{
  uint16 *blImage = baseline->estimate;
  uint16 rowSkip = MAX_RX - rxCount;
  uint16 i = txCount;

  do
  {
    uint16 j = rxCount;
    do
    {
      int16 delta = *blImage - *rawImage;
      if (delta > 0)
      {
        uint16 correction = ((uint32) clippedGain * (uint16) delta + 0xFFFF) >> 16; // 0p16 * 16p0 -> 16p0
        *blImage -= correction;
      }
      else
      {
        uint16 correction = ((uint32) clippedGain * (uint16) (-delta) + 0xFFFF) >> 16; // 0p16 * 16p0 -> 16p0
        *blImage += correction;
      }
      blImage++;
      rawImage++;
    } while(--j);

    blImage += rowSkip;
    rawImage += rowSkip;
  } while(--i);
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: baselineUpdater_init()
Purpose: Initialize the module.
Inputs:
Outputs:
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void baselineUpdater_init(void)
{
  thermal_update_ms = 0;
  thermal_update_speed = 1;
}

/* -----------------------------------------------------------------
Name: baselineUpdater_reinit()
Purpose: Re-initialize the Baseline Estimate.
Inputs:
Outputs:
Effects: None.
Notes: Resets baseline state to 'start'
Example: None.
----------------------------------------------------------------- */
void baselineUpdater_reinit(void)
{
  baselineUpdater_init();
}

/* -----------------------------------------------------------------
Name: baselineUpdater_configure()
Purpose: Configure the Baseline Updater module.
Inputs: thermalUpdateInterval_ms   - time between 1 LSB for slow relaxations
        fastHalflife_ms            - decay half-life of deltaImage in fast
                                     relaxation
Outputs: None
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void baselineUpdater_configure(baselineUpdaterConfig_t *inConfig)
{
  buConfig = *inConfig;
  thermal_update_speed = inConfig->baselineUpdateSpeed;
}

/* -----------------------------------------------------------------
Name: baselineUpdater_removeBaseline(rawImage, deltaImage)
Purpose: Removes the baseline from the raw image to create the delta image
Inputs: raw image
Outputs: delta image
Effects: None.
Notes: Leaves the delta image with its 1 pixel 0-padding on all edges untouched.
       deltaImage is an array of size (MAX_TX+2) * (MAX_RX+1) + 1.
Example: None.
------------------------------------------------------------------- */
void baselineUpdater_remove(sensorParams_t *sensorParams, uint16 *rawImage, imageBaseline_t *baseline, int16 *deltaImage)
{
  uint16 txCount = sensorParams->txCount;
  uint16 rxCount = sensorParams->rxCount;

  if (baseline->acquired && rxCount && txCount)
  {
    uint16 *blPtr = baseline->estimate;
    subtractBaseline(rawImage, blPtr, deltaImage, rxCount, txCount);
        }
        else
        {
    memset16(deltaImage, 0, (MAX_TX + 2) * (MAX_RX + 1) + 1);
  }
}

/* -----------------------------------------------------------------
Name: baselineUpdater_update
Purpose: Adjust baseline to compensate for drift, hold if an object is on the sensor,
         or damp away detected errors.
Inputs: relax command (relaxCommand_t enum), time since last frame (ms), raw image, image baseline
Outputs: None
Effects: Adjusts the baseline in-place.
Notes: Assumes deltaImage has a 1 pixel padding on all edges
Example: None.
----------------------------------------------------------------- */
void baselineUpdater_update(sensorParams_t *sensorParams, uint16 relaxCommand, uint16 frameTime_ms, uint16 *rawImage, imageBaseline_t *baseline)
{
  /* update baseline */
  switch (relaxCommand)
  {
    case relaxCommand_thermal:
      /* mostly 0 with a +/- 1 correction every so often; allow more if long sampling times like during doze */
      thermal_update_ms += (frameTime_ms * thermal_update_speed);
      if (thermal_update_ms >= buConfig.thermalUpdateInterval_ms)
      {
        relaxNCounts(sensorParams, rawImage, (uint16) (thermal_update_ms * thermal_update_speed) / buConfig.thermalUpdateInterval_ms, baseline);
        thermal_update_ms %= buConfig.thermalUpdateInterval_ms;
        baseline->modified = 1;  // true
      }
      else
      {
        baseline->modified = 0;  // false
      }
      break;
    case relaxCommand_frozen:
      thermal_update_ms = 0;
      baseline->modified = 0;  // false
      break;
    case relaxCommand_fast:
      applyExponentialDamping(sensorParams, frameTime_ms, rawImage, baseline);
      thermal_update_ms = 0;
      baseline->modified = 1;  // true
      break;
    case relaxCommand_rezero:
      memcpy16(baseline->estimate, rawImage, MAX_RX * MAX_TX);
      baseline->acquired = 1;
      thermal_update_ms = 0;
      baseline->modified = 1;  // true
      break;
  }
}
