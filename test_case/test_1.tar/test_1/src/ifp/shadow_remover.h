// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
#ifndef _SHADOW_REMOVER_H
#define _SHADOW_REMOVER_H

#include "ifp_common.h"

#if CONFIG_HAS_SHADOW_REMOVER
void shadowRemover_configure(shadowRemoverConfig_t *config);
void shadowRemover_remove(int16* deltaImage,
                          sensorParams_t* sensorParams);
#else
ATTR_INLINE void shadowRemover_configure(ATTR_UNUSED shadowRemoverConfig_t *config) {};
ATTR_INLINE void shadowRemover_remove(ATTR_UNUSED int16* deltaImage,
                                             ATTR_UNUSED sensorParams_t* sensorParams) {};
#endif // CONFIG_HAS_SHADOW_REMOVER

#endif  // _SHADOW_REMOVER_H
