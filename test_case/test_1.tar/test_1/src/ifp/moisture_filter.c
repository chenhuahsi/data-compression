/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2014  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

  $Id$
----------------------------------------------------------------- */

#include "ifp_common.h"

#if CONFIG_HAS_MOISTURE

#include "ifp_string.h"
#include "ifp_bit_manipulation.h"
#include "moisture_filter.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

#define MAX_PROFILE_PEAKS 5

/* =================================================================
   MODULE TYPES
==================================================================*/

typedef struct
{
  uint16 location;
  int16 amplitude;
  uint16 valleyPosL;
  uint16 valleyPosR;
} peakAttribute_t;


typedef struct
{
  peakAttribute_t peaks[MAX_PROFILE_PEAKS];
} peakList_t;

typedef struct
{
  int16 minAmplitude;
  uint16 peakCount;
  peakList_t peakList;
} sortedProfilePeakList_t;

typedef struct
{
  uint16 begin;
  uint16 end;
} limits_t;

typedef struct
{
  limits_t row;
  limits_t col;
} ROI_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static moistureFilterConfig_t config;

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/
static uint16 maxIndex(int16 *array, uint16 length);
static uint16 minIndex(int16 *array, uint16 length);
static uint16 isLocalMax(int16 *deltaProfile, uint16 idx, int16 threshold, uint16 profileLength);
static uint16 isLocalMin(int16 *deltaProfile, uint16 idx, uint16 profileLength);
static void addPeak(sortedProfilePeakList_t *sortedPeaks, peakAttribute_t *peak);
static void findProminentPeaks(int16 *deltaProfile, uint16 profileLength, peakList_t *peakList);
static uint16 findLeftPeak(peakList_t *peakList, uint16 currentIndex);
static void profileSegment(int16 *deltaProfile, uint16 profileLength, int16 profilePeakThreshold, uint16 *numClumps, uint16 *labelProfile);
static limits_t get1DclumpEnds(uint16 *array, uint16 length, uint16 val);
static int32 calcROIenergy(int16 *deltaImage, ROI_t *region);
static uint16 isAboveNoiseFloor(int16 *deltaImage, ROI_t *region, sensorParams_t *sensorParams);
static objectBitmask_t findProminentClump(int16 *deltaImage, ROI_t *region, clumps_t *clumps, int16 clumpPeakThreshold, objectBitmask_t keepClumps);
static uint16 mergeClumps(clumps_t *clumps, int16 *deltaImage, uint16 clumpId1, uint16 clumpId2);
static uint16 check3x3Block(int16 *deltaPtr, int16 blockThreshold, uint16 N);
static void changeLabel(clumps_t *clumps, uint16 clumpId, uint16 newlabel);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: maxIndex
Purpose: Find the index of the maximum element of array
Inputs: pointer to a array, array length
Outputs: index of maximum of array
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------- */
static uint16 maxIndex(int16 *array, uint16 length)
{
  uint16 i;
  uint16 maxIdx = 0;
  int16 max = -32768;
  int16 *ptr = array;
  for (i = 0; i < length; i++)
  {
    int16 val = *ptr++;
    if (val > max)
    {
      max = val;
      maxIdx = i;
    }
  }
  return maxIdx;
}

/* -----------------------------------------------------------
Name: minIndex
Purpose: Find the index of the minimum element of array
Inputs: pointer to a array, array length
Outputs: index of minimum of array
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------- */
static uint16 minIndex(int16 *array, uint16 length)
{
  uint16 i;
  uint16 minIdx = 0;
  int16 min = 32767;
  int16 *ptr = array;
  for (i = 0; i < length; i++)
  {
    int16 val = *ptr++;
    if (val < min)
    {
      min = val;
      minIdx = i;
    }
  }
  return minIdx;
}

/* -----------------------------------------------------------
Name: isLocalMax
Purpose: Determines whether the pixel is a local maximum
Inputs: pointer to a pixel in the delta image,
        index of element, profile length
Outputs: true/false
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------- */
static uint16 isLocalMax(int16 *deltaProfile, uint16 idx, int16 threshold, uint16 profileLength)
{
  int16 v = deltaProfile[idx];
  if (idx == 0)
  {
    return (v > threshold) && (v > deltaProfile[1]);
  }
  else if (idx == profileLength-1)
  {
    return (v > threshold) && (v >= deltaProfile[idx-1]);
  }
  else
  {
    return (v > threshold) && (v >= deltaProfile[idx-1]) && (v > deltaProfile[idx+1]);
  }
}

/* -----------------------------------------------------------
Name: isLocalMin
Purpose: Determines whether the pixel is a local minimum
Inputs: pointer to a pixel in the delta image,
        index of element, profile length
Outputs: true/false
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------- */
static uint16 isLocalMin(int16 *deltaProfile, uint16 idx, uint16 profileLength)
{
  int16 v = deltaProfile[idx];
  if (idx == 0)
  {
    return v <= deltaProfile[idx+1];
  }
  else if (idx == profileLength-1)
  {
    return v < deltaProfile[idx-1];
  }
  else
  {
    return (v < deltaProfile[idx-1]) && (v <= deltaProfile[idx+1]);
  }
}

/* -----------------------------------------------------------
Name: addPeak
Purpose: Adds a peak to the sorted list of peaks
Inputs: sorted peaks structure; new peak to be added
Outputs: sorted peaks structure
Effects: None.
Notes: Peak list is ordered largest to smallest. If the peak
       passed in does not fit on the list, it will be dropped.
       If the list is already full but this is a larger peak
       than the minimum on the list, then the minimum on the
       list will be dropped to make room for the new peak.
----------------------------------------------------------- */
static void addPeak(sortedProfilePeakList_t *sortedPeaks, peakAttribute_t *peak)
{
  uint16 i;
  uint16 newPeakIdx;

  if (peak->amplitude <= sortedPeaks->minAmplitude)
  {
    return;
  }

  // This loop terminates either at the end of the list or at the
  // desired insertion point in the middle of the list
  for (i = 0; i < MAX_PROFILE_PEAKS; i++)
  {
    if (sortedPeaks->peakList.peaks[i].amplitude < peak->amplitude)
    {
      break;
    }
  }
  newPeakIdx = i;

    // make a hole for the new element
  if (sortedPeaks->peakCount >= MAX_PROFILE_PEAKS)
  {
    sortedPeaks->peakCount = MAX_PROFILE_PEAKS-1;
    sortedPeaks->minAmplitude = sortedPeaks->peakList.peaks[MAX_PROFILE_PEAKS-1].amplitude;
  }
  for (i = sortedPeaks->peakCount; i > newPeakIdx; i--)
  {
    sortedPeaks->peakList.peaks[i] = sortedPeaks->peakList.peaks[i-1];
  }
    // add the new element
  sortedPeaks->peakList.peaks[newPeakIdx] = *peak;
  sortedPeaks->peakCount++;
}

/* -----------------------------------------------------------
Name: findProminentPeaks
Purpose: Eliminates peaks that are not prominent
Inputs:  deltaProfile, profileLength, peakList
Outputs: Updates peakList
Effects: None.
Notes: None.
----------------------------------------------------------- */
static void findProminentPeaks(int16 *deltaProfile, uint16 profileLength, peakList_t *peakList)
{
  uint16 i, j, numPeaks = 0;
  for (i = 0; i < MAX_PROFILE_PEAKS; i++)
  {
    int16 lowestValleyL, lowestValleyR;
    int8p8 prominenceL, prominenceR;
    uint16 leftPeakPos = 0;
    uint16 rightPeakPos = profileLength - 1;
    peakAttribute_t peak = peakList->peaks[i];
    if (peak.amplitude > 0)
    {
      // Find the first peak on its left that is taller than current peak
      for (j = i-1; (int16) j >= 0; j--)
      {
        if (peakList->peaks[j].amplitude >= peak.amplitude)
        {
          leftPeakPos = peakList->peaks[j].location;
          break;
        }
      }
      lowestValleyL = deltaProfile[leftPeakPos + minIndex(&deltaProfile[leftPeakPos], (peak.location - leftPeakPos + 1))];

      // Find the first peak on its right that is taller than current peak
      for (j = i+1; j < MAX_PROFILE_PEAKS; j++)
      {
        if (peakList->peaks[j].amplitude >= peak.amplitude)
        {
          rightPeakPos = peakList->peaks[j].location;
          break;
        }
      }
      lowestValleyR = deltaProfile[peak.location + minIndex(&deltaProfile[peak.location], (rightPeakPos - peak.location + 1))];

      // Find the prominence of current peak
      prominenceL = (int8p8) ((int32) 256*(peak.amplitude - lowestValleyL)/peak.amplitude);
      prominenceR = (int8p8) ((int32) 256*(peak.amplitude - lowestValleyR)/peak.amplitude);

      // Retain a peak if both its left and right prominences >= 0.2. For peaks on the
      // edge, prominence on the non-edge side should be >= 0.2.
      if (((prominenceL >= 52) && (prominenceR >= 52)) ||    // 0.2 in int8p8
         ((leftPeakPos == 0) && (prominenceR >= 52)) ||
         ((rightPeakPos == profileLength-1) && (prominenceL >= 52)))
      {
        numPeaks++;
      }
      else
      {
        // Discard the peak by setting its amplitude to 0. Update the right valley position
        // of the peak on its left and the left valley position of the peak on its right
        peakList->peaks[i].amplitude = 0;
        if (numPeaks > 0)
        {
          uint16 leftPeakIndex = findLeftPeak(peakList, i);
          if (deltaProfile[peakList->peaks[leftPeakIndex].valleyPosR] > deltaProfile[peakList->peaks[i].valleyPosR])
          {
            peakList->peaks[leftPeakIndex].valleyPosR = peakList->peaks[i].valleyPosR;
          }
        }
        if (i < (MAX_PROFILE_PEAKS-1))
        {
          if (deltaProfile[peakList->peaks[i+1].valleyPosL] > deltaProfile[peakList->peaks[i].valleyPosL])
          {
            peakList->peaks[i+1].valleyPosL = peakList->peaks[i].valleyPosL;
          }
        }
      }
    }
  }
}

/* -----------------------------------------------------------
Name: findLeftPeak
Purpose: Finds the closest peak with non-zero amplitude to the left of the current peak
Inputs: peakList, index of current peak
Outputs: index of first non-zero amplitude peak on its left
Effects: None.
Notes: None.
----------------------------------------------------------- */
static uint16 findLeftPeak(peakList_t *peakList, uint16 currentIndex)
{
  int16 i;
  uint16 leftPeakIndex = currentIndex - 1;
  for (i = leftPeakIndex; i >= 0; i--)
  {
    if (peakList->peaks[i].amplitude > 0)
    {
      leftPeakIndex = i;
      break;
    }
  }
  return leftPeakIndex;
}

/* -----------------------------------------------------------
Name: profileSegment
Purpose: Performs segmentation on a delta profile
Inputs: delta profile, profile length, profilePeakThreshold
Outputs: number of 1D clumps, labelProfile
Effects: None.
Notes:
----------------------------------------------------------- */
static void profileSegment(int16 *deltaProfile,
                           uint16 profileLength,
                           int16 profilePeakThreshold,
                           uint16 *numClumps,
                           uint16 *labelProfile)
{
  uint16 i;
  peakAttribute_t peak;
  peakList_t peakList;
  sortedProfilePeakList_t sortedPeaks;
  uint16 peakCount;
  uint16 peakFlag = 0;
  int16 deltaProfileMin;


  // Initialize peakList, sortedPeaks, labelProfile, numClumps
  memset16(&peakList, 0, sizeof(peakList) / sizeof(uint16));
  memset16(&sortedPeaks, 0, sizeof(sortedPeaks) / sizeof(uint16));
  for (i = 0; i < MAX_PROFILE_PEAKS; i++)
  {
    peakList.peaks[i].valleyPosR = profileLength-1;
    sortedPeaks.peakList.peaks[i].valleyPosR = profileLength-1;
  }
  memset16(labelProfile, 0, profileLength);
  *numClumps = 0;

  // Apply DC shift to deltaProfile if it has negative values
  deltaProfileMin = deltaProfile[minIndex(deltaProfile, profileLength)];
  if (deltaProfileMin < 0)
  {
    for (i = 0; i < profileLength; i++)
    {
      deltaProfile[i] -= deltaProfileMin;
    }
  }

  // Find local maxima and minima
  peakCount = 0;
  for (i = 0; i < profileLength; i++)
  {
    if (isLocalMax(deltaProfile, i, profilePeakThreshold, profileLength))
    {
      if (++peakCount > MAX_PROFILE_PEAKS)
      {
        break;
      }
      peakFlag = 1;
      peakList.peaks[peakCount-1].location = i;
      peakList.peaks[peakCount-1].amplitude = deltaProfile[i];
    }

    if (peakFlag)  // Ensure that every minimum corresponds to the maximum on its left
    {
      if (isLocalMin(deltaProfile, i, profileLength))
      {
        peakList.peaks[peakCount-1].valleyPosR = i;
        if (peakCount < MAX_PROFILE_PEAKS)
        {
          peakList.peaks[peakCount].valleyPosL = i;
        }
        peakFlag = 0;
      }
    }
  }

  if (peakCount > 0)
  {
    // Eliminate less prominent peaks
    if (peakCount > 1)
    {
      findProminentPeaks(deltaProfile, profileLength, &peakList);
    }

    // Add the peaks to sortedPeaks
    for (i = 0; i < MAX_PROFILE_PEAKS; i++)
    {
      peak = peakList.peaks[i];
      if (peak.amplitude > profilePeakThreshold)
      {
        addPeak(&sortedPeaks, &peak);
      }
    }

    // Flood fill
    for (i = 0; i < MAX_PROFILE_PEAKS; i++)
    {
      int16 localFillThreshold;
      peak = sortedPeaks.peakList.peaks[i];
      localFillThreshold = profilePeakThreshold > (peak.amplitude >> 2) ? profilePeakThreshold : (peak.amplitude >> 2);

      if (peak.amplitude > localFillThreshold)
      {
        int16 j;
        uint16 peakIdx = peak.location;

        // If peak pixel has not been labeled already, label it
        if (labelProfile[peakIdx] == 0)
        {
          labelProfile[peakIdx] = i+1;
        }

        // Flood fill right neighbors
        j = peakIdx + 1;
        while ((j <= (int16) peak.valleyPosR) && (deltaProfile[j] > localFillThreshold))
        {
          if (labelProfile[j] == 0)
          {
            labelProfile[j] = i+1;
          }
          j++;
        }

        // Flood fill left neighbors
        j = peakIdx - 1;
        while ((j >= (int16) peak.valleyPosL) && (deltaProfile[j] > localFillThreshold))
        {
          if (labelProfile[j] == 0)
          {
            labelProfile[j] = i+1;
          }
          j--;
        }
      }
    }

    *numClumps = labelProfile[maxIndex((int16 *) labelProfile, profileLength)];
  }
}

/* -----------------------------------------------------------
Name: get1DclumpEnds
Purpose: Given an array containing a contiguous block of locations with value val,
         this function returns the start and end indices of this block, with
         deltaImage zero-padding taken into account.
         This function is useful in iterating over a delta or label image
         based on 1D segmentation.
Outputs: Returns the start and end indices in limits_t struct
Effects: None.
Notes: None.
----------------------------------------------------------- */
static limits_t get1DclumpEnds(uint16 *array, uint16 length, uint16 val)
{
  uint16 i;
  uint16 started = 0;
  limits_t limits;

  for (i = 0; i < length; i++)
  {
    if (array[i] == val)
    {
      if (!started)
      {
        limits.begin = i + 1;
        started = 1;
      }

      if (started)
      {
        limits.end = i + 1;
      }
    }
  }
  return limits;
}

/* -----------------------------------------------------------
Name: calcROIenergy
Purpose: Finds the sum of positive pixels in a region of interest in the delta image
Inputs:  delta image, region of interest
Outputs: sum of positive pixels in the region
Effects: None.
Notes: None.
----------------------------------------------------------- */
static int32 calcROIenergy(int16 *deltaImage, ROI_t *region)
{
  uint16 i, j;
  int32 sum = 0;
  for (i = region->row.begin; i <= region->row.end; i++)
  {
    for (j = region->col.begin; j <= region->col.end; j++)
    {
      int16 delta = deltaImage[i*(MAX_RX+1)+j];
      if (delta > 0) sum += delta;
    }
  }
  return sum;
}


/* -----------------------------------------------------------
Name: isAboveNoiseFloor
Purpose: Checks if every pixel in a region of interest in the delta image is above -noise floor
Inputs:  delta image, region of interest, sensorParams
Outputs: true/false
Effects: None.
Notes: None.
----------------------------------------------------------- */
static uint16 isAboveNoiseFloor(int16 *deltaImage, ROI_t *region, sensorParams_t *sensorParams)
{
  uint16 i, j;
  for (i = region->row.begin; i <= region->row.end; i++)
  {
    for (j = region->col.begin; j <= region->col.end; j++)
    {
      if (deltaImage[i*(MAX_RX+1)+j] <= -sensorParams->noiseFloor_LSB)
        return 0;
    }
  }
  return 1;
}

/* -----------------------------------------------------------
Name: findProminentClump
Purpose: Finds the prominent clump in a region of interest in delta image
Inputs:  delta image, region of interest, clumps, clumpPeakThreshold, keepClumps
Outputs: Returns bitmask keepClumps.
Effects: None.
Notes: The metric clump area * peakHeight is evaluated for all the clumps in the ROI whose peak
       amplitude is greater than clumpPeakThreshold. Note that clump area here refers to number of
       clump pixels that lie in the ROI, not total number of pixels in clump. The clumps whose metric
       is greater than 25% of largest clump metric are merged.
       If 2 or more clumps in the ROI are merged, the bits associated with the merged clumps
       are reset in keepClumps.
----------------------------------------------------------- */
static objectBitmask_t findProminentClump(int16 *deltaImage,
                                          ROI_t *region,
                                          clumps_t *clumps,
                                          int16 clumpPeakThreshold,
                                          objectBitmask_t keepClumps)
{
  uint16 i, j;
  uint16 numPixels[MAX_OBJECTS];
  int32 metrics[MAX_OBJECTS];
  int32 metricThreshold = 0;
  uint16 mergeCount = 0;
  objectBitmask_t clumpsToMerge = 0;

  memset16(numPixels, 0, MAX_OBJECTS);
  memset16(metrics, 0, sizeof(metrics) / sizeof(uint16));

  for (i = region->row.begin; i <= region->row.end; i++)
  {
    for (j = region->col.begin; j <= region->col.end; j++)
    {
      uint16 label = clumps->labelImage[i*(MAX_RX+1)+j];
      if (label > 0)
      {
        numPixels[label-1]++;
      }
    }
  }

  if (numPixels[maxIndex((int16 *) numPixels, MAX_OBJECTS)] > 0)
  {
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      uint16 r = clumps->info[i].peakLocation.row;
      uint16 c = clumps->info[i].peakLocation.col;
      int16 peakAmp = deltaImage[r*(MAX_RX+1)+c];
      if (peakAmp > clumpPeakThreshold)
      {
        metrics[i] = (int32) numPixels[i] * peakAmp;
        if (metrics[i] > metricThreshold)
        {
          metricThreshold = metrics[i];
        }
      }
    }

    // Merge all clumps in the ROI whose metric > 25% of largest metric
    metricThreshold = metricThreshold >> 2;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (metrics[i] > metricThreshold)
      {
        mergeCount++;
        keepClumps = setBit(keepClumps, i);
        clumpsToMerge = setBit(clumpsToMerge, i);
      }
    }

    if (mergeCount > 1)
    {
      for (i = 0; i < MAX_OBJECTS; i++)
      {
        for (j = i+1; j < MAX_OBJECTS; j++)
        {
          if (isBitSet(clumpsToMerge, i) && isBitSet(clumpsToMerge, j))
           {
            uint16 discardClumpId = mergeClumps(clumps, deltaImage, i, j);
            keepClumps = clearBit(keepClumps, discardClumpId);
            clumpsToMerge = clearBit(clumpsToMerge, discardClumpId);
          }
        }
      }
    }
  }
  return keepClumps;
}

/* -----------------------------------------------------------
Name: mergeClumps
Purpose: Appends the clump with higher peak amplitude to the end of other clump
Inputs:  clumps, deltaImage, clumpId1, clumpId2
Outputs: label of clump to be discarded
Effects: None.
Notes: None.
----------------------------------------------------------- */
static uint16 mergeClumps(clumps_t *clumps, int16 *deltaImage, uint16 clumpId1, uint16 clumpId2)
{
  uint16 discardClumpId = MAX_OBJECTS;
  if (clumpId1 != clumpId2)
  {
    uint16 mergeClumpId;
    uint16 r1 = clumps->info[clumpId1].peakLocation.row;
    uint16 c1 = clumps->info[clumpId1].peakLocation.col;
    uint16 r2 = clumps->info[clumpId2].peakLocation.row;
    uint16 c2 = clumps->info[clumpId2].peakLocation.col;
    pixelIndex_t p;

    if (deltaImage[r1*(MAX_RX+1) + c1] < deltaImage[r2*(MAX_RX+1) + c2])
    {
      mergeClumpId = clumpId1;
      discardClumpId = clumpId2;
    }
    else
    {
      mergeClumpId = clumpId2;
      discardClumpId = clumpId1;
    }

    p = clumps->info[mergeClumpId].peakLocation; // peakLocation is always the last pixel in the list
    clumps->listImage[p.row*(MAX_RX+1) + p.col] = clumps->info[discardClumpId].firstPixel;

    // Overwrite labelImage for clumpId with mergeClumpId
    // ListImage for mergeClumpId has been updated above, so changeLabel() overwrites clumpId with mergeClumpId
    changeLabel(clumps, mergeClumpId, mergeClumpId+1);

    // Overwrite peak location of mergeClumpId with peak location of discardClumpId
    clumps->info[mergeClumpId].peakLocation = clumps->info[discardClumpId].peakLocation;
  }
  return discardClumpId;
}

/* -----------------------------------------------------------
Name: check3x3Block
Purpose: Checks if at least N pixels of a 3x3 block around a pixel including it are greater some threshold
Inputs:  pointer to a pixel in delta image, the threshold, number of pixels
Outputs: True if at least N pixels of a 3x3 block around a pixel including it are greater some threshold,
         False otherwise.
Effects: None.
Notes: None.
----------------------------------------------------------- */
static uint16 check3x3Block(int16 *deltaPtr, int16 blockThreshold, uint16 N)
{
  uint16 num = 0;
  deltaPtr -= MAX_RX+2;

  num += (deltaPtr[0]          > blockThreshold);
  num += (deltaPtr[1]          > blockThreshold);
  num += (deltaPtr[2]          > blockThreshold);
  num += (deltaPtr[MAX_RX+1]   > blockThreshold);
  num += (deltaPtr[MAX_RX+2]   > blockThreshold);
  num += (deltaPtr[MAX_RX+3]   > blockThreshold);
  num += (deltaPtr[2*MAX_RX+2] > blockThreshold);
  num += (deltaPtr[2*MAX_RX+3] > blockThreshold);
  num += (deltaPtr[2*MAX_RX+4] > blockThreshold);

  return num >= N;
}

/* -----------------------------------------------------------
Name: changeLabel
Purpose: Changes the label of clumps' labelImage at a given clumpId to newLabel
Inputs:  clumps, clumpId whose label needs to be changed, new label
Outputs: Updated clumps' labelImage
Effects: None.
Notes: None.
----------------------------------------------------------- */
static void changeLabel(clumps_t *clumps, uint16 clumpId, uint16 newlabel)
{
  pixelIndex_t p = clumps->info[clumpId].firstPixel;
  while (p.row != 0)
  {
    uint16 r = p.row;
    uint16 c = p.col;
    uint16 offset = r*(MAX_RX+1) + c;
    clumps->labelImage[offset] = newlabel;
    p = clumps->listImage[offset];
  }
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: moistureFilter_configure
Purpose: Configures moistureFilter parameters
Inputs: moistureFilter configuration struct
Outputs: None.
Effects: sets absXPenThreshold_LSB, absYPenThreshold_LSB,
         absXFingerThreshold_LSB, absYFingerThreshold_LSB, clumpPeakThreshold_pct
Notes: None.
----------------------------------------------------------- */
void moistureFilter_configure(moistureFilterConfig_t *cfg)
{
  config = *cfg;
}

/* -----------------------------------------------------------
Name: moistureFilter_filterClumps
Purpose: Filters clumps
Inputs: delta image, delta abs X and Y profiles X, sensor parameters, clumps
Outputs: Filtered clumps
Effects: None.
Notes: None.
----------------------------------------------------------- */
void moistureFilter_filterClumps(int16 *deltaImage,
                                 int16 *deltaXProfile,
                                 int16 *deltaYProfile,
                                 sensorParams_t *sensorParams,
                                 clumps_t *clumps)
{
  int16 maxDeltaXProfile = deltaXProfile[maxIndex(deltaXProfile, sensorParams->rxCount)];
  int16 maxDeltaYProfile = deltaYProfile[maxIndex(deltaYProfile, sensorParams->txCount)];
  objectBitmask_t keepClumps = 0;

  if ((maxDeltaXProfile > config.absXPenThreshold_LSB) && (maxDeltaYProfile > config.absYPenThreshold_LSB))
  {
    uint16 i, j, maxPeakIdx, numXclumps, numYclumps;
    int16 clumpPeakThreshold;
    uint16 labelProfileX[MAX_ABS_RX], labelProfileY[MAX_ABS_TX];
    int32 roiEnergy[MAX_PROFILE_PEAKS*MAX_PROFILE_PEAKS];
    ROI_t ROIs[MAX_PROFILE_PEAKS*MAX_PROFILE_PEAKS];
    uint16 ROIcount = 0;
    int32 roiEnergyThreshold = 0;

    // Initialize roiEnergy, ROIs, labelProfiles
    memset16(roiEnergy, 0, sizeof(roiEnergy) / sizeof(uint16));
    memset16(ROIs, 0, sizeof(ROIs) / sizeof(uint16));

    // Detect fingers
    // Segment profiles
    profileSegment(deltaXProfile, sensorParams->rxCount, config.absXFingerThreshold_LSB, &numXclumps, labelProfileX);
    profileSegment(deltaYProfile, sensorParams->txCount, config.absYFingerThreshold_LSB, &numYclumps, labelProfileY);

    // Find the height of the tallest peak in the delta image
    maxPeakIdx = (MAX_RX + 1) + maxIndex(deltaImage + (MAX_RX + 1), sensorParams->txCount * (MAX_RX + 1));
    clumpPeakThreshold = (int16) (((int32) config.clumpPeakThreshold_pct * deltaImage[maxPeakIdx] + 255)/256);

    // Store energy of each ROI
    for (i = 0; i < numXclumps; i++)
    {
      for (j = 0; j < numYclumps; j++)
      {
        ROIs[ROIcount].col = get1DclumpEnds(labelProfileX, sensorParams->rxCount, i+1);
        ROIs[ROIcount].row = get1DclumpEnds(labelProfileY, sensorParams->txCount, j+1);
        roiEnergy[ROIcount] = calcROIenergy(deltaImage, &ROIs[ROIcount]);
        if (roiEnergy[ROIcount] > roiEnergyThreshold)
        {
          roiEnergyThreshold = roiEnergy[ROIcount];
        }
        ROIcount++;
      }
    }
    // Set roiEnergyThreshold to 0.15 * max delta energy among the ROIs
    roiEnergyThreshold = (38 * roiEnergyThreshold) >> 8;

    // Find prominent clump in each ROI
    for (i = 0; i < ROIcount; i++)
    {
      if (roiEnergy[i] > roiEnergyThreshold)
      {
        keepClumps = findProminentClump(deltaImage, &ROIs[i], clumps, clumpPeakThreshold, keepClumps);
      }
    }

    // If no fingers are found, detect pens
    if (countSetBits(keepClumps) == 0)
    {
      // Segment profiles
      profileSegment(deltaXProfile, sensorParams->rxCount, config.absXPenThreshold_LSB, &numXclumps, labelProfileX);
      profileSegment(deltaYProfile, sensorParams->txCount, config.absYPenThreshold_LSB, &numYclumps, labelProfileY);

      // Find prominent clump in each ROI
      for (i = 0; i < numXclumps; i++)
      {
        ROI_t roi;
        roi.col = get1DclumpEnds(labelProfileX, sensorParams->rxCount, i+1);
        for (j = 0; j < numYclumps; j++)
        {
          roi.row = get1DclumpEnds(labelProfileY, sensorParams->txCount, j+1);
          if (isAboveNoiseFloor(deltaImage, &roi, sensorParams))
          {
            keepClumps = findProminentClump(deltaImage, &roi, clumps, clumpPeakThreshold, keepClumps);
          }
        }
      }

      // Perform spatial checks
      if (countSetBits(keepClumps) > 0)
      {
        for (i = 0; i < MAX_OBJECTS; i++)
        {
          if (isBitSet(keepClumps, i))
          {
            uint16 r = clumps->info[i].peakLocation.row;
            uint16 c = clumps->info[i].peakLocation.col;
            uint16 peakOffset = r*(MAX_RX+1) + c;
            if ((!check3x3Block(&deltaImage[peakOffset], sensorParams->noiseFloor_LSB, 4)) &&
               (!check3x3Block(&deltaImage[peakOffset], -sensorParams->noiseFloor_LSB, 9)))
            {
              keepClumps = clearBit(keepClumps, i);
            }
          }
        }
      }
    }
  }

  // Filter clumps
  {
    uint16 i;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (!isBitSet(keepClumps, i))
      {
        changeLabel(clumps, i, 0);
        memset16(&clumps->info[i], 0, sizeof(clumps->info[0]) / sizeof(uint16));
      }
    }
  }
}

/* -----------------------------------------------------------
Name: moistureFilter_processClassifications
Purpose: Suppresses small objects, overwrites palms with fingers
Inputs: trackedObjects, classifications
Outputs: Overwrite classifications
Effects: None.
Notes: None.
----------------------------------------------------------- */
void moistureFilter_processClassifications(trackedObject_t *trackedObjects, classification_t *classifications)
{
  uint16 clumpId, eldest;

  for (clumpId = 1; clumpId <= MAX_OBJECTS; clumpId++)
  {
    uint16 trackInd;
    trackedObject_t *currTrack;
    classification_t *classification;
    for (trackInd = 0, currTrack = trackedObjects; trackInd < MAX_OBJECTS; trackInd++, currTrack++)
    {
      if (currTrack->clumpId == clumpId) break;
    }

    if (trackInd < MAX_OBJECTS)
    {
      classification = &classifications[trackInd];
      // Moisture often makes touches bigger, so turn palms into fingers.
      // We know more than the classifier knows, so override classifications.
      if ((classification->touchType == touchType_palm) ||
          (classification->touchType == touchType_baselineError))
      {
        classification->touchType = touchType_finger;
        classification->touchFlag = 1;
      }
    }
  }

  // For touches *after the first one*, forbid pens and generally
  // delay reports for greater confidence. First touch is always
  // saturated finger or palm.
  eldest = MAX_OBJECTS;
  {
    uint16 maxAge = 0;
    uint16 trackInd;
    trackedObject_t *track = trackedObjects;
    for (trackInd = 0; trackInd < MAX_OBJECTS; trackInd++, track++)
    {
      if (track->trackedFrames > maxAge)
      {
        maxAge = track->trackedFrames;
        eldest = trackInd;
      }
    }
  }
  for (clumpId = 1; clumpId <= MAX_OBJECTS; clumpId++)
  {
    uint16 trackInd;
    trackedObject_t *currTrack;
    for (trackInd = 0, currTrack = trackedObjects; trackInd < MAX_OBJECTS; trackInd++, currTrack++)
    {
      if (currTrack->clumpId == clumpId) break;
    }
    if (trackInd < MAX_OBJECTS)
    {
      if (trackInd == eldest)
      {
        if (currTrack->trackedFrames <= 1)
        {
          classifications[trackInd].touchFlag = 0;
        }
      }
      else if ((classifications[trackInd].touchType == touchType_smallObject) ||
               (currTrack->trackedFrames <= 5))
      {
        classifications[trackInd].touchFlag = 0;
      }
    }
  }
}

#endif // CONFIG_HAS_MOISTURE
