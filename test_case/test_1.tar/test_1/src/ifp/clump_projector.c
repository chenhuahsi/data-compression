/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

  Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
   (408) 454-5100

----------------------------------------------------------------- */

#include "ifp_common.h"
#include "ifp_string.h"
#include "ifp_vector_util.h"
#include "clump_projector.h"

static uint8p8 getPixelFraction(int16 u, int16 minSplit, int16 maxSplit);

static uint8p8 getPixelFraction(int8p8 u, int8p8 minSplit, int8p8 maxSplit)
{
  int8p8 frac;

  if (u >= minSplit + 0x80 && u <= maxSplit - 0x80)
  {
    frac = 0x100;
  }
  else if (u <= minSplit - 0x80 || u >= maxSplit + 0x80)
  {
    frac = 0;
  }
  else
  {
    int8p8 lowFrac = (u + 0x80) - minSplit;
    if (lowFrac < 0x100)
    {
      frac = lowFrac;
    }
    else
    {
      frac = maxSplit - (u - 0x80);
    }
  }

  return frac;
}

void clumpProjector_unrotateCoordinate(uint8p8 u, uint8p8 v, uint16 axis, uint8p8 *r, uint8p8 *c)
{
  switch(axis)
  {
  case splitAxis_0:
    *r = v + 0x100;
    *c = u + 0x100;
    break;
  case splitAxis_90:
    *r = u + 0x100;
    *c = v + 0x100;
    break;
  case splitAxis_45:
    *r = (0x100 + (MAX_TX<<8) + u - v)/2;
    *c = (0x300 - (MAX_TX<<8) + u + v)/2;
    break;
  case splitAxis_minus_45:
    *r = (0x100 + (MAX_TX<<8) - u + v)/2;
    *c = (0x300 - (MAX_TX<<8) + u + v)/2;
    break;
  default:
    *r = *c = 0;
  }
}

void clumpProjector_rotateCoordinate(uint16 r, uint16 c, uint16 axis, uint16 *u, uint16 *v)
{
  switch(axis)
  {
  case splitAxis_0:
    *u = c - 1;
    *v = r - 1;
    break;
  case splitAxis_90:
    *u = r - 1;
    *v = c - 1;
    break;
  case splitAxis_45:
    *u = r + c - 2;
    *v = MAX_TX - 1 - r + c;
    break;
  case splitAxis_minus_45:
    *u = MAX_TX - 1 - r + c;
    *v = r + c - 2;
    break;
  default:
    *u = *v = 0;
  }
}

uint16 clumpProjector_getProjectionUV(clumps_t *clumps, uint16 clumpId, int16 blobId, int16 *deltaImage,
                                      uint16 *projU, uint16 *projV
                                      #if CONFIG_HAS_CUSTOM_SPLITTER
                                      , sensorParams_t *sensorParams
                                      #endif
                                      )
{
  clumpInfo_t *info;
  splitAxis_t angle;
  pixelIndex_t p;
  uint16 pixelCount;

  info = &clumps->info[clumpId-1];

  memset16_large(projU, 0, MAX_RX + MAX_TX - 1);
  memset16_large(projV, 0, MAX_RX + MAX_TX - 1);

  angle = (splitAxis_t) info->splitAxis;
  p = info->firstPixel;

  if (angle == splitAxis_0 && (blobId == -1 || info->splitCount == 0))
  {
    // rebase arrays to allow 1-based r/c indexing
    uint16 *projUAdj = &projU[-1];
    uint16 *projVAdj = &projV[-1];
    pixelIndex_t *listImage = clumps->listImage;
    uint16 pixelCount16 = 0;
    while(p.row != 0)
    {
      uint16 r, c;
      uint16 offset;
      int16 delta;
      r = p.row;
      c = p.col;
      offset = r*(MAX_RX+1) + c;
      delta = deltaImage[offset];
      if (delta < 0) delta = -delta;  /* assumes pixels in clumps have always only one sign */
      projUAdj[c] += delta;
      projVAdj[r] += delta;
      pixelCount16++;
      p = listImage[offset];
    }
    pixelCount = ((pixelCount16 & 0xFF00) == 0) ? pixelCount16 : 0xFF;  // clip at 255
  }
  else
  {
    int8p8 minSplit, maxSplit;
    uint24p8 pixelCount32 = 0;
    pixelIndex_t *listImage = clumps->listImage;

    if (blobId > 0)
    {
      minSplit = clumps->splits[info->firstSplit + blobId - 1];
    }
    else
    {
      minSplit = -0x100;
    }

    if (blobId != (int16) info->splitCount && blobId != -1)
    {
      maxSplit = clumps->splits[info->firstSplit + blobId];
    }
    else
    {
      maxSplit = (MAX_TX + MAX_RX) << 8;
    }

    while(p.row != 0)
    {
      uint16 r, c, u, v;
      uint16 offset;
      int16 delta;
      uint8p8 frac;
      r = p.row;
      c = p.col;
      clumpProjector_rotateCoordinate(r, c, angle, &u, &v);
      frac = getPixelFraction((int8p8) u << 8, minSplit, maxSplit);
      offset = r*(MAX_RX+1) + c;
      delta = (frac == 0) ? 0 : deltaImage[offset];
      if (delta < 0) delta = -delta;  /* assumes pixels in clumps have always only one sign */
      if ((frac & 0xFF00) == 0) // (frac < 0x100)
      {
        delta = (uint16) (((uint32) delta * frac) >> 8);
      }
      projU[u] += delta;
      projV[v] += delta;
      pixelCount32 = pixelCount32 + frac;
      p = listImage[offset];
    }
    pixelCount32 = ((pixelCount32 + 0x80) >> 8);  // discard fraction
    pixelCount = ((pixelCount32 & 0xFFFFFF00) == 0) ? (pixelCount32 & 0xFF) : 0xFF;  // clip at 255
  }

  #if CONFIG_HAS_CUSTOM_SPLITTER
  if (sensorParams->Splitter.Enable && blobId == -1 && sensorParams->Splitter.Coefficient)
  {
    uint16 uv;
    for (uv = 0; uv < 2; uv++)
    {
      uint16 i, max1 = 0, max2 = 0, prev = 0;
      uint16 *p = projU;
      uint16 l = sensorParams->Splitter.Length_U;
      if (uv)
      {
        p = projV;
        l = sensorParams->Splitter.Length_V;
      }
      for (i = 0; i < l; i++)
      {
        if (max1 < p[i])
        {
          max1 = p[i];
        }
        uint16 next = i == l - 1 ? 0 : p[i + 1];
        uint16 curr = p[i];
        int32 v = (((uint32)curr * sensorParams->Splitter.Coefficient) >> 4) - (prev + next);
        p[i] = v > 0 ? v : 0;
        if (max2 < p[i])
        {
          max2 = p[i];
        }
        prev = curr;
      }
      if (max2)
      {
        for (i = 0; i < l; i++)
        {
          p[i] = ((uint32)p[i] * max1) / max2;
        }
      }
    }
  }
  #endif

  return (uint16) pixelCount;
}

uint16 clumpProjector_getProjectionXY(clumps_t *clumps, uint16 clumpId, int16 blobId, int16 *deltaImage,
                                      uint16 *projX, uint16 *projY)
{
  // rebase arrays to allow 1-based r/c indexing
  uint16 *projXAdj = &projX[-1];
  uint16 *projYAdj = &projY[-1];
  uint16 *labelImage = clumps->labelImage;
  pixelIndex_t *listImage = clumps->listImage;
  clumpInfo_t *info;
  pixelIndex_t p;
  uint16 pixelCount;

  info = &clumps->info[clumpId-1];

  memset16_large(projX, 0, MAX_RX);
  memset16_large(projY, 0, MAX_TX);

  p = info->firstPixel;

  if ((splitAxis_t) info->splitAxis == splitAxis_0 && (blobId == -1 || info->splitCount == 0))
  {
    uint16 pixelCount16 = 0;
    while(p.row != 0)
    {
      uint16 r, c;
      uint16 offset;
      int16 delta;
      r = p.row;
      c = p.col;
      offset = r*(MAX_RX+1) + c;
      delta = deltaImage[offset];
      if (delta < 0) delta = -delta;  /* assumes pixels in clumps have always only one sign */
      projXAdj[c] += delta;
      projYAdj[r] += delta;
      pixelCount16++;
      p = listImage[offset];
    }
    pixelCount = ((pixelCount16 & 0xFF00) == 0) ? pixelCount16 : 0xFF;  // clip at 255
  }
  else
  {
    splitAxis_t angle = (splitAxis_t) info->splitAxis;
    int8p8 minSplit, maxSplit;
    uint24p8 pixelCount32 = 0;
    if (blobId > 0)
    {
      minSplit = clumps->splits[info->firstSplit + blobId - 1];
    }
    else
    {
      minSplit = -0x100;
    }

    if (blobId != (int16) info->splitCount && blobId != -1)
    {
      maxSplit = clumps->splits[info->firstSplit + blobId];
    }
    else
    {
      maxSplit = (MAX_TX + MAX_RX) << 8;
    }

    switch(angle)
    {
        case splitAxis_0:
            while(p.row != 0)
            {
              uint16 r, c, u;
              uint16 offset;
              uint8p8 frac;
              int16 delta;
              r = p.row;
              c = p.col;
              u = c - 1;
              frac = getPixelFraction((int8p8) u << 8, minSplit, maxSplit);
              offset = r*(MAX_RX+1) + c;
              delta = (frac == 0) ? 0 : deltaImage[offset];
              if (delta != 0)
              {
                if (delta < 0) delta = -delta;
                if ((frac & 0xFF00) == 0) // (frac < 0x100)
                {
                  delta = (uint16) (((uint32) delta * frac) >> 8);
                }
                *(projXAdj + c) += delta;
                *(projYAdj + r) += delta;
                pixelCount32 += frac;
                labelImage[offset] |= (blobId << 8);
              }
              p = listImage[offset];
            }
            break;
        case splitAxis_90:
             while(p.row != 0)
            {
              uint16 r, c, u;
              uint16 offset;
              uint8p8 frac;
              int16 delta;
              r = p.row;
              c = p.col;
              u = r - 1;
              frac = getPixelFraction((int8p8) u << 8, minSplit, maxSplit);
              offset = r*(MAX_RX+1) + c;
              delta = (frac == 0) ? 0 : deltaImage[offset];
              if (delta != 0)
              {
                if (delta < 0) delta = -delta;
                if ((frac & 0xFF00) == 0) // (frac < 0x100)
                {
                  delta = (uint16) (((uint32) delta * frac) >> 8);
                }
                *(projXAdj + c) += delta;
                *(projYAdj + r) += delta;
                pixelCount32 += frac;
                labelImage[offset] |= (blobId << 8);
              }
              p = listImage[offset];
            }
            break;
      case splitAxis_45:
            while(p.row != 0)
            {
              uint16 r, c, u;
              uint16 offset;
              uint8p8 frac;
              int16 delta;
              r = p.row;
              c = p.col;
              u = r + c - 2;
              frac = getPixelFraction((int8p8) u << 8, minSplit, maxSplit);
              offset = r*(MAX_RX+1) + c;
              delta = (frac == 0) ? 0 : deltaImage[offset];
              if (delta != 0)
              {
                if (delta < 0) delta = -delta;
                if ((frac & 0xFF00) == 0) // (frac < 0x100)
                {
                  delta = (uint16) (((uint32) delta * frac) >> 8);
                }
                *(projXAdj + c) += delta;
                *(projYAdj + r) += delta;
                pixelCount32 += frac;
                labelImage[offset] |= (blobId << 8);
              }
              p = listImage[offset];
            }
            break;
      case splitAxis_minus_45:
            while(p.row != 0)
            {
              uint16 r, c, u;
              uint16 offset;
              uint8p8 frac;
              int16 delta;
              r = p.row;
              c = p.col;
              u = MAX_TX - 1 - r + c;
              frac = getPixelFraction((int8p8) u << 8, minSplit, maxSplit);
              offset = r*(MAX_RX+1) + c;
              delta = (frac == 0) ? 0 : deltaImage[offset];
              if (delta != 0)
              {
                if (delta < 0) delta = -delta;
                if ((frac & 0xFF00) == 0) // (frac < 0x100)
                {
                  delta = (uint16) (((uint32) delta * frac) >> 8);
                }
                *(projXAdj + c) += delta;
                *(projYAdj + r) += delta;
                pixelCount32 += frac;
                labelImage[offset] |= (blobId << 8);
              }
              p = listImage[offset];
            }
            break;
      default:
            break;
    }
    pixelCount32 = ((pixelCount32 + 0x80) >> 8);  // discard fraction
    pixelCount = ((pixelCount32 & 0xFFFFFF00) == 0) ? (uint16) pixelCount32 : 0xFF;  // clip at 255
  }

  return pixelCount;
}

uint16 clumpProjector_getBlobMax(clumps_t *clumps, uint16 clumpId, int16 blobId, int16 *deltaImage)
{
  clumpInfo_t *info = &clumps->info[clumpId-1];
  splitAxis_t angle = (splitAxis_t) info->splitAxis;
  pixelIndex_t p = info->firstPixel;
  int8p8 minSplit, maxSplit;
  pixelIndex_t *listImage = clumps->listImage;
  int16 blobMax = -32768;

  if (info->splitCount == 0 && blobId == 0)
  {
    pixelIndex_t peak = info->peakLocation;
    return deltaImage[peak.row * (MAX_RX + 1) + peak.col];
  }

  if (blobId > 0)
  {
    minSplit = clumps->splits[info->firstSplit + blobId - 1];
  }
  else
  {
    minSplit = -0x100;
  }

  if (blobId != (int16) info->splitCount && blobId != -1)
  {
    maxSplit = clumps->splits[info->firstSplit + blobId];
  }
  else
  {
    maxSplit = (MAX_TX + MAX_RX) << 8;
  }

  while(p.row != 0)
  {
    uint16 r, c, u, v;
    uint16 offset;
    int16 delta;
    uint8p8 frac;
    r = p.row;
    c = p.col;
    clumpProjector_rotateCoordinate(r, c, angle, &u, &v);
    frac = getPixelFraction((int8p8) u << 8, minSplit, maxSplit);
    offset = r*(MAX_RX+1) + c;
    delta = (frac == 0) ? 0 : deltaImage[offset];
    if (delta < 0) delta = -delta;  /* assumes pixels in clumps have always only one sign */
    if ((frac & 0xFF00) == 0) // (frac < 0x100)
    {
      delta = (uint16) (((uint32) delta * frac) >> 8);
    }
    if (delta > blobMax) blobMax = delta;
    p = listImage[offset];
  }
  return blobMax;
}
