// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------

#include "ifp_common.h"
#include "ifp_string.h"
#include "ifp_vector_util.h"
#include "hydra_util.h"

#include "calc2.h"

#include "image_frame_processor.h"
#include "anti_bending.h"
#include "baseline_checker.h"
#include "baseline_manager.h"
#include "baseline_updater.h"
#include "profile_baseline_updater.h"
#include "gain_compensator.h"
#include "shadow_remover.h"
#include "shadow_remover_AMP.h"
#include "lgm_manager.h"
#include "lgm_corrector.h"
#include "display_noise_remover.h"
#include "hybrid_display_noise_remover.h"
#include "muxRX_hybrid_display_noise_remover.h"
#include "muxTX_hybrid_display_noise_remover.h"
#include "moisture_detector.h"
#include "moisture_filter.h"
#include "moisture_filter_AMP.h"
#include "pen_recorrector.h"
#include "segmenter.h"
#include "filter_noise_blobs.h"
#include "circumscriber.h"
#include "clump_splitter.h"
#include "linear_swipe_splitter.h"
#include "tracker.h"
#include "classifier.h"
#include "unison_noise_remover.h"
#include "position_estimator.h"
#include "kalman_filter.h"
#include "land_lift_jitter_filter.h"
#include "coordinate_converter.h"
#include "position_reporter.h"
#include "adaptive_lgm.h"
#include "fist_reject.h"
#include "touch_buffer.h"
#include "buttons_0D.h"
#include "face_detect.h"
#include "extreme_noise_remover.h"
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
#include "metal_detection.h"
#endif
#include "row_column_noise_remover.h"
#include "single_finger.h"
#include "thick_glove.h"
#include "weak_object_filter.h"
#include "side_touch.h"
#include "abs_cmnr_filter.h"
#include "insystem_noise_mitigation.h"
#include "../knuckle.h"
#include "spatial_filter.h"
#if defined(__CHIMERA__)
#include "calc_hw.h"
#endif

/* =================================================================
   MODULE MACRO AND VARIABLE DEFINITIONS
==================================================================*/
static sensorParams_t mSensorParams;
static int16 mDeltaImage[(MAX_TX+2)*(MAX_RX+1)+1];
static int16 mDeltaXProfile[MAX_ABS_RX];
static int16 mDeltaYProfile[MAX_ABS_TX];
static imageBaseline_t imageBaseline;
static absXBaseline_t absXBaseline;
static absYBaseline_t absYBaseline;
static ifpActionFlags_t ifpActionFlags;

/* =================================================================
   MODULE STATIC FUNCTION DECLARATIONS
==================================================================*/
static void clearBaselines(void);

/* =================================================================
   MODULE STATIC FUNCTION DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: clearBaselines
Purpose: Clear baseline estimates and mark as unacquired
Inputs: None
Outputs: None
Effects: Updates in-place
Notes: None
Example: None.
----------------------------------------------------------------- */
static void clearBaselines(void)
{
  memset16(&imageBaseline, 0, sizeof(imageBaseline) / sizeof(uint16));
  memset16(&absXBaseline, 0, sizeof(absXBaseline) / sizeof(uint16));
  memset16(&absYBaseline, 0, sizeof(absYBaseline) / sizeof(uint16));
}

#if CONFIG_HAS_LINEAR_SWIPE_SPLITTER
/* -----------------------------------------------------------------
Name: getPeakLocation()
Purpose: Retrieves the peak pixel of the blob.
Inputs:  trackedObj      - the tracking info of the blob
         clumps          - the clumps
Outputs: None.
Return:  the peak pixel
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
static ATTR_INLINE pixelIndex_t getPeakLocation(trackedObject_t *trackedObj, clumps_t *clumps)
{
  clumpInfo_t *info = &clumps->info[trackedObj->clumpId - 1];

  if (info->splitCount == 0 || info->polarity != clumpPolarity_positive)
  {
    return info->peakLocation;
  }
  else
  {
    pixelIndex_t peak, pixel = info->firstPixel;
    uint16 label = (trackedObj->blobId << 8) | trackedObj->clumpId;
    int16 max = 0;
    while (pixel.row)
    {
      uint16 index = (MAX_RX + 1) * pixel.row + pixel.col;
      if (label == clumps->labelImage[index])
      {
        int16 delta = mDeltaImage[index];
        if (max < delta)
        {
          max = delta;
          peak = pixel;
        }
      }
      pixel = clumps->listImage[index];
    }
    return peak;
  }
}

/* -----------------------------------------------------------------
Name: getFirstPixel()
Purpose: Retrieves the first pixel of the blob.
Inputs:  trackedObj      - the tracking info of the blob
         clumps          - the clumps
Outputs: None.
Return:  the first pixel
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
static ATTR_INLINE pixelIndex_t getFirstPixel(trackedObject_t *trackedObj, clumps_t *clumps)
{
  clumpInfo_t *info = &clumps->info[trackedObj->clumpId - 1];

  if (info->splitCount == 0 || info->polarity != clumpPolarity_positive)
  {
    return info->firstPixel;
  }
  else
  {
    pixelIndex_t pixel = info->firstPixel;
    uint16 label = (trackedObj->blobId << 8) | trackedObj->clumpId;
    while (pixel.row)
    {
      uint16 index = (MAX_RX + 1) * pixel.row + pixel.col;
      if (label == clumps->labelImage[index])
      {
        break;
      }
      pixel = clumps->listImage[index];
    }
    return pixel;
  }
}

/* -----------------------------------------------------------------
Name: getNextPixel()
Purpose: Retrieves the next pixel of the blob.
Inputs:  pixel           - the current pixel
         clumps          - the clumps
Outputs: None.
Return:  the next pixel
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
static ATTR_INLINE pixelIndex_t getNextPixel(pixelIndex_t pixel, clumps_t *clumps)
{
  uint16 index = (MAX_RX + 1) * pixel.row + pixel.col;
  uint16 label = clumps->labelImage[index];
  pixel = clumps->listImage[index];
  while (pixel.row)
  {
    index = (MAX_RX + 1) * pixel.row + pixel.col;
    if (label == clumps->labelImage[index])
    {
      break;
    }
    pixel = clumps->listImage[index];
  }
  return pixel;
}
#endif // CONFIG_HAS_LINEAR_SWIPE_SPLITTER

/* ----------------------------------------------------------------------------
  Name:       lsbPos
  Purpose:    Find the bit index of the least significant bit that is set
              within a 16-bit value.
        NOTE: If the input is 0 this algorithm will return 15. It is up to the
              caller to worry about this.
  Inputs:     Value to examine.
  Outputs:    The bit position of the lsb that is set (0..15)
  Effects:
 ---------------------------------------------------------------------------- */
ATTR_INLINE uint16 lsbPos(uint16 val)
{
#if defined(__CHIMERA__)
  val = (-val) & val;
  asm volatile("        ffo     %[regA]  ; size == 1\n"  : [regA] "+a" (val));
  if (val & 0x8000) {
    val = 15;
  }
  return(val);
#else
  uint16 pos = 0;

  if ((val & 0x00FF) == 0) {
    pos += 8;
    val >>= 8;
  }
  if ((val & 0x000F) == 0) {
    pos += 4;
    val >>= 4;
  }
  if ((val & 0x0003) == 0) {
    pos += 2;
    val >>= 2;
  }
  if ((val & 0x0001) == 0) {
    pos += 1;
  }

  return (pos);
#endif
}

#if CONFIG_HAS_CORNER_SUPPRESSION
/* -----------------------------------------------------------------
Name:    suppressCorner()
Purpose: Suppresses spurious reports near the column #0 corners.
Inputs:  sensorPositions ... the sensor positions
         classifications ... the classification results
Outputs: classifications ... We set touchFlag = 0 to suppress the object.
Effects: Updates in-place
Notes:   None
Example: None.
----------------------------------------------------------------- */
static void suppressCorner(sensorPosition_t *sensorPositions, classification_t *classifications)
{
  if (mSensorParams.CornerSuppression.Enable)
  {
    uint16 i;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (classifications[i].touchFlag && classifications[i].touchType == touchType_finger)
      {
        uint16 row = sensorPositions[i].yPosition >> 8;
        uint16 col = sensorPositions[i].xPosition >> 8;
        if (row & 0x8000) row = 0;
        if (mSensorParams.txCount <= row) row = mSensorParams.txCount - 1;
        if (col & 0x8000) col = 0;
        if (mSensorParams.rxCount <= col) col = mSensorParams.rxCount - 1;
        if ((row == 0 || row == mSensorParams.txCount - 1) && col < mSensorParams.CornerSuppression.NumPixels)
        {
          int16 *delta = &mDeltaImage[(MAX_RX + 1) * (row + 1) + col + 1];
          int16 peak = *delta++;
          int16 max = peak;
          for (col++; col < mSensorParams.rxCount; col++, delta++)
          {
            if (max < *delta)
            {
              max = *delta;
            }
          }
          if (peak < (((int32)max * mSensorParams.CornerSuppression.Ratio) >> 8))
          {
            classifications[i].touchFlag = 0;
          }
        }
      }
    }
  }
}
#endif

#if CONFIG_HAS_METAL_SLUG_SUPPRESION
/* -----------------------------------------------------------------
Name: clearBaselines
Purpose: Clear baseline estimates and mark as unacquired
Inputs: None
Outputs: None
Effects: Updates in-place
Notes: None
Example: None.
----------------------------------------------------------------- */
static void suppressMetalSlug(clumps_t *clumps, classification_t *classifications, trackedObject_t *trackedObjPtr)
{
  static uint16 prevFingers;
  uint16 fingers = 0;
  if (mSensorParams.MetalSlug.Enable)
  {
    uint16 i, mask;
    for (i = 0, mask = 1; i < MAX_OBJECTS; i++, mask <<= 1)
    {
      if (classifications[i].touchFlag && classifications[i].touchType == touchType_finger)
      {
        fingers |= mask;
        if (prevFingers && !(prevFingers & mask))
        {
          uint16 size = 0;
          pixelIndex_t peak  = clumps->info[trackedObjPtr[i].clumpId - 1].peakLocation;
          int16 threshold = (uint16)(mDeltaImage[(MAX_RX + 1) * peak.row + peak.col] * mSensorParams.MetalSlug.PixelThreshold) >> 4;
          pixelIndex_t pixel = clumps->info[trackedObjPtr[i].clumpId - 1].firstPixel;
          while (pixel.row)
          {
            uint16 index = (MAX_RX + 1) * pixel.row + pixel.col;
            if (threshold < mDeltaImage[index])
            {
              size++;
            }
            pixel = clumps->listImage[index];
          }
          if (size <= mSensorParams.MetalSlug.MaxNumPixels)
          {
            classifications[i].touchFlag = 0;
          }
        }
      }
    }
  }
  prevFingers = fingers;
}
#endif

#if CONFIG_HAS_GRIP_SUPPRESSION_4
/* -----------------------------------------------------------------
Name: suppress_grip()
Purpose: Tries to suppress reporting the objects brought by gripping
Inputs:  clumps          - the clumps
         trackedObjPtr   - the object tracking information
         classifications - the classifications
Outputs: classifications - We clear touchFlag to suppress the object.
Effects: Updates in-place
Notes:   None
Example: None.
----------------------------------------------------------------- */
static void suppress_grip(clumps_t *clumps, trackedObject_t *trackedObjPtr, classification_t *classifications, hostPosition_t *hostPositions)
{
  static uint16 reported, suppressed[2];
  static uint16 delay[MAX_OBJECTS];
#if CONFIG_HAS_GLOVE_SUPPRESSION
  mSensorParams.grip4.Suppressing = 0;
#endif
  if (mSensorParams.grip4.Enable)
  {
    uint16 gripped = 0;
    if (mSensorParams.grip4.MinTotalWidth)
    {
      uint16 edge;
      for (edge = 0; edge < 2; edge++)
      {
        uint16 col, count = 0;
        int16 *delta = &mDeltaImage[(MAX_RX + 1) * (edge == 0 ? 1 : mSensorParams.txCount) + 1];
        for (col = 0; col < mSensorParams.rxCount; col++)
        {
          if (mSensorParams.grip4.MinSignalToMeasureWidth <= *delta)
          {
            count++;
          }
          delta++;
        }
        if (mSensorParams.grip4.MinTotalWidth <= count)
        {
          gripped |= 1 << edge;
        }
      }
    }

    uint16 i, mask;
    for (i = 0, mask = 1; i < MAX_OBJECTS; i++, mask <<= 1)
    {
      if (classifications[i].touchFlag
      #if CONFIG_HAS_LANDING_LARGE_FINGER_DROP
        && trackedObjPtr[i].clumpId
      #endif
      )
      {
        if ((classifications[i].touchType == touchType_finger || (mSensorParams.grip4.Glove && classifications[i].touchType == touchType_glove)) && !(reported & mask))
        {
          pixelIndex_t peak = getPeakLocation(&trackedObjPtr[i], clumps);
          if (
            (
               mSensorParams.grip4.MaybeInside
            || peak.row == 1
            || peak.row == mSensorParams.txCount
            )
            &&
            (
              mSensorParams.grip4.UnitsMin == 0
            || hostPositions[i].xPosition < mSensorParams.grip4.UnitsMin
            || mSensorParams.grip4.UnitsMax < hostPositions[i].xPosition
            )
          )
          {
            uint16 side = peak.row < mSensorParams.txCount / 2 ? 0 : 1;
            uint16 min_col, max_col;
            min_col = max_col = peak.col;
            if (mSensorParams.grip4.MinObjectWidth)
            {
              pixelIndex_t pixel = getFirstPixel(&trackedObjPtr[i], clumps);
              while (pixel.row)
              {
                uint16 index = (MAX_RX + 1) * pixel.row + pixel.col;
                if ((pixel.row == 1 || pixel.row == mSensorParams.txCount) && mSensorParams.grip4.MinSignalToMeasureWidth <= mDeltaImage[index])
                {
                  if (pixel.col < min_col)
                  {
                    min_col = pixel.col;
                  }
                  if (max_col < pixel.col)
                  {
                    max_col = pixel.col;
                  }
                }
                pixel = getNextPixel(pixel, clumps);
              }
            }

            if ((gripped & (1 << side))
            || mSensorParams.grip4.NarrowUnitsMin == 0
            || mSensorParams.grip4.NarrowObjectWidth < max_col - min_col + 1
            || hostPositions[i].xPosition < mSensorParams.grip4.NarrowUnitsMin
            || mSensorParams.grip4.NarrowUnitsMax < hostPositions[i].xPosition
            )
            {
              if ((suppressed[0] | suppressed[1]) & mask)
              {
                classifications[i].touchFlag = 0;
              }
              else if (delay[i] < mSensorParams.grip4.NumFrames)
              {
                delay[i]++;
                classifications[i].touchFlag = 0;
              }
              else if (
                   (mSensorParams.grip4.MinObjectWidth && mSensorParams.grip4.MinObjectWidth <= max_col - min_col + 1) // wide
                || (mDeltaImage[(MAX_RX + 1) * peak.row + peak.col] <= mSensorParams.grip4.SmallSignal)                // the peak is weak
              )
              {
                classifications[i].touchFlag = 0;
                suppressed[side] |= mask;
              }
              else if (
                (peak.row == 1 || peak.row == mSensorParams.txCount)
                && (
                     (mSensorParams.grip4.BigPeakSignal <= mDeltaImage[(MAX_RX + 1) * peak.row + peak.col])                         // the peak is strong
                  || (mSensorParams.grip4.BigAdjacentSignal <= mDeltaImage[(MAX_RX + 1) * (peak.row + (side ? -1 : 1)) + peak.col]) // wide over rows
                )
              )
              {
                // keep it
              }
              else if (
                   suppressed[side]
                || (gripped & (1 << side))
              )
              {
                classifications[i].touchFlag = 0;
                suppressed[side] |= mask;
              }
            }
          }
          else
          {
            suppressed[0] &= ~mask;
            suppressed[1] &= ~mask;
          }
        }
        if (classifications[i].touchFlag)
        {
          reported |= mask;
        }
      #if CONFIG_HAS_GLOVE_SUPPRESSION
        else if (classifications[i].touchType == touchType_finger)
        {
          mSensorParams.grip4.Suppressing = 1;
        }
      #endif
      }
      else
      {
        reported &= ~mask;
        suppressed[0] &= ~mask;
        suppressed[1] &= ~mask;
        delay[i] = 0;
      }
    }
  }
}
#endif

#if CONFIG_HAS_LGM_DETECTOR
static void detectLGM_init(void)
{
  mSensorParams.LGMDetector.LGM = 0;
}

static void detectLGM_check(void)
{
  if (mSensorParams.LGMDetector.Enable)
  {
    int32 posSum = 0, negSum = 0;
    int16 min = 0x7fff, max = 0x8000;
    uint16 row, col;
    int16 *delta = &mDeltaImage[(MAX_RX + 1) * 1 + 1];
    uint16 skip = MAX_RX + 1 - mSensorParams.rxCount;
    for (row = mSensorParams.txCount; row; row--)
    {
      for (col = mSensorParams.rxCount; col; col--)
      {
        if (*delta < min)
        {
          min = *delta;
        }
        if (max < *delta)
        {
          max = *delta;
        }
        if (*delta < 0)
        {
          negSum += -*delta;
        }
        else
        {
          posSum += *delta;
        }
        delta++;
      }
      delta += skip;
    }
    uint16 ratio = posSum ? (negSum << 8) / posSum : 0xffff;
    if (mSensorParams.LGMDetector.LGM)
    {
      if (mSensorParams.LGMDetector.End.Transcap <= max && ratio <= mSensorParams.LGMDetector.End.Ratio)
      {
        mSensorParams.LGMDetector.LGM = 0;
      }
    }
    else
    {
      if (min < mSensorParams.LGMDetector.Start.Transcap && mSensorParams.LGMDetector.Start.Ratio < ratio)
      {
        mSensorParams.LGMDetector.LGM = 1;
      }
    }
  }
}
#endif

#if CONFIG_HAS_LGM_MERGER
static struct mergeStat_t {
  uint16 numObjects;
  uint16 drop;
  #if CONFIG_HAS_LGM_MERGER_ONLY_INSIDE_CLUMPS
  uint16 removedSplits;
  #endif
  struct {
    uint16 clumpId;
    uint16 blobId;
    uint16 mergedObjectIDs;
    pixelIndex_t peak; // just for debugging
  } objects[MAX_OBJECTS /* object ID */];
  uint16 splitObjectIDs[MAX_OBJECTS];
} mergeStat;
static void mergeLGM_drop(trackedObject_t *trackedObjPtr, clumps_t *clumps)
{
  mergeStat.drop = 0;
  if (mSensorParams.LGMMerger.DropWeak)
  {
    int16 max[2];
    uint16 side;
    for (side = 0; side < 2; side++)
    {
      int16 *delta = &mDeltaImage[(MAX_RX + 1) * (side ? mSensorParams.txCount : 1) + 1];
      int16 *m = &max[side];
      *m = 0;
      uint16 col;
      for (col = mSensorParams.rxCount; col; col--, delta++)
      {
        if (*m < *delta)
        {
          *m = *delta;
        }
      }
    }

    uint16 i, mask;
    for (i = 0, mask = 1; i < MAX_OBJECTS; i++, mask <<= 1, trackedObjPtr++)
    {
      if (trackedObjPtr->clumpId)
      {
        pixelIndex_t peak = getPeakLocation(trackedObjPtr, clumps);
        if (peak.row == 1 || peak.row == mSensorParams.txCount)
        {
          int16 threshold = ((int32)max[peak.row == 1 ? 0 : 1] * mSensorParams.LGMMerger.WeakRatio) >> 8;
          if (mDeltaImage[(MAX_RX + 1) * peak.row + peak.col] < threshold)
          {
            mergeStat.drop |= mask;
          }
        }
      }
    }
  }
}
static void mergeLGM_merge(int16 *deltaXProfilePtr, int16 *deltaYProfilePtr, trackedObject_t *trackedObjPtr, clumps_t *clumps)
{
  uint16 i;
  uint16 lastMerged[MAX_OBJECTS];
  for (i = 0; i < MAX_OBJECTS; i++)
  {
    lastMerged[i] = mergeStat.objects[i].mergedObjectIDs;
  }

  uint16 mask, found = 0;
  mergeStat.numObjects = 0;
  memset16(&mergeStat.objects, 0, sizeof(mergeStat.objects) / sizeof(uint16));
  #if CONFIG_HAS_LGM_MERGER_ONLY_INSIDE_CLUMPS
  mergeStat.removedSplits = 0;
  #endif
  for (i = 0, mask = 1; i < MAX_OBJECTS; i++, mask <<= 1)
  {
    if (trackedObjPtr[i].clumpId == 0 || (mergeStat.drop & mask))
    {
      mergeStat.splitObjectIDs[i] = 0;
    }
    else
    {
      found |= 1 << i;
      mergeStat.numObjects++;
      mergeStat.objects[i].clumpId = trackedObjPtr[i].clumpId;
      mergeStat.objects[i].blobId = trackedObjPtr[i].blobId;
      mergeStat.objects[i].mergedObjectIDs |= 1 << i;

      pixelIndex_t peak1 = getPeakLocation(&trackedObjPtr[i], clumps);
      mergeStat.objects[i].peak = peak1;

      uint16 j;
      for (j = i + 1; j < MAX_OBJECTS; j++)
      {
        if (!((mergeStat.drop & (1 << j)) || trackedObjPtr[j].clumpId == 0 || (mergeStat.splitObjectIDs[i] & (1 << j))))
        {
          pixelIndex_t peak2 = getPeakLocation(&trackedObjPtr[j], clumps);
          uint16 foundValley = 0, keepMerged = 0;

        #if CONFIG_HAS_LGM_MERGER_ONLY_INSIDE_CLUMPS
          if (mSensorParams.LGMMerger.OnlyInsideClumps && trackedObjPtr[i].clumpId != trackedObjPtr[j].clumpId)
          {
            // We do not merge clumps
            foundValley = 1;
          }
          else
        #endif
        #if CONFIG_HAS_NOISY_WIRELESS_CHARGER
          if ((deltaXProfilePtr == NULL || deltaYProfilePtr == NULL) && mSensorParams.NoisyWirelessCharger.TakeCareOfLGMMerger)
          {
            if (trackedObjPtr[i].clumpId != trackedObjPtr[j].clumpId)
            {
              foundValley = 1;
            }
          }
          else
        #endif
          {
            if (mSensorParams.LGMMerger.TxValley && peak1.row != peak2.row)
            {
              uint16 step = peak1.row < peak2.row ? 1 : -1;
              int16 delta1 = deltaYProfilePtr[peak1.row - 1], delta2 = deltaYProfilePtr[peak2.row - 1];
              int16 threshold = ((int32)(delta1 < delta2 ? delta1 : delta2) * mSensorParams.LGMMerger.TxValley) >> 8;
            #if CONFIG_HAS_LGM_MERGER_WEIRD_ROW
              if (mSensorParams.LGMMerger.WeirdRow && threshold <= 0)
              {
                if ( (delta1 <= delta2 && peak1.row == mSensorParams.txCount)
                  || (delta2 <= delta1 && peak2.row == mSensorParams.txCount))
                {
                  threshold = 1;
                }
              }
            #endif
              if (threshold == 0)
              {
                keepMerged = 1;
              }
              else
              {
                uint16 row;
                for (row = peak1.row + step - 1; row != (uint16)(peak2.row - 1); row += step)
                {
                  if (deltaYProfilePtr[row] < threshold)
                  {
                    foundValley = 1;
                    break;
                  }
                }
              }
            }

            if (!foundValley && mSensorParams.LGMMerger.RxValley && peak1.col != peak2.col)
            {
              uint16 step = peak1.col < peak2.col ? 1 : -1;
              int16 delta1 = deltaXProfilePtr[peak1.col - 1], delta2 = deltaXProfilePtr[peak2.col - 1];
              int16 threshold = ((int32)(delta1 < delta2 ? delta1 : delta2) * mSensorParams.LGMMerger.RxValley) >> 8;
              if (threshold == 0)
              {
                keepMerged = 1;
              }
              else
              {
                uint16 col;
                for (col = peak1.col + step - 1; col != (uint16)(peak2.col - 1); col += step)
                {
                  if (deltaXProfilePtr[col] < threshold)
                  {
                    foundValley = 1;
                    break;
                  }
                }
              }
            }
          }

          if (foundValley)
          {
            mergeStat.splitObjectIDs[i] |= 1 << j;
            mergeStat.splitObjectIDs[j] |= 1 << i;
          }
          else if (!keepMerged || (keepMerged && (lastMerged[i] & (1 << j))))
          {
            mergeStat.objects[i].mergedObjectIDs |= 1 << j;
            mergeStat.objects[j].mergedObjectIDs |= 1 << i;
            uint16 IDs = mergeStat.objects[j].mergedObjectIDs;
            while (IDs)
            {
              uint16 k = lsbPos(IDs);
              if (!(mergeStat.splitObjectIDs[k] & ((1 << i) | (1 << j))))
              {
                mergeStat.objects[k].mergedObjectIDs |= 1 << i;
                mergeStat.objects[k].mergedObjectIDs |= 1 << j;
              }
              IDs &= IDs - 1;
            }
          #if CONFIG_HAS_LGM_MERGER_ONLY_INSIDE_CLUMPS
            if (mSensorParams.LGMMerger.OnlyInsideClumps)
            {
              int16 split_i = clumps->info[trackedObjPtr[i].clumpId - 1].firstSplit + trackedObjPtr[i].blobId - 1;
              int16 split_j = clumps->info[trackedObjPtr[j].clumpId - 1].firstSplit + trackedObjPtr[j].blobId - 1;
              int16 split = split_i < split_j ? split_j : split_i;
              mergeStat.removedSplits |= 1 << split;
            }
          #endif
          }
        }
      }
    }
  }

  for (i = 0; i < MAX_OBJECTS; i++)
  {
    mergeStat.splitObjectIDs[i] &= found;
  }
}
static void mergeLGM_remap(clumps_t *clumps)
{
  if (mergeStat.numObjects <= 1 && mergeStat.drop == 0)
  {
    return;
  }

#if CONFIG_HAS_LGM_MERGER_ONLY_INSIDE_CLUMPS
  if (mSensorParams.LGMMerger.OnlyInsideClumps)
  {
    uint16 removedSplits = mergeStat.removedSplits;
    while (removedSplits)
    {
      uint16 split = lsbPos(removedSplits);
      uint16 split_max = sizeof(clumps->splits) / sizeof(clumps->splits[0]) - 1;

      uint16 i;
      for (i = split; i < split_max; i++)
      {
        clumps->splits[i] = clumps->splits[i + 1];
      }
      clumps->splits[split_max] = 0;

      for (i = 0; i < MAX_OBJECTS; i++)
      {
        if (clumps->info[i].splitCount)
        {
          if (split < clumps->info[i].firstSplit)
          {
            clumps->info[i].firstSplit--;
          }
          else if (split == clumps->info[i].firstSplit)
          {
            clumps->info[i].splitCount--;
          }
          else if (split < (uint16)clumps->info[i].firstSplit + (uint16)clumps->info[i].splitCount)
          {
            clumps->info[i].splitCount--;
          }
        }
      }

      removedSplits &= removedSplits - 1;
      removedSplits >>= 1;
    }
  }
  else
#endif
  {
    clumps_t clumps_work;
    memset16(&clumps_work, 0, sizeof(clumps_work) / sizeof(uint16));

    uint16 i, mask, merged = 0;
    for (i = 0, mask = 1; i < MAX_OBJECTS; i++, mask <<= 1)
    {
      uint16 objectIDs = mergeStat.objects[i].mergedObjectIDs;
      if (objectIDs && !(merged & mask))
      {
        clumpInfo_t *info = &clumps_work.info[i];
        while (objectIDs)
        {
          uint16 objectID = lsbPos(objectIDs);
          trackedObject_t track;
          track.clumpId = mergeStat.objects[objectID].clumpId;
          track.blobId = mergeStat.objects[objectID].blobId;

          pixelIndex_t peak = getPeakLocation(&track, clumps);
          if (info->peakLocation.row == 0 || mDeltaImage[(MAX_RX + 1) * info->peakLocation.row + info->peakLocation.col] < mDeltaImage[(MAX_RX + 1) * peak.row + peak.col])
          {
            info->peakLocation = peak;
          }

          pixelIndex_t pixel = getFirstPixel(&track, clumps);
          if (pixel.row)
          {
            pixelIndex_t firstPixel = pixel;
            uint16 index ATTR_INITIALIZED;
            while (pixel.row)
            {
              index = (MAX_RX + 1) * pixel.row + pixel.col;
              clumps_work.labelImage[index] = i + 1;
              pixel = getNextPixel(pixel, clumps);
              clumps_work.listImage[index] = pixel;
            }

            clumps_work.listImage[index] = info->firstPixel;
            info->firstPixel = firstPixel;
          }

          merged |= 1 << objectID;
          objectIDs &= objectIDs - 1;
        }
        info->peakCount = 1;
      }
    }

    memcpy16(clumps, &clumps_work, sizeof(clumps_work) / sizeof(uint16));
  }
}
static void mergeLGM(int16 *deltaXProfilePtr, int16 *deltaYProfilePtr, trackedObject_t **trackedObjPtrPtr, clumps_t *clumps, ifpTimeStamp_t timeSinceLast_ms)
{
  tracker_next_drawer();
#if CONFIG_HAS_NOISY_WIRELESS_CHARGER
  if (mSensorParams.LGMMerger.Enable && ((deltaXProfilePtr && deltaYProfilePtr) || mSensorParams.NoisyWirelessCharger.TakeCareOfLGMMerger))
#else
  if (mSensorParams.LGMMerger.Enable && deltaXProfilePtr && deltaYProfilePtr) // We assume we don't lose hybrid ABS delta once we get one.
#endif
  {
    if (mSensorParams.LGMDetector.LGM || mSensorParams.LGMMerger.Always)
    {
      mergeLGM_drop(*trackedObjPtrPtr, clumps);
      mergeLGM_merge(deltaXProfilePtr, deltaYProfilePtr, *trackedObjPtrPtr, clumps);
      mergeLGM_remap(clumps);
    }
    else
    {
      memset16(&mergeStat, 0, sizeof(mergeStat) / sizeof(uint16));
      memset16(&mergeStat.splitObjectIDs, 0xffff, sizeof(mergeStat.splitObjectIDs) / sizeof(uint16));
    }
    *trackedObjPtrPtr = tracker_track(mDeltaImage, clumps, timeSinceLast_ms, &mSensorParams);
  }
}
#endif

#if CONFIG_HAS_PROFILE_BASELINE_CONTROL
static void assessProfile(uint16 *relaxCommand, int16 *deltaXProfilePtr, int16 *deltaYProfilePtr)
{
#if CONFIG_HAS_NOISY_WIRELESS_CHARGER
  if (deltaXProfilePtr == NULL || deltaYProfilePtr == NULL)
    return;
#endif

  if (mSensorParams.ProfileBaselineControl.Enable && (*relaxCommand == relaxCommand_thermal || *relaxCommand == relaxCommand_frozen))
  {
    if (mSensorParams.ProfileBaselineControl.TxThreshold)
    {
      int32 sum = 0;
      uint16 row;
      #if CONFIG_HAS_PROFILE_BASELINE_CONTROL_RATIO
      uint16 numTx = 0;
      #endif
      for (row = mSensorParams.txCount; row; row--)
      {
        #if CONFIG_HAS_PROFILE_BASELINE_CONTROL_RATIO
        if (*deltaYProfilePtr < mSensorParams.ProfileBaselineControl.TxThreshold)
        {
          numTx++;
        }
        #endif
        sum += *deltaYProfilePtr++;
      }
      int16 ave = sum / (int16)mSensorParams.txCount;
      if (ave < mSensorParams.ProfileBaselineControl.TxThreshold
        #if CONFIG_HAS_PROFILE_BASELINE_CONTROL_RATIO
        && mSensorParams.ProfileBaselineControl.NumTx < numTx
        #endif
      )
      {
        *relaxCommand = relaxCommand_rezero;
      }
    }
    if (mSensorParams.ProfileBaselineControl.RxThreshold && *relaxCommand != relaxCommand_rezero)
    {
      int16 count = mSensorParams.rxCount;
      if (mSensorParams.ProfileBaselineControl.DisregardEdgeCols)
      {
        deltaXProfilePtr++;
        count -= 2;
      }
      int32 sum = 0;
      uint16 col;
      #if CONFIG_HAS_PROFILE_BASELINE_CONTROL_RATIO
      uint16 numRx = 0;
      #endif
      for (col = count; col; col--)
      {
        #if CONFIG_HAS_PROFILE_BASELINE_CONTROL_RATIO
        if (*deltaXProfilePtr < mSensorParams.ProfileBaselineControl.RxThreshold)
        {
          numRx++;
        }
        #endif
        sum += *deltaXProfilePtr++;
      }
      int16 ave = sum / count;
      if (ave < mSensorParams.ProfileBaselineControl.RxThreshold
        #if CONFIG_HAS_PROFILE_BASELINE_CONTROL_RATIO
        && mSensorParams.ProfileBaselineControl.NumRx < numRx
        #endif
      )
      {
        *relaxCommand = relaxCommand_rezero;
      }
    }
  }
}
#endif

#if CONFIG_HAS_METAL_PLATE_SUPPRESSION
static void suppressMetalPlate(classification_t *classifications)
{
  if (mSensorParams.MetalPlate.Enable)
  {
    struct {
      uint16 count;
      uint16 sum;
       int16 average;
    } statistics[2], *stat;
    memset16(statistics, 0, sizeof(statistics) / sizeof(uint16));
    uint16 side;
    int16 noise = mSensorParams.MetalPlate.Noise;
    for (side = 0; side < 2; side++)
    {
      int16 *delta = &mDeltaImage[(MAX_RX + 1) * (side ? mSensorParams.txCount : 1) + 1];
      uint16 col;
      stat = &statistics[side];
      for (col = mSensorParams.rxCount; col; col--)
      {
        if (noise < *delta)
        {
          stat->count++;
          stat->sum += *delta;
        }
        delta++;
      }
      stat->average = stat->sum / (stat->count ?: 1);
    }
    if (
         statistics[0].count < mSensorParams.MetalPlate.NumColsExit
      || statistics[1].count < mSensorParams.MetalPlate.NumColsExit
    )
    {
      mSensorParams.MetalPlate.Suppressing = 0;
    }
    else if (
         mSensorParams.MetalPlate.NumColsEnter <= statistics[0].count
      && mSensorParams.MetalPlate.NumColsEnter <= statistics[1].count
      && mSensorParams.MetalPlate.Threshold    <= statistics[0].average
      && mSensorParams.MetalPlate.Threshold    <= statistics[1].average
    )
    {
      mSensorParams.MetalPlate.Suppressing = 1;
    }

    if (mSensorParams.MetalPlate.Suppressing)
    {
      uint16 i;
      for (i = 0; i < MAX_OBJECTS; i++)
      {
        classifications[i].touchFlag = 0;
      }
    }
  }
}
#endif

#if CONFIG_HAS_NUM_GLOVES
static void discardGloves(classification_t *classifications)
{
  if (mSensorParams.NumGloves.Max)
  {
    static uint16 reporting, suppressing, lastCount;
    uint16 i, mask, oldCount = 0, newCount = 0;
    for (i = 0, mask = 1; i < MAX_OBJECTS; i++, mask <<= 1)
    {
      if (classifications[i].touchFlag && classifications[i].touchType == touchType_glove)
      {
        if (suppressing & mask)
        {
          classifications[i].touchFlag = 0;
        }
        else if (reporting & mask)
        {
          oldCount++;
        }
        else
        {
          if ((lastCount + newCount) < mSensorParams.NumGloves.Max)
          {
            reporting |= mask;
            newCount++;
          }
          else
          {
            suppressing |= mask;
            classifications[i].touchFlag = 0;
          }
        }
      }
      else
      {
        reporting &= ~mask;
        suppressing &= ~mask;
      }
    }
    lastCount = oldCount + newCount;
  }
}
#endif

#if CONFIG_HAS_GLOVE_ONLY
static void suppressGloves(classification_t *classifications)
{
  if (!mSensorParams.GloveOnly.Enable)
  {
    mSensorParams.GloveOnly.Suppress = 0;
  }
  else
  {
    uint16 i, hasSignificant = 0, hasObjects = 0;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (classifications[i].touchFlag)
      {
        hasObjects = 1;
        if (classifications[i].touchType != touchType_glove)
        {
          hasSignificant = 1;
          break;
        }
      }
    }
    if (!hasObjects)
    {
      mSensorParams.GloveOnly.Suppress = 0;
    }
    else if (!mSensorParams.GloveOnly.Suppress && hasSignificant)
    {
      mSensorParams.GloveOnly.Suppress = 1;
    }
    if (mSensorParams.GloveOnly.Suppress)
    {
      for (i = 0; i < MAX_OBJECTS; i++)
      {
        if (classifications[i].touchFlag && classifications[i].touchType == touchType_glove)
        {
          classifications[i].touchFlag = 0;
        }
      }
    }
  }
}
#endif

#if CONFIG_HAS_GLOVE_CMNR
static void glove_CMNR(void)
{
  if (mSensorParams.GloveCMNR.Enable)
  {
    int16 cmn[MAX_TX];
    int16 min = 0x7fff, max = 0x8000;
    uint16 row, col;
    uint16 thisIsNoisy = 0;
    for (row = 0; row < mSensorParams.txCount; row++)
    {
      int16 *delta = &mDeltaImage[(MAX_RX + 1) * (row + 1) + 1];
      int32 sum = 0;
      int16 row_max = 0x8000;
      for (col = 0; col < mSensorParams.rxCount; col++)
      {
        if (*delta < min)
        {
          min = *delta;
        }
        if (max < *delta)
        {
          max = *delta;
        }
        if (row_max < *delta)
        {
          row_max = *delta;
        }
        sum += *delta;
        delta++;
      }
      if (row_max <= mSensorParams.GloveCMNR.NoisyNegativeTh)
      {
        mSensorParams.GloveCMNR.Noisy = 1;
        mSensorParams.GloveCMNR.numFrames = 0;
        thisIsNoisy = 1;
      }
      cmn[row] = sum / (int16)mSensorParams.rxCount;
    }
    if (mSensorParams.GloveCMNR.Noisy && !thisIsNoisy)
    {
      if (-mSensorParams.GloveCMNR.QuietTh <= min && max <= mSensorParams.GloveCMNR.QuietTh)
      {
        if (mSensorParams.GloveCMNR.QuietFrames <= mSensorParams.GloveCMNR.numFrames++)
        {
          mSensorParams.GloveCMNR.Noisy = 0;
        }
      }
      else
      {
        mSensorParams.GloveCMNR.numFrames = 0;
      }
    }

    if (mSensorParams.GloveCMNR.Noisy)
    {
    #if CONFIG_HAS_GLOVE_CMNR_RESTRICT
      if (mSensorParams.GloveCMNR.FingerTh == 0 || max <= mSensorParams.GloveCMNR.FingerTh)
    #endif
      {
        for (row = 0; row < mSensorParams.txCount; row++)
        {
          int16 *delta = &mDeltaImage[(MAX_RX + 1) * (row + 1) + 1];
          int16 adj = cmn[row];
          if (adj < -mSensorParams.GloveCMNR.Cap)
          {
            adj = -mSensorParams.GloveCMNR.Cap;
          }
          else if (mSensorParams.GloveCMNR.Cap < adj)
          {
            adj = mSensorParams.GloveCMNR.Cap;
          }
          delta = &mDeltaImage[(MAX_RX + 1) * (row + 1) + 1];
          for (col = 0; col < mSensorParams.rxCount; col++)
          {
            *delta -= adj;
            delta++;
          }
        }
      }
    }
  }
}
#endif

#if CONFIG_HAS_GLOVE_NOISE_FLOOR
void updateGloveNF(classification_t *classifications)
{
  uint16 onlyGlove = 0;
  if (mSensorParams.GloveNF.Enable)
  {
    uint16 i, hasGlove = 0;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (classifications[i].touchFlag)
      {
        if (classifications[i].touchType == touchType_glove)
        {
          hasGlove = 1;
        }
        else
        {
          break;
        }
      }
    }
    if (hasGlove && i == MAX_OBJECTS)
    {
      onlyGlove = 1;
    }
  }
  mSensorParams.GloveNF.OnlyGlove = onlyGlove;
}
#endif

#if CONFIG_HAS_DIRTY_GLOVE
static struct {
  uint16 Noisy   : 1;
  uint16 Duration;
} dirtyGlove;
static void dirtyGlove_clean(ifpTimeStamp_t timeSinceLast_ms)
{
  if (!mSensorParams.DirtyGlove.Enable)
  {
    dirtyGlove.Noisy = 0;
  }
  else
  {
    uint16 row, col, count = 0;
    int32 sum = 0;
    for (row = 0; row < mSensorParams.txCount; row++)
    {
      int16 *delta = &mDeltaImage[(MAX_RX + 1) * (row + 1) + 1];
      for (col = 0; col < mSensorParams.rxCount; col++)
      {
        if (mSensorParams.DirtyGlove.LowerLevel <= *delta && *delta <= mSensorParams.DirtyGlove.UpperLevel)
        {
          count++;
          sum += *delta;
        }
        delta++;
      }
    }

    uint16 dirty = (((uint32)mSensorParams.txCount * mSensorParams.rxCount * mSensorParams.DirtyGlove.Ratio1) >> 8) <= count;
    if (dirty)
    {
      dirtyGlove.Noisy = 1;
      dirtyGlove.Duration = 0;
    }
    else if (dirtyGlove.Noisy)
    {
      if (dirtyGlove.Duration + timeSinceLast_ms < dirtyGlove.Duration)
      {
        dirtyGlove.Duration = 0xffff;
      }
      else
      {
        dirtyGlove.Duration += timeSinceLast_ms;
      }
      if (mSensorParams.DirtyGlove.QuietDuration <= dirtyGlove.Duration)
      {
        dirtyGlove.Noisy = 0;
      }
    }

    if (dirtyGlove.Noisy)
    {
      if ((((uint32)mSensorParams.txCount * mSensorParams.rxCount * mSensorParams.DirtyGlove.Ratio2) >> 8) <= count)
      {
        int16 average = sum / (int16)count;
        for (row = 0; row < mSensorParams.txCount; row++)
        {
          int16 *delta = &mDeltaImage[(MAX_RX + 1) * (row + 1) + 1];
          for (col = 0; col < mSensorParams.rxCount; col++)
          {
            *delta = (average < *delta) ? (*delta - average) : 0;
            delta++;
          }
        }
      }
    }
  }
}
#endif

#if CONFIG_HAS_NOISY_WIRELESS_CHARGER
static struct {
  uint16 Noisy    : 1;
  uint16 wasNoisy : 1; // just for debugging
  uint16 Quiet;
  uint16 hadObjects;
  struct {
     int16 Min;
     int16 Max;
     int16 Last;
  } Objects[MAX_OBJECTS];
} NoisyWirelessCharger;
void noisyWirelessCharger_init(void)
{
  memset16(&NoisyWirelessCharger, 0, sizeof(NoisyWirelessCharger) / sizeof(uint16));
  NoisyWirelessCharger.Noisy = mSensorParams.NoisyWirelessCharger.NoisyByDefault ? 1 : 0;
}
void noisyWirelessCharger_check(trackedObject_t *trackedObjPtr, int16 **deltaX, int16 **deltaY)
{
  if (mSensorParams.NoisyWirelessCharger.Enable && *deltaX && *deltaY)
  {
    if (mSensorParams.NoisyWirelessCharger.NoisyAllTheTime)
    {
      NoisyWirelessCharger.Noisy = 1;
    }
    else
    {
      uint16 i, dirty = 0, quiet = 1, mask = 1;
      for (i = 0; i < MAX_OBJECTS; i++, trackedObjPtr++, mask <<= 1)
      {
        uint16 row = (trackedObjPtr->yCentroid >> 8) + 1;
        uint16 col = (trackedObjPtr->xCentroid >> 8) + 1;
        int16 transcap = mDeltaImage[(MAX_RX + 1) * row + col];// note: row and col are surely false if clumpId=0, but they are to be still in the range.
        if (trackedObjPtr->clumpId == 0 || transcap < mSensorParams.NoisyWirelessCharger.Transcap)
        {
          memset16(&NoisyWirelessCharger.Objects[i], 0, sizeof(NoisyWirelessCharger.Objects[i]) / sizeof(uint16));
          NoisyWirelessCharger.hadObjects &= ~mask;
        }
        else
        {
          int16 profile = (*deltaX)[col - 1];
          if (!(NoisyWirelessCharger.hadObjects & mask))
          {
            NoisyWirelessCharger.Objects[i].Min = profile;
            NoisyWirelessCharger.Objects[i].Max = profile;
          }
          else
          {
            if (profile < NoisyWirelessCharger.Objects[i].Min)
            {
              NoisyWirelessCharger.Objects[i].Min = profile;
            }
            if (NoisyWirelessCharger.Objects[i].Max < profile)
            {
              NoisyWirelessCharger.Objects[i].Max = profile;
            }
            if (NoisyWirelessCharger.Objects[i].Min < mSensorParams.NoisyWirelessCharger.NoisyLower && mSensorParams.NoisyWirelessCharger.NoisyUpper < NoisyWirelessCharger.Objects[i].Max)
            {
              dirty = 1;
              NoisyWirelessCharger.Objects[i].Min = 0;
              NoisyWirelessCharger.Objects[i].Max = 0;
            }
          }

          int16 average;
          if (col == 1)
          {
            average = (profile + (*deltaX)[1]) / 2;
          }
          else if (col == mSensorParams.rxCount)
          {
            average = (profile + (*deltaX)[mSensorParams.rxCount - 1]) / 2;
          }
          else
          {
            average = (profile + (*deltaX)[col - 2] + (*deltaX)[col]) / 3;
          }

          if (NoisyWirelessCharger.hadObjects & mask)
          {
            int16 diff = average - NoisyWirelessCharger.Objects[i].Last;
            diff *= (diff < 0) ? -1 : 1;
            if (mSensorParams.NoisyWirelessCharger.QuietRange < diff)
            {
              quiet = 0;
            }
          }
          NoisyWirelessCharger.Objects[i].Last = average;
          NoisyWirelessCharger.hadObjects |= mask;
        }
      }

      if (!NoisyWirelessCharger.hadObjects)
      {
        NoisyWirelessCharger.Quiet = 0;
      }
      else
      {
        if (dirty)
        {
          NoisyWirelessCharger.Noisy = 1;
          NoisyWirelessCharger.Quiet = 0;
        }
        else if (quiet && NoisyWirelessCharger.Noisy)
        {
          NoisyWirelessCharger.Quiet++;
          if (mSensorParams.NoisyWirelessCharger.QuietFrames < NoisyWirelessCharger.Quiet)
          {
            NoisyWirelessCharger.Noisy = 0;
          }
        }
      }
    }

    if (NoisyWirelessCharger.Noisy)
    {
      *deltaX = NULL;
      *deltaY = NULL;
      NoisyWirelessCharger.wasNoisy = 1;
    }
  }
}
#endif

#if CONFIG_HAS_CUSTOM_ENERGY_RATIO
static void energyRatio_check(uint16 *relaxCommand)
{
  if (mSensorParams.EnergyRatio.Enable && *relaxCommand != relaxCommand_rezero)
  {
    uint32 sumPos = 0, sumNeg = 0;
    uint16 row, col;
    int16 noiseFloor = mSensorParams.EnergyRatio.NoiseFloor;
    for (row = 0; row < mSensorParams.txCount; row++)
    {
      int16 *delta = &mDeltaImage[(MAX_RX + 1) * row + 1];
      for (col = 0; col < mSensorParams.rxCount; col++)
      {
        if (noiseFloor < *delta)
        {
          sumPos += *delta;
        }
        else if (*delta < -noiseFloor)
        {
          sumNeg += -*delta;
        }
        delta++;
      }
    }

    if (mSensorParams.EnergyRatio.MinNegSum <= sumNeg && ((sumPos * mSensorParams.EnergyRatio.Ratio) >> 4) < sumNeg)
    {
      *relaxCommand = relaxCommand_rezero;
    }
  }
}
#endif

#if CONFIG_HAS_LANDING_LARGE_FINGER_DROP
static struct {
  uint16 found;
  uint16 dropped;
  uint16 dropNext;
  classification_t classifications[MAX_OBJECTS];
  sensorPosition_t sensorPositions[MAX_OBJECTS];
} landingLarge;
static void landingLarge_init()
{
  memset16(&landingLarge, 0, sizeof(landingLarge) / sizeof(uint16));
}
static void landingLarge_reinit()
{
  landingLarge_init();
}
static void landingLarge_drop(classification_t *classifications, sensorPosition_t *sensorPositions)
{
  if (mSensorParams.LandingLargeFingerDrop.Enable)
  {
    uint16 i, mask;
    for (i = 0, mask = 1; i < MAX_OBJECTS; i++, mask <<= 1)
    {
      if (classifications[i].touchFlag)
      {
        if (landingLarge.found & mask)
        {
          landingLarge.dropped &= ~mask;
        }
        else
        {
          // A new object
          uint16 w = coordConv_computeW(&sensorPositions[i]);
          uint16 z = coordConv_computeZ(&sensorPositions[i]);
          if ( (landingLarge.dropNext & mask)
            || (mSensorParams.LandingLargeFingerDrop.MinW && mSensorParams.LandingLargeFingerDrop.MinW <= w)
            || (mSensorParams.LandingLargeFingerDrop.MinZ && mSensorParams.LandingLargeFingerDrop.MinZ <= z))
          {
            landingLarge.classifications[i] = classifications[i];
            landingLarge.sensorPositions[i] = sensorPositions[i];
            classifications[i].touchFlag = 0;
            landingLarge.dropped |= mask;
          }
        }
        landingLarge.found |= mask;
        landingLarge.dropNext &= ~mask;
      }
      else
      {
        if (landingLarge.dropped & mask)
        {
          // The object was gone without being reported.
          classifications[i] = landingLarge.classifications[i];
          sensorPositions[i] = landingLarge.sensorPositions[i];
          landingLarge.dropNext |= mask;
        }
        else
        {
          landingLarge.dropNext &= ~mask;
        }
        landingLarge.found &= ~mask;
        landingLarge.dropped &= ~mask;
      }
    }
  }
}
#endif

#if CONFIG_HAS_GLOVE_DELAY
static struct {
  struct {
    uint16 drop;
    uint16 indexR;
    uint16 indexW;
    sensorPosition_t pos[4];
  } object[MAX_OBJECTS];
} gloveDelay;
static void gloveDelay_init(void)
{
  memset16(&gloveDelay, 0, sizeof(gloveDelay) / sizeof(uint16));
}
static void gloveDelay_reinit(void)
{
  gloveDelay_init();
}
static void gloveDelay_delay(classification_t *classifications, sensorPosition_t *sensorPositions)
{
  if (mSensorParams.GloveDelay.NumDrops)
  {
    uint16 i;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (classifications[i].touchFlag && classifications[i].touchType == touchType_glove)
      {
        uint16 *indexR = &gloveDelay.object[i].indexR;
        uint16 *indexW = &gloveDelay.object[i].indexW;

        if (*indexW < 4 && mSensorParams.GloveDelay.Replace[*indexW] < 15 && mSensorParams.GloveDelay.Replace[*indexW] == gloveDelay.object[i].drop)
        {
          gloveDelay.object[i].pos[*indexW] = sensorPositions[i];
          (*indexW)++;
        }

        if (gloveDelay.object[i].drop < mSensorParams.GloveDelay.NumDrops)
        {
          classifications[i].touchFlag = 0;
          classifications[i].newTouchFlag = 0;
        }
        else
        {
          if (gloveDelay.object[i].drop == mSensorParams.GloveDelay.NumDrops)
          {
            classifications[i].newTouchFlag = 1;
          }
          if (*indexR < *indexW && mSensorParams.GloveDelay.Replace[*indexR] < 15 && *indexR == gloveDelay.object[i].drop - mSensorParams.GloveDelay.NumDrops)
          {
            sensorPositions[i] = gloveDelay.object[i].pos[*indexR];
            (*indexR)++;
          }
        }
        if (gloveDelay.object[i].drop < 128)
        {
          gloveDelay.object[i].drop++;
        }
      }
      else
      {
        memset16(&gloveDelay.object[i], 0, sizeof(gloveDelay.object[i]) / sizeof(uint16));
      }
    }
  }
}
#endif

#if CONFIG_HAS_HYBRID_REZERO
static struct {
  uint16 count;
  uint16 GloveOrFinger;
} hybridRezero;
static void hybridRezero_init(void)
{
  memset16(&hybridRezero, 0, sizeof(hybridRezero) / sizeof(uint16));
}
static void hybridRezero_reinit(void)
{
  hybridRezero_init();
}
static void hybridRezero_check(uint16 *relaxCommand, int16 *deltaXProfilePtr)
{
  if (mSensorParams.HybridRezero.Enable)
  {
    if (*relaxCommand == relaxCommand_rezero || !hybridRezero.GloveOrFinger)
    {
      hybridRezero.count = 0;
    }
    else
    {
      uint16 rx = 0;
      if (deltaXProfilePtr && (deltaXProfilePtr[0] <= mSensorParams.HybridRezero.Negative
                            || deltaXProfilePtr[1] <= mSensorParams.HybridRezero.Negative))
      {
        rx = 1;
        uint16 col;
        for (col = 0; col < mSensorParams.rxCount; col++)
        {
          if (mSensorParams.HybridRezero.Positive < deltaXProfilePtr[col])
          {
            rx = 0;
            break;
          }
        }
      }

      if (rx)
      {
        hybridRezero.count++;
        if (mSensorParams.HybridRezero.NumFrames < hybridRezero.count)
        {
          *relaxCommand = relaxCommand_rezero;
          hybridRezero.count = 0;
        }
      }
      else
      {
        hybridRezero.count = 0;
      }
    }
  }
}
static void hybridRezero_prepare(classification_t *classifications)
{
  if (mSensorParams.HybridRezero.Enable)
  {
    uint16 hasGlove = 0;
    uint16 i;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (classifications[i].touchFlag)
      {
        if (classifications[i].touchType == touchType_glove)
        {
          hasGlove = 1;
        }
        else if (classifications[i].touchType == touchType_finger)
        {
          hybridRezero.GloveOrFinger = 0;
          hasGlove = 0;
          break;
        }
      }
    }
    hybridRezero.GloveOrFinger |= hasGlove;
  }
}
#endif

#if CONFIG_HAS_NEGATIVE_REZERO
static struct {
  uint16 NumFrames;
} negativeRezero;
static void negativeRezero_init(void)
{
  negativeRezero.NumFrames = 0;
}
static void negativeRezero_reinit(void)
{
  negativeRezero_init();
}
static void negativeRezero_check(uint16 *relaxCommand)
{
  if (mSensorParams.NegativeRezero.Enable)
  {
    if (*relaxCommand == relaxCommand_rezero)
    {
      negativeRezero.NumFrames = 0;
    }
    else
    {
      uint16 row, col;
      int16 min = 0, max = 0;
      for (row = 0; row < mSensorParams.txCount; row++)
      {
        int16 *delta = &mDeltaImage[(MAX_RX + 1) * (row + 1) + 1];
        for (col = 0; col < mSensorParams.rxCount; col++, delta++)
        {
          if (*delta < min)
          {
            min = *delta;
          }
          if (max < *delta)
          {
            max = *delta;
          }
        }
      }

      if (min <= mSensorParams.NegativeRezero.MinNeg && (max + min) <= mSensorParams.NegativeRezero.MinDiff)
      {
        negativeRezero.NumFrames++;
        if (mSensorParams.NegativeRezero.NumFrames < negativeRezero.NumFrames)
        {
          *relaxCommand = relaxCommand_rezero;
          negativeRezero.NumFrames = 0;
        }
      }
      else
      {
        negativeRezero.NumFrames = 0;
      }
    }
  }
}
#endif

#if CONFIG_HAS_GLOVE_SUPPRESSION
static struct {
  uint16 suppressing : 1;
} gloveSuppression;
static void gloveSuppression_suppress(classification_t *classifications, sensorPosition_t *sensorPositions)
{
  if (mSensorParams.GloveSuppression.Enable)
  {
    if (mSensorParams.grip4.Suppressing)
    {
      gloveSuppression.suppressing = 1;
    }

    uint16 found = 0;
    uint16 i;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (classifications[i].touchFlag && classifications[i].touchType == touchType_glove)
      {
        if (gloveSuppression.suppressing)
        {
          if (mSensorParams.GloveSuppression.minY < sensorPositions[i].yPosition && sensorPositions[i].yPosition < mSensorParams.GloveSuppression.maxY)
          {
            found = 1;
          }
          else
          {
            classifications[i].touchFlag = 0;
          }
        }
      }
    }

    if (!mSensorParams.grip4.Suppressing && found)
    {
      gloveSuppression.suppressing = 0;
    }
  }
}
#endif

/* =================================================================
   MODULE NON-STATIC FUNCTION DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: imageFrameProcessor_init()
Purpose: Initialize the image frame processing modules, as at
         ASIC power-on.
Inputs: None.
Outputs: None.
Effects: None.
Notes: This function must be called before the first
       call to nextFrame().
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_init()
{
  ifp_vector_util_init(); //must be first
  clearBaselines();
  memset16(&ifpActionFlags, 0, sizeof(ifpActionFlags) / sizeof(uint16));

  baselineChecker_init();
  baselineManager_init();
  baselineUpdater_init();
  profileBaselineUpdater_init();
  gainCompensator_init();
  lgmManager_init();
  lgmCorrector_init();
#if CONFIG_HAS_DISPLAY_NOISE_REMOVER
  displayNoiseRemover_init();
#endif
  moistureDetector_init();
  moistureFilterAMP_init();
  penRecorrector_init();
  segmenter_init();
  filterNoiseBlobs_init();
  tracker_init();
  classifier_init();
  fistReject_init();
  positionEstimator_init();
  kalmanFilter_init();
  landLiftJitterFilter_init();
  coordConv_init();
  posReporter_init();
  touchBuffer_init();
#if CONFIG_HAS_0D_BUTTONS
  buttons0D_init();
#endif
  faceDetect_init();
  single_finger_init();
  thick_glove_init();
  ALGM_init();
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
  metal_detection_init(&mSensorParams);
#endif
  sideTouch_init();
  absFilter_init();
#if CONFIG_HAS_LGM_DETECTOR
  detectLGM_init();
#endif
#if CONFIG_HAS_NOISY_WIRELESS_CHARGER
  noisyWirelessCharger_init();
#endif
#if CONFIG_HAS_LANDING_LARGE_FINGER_DROP
  landingLarge_init();
#endif
#if CONFIG_HAS_GLOVE_DELAY
  gloveDelay_init();
#endif
#if CONFIG_HAS_HYBRID_REZERO
  hybridRezero_init();
#endif
#if CONFIG_HAS_NEGATIVE_REZERO
  negativeRezero_init();
#endif
}

/* -----------------------------------------------------------------
Name: imageFrameProcessor_reinit()
Purpose: Re-initialize the image frame processing modules, as at
         a rezero command.
Inputs: None.
Outputs: None.
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_reinit()
{
  ifp_vector_util_reinit(); //must be first
  clearBaselines();
  memset16(&ifpActionFlags, 0, sizeof(ifpActionFlags) / sizeof(uint16));

  baselineChecker_reinit();
  baselineManager_reinit();
  baselineUpdater_reinit();
  profileBaselineUpdater_reinit();
  gainCompensator_reinit();
  lgmManager_reinit();
  lgmCorrector_reinit();
#if CONFIG_HAS_DISPLAY_NOISE_REMOVER
  displayNoiseRemover_reinit();
#endif
  moistureDetector_reinit();
  moistureFilterAMP_reinit();
  penRecorrector_reinit();
  segmenter_reinit();
  filterNoiseBlobs_reinit();
  tracker_reinit();
  classifier_reinit();
  fistReject_reinit();
  positionEstimator_reinit();
  kalmanFilter_reinit();
  landLiftJitterFilter_reinit();
  coordConv_reinit();
  posReporter_reinit();
  touchBuffer_reinit();
#if CONFIG_HAS_0D_BUTTONS
  buttons0D_reinit();
#endif
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
  metal_detection_init(&mSensorParams);
#endif
  faceDetect_reinit();
  single_finger_reinit();
  thick_glove_reinit();
  ALGM_reinit();
  sideTouch_reinit();
  absFilter_reinit();
#if CONFIG_HAS_LGM_DETECTOR
  detectLGM_init();
#endif
#if CONFIG_HAS_NOISY_WIRELESS_CHARGER
  noisyWirelessCharger_init();
#endif
#if CONFIG_HAS_LANDING_LARGE_FINGER_DROP
  landingLarge_reinit();
#endif
#if CONFIG_HAS_GLOVE_DELAY
  gloveDelay_reinit();
#endif
#if CONFIG_HAS_HYBRID_REZERO
  hybridRezero_reinit();
#endif
#if CONFIG_HAS_NEGATIVE_REZERO
  negativeRezero_reinit();
#endif
}

#if CONFIG_IFP_ESD_ACTIVEMODE
/* -----------------------------------------------------------------
Name: imageFrameProcessor_reinit_keepBaseline()
Purpose: Initialize image processing, used at exit ESD_MODE
Inputs: None.
Outputs: None.
Effects: Reset image processor state, as at a rezero command.
         This clears objects that were being tracked.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_reinit_keepBaseline(void)
{
  tracker_reinit();
  classifier_reinit();
  positionEstimator_reinit();
  landLiftJitterFilter_reinit();
  coordConv_reinit();
  posReporter_reinit();
}
#endif
/* -----------------------------------------------------------------
Name: imageFrameProcessor_configure()
Purpose: Configure the image frame processing modules
Inputs: config - a configuration structure.
Outputs: None.
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_configure(ifpConfig_t *config)
{
  ifp_vector_util_configure(); //must be first
  mSensorParams = config->sensorParams;
#if CONFIG_HAS_ANTI_BENDING
    antiBending_configure(&mSensorParams, &config->abConfig);
#endif
  baselineChecker_configure(&config->bcConfig);
  baselineManager_configure(&mSensorParams, &config->bmConfig);
  baselineUpdater_configure(&config->buConfig);
#if CONFIG_HAS_HYBRID
  profileBaselineUpdater_configure(&mSensorParams, &config->pbuConfig);
  #if CONFIG_HAS_RX_MUXING
    muxRXHybridDisplayNoiseRemover_configure(&mSensorParams, &config->mRXhdnrConfig);
  #elif CONFIG_HAS_TX_MUXING
    muxTXHybridDisplayNoiseRemover_configure(&mSensorParams, &config->mTXhdnrConfig);
  #elif CONFIG_HAS_HYBRID_DISPLAY_NOISE_REMOVER
  hybridDisplayNoiseRemover_configure(&mSensorParams, &config->hdnrConfig);
  #endif
#else
  #if CONFIG_HAS_DISPLAY_NOISE_REMOVER
  displayNoiseRemover_configure(&mSensorParams, &config->dnrConfig);
  #endif
#endif
#if CONFIG_HAS_MOISTURE
  moistureDetector_configure(&config->mdConfig, &mSensorParams);
  moistureFilter_configure(&config->mfConfig);
#endif
  gainCompensator_configure(&config->gainCompParams);
#if CONFIG_HAS_SHADOW_REMOVER
  shadowRemover_configure(&config->srConfig);
#endif
#if CONFIG_HAS_SHADOW_REMOVER_AMP
  shadowRemoverAMP_configure(&config->ampShadowRemoverConfig);
#endif
#if CONFIG_HAS_LGM_CORRECTOR
  lgmManager_configure(&config->lgmConfig);
#endif
#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
  penRecorrector_configure(&config->prcConfig);
#endif
  segmenter_configure(&config->segConfig);
  clumpSplitter_configure(&config->csConfig);
  filterNoiseBlobs_configure(&config->fnbConfig);
#if CONFIG_HAS_LINEAR_SWIPE_SPLITTER
  linearSwipeSplitter_configure(&mSensorParams, &config->lssConfig);
#endif
#if CONFIG_HAS_FIST_REJECT
  fistReject_configure(&config->frConfig);
#endif
  tracker_configure(&config->trackerConfig);
  classifier_configure(&config->classConfig);
#if CONFIG_HAS_NOTCH_CUT
  positionEstimator_configure(&mSensorParams, &config->peConfig);
#else
  positionEstimator_configure(&config->peConfig);
#endif //CONFIG_HAS_NOTCH_CUT
#if CONFIG_HAS_KALMAN_FILTER
  kalmanFilter_configure(&config->kfConfig);
#endif
  landLiftJitterFilter_configure(&config->lljfConfig);
  coordConv_configure(&mSensorParams, &config->coordConvConfig);
  posReporter_configure(&config->posReportConfig);
  touchBuffer_configure(&mSensorParams, &config->coordConvConfig, 0); //_DS_TODO: hardcoded forceFreshReport to 0 for now.
#if CONFIG_HAS_0D_BUTTONS
  buttons0D_configure(&mSensorParams, &config->buttons0DConfig);
#endif
  weakObjectFilter_configure(&config->wofConfig);
#if CONFIG_HAS_FACE_DETECT
  faceDetect_configure(&config->faceDetectConfig);
#endif
#if CONFIG_HAS_THICK_GLOVE
  single_finger_configure(&config->sfConfig);
  thick_glove_configure(&config->sfConfig);
#endif
#if CONFIG_HIC_LPWG_MODE_B
  // TODO:  What if CONFIG_HAS_THICK_GLOVE is also defined?
  single_finger_configure(&config->sfConfig);
#endif
#if CONFIG_HAS_EXTREME_NOISE_REMOVER
  extreme_noise_remover_configure(&config->segConfig, &config->classConfig, &mSensorParams, &config->eNoiseRemoverConfig);
#endif
#if CONFIG_HAS_ADAPTIVE_LGM
  aLGM_configure(&config->aLGMConfig);
#endif
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
  metal_detect_configure(&config->metalDetectConfig);
#endif
#if CONFIG_HAS_ROW_COL_NOISE_REMOVER
  rowColumnNoiseRemover_configure(&mSensorParams, &config->rcNoiseRemoverConfig);
#endif
#if CONFIG_HAS_TDDI_AMP_MOISTURE
  moistureFilterAMP_configure(&config->ampMoistureConfig);
#endif
#if CONFIG_HAS_SIDE_TOUCH
  sideTouch_configure(&config->sideTouchTemporalFilterConfig);
#endif
#if CONFIG_HAS_ABS_CMNR_FILTER
  absFilter_configure(&config->absFilterConfig);
#endif
#if CONFIG_HAS_HYBRID_CHARGER_NOISE_MITIGATION
  hybridChargerNoiseMitigation_configure(&config->hybridChargerNoiseMitigationConfig);
#endif
#if CONFIG_HAS_GLOVE_SPATIAL_FILTER
  spatialFilter_configure(&config->spatialFilterConfig, spatialFilterType_glove);
#endif
}

/* -----------------------------------------------------------------
Name: imageFrameProcessor_getBaseline()
Purpose: Get a pointer to the baseline uint16 array.
Inputs: baseline type (baselineType_t enum)
Outputs: pointer to uint16 array holding the current baseline
         estimate of the requested type or NULL if baseline has not
         yet been acquired
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
uint16 *imageFrameProcessor_getBaseline(uint16 baselineType)
{
  if (baselineType == baselineType_trans && imageBaseline.acquired)
  {
    return imageBaseline.estimate;
  }
  else if (baselineType == baselineType_absx && absXBaseline.acquired)
  {
    return absXBaseline.estimate;
  }
  else if (baselineType == baselineType_absy && absYBaseline.acquired)
  {
    return absYBaseline.estimate;
  }
#if CONFIG_HAS_0D_BUTTONS
  else if (baselineType == baselineType_button)
  {
    return buttons0D_getBaseline();
  }
#endif
  else
  {
    return NULL;
  }
}

/* -----------------------------------------------------------------
Name: imageFrameProcessor_getDelta()
Purpose: Get a pointer to the delta uint16 array.
Inputs: baseline type (baselineType_t enum)
Outputs: pointer to uint16 array holding the current delta
         of the requested type or NULL if baseline has not
         yet been acquired
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
int16 *imageFrameProcessor_getDelta(uint16 baselineType)
{
  if (baselineType == baselineType_trans && imageBaseline.acquired)
  {
    return mDeltaImage;
  }
  else if (baselineType == baselineType_absx && absXBaseline.acquired)
  {
    return mDeltaXProfile;
  }
  else if (baselineType == baselineType_absy && absYBaseline.acquired)
  {
    return mDeltaYProfile;
  }
#if CONFIG_HAS_0D_BUTTONS
  else if (baselineType == baselineType_button)
  {
    return buttons0D_getDelta();
  }
#endif
  else
  {
    return NULL;
  }
}

/* -----------------------------------------------------------------
Name: imageFrameProcessor_getBaselineState()
Purpose: Determine whether the baseline of a given type has been acquired
Inputs: baseline type (baselineType_t enum)
Outputs: Baseline state (baselineState_t enum), either
         baselineState_noBaseline or baselineState_baselineAcquired
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
uint16 imageFrameProcessor_getBaselineState(uint16 baselineType)
{
  if (baselineType == baselineType_trans && imageBaseline.acquired)
  {
    return baselineState_baselineAcquired;
  }
  else if (baselineType == baselineType_absx && absXBaseline.acquired)
  {
    return baselineState_baselineAcquired;
  }
  else if (baselineType == baselineType_absy && absYBaseline.acquired)
  {
    return baselineState_baselineAcquired;
  }
#if CONFIG_HAS_0D_BUTTONS
  else if (baselineType == baselineType_button)
  {
    return buttons0D_getBaselineState();
  }
#endif
  else
  {
    return baselineState_noBaseline;
  }
}

/* -----------------------------------------------------------------
Name: imageFrameProcessor_computeTagsImage()
Purpose: Create the tag image for RT76 production test
Inputs: rawSrc
        dstTags
Outputs: None
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_computeTagsImage(int16 *rawSrc, int16 *dstTags)
{
  moistureDetector_computeTagsImage(rawSrc, dstTags);
}

#if CONFIG_HIC_LPWG_MODE_B
/* -----------------------------------------------------------------
Name: imageFrameProcessor_absFilterApplyFilter()
Purpose: Apply a filter to abs data
Inputs:  *frame.
Outputs: None.
Effects: None.
Notes:   Entry point for non-IFP code
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_absFilterApplyFilter(int16 *absPtr, uint16 num, uint16 isX)
{
  absFilter_applyFilter(absPtr, num, isX);
}

// From HIC
/* -----------------------------------------------------------------
Name: imageFrameProcessor_nextUltraLPWGFrame()
Purpose: Quick finger detection in LPWG abs cap TRGT mode
Inputs: frame - new raw image/profiles to process
        timeSinceLast_ms - time since the previous frame, in
                           milliseconds
        mode - specifies how IFP should behave, including the flags:
          noiseMitigationEnabled - set to true if firmware noise
                                   mitigation is currently being
                                   used.
          inhibitRelaxation - set to true to prevent any updates
                              of the baseline estimate.
Outputs: Loads finger positions in the reports structure.
Effects: No harmful effects.
Notes:
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_nextUltraLPWGFrame(reportData_t *report ATTR_UNUSED, ifpFrame_t *frame,
                                   ifpTimeStamp_t timeSinceLast_ms ATTR_UNUSED, ifpMode_t mode ATTR_UNUSED)
{
  int16 result;
  // Note: although we only track 2 objects the coordConv_convertPositions() code loops on MAX_OBJECTS
  // TODO: save RAM by only allocating two and writing a coordConv_convertPosition() like in HIC code
  sensorPosition_t SFSensorPositions[MAX_OBJECTS];
  hostPosition_t SFHostPositions[MAX_OBJECTS];
  uint16 i;

  int16 *deltaXProfilePtr = NULL;
  int16 *deltaYProfilePtr = NULL;
  deltaXProfilePtr = profileBaselineUpdater_removeX(frame->rawProfileRX, &absXBaseline, mDeltaXProfile);
  deltaYProfilePtr = profileBaselineUpdater_removeY(frame->rawProfileTX, &absYBaseline, mDeltaYProfile);

  // TODO: replaced with CONFIG_HAS_ABS_CMNR_FILTER?
  #if defined(cfg_f54_hasCMNR_Neg_Filter) && cfg_f54_hasCMNR_Neg_Filter
  {
    int32 deltaAve = 0;
    for(i=0;i<mSensorParams.txCount;i++)
        deltaAve += deltaYProfilePtr[i];

    if(deltaAve<0) {
        deltaAve /= mSensorParams.txCount;
        for(i=0;i<mSensorParams.txCount;i++)
            deltaYProfilePtr[i] -= deltaAve;
    }
  }
  #endif

  if (CONFIG_HAS_ABS_CMNR_FILTER)
  {
    absFilter_applyFilter(deltaXProfilePtr, mSensorParams.rxCount, 1);
    absFilter_applyFilter(deltaYProfilePtr, mSensorParams.txCount, 0);
  }

  // clear single finger sensor position report
  memset16(&SFSensorPositions, 0, sizeof(SFSensorPositions) / sizeof(uint16));
  memset16(&SFHostPositions, 0, sizeof(SFHostPositions) / sizeof(uint16));

  result = SF_process(mDeltaXProfile, mSensorParams.rxCount, mDeltaYProfile, mSensorParams.txCount,
      SF_dynamic_threshold_high, REPORT_TWO_WITH_MAX_ENERGY, SF_ForceSF_client,
      SFSensorPositions);  // returns # fingers << 1 | freshData

  report->SFReport.objectsPresent = 0;
  if (result >> 1)
  {
    for (i = 0; i < 2; i++)
    {
      coordConv_convertPositions(&SFSensorPositions[i], &SFHostPositions[i]);
    }
    report->SFReport.objectsPresent = 1;
  }
  for (i = 0; i < 2; i++)
  {
    // set the classification if z>0, used in gesture_detect(), 0 otherwise (hostClassification_none)
    if (SFHostPositions[i].z)
      report->SFReport.pos[i].classification = hostClassification_finger;
    report->SFReport.pos[i].xMeas = SFHostPositions[i].xPosition;
    report->SFReport.pos[i].yMeas = SFHostPositions[i].yPosition;
    report->SFReport.pos[i].z = SFHostPositions[i].z;
    report->SFReport.pos[i].xWidth = SFHostPositions[i].xWidth;
    report->SFReport.pos[i].yWidth = SFHostPositions[i].yWidth;
  }
  report->SFReport.freshData = (result & 0x1) ? 1 : 0;
  report->SFReport.type = abs_TRGT_SF; // Tag the single finger report type for down-stream processing

  {
    // There is no baseline recovery mechanism as of now
    relaxCommand_t relaxCommand;
    relaxCommand = baselineManager_manage((uint16) report->SFReport.objectsPresent,
                                          0, 0, (uint16) mode.inhibitRelaxation,
                                          timeSinceLast_ms);
    profileBaselineUpdater_updateX(relaxCommand, timeSinceLast_ms, frame->rawProfileRX, &absXBaseline);
    profileBaselineUpdater_updateY(relaxCommand, timeSinceLast_ms, frame->rawProfileTX, &absYBaseline);
  }
}
#endif

/* -----------------------------------------------------------------
Name: imageFrameProcessor_nextFrame()
Purpose: Process a new image frame
Inputs: frame - new raw image/profiles to process
        timeSinceLast_ms - time since the previous frame, in
                           milliseconds
        mode - specifies how IFP should behave, including the flags:
          noiseMitigationEnabled - set to true if firmware noise
                                   mitigation is currently being
                                   used.
          inhibitRelaxation - set to true to prevent any updates
                              of the baseline estimate.
Outputs: report - the report structure.
Effects: Updates internal module states.
Notes: - On the first frame, timeSinceLast_ms is ignored.
       - The timeSinceLast_ms parameter is used for tracking objects
       and classifying them. You must provide a reasonable value
       close to your actual frame period for it--zero will not work.
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_nextFrame(reportData_t *report, ifpFrame_t *frame,
                                   ifpTimeStamp_t timeSinceLast_ms, ifpMode_t mode)
{
  int16 *deltaXProfilePtr = NULL;
  int16 *deltaYProfilePtr = NULL;

  //
  // These comments correspond to ifp_guide.rst "High-Level Overview"
  //

  // --> And these to ifp_guide.rst "System Specification" (diagram)

  //
  // Raw image
  //

  // --> Remove Baseline (find the delta image)
  baselineUpdater_remove(&mSensorParams, frame->rawImage, &imageBaseline, mDeltaImage);

  #if CONFIG_HAS_GLOVE_CMNR
  glove_CMNR();
  #endif
  #if CONFIG_HAS_GLOVE_SPATIAL_FILTER
    spatialFilter_processFrame(&mSensorParams, mDeltaImage, spatialFilterDelta_padded, spatialFilterType_glove);
  #endif
  if (CONFIG_HAS_HYBRID)
  {
    deltaXProfilePtr = profileBaselineUpdater_removeX(frame->rawProfileRX, &absXBaseline, mDeltaXProfile);
    deltaYProfilePtr = profileBaselineUpdater_removeY(frame->rawProfileTX, &absYBaseline, mDeltaYProfile);
  }

  #if CONFIG_HAS_DIRTY_GLOVE
  dirtyGlove_clean(timeSinceLast_ms);
  #endif

#if defined(CONFIG_ACTIVE_ZONE_ENABLE) && CONFIG_ACTIVE_ZONE_ENABLE
  calcStaticConfig_t scfg;
  COMM_getStaticConfig(&scfg);
  if (scfg.lpwgParams.ActiveZoneEn && mode.closedCoverOperation){
    uint16 i, j;
    int16 *pdImg;
    // erase inactive area data.
    pdImg = mDeltaImage + (MAX_RX+1) + 1;
    for (i=0; i<MAX_TX; i++)
    {
      for (j=0; j<MAX_RX; j++)
      {
        if((i<scfg.lpwgParams.ActiveZoneX0) || (i>scfg.lpwgParams.ActiveZoneX1)|| (j<scfg.lpwgParams.ActiveZoneY0)|| (j>scfg.lpwgParams.ActiveZoneY1))
         *pdImg = 0;

        *pdImg++;
      }
      pdImg++;
    }
  }
#endif
#if defined(CONFIG_IFP_FORCE_DETECT) && CONFIG_IFP_FORCE_DETECT
  if(ifpAdvFeatureEn)
  {
    forceDetect_copy(mDeltaImage, frame->rawImage);
  }
#endif
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
  metal_detection_detect(mDeltaImage);
#endif
  if (CONFIG_HAS_ROW_COL_NOISE_REMOVER)
  {
    rowColumnNoiseRemover_removeColumnNoise(mDeltaImage);
    rowColumnNoiseRemover_removeRowNoise(mDeltaImage);
  }

  // --> Gain Compensator
  if (!mode.inhibitGainCompensation)
  {
    gainCompensator_compensateGain(&mSensorParams, mDeltaImage);
  }

  // --> Hybrid Display Noise Remover / Display Noise Remover
  if (CONFIG_HAS_HYBRID)
  {
    if (CONFIG_HAS_HYBRID_DISPLAY_NOISE_REMOVER && !mode.inhibitHybridDisplayNoiseRemoval)
    {
      if (CONFIG_HAS_RX_MUXING)
      {
        uint16 hdnrError = muxRXHybridDisplayNoiseRemover_remove(&mSensorParams, mDeltaImage, deltaYProfilePtr, deltaXProfilePtr);
        ifpActionFlags.hdnrError = !(hdnrError == 0);
        // ifpActionFlags retain their values from the previous frame if not modified/cleared
      }
      else if (CONFIG_HAS_TX_MUXING)
      {
        muxTXHybridDisplayNoiseRemover_remove(&mSensorParams, mDeltaImage, deltaYProfilePtr, deltaXProfilePtr);
      }
      else
      {
      hybridDisplayNoiseRemover_remove(&mSensorParams, mDeltaImage, deltaYProfilePtr, deltaXProfilePtr);
      }
    }
  }
  else if (CONFIG_HAS_DISPLAY_NOISE_REMOVER && !mode.inhibitDisplayNoiseRemoval)
  {
    displayNoiseRemover_remove(&mSensorParams, (uint16) mode.inhibitDisplayNoiseRemovalGlobalMedian, mDeltaImage);
  }

  // --> Anti-Bending Corrector
  if (CONFIG_HAS_ANTI_BENDING && !mode.inhibitAntiBending)
  {
    antiBending_correctImage(&mSensorParams, mDeltaImage);
    if (CONFIG_HAS_HYBRID && !mode.inhibitProfileAntiBending)
    {
      antiBending_correctXProfile(&mSensorParams, deltaXProfilePtr);
      antiBending_correctYProfile(&mSensorParams, deltaYProfilePtr);
    }
  }

  if (CONFIG_HAS_ADAPTIVE_LGM)
  {
    setAlgmEnabled(mode.enableALGM);
    if(imageBaseline.acquired)
    {
      adaptive_LGM_compensate(mDeltaImage, &mSensorParams);
    }
    else
    {
      //- Set init cSat_LSB value
      adaptive_lgm_initCSat (mSensorParams.cSat_LSB);
    }
  }

  // --> Shadow Remover
  if (CONFIG_HAS_SHADOW_REMOVER && !mode.inhibitShadowRemoval)
  {
    shadowRemover_remove(mDeltaImage, &mSensorParams);
  }
  if (!mode.inhibitShadowRemovalAMP)
  {
    shadowRemoverAMP_remove(mDeltaImage, &mSensorParams);
  }

  // --> Low Ground Mass Manager and Corrector
  if (CONFIG_HAS_LGM_CORRECTOR && !(CONFIG_HAS_MOISTURE && ifpActionFlags.filterMoisture) && !mode.noiseMitigationEnabled)
  {
    lgmManagerParams_t lgmManagerParams;
    lgmManager_manage(mDeltaImage, deltaXProfilePtr, deltaYProfilePtr, &mSensorParams,
                      (uint16) mode.inhibitLGMCorrection, &lgmManagerParams);
    lgmCorrector_correct(mDeltaImage, deltaXProfilePtr, deltaYProfilePtr, &mSensorParams, &lgmManagerParams);
  }

  if (CONFIG_HAS_ABS_CMNR_FILTER)
  {
    absFilter_applyFilter(deltaXProfilePtr, mSensorParams.rxCount, 1);
    absFilter_applyFilter(deltaYProfilePtr, mSensorParams.txCount, 0);
  }

  if (CONFIG_HAS_HYBRID && CONFIG_HAS_HYBRID_CHARGER_NOISE_MITIGATION && mode.noiseMitigationEnabled)
  {
    hybridChargerNoiseMitigation_filter(&mSensorParams, mDeltaImage, mDeltaYProfile);
  }

  if (CONFIG_HAS_EXTREME_NOISE_REMOVER)
  {
    // IIR to the delta image. Filter strength can be managed dynamically.
    if (mode.noiseMitigationEnabled)
    {
      updateDeltaIIR(mDeltaImage);
    }
    else
    {
      initDeltaIIR(mDeltaImage);
    }

    // Control mergeThreshold and minPeak - currently hardcoded.
    setSegmenterParams(mode.noiseMitigationEnabled);
  }

  if (CONFIG_HAS_SMALL_OBJECT_DETECTOR)
  {
    penRecorrector_recorrectPen(&mSensorParams, frame->rawImage,  &imageBaseline, mDeltaImage);
  }

  // Aggressively restrict the scope of these stack variables via blocks. The
  // compiler cannot limit the scope for us if we use the STACKED attribute.
  // The deepest stack is the combination of the clumps structure and the
  // tracker.
  {
  #if CONFIG_HAS_LGM_DETECTOR
    detectLGM_check();
  #endif

    int16 sfFreshData ATTR_UNUSED = 0;
    int16 sfFingerCount ATTR_UNUSED = 0;
    int16 sfType ATTR_UNUSED = 0;
    int16 thickGloveSFResult ATTR_UNUSED = 0;
    uint16 originalTouchType[MAX_OBJECTS] = {touchType_none, };

    classification_t classifications[MAX_OBJECTS] IFP_STACKED;
    sensorPosition_t sensorPositions[MAX_OBJECTS] IFP_STACKED;
    clumps_t clumps IFP_STACKED;
    buttons0DReport_t buttons0DReport IFP_STACKED;
    trackedObject_t *trackedObjPtr = NULL;
    memset16(&buttons0DReport, 0, sizeof(buttons0DReport_t) / sizeof(uint16));

    //
    // Segmentation
    //

    // --> Segmenter
    segmenter_segment(mDeltaImage, mSensorParams.noiseFloor_LSB, &mSensorParams, &clumps);

    // --> Noise Blobs Filter
    if (mode.noiseMitigationEnabled)
    {  // Reduce the number of blobs, to not saturate the touch buffer later
      filterNoiseBlobs_filter(&mSensorParams, mDeltaImage, &clumps);
    }

    if (CONFIG_HAS_TDDI_AMP_MOISTURE && !mode.inhibitMoistureMitigationAMP)
    {
      ifpActionFlags.filterMoistureAMP = moistureFilterAMP_detect(&mSensorParams, mDeltaImage, &clumps) ? 1 : 0;
    }

    // --> Moisture Filter
    if (CONFIG_HAS_MOISTURE && !mode.inhibitMoistureMitigation)
    {
      uint16 moistureAction;
      if (!mode.noiseMitigationEnabled)
      {
        moistureAction = moistureDetector_detect(&mSensorParams, mDeltaImage, deltaXProfilePtr, deltaYProfilePtr, frame->rawImage, &clumps);
      }
      else
      {
        moistureDetector_reinit();
        moistureAction = moistureAction_none;
      }
      ifpActionFlags.filterMoisture = (moistureAction == moistureAction_filter ||
                                       moistureAction == moistureAction_filterAndFreeze);
      ifpActionFlags.forceFastRelax = moistureAction == moistureAction_fastRelax;
      ifpActionFlags.freezeBaseline = moistureAction == moistureAction_filterAndFreeze;
    }

    if (ifpActionFlags.forceFastRelax)
    {
      // During force fast relax, we typically want to report nothing and undo
      // any corruption of width estimates.
      memset16(classifications, 0, MAX_OBJECTS * sizeof(*classifications) / sizeof(uint16));
      memset16(sensorPositions, 0, MAX_OBJECTS * sizeof(*sensorPositions) / sizeof(uint16));
      positionEstimator_reinit();
    }
    else
    {
      // --> Linear Swipe Splitter / Clump Splitter / Moisture Filter Clumps
      if (CONFIG_HAS_MOISTURE && ifpActionFlags.filterMoisture)
      {
        moistureFilter_filterClumps(mDeltaImage, mDeltaXProfile, mDeltaYProfile, &mSensorParams, &clumps);
      }
      else if (CONFIG_HAS_TDDI_AMP_MOISTURE && ifpActionFlags.filterMoistureAMP)
      {
        moistureFilterAMP_filter(&clumps);
      }
      else  // normal
      {
        // no need to split clump more when raw ADC fluctuates severely due to noise
        if ((!CONFIG_HAS_EXTREME_NOISE_REMOVER) ||
            (CONFIG_HAS_EXTREME_NOISE_REMOVER && !CONFIG_EXT_CENTROID_POSITIONING ) ||
            (CONFIG_HAS_EXTREME_NOISE_REMOVER && !mode.noiseMitigationEnabled)
            )
        {
          if (CONFIG_HAS_LINEAR_SWIPE_SPLITTER)
          {
            linearSwipeSplitter_split(&mSensorParams, mDeltaImage, &clumps);
          }
          else
          {
            clumpSplitter_split(mDeltaImage, mSensorParams.cSat_LSB, &clumps);
          }
        }
      }

      // --> Circumscriber
      circumscriber_circumscribeClumps(&clumps, mDeltaImage, &mSensorParams);

      //
      // Object Tracking
      //

      // --> Tracker
    #if CONFIG_HAS_LGM_MERGER
      tracker_first_drawer();
    #endif
      trackedObjPtr = tracker_track(mDeltaImage, &clumps, timeSinceLast_ms, &mSensorParams);

    #if CONFIG_HAS_NOISY_WIRELESS_CHARGER
      noisyWirelessCharger_check(trackedObjPtr, &deltaXProfilePtr, &deltaYProfilePtr);
    #endif


    #if CONFIG_HAS_LGM_MERGER
      mergeLGM(deltaXProfilePtr, deltaYProfilePtr, &trackedObjPtr, &clumps, timeSinceLast_ms);
    #endif

      // --> Unison Noise Remover
      if (!mode.inhibitUnisonNoiseRemoval)
      {
      unisonNoiseRemover_remove(&mSensorParams, mDeltaImage, &clumps);
      }

      //
      // Classification
      //

      // --> Classifier
      classifier_classify(&mSensorParams, mDeltaImage, deltaXProfilePtr, deltaYProfilePtr,
                          &clumps, trackedObjPtr, classifications);

    #if CONFIG_HAS_GLOVE_ONLY && CONFIG_HAS_GLOVE_ONLY2
      if (mSensorParams.GloveOnly.Early)
      {
        suppressGloves(classifications);
      }
    #endif

    #if CONFIG_HAS_HYBRID_REZERO
      hybridRezero_prepare(classifications);
    #endif

    #if CONFIG_HAS_METAL_SLUG_SUPPRESION
      suppressMetalSlug(&clumps, classifications, trackedObjPtr);
    #endif

    #if CONFIG_HAS_GLOVE_NOISE_FLOOR
      updateGloveNF(classifications);
    #endif

      if (CONFIG_HAS_MOISTURE && ifpActionFlags.filterMoisture)
      {
        moistureFilter_processClassifications(trackedObjPtr, classifications);
      }
      else if (CONFIG_HAS_FIST_REJECT && !mode.inhibitFistReject && !mode.noiseMitigationEnabled)
      {
        fistReject_detect(deltaXProfilePtr, deltaYProfilePtr, &clumps, trackedObjPtr, classifications, &mSensorParams);
      }

      // --> Weak Object Filter
      if (!mode.inhibitWeakObjectFilter)
      {
        weakObjectFilter_filter(classifications, trackedObjPtr, &clumps, mDeltaImage);
      }

      // Force classified object as palm to use centroid positioning.
      if (CONFIG_HAS_EXTREME_NOISE_REMOVER && CONFIG_EXT_CENTROID_POSITIONING && mode.noiseMitigationEnabled)
      {
        rephraseTouchType(trackedObjPtr, classifications, touchType_palm, originalTouchType);
      }

      //
      // Fine Position Estimation
      //

      // --> Position Estimator
      positionEstimator_calcPositions(&mSensorParams, mDeltaImage, &clumps, trackedObjPtr,
                                      classifications, sensorPositions);

    #if CONFIG_HAS_GLOVE_DELAY
      gloveDelay_delay(classifications, sensorPositions);
    #endif

      // Object type will be assigned as classified object as it was.
      if (CONFIG_HAS_EXTREME_NOISE_REMOVER && CONFIG_EXT_CENTROID_POSITIONING && mode.noiseMitigationEnabled)
      {
        rephraseTouchType(trackedObjPtr, classifications, touchType_none, originalTouchType);
      }
      // thick glove
      if ( CONFIG_HAS_THICK_GLOVE &&(mode.thickGloveEnabled) && (!mode.noiseMitigationEnabled)) {
        if (!(sfFingerCount || sfFreshData)) {
          doThickGloveProcessing(&mSensorParams, deltaXProfilePtr, deltaYProfilePtr, classifications, sensorPositions, &thickGloveSFResult);
          sfFreshData = thickGloveSFResult & 0x01;
          sfFingerCount = thickGloveSFResult & 0x02;
          if (sfFingerCount || sfFreshData) {
            sfType = hostClassification_thickGlove;
          }
        }
      }
      if (CONFIG_HAS_SMALL_OBJECT_DETECTOR)
      {
        penRecorrector_setPenTarget(trackedObjPtr, &clumps, classifications);
      }
    }

  #if CONFIG_HAS_LANDING_LARGE_FINGER_DROP
    landingLarge_drop(classifications, sensorPositions);
  #endif

    // --> Kalman or Land-Lift Jitter Filter
    if (CONFIG_HAS_KALMAN_FILTER)
    {
      kalmanFilter_filterPositions(&mSensorParams, sensorPositions, classifications);
    }
    landLiftJitterFilter_filterPositions(sensorPositions, classifications, (uint16) (ifpActionFlags.filterMoisture | ifpActionFlags.filterMoistureAMP));
#if CONFIG_HAS_0D_BUTTONS
    if (CONFIG_HAS_0D_BUTTONS && mSensorParams.buttonsCount > 0)
    {
      buttons0D_analyzeData(frame->rawAbsButtons, classifications, &buttons0DReport, timeSinceLast_ms , mode.inhibitRelaxation);
    }
#endif
    {
      hostPosition_t hostPositions[MAX_OBJECTS] IFP_STACKED;

      // --> Coordinate Converter
      coordConv_convertPositions(sensorPositions, hostPositions);

      #if CONFIG_HAS_CORNER_SUPPRESSION
      suppressCorner(sensorPositions, classifications);
      #endif

      #if CONFIG_HAS_GRIP_SUPPRESSION_4
      suppress_grip(&clumps, trackedObjPtr, classifications, hostPositions);
      #endif

      #if CONFIG_HAS_METAL_PLATE_SUPPRESSION
      suppressMetalPlate(classifications);
      #endif

      #if CONFIG_HAS_NUM_GLOVES
      discardGloves(classifications);
      #endif

      #if CONFIG_HAS_GLOVE_ONLY
      #if CONFIG_HAS_GLOVE_ONLY2
      if (!mSensorParams.GloveOnly.Early)
      #endif
      {
        suppressGloves(classifications);
      }
      #endif

      #if CONFIG_HAS_GLOVE_SUPPRESSION
      gloveSuppression_suppress(classifications, sensorPositions);
      #endif

      // --> Position Reporter
      posReporter_makeReport(hostPositions, sensorPositions, classifications,
                             (uint16) mode.holdLiftedIndices, (uint16) ifpActionFlags.filterMoisture, report);

      if ( CONFIG_HAS_THICK_GLOVE && (sfFingerCount || sfFreshData) ) {
        reportPos_t *rep1 = &report->pos[0];
        hostPosition_t *hostPos1 = &hostPositions[0];
        uint16 thickGlovePresent = 0;

        rep1->xMeas = hostPos1->xPosition;
        rep1->yMeas = hostPos1->yPosition;
        rep1->xWidth = hostPos1->xWidth;
        rep1->yWidth = hostPos1->yWidth;
        rep1->txPos = sensorPositions[0].yPosition;
        rep1->rxPos = sensorPositions[0].xPosition;
        rep1->z = hostPos1->z;
        report->sfFreshData = sfFreshData ? 1 : 0;
        get_thick_glove_present(&thickGlovePresent);
        report->thickGlovePresent = thickGlovePresent;
        report->objectsPresent = sfFingerCount ? 1 : 0;
        rep1->classification = sfType;
      }

      touchBuffer_update(report, mode.noiseMitigationEnabled);
      #if CONFIG_IFP_CLOSEDCOVER
        if(getClosedCoverStatus())
        {
          // do not report Buttons
        }
        else
      #endif
        {
#if CONFIG_HAS_0D_BUTTONS
            report->buttons0DReport = buttons0DReport;
            //report->freshData |= buttons0DReport.freshData; //don't assert func12 interrupt for button, since button will be reported from func1A
            report->objectsPresent |= buttons0DReport.objectPresent;
#endif

          //
          // Reported Data
          //
        }
    }

    positionEstimator_reportGaussianWidth(&report->tuning.gaussianWidthX, &report->tuning.gaussianWidthY);
    report->tuning.smallObjectFeatures = classifier_getSmallObjectFeatures();
    report->tuning.fistFeatures = fistReject_getFistFeatures();
#if CONFIG_HAS_0D_BUTTONS
    memcpy16(report->tuning.buttons0DVariances, buttons0D_getVariance(), MAX_BUTTONS);
#endif
    if (CONFIG_HAS_ADAPTIVE_LGM)
    {
      //- Set cSat_LSB to init value
      adaptive_lgm_recoverCSat (&mSensorParams.cSat_LSB);
    }

    {
      uint16 objectsPresent, errorsPresent;
      uint16 relaxCommand;

      // --> Check Baseline
      baselineChecker_check(&mSensorParams, frame, &imageBaseline, &absXBaseline, &absYBaseline,
                            mDeltaImage, classifications, &objectsPresent, &errorsPresent);

      // --> Manage Baseline
      relaxCommand = baselineManager_manage(
        (uint16) (objectsPresent || (uint16) ifpActionFlags.freezeBaseline),
        errorsPresent, (uint16) ifpActionFlags.forceFastRelax, (uint16) mode.inhibitRelaxation,
        timeSinceLast_ms);

    #if CONFIG_HAS_PROFILE_BASELINE_CONTROL
      assessProfile(&relaxCommand, deltaXProfilePtr, deltaYProfilePtr);
    #endif

    #if CONFIG_HAS_CUSTOM_ENERGY_RATIO
      energyRatio_check(&relaxCommand);
    #endif

    #if CONFIG_HAS_HYBRID_REZERO
      hybridRezero_check(&relaxCommand, deltaXProfilePtr);
    #endif

    #if CONFIG_HAS_NEGATIVE_REZERO
      negativeRezero_check(&relaxCommand);
    #endif

      // --> Update Baseline
      baselineUpdater_update(&mSensorParams, relaxCommand, timeSinceLast_ms, frame->rawImage, &imageBaseline);
      if (CONFIG_HAS_HYBRID)
      {
        profileBaselineUpdater_updateX(relaxCommand, timeSinceLast_ms, frame->rawProfileRX, &absXBaseline);
        profileBaselineUpdater_updateY(relaxCommand, timeSinceLast_ms, frame->rawProfileTX, &absYBaseline);
      }
    }

    if (mode.knuckleEnabled)
    {
      getRoiPeak7x7Data(trackedObjPtr, &clumps, report);
    }

  }
  if ( CONFIG_HAS_FACE_DETECT && mode.faceDetectEnable )
  {
    if (CONFIG_HAS_TDDI_AMP_FACE_DETECT)
    {
      report->faceDetected= isFaceDetected(frame->rawImage);
    }
    else
    {
      report->faceDetected = isFaceDetected(frame->rawProfileRX);
    }
    if (report->faceDetected)
    {
      report->freshData =1;
    }
  }
  if (CONFIG_HAS_SIDE_TOUCH && mode.enableSideTouch)
  {
    sideTouch_run(frame->rawImage);
  }
}
