// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: ifp_vector_util.c
// Description: Some vector operations for ifp
//
// $Id:$

#include "ifp_common.h"
#include "ifp_vector_util.h"
#include "calc_config.h"
#include "ifp.h"
#include "ifp_string.h"

#ifndef CONFIG_INHIBIT_HYDRA
#define CONFIG_INHIBIT_HYDRA 0
#endif

#ifndef CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY
#define CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY 0
#endif

#if !defined(__CHIMERA__) && defined(MATLAB_MEX_FILE)
#include "mex.h"
#endif

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: ifp_vector_util_configure()
Purpose: Configure the module.
Inputs: None
Outputs: None.
Effects: enables hydra if available, always necessary
Notes: Some functions of ifp_vector_util have an hydra implementation.
Hydra must be enabled before they ever get called.
Configure of other modules my use hydra functions like memset16,
so ifp_vector_util_configure() should be called first.
Example: None.
----------------------------------------------------------------- */
void ifp_vector_util_configure(void)
{
  hydra_enable();
}

/* -----------------------------------------------------------------
Name: ifp_vector_util_init()
Purpose: Initialize
Inputs: None.
Outputs: None.
Effects: Enables hydra if available, not necessary if rezero does not switch off hydra.
         Resets the module at power-on.
Notes: This function must be called before using the module.
Example: None.
----------------------------------------------------------------- */
void ifp_vector_util_init(void)
{
  hydra_enable();
}

/* -----------------------------------------------------------------
Name: ifp_vector_util_reinit()
Purpose: Re-initialize
Inputs: None.
Outputs: None.
Effects: Enables hydra if available, not necessary if rezero does not switch off hydra.
         Resets the module at rezero.
Notes: This function must be called if the host sends a rezero command.
Example: None.
----------------------------------------------------------------- */
void ifp_vector_util_reinit(void)
{
  ifp_vector_util_init();
}

#if CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY == 1 || !(defined(__CHIMERA__) && __CHIMERA_VERSION__ >= 23)
#include <stdint.h>  // for scalarProductMean

/*
Name: scalarMultiplyAccumulate
Purpose: Helper function that returns the sum of a vector multiplied by a scalar
Inputs: input - pointer to the vector
        alpha - scalar
        numElements - the number of elements to sum over
Outputs: scalarProductSum - int32 containing the sum of the scalar multipled by the vector
Effects: None.
*/
int32 scalarMultiplyAccumulate(int16 *input, int16 alpha, uint16 numElements)
{
  int32 sum = 0;
  while (numElements--)
  {
    sum += (int32) alpha * *input++;
  }
  return sum;
}

/*
Name: sum16Stride
Purpose: Compute the sum of an array on the orthogonal axis
Inputs: Pointer to start of memory, size of array, stride
        (length between two elements on the orthogonal axis)
Outputs: sum of elements in the array in 32 bit precision
Notes: On Chimera, this is replaced with an assembly version that uses a
       single-cycle multiply-accumulate instruction (SMAC), making use
       of stride
*/
int32 sum16Stride(int16 *input, uint16 numElements, uint16 stride)
{
  uint16 i;
  int16 *pSrc = input;
  int32 sum = 0;
  for (i = 0; i < numElements; i++)
  {
    sum += *pSrc;
    pSrc += stride;
  }
  return sum;
}

/*
Name: scalarProduct
Purpose: Compute the dot product or scalar product of two vectors
Inputs: Two 16-bit vectors and the length of the vector
Outputs: The Scalar product as 32 bit integer
Notes: On Chimera, this is replaced with an assembly version that uses a
       single-cycle multiply-accumulate instruction (SMAC).
*/
int32 scalarProduct(int16 *veca, int16 *vecb, uint16 numElements)
{
  int32 dotProduct32 = 0;
  uint16 i;
  for (i = 0; i < numElements; i++)
  {
    dotProduct32 += (int32) *veca++ * *vecb++;
  }
  return dotProduct32;
}

/*
Name: applyCorrectionRow
Purpose: Helper function that applies a correction to deltaRow. The values in rxWeights,
         after scaling by txAmp, are subtracted elementwise from deltaRow. Note that rxWeights
         and txAmp are fixed point and their product is rounded before subtraction.
Inputs: rxWeights   - pointer to vector of correction weights
        deltaRow    - pointer to the row in deltaImage to be corrected
        numElements - number of elements in rxWeights and deltaRow
        txAmp       - scaling to apply to rxWeights before correction
Outputs: None.
Effects: deltaRow is corrected in place.
Notes: When rounding the result of each multiplication, ties are broken towards inf
       instead of the standard away from 0
*/
void applyCorrectionRow(uint8p8 *rxWeights, int16 *deltaRow, uint16 numElements, int24p8 txAmp)
{
  uint16 col;
  for (col = 0; col < numElements; col++)
  {
    *deltaRow++ -= (int16) ((txAmp * *rxWeights++ + 0x8000) >> 16);
  }
  return;
}

/* -----------------------------------------------------------------
Name: findMax, findMin
Purpose: Find the min/max element of a vector
Inputs: vector and its length
Outputs: max/min value
Notes: On Chimera, these are replaced with an assembly version using
       a single-cycle median of 3 compare and update (SMED)
----------------------------------------------------------------- */
int16 findMax(int16 *inputVector, uint16 vectorLength)
{
  uint16 i;
  int16 maxVal = *inputVector++;

  if (vectorLength == 0) return 0x7FFF;  // INT16_MAX

  for (i = 0; i < (vectorLength - 1); i++)
  {
    if (*inputVector > maxVal) maxVal = *inputVector;
    inputVector++;
  }

  return maxVal;
}

int16 findMin(int16 *inputVector, uint16 vectorLength)
{
  uint16 i;
  int16 minVal = *inputVector++;

  if (vectorLength == 0) return 0x8000;  // INT16_MIN

  for (i = 0; i < (vectorLength - 1); i++)
  {
    if (*inputVector < minVal) minVal = *inputVector;
    inputVector++;
  }

  return minVal;
}

/*
Name: sum32
Purpose: Compute the sum of an int32 array
Inputs: Pointer to start of memory, size of array
Outputs: sum of elements in the array in 32 bit precision
Notes: On Chimera, this is replaced with an assembly version that uses a
       pair of single-cycle multiply-accumulate instructions (SMAC, UMAC).
*/
int32 sum32(int32 *input, uint16 numElements)
{
  int32 sum = 0;
  while (numElements--)
  {
    sum += *input++;
  }
  return sum;
}

#endif  // CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY == 1 || !(defined(__CHIMERA__) && __CHIMERA_VERSION__ >= 23)

#if !(defined(__CHIMERA__) && __CHIMERA_VERSION__ >= 23)
/*
Name: calculateMean
Purpose: Compute the mean of an array
Inputs: Pointer to start of memory, size of array. Size must be <= INT16_MAX (32767)
Outputs: mean of the array in 32 bit precision
Notes: On Chimera, this is replaced with an assembly version that uses a
       single-cycle multiply-accumulate instruction (SMAC).
*/
int16 calculateMean(int16 *input, uint16 numElements)
{
  int32 sum = 0;
  uint16 i;

  if (numElements > 0x7FFF)  // > INT16_MAX
  {
#if !defined(__CHIMERA__) && defined(MATLAB_MEX_FILE)
    mexErrMsgIdAndTxt("IFP:IFPVectorUtil:valueError",
      "Tried to calculate mean of array of length more than 32767");
#else
    return 0;
#endif
  }
  else if (numElements == 0)
  {
    return 0;
  }

  for (i = 0; i < numElements; i++)
  {
    sum += *input++;
  }
  if (sum >= 0)
  {
    return (int16) ((float) sum / numElements + 0.5);
  }
  else
  {
    return (int16) ((float) sum / numElements - 0.5);
  }
}

/*
Name: var16Stride
Purpose: Compute the variance of an array on the orthogonal axis
Inputs: Pointer to start of memory, size of array, stride
        (length between two elements on the orthogonal axis), and mean of array
Outputs: variance of elements in the array in 32 bit precision
Notes: On Chimera, this is replaced with an assembly version that uses a
       single-cycle multiply-accumulate instruction (UMAC), making use
       of stride
*/
int32 var16Stride(int16 *input, uint16 numElements, uint16 stride, int16 mean)
{
  int64_t sum = 0;
  uint16 i;

  if (numElements > 0x7FFF)  // > INT16_MAX
  {
#if !defined(__CHIMERA__) && defined(MATLAB_MEX_FILE)
    mexErrMsgIdAndTxt("IFP:IFPVectorUtil:valueError",
      "Tried to calculate mean of array of length more than 32767");
#else
    return 0;
#endif
  }
  else if (numElements == 0)
  {
    return 0;
  }

  for (i = 0; i < numElements; i++)
  {
    sum += input[i*stride] * input[i*stride];
  }

  return (int32) (sum / (double) numElements + 0.5) - mean * mean;
}

/*
Name: scalarProductMean
Purpose: Compute the dot product or scalar product of two vectors divided by the number of elements
Inputs: Two 16-bit vectors and the length of the vector. Length must be <= INT16_MAX (32767)
Outputs: The Scalar product as 32 bit integer divided by the number of elements
Notes: On Chimera, this is replaced with an assembly version that uses a
       single-cycle multiply-accumulate instruction (SMAC).
*/
int32 scalarProductMean(int16 *veca, int16 *vecb, uint16 numElements)
{
  int64_t dotProduct = 0;
  uint16 i;

  if (numElements > 0x7FFF)  // > INT16_MAX
  {
#if !defined(__CHIMERA__) && defined(MATLAB_MEX_FILE)
    mexErrMsgIdAndTxt("IFP:IFPVectorUtil:valueError",
      "Tried to calculate mean of array of length more than 32767");
#else
    return 0;
#endif
  }
  else if (numElements == 0)
  {
    return 0;
  }

  for (i = 0; i < numElements; i++)
  {
    dotProduct += (int64_t) *veca++ * *vecb++;
  }
  if (dotProduct >= 0)
  {
    return (int32) (dotProduct / (double) numElements + 0.5);
  }
  else
  {
    return (int32) (dotProduct / (double) numElements - 0.5);
  }
}

#endif

/*
Name: sum16
Purpose: Compute the sum of an array
Inputs: Pointer to start of memory, size of array
Outputs: sum of elements in the array in 32 bit precision
Notes: On Chimera, this is replaced with an assembly version that uses a
       single-cycle multiply-accumulate instruction (SMAC).
*/
#if CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY == 0 && defined(__CHIMERA__) && __CHIMERA_VERSION__ >= 23
int32 sum16(int16 *input, uint16 numElements)
{
  return scalarMultiplyAccumulate(input, 1, numElements);
}
#else
int32 sum16(int16 *input, uint16 numElements)
{
  int32 sum = 0;
  while (numElements--)
  {
    sum += *input++;
  }
  return sum;
}
#endif

///* -----------------------------------------------------------------
//Name: argMin32
//Purpose: Compute argMin of a list of int32
//Inputs: list, list length
//Outputs: argMin
//----------------------------------------------------------------- */
#if CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY == 1 || !(defined(__CHIMERA__) && __CHIMERA_VERSION__ > 30)
uint16 argMin32(int32 *list, uint16 length)
{
  if (length < 2)
  {
    return 0;
  }

  {
    /* Assuming 'length' is at least 2 */
    int32 min;
    uint16 j=length-1, minidx = j;
    list += j--;
    min = *list--;

    do
    {
      int32 val = *list--;
      if (val <= min) {
        min = val;
        minidx = j;
      }
    } while (j--);
    return minidx;
  }
}
#else
extern uint16 argMin32(int32 *list, uint16 length);
#endif

///* -----------------------------------------------------------------
//Name: argMax32
//Purpose: Compute argMax of a list of int32
//Inputs: list, list length
//Outputs: argMax
//----------------------------------------------------------------- */
#if CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY == 1 || !(defined(__CHIMERA__) && __CHIMERA_VERSION__ > 30)
uint16 argMax32(int32 *list, uint16 length)
{
  if (length < 2)
  {
    return 0;
  }

  {
    /* Assuming 'length' is at least 2 */
    int32 max;
    uint16 j=length-1, maxidx = j;
    list += j--;
    max = *list--;

    do {
      int32 val = *list--;
      if (val > max) {
        max = val;
        maxidx = j;
      }
    } while (j--);
    return maxidx;
  }
}
#else
extern uint16 argMax32(int32 *list, uint16 length);
#endif

///* -----------------------------------------------------------------
//Name: argMax16
//Purpose: Compute argMax of a list of int16
//Inputs: list, list length
//Outputs: argMax
//Note: If numElements is 0, return 0.
//----------------------------------------------------------------- */
#if CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY == 1 || !(defined(__CHIMERA__) && __CHIMERA_VERSION__ > 30)
uint16 argMax16(int16 *input, uint16 numElements)
{
  uint16 i;
  int16 max = -32767;
  uint16 argMax = 0;
  for (i = 0; i < numElements; i++, input++)
  {
    int16 val = *input;
    if (val > max)
    {
      argMax = i;
      max = val;
    }
  }
  return argMax;
}

///* -----------------------------------------------------------------
//Name: argMaxAbs16
//Purpose: Compute argMax of the absolute values of a list of int16
//Inputs: list, list length
//Outputs: argMax
// Note: if all elements are 0, return 0.
//----------------------------------------------------------------- */
uint16 argMaxAbs16(int16 *input, uint16 numElements)
{
  uint16 i;
  int16 max = 0;
  uint16 argMax = 0;
  for (i = 0; i < numElements; i++, input++)
  {
    int16 val = IFP_ABS(*input);
    if (val > max)
    {
      argMax = i;
      max = val;
    }
  }
  return argMax;
}
#endif

#if !(defined(__CHIMERA__) && (!__T100X_HAS_FPU__))
// float scalarProductFloatFloat(float *veca, float *vecb, uint16 numElements)
// Name: scalarProductFloatFloat
// Purpose: Helper function that returns the scalar product of two vectors
// Inputs: veca - pointer to the vector a
//         vecb - pointer to the vector b
//         numElements - the number of elements in the vector
// Outputs: dotproduct - float containing the scalar product of vectors a and b
// Effects: None.
#if CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY == 1 || !defined(__CHIMERA__) || (__CHIMERA_VERSION__ < 30)
float scalarProductFloatFloat(float *veca, float *vecb, uint16 length)
{
  uint16 i;
  float sum = 0.f;
  for (i = 0; i < length; i++)
  {
    sum += *veca++ * *vecb++;
  }
  return sum;
}
#endif

#if !defined(__CHIMERA__) || (__CHIMERA_VERSION__ < 30) || ( CONFIG_INHIBIT_OPTIMIZED_ASSEMBLY == 1 && (CONFIG_INHIBIT_HYDRA == 1 || __T100X_HAS_HYDRA__ <= 2) )
void matTimesVec_floatFloat(uint16 rows, uint16 cols, float *mat, float *vec, float *result)
{
  uint16 r;
  float *matPtr = mat;
  float *resultPtr = result;
  for (r = 0; r < rows; r++)
  {
    *resultPtr++ = scalarProductFloatFloat(matPtr, vec, cols);
    matPtr += cols;
  }
}
#endif


// Convert a vector of floats to int16 using rounding.
#if !defined(__CHIMERA__)
#include <math.h>
// Visual Studio prior to 2013 didn't support a lot of C99, including
// math.h's roundf, but it did support floorf and ceilf.
static float ivu_roundf(float x)
{
   return x >= 0.0f ? floorf(x + 0.5f) : ceilf(x - 0.5f);
}
void convertFloatToInt16(int16 *i, float *f, uint16 len)
{
  uint16 ind;
  for (ind = 0; ind < len; ind++)
  {
    *i++ = (int16) ivu_roundf(*f++);
  }
}

void convertInt16ToFloat(float *f, int16 *i, uint16 len)
{
  uint16 ind;
  for (ind = 0; ind < len; ind++)
  {
    *f++ = (float) *i++;
  }
}
#endif
#endif  // !(defined(__CHIMERA__) && (!__T100X_HAS_FPU__))

#if !defined(__CHIMERA__) || (CONFIG_INHIBIT_HYDRA == 1 || __T100X_HAS_HYDRA__ <= 2)
/* -----------------------------------------------------------
Name: subtractFitDelta
Purpose: Subtract fit from original function.
Inputs: input array
        array length
        fit array
Outputs: None.
Effects: Modifies input array in-place.
Notes: None.
----------------------------------------------------------- */
void subtractFitDelta(int16 *row, uint16 rowLen, int16 *fit)
{
  // Finally subtract fit from row in-place.
  {
    uint16 i;
    int16 *rowPtr = row;
    int16 *fitPtr = fit;
    for (i = 0; i < rowLen; i++)
    {
      *rowPtr++ -= *fitPtr++;
    }
  }
}

/* -----------------------------------------------------------
Name: subtractFitRaw
Purpose: Subtract fit from original function.
Inputs: input array
        array length
        fit array
        whether to flip the polarity of the fit (for transcap raw)
Outputs: None.
Effects: Modifies input array in-place.
Notes: None.
----------------------------------------------------------- */
void subtractFitRaw(uint16 *row, uint16 rowLen, int16 *fit, uint16 flipSign)
{
  // Finally subtract fit from row in-place.
  if (flipSign)
  {
    uint16 i;
    uint16 *rowPtr = row;
    int16 *fitPtr = fit;
    for (i = 0; i < rowLen; i++)
    {
      *rowPtr++ += *fitPtr++;
    }
  }
  else
  {
    uint16 i;
    uint16 *rowPtr = row;
    int16 *fitPtr = fit;
    for (i = 0; i < rowLen; i++)
    {
      *rowPtr++ -= *fitPtr++;
    }
  }
}

/* -----------------------------------------------------------------
Name: projectDeltaImage
Purpose: Compute the projection of the delta image along rows and columns
Inputs: sensor params, delta image
Outputs: projection to TX axis, projection to RX axis
Notes:
----------------------------------------------------------------- */
void projectDeltaImage(uint16 rxCount, uint16 txCount , int16 *deltaImage, int32 *projTX, int32 *projRX)
{
  uint16 r, c;
  int16 *pSource;

  memset16(projTX, 0, MAX_TX * sizeof(*projTX) / sizeof(uint16));
  memset16(projRX, 0, MAX_RX * sizeof(*projRX) / sizeof(uint16));

  pSource = deltaImage + MAX_RX + 2;
  for (r = 0; r < txCount; r++)
  {
    *projTX++ = sum16(pSource, rxCount);
    pSource += MAX_RX + 1;
  }
  pSource = deltaImage + MAX_RX + 2;
  for (c = 0; c < rxCount; c++)
  {
    *projRX++ = sum16Stride(pSource++, txCount, MAX_RX + 1);
  }
}

/* -----------------------------------------------------------------
Name: subtractBaseline
Purpose: Compute the delta image
Inputs: sensor params, rawImage, baseline
Outputs: deltaImage
Notes:
----------------------------------------------------------------- */
void subtractBaseline(uint16 *rawImage, uint16 *baseline, int16 *deltaImage, uint16 rxCount, uint16 txCount)
{
    uint16 rowSkip = MAX_RX - rxCount;
    uint16 i = txCount;
    deltaImage += (MAX_RX + 1) + 1;  // account for border
    do
    {
      uint16 j = rxCount;
      do
      {
        if (CONFIG_IMAGE_DELTA_IS_POSITIVE) // compile-time test
        {
          *deltaImage++ = *rawImage++ - *baseline++;
        }
        else
        {
          *deltaImage++ = *baseline++ - *rawImage++;
        }
      } while(--j);

      baseline += rowSkip;
      rawImage += rowSkip;
      deltaImage += rowSkip + 1;
    } while(--i);
}

#endif

/*
Name: sortU16
Purpose: Sort the elements of an array of uint16.
Inputs: Pointer to start of memory, size of array
Outputs: None (the array is sorted in-place)
Notes: It uses insertion sort. It could easily be done generic like
       stdlib.h's qsort, by passing a comparison function.
*/
void sortU16(uint16 *input, uint16 numElements)
{
  uint16 i;

  for (i = 1; i < numElements; i++)
  {
    uint16 j;
    uint16 *inputCursor = input + i;
    for (j = i; j > 0; j--, inputCursor--)
    {
      if (inputCursor[-1] > inputCursor[0])
      {  // swap inputCursor[-1] and inputCursor[0]
        uint16 tmp = inputCursor[-1];
        inputCursor[-1] = inputCursor[0];
        inputCursor[0] = tmp;
      }
      else
      {
        break;
      }
    }
  }
}

///* -----------------------------------------------------------------
//Name: argMinMax32
//Purpose: Compute argMin and argMax list of int32
//Inputs: list, list length
//Outputs: argMin argMax
//----------------------------------------------------------------- */
void argMinMax32(int32 *list, uint16 length, uint16 *argmin, uint16 *argmax)
{
  if (length < 2)
  {
    *argmin = 0;
    *argmax = 0;
  }

  {
    /* Assuming 'length' is at least 2 */
    int32 min, max;
    uint16 j=length, minidx, maxidx;
    minidx = maxidx = --j;
    list += j--;
    min = max = *list--;
    do {
      int32 val = *list--;
      if (val < min) {
        min = val;
        minidx = j;
      }
      if (val > max) {
        max = val;
        maxidx = j;
      }
    } while (j--);
    *argmin = minidx;
    *argmax = maxidx;
  }
}

///* -----------------------------------------------------------------
//Name: alphaTrimmedMeanDestructive32
//Purpose: Compute the alpha-trimmed mean over a list of numbers
//Inputs: list, num to drop on each end, list length
//Outputs: the mean of surviving elements
//Effects: the list will have dropped elements overwritten with elements from the front of the list
//Notes: INT32_MIN in the input denotes an element to be skipped. If all elements
//       end up skipped, return 0.
//----------------------------------------------------------------- */
int32 alphaTrimmedMeanDestructive32(int32 *list, uint16 numDrop, uint16 length)
{
  // Can get cleverer later with partial sorting, but for now, iteratively overwrite
  // the max and min with values removed from the list.
  uint16 i, j;
  const int32 ATMD_IGNORE = -2147483647 - 1;
  int32 *listPtr = list;

  // This is just a hack to reduce the cpu cycles by 2/3. Best result is to drop
  // 1/3 of untouched pixels. The next best thing is to clip at numDrop = 8; However,
  //even this exceeds our cpu cycles.
  if (numDrop > 4)
  {
    numDrop = 4;
  }

// process elements that are marked for ignoring
  j = 0;
  for (i = 0; i < length; i++)
  {
    if (*listPtr == ATMD_IGNORE)
    {
      *listPtr = *list++; // truncate the list
      j++;
    }
    listPtr++;
  }
  // adjust length
  length -= j;

  // this would result in an empty list after dropping elements
  if (numDrop * 2 >= length)
  {
    return 0;
  }

  for (i = 0; i < numDrop; i++)
  {
    uint16 argmin, argmax;

    //argMinMax32(list, length, &argmin, &argmax);
    argmin = argMin32(list, length);
    argmax = argMax32(list, length);

    list[argmin] = list[0];
    list[argmax] = list[1];
    if (argmax == 0) list[argmin] = list[1];

    list += 2;
    length -= 2;
  }

  // Now take the mean of survivors
  {
    int32 sum = sum32(list, length);

    // Take care of signed division rounding.
    {
      int32 mean;
      uint16 isNegative = sum < 0;
      if (isNegative) sum = -sum;
      mean = (sum + (length / 2)) / length;
      if (isNegative) mean = -mean;
      return mean;
    }
  }
}

/* -----------------------------------------------------------------
Name: nthSortedEntry
Purpose: finds the nth element of a (partially) sorted vector
Inputs: vector, bounds, element number
Outputs: value of the nth element
Effects: None
----------------------------------------------------------------- */
int32 nthSortedEntry(int32 *x, int16 start, int16 end, int16 n, int16 length)
{
  {
    if (n < start || n > end || end >= length || start < 0)
    {
      return 0;
    }

    if (n == start)
    {
      uint16 argmin;
      argmin = argMin32(&x[start], end - start + 1);
      return x[start + argmin];
    }

    if (n == end)
    {
      uint16 argmax;
      argmax = argMax32(&x[start], end - start + 1);
      return x[start + argmax];
    }
  }

  {
    int16 lPtr = start;
    int16 rPtr = end;
    while (lPtr < rPtr)
    {
      int32 xPivot = x[n];
      int16 i = lPtr;
      int16 j = rPtr;

      int32 *xl = x + i;
      int32 *xr = x + j;
      while (n < j && i < n)
      {
        while(*xl < xPivot)
        {
          i++;
          xl++;
        }
        while(xPivot < *xr)
        {
          j--;
          xr--;
        }
        {
          int32 tmp = *xl;
          *xl = *xr;
          *xr = tmp;
        }

        i++;
        xl++;
        j--;
        xr--;
      }

      //setting up new start and end
      if (i < n)
      {
        lPtr = i;
      }
      if (n < j)
      {
        rPtr = j;
      }

      //skipping equal elemenets
      while(i <= end && *xl == xPivot)
      {
        i++;
        xl++;
      }
      while(j >= start && *xr == xPivot)
      {
        j--;
        xr--;
      }

      //exit condition
      if (i > n && j < n)
      {
        break;
      }
    }
    return x[n];
  }
}
