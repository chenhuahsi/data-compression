#ifndef _position_reporter_H_
#define _position_reporter_H_
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: position_reporter.h
   Description: Header for calling the position reporter module.

  $Id: position_reporter.h,v 1.5 2012/07/21 19:34:04 mposadas Exp $
----------------------------------------------------------------- */

#include "ifp_common.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

/* =================================================================
   MODULE TYPES
==================================================================*/

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* -----------------------------------------------------------
Name: posReporter_init()
Purpose: Initializes the position reporter
Inputs: none
Outputs: none
Effects: Resets internal state of coordinate converter, as at
         power-on.
Notes: This function must be called before using the position
       reporter module.
Example: none
----------------------------------------------------------- */
void posReporter_init(void);

/* -----------------------------------------------------------
Name: posReporter_reinit()
Purpose: Reinitializes the position reporter
Inputs: none
Outputs: none
Effects: Resets internal state of position reporter, as at a
         host rezero.
Notes: This function must be called if the host sends a rezero
       command.
Example: none
----------------------------------------------------------- */
void posReporter_reinit(void);

/* -----------------------------------------------------------
Name: posReporter_configure()
Purpose: Set host-defined parameters
Inputs: deadZoneSizeX, deadZoneSizeY: the half-width of the
          region the finger must leave in order for the freshReport
          flag to be set
        forceFreshReport: forces freshReport flag to be set on
          every frame.
        palmFilterMode: none, reject all touches, or
          reject new touches
        palmFilterAllowStylus: true or false, whether to allow
          a stylus to be reported while a palm is detected if the
          palm filter is enabled.
        maxReportedObjects: how many elements of the reported
          fingers structure to populate and set the freshReport
          flag based on.
        maxReportedObjectsAlt: alternate value that can be
          swapped into the role of maxReportedObjects at
          runtime via the useMaxReportedObjectsAlt flag to
          posReporter_makeReport.
        reportedObjectTypes: bitmask of 'touching
          finger', 'stylus', 'palm', 'unknown' as desired,
          specifies which objects to put in the reported fingers
          structure.
        skinModeFilterType: none, reject all touches, or
          reject new touches. (Skin Mode filter is meant to specify if
          the reporting of any object type should be suppressed in
          the presence of touching fingers)
        skinModeSuppressObjectTypes: Type of objects to suppress
          during skinMode.
Outputs: none
Effects: none
Notes:   none
Example: none
----------------------------------------------------------- */
void posReporter_configure(positionRepConfig_t* config);

/* -----------------------------------------------------------
Name: getOriginControlPositionRep()
Purpose: get OriginControl Value
Inputs: none
Outputs: the OriginControl Value
Effects: none
Notes: none
Example: none
----------------------------------------------------------- */
#if defined(CONFIG_IFP_ORIGIN) && CONFIG_IFP_ORIGIN
uint16 getOriginControlPositionRep(void);
#endif

void setPosReporterDynamicConfig(ifpMode_t *pMode);
#if CONFIG_IFP_CLOSEDCOVER
uint16 getClosedCoverStatus(void);
uint0p16 getClosedCoverThresholdPct(void);
#endif
/* -----------------------------------------------------------
Name: posReporter_makeReport()
Purpose: builds a position report structure
Inputs: hostPositions - positions in host units
        sensorPositions - positions in sensor units
        classifications - object classifications
        holdLiftedIndices - while true, indices of lifted
            fingers are not reused for new objects
        useMaxReportedObjectsAlt - while true, use maxReportedObjectsAlt
        instead of maxReportedObjects to limit how many reports to make
Outputs: report - the report data structure
Effects: none
Notes: none
Example: none
----------------------------------------------------------- */
void posReporter_makeReport(hostPosition_t *hostPositions,
                            sensorPosition_t *sensorPositions,
                            classification_t *classifications,
                            uint16 holdLiftedIndices,
                            uint16 useMaxReportedObjectsAlt,
                            reportData_t *report);

#endif /* matches #ifndef _position_reporter_H_ */
