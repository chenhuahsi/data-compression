/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

  Description: Common definitions for image processing functions.
----------------------------------------------------------------- */

#ifndef _IFP_COMMON_H_
#define _IFP_COMMON_H_

// ifp.h contains the externally visible part of this file.
#include "ifp.h"

// NOTE: BUILD_IFP_MODEL specifies building for model and model type
//       0:        Build for Onebase
//       1: Build as standalone
// This is used for setting thread annotations on Chimera assembly functions.
// When simulated on host, we simulate in thread 1 while in real firmware,
// IFP runs in thread 3. In C, we handle this via build flags.
// It is also used to initialize hydra in the simulator on host.
#ifndef BUILD_IFP_MODEL
  #define BUILD_IFP_MODEL 0
#endif

// Byte pointers ruined everything. Onebase, and therefore chimcc, now warn on
// sizeof since a naive usage is ambiguous. We disable the warning since we
// have checked that every instance of sizeof is used correctly.
#ifdef __CHIMERA__
  #ifndef DO_NOT_POISON_SIZEOF
    #define DO_NOT_POISON_SIZEOF
    #endif
  #ifndef DO_NOT_POISON_ALIGNED
    #define DO_NOT_POISON_ALIGNED
  #endif
#endif // __CHIMERA__

// add your compiler's preferred preprocessor symbol to this list if
// it's capable of generating arithmetic right shifts for signed
// operands.
#if defined(__GNUC__) || defined(_MSC_VER)
  #define SIGNED_RIGHT_SHIFT_IS_ARITHMETIC 1
#else
  #define SIGNED_RIGHT_SHIFT_IS_ARITHMETIC 0
#endif

#define IFP_MAX2(x,y) ((x) > (y) ? (x) : (y))
#define IFP_MIN2(x,y) ((x) < (y) ? (x) : (y))
#define IFP_ABS(x)    ((x) > (-(x)) ? (x) : (-(x)))

#ifndef TRUE
#  define TRUE 1
#endif

#ifndef FALSE
#  define FALSE 0
#endif

#ifndef NULL
#  define NULL 0
#endif

#ifndef ATTR_UNUSED
  #ifdef __CHIMERA__
    #define ATTR_UNUSED  __attribute__ ((unused))
  #else
    #define ATTR_UNUSED
  #endif
#endif // ATTR_UNUSED

#ifndef BUILD_IFP_MODEL
  #ifndef ATTR_INLINE
    #ifdef _MSC_VER  // use C-compatible _inline
      #define ATTR_INLINE  _inline
  #else
      #define ATTR_INLINE  inline
  #endif
  #endif
#else
  // conflicts with definition in syna_attr.h
  /*#undef ATTR_INLINE
  #ifdef _MSC_VER  // use C-compatible _inline
    #define ATTR_INLINE  _inline
  #else
    #define ATTR_INLINE  inline
  #endif*/
#endif

// We would like structs to have the same layout on t100x-gcc, gcc, and VC++.
// Force struct packing to be 16-bit everywhere. Note that t100x-gcc makes an
// exception for floats and longs (32-bit), where it will force 32-bit
// alignment in structs. As we can't express this exception with the pack
// pragma, we'd just have to handle ChimSim<->mex manually for float or long
// members. Except(!), we can specify -mhas-aligned-longs=0, so at least longs
// get pack-compatible layouts and only floats are the special case.
#ifndef __CHIMERA__
  #pragma pack(push)
  #pragma pack(2)
#endif

typedef enum
{
  polarity_positive = 0,
  polarity_negative = 1
} polarity_t;

typedef struct
{
   uint32 runningVarButton[MAX_BUTTONS];
   uint16 data[MAX_BUTTONS];
   uint16 baseline[MAX_BUTTONS];
   uint16 runningMeanButton[MAX_BUTTONS];
   uint16 gloveBaseline[MAX_BUTTONS];
   buttonsBitmask_t fingerReports; //individual button reports for diagnostics and debugging
   buttonsBitmask_t gloveReports;
   buttonsBitmask_t fingerTests; //individual button tests for diagnostics and debugging
   buttonsBitmask_t gloveTests;
} buttons0DDiagnostics_t;

typedef struct
{
  uint16 filterMoisture : 1;
  uint16 filterMoistureAMP : 1;
  uint16 forceFastRelax : 1;
  uint16 freezeBaseline : 1;
  uint16 hdnrError : 1;
} ifpActionFlags_t;

typedef enum
{
  relaxCommand_rezero,
  relaxCommand_fast,
  relaxCommand_thermal,
  relaxCommand_frozen
} relaxCommand_t;

typedef enum
{
  moistureAction_none,
  moistureAction_filter,
  moistureAction_filterAndFreeze,
  moistureAction_fastRelax,
} moistureAction_t;

typedef struct
{
  uint16 touchType : 10;  // touchType_t; in C, cannot portably use enums in bitfields
  uint16 touchFlag : 1;
  uint16 bufferTouchFlag : 1;
  uint16 recoverTouchFlag : 1;
  uint16 newTouchFlag : 1;
} classification_t;

typedef int16 deltaPixel_t;

typedef struct
{
  uint16 minAmplitude;
  uint16 peakCount;
  struct {
    uint16 offset;
    uint16 amplitude;
  } peakList[MAX_PEAKS];
} sortedPeakList_t;

#if MAX_OBJECTS > 16
  #error "You must redefine clumpInfo_t peakCount, splitCount, and firstSplit bitfield sizes to support more than 16 objects"
#endif

// If you change this enum, then you will have to change routines that
// clear the clumps structure and the tracker_init() function to use a
// non-zero default for polarity.
typedef enum
{
  clumpPolarity_positive = 0,
  clumpPolarity_negative = 1
} clumpPolarity_t;

// If you change this enum, make sure to change positionStateInfo_t in
// position_estimator.c.
typedef enum
{
  splitAxis_0,
  splitAxis_90,
  splitAxis_45,
  splitAxis_minus_45
} splitAxis_t;

typedef struct
{
  pixelIndex_t firstPixel;
  pixelIndex_t peakLocation;
  uint16 peakCount : 4;
  uint16 splitCount : 4;
  uint16 firstSplit : 4;
  uint16 splitAxis : 2;  // splitAxis_t; in C, cannot portably use enums in bitfields
  uint16 polarity : 1;
  uint16 preventSplit : 1;
  uint16 suspectMoisture : 1;
} clumpInfo_t ;

typedef struct
{
  clumpInfo_t info[MAX_OBJECTS];
  uint16 labelImage[(MAX_TX+2)*(MAX_RX+1)+1];
  pixelIndex_t listImage[(MAX_TX+2)*(MAX_RX+1)+1];
  uint8p8 splits[MAX_OBJECTS-1];
} clumps_t;

typedef struct
{
  uint16 clumpId : 8;
  uint16 blobId : 8;
  uint8p8 xCentroid;
  uint8p8 yCentroid;
  uint8p8 zerothMoment;
  int8p8 speedx;
  int8p8 speedy;
  uint16 pixelCount : 8;
  uint16 trackedFrames : 4;
  uint16 missingFrames : 3;
  uint16 polarity : 1;
} trackedObject_t;

typedef struct
{
  int8p8 xPosition;
  int8p8 yPosition;
  int8p8 xWidth;
  int8p8 yWidth;
  uint8p8 z;
} sensorPosition_t;

typedef struct
{
  int16 xPosition;
  int16 yPosition;
  uint16 xWidth : 8;
  uint16 yWidth : 8;
  uint16 z;
} hostPosition_t;

typedef struct
{
  uint16 classification;  // in C, cannot portably use enums in bitfields
  uint16 xWidth : 8;
  uint16 yWidth : 8;
  int8p8 txPos; //Not used by RMI
  int8p8 rxPos; //Not used by RMI
  uint16 z;
} bufferedReport_t;

typedef struct
{
    uint16 x[MAX_ABS_RX];
    uint16 y[MAX_ABS_TX];
    uint16 xLength : 8;
    uint16 yLength : 8;
} touchedElectrodes_t;

typedef struct
{
    uint16  skipCorrection: 1;
    uint16  usePrevLGMCorrFactor: 1;
    uint16  isPrevLGMObjStillPresent: 1;
    touchedElectrodes_t lgmCorrElectrodes;
} lgmManagerParams_t;

// Individual on/off of different filters in the touch buffer.
typedef struct
{
  uint16 removeGhostsRX : 1;
  uint16 removeGhostsShort : 1;
  uint16 removeGhostsAbsConsistency : 1;
  uint16 removeGhostsFast : 1;
  uint16 removeGhostsLowAmplitude : 1;
  uint16 fillInDroppedFingers : 1;
  uint16 filterPosition : 1;
} tbActions_t;

// Possible touch buffer filters acting, and how many times.
typedef struct
{
  uint16 removeGhostsRX;
  uint16 removeGhostsShort;
  uint16 removeGhostsAbsConsistency;
  uint16 removeGhostsFast;
  uint16 removeGhostsLowAmplitude;
  uint16 fillInDroppedFingers;
} tbFilteredCounts_t;

// Possible causes of a baseline error, and how many happened.
typedef struct
{
  uint16 classification;
  uint16 bumpiness;
  uint16 globalEnergyRatio;
  uint16 metalPlate;
  uint16 absPositivityRX;
  uint16 absPositivityTX;
} baselineErrorCounts_t;

typedef struct
{
  int16 sum;
  int16 max;
  pixelIndex_t argMax;
} tagsStats_t;

/**************************************************************************************
* START THICK GLOVE
**************************************************************************************/
#define ONE_8p8 256

typedef struct
{
  int32 value1;
  int32 value2;
  int32 value3;
  int32 value4;
  int32 value5;
} thickGloveDebug_t;

// thick glove modes
typedef enum
{
  thickGloveMode_disabled,
  thickGloveMode_sleep,
  thickGloveMode_prox,
  thickGloveMode_touch
} thickGloveMode_t;

// thick glove axis report
typedef struct
{
  float rsnr;
  uint16 present;
  int8p8 position;
  uint16 negFinger;
  uint16 unusedPadding;  // to keep everything aligned on even registers
} thickGloveAxisReport_t;

// thick glove hover report
typedef struct
{
  float rsnrTx;
  float rsnrRx;
  uint16 present;
  int8p8 posTx;
  int8p8 posRx;
  uint16 negFinger;
} thickGloveHoverReport_t;

// thick glove diagnostics report
typedef struct
{
  float delta[MAX_PROFILE_SIZE];
  float rsnr;
} thickGloveDiagnosticsReport_t;

// thick glove report
typedef struct
{
  thickGloveHoverReport_t hoverReport;
  thickGloveDiagnosticsReport_t diagnosticsTxReport;
  thickGloveDiagnosticsReport_t diagnosticsRxReport;
} thickGloveReport_t;

// thick glove frame filter
#define FRAME_FILTER_EMPTY 0x80000000L
typedef struct
{
  float iirState1[MAX_PROFILE_SIZE];
  float iirState2[MAX_PROFILE_SIZE];
  float frameFilter;
  float rsnr;
  uint16 profileLength;
  uint16 edgeExclusion;
} thickGloveFrameFilter_t;

typedef struct
{
  float frameFilter;
  uint16 edgeExclusion;
  uint16 unusedPadding;  // to keep everything aligned on even registers
} thickGloveFrameFilterConfig_t;

// thick glove detection
typedef struct
{
  float thresholdScale;
  float threshold;
} thickGloveDetection_t;

typedef struct
{
  float threshold;
} thickGloveDetectionConfig_t;

// thick glove position
typedef struct
{
  uint16 profileLength;
  uint16 unusedPadding;  // to keep everything aligned on even registers
} thickGlovePosition_t;

// thick glove hover
typedef struct
{
  thickGloveFrameFilter_t frameFilter;
  thickGloveDetection_t detection;
  thickGlovePosition_t position;
} thickGloveHover_t;

typedef struct
{
  thickGloveFrameFilterConfig_t frameFilterConfig;
  thickGloveDetectionConfig_t detectionConfig;
} thickGloveHoverConfig_t;

// thick glove position filter
#define MAX_POS_BUFFER_LENGTH 5
#define POSITION_FILTER_EMPTY 32767
typedef struct
{
  float posBufferTx[MAX_POS_BUFFER_LENGTH];
  float posBufferRx[MAX_POS_BUFFER_LENGTH];
  float posStateTx;
  float posStateRx;
  float settlingThreshold;
  float rsnrBuffer[MAX_POS_BUFFER_LENGTH];
  float rsnrState;
  int8p8 jitterThreshold;
  uint16 gloveState;
  uint16 riseTime;
  uint16 unusedPadding;  // to keep everything aligned on even registers
} thickGlovePositionFilter_t;

typedef struct
{
  float settlingThreshold;
  int8p8 jitterThreshold;
  uint16 unusedPadding;  // to keep everything aligned on even registers
} thickGlovePositionFilterConfig_t;

// thick glove frame processor
typedef struct
{
  thickGloveHover_t hoverTx;
  thickGloveHover_t hoverRx;
  thickGlovePositionFilter_t filter;
  uint16 profileLengthTx;
  uint16 profileLengthRx;
  uint16 mode;
  uint16 unusedPadding;  // to keep everything aligned on even registers
} thickGloveFrameProcessor_t;

typedef struct
{
  thickGloveHoverConfig_t hoverConfigTx;
  thickGloveHoverConfig_t hoverConfigRx;
  thickGlovePositionFilterConfig_t filterConfig;
} thickGloveFrameProcessorConfig_t;

// Prevent the pack pragma from infecting everything. VC++ warns about this.
#ifndef __CHIMERA__
  #pragma pack(pop)
#endif

#endif // _IFP_COMMON_H
