// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: baseline_manager.c
// Description: Decides what relaxation strategy to use for baseline maintenance
// $Id:$

/* =================================================================
   MODULE INCLUDES
==================================================================*/

#include "ifp_common.h"
#include "baseline_manager.h"
#include "ifp_bit_manipulation.h"

/* =================================================================
   MODULE MACROS
==================================================================*/

typedef enum
{
  state_start,
  state_rezero,
  state_fast,
  state_thermal,
  state_frozen,
  state_frozen_with_error
} state_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static uint16 baselineState;     // internal state for baseline state machine
static uint16 timer_ms;          // timer to be repurposed by each state:
                                 //  - fast: time left in fast
                                 //  - thermal: time w/ BL err
                                 //  - frozen: time w/ no fingers or BL err

// configuration knobs
static uint16 holdFastTransition_ms;  // let errors persist this long before fast relaxing
static uint16 fastRelaxDuration_ms;  // how long fast relaxation should run when invoked
static uint16 delayedRelaxationEnabled;

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: baselineManager_init()
Purpose: Initialize the module.
Inputs:
Outputs:
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void baselineManager_init(void)
{
  // Zero variables that config() does not assign values to
  baselineState = state_start;
  timer_ms = 0;
}

/* -----------------------------------------------------------------
Name: baselineManager_reinit()
Purpose: Re-initialize the Baseline Manager
Inputs:
Outputs:
Effects: None.
Notes: Resets baseline state to 'start'
Example: None.
----------------------------------------------------------------- */
void baselineManager_reinit(void)
{
  baselineState = state_start;
  timer_ms = 0;
}

/* -----------------------------------------------------------------
Name: baselineManager_configure()
Purpose: Configure the Baseline Manager module.
Inputs: holdFastTransition_ms  - delay before fast relaxing
        fastHalflife_ms        - half-life of fast (exponential) relaxation
Outputs: None
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void baselineManager_configure(sensorParams_t *sp, baselineManagerConfig_t *config)
{
  uint16 Nrelax = (sp->noiseFloor_LSB > 0) ? (numBits(sp->cSat_LSB / sp->noiseFloor_LSB) + 1) : numBits(sp->cSat_LSB);  /* numBits(x) == floor(log2(x)) */
  holdFastTransition_ms = config->holdFastTransition_ms;
  fastRelaxDuration_ms = Nrelax * config->fastHalflife_ms;
  delayedRelaxationEnabled = !config->disableDelayedRelaxation;
}

/* -----------------------------------------------------------------
Name: baselineManager_manage
Purpose: Choose baseline relaxation strategy.
Inputs: flags indicating that objects are present, errors are present,
        whether to override state machine and simply go into the fast state,
        whether relaxation is disabled or not, then the time since
        last frame
Outputs: relaxation command (relaxCommand_t enum)
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
uint16 baselineManager_manage(uint16 objectsPresent,
                              uint16 errorsPresent,
                              uint16 forceFastRelax,
                              uint16 relaxationDisabled,
                              uint16 frameTime_ms)
{
  relaxCommand_t relaxCommand;

  switch (baselineState)
  {
    case state_thermal:
      if (errorsPresent)
      {
        timer_ms += frameTime_ms;  // time with BL errors
        if (timer_ms >= holdFastTransition_ms)  // time with BL errors
        {
          baselineState = state_fast;
          timer_ms = 0;  // time in fast
        }
      }
      else
      {
        timer_ms = (timer_ms > frameTime_ms) ? (timer_ms - frameTime_ms) : 0;
      }
      if ((baselineState != state_fast) && objectsPresent)
      {
        baselineState = state_frozen;
      }
      break;
    case state_frozen:
      if (!objectsPresent)
      {
        baselineState = state_thermal;
        timer_ms = 0;
      }
      else if (errorsPresent)
      {
        timer_ms += frameTime_ms; // time w/ consecutive BL errors
        if (timer_ms >= holdFastTransition_ms)  // enough consecutive BL errors
        {
          if (delayedRelaxationEnabled)
          {
            baselineState = state_frozen_with_error;
          }
          else
          {
            baselineState = state_fast;
            timer_ms = 0;  // time in fast
          }
        }
      }
      else
      {
        timer_ms = (timer_ms > frameTime_ms) ? (timer_ms - frameTime_ms) : 0;
      }
      break;
    case state_frozen_with_error:
      // We've seen an error; as soon as finger lifts, relax.
      if (!objectsPresent)
      {
        timer_ms += frameTime_ms;
        if (timer_ms >= holdFastTransition_ms)
        {
        baselineState = state_fast;
        timer_ms = 0;  // time in fast
      }
      }
      else
      {
        timer_ms = (timer_ms > frameTime_ms) ? (timer_ms - frameTime_ms) : 0;
      }
      break;
    case state_fast:
      if (objectsPresent && !errorsPresent)
      {
        baselineState = state_frozen;
        timer_ms = 0;  // time w/ consecutive BL errors
      }
      else if (timer_ms >= fastRelaxDuration_ms)
      {
        baselineState = objectsPresent ? state_frozen : state_thermal;
        timer_ms = 0;  // time since update
      }
      else
      {
        timer_ms += frameTime_ms;  // time in fast
      }
      break;
    case state_rezero:
      baselineState = state_fast;
      timer_ms = 0;  // time in fast
      break;
    case state_start:
      baselineState = state_rezero;
      break;
  }

  /* force fast state */
  if (forceFastRelax)
  {
    baselineState = state_fast;
    timer_ms = 0;  // time in fast
  }

  /* emit relaxation commands */
  switch (baselineState)
  {
    case state_thermal:
      relaxCommand = relaxCommand_thermal;
      break;
    case state_frozen:
    case state_frozen_with_error:  // intentional fall-through
      relaxCommand = relaxCommand_frozen;
      break;
    case state_fast:
      relaxCommand = relaxCommand_fast;
      break;
    case state_rezero:
      relaxCommand = relaxCommand_rezero;
      break;
    default:  /* Should never, ever happen, so make it dramatic if it does. */
      relaxCommand = relaxCommand_fast;
      break;
  }

  /* disable relaxation by filtering commands */
  if (relaxationDisabled && (relaxCommand == relaxCommand_thermal || relaxCommand == relaxCommand_fast))
  {
    relaxCommand = relaxCommand_frozen;
  }

  return relaxCommand;
}
