// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
#ifndef _SHADOW_REMOVER_AMP_H
#define _SHADOW_REMOVER_AMP_H

#include "ifp_common.h"

#if CONFIG_HAS_SHADOW_REMOVER_AMP
void shadowRemoverAMP_configure(ampShadowRemoverConfig_t *config);
void shadowRemoverAMP_remove(int16* deltaImage,
                             sensorParams_t* sensorParams);
#else
static ATTR_INLINE void shadowRemoverAMP_configure(ATTR_UNUSED ampShadowRemoverConfig_t *config) {};
static ATTR_INLINE void shadowRemoverAMP_remove(ATTR_UNUSED int16* deltaImage,
                                                ATTR_UNUSED sensorParams_t* sensorParams) {};
#endif // CONFIG_HAS_SHADOW_REMOVER_AMP

#endif
