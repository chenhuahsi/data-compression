#ifndef _INSYSTEM_NOISE_MITIGATION_H_
#define _INSYSTEM_NOISE_MITIGATION_H_
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: hybrid nosie mitigation main module.
   $Id: filter_noise_blobs.h,v 1.1.4.3 2013/03/29 19:51:20 rfreeze Exp $
----------------------------------------------------------------- */

#include "ifp_common.h"

#if CONFIG_HAS_HYBRID_CHARGER_NOISE_MITIGATION
void hybridChargerNoiseMitigation_configure(hybridChargerNoiseMitigationConfig_t *config);
void hybridChargerNoiseMitigation_filter(sensorParams_t* pParams, int16* pDeltaImage, int16* pDeltaYProfile);
#else
static ATTR_INLINE void hybridChargerNoiseMitigation_configure(hybridChargerNoiseMitigationConfig_t *config ATTR_UNUSED) {};
static ATTR_INLINE void hybridChargerNoiseMitigation_filter(sensorParams_t* pParams ATTR_UNUSED,
                                                            int16* pDeltaImage ATTR_UNUSED,
                                                            int16* pDeltaYProfile ATTR_UNUSED) {};
#endif
#endif
