#ifndef _IFP_VECTOR_UTIL_H_
#define _IFP_VECTOR_UTIL_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: ifp_vector_util.h
// Description: Header file for ifp_vector_util.c
//
// $Id:$

#include "ifp_common.h"
#include "ifp_string.h"
#include "hydra_util.h"

// Assembly needs protection from C++ name mangling.
#ifdef __cplusplus
    extern "C" {
#endif

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

int32 scalarMultiplyAccumulate(int16 *input, int16 alpha, uint16 numElements);
int32 scalarProduct(int16 *veca, int16 *vecb, uint16 numElements);
int32 scalarProductMean(int16 *veca, int16 *vecb, uint16 numElements);
int32 sum16Stride(int16 *input, uint16 numElements, uint16 stride);
void applyCorrectionRow(uint8p8 *rxWeights, int16 *deltaRow, uint16 numElements, int24p8 txAmp);
int16 findMax(int16 *inputVector, uint16 vectorLength);
int16 findMin(int16 *inputVector, uint16 vectorLength);
int32 var16Stride(int16 *input, uint16 numElements, uint16 stride, int16 mean);
int16 calculateMean(int16 *input, uint16 numElements);
int32 sum32(int32 *input, uint16 numElements);
uint16 argMax32(int32 *list, uint16 length);
uint16 argMin32(int32 *list, uint16 length);
uint16 argMax16(int16 *input, uint16 numElements);
uint16 argMaxAbs16(int16 *input, uint16 numElements);
int32 sum16(int16 *input, uint16 numElements);  // implemented in C using scalarMultiplyAccumulate

#if defined(__CHIMERA__) && (!__T100X_HAS_FPU__)
static ATTR_INLINE float scalarProductFloatFloat(ATTR_UNUSED float *veca, ATTR_UNUSED float *vecb, ATTR_UNUSED uint16 length) { return 0.f; }
static ATTR_INLINE void matTimesVec_floatFloat(ATTR_UNUSED uint16 rows, ATTR_UNUSED uint16 cols, ATTR_UNUSED float *mat, ATTR_UNUSED float *vec, ATTR_UNUSED float *result) {}
static ATTR_INLINE void convertFloatToInt16(ATTR_UNUSED int16 *i, ATTR_UNUSED float *f, ATTR_UNUSED uint16 len) {}
static ATTR_INLINE void convertInt16ToFloat(ATTR_UNUSED float *f, ATTR_UNUSED int16 *i, ATTR_UNUSED uint16 len) {}
#else
float scalarProductFloatFloat(float *veca, float *vecb, uint16 length);
void matTimesVec_floatFloat(uint16 rows, uint16 cols, float *mat, float *vec, float *result);
void convertFloatToInt16(int16 *i, float *f, uint16 len);
void convertInt16ToFloat(float *f, int16 *i, uint16 len);
#endif

#ifdef __cplusplus
    }
#endif

void sortU16(uint16 *input, uint16 numElements);
void argMinMax32(int32 *list, uint16 length, uint16 *argmin, uint16 *argmax);
int32 alphaTrimmedMeanDestructive32(int32 *list, uint16 numDrop, uint16 length);
int32 nthSortedEntry(int32 *x, int16 start, int16 end, int16 n, int16 length);
void projectDeltaImage(uint16 rxCount, uint16 txCount, int16 *deltaImage, int32 *projTX, int32 *projRX);
void subtractBaseline(uint16 *rawImage, uint16 *baseline, int16 *deltaImage, uint16 rxCount, uint16 txCount);

static ATTR_INLINE void memset16_large(void *dst, int16 value, uint16 size)
{
#if defined(__CHIMERA__) && (__T100X_HAS_HYDRA__ > 2 && CONFIG_INHIBIT_HYDRA == 0)
   hydra_memset16(dst, value, size);
#else
   memset16(dst, value, size);
#endif
};

void ifp_vector_util_configure(void); //enables hydra if available, always necessary
void ifp_vector_util_init(void);      //enables hydra if available, not necessary if rezero does not switch off hydra
void ifp_vector_util_reinit(void);    //enables hydra if available, not necessary if rezero does not switch off hydra

#endif  //_IFP_VECTOR_UTIL_H_
