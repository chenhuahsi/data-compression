// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: row_column_noise_remover.c
// Description: Removes the mean pixel vlaue from the column and the half rows
//

#include "ifp_common.h"

#if CONFIG_HAS_ROW_COL_NOISE_REMOVER

#define COLUMN_CMN_MEAN_THRESHOLD rcnrcfg.columnMeanThreshold
#define COLUMN_CMN_APPL_THRESHOLD rcnrcfg.columnApplyThreshold
#define ROW_CMN_MEAN_THRESHOLD_L  rcnrcfg.leftRowsMeanThreshold
#define ROW_CMN_APPL_THRESHOLD_L  rcnrcfg.leftRowsApplyThreshold
#define ROW_CMN_MEAN_THRESHOLD_R  rcnrcfg.rightRowsMeanThreshold
#define ROW_CMN_APPL_THRESHOLD_R  rcnrcfg.rightRowsApplyThreshold

// IFP must have some utility file somewhere...
// can't seem to find it
#define abs16(x) (((x) < 0) ? -(x) : (x))

static sensorParams_t scfg;
static rowColumnNoiseRemoverConfig_t rcnrcfg;

#ifdef __CHIMERA__
uint16 sumWithinThreshold(int16 *input, uint16 len, int16 threshold, int32 *sum);
uint16 sumColumnWithinThreshold(int16 *input, uint16 len, int16 threshold, int32 *sum, uint16 stride);
#else
static ATTR_INLINE int16 sumWithinThreshold(int16 *input, uint16 len, int16 threshold, int32 *sum)
{
  int16 delta;
  int32 acc32=0;
  uint16 count=0;

  do{
    delta = *input++;
    if(abs16(delta) <= threshold)
    {
      acc32 += delta;
      count++;
    }
  }while(--len > 0);

  *sum = acc32;
  return count;
}

static ATTR_INLINE int16 sumColumnWithinThreshold(int16 *input, uint16 len, int16 threshold, int32 *sum, uint16 stride)
{
  int16 delta;
  int32 acc32=0;
  uint16 count=0;

  do{
    delta = *input;
    input += stride;
    if(abs16(delta) <= threshold)
    {
      acc32 += delta;
      count++;
    }
  }while(--len > 0);

  *sum = acc32;
  return count;
}
#endif //__CHIMERA__

// helper function to get the delta image value
// because IFP has padding
int16* getValueFromDeltaImage(int16 *deltaImage, uint16 row, uint16 col)
{
  return (deltaImage + (MAX_RX + 1) * col + (MAX_RX + 1) + 1 + row);
}

void rowColumnNoiseRemover_configure(sensorParams_t *sensorParams, rowColumnNoiseRemoverConfig_t *rcNoiseRemoverConfig)
{
  scfg    = *sensorParams;
  rcnrcfg = *rcNoiseRemoverConfig;
}

void rowColumnNoiseRemover_removeColumnNoise(int16 *deltaImage)
{
  uint16 r, c, count;
  int16 delta;
  int16 sum[MAX_TX];
  int32 acc32;
  int16 *pPixel = deltaImage + (MAX_RX+1) + 1;
  int16 *pSum = &sum[0];
  uint16 stride = (MAX_RX+1) - scfg.rxCount;

  if (COLUMN_CMN_MEAN_THRESHOLD == 0)
    return;

  // basic algorithm:
  // find the average of all the RXes across the entire panel
  // assuming the values are below some threshold
  for (r = 0; r < scfg.txCount; r++)
  {
    count = 0;
    acc32 = 0;

    count = sumWithinThreshold(pPixel, scfg.rxCount, COLUMN_CMN_MEAN_THRESHOLD, &acc32);
    pPixel+=(MAX_RX+1);//deltaimage column width is MAX_RX+1

    // in the event count == 0, just set the average to zero
    if(count)
    {
      acc32 = acc32 / count;
    }

    *pSum++ = (int16)acc32;
  }

  pPixel = deltaImage + (MAX_RX+1) + 1;
  pSum = &sum[0];

  for (r = 0; r < scfg.txCount; r++)
  {
    c = scfg.rxCount;
    do{
      delta = *pPixel;

      if (delta <= COLUMN_CMN_APPL_THRESHOLD)
      {
        delta -= *pSum;
        *pPixel = delta;
      }
      pPixel++;
    }while(--c > 0);
    pPixel+= stride; //deltaimage column width is MAX_RX+1
    pSum++;
  }
}

void rowColumnNoiseRemover_removeRowNoise(int16 *deltaImage)
{
  uint16 i, j, count;
  int16 delta;
  int32 acc32;
  int32 sum_left[MAX_RX], sum_right[MAX_RX];
  int32 *pSum;
  int16 *pPixel = deltaImage + (MAX_RX+1) + 1;

  if ((ROW_CMN_MEAN_THRESHOLD_L == 0) && (ROW_CMN_MEAN_THRESHOLD_R == 0))
    return;

  pSum = &sum_left[0];
  for(i = 0; i < scfg.rxCount; i++)
  {
    count = 0;
    acc32 = 0;
    count = sumColumnWithinThreshold(pPixel, scfg.txCount/2, ROW_CMN_MEAN_THRESHOLD_L, &acc32, MAX_RX+1);
    pPixel++;

    if (count)
    {
      acc32 = acc32/count;
    }
    *pSum++ = acc32;
  }

  pPixel = deltaImage + (MAX_RX+1)*(scfg.txCount/2+1) + 1;
  pSum = &sum_right[0];
  for(i = 0; i < scfg.rxCount; i++)
  {
    count = 0;
    acc32 = 0;
    count = sumColumnWithinThreshold(pPixel, scfg.txCount/2, ROW_CMN_MEAN_THRESHOLD_R, &acc32, MAX_RX+1);
    pPixel++;

    if (count)
    {
      acc32 = acc32/count;
    }
    *pSum++ = acc32;
  }

  pSum = &sum_left[0];
  pPixel = deltaImage + (MAX_RX+1) + 1;
  for(i = 0; i < scfg.rxCount; i++)
  {
    j = scfg.txCount/2;
    do{
      delta = *pPixel;
      if (delta <= ROW_CMN_APPL_THRESHOLD_L)
      {
        delta -= *pSum;
        *pPixel = delta;
      }
      pPixel += (MAX_RX+1);
    }while(--j > 0);

    pSum++;
    pPixel -= ((MAX_RX+1)*(scfg.txCount/2)-1);
  }

  pSum = &sum_right[0];
  pPixel = deltaImage + (MAX_RX+1)*(scfg.txCount/2+1) + 1;
  for(i = 0; i < scfg.rxCount; i++)
  {
    j = scfg.txCount/2;
    do{
      delta = *pPixel;
      if (delta <= ROW_CMN_APPL_THRESHOLD_R)
      {
        delta -= *pSum;
        *pPixel = delta;
      }
      pPixel += (MAX_RX+1);
    }while(--j > 0);

    pSum++;
    pPixel -= ((MAX_RX+1)*(scfg.txCount/2)-1);
  }
}

#endif // CONFIG_HAS_ROW_COL_NOISE_REMOVER
