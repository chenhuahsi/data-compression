#ifndef _CDM_DECODER_H
#define _CDM_DECODER_H

/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Description: CDM decoder utility functions header
   $Id$
----------------------------------------------------------------- */

#include "ifp_common.h"

/* -----------------------------------------------------------
Name: decodeCDM16
Purpose: Restores image that has CDM16 applied to it
Inputs: image - the image
        numEnabledTX - the number of enabled transmitters
        numEnabledRX - the number of enabled receivers
Outputs: modified image
Effects: None.
Notes: None.
----------------------------------------------------------- */
void decodeCDM16(uint16 *image, uint16 numEnabledTX, uint16 numEnabledRX);

/* -----------------------------------------------------------
Name: decodeCDM10
Purpose: Restores image that has CDM10 applied to it
Inputs: image - the image
        numEnabledTX - the number of enabled transmitters
        numEnabledRX - the number of enabled receivers
Outputs: modified image
Effects: None.
Notes: None.
----------------------------------------------------------- */
void decodeCDM10(uint16 *image, uint16 numEnabledTX, uint16 numEnabledRX);

/* -----------------------------------------------------------
Name: decodeCDM4
Purpose: Restores image that has CDM4 applied to it
Inputs: image - the image
        numEnabledTX - the number of enabled transmitters
        numEnabledRX - the number of enabled receivers
Outputs: modified image
Effects: None.
Notes: None.
----------------------------------------------------------- */
void decodeCDM4(uint16 *image, uint16 numEnabledTX, uint16 numEnabledRX);

#endif //_CDM_DECODER_H
