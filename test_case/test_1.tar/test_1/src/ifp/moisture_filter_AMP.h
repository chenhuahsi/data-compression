#ifndef _MOISTURE_FILTER_AMP_H_
#define _MOISTURE_FILTER_AMP_H_
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: moisture_filter_AMP.h
   Description: Header for moisture_filter_AMP block external API
----------------------------------------------------------------- */
#if CONFIG_HAS_TDDI_AMP_MOISTURE
void moistureFilterAMP_init();
void moistureFilterAMP_reinit();
void moistureFilterAMP_configure(ampMoistureConfig_t *config);
uint16 moistureFilterAMP_detect(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps);
void moistureFilterAMP_filter(clumps_t *clumps);
void moistureFilterAMP_processClassifications(trackedObject_t *trackedObjects, classification_t *classifications);
#else
static ATTR_INLINE void moistureFilterAMP_init() {};
static ATTR_INLINE void moistureFilterAMP_reinit() {};
static ATTR_INLINE void moistureFilterAMP_configure(ATTR_UNUSED ampMoistureConfig_t *config) {};
static ATTR_INLINE uint16 moistureFilterAMP_detect(ATTR_UNUSED sensorParams_t *sensorParams,
                                                   ATTR_UNUSED int16 *deltaImage,
                                                   ATTR_UNUSED clumps_t *clumps) { return 0; };
static ATTR_INLINE void moistureFilterAMP_filter(ATTR_UNUSED clumps_t *clumps) {};
static ATTR_INLINE void moistureFilterAMP_processClassifications(ATTR_UNUSED trackedObject_t *trackedObjects,
                                                                 ATTR_UNUSED classification_t *classifications) {};
#endif

#endif  //_MOISTURE_FILTER_AMP_H_
