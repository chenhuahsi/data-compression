/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: position_reporter.c
   Description: Packs positions into reported data structure.
                Also implements palm filtering, reduced reporting mode.

 $Id: position_reporter.c,v 1.4.8.2 2012/08/29 18:34:07 jjordan Exp $
----------------------------------------------------------------- */

#include "ifp_common.h"
#include "edge_swipe_detector.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

/* =================================================================
   MODULE TYPES
==================================================================*/

/* =================================================================
   MODULE VARIABLES
==================================================================*/

static reportData_t bufferedReports[2];

static int16 edgeMinX;
static int16 edgeMinY;
static int16 edgeMaxX;
static int16 edgeMaxY;

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

// - external functions

/* -----------------------------------------------------------
Name: edgeSwipeDetector_init()
Purpose: Initializes the edge swipe detector
Inputs: none
Outputs: none
Effects: Resets internal state, as at power-on.
Notes: This function must be called before using the position
       reporter module.
Example: none
----------------------------------------------------------- */
void edgeSwipeDetector_init(void)
{
  // -- inline memset --
  uint16 i;
  uint16 *ptr = (uint16 *) bufferedReports;
  for (i = 0; i < sizeof(bufferedReports)/sizeof(uint16); i++)
  {
    *ptr++ = 0;
  }
}

/* -----------------------------------------------------------
Name: edgeSwipeDetector_reinit()
Purpose: Reinitializes the edge swipe detector
Inputs: none
Outputs: none
Effects: Resets internal state, as at a
         host rezero.
Notes: This function must be called if the host sends a rezero
       command.
Example: none
----------------------------------------------------------- */
void edgeSwipeDetector_reinit(void)
{
  edgeSwipeDetector_init();
}

/* -----------------------------------------------------------
Name: edgeSwipeDetector_configure()
Purpose: Set host-defined parameters
Inputs: edgeMinX, edgeMinY, edgeMaxX, edgeMaxY: the edges of the touch
          region for the purposes of edge swipe entry
Outputs: none
Effects: none
Notes:   none
Example: none
----------------------------------------------------------- */
void edgeSwipeDetector_configure(edgeSwipeDetectorConfig_t* config)
{
  edgeMinX = config->edgeMinX;
  edgeMinY = config->edgeMinY;
  edgeMaxX = config->edgeMaxX;
  edgeMaxY = config->edgeMaxY;
}

/* -----------------------------------------------------------
Name: edgeSwipeDetector_detectEdgeSwipe()
Purpose: adds touches at edge of screen for swipes
Inputs: inReport - the report data structure
Outputs: outReport - the report data structure, possibly with added touches
           to ensure swipes begin at edge
Effects: The internal deque of the edge swipe detector is rotated
Notes:   none
Example: none
----------------------------------------------------------- */
void edgeSwipeDetector_detectEdgeSwipe(reportData_t *reportIn,
        reportData_t *reportOut)
{
  uint16 i;

  // Move reports through the buffer

  *reportOut = bufferedReports[0];
  bufferedReports[0] = bufferedReports[1];
  bufferedReports[1] = *reportIn;

  // For each touch

  for (i = 0; i != MAX_OBJECTS; ++i)
  {

    // Are we about to return the report before a new touch that
    // persists for at least two frames?

    if (!reportOut->pos[i].z && bufferedReports[0].pos[i].z && bufferedReports[1].pos[i].z)
    {
      int16 oldX, oldY;
      int16 flag;

      // Assume the finger is moving linearly.  Compute the previous
      // location of the touch.

      oldX = bufferedReports[0].pos[i].xMeas * 2 - bufferedReports[1].pos[i].xMeas;
      oldY = bufferedReports[0].pos[i].yMeas * 2 - bufferedReports[1].pos[i].yMeas;

      // Check if the projected location was outside the sensor.  If it
      // was, clip it to the edge and flag that we need to insert the edge
      // touch into the report we are about to return

      flag = 0;
      if (oldX < edgeMinX)
      {
        oldX = edgeMinX;
        flag = 1;
      }
      if (oldY < edgeMinY)
      {
        oldY = edgeMinY;
        flag = 1;
      }
      if (oldX > edgeMaxX)
      {
        oldX = edgeMaxX;
        flag = 1;
      }
      if (oldY > edgeMaxY)
      {
        oldY = edgeMaxY;
        flag = 1;
      }

      // Insert the edge touch into the report

      if (flag)
      {
        // Copy over all the touch properties
        reportOut->pos[i] = bufferedReports[0].pos[i];
        reportOut->freshData = bufferedReports[0].freshData;
        reportOut->objectsPresent = bufferedReports[0].objectsPresent;

        // Use the clipped back-projected location
        reportOut->pos[i].xMeas = oldX; // oldX;
        reportOut->pos[i].yMeas = oldY; // oldY;
      }

    }
  }
}
