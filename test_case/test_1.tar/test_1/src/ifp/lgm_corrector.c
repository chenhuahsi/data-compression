//==============================================================================
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2014  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 Mckay Drive
// San Jose, CA 95131
// (408) 904-1100
//
//
// -----------------------------------------------------------------


#include "ifp_common.h"

#if CONFIG_HAS_LGM_CORRECTOR

#include "ifp_string.h"
#include "lgm_corrector.h"
#include "ifp_bit_manipulation.h"

/* =================================================================
   MODULE MACROS
==================================================================*/

#define abs(x)      (((x) >= 0) ? (x) : -(x))
#define max(a,b)    ((a) > (b) ?  (a) : (b))
#define min(a,b)    ((a) > (b) ?  (b) : (a))

#define TRANS_SHIFT  24
#define MAX_ALLOWED_CORRECTION 32768   // To prevent overflow, 2^15-1
#define Z2O_IDX(idx) (1+(idx))
#define O2Z_IDX(idx) ((idx)-1)

#define TOUCH_METRIC_SIZE (2*(MAX_ABS_TX)*(MAX_ABS_RX))
/* =================================================================
   MODULE VARIABLES
==================================================================*/
static uint32 corrFactor;
static uint32 prevCorrFactor;

/* =================================================================
   Global VARIABLES
==================================================================*/
static uint16 bIsOverFlow;

/* =================================================================
   MODULE  INTERNAL FUNCTION DEFINITIONS
==================================================================*/
static uint16 calculateTouchMetricInfo(lgmManagerParams_t *lgmManagerParams, int16 *pDeltaImage, int16 *pdeltaXProfile, int16 *pdeltaYProfile, uint16 *pTouchMetricInfo, uint32 binWidth, uint16 *maxBinNumber);
static void getHistogramIndexInfo(uint16 nAvailableBins, uint16 maxBinNumber, uint16 *firstHistBin, uint16 *idxLastBin);
static uint32 findMaxOfProfileImage(int16 *pdeltaXProfile, int16 *pdeltaYProfile, lgmManagerParams_t *lgmManagerParams);
static void createHistogram(uint16 *touchMetricInfo, uint16 nArrayElements, uint16 nHistElements, uint16 maxBinNumber);
static uint32 getMedianCorrectionFactor(uint16 *pHist, uint16 nNonZeroBins, uint16 idxLastBin, uint16 firstHistBin, uint32 binWidth);
static void correctDeltaImage(int16 *pDeltaImage, int16 *pdeltaXProfile, int16 *pdeltaYProfile, lgmManagerParams_t *lgmManagerParams, sensorParams_t *pSensorParams, uint16 *pIndicesOfCorrectedPixels);
static uint32 mul32By32(uint32 input1, uint32 input2, uint16 *exp);

/* -----------------------------------------------------------------
Name:    mul32By32( )
Purpose: compute 32bx32b multiplication. Makes sure the result does not overflow.
Inputs:  input1 and input2 are source uint32s. input3 is the destination pointer
         for the exponent portion of the result.
Outputs: The mantissa portion of the end result which fits into 32 bits
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
static uint32 mul32By32(uint32 input1, uint32 input2, uint16 *exp)
{
  uint16 input1Hi16;
  uint16 input2Hi16;
  uint16 input1exp = 0;
  uint16 input2exp = 0;

  input1Hi16 = (uint16)(input1 >> 16);
  input2Hi16 = (uint16)(input2 >> 16);

  if (input1Hi16 != 0)
    input1exp = numBits(input1Hi16) + 1;
  if (input2Hi16 != 0)
    input2exp = numBits(input2Hi16) + 1;

  *exp = input1exp + input2exp;

  return ((uint32)(input1 >> input1exp))*((uint16)(input2 >> input2exp));
}
/* -----------------------------------------------------------------
Name:    calculateTouchMetricInfo()
Purpose: Calculates - the (touch metrics) for negative pixels that fall
         on electrodes that are included for correction
Inputs:  1 - lgmManagerParams
         2 - pDeltaImage:        trans delta image
         3,4 - pdeltaX/YProfile: absolute delta profiles
         5 - pTouchMetricInfo:   pointer to touchMetricInfo array (for
             understanding the structure of this array, please refer to
             the description in lgmcorrector_correct)
         6 - bin width
         7 - pointer to maxBinNumber
Outputs: Total number of elements in the histogram
Effects: None.
Notes:  The values calculated are actually the negative of the touch
        metrics
Example: None.
----------------------------------------------------------------- */
static uint16 calculateTouchMetricInfo(
                                       lgmManagerParams_t *lgmManagerParams,
                                       int16 *pDeltaImage,
                                       int16 *pdeltaXProfile,
                                       int16 *pdeltaYProfile,
                                       uint16 *pTouchMetricInfo,
                                       uint32 binWidth,
                                       uint16 *maxBinNumber )
{
  uint16 nElements;
  uint16 *pDest;
  uint16 *pXElectrodes;
  uint16 *pYElectrodes;
  uint16 idx;
  uint16 yLen = 0;
  uint16 xLen;
  uint16 posDelta;
  uint32 TouchMetric;
  uint32 binNumber;

  // If there is not enough precision for calculating the bins, just return 0 so that no correction will be done
  if (binWidth == 0)
    return 0;

  nElements = 0;
  pDest = pTouchMetricInfo;
  *maxBinNumber = 0;
  pYElectrodes = &(lgmManagerParams->lgmCorrElectrodes.y[0]);
  while (yLen < lgmManagerParams->lgmCorrElectrodes.yLength)
  {
    uint16 idx_start = (MAX_RX + 1)*(*pYElectrodes);
    int16 deltaY = pdeltaYProfile[ O2Z_IDX(*pYElectrodes) ];
    pXElectrodes = &(lgmManagerParams->lgmCorrElectrodes.x[0]);
    xLen = 0;
    while (xLen < lgmManagerParams->lgmCorrElectrodes.xLength)
    {
      idx = idx_start + (*pXElectrodes);
      if (pDeltaImage[idx] < 0)
      {
        //Make sure that profImageVal fits in 13 bits
        uint32 profImageVal = (uint32)pdeltaXProfile[ O2Z_IDX(*pXElectrodes) ] * (uint16)deltaY;
        // TouchMetric numerator runs the risk of over flow because theoretically
        // -pDeltaImage can be 12 bits. In this case where TRANS_SHIFT = 24, -pDeltaImage should fit in 8 bits
        // However in reality, these are negative pixels caused by LGM and won't be so large
        // If a risk is ever seen, a check can be put in.
        // If the result does not fit in 8 bits then no correction should be done or
        // another solution is that TRANS_SHIFT can be reduced based on the maximum profileImage
        // values that can be expected. For example if under Good Ground, a covered receiver
        // has a response of delta_R and a covered transmitter has a response of delta_T, then
        // ceil(log2(delta_R*delta_T))<TRANS_SHIFT <29, and the smallest bound can be used. In
        // which case -pDeltaImage[idx] should fit in 32-ceil(log2(delta_R*delta_T)). This can
        // be done via calibration.
        // Another solution is one that Alex Zenkin put in below (the if statement), which is to right-shift the profImageVal.
        posDelta = -pDeltaImage[idx];

        // give  delta  a chance to be  up to 4095; keep reducing shifts if larger needed (slight accuracy degradation)
        // (2^(32 - TRANS_SHIFT) - 1) = 255
        if(posDelta <= 255)
          TouchMetric  = ((uint32)(posDelta) << TRANS_SHIFT) / profImageVal;
        else if(posDelta <= 511 && profImageVal >= 2)
          TouchMetric  = ((uint32)(posDelta) << (TRANS_SHIFT-1) ) / (profImageVal/2);
        else if(posDelta <= 1023 && profImageVal >= 4)
          TouchMetric  = ((uint32)(posDelta) << (TRANS_SHIFT-2) ) / (profImageVal/4);
        else if(posDelta <= 2047 && profImageVal >= 8)
          TouchMetric  = ((uint32)(posDelta) << (TRANS_SHIFT-3) ) / (profImageVal/8);
        else if(posDelta <= 4095 && profImageVal >= 16)
          TouchMetric  = ((uint32)(posDelta) << (TRANS_SHIFT-4) ) / (profImageVal/16);
        else
        {
          bIsOverFlow = 1;
          return 0;
        }

        binNumber = TouchMetric / binWidth;
        if (binNumber > 65535)
        {
          bIsOverFlow = 1;
          return 0;
        }

        *pDest = (uint16)(binNumber); // bin number of the touch metric for pixel idx

        nElements ++;
        *maxBinNumber = (*pDest > *maxBinNumber) ? *pDest : *maxBinNumber;
        pDest ++;
      }
      pXElectrodes ++;
      xLen ++;
    }
    pYElectrodes ++;
    yLen ++;
  }
  return nElements;
}

/* -----------------------------------------------------------------
Name:    createHistogram()
Purpose: Creates the histogram of the touchMetrics that were calculated
         in calculateTouchMetricInfo. For more info look at the description
         for pTouchMetricInfo in lgmCorrector_correct
Inputs:  1 - pointer to touchmetric info
         2 - size of touchmetricInfo array (nArrayElements)
         3 - total number of elements in the histogram (nHistElements)
         4 - maximum bin number
Outputs: None
Effects: None
Notes:   None
Example: None.
----------------------------------------------------------------- */
static void createHistogram(uint16 *touchMetricInfo, uint16 nArrayElements, uint16 nHistElements, uint16 maxBinNumber)
{
  uint16 *pHist;
  uint16 nAvailableBins;
  uint16 *pBinNumber;

  if (nHistElements == 0)
    return;

  pHist = &touchMetricInfo[nHistElements];
  pBinNumber = touchMetricInfo;
  nAvailableBins = nArrayElements - nHistElements;
  memset16(pHist, 0, min(nAvailableBins, maxBinNumber));

  if (maxBinNumber < nAvailableBins)
  {
    while (pBinNumber < (touchMetricInfo + nHistElements))
      pHist[*pBinNumber++]++;
  }
  else
  {
    uint16 offset = maxBinNumber - (nAvailableBins - 1);
    while (pBinNumber < (touchMetricInfo + nHistElements))
    {
      if (*pBinNumber >= offset)
        pHist[*pBinNumber - offset]++;
      pBinNumber++;
    }
  }
}

/* -----------------------------------------------------------------
Name:    findMaxOfProfileImage()
Purpose: Calculates - the maximum value of the profile image created
         by the outer product of electrodes highlighted in the lgm
         corrector mask provided by the LGM manager
Inputs:  1,2 - delta profiles
         3 - lgmManagerParams
Outputs: Maximum value of the profile image
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
 static uint32 findMaxOfProfileImage(int16 *pdeltaXProfile, int16 *pdeltaYProfile, lgmManagerParams_t *lgmManagerParams)
 {
   uint16 *pYElectrodes = lgmManagerParams->lgmCorrElectrodes.y;
   uint16 *pXElectrodes;
   uint32 currentVal = 0;
   uint32 maxVal = 0;
   uint16 jLen = 0;
   uint16 iLen;

   while (jLen < lgmManagerParams->lgmCorrElectrodes.yLength)
   {
     int16 deltaY = pdeltaYProfile[ O2Z_IDX(*pYElectrodes) ];
     pXElectrodes = lgmManagerParams->lgmCorrElectrodes.x;
     iLen = 0;
     while(iLen < lgmManagerParams->lgmCorrElectrodes.xLength)
     {
       currentVal = (uint32)pdeltaXProfile[ O2Z_IDX(*pXElectrodes) ] * (uint16)deltaY;
       maxVal     =  (currentVal > maxVal) ? currentVal : maxVal;
       pXElectrodes++;
       iLen++;
     }
     pYElectrodes++;
     jLen++;
   }
   return maxVal;
 }
 /* -----------------------------------------------------------------
Name:    getHistogramIndexInfo()
Purpose: If enough RAM is available, the histogram for all bins will
         be created. If not, then only the histogram for the most positive
         bins will be created until all the avaiable space allocated for
         histogram creation is filled up. Therefore, this function
         Calculates - the (firstHistBin) that will go into the first
         element of the histogram, and the index to the last Bin (idxLastBin)
         The  histogram information will exist in pHist[0] to pHist[idxLastBin]
         and the bin numbers are 0+firstHistBin to idxLastBin+firstHistBin
         For more information look at the explanation in lgmcorrector_correct
Inputs:  1 - number of bins available (nAvailableBins)
         2 - maximum bin number
         3 - pointer to first bin recorded in pHist (firstHistBin)
         4 - pointer to index of last bin - with reference to pHist (idxLastBin)
Outputs: None
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
 static void getHistogramIndexInfo(uint16 nAvailableBins, uint16 maxBinNumber, uint16 *firstHistBin, uint16 *idxLastBin)
 {
    if  (maxBinNumber < nAvailableBins)
    {
      *firstHistBin = 0;
      *idxLastBin = maxBinNumber;
    }
    else
    {
      *firstHistBin = maxBinNumber - (nAvailableBins - 1);
      *idxLastBin = nAvailableBins - 1;
    }
 }

 /* -----------------------------------------------------------------
Name:    getTopThirdHistogramElementsInfo()
Purpose: Goes through the histogram information saved (pHist), finds
         the bins that contain the top 1/3 most positive touch metrics
         (nElementsNeeded). The most positive metric is associated with
         pHist[idxLastBin]. All bins between idx and idxLastBin are
         considered to contain the top 1/3 elements. This function
         returns the index to the beginning of the 1/3 most positive
         bin(idx_p), the index to the bin containing the most number of
         elements(idxMax_p), the total number of elements contained in
         these bins(sumElements_p), and the number of bins that have
         elements in them and are non-zero (nNonZeroBins_p). If
         sumElements >= nElements needed, then the
         histogram contains the relevant bins for calculating the
         correction factor.
Inputs:  1 - pHist: pointer to beginning of array containing the histogram
         2 - Number of elements needed for corrFactor calculation
         3 - index to last bin of histogram relative to pHist[0]
         4 - pointer containing the index to beginning of the top 3rd
             positive elements, idx_p
         5 - pointer containing the index to the mode of the bins, idxMax_p
         6 - pointer to number of elements in the bins marked to contain
             the top 3rd positive elements
         7 - pointer to the number of nonzero bins, nNonZeroBins_p
Outputs: None
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
static void getTopThirdHistogramElementsInfo(uint16 *pHist, uint16 nElementsNeeded, uint16 idxLastBin, uint16  *idx_p, uint16 *idxMax_p, uint16 *sumElements_p, uint16 *nNonZeroBins_p)
{
  uint16 maxNumOfElements;

  uint16 idx;
  uint16 idxMax;
  uint16 sumElements;
  uint16 nNonZeroBins;

  maxNumOfElements = 0;

  sumElements = 0;
  nNonZeroBins = 0;
  idx = idxLastBin;
  idxMax = idx;

  while ((sumElements < nElementsNeeded))
  {
    nNonZeroBins += (uint16)(pHist[idx] > 0);
    sumElements += pHist[idx];
    if (pHist[idx] > maxNumOfElements)
    {
      // It is important NOT to use >= here
      maxNumOfElements = pHist[idx];
      idxMax = idx;
    }
    if(idx == 0) {
      idx--;
      break;
    }
    idx--;
  }

  idx++;

  *idx_p =  idx;
  *idxMax_p =  idxMax;
  *sumElements_p =  sumElements;
  *nNonZeroBins_p =  nNonZeroBins;
}

/* -----------------------------------------------------------------
Name:    getMedianCorrectionFactor()
Purpose: If all elements in the the relevant bins (bins containing top
         1/3rd elements) that are nonzero only contain one element then
         the safest thing to do is to pick the median bin as the correction factor

Inputs:  1 - pointer to first element in histogram
         2 - number of nonzerobins
         3 - index to last bin in the histogram, relative to pHist[0]
         4 - first bin saved in the histogram (smallest bin)
         5 - bin width
Outputs: correction factor
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
static uint32 getMedianCorrectionFactor(uint16 *pHist, uint16 nNonZeroBins, uint16 idxLastBin, uint16 firstHistBin, uint32 binWidth)
{
  uint16 sumElements = nNonZeroBins; // This is the case if we are in here
  uint16 nIterations = 0;
  uint16 medNonZeroIdxHi = nNonZeroBins >> 1;
  uint16 medNonZeroIdxLo = medNonZeroIdxHi - ((nNonZeroBins - 1) & 0x0001);
  uint32 medCorrFactor = 0;
  while (nIterations != 2)
  {
    while (sumElements != medNonZeroIdxHi)
      sumElements -= pHist[idxLastBin--];

    medCorrFactor += (((firstHistBin + idxLastBin + 1)*binWidth + binWidth/2 ) >> 1);
    medNonZeroIdxHi = medNonZeroIdxLo;
    nIterations++;
  }
  return medCorrFactor;
}

/* -----------------------------------------------------------------
Name:    correctDeltaImage()
Purpose: Applies the calculated lgm correction factor to the delta
         trans capacitive image (pDeltaImage). Please note that this
         algorithm does not apply any correction to the delta profiles,
         because the shapes of the delta profiles under LGM are not
         distorted when guarding the orthogonal axis to the sensing axis.
         Only their signal levels are attenuated.
         Checks for overcompensation in the corrected image and corrects
         for it by recalculating the correction factor and corrected delta image

Inputs:  1 - pDeltaImage: transcap delta image
         2,3 - pdeltaXProfile, pDeltaYProfile: delta profiles
         4 - lgmManagerParams: parameters passed along by the lgmManager module
         5 - sensor params
         6 - pointer to array saving the indices of corrected pixels
Outputs: None
Effects: Modifies the delta image, pDeltaImage. Its effects are propagated
         through the whole IFP chain
Notes:   None
Example: None.
----------------------------------------------------------------- */
static void correctDeltaImage(int16 *pDeltaImage, int16 *pdeltaXProfile, int16 *pdeltaYProfile, lgmManagerParams_t *lgmManagerParams,  sensorParams_t *pSensorParams, uint16 *pCorrectedPixIndices )
{
  // Safe for sensors that have more than 4 receivers and 4 transmitters
  uint16 *pIndicesOfCorrectedPixels = pCorrectedPixIndices;
  uint16 *pYElectrodes   = lgmManagerParams->lgmCorrElectrodes.y;
  uint16 yLength = lgmManagerParams->lgmCorrElectrodes.yLength;
  uint16 *pXElectrodes;
  uint16 xLength = lgmManagerParams->lgmCorrElectrodes.xLength;
  uint16 nTotalPixelsNeedingCorrection = 0;
  uint16 idx = 0;
  uint32 currProfImageVal;
  int16  maxPixNewDeltaImage           = 0;
  uint32 profImageValOfMaxPix          = 0;
  uint16 i;
#if CONFIG_HAS_LGM_CORRECTOR_CORRECTOR
  int16 ceiling = pSensorParams->LGMCorrectorCorrector.Enable ? pSensorParams->LGMCorrectorCorrector.Ceiling : -32768;
#endif

  for (i = 0; (i < yLength) && (*pYElectrodes != 0); i++)
  {
    int16 deltaY = pdeltaYProfile[ O2Z_IDX(*pYElectrodes) ];
    uint16 idx_start = (MAX_RX + 1) * (*pYElectrodes);
    uint16 j;
    pXElectrodes = lgmManagerParams->lgmCorrElectrodes.x;
    for (j = 0; (j < xLength) && (*pXElectrodes != 0); j++)
    {
      uint16 expAdditiveCorrection;
      uint32 mantissaAdditiveCorrection;
      nTotalPixelsNeedingCorrection++;
      idx =  idx_start + *pXElectrodes;
      currProfImageVal = (uint32)pdeltaXProfile[ O2Z_IDX(*pXElectrodes) ] * (uint16)deltaY;
      mantissaAdditiveCorrection = mul32By32(corrFactor, currProfImageVal, &expAdditiveCorrection);
    #if CONFIG_HAS_LGM_CORRECTOR_CORRECTOR
      int16 org = pDeltaImage[idx];
    #endif
      if (expAdditiveCorrection <= TRANS_SHIFT)
        pDeltaImage[idx] = pDeltaImage[idx] + ((mantissaAdditiveCorrection) >> (TRANS_SHIFT - expAdditiveCorrection));
      else
        pDeltaImage[idx] = pDeltaImage[idx] + ((mantissaAdditiveCorrection) << (expAdditiveCorrection - TRANS_SHIFT));
    #if CONFIG_HAS_LGM_CORRECTOR_CORRECTOR
      if (org <= ceiling)
      {
        if (ceiling < pDeltaImage[idx])
          pDeltaImage[idx] = ceiling;
      }
    #endif
      *pIndicesOfCorrectedPixels++ = idx;
      if (pDeltaImage[idx] > maxPixNewDeltaImage)
      {
        maxPixNewDeltaImage = pDeltaImage[idx];
        profImageValOfMaxPix = currProfImageVal;
      }
      pXElectrodes++;
    }
    pYElectrodes++;
  }

  if (maxPixNewDeltaImage == 0)
  {
    corrFactor = 0;
    return;
  }
  else if( maxPixNewDeltaImage > (int16)(pSensorParams->cSat_LSB * 68 >> 6) ) // * 1.05
  {
    // If maximum pixel value in the corrected image is greater than 5% of the saturation
    // value, recalculate correction factor and corrected image
    uint32 corrFactorOvercompensation;
    uint16 deltaADCOvercompensation   = maxPixNewDeltaImage - pSensorParams->cSat_LSB;
    if(deltaADCOvercompensation <= 255)
      corrFactorOvercompensation = ((uint32)deltaADCOvercompensation << (TRANS_SHIFT))/profImageValOfMaxPix;
    else if(deltaADCOvercompensation <= 511 && (profImageValOfMaxPix >= 2))
      corrFactorOvercompensation = ((uint32)deltaADCOvercompensation << (TRANS_SHIFT-1))/(profImageValOfMaxPix/2);
    else if(deltaADCOvercompensation <= 1023 && (profImageValOfMaxPix >= 4))
      corrFactorOvercompensation = ((uint32)deltaADCOvercompensation << (TRANS_SHIFT-2))/(profImageValOfMaxPix/4);
    else if(deltaADCOvercompensation <= 2047 && (profImageValOfMaxPix >= 8))
      corrFactorOvercompensation = ((uint32)deltaADCOvercompensation << (TRANS_SHIFT-3))/(profImageValOfMaxPix/8);
    else if(deltaADCOvercompensation <= 4096 && (profImageValOfMaxPix >= 16))
      corrFactorOvercompensation = ((uint32)deltaADCOvercompensation << (TRANS_SHIFT-4))/(profImageValOfMaxPix/16);
    else
      corrFactorOvercompensation = corrFactor;

    if (corrFactor >= corrFactorOvercompensation )
    {
      uint16 i;
      // This if statement should always be true if cSat_LSB is tuned properly. If the LGM code made it inside the
      // else if statement ( maxPixNewDeltaImage > (int16)(pSensorParams->cSat_LSB * 68 >> 6) )then the LGM code
      // should always be running the code within this if statement. However, it has been seen unfortunately,
      // that currently almost always this value is tuned without properly grounding the slug. As a result of this,
      // LGM algorithm will not work properly and it will be even more catastrophic if this if statement does not exist.
      // It has been seen that with proper tuning, cSat_LSB can be 200% of what it is being tuned for as of today.
      // 1 - For proper LGM algorithm functioning cSat_LSB should be tuned properly and therefore the if condition above should always be true.
      // 2 - If cSat_LSB is not tuned properly, the if condition may become false, in which case the code below will not run
      // 3 - If the code below runs when the if condition is false, the results will be catastrophic
      // 4 - If the if condition is false and therefore the code below does not run, LGM reconstruction will not be doing its job fully
      // 5 - All the above means, PLEASE tune cSat_LSB correctly by physically connecting the slug to the ground of the system when tuning for this parameter. Thanks.
      corrFactor    -= corrFactorOvercompensation;
      pYElectrodes   = lgmManagerParams->lgmCorrElectrodes.y;
      pIndicesOfCorrectedPixels = pCorrectedPixIndices;

      for (i = 0; (i < yLength) && (*pYElectrodes != 0); i++)
      {
        int16 deltaY = pdeltaYProfile[ O2Z_IDX(*pYElectrodes) ];
        uint16 j;
        pXElectrodes = lgmManagerParams->lgmCorrElectrodes.x;
        for (j = 0; (j < xLength) && (*pXElectrodes != 0); j++)
        {
          uint16 expAdditiveCorrection;
          uint32 mantissaAdditiveCorrection;
          idx = *pIndicesOfCorrectedPixels;
          currProfImageVal = (uint32)pdeltaXProfile[ O2Z_IDX(*pXElectrodes) ] * (uint16)deltaY;
          mantissaAdditiveCorrection = mul32By32(corrFactorOvercompensation, currProfImageVal, &expAdditiveCorrection);
          if (expAdditiveCorrection <= TRANS_SHIFT)
            pDeltaImage[idx] = pDeltaImage[idx] - (mantissaAdditiveCorrection >> (TRANS_SHIFT - expAdditiveCorrection));
          else
            pDeltaImage[idx] = pDeltaImage[idx] - (mantissaAdditiveCorrection << (expAdditiveCorrection - TRANS_SHIFT));
          pIndicesOfCorrectedPixels++;
          pXElectrodes++;
        }
        pYElectrodes++;
      }
    }
    else
      corrFactor = 0;
  }
}
/*==================================================================
MODULE MAIN FUNCTIONS
===================================================================*/

void lgmCorrector_init(void)
{
  corrFactor     = 0;
  prevCorrFactor = 0;
}

void lgmCorrector_reinit(void)
{
  corrFactor     = 0;
  prevCorrFactor = 0;
}

/* -----------------------------------------------------------------
Name:    lgmCorrector_correct()
Purpose: Purpose: Calculates an lgm correction factor for the current frame
         and applies the correction factor to the delta trans capacitive
         image (pDeltaImage). Please note that this algorithm does not
         apply any correction to the delta profiles, because the shapes of
         the delta profiles under LGM are not distorted when guarding the
         orthogonal axis to the sensing axis. Only their signal levels are
         attenuated.

Inputs:  1 - pDeltaImage: transcap delta image
         2,3 - pdeltaXProfile, pDeltaYProfile: delta profiles
         4 - lgmManagerParams: parameters passed along by the lgmManager module
         5 - sensor params
Outputs: None
Effects: Modifies the delta image. Therefore its effects are propagated
         through the whole IFP chain.
Notes:   Please note that the number of bins are not the same as nHistElements.
         The histogram can be quite sparse and therefore alot more bins may be
         required than the number of elements that go into the histogram. The opposite
         is also true. There is no correlation between nHistElements and maxBinNumber.
         This code utilizes the available RAM to
         1 - maximize the number of bins that can be used
         2-  use simple code for histogram creation
         3 - make use of the available number of bins if the number of bins needed
             exceeds the space available. This is why the binNumbers are saved so that
             the span of bins needed will be known beforehand.
         4 - Minimize the number of passes needed to go through the image. Another reason
             bin numbers are saved.

         ----------------------------------------------------------------------------------
         ****Structure of touchMetricInfo:*************************************************
         -----------------------------------------------------------------------------------
         nHistElements + nAvailableBins = TOUCH_METRIC_SIZE

                             ------|binNumber 0                   |<-&touchMetricInfo[0]
                            |      |     .                        |
              nHistElements--      |     .                        |
                            |      |binNumber nHistElements-1     |
                             ------| nElements in bin 0           |<-pHist
                            |      |     .                        |
                            |      |     .                        |
         nAvailableBins   --|      | nElements in bin maxBinNumber|<-  contains the last valid entry
         which can be used  |      |     .                        |
         for binning        -------|     .                        |
         ----------------------------------------------------------------------------------
         If there are more bins than nAvailableBins then the top bins are saved:


                             ------|binNumber 0                                    |<-&touchMetricInfo[0]
                            |      |     .                                         |
              nHistElements--      |     .                                         |
                            |      |binNumber nHistElements-1                      |
                             ------| nElements in bin (maxBinNumber-nAvailableBins)|<-pHist
                            |      |     .                                         |
                            |      |     .                                         |
         nAvailableBins   --|      |     .                                         |
         which can be used  |      |     .                                         |
         for binning        -------|nElements in bin maxBinNumber                  |<-  contains the last valid entry
         -----------------------------------------------------------------------------------
Example: None.
----------------------------------------------------------------- */
void lgmCorrector_correct(int16 *pDeltaImage, int16 *pdeltaXProfile, int16 *pdeltaYProfile,  sensorParams_t *pSensorParams, lgmManagerParams_t *lgmManagerParams)
{
  uint16 maxCorrErr;    // Max ADC error allowed within each bin
  uint32 binWidth;
  uint16 touchMetricInfo[ TOUCH_METRIC_SIZE ];
  uint16 nHistElements;// Total number of elements that will go into the histogram
  uint32 maxProfImageValue;
  uint16 maxBinNumber;

  if (lgmManagerParams->skipCorrection == 1)
  {
    corrFactor = 0;
    prevCorrFactor = 0;
    return;
  }
  // Set the global variable
  bIsOverFlow = 0;

  maxCorrErr = min(max((pSensorParams->noiseFloor_LSB - 1), 1), 7); //Make sure this fits in 3 bits

  // save previous frame's correction factor
  prevCorrFactor = corrFactor;

  corrFactor = 0;
  // Find maximum of profile image for calculating the bin width
  maxProfImageValue = findMaxOfProfileImage(pdeltaXProfile, pdeltaYProfile, lgmManagerParams);
  if (lgmManagerParams->usePrevLGMCorrFactor == 0)
  {
    // Calculate binWidth, please note that if binWidth == 0, then nHistElements in CalculateTouchMetricInfo
    // will be returned as 0. This prevents going into the if (nHistElements >=4) statement. Therefore divide
    // by binWidth, or in this case, divide by 0, will be prevented.
    // If binWidth happens to be 0, them maxProfImageValue should be rightshifted. This right-shift should propagate
    //correctly through the rest of the code. This solution is not adopted here; instead, no correction is done.
    binWidth = ((uint32)maxCorrErr << (TRANS_SHIFT))/maxProfImageValue;

    // Initialize parameters relevant for calculating histograms
    memset16(&touchMetricInfo[0], 0, TOUCH_METRIC_SIZE * sizeof(touchMetricInfo[0]) / sizeof(uint16)); // debug only
    maxBinNumber = 0;
    // Calculate histogram
    nHistElements = calculateTouchMetricInfo(
                                            lgmManagerParams,
                                            pDeltaImage,
                                            pdeltaXProfile,
                                            pdeltaYProfile,
                                            &touchMetricInfo[0],
                                            binWidth,
                                            &maxBinNumber);
    if (nHistElements >=4)
    {
      uint16 idxMax;
      uint16 idxLastBin;
      uint16 nNonZeroBins;
      uint16 nAvailableBins;
      uint16 firstHistBin;
      uint16 sumElements;
      uint16 *pHist;
      uint16 nElementsNeeded;
      uint16 idx;

      createHistogram(&touchMetricInfo[0], TOUCH_METRIC_SIZE, nHistElements, maxBinNumber);
      nAvailableBins = TOUCH_METRIC_SIZE - nHistElements;
      getHistogramIndexInfo(nAvailableBins, maxBinNumber, &firstHistBin, &idxLastBin);

      pHist = &touchMetricInfo[nHistElements]; // point to first bin in the histogram
      nElementsNeeded = ((nHistElements - 1) / 3) + 1;  // number of elements needed for corrFactor calculation
      getTopThirdHistogramElementsInfo(pHist, nElementsNeeded, idxLastBin, &idx, &idxMax, &sumElements, &nNonZeroBins);

      // If sumElements >= nElementsNeeded then enough relevant information exists in the bins to calculate the correction factor
      // If not, the size of touchMetricinfo needs to increase to accomodate more number of bins
      if (sumElements >= nElementsNeeded)
      {
        if (sumElements == nNonZeroBins)
        {
          // If this is the case then all the bins contain only 1 element in which case
          // the safest thing to do is to take the median of the bins
          corrFactor = getMedianCorrectionFactor(pHist, nNonZeroBins, idxLastBin, firstHistBin, binWidth);
        }
        else
        {
          // Due to the mathematics behind this, the multiplication should not overflow.
          corrFactor = (firstHistBin + idxMax)*binWidth + binWidth / 2;
        }
      }
    }
  }

  if (corrFactor == 0 && prevCorrFactor != 0 && lgmManagerParams->isPrevLGMObjStillPresent == 1 && bIsOverFlow == 0)
    corrFactor = prevCorrFactor;

  if (corrFactor != 0)
  {
    // Utilize touchMetricInfo to save the indices of corrected pixels
    uint16 *pIndicesOfCorrectedPixels = &touchMetricInfo[0];
    uint32 maxAdditiveCorrection;
    uint16 expAdditiveCorrection;
    uint32 mantissaAdditiveCorrection;

    // Before attempting to do any kind of correction, ensure that no overflow will occur in adding the additive
    // LGM correction to the lgm corrupted deltaImage. The delta image is int16 whereas if there is an error in
    // correction factor calculation the additive correction can be a uint32. Because the deltaImage is corrected
    // on the fly on a pixel by pixel basis, if an attempt to correct pixel n results in overflow, there is no way
    // to recover the previous pixel values, hence no way to recover the original image. And; obviously the corrected
    // image is also corrupted. So it should be ensured that no such overflow will occur before attempting to correct
    // the image. If the pixel which has the largest profImagevalue will not cause overflow, then this condition
    // won't happen and it is safe to proceed with correction
    mantissaAdditiveCorrection = mul32By32(corrFactor, maxProfImageValue, &expAdditiveCorrection);
    if (expAdditiveCorrection <= TRANS_SHIFT)
      maxAdditiveCorrection = ((mantissaAdditiveCorrection) >> (TRANS_SHIFT - expAdditiveCorrection));
    else
      maxAdditiveCorrection = ((mantissaAdditiveCorrection) << (expAdditiveCorrection - TRANS_SHIFT));

    // Make sure result of additive correction fits in 15 bits so that when it is added to the original
    // int16 deltaImage, it will not overflow
    if (maxAdditiveCorrection < MAX_ALLOWED_CORRECTION)
      correctDeltaImage(pDeltaImage, pdeltaXProfile, pdeltaYProfile, lgmManagerParams, pSensorParams, pIndicesOfCorrectedPixels);
    else
      corrFactor = 0;
  }

  return;
}

#endif // CONFIG_HAS_LGM_CORRECTOR
