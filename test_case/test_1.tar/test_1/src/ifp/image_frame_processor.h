#ifndef _image_frame_processor_H_
#define _image_frame_processor_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: image_frame_processor.h
// Description: Header file for Image Frame Processor, the gateway
//   to image processing routines on Waikiki. All functions accessing
//   image processing variables from outside of the ifp/ directory MUST
//   be declared here.
//
// $Id: image_frame_processor.h,v 1.5.8.2.4.2 2013/01/02 22:32:24 nfotopou Exp $

#include "ifp_common.h"

#ifdef __cplusplus
extern "C" {
#endif
/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: imageFrameProcessor_init()
Purpose: Initialize image processing, used at startup
Inputs: None.
Outputs: None.
Effects: Resets all internal state of image processing modules to
         power-on values.
Notes: This function must be called before the first call to
       imageFrameProcessor_nextFrame().
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_init(void);

/* -----------------------------------------------------------------
Name: imageFrameProcessor_reinit()
Purpose: Initialize image processing, used at rezero
Inputs: None.
Outputs: None.
Effects: Reset image processor state, as at a rezero command. This
         clears the baseline estimate and all objects that were
         being tracked.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_reinit(void);

#if CONFIG_IFP_ESD_ACTIVEMODE
/* -----------------------------------------------------------------
Name: imageFrameProcessor_reinit_keepBaseline()
Purpose: Initialize image processing, used at exit ESD_MODE
Inputs: None.
Outputs: None.
Effects: Reset image processor state, as at a rezero command.
         This clears objects that were being tracked.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_reinit_keepBaseline(void);
#endif
/* -----------------------------------------------------------------
Name: imageFrameProcessor_configure()
Purpose: Configure image processing modules
Inputs: config - configuration structure
Outputs: None.
Effects: Overwrites any previous configuration. If configuration
         changes substantially, modules may drop previously
         tracked objects. If configuration is inconsistent in
         some way, the image processing modules may return
         nonsensical data.
Notes: This function must be called before the first call to
       imageFrameProcessor_nextFrame().
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_configure(ifpConfig_t *config);

/* -----------------------------------------------------------------
Name: imageFrameProcessor_nextFrame()
Purpose: Process a new image frame
Inputs: frame - the new raw image/profiles to process
        timeSinceLast_ms - time since the previous frame, in
                           milliseconds
        mode - specifies how IFP should behave, including the flags:
          noiseMitigationEnabled - set to true if firmware noise
                                   mitigation is currently being
                                   used.
          inhibitRelaxation - set to true to prevent any updates
                              of the baseline estimate.
Outputs: report - the report structure.
Effects: Updates internal module states.
Notes: - On the first frame, timeSinceLast_ms is ignored.
       - The timeSinceLast_ms parameter is used for tracking objects
       and classifying them. You must provide a reasonable value
       close to your actual frame period for it--zero will not work.
Example:
  uint16 rawImage[MAX_TX*MAX_RX];
  ifpFrame_t frame;
  reportData_t reports;
  ifpTimeStamp_t framePeriod_ms = 10; // don't hard-code this if it varies
  ifpMode_t mode;
  mode.inhibitRelaxation = 0;
  mode.noiseMitigationEnabled = 0;
  frame.image = rawImage;

  while (TRUE)
  {
    ... // copy an image into rawImage
    imageFrameProcessor_nextFrame(&reports, frame, framePeriod_ms, mode);
    if (reports.freshData)
    {
      // report to host
    }
    elseif (reports.objectsPresent)
    {
      // inhibit doze/sleep
    }
  }
----------------------------------------------------------------- */
void imageFrameProcessor_nextFrame(reportData_t *report, ifpFrame_t *frame,
                                   ifpTimeStamp_t timeSinceLast_ms,
                                   ifpMode_t mode);

#if CONFIG_HIC_LPWG_MODE_B
/* -----------------------------------------------------------------
Name: imageFrameProcessor_absFilterApplyFilter()
Purpose: Apply a filter to abs data
Inputs:  *frame.
Outputs: None.
Effects: None.
Notes:   Entry point for non-IFP code
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_absFilterApplyFilter(int16 *absPtr, uint16 num, uint16 isX);

/* -----------------------------------------------------------------
Name: imageFrameProcessor_nextUltraLPWGFrame()
Purpose: Quick finger detection in LPWG abs cap TRGT mode
Inputs: frame - new raw image/profiles to process
        timeSinceLast_ms - time since the previous frame, in
                           milliseconds
        mode - specifies how IFP should behave, including the flags:
          noiseMitigationEnabled - set to true if firmware noise
                                   mitigation is currently being
                                   used.
          inhibitRelaxation - set to true to prevent any updates
                              of the baseline estimate.
Outputs: Loads finger positions in the reports structure.
Effects: No harmful effects.
Notes:
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_nextUltraLPWGFrame(reportData_t *report ATTR_UNUSED, ifpFrame_t *frame,
    ifpTimeStamp_t timeSinceLast_ms ATTR_UNUSED, ifpMode_t mode ATTR_UNUSED);
#endif

/* -----------------------------------------------------------------
Name: imageFrameProcessor_getBaseline()
Purpose: Get a pointer to the baseline uint16 array.
Inputs: baseline type (baselineType_t enum)
Outputs: pointer to uint16 array holding the current baseline
         estimate of the requested type or NULL if baseline has not
         yet been acquired
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
uint16 *imageFrameProcessor_getBaseline(uint16 baselineType);

/* -----------------------------------------------------------------
Name: imageFrameProcessor_getDelta()
Purpose: Get a pointer to the delta uint16 array.
Inputs: baseline type (baselineType_t enum)
Outputs: pointer to uint16 array holding the current delta
         of the requested type or NULL if baseline has not
         yet been acquired
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
int16 *imageFrameProcessor_getDelta(uint16 baselineType);

/* -----------------------------------------------------------------
Name: imageFrameProcessor_getBaselineState()
Purpose: Determine whether the baseline of a given type has been acquired
Inputs: baseline type (baselineType_t enum)
Outputs: Baseline state (baselineState_t enum), either
         baselineState_noBaseline or baselineState_baselineAcquired
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
uint16 imageFrameProcessor_getBaselineState(uint16 baselineType);
void imageFrameProcessor_getButtons0DDiagnostics(buttons0DDiagnostics_t *buttons0DDiagnostics);
/* -----------------------------------------------------------------
Name: imageFrameProcessor_computeTagsImage()
Purpose: Create the tag image for RT76 production test
Inputs: rawSrc
        dstTags
Outputs: None
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void imageFrameProcessor_computeTagsImage(int16 *rawSrc, int16 *dstTags);
#ifdef __cplusplus
};
#endif

#endif  //_image_frame_processor_H_
