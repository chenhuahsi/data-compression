#ifndef _ADAPTIVE_LGM_H_
#define _ADAPTIVE_LGM_H_

#include "ifp_common.h"

#if CONFIG_HAS_ADAPTIVE_LGM
void adaptive_LGM_compensate(int16 *pDeltaImage , sensorParams_t *mSensorParams);
uint16 getMaxTixelDeltaImage_ALGM(int16 *deltaImage, sensorParams_t *mSensorParams);
uint16 estimateElectrodesAccumDelta(int16 *pDeltaImage, int16 compVal, sensorParams_t *mSensorParams);
float filterAlgmCoeff(float alpha, float k);
void ALGM_init(void);
void ALGM_reinit(void);
void setAlgmEnabled(uint16 enable);
void aLGM_configure(aLGMConfig_t *config);
void adaptive_lgm_initCSat (uint16 cSat_LSB);
void adaptive_lgm_recoverCSat (uint16 *cSat_LSB);
#else
static ATTR_INLINE void adaptive_LGM_compensate(ATTR_UNUSED int16 *pDeltaImage,
                                               ATTR_UNUSED sensorParams_t *mSensorParams) {};
static ATTR_INLINE uint16 getMaxTixelDeltaImage_ALGM(ATTR_UNUSED int16 *deltaImage,
                                                     ATTR_UNUSED sensorParams_t *mSensorParams) { return 0; };
static ATTR_INLINE uint16 estimateElectrodesAccumDelta(ATTR_UNUSED int16 *pDeltaImage,
                                                       ATTR_UNUSED int16 compVal,
                                                       ATTR_UNUSED sensorParams_t *mSensorParams) { return 0; };
static ATTR_INLINE float filterAlgmCoeff(ATTR_UNUSED float alpha,
                                         ATTR_UNUSED float k) { return 0; };
static ATTR_INLINE void ALGM_init(void) {};
static ATTR_INLINE void ALGM_reinit(void) {};
static ATTR_INLINE void setAlgmEnabled(ATTR_UNUSED uint16 enable) {};
static ATTR_INLINE void aLGM_configure(ATTR_UNUSED aLGMConfig_t *config) {};
static ATTR_INLINE void adaptive_lgm_initCSat (ATTR_UNUSED uint16 cSat_LSB) {};
static ATTR_INLINE void adaptive_lgm_recoverCSat (ATTR_UNUSED uint16 *cSat_LSB) {};
#endif // CONFIG_HAS_ADAPTIVE_LGM

#if CONFIG_IFP_ALGM_FITCURVE_ENABLE
uint16 getALGMTuningEnableStatus(void);
void collectLGMData(uint16 *pLGMMaxDeltaValTest,
                    uint16 *pLGMRelatedAreaTest,
                    uint16 *pLGMFingerPredictMaxValTest,
                    uint16 *pLGMRealFingerThresholdTest);
#endif // CONFIG_IFP_ALGM_FITCURVE_ENABLE


#endif

