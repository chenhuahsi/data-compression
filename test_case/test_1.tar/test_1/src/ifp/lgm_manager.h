//==============================================================================
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 Mckay Drive
// San Jose, CA 95131
// (408) 904-1100
//

/*
 *
 */

#ifndef _LGM_MANAGER_H_
#define _LGM_MANAGER_H_

#if CONFIG_HAS_LGM_CORRECTOR
void lgmManager_init(void);
void lgmManager_reinit(void);
void lgmManager_configure(lgmManagerConfig_t *config);
void lgmManager_manage(
                       int16 *pDeltaImage,
                       int16 *pdeltaXProfile,
                       int16 *pdeltaYProfile,
                       sensorParams_t *pSensorParams,
                       uint16 correctionDisabled,
                       lgmManagerParams_t * lgmManagerParams
                                );
#else
static ATTR_INLINE void lgmManager_init(void) {};
static ATTR_INLINE void lgmManager_reinit(void) {};
static ATTR_INLINE void lgmManager_configure(ATTR_UNUSED lgmManagerConfig_t *config) {};
static ATTR_INLINE void lgmManager_manage(
                       ATTR_UNUSED int16 *pDeltaImage,
                       ATTR_UNUSED int16 *pdeltaXProfile,
                       ATTR_UNUSED int16 *pdeltaYProfile,
                       ATTR_UNUSED sensorParams_t *pSensorParams,
                       ATTR_UNUSED uint16 correctionDisabled,
                       ATTR_UNUSED lgmManagerParams_t * lgmManagerParams
                                )  {};
#endif // CONFIG_HAS_LGM_CORRECTOR

#endif
