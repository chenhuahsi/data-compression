/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: segmenter.h
   Description: Header for watershed segmenter block external API
----------------------------------------------------------------- */
#ifndef _SEGMENTER_H
#define _SEGMENTER_H

void segmenter_init(void);
void segmenter_reinit(void);
void segmenter_configure(segmenterConfig_t *config);
void segmenter_segment(int16 *deltaImage, int16 noiseFloor_LSB,
                       sensorParams_t *sensorParams,
                       clumps_t *clumps);

#endif // _SEGMENTER_H
