/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Description: Removes shadow artifacts from delta image
----------------------------------------------------------------- */

#include "ifp_common.h"

#if CONFIG_HAS_SHADOW_REMOVER

#include "shadow_remover.h"
#include "ifp_string.h"
#include "ifp_vector_util.h"

/* =================================================================
   MODULE VARIABLES
==================================================================*/
uint0p16 fingerThreshold_pct;
uint0p16 penThreshold_pct;
shadowDirection_t shadowDirection;

/* =================================================================
   MODULE STATIC FUNCTIONS DECLARATIONS
==================================================================*/
static uint16 createBlobMap(int16 *deltaImage, sensorParams_t* sensorParams, int16 *blobMap, uint16 *blobRows, uint16 *blobCols);
static void dilate3x3(int16 *ptr);
static void maskRowPixelsNotBetweenTouches(sensorParams_t* sensorParams, int16 *blobMap, uint16 *blobRows);
static void removeColShadows(int16* deltaImage, int16 *blobMap,  uint16 *blobCols, sensorParams_t* sensorParams);
static void removeRowShadows(int16* deltaImage, int16 *blobMap, uint16 *blobRows, sensorParams_t* sensorParams);
static void calcLinearLeastSquaresFit(int16 *array, int16 *mask, uint16 arraySize, uint16 stepSize, int16 noiseFloor);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/
// -----------------------------------------------------------------
// Name:    createBlobMap()
// Purpose: Constructs blobs by thresholding the delta image.
// Inputs:  deltaImage - pointer to delta image
//          sensorParams - sensor parameters
//          blobMap - pointer to blob map
//          blobRows - pointer to array of flags that are are set if a blob
//                     is present in current row
//          blobCols - pointer to array of flags that are are set if a blob
//                     is present in current col
// Outputs: None.
// Effects: None.
// Notes:   blobMap, blobRows and blobCols are updated.
//          blobMap pixel = 1 if finger is present
//                        = -1 if pen is present
//                        = -2 if the pixel is affected by LGM
//                        = 0 otherwise
// Example: None.
// -----------------------------------------------------------------
static uint16 createBlobMap(int16 *deltaImage,
                            sensorParams_t* sensorParams,
                            int16 *blobMap,
                            uint16 *blobRows,
                            uint16 *blobCols)
{
  int16 row, col;
  int16 maxRows = sensorParams->txCount;
  int16 maxCols = sensorParams->rxCount;
  uint16 hasTouch = FALSE;
  int16 fingerThreshold = ((uint32)sensorParams->cSat_LSB * fingerThreshold_pct) >> 16;
  int16 penThreshold = ((uint32)sensorParams->cSat_LSB * penThreshold_pct) >> 16;
  // SDPthreshold is the threshold for the product of second derivatives of
  // delta image along rows and cols
  uint16 SDPthreshold = (uint16) penThreshold * ((uint16) penThreshold >> 1);

  // Threshold the delta image at fingerThreshold and
  // dilate the blobs along rows and cols
    for (row = 1; row <= maxRows; row++)
    {
      int16 *pBlob = &blobMap[row*(MAX_RX+1) + 1];
      int16 *pDelta = &deltaImage[row*(MAX_RX+1) + 1];
      for (col = 1; col <= maxCols; col++)
      {
        if (*pDelta >= fingerThreshold)
        {
          dilate3x3(pBlob);
          blobRows[row-1] = 1;
          blobRows[row] = 1;
          blobRows[row+1] = 1;
          blobCols[col-1] = 1;
          blobCols[col] = 1;
          blobCols[col+1] = 1;
          hasTouch = TRUE;
        }
        pBlob++;
        pDelta++;
      }
    }
  if (penThreshold > 0)
  {
    // Do not calculate second derivatives product along the border pixels
    for (row = 2; row < maxRows; row++)
    {
      int16 *pBlob = &blobMap[row*(MAX_RX+1) + 2];  // set at center pixel
      int16 *pDelta = &deltaImage[(row - 1)*(MAX_RX+1) + 2];  // set at top pixel
      for (col = 2; col < maxCols; col++)
      {
        if (*pBlob == 0)
        {
          // Set blobMap to -1 at pen pixels
          int16 SDP_vert = 2*pDelta[MAX_RX+1] - pDelta[0] - pDelta[2*MAX_RX+2];

          if (SDP_vert > 0)
          {
            int16 SDP_horiz = 2*pDelta[MAX_RX+1] - pDelta[MAX_RX] - pDelta[MAX_RX+2];
            if ((SDP_horiz > 0) && ((uint16) SDP_vert * (uint16) SDP_horiz >= SDPthreshold))
            {
              *pBlob = -1; // pen pixel
            }
          }
        }
        pBlob++;
        pDelta++;
      }
    }
  }

  if (hasTouch)
  {
    // Set blobMap to -2 at pixels affected by LGM
    for (row = 1; row <= maxRows; row++)
    {
      if (blobRows[row] > 0)
      {
      int16 *pBlob = &blobMap[row*(MAX_RX+1) + 1];
      for (col = 1; col <= maxCols; col++)
      {
          if ((blobCols[col] > 0) && (*pBlob == 0))
        // LGM pixels in the blob map cannot overwrite finger or pen pixels
        {
          *pBlob = -2; // LGM pixel
        }
        pBlob++;
      }
    }
  }
  }
  return hasTouch;
}

/* -----------------------------------------------------------
Name: dilate3x3
Purpose: Fills a pixel and the 3x3 block around it with ones.
Inputs:  pointer to a pixel in input image
Outputs: None.
Effects: None.
Notes: None.
----------------------------------------------------------- */
static void dilate3x3(int16 *ptr)
{
  ptr -= MAX_RX+2;
  ptr[0]          = 1;
  ptr[1]          = 1;
  ptr[2]          = 1;
  ptr[MAX_RX+1]   = 1;
  ptr[MAX_RX+2]   = 1;
  ptr[MAX_RX+3]   = 1;
  ptr[2*MAX_RX+2] = 1;
  ptr[2*MAX_RX+3] = 1;
  ptr[2*MAX_RX+4] = 1;
}

// -----------------------------------------------------------------
// Name:    maskRowPixelsNotBetweenTouches()
// Purpose: Mask out pixels in rows that are not between touched pixels
// Inputs:  sensorParams - sensor parameters
//          blobMap - pointer to blob map
//          blobRows - pointer to array of flags that are are set if a blob
//                     is present in current row
// Outputs: None.
// Effects: None.
// Notes:   blobMap, blobRows and blobCols are updated.
//          blobMap pixel = 1 if finger is present
//                        = -1 if pen is present
//                        = -2 if the pixel is affected by LGM
//                        = 0 otherwise
// Example: None.
// -----------------------------------------------------------------
static void maskRowPixelsNotBetweenTouches(sensorParams_t* sensorParams, int16 *blobMap, uint16 *blobRows)
{
  uint16 row, col;
  uint16 maxRows = sensorParams->txCount;
  uint16 maxCols = sensorParams->rxCount;

  for (row = 1; row <= maxRows; row++)
  {
    int16 *pBlob = &blobMap[row*(MAX_RX+1) + 1];
    uint16 firstTouchedCol = 0;
    uint16 lastTouchedCol = 0;
    uint16 emptyColsFlag = 0;

    // skip rows that shadow removal not operating on
    if (!blobRows[row])
    {
      continue;
    }

    // search for first and last touched col
    for (col = 1; col <= maxCols; col++)
    {
      if (*pBlob == 1)
      {
        if (!firstTouchedCol)
        {
          firstTouchedCol = col;
        }
        lastTouchedCol = col;
      }
      pBlob++;
    }

    // mark cols before first as touched so shadow removal does not operate there
    pBlob = &blobMap[row*(MAX_RX+1) + 1];
    for (col = 1; col < firstTouchedCol; col++)
    {
      *pBlob = 1;
      pBlob++;
    }

    // mark cols after last as touched so shadow removal does not operate there
    pBlob = &blobMap[row*(MAX_RX+1) + lastTouchedCol];
    for (col = lastTouchedCol; col < maxCols; col++)
    {
      *pBlob = 1;
      pBlob++;
    }

    // check for columns that are empty to flag row for shadow removal
    pBlob = &blobMap[row*(MAX_RX+1) + 1];
    for (col = 1; col <= maxCols; col++)
    {
      if (*pBlob == 0)
  {
        emptyColsFlag = 1;
        break;
      }
      pBlob++;
    }
    blobRows[row] = emptyColsFlag;
  }
}

// -----------------------------------------------------------------
// Name:    removeColShadows()
// Purpose: Remove shadows along cols
// Inputs:  deltaImage - pointer to delta image to be overwritten with
//                       its estimate without shadows along cols
//          blobMap - pointer to blob map
//          blobCols - pointer to array of flags that are set if a
//                     blob is present in the current col
//          sensorParams - sensor parameters
// Outputs: None.
// Effects: None.
// Notes:   None.
// Example: None.
// -----------------------------------------------------------------
static void removeColShadows(int16* deltaImage,
                             int16 *blobMap,
                             uint16 *blobCols,
                             sensorParams_t* sensorParams)
{
  uint16 col;
  uint16 maxRows = sensorParams->txCount;
  uint16 maxCols = sensorParams->rxCount;

  for (col = 1; col <= maxCols; col++)
  {
    uint16 row = 1;
    uint16 startRow = 1;

    if (blobCols[col] > 0)
    {
      while (row < maxRows+1)
      {
        // Traverse down the col till a finger blob is encountered
        while ((row <= maxRows) && (blobMap[row*(MAX_RX+1) + col] != 1))
        {
          row++;
        }

        if (row > 1)
        {
          // Subtract the least squares estimate of the shadow region from the delta image
          calcLinearLeastSquaresFit(&deltaImage[startRow*(MAX_RX+1) + col],
                              &blobMap[startRow*(MAX_RX+1) + col],
                              row-startRow, MAX_RX+1, sensorParams->noiseFloor_LSB >> 1);
        }

        // If a blob is found, traverse down the col till the end of the blob is reached
        while ((row <= maxRows) && (blobMap[row*(MAX_RX+1) + col] == 1))
        {
          row++;
        }
        startRow = row;
      }
    }
  }
}

// -----------------------------------------------------------------
// Name:    removeRowShadows()
// Purpose: Remove shadows along rows
// Inputs:  deltaImage - pointer to delta image to be overwritten with
//                       its estimate without shadows along rows
//          blobMap - pointer to blob map
//          blobRows - pointer to array of flags that are set if a
//                     blob is present in the current row
//          sensorParams - sensor parameters
// Outputs: None.
// Effects: None.
// Notes:   None.
// Example: None.
// -----------------------------------------------------------------
static void removeRowShadows(int16* deltaImage,
                             int16 *blobMap,
                             uint16 *blobRows,
                             sensorParams_t* sensorParams)
{
  uint16 row;
  uint16 maxRows = sensorParams->txCount;
  uint16 maxCols = sensorParams->rxCount;

  for (row = 1; row <= maxRows; row++)
  {
    uint16 col = 1;
    uint16 startCol = 1;
    uint16 offset = row*(MAX_RX+1);

    if (blobRows[row] > 0)
    {
      while (col < maxCols+1)
      {
        // Traverse across the row till a finger blob is encountered
        while ((col <= maxCols) && (blobMap[offset + col] != 1))
        {
          col++;
        }

        if (col > 1)
        {
          // Subtract the least squares estimate of the shadow region from the delta image
          calcLinearLeastSquaresFit(&deltaImage[offset + startCol],
                              &blobMap[offset + startCol],
                              col-startCol, 1, sensorParams->noiseFloor_LSB >> 1);
        }

        // If a blob is found, traverse across the row till the end of the blob is reached
        while ((col <= maxCols) && (blobMap[offset + col] == 1))
        {
          col++;
        }
        startCol = col;
      }
    }
  }
}

// -----------------------------------------------------------------
// Name:    calcLinearLeastSquaresFit()
// Purpose: Finds the difference between input array and its linear least squares estimate.
// Inputs:  array - pointer to input array, to be replaced with output
//          mask - pointer to mask. mask = -1 for pen, -2 for LGM pixels, 0 otherwise
//          arraySize - size of array
//          stepSize - step to increment pointer to access next element of array
// Outputs: array is replaced with the difference between input array and its
//          linear least squares estimate.
// Effects: None.
// Notes:   None.
// Example: None.
// -----------------------------------------------------------------
static void calcLinearLeastSquaresFit(int16 *array,
                                      int16 *mask,
                                      uint16 arraySize,
                                      uint16 stepSize,
                                      int16 noiseFloor)
{
  if (arraySize > 1)
  {
    uint16 firstEl = 0;
    uint16 lastEl = firstEl + ((arraySize-1) * stepSize);

    // The shadow might not span the entire length of the array.
    // In such situations, the linear estimate needs to be found using only the
    // points in the shadow region of the array. Determine the shadow region by
    // traversing the array from both directions till the first pixel > noiseFloor is found,
    // skipping over the pen/LGM regions (with mask < 0).

    // Traverse the array from left to right
    while ((firstEl < lastEl) &&
          ((array[firstEl] < noiseFloor) ||
          ((array[firstEl] >= noiseFloor) && (mask[firstEl] < 0))))
    {
      firstEl += stepSize;
    }

    // Traverse the array from right to left
    while ((lastEl > firstEl) &&
          ((array[lastEl] < noiseFloor) ||
          ((array[lastEl] >= noiseFloor) && (mask[lastEl] < 0))))
    {
      lastEl -= stepSize;
    }

    if (firstEl < lastEl)
    {
      int8p8 xMean;
      int16 i, xSum = 0, ySum = 0, count = 0;
      int24p8 yMean, xTx = 0, xTy = 0;
      int16 *pArray = &array[firstEl];
      int16 *pBlob = &mask[firstEl];
      int16 n = ((lastEl - firstEl)/stepSize) + 1;
      int16 k = firstEl/stepSize;

      for (i = 0; i < n; i++)
      {
        if (*pBlob == 0)
        {
          xSum += k + i;
          ySum += *pArray;
          count++;
        }
        pArray += stepSize;
        pBlob += stepSize;
      }

      if (count > 2)
      // Correct for shadows only if we have enough points to estimate the linear fit.
      {
        xMean = (int8p8) ((int32) 256*xSum / count);
        yMean = (int24p8) ((int32) 256*ySum / count);

        pArray = &array[firstEl];
        pBlob = &mask[firstEl];
        for (i = 0; i < n; i++)
        {
          if (*pBlob == 0)
          {
            int8p8 xPrime = (int8p8)((int32)(k + i) * 256) - xMean;
            int24p8 yPrime = (int24p8)((int32)*pArray * 256) - yMean;
            xTx += (int24p8)(((int32)xPrime * xPrime) >> 8);
            xTy += (int24p8)((int32)(k + i) * yPrime);
          }
          pArray += stepSize;
          pBlob += stepSize;
        }

        if (xTx != 0)
        {
          int32 num = (int32) xTy << 4;
          int32 den = (int32) xTx >> 4;
          int8p8 slope = (int8p8) (num / den);

          // Subtract linear fit from the array
          pArray = array;
          pBlob = mask;
          for (i = 0; i < (int16)arraySize; i++)
          {
            int8p8 temp = (int8p8)((int32) i << 8) - xMean;
            int24p8 mx = (int24p8) (((int32)slope * temp) >> 8);
            int16 leastSqEstimate = (int16)(((int32)mx + yMean) >> 8);
            if (leastSqEstimate > 0)
            {
              // allow corrected delta image to go negative only at the suspected LGM pixels
              if ((*pBlob != -2) && (leastSqEstimate > *pArray) && (*pArray > 0))
              {
                *pArray = 0;
              }
              else
              {
                *pArray -= leastSqEstimate;
              }
            }
            pArray += stepSize;
            pBlob += stepSize;
          }
        }
      }
    }
  }
}

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/
/* -----------------------------------------------------------
Name: shadowRemover_configure
Purpose: Configures shadowRemover
Inputs: shadowRemoverConfig_t structure
Outputs: None.
Effects: Must be called *before* init() or reinit().
Notes: None.
----------------------------------------------------------- */
void shadowRemover_configure(shadowRemoverConfig_t *config)
{
  fingerThreshold_pct = config->shadowFingerThreshold_pct;
  penThreshold_pct = config->shadowPenThreshold_pct;
  shadowDirection = (shadowDirection_t) config->shadowDirection;
}

/* -----------------------------------------------------------
Name: shadowRemover_remove
Purpose: Removes shadow artifacts from delta image
Inputs: deltaImage, sensorParams
Outputs: None.
Effects: Shadow artifacts in the delta image are removed.
Notes: None.
----------------------------------------------------------- */
void shadowRemover_remove(int16* deltaImage,
                          sensorParams_t* sensorParams)
{
  int16 blobMap[(MAX_TX+2)*(MAX_RX+1)+1];
  uint16 blobRows[MAX_TX+2], blobCols[MAX_RX+2];
  uint16 hasTouch = FALSE;

  if (shadowDirection == shadowDirection_none)
  {
    return;
  }

  memset16_large(blobMap, 0, (MAX_TX+2)*(MAX_RX+1)+1);
  memset16_large(blobRows, 0, MAX_TX+2);
  memset16_large(blobCols, 0, MAX_RX+2);

  hasTouch = createBlobMap(deltaImage, sensorParams, blobMap, blobRows, blobCols);

  if (hasTouch)
  {
    if ((shadowDirection == shadowDirection_cols) || (shadowDirection == shadowDirection_rowsAndCols) || (shadowDirection == shadowDirection_rowsBetweenTouchesAndCols))
    {
      // Remove shadows along cols
      removeColShadows(deltaImage, blobMap, blobCols, sensorParams);
    }

    if ((shadowDirection == shadowDirection_rows) || (shadowDirection == shadowDirection_rowsAndCols) || (shadowDirection == shadowDirection_rowsBetweenTouchesAndCols))
    {

      if (shadowDirection == shadowDirection_rowsBetweenTouchesAndCols)
      {
        // Mask pixels along a row not between touches
        maskRowPixelsNotBetweenTouches(sensorParams, blobMap, blobRows);
      }
      // Remove shadows along rows
      removeRowShadows(deltaImage, blobMap, blobRows, sensorParams);
    }
  }
}

#endif // CONFIG_HAS_SHADOW_REMOVER
