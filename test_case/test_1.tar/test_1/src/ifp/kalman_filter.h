
#ifndef _KALMAN_FILTER_H_
#define _KALMAN_FILTER_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: kalman_filter.h
// Description: Header file for kalman_filter.c
//
#if CONFIG_HAS_KALMAN_FILTER && !(defined(__CHIMERA__) && (__CHIMERA_VERSION__ < 31 || !__T100X_HAS_FPU__))
void kalmanFilter_init();
void kalmanFilter_reinit();
void kalmanFilter_configure(kalmanFilterConfig_t *config);
void kalmanFilter_filterPositions(sensorParams_t *sensorParams, sensorPosition_t *sensorPosition, classification_t *classifications);
#else
static ATTR_INLINE void kalmanFilter_init() {};
static ATTR_INLINE void kalmanFilter_reinit() {};
static ATTR_INLINE void kalmanFilter_configure(ATTR_UNUSED kalmanFilterConfig_t *config) {};
static ATTR_INLINE void kalmanFilter_filterPositions(ATTR_UNUSED sensorParams_t *sensorParams, ATTR_UNUSED sensorPosition_t *sensorPosition, ATTR_UNUSED classification_t *classifications) {};
#endif //hasFPU && CONFIG_HAS_KALMAN_FILTER

#endif  //_KALMAN_FILTER_H_
