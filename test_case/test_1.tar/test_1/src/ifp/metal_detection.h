#ifndef _METAL_DETECTION_H_
#define _METAL_DETECTION_H_
//-----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//-----------------------------------------------------------------
// Filename: metal_detection.h
// Description: Header file for metal_detection.c
#include "calc2.h"
#include "ifp_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#if CONFIG_IFP_SUPPRESS_METAL_HISTO
void metal_detect_configure(metalDetectConfig_t* metalDetectConfig);
void metal_detection_init(sensorParams_t *sensorParams);
void metal_detection_detect(int16* mDeltaImage);
int16 metal_detection_getState(void);
int16 metal_detection_getEsdState(void);
#else
ATTR_INLINE void metal_detect_configure(ATTR_UNUSED metalDetectConfig_t* metalDetectConfig);
ATTR_INLINE void metal_detection_init(ATTR_UNUSED sensorParams_t *sensorParams);
ATTR_INLINE void metal_detection_detect(ATTR_UNUSED int16* mDeltaImage);
ATTR_INLINE int16 metal_detection_getState(void);
ATTR_INLINE int16 metal_detection_getEsdState(void);
#endif

#ifdef __cplusplus
};
#endif

#endif  // _METAL_DETECTION_H_

