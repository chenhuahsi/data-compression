// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: hydra_util.c
// Description: Some vector operations for ifp
//
// $Id:$

#include "ifp_config.h"

#ifndef CONFIG_INHIBIT_HYDRA
#define CONFIG_INHIBIT_HYDRA 0
#endif

//__T100X_HAS_HYDRA__
//0 - No Hydra Coprocessor present
//1 - Hydra spec revision 1.1 / Hydra 1
//2 - Hydra spec revision 2.5 / Hydra 2
//3 - Hydra spec revision 2.13 / Hydra 2
//4 - Hydra spec revision 2.50 / Hydra 2e

#if defined(__CHIMERA__) && (__T100X_HAS_HYDRA__ > 2 && CONFIG_INHIBIT_HYDRA == 0)

#if defined(BUILD_IFP_MODEL) && BUILD_IFP_MODEL == 1
#include "stdlib.h" //this if for chimcc, firwmware could provide a single-line stdlib.h with #include <silicon.h>
#else
#include <silicon.h>
#endif

#include "hydra_util.h" //this needs to be included after a file that defines uint16 and friends (stdlib.h, silicon.h, ifp.h etc)

//Sanity check
#if _HYDRA_START != 0xFE00
  #error "hydra util has been written for hydra 2 and it expects the hydra block to start at 0xFE00. Please double check the location of the HYDRA_BLOCK for your chip."
#endif

//Notice that HYDRA_BASE_ADDR is different for different versions fo HYDRA
//also it would be good to have the following register automatically defined

#define HYDRA_BASE_ADDR   (uint16 volatile*)0xFE00
#define HYDRA_STS         (uint16 volatile*)(HYDRA_BASE_ADDR + 0x1A)
#define HYDRA_CCTL        (uint16 volatile*)(HYDRA_BASE_ADDR + 0x19)
#define HYDRA_CFG0        (uint16 volatile*)(HYDRA_BASE_ADDR + 0x15)
#define HYDRA_MCFG0       (uint16 volatile*)(HYDRA_BASE_ADDR + 0x16)
#define HYDRA_CFG1        (uint16 volatile*)(HYDRA_BASE_ADDR + 0x17)
#define HYDRA_MCFG1       (uint16 volatile*)(HYDRA_BASE_ADDR + 0x18)

#define HYDRA_G00         (uint16 volatile*)(HYDRA_BASE_ADDR + 0x08)
#define HYDRA_G01         (uint16 volatile*)(HYDRA_BASE_ADDR + 0x09)
#define HYDRA_G10         (uint16 volatile*)(HYDRA_BASE_ADDR + 0x0A)
#define HYDRA_G11         (uint16 volatile*)(HYDRA_BASE_ADDR + 0x0B)

#ifndef IFP_MAX2
  #define IFP_MAX2(x,y) ((x) > (y) ? (x) : (y))
#endif

typedef enum
{
  // ITYPB 00001
  HOCA_11_15_ADD = (2 << 11),
  HOCA_11_15_ADDC = (3 << 11),
  HOCA_11_15_SUB = (4 << 11),
  HOCA_11_15_SUBB = (5 << 11),
  HOCA_11_15_SUBR = (6 << 11),
  HOCA_11_15_SUBBR = (7 << 11),
  HOCA_11_15_MUL = (8 << 11),
  HOCA_11_15_MUL32 = (9 << 11),
  HOCA_11_15_MACMM = (10 << 11),
  HOCA_11_15_CXX = (11 << 11),
  HOCA_11_15_AND = (12 << 11),
  HOCA_11_15_OR = (13 << 11),
  HOCA_11_15_XOR = (14 << 11),
  HOCA_11_15_CBXX = (15 << 11),
  HOCA_11_15_MIN = (16 << 11),
  HOCA_11_15_MAX = (17 << 11),
  HOCA_11_15_SRS32 = (18 << 11),
  HOCA_11_15_MGE = (19 << 11),
  // Reserved 10100
  // Reserved 10101
  // FTYPB 10110
  HOCA_11_15_FADD = (23 << 11),
  HOCA_11_15_FSUB = (24 << 11),
  HOCA_11_15_FSUBR = (25 << 11),
  HOCA_11_15_FMUL = (26 << 11),
  HOCA_11_15_FMACMM = (27 << 11),
  HOCA_11_15_FCXX = (28 << 11),
  // Reserved 11101
  HOCA_11_15_FMIN = (30 << 11),
  HOCA_11_15_FMAX = (31 << 11),

  HOCA_10_SRC2_VECTOR = (0 << 10),
  HOCA_10_SRC2_SCALAR = (1 << 10),

  HOCA_9_SRC2_ADDRVEC_DIR = (0 << 9),
  HOCA_9_SRC2_ADDRVEC_IDX = (1 << 9),
  HOCA_9_SRC2_ADDRSCLR_IMM = (0 << 9),
  HOCA_9_SRC2_ADDRSCLR_REG = (1 << 9),

  HOCA_7_8_SRC2VEC_STRIDE_S00 = (0 << 7),
  HOCA_7_8_SRC2VEC_STRIDE_S01 = (1 << 7),
  HOCA_7_8_SRC2VEC_STRIDE_S10 = (2 << 7),
  HOCA_7_8_SRC2VEC_STRIDE_1 = (3 << 7),

  HOCA_7_8_SRC2SCLR_IMM = (0 << 7),

  HOCA_7_8_SRC2SCLR_USE_G00 = (0 << 7),
  HOCA_7_8_SRC2SCLR_USE_G01 = (1 << 7),
  HOCA_7_8_SRC2SCLR_USE_G10 = (2 << 7),
  HOCA_7_8_SRC2SCLR_USE_G11 = (3 << 7),

  HOCA_6_SRC1_ADDRVEC_DIR = (0 << 6),
  HOCA_6_SRC1_ADDRVEC_IDX = (1 << 6),
  HOCA_6_SRC1_ADDRSCLR_IMM = (0 << 6),
  HOCA_6_SRC1_ADDRSCLR_REG = (1 << 6),

  HOCA_4_5_SRC1VEC_STRIDE_S00 = (0 << 4),
  HOCA_4_5_SRC1VEC_STRIDE_S01 = (1 << 4),
  HOCA_4_5_SRC1VEC_STRIDE_S10 = (2 << 4),
  HOCA_4_5_SRC1VEC_STRIDE_1 = (3 << 4),

  HOCA_1_3_CXX_CEQ = (0 << 1),
  HOCA_1_3_CXX_CNE = (1 << 1),
  HOCA_1_3_CXX_CGT = (2 << 1),
  HOCA_1_3_CXX_CGE = (3 << 1),
  HOCA_1_3_CXX_CLT = (4 << 1),
  HOCA_1_3_CXX_CLE = (5 << 1),
  HOCA_1_3_CXX_RNG0 = (6 << 1),
  HOCA_1_3_CXX_RNG1 = (7 << 1),

  HOCA_1_3_MAC_REG_ADDR = (0 << 1),
  HOCA_1_3_MAC_DIR_ADDR_F_I16 = (1 << 1),
  HOCA_1_3_MAC_IDX_ADDR_F_I16 = (2 << 1),
  HOCA_1_3_MAC_DIR_ADDR_I32 = (3 << 1),
  HOCA_1_3_MM_STRIDE_S00_F_I16 = (4 << 1),
  HOCA_1_3_MM_STRIDE_S01_F_I16 = (5 << 1),
  HOCA_1_3_MM_STRIDE_S10_F_I16 = (6 << 1),
  HOCA_1_3_MM_STRIDE_S10_I32 = (7 << 1),

  HOCA_3_DST_ADDRVEC_DIR = (0 << 3),
  HOCA_3_DST_ADDRVEC_IDX = (1 << 3),

  HOCA_1_2_DSTVEC_STRIDE_S00 = (0 << 1),
  HOCA_1_2_DSTVEC_STRIDE_S01 = (1 << 1),
  HOCA_1_2_DSTVEC_STRIDE_S10 = (2 << 1),
  HOCA_1_2_DSTVEC_STRIDE_1 = (3 << 1),

  HOCA_0_VECLEN_VXX0 = (0 << 0),
  HOCA_0_VECLEN_VXX1 = (1 << 0),
} HYDRA_OP_CODE_A_t;


typedef enum
{
  HOCB_11_15_ITYPB = (1 << 11),
  HOCB_11_15_FTYPB = (22 << 11),

  HOCB_7_10_LD = (0 << 7),
  HOCB_7_10_ST = (1 << 7),
  HOCB_7_10_CP = (2 << 7),
  HOCB_7_10_CPS = (3 << 7),
  HOCB_7_10_CPC = (4 << 7),
  HOCB_7_10_CPE = (5 << 7),
  HOCB_7_10_SA = (6 << 7),
  HOCB_7_10_SL = (7 << 7),
  HOCB_7_10_SB = (8 << 7),
  HOCB_7_10_VPOP = (9 << 7),
  HOCB_7_10_MINI = (10 << 7),
  HOCB_7_10_MAXI = (11 << 7),
  HOCB_7_10_MT = (12 << 7),
  HOCB_7_10_CP32 = (13 << 7),
  HOCB_7_10_CPS32 = (14 << 7),
  // 7-10: Reserved 1111

  HOCB_7_10_FMINI = (0 << 7),
  HOCB_7_10_FMAXI = (1 << 7),
  // 7-10: F Reserved 0010
  // 7-10: F Reserved 0011
  HOCB_7_10_FI2F = (4 << 7),
  HOCB_7_10_FF2I = (5 << 7),
  // 7-10: F Reserved 0110
  // 7-10: F Reserved 0111
  HOCB_7_10_FRCP = (8 << 7),
  HOCB_7_10_FSQRT = (9 << 7),
  // 7-10: F Reserved 1010
  // 7-10: F Reserved 1011
  // 7-10: F Reserved 1100
  // 7-10: F Reserved 1101
  // 7-10: F Reserved 1110
  // 7-10: F Reserved 1111

  HOCB_6_SRC1_ADDRVEC_DIR = (0 << 6),
  HOCB_6_SRC1_ADDRVEC_IDX = (1 << 6),
  HOCB_6_SRC1_ADDRSCLR_IMM = (0 << 6),
  HOCB_6_SRC1_ADDRSCLR_REG = (1 << 6),

  HOCB_4_5_SRC1VEC_STRIDE_S00 = (0 << 4),
  HOCB_4_5_SRC1VEC_STRIDE_S01 = (1 << 4),
  HOCB_4_5_SRC1VEC_STRIDE_S10 = (2 << 4),
  HOCB_4_5_SRC1VEC_STRIDE_1 = (3 << 4),

  HOCB_4_5_SRC1SCLR_IMM = (0 << 4),

  HOCB_4_5_SRC1SCLR_USE_G00 = (0 << 4),
  HOCB_4_5_SRC1SCLR_USE_G01 = (1 << 4),
  HOCB_4_5_SRC1SCLR_USE_G10 = (2 << 4),
  HOCB_4_5_SRC1SCLR_USE_G11 = (3 << 4),

  HOCB_3_DST_ADDRSCLR = (0 << 3),
  HOCB_3_DST_ADDRVEC_DIR = (0 << 3),
  HOCB_3_DST_ADDRVEC_IDX = (1 << 3),

  HOCB_1_2_DSTVEC_STRIDE_S00 = (0 << 1),
  HOCB_1_2_DSTVEC_STRIDE_S01 = (1 << 1),
  HOCB_1_2_DSTVEC_STRIDE_S10 = (2 << 1),
  HOCB_1_2_DSTVEC_STRIDE_1 = (3 << 1),

  HOCB_1_2_DSTSCLR_USE_G00 = (0 << 1),
  HOCB_1_2_DSTSCLR_USE_G01 = (1 << 1),
  HOCB_1_2_DSTSCLR_USE_G10 = (2 << 1),
  HOCB_1_2_DSTSCLR_USE_G11 = (3 << 1),

  HOCB_0_VECLEN_VXX0 = (0 << 0),
  HOCB_0_VECLEN_VXX1 = (1 << 0),

  HOCB_6_LD_ADDRSCLR_IMM = (0 << 6),
  HOCB_6_LD_ADDRSCLR_DIR = (1 << 6),

  HOCB_5_LD_TOREG = (0 << 5),
  HOCB_5_LD_FISTTOINTREG = (1 << 5),

  HOCB_0_4_LD_G00 = (0 << 0),
  HOCB_0_4_LD_G01 = (1 << 0),
  HOCB_0_4_LD_G10 = (2 << 0),
  HOCB_0_4_LD_G11 = (3 << 0),
  HOCB_0_4_LD_VL0 = (4 << 0),
  HOCB_0_4_LD_VFA0 = (5 << 0),
  HOCB_0_4_LD_VMA0 = (6 << 0),
  HOCB_0_4_LD_VL1 = (7 << 0),
  HOCB_0_4_LD_VFA1 = (8 << 0),
  HOCB_0_4_LD_VMA1 = (9 << 0),
  HOCB_0_4_LD_S00 = (10 << 0),
  HOCB_0_4_LD_S01 = (11 << 0),
  HOCB_0_4_LD_S10 = (12 << 0),
  HOCB_0_4_LD_CFG0 = (13 << 0),
  HOCB_0_4_LD_MCFG0 = (14 << 0),
  HOCB_0_4_LD_CFG1 = (15 << 0),
  HOCB_0_4_LD_MCFG1 = (16 << 0),
  HOCB_0_4_LD_CCTL = (17 << 0),
  HOCB_0_4_LD_STS = (18 << 0),

  HOCB_2_6_ST_G00 = (0 << 2),
  HOCB_2_6_ST_G01 = (1 << 2),
  HOCB_2_6_ST_G10 = (2 << 2),
  HOCB_2_6_ST_G11 = (3 << 2),
  HOCB_2_6_ST_VL0 = (4 << 2),
  HOCB_2_6_ST_VFA0 = (5 << 2),
  HOCB_2_6_ST_VMA0 = (6 << 2),
  HOCB_2_6_ST_VL1 = (7 << 2),
  HOCB_2_6_ST_VFA1 = (8 << 2),
  HOCB_2_6_ST_VMA1 = (9 << 2),
  HOCB_2_6_ST_S00 = (10 << 2),
  HOCB_2_6_ST_S01 = (11 << 2),
  HOCB_2_6_ST_S10 = (12 << 2),
  HOCB_2_6_ST_CFG0 = (13 << 2),
  HOCB_2_6_ST_MCFG0 = (14 << 2),
  HOCB_2_6_ST_CFG1 = (15 << 2),
  HOCB_2_6_ST_MCFG1 = (16 << 2),
  HOCB_2_6_ST_CCTL = (17 << 2),
  HOCB_2_6_ST_STS = (18 << 2),
} HYDRA_OP_CODE_B_t;

//=======================
// DIG2401 Initialization
//=======================
void initDig2401()
{
  //  SUPER_CTL.EN = 1;
  //  CLK_CTL.CACHE_EN = 1;
  asm const (" bset SUPER_EN ");
  asm const (" bset CLK_CTL_CACHE_EN ");
  asm (" invalidate_icache: ");
  asm const (" bclr icache_en ");
  asm const (" movn a, #$0003 ");
  asm const (" movn icache_map, a ");
  asm const (" xch y, link ");
  asm const (" clr link ");
  asm const (" clr x ");
  asm const (" movn loop_count, #1024 ");
  asm (" invalidate_loop: ");
  asm const (" progop #4, @x, #4 ");
  asm const (" floop invalidate_loop ");
  asm const (" bset icache_en ");
  //ICACHE_CTL.SPEC_EN = 1;         // Enable speculation
  asm const (" bset ICACHE_CTL BIT 3 ");
  asm const (" xch y, link ");
}

//=====================
// Hydra Initialization
//=====================
void hydra_enable(void)
{
  // Hydra clock enable
  CLK_CTL.HYDRA_EN = 1;
  // asm const (" bset CLK_CTL_HYDRA_EN ");
  CLK_CTL.HYDRA_DYN_CG_EN = 1;
  // asm const ("bset CLK_ENABLES bit 8");// dynamic clock gating
  INT_CTL10.MAP = __builtin_chimera_tid(); //thread number where the hydra call is
  // asm const ("clr reg $FF9A");// interrupt control register for Hydra
  INT_CTL10.EN = 1;
  // asm const ("bset reg $FF9A bit 9");// interrupt control register for Hydra
  HYDRA.HYDRA_INTC_OV = 1;
}

void hydra_disable(void)
{
  CLK_CTL.HYDRA_EN = 0;
  CLK_CTL.HYDRA_DYN_CG_EN = 0;
}


// Check instruction FIFO full status and if full set Chimera to sleep
inline void if_inst_fifo_full_chimera_goto_sleep()
{
  HYDRA.HYDRA_INTC_F2NF = 1;
  if (HYDRA.HYDRA_FIFO_FULL) {
    HYDRA.HYDRA_IEN_F2NF = 1;
    SLEEP;
    HYDRA.HYDRA_IEN_F2NF = 0;
    HYDRA.HYDRA_INTC_F2NF = 1;
  }
}

inline void if_inst_fifo_notempty_chimera_goto_sleep()
{
  HYDRA.HYDRA_INTC_NE2E = 1;
  if (!HYDRA.HYDRA_FIFO_EMPTY) {
    HYDRA.HYDRA_IEN_NE2E = 1;
    SLEEP;
    HYDRA.HYDRA_IEN_NE2E = 0;
    HYDRA.HYDRA_INTC_NE2E = 1;
  }
}

// Status polling and clearing
void instr_done()
{
   uint16 hydr_status;
   hydr_status = *HYDRA_STS;
    while((hydr_status & 0x8000) == 0x0000)
    {
      hydr_status = *HYDRA_STS;
    }
    *HYDRA_CCTL = *HYDRA_CCTL | 0x0400;
}

void matTimesVec_floatFloat(uint16 rows, uint16 cols, float *mat, float *vec, float *result)
{
  *HYDRA_MCFG0 = (1 << 12) | ((cols-1) << 6) | (0);  // AWM mode for matrix, A_COL_NUM, BC_COL_NUM
  HYDRA.HYDRA_VL0 = (uint16) rows;  // total number of addresses in result
  HYDRA.HYDRA_S00 = (uint16) 2;  // src2/result matrix address stride
  HYDRA.HYDRA_S01 = (uint16) 2*(cols);  // src1 matrix address stride
  HYDRA.HYDRA_ISRC2 = (uint16) vec;
  HYDRA.HYDRA_ISRC1 = (uint16) mat;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S01 |
    HOCA_1_3_MM_STRIDE_S00_F_I16 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void matTimesMat_floatFloat(uint16 rowsA, uint16 colsA, uint16 colsBC, float *matA, float *matB, float *matC)
{ // A * B = C
  *HYDRA_MCFG0 = (1 << 12) | ((colsA-1) << 6) | (colsBC-1);  // AWM mode for matrix, A_COL_NUM, BC_COL_NUM
  HYDRA.HYDRA_VL0 = (uint16) rowsA * colsBC;  // total number of addresses in result
  HYDRA.HYDRA_S00 = (uint16) 2*(colsBC);  // src2/result matrix address stride
  HYDRA.HYDRA_S01 = (uint16) 2*(colsA);  // src1 matrix address stride
  HYDRA.HYDRA_ISRC2 = (uint16) matB;
  HYDRA.HYDRA_ISRC1 = (uint16) matA;
  HYDRA.HYDRA_IDEST = (uint16) matC;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S01 |
    HOCA_1_3_MM_STRIDE_S00_F_I16 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void vecTimesVec_floatFloat(uint16 len, float *vec1, float *vec2, float *result)
{ // scalar produc v1 * v2
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VL0 = (uint16) len;  // vec len
  HYDRA.HYDRA_S00 = (uint16) 2;  // src1/src2 matrix address stride
  HYDRA.HYDRA_ISRC2 = (uint16) vec2;
  HYDRA.HYDRA_ISRC1 = (uint16) vec1;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_1_3_MAC_DIR_ADDR_F_I16 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void vecTimesVec_floatFloatDoubleStride(uint16 len, uint16 stride1, uint16 stride2, float *vec1, float *vec2, float *result)
{ // scalar produc v1 * v2
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VL0 = (uint16) len;  // vec len
  HYDRA.HYDRA_S00 = (uint16) stride1;  // src0 matrix address stride
  HYDRA.HYDRA_S01 = (uint16) stride2;  // src2 matrix address stride
  HYDRA.HYDRA_ISRC2 = (uint16) vec2;
  HYDRA.HYDRA_ISRC1 = (uint16) vec1;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S01 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_1_3_MAC_DIR_ADDR_F_I16 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void vecTimesVec_floatFloatIndexed(uint16 len, uint16* index, float *vec1, float *vec2, float *result)
{
  // scalar produc v1 * v2
  *HYDRA_MCFG0 = (0 << 12) | (0) | (0);
  HYDRA.HYDRA_VL0 = (uint16) len;  // vec len
  HYDRA.HYDRA_S10 = (uint16) index;  // src1/src2 indexes (to skip seconde element, 0 1 4 5 6 7 ...)
  HYDRA.HYDRA_ISRC2 = (uint16) vec2;
  HYDRA.HYDRA_ISRC1 = (uint16) vec1;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_IDX | HOCA_7_8_SRC2VEC_STRIDE_S10 |
    HOCA_6_SRC1_ADDRVEC_IDX | HOCA_4_5_SRC1VEC_STRIDE_S10 |
    HOCA_1_3_MAC_DIR_ADDR_F_I16 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void vecTimesVec_floatFloatDoubleIndexed(uint16 len, uint16* index1, uint16* index2, float *vec1, float *vec2, float *result)
{
  // scalar produc v1 * v2
  *HYDRA_MCFG0 = (0 << 12) | (0) | (0);
  HYDRA.HYDRA_VL0 = (uint16) len;  // vec len
  HYDRA.HYDRA_S10 = (uint16) index2;  // src2 indexes (to skip seconde element, 0 1 4 5 6 7 ...)
  HYDRA.HYDRA_S01 = (uint16) index1;  // src1 indexes (to skip seconde element, 0 1 4 5 6 7 ...)
  HYDRA.HYDRA_ISRC2 = (uint16) vec2;
  HYDRA.HYDRA_ISRC1 = (uint16) vec1;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_IDX | HOCA_7_8_SRC2VEC_STRIDE_S10 |
    HOCA_6_SRC1_ADDRVEC_IDX | HOCA_4_5_SRC1VEC_STRIDE_S01 |
    HOCA_1_3_MAC_DIR_ADDR_F_I16 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void vecTimesVec_floatFloatMasked(uint16 len, uint16* mask, float *vec1, float *vec2, float *result)
{
  // scalar produc v1 * v2
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VMA0 = (uint16) mask; //bitwise mask (to skip second element mask in binary 010000...)
  HYDRA.HYDRA_VM_EN0 = 1;
  HYDRA.HYDRA_ICODE = (uint16)2080; //bin2dec('00001 0000 010 0000') = 2080 = 0x820 //LOAD VECTOR MASK 0
  //HYDRA.HYDRA_ICODE = (uint16)2081; //bin2dec('00001 0000 010 0001') = 2081 = 0x821 //LOAD VECTOR MASK 1
  if_inst_fifo_full_chimera_goto_sleep();

  *HYDRA_MCFG0 = (0 << 12) | (0) | (0);
  HYDRA.HYDRA_VL0 = (uint16) len;  // vel len
  HYDRA.HYDRA_S00 = (uint16) 2;  // src1/src2 address stride
  HYDRA.HYDRA_ISRC2 = (uint16) vec2;
  HYDRA.HYDRA_ISRC1 = (uint16) vec1;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_1_3_MAC_REG_ADDR |
    HOCA_0_VECLEN_VXX0;
  //instr_done();

  if_inst_fifo_notempty_chimera_goto_sleep();
   HYDRA.HYDRA_VM_EN0 = 0;
  *result = *(volatile float*)HYDRA_G00;
}

void multiply_floatFloat(uint16 len, float *vec1, float *vec2, float *result)
{ //element-wise multiplication
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VL0 = (uint16) len;  // vec len
  HYDRA.HYDRA_S00 = (uint16) 2;  // src1/src2/result matrix address stride
  HYDRA.HYDRA_ISRC2 = (uint16) vec1;
  HYDRA.HYDRA_ISRC1 = (uint16) vec2;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMUL |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_3_DST_ADDRVEC_DIR | HOCA_1_2_DSTVEC_STRIDE_S00 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void multiply_floatFloatMasked(uint16 len, uint16 *mask, float *vec1, float *vec2, float *result)
{ //element-wise multiplication
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VMA0 = (uint16) mask;
  HYDRA.HYDRA_VM_EN0 = 1;
  HYDRA.HYDRA_ICODE = (uint16)2080; //bin2dec('00001 0000 010 0000') = 2080 = 0x820 //LOAD VECTOR MASK 0
  //HYDRA.HYDRA_ICODE = (uint16)2081; //bin2dec('00001 0000 010 0001') = 2081 = 0x821 //LOAD VECTOR MASK 1
  if_inst_fifo_full_chimera_goto_sleep();

  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VL0 = (uint16) len;  // vel len
  HYDRA.HYDRA_S00 = (uint16) 2;  // src1/src2/result matrix address stride
  HYDRA.HYDRA_ISRC2 = (uint16) vec1;
  HYDRA.HYDRA_ISRC1 = (uint16) vec2;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMUL |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_3_DST_ADDRVEC_DIR | HOCA_1_2_DSTVEC_STRIDE_S00 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();

  if_inst_fifo_notempty_chimera_goto_sleep();
  HYDRA.HYDRA_VM_EN0 = 0;
}

void multiply_floatFloatIndexed(uint16 len, uint16 *indexSrc, uint16 *indexDest, float *vec1, float *vec2, float *result)
{ //element-wise multiplication
  //uint16 index[10] = {0,1,4,5,6,7,8,9,10,11}; //jumps of 16 bits for src
  //uint16 indexDest[5] = {0,4,6,8,10}; //jumps of 32 bits for destination
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VL0 = (uint16) len;  // vec len
  HYDRA.HYDRA_S00 = (uint16) indexSrc;  // src1/src2 index
  HYDRA.HYDRA_S01 = (uint16) indexDest;  // result index
  HYDRA.HYDRA_ISRC2 = (uint16) vec1;
  HYDRA.HYDRA_ISRC1 = (uint16) vec2;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_FMUL |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_IDX | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_IDX | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_3_DST_ADDRVEC_IDX | HOCA_1_2_DSTVEC_STRIDE_S01 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

//void subtractFit(int16 *row, int16 *fit, int16 *res, uint16 len)
//{
//   uint16 i;
//   for (i=0; i<len; i++)
//   {
//     res[i] = row[i] - fit[i];
//   }
//}

void subtractFit(int16 *row, int16 *fit, int16 *res, uint16 *flags, uint16 len)
{
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VFA0 = (uint16) flags; //unfortunately this is not optional at this stage
  HYDRA.HYDRA_VL0 = (uint16) len;  // total number of elements in result
  HYDRA.HYDRA_S00 = (uint16) 1;  // src1/src2/result address stride
  HYDRA.HYDRA_ISRC2 = (uint16) fit;
  HYDRA.HYDRA_ISRC1 = (uint16) row;
  HYDRA.HYDRA_IDEST = (uint16) res; //row
  HYDRA.HYDRA_ICODE = HOCA_11_15_SUB |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_3_DST_ADDRVEC_DIR | HOCA_1_2_DSTVEC_STRIDE_S00 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void subtractFitDelta(int16 *row, uint16 rowLen, int16 *fit, uint16 *flags)
{
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VFA0 = (uint16) flags; //unfortunately this is not optional at this stage
  HYDRA.HYDRA_VL0 = (uint16) rowLen;  // total number of elements in result
  HYDRA.HYDRA_S00 = (uint16) 1;  // src1/src2/result address stride
  HYDRA.HYDRA_ISRC2 = (uint16) fit;
  HYDRA.HYDRA_ISRC1 = (uint16) row;
  HYDRA.HYDRA_IDEST = (uint16) row; //row
  HYDRA.HYDRA_ICODE = HOCA_11_15_SUB |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_3_DST_ADDRVEC_DIR | HOCA_1_2_DSTVEC_STRIDE_S00 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void subtractFitRaw(uint16 *row, uint16 rowLen, int16 *fit, uint16 *flags, uint16 flipSign)
{
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VFA0 = (uint16) flags; //unfortunately this is not optional at this stage
  HYDRA.HYDRA_VL0 = (uint16) rowLen;  // total number of elements in result
  HYDRA.HYDRA_S00 = (uint16) 1;  // src1/src2/result address stride
  HYDRA.HYDRA_ISRC2 = (uint16) fit;
  HYDRA.HYDRA_ISRC1 = (uint16) row;
  HYDRA.HYDRA_IDEST = (uint16) row; //row
  HYDRA.HYDRA_ICODE = (HOCA_11_15_SUB >> flipSign) |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_3_DST_ADDRVEC_DIR | HOCA_1_2_DSTVEC_STRIDE_S00 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void subtractFitIndexed(int16 *row, int16 *fit, int16 *res, uint16 *index, uint16 *flags, uint16 len)
{
  //uint16 index[10] = {0,1,2,3,4,5,6,7,8,9};
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VFA0 = (uint16) flags; //unfortunately this is not optional at this stage
  HYDRA.HYDRA_VL0 = (uint16) len;  // total number of elements in result
  HYDRA.HYDRA_S00 = (uint16) index;  // src1/src2/result address stride
  HYDRA.HYDRA_ISRC2 = (uint16) fit;
  HYDRA.HYDRA_ISRC1 = (uint16) row;
  HYDRA.HYDRA_IDEST = (uint16) res; //row
  HYDRA.HYDRA_ICODE = HOCA_11_15_SUB |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_IDX | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_IDX | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_3_DST_ADDRVEC_IDX | HOCA_1_2_DSTVEC_STRIDE_S00 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void subtractFitMasked(int16 *row, int16 *fit, int16 *res, uint16 *mask, uint16 *flags, uint16 len)
{
  //uint16 mask[10] = {0,0,0,0,0,0,0,0,0,0};
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VFA0 = (uint16) flags; //unfortunately this is not optional at this stage
  HYDRA.HYDRA_VMA0 = (uint16) mask;
  HYDRA.HYDRA_VM_EN0 = 1;
  HYDRA.HYDRA_ICODE = (uint16)2080; //bin2dec('00001 0000 010 0000') = 2080 = 0x820 //LOAD VECTOR MASK 0
  //HYDRA.HYDRA_ICODE = (uint16)2081; //bin2dec('00001 0000 010 0001') = 2081 = 0x821 //LOAD VECTOR MASK 1
  if_inst_fifo_full_chimera_goto_sleep();

  HYDRA.HYDRA_VL0 = (uint16) len;  // total number of elements in result
  HYDRA.HYDRA_S00 = (uint16) 1;  // src1/src2/result address stride
  HYDRA.HYDRA_ISRC2 = (uint16) fit;
  HYDRA.HYDRA_ISRC1 = (uint16) row;
  HYDRA.HYDRA_IDEST = (uint16) res; //row
  HYDRA.HYDRA_ICODE = HOCA_11_15_SUB |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_3_DST_ADDRVEC_DIR | HOCA_1_2_DSTVEC_STRIDE_S00 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();

  if_inst_fifo_notempty_chimera_goto_sleep();
  HYDRA.HYDRA_VM_EN0 = 0;
}

void addFit(int16 *row, int16 *fit, int16 *res, uint16 *flags, uint16 len)
{
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VFA0 = (uint16) flags; //unfortunately this is not optional at this stage
  HYDRA.HYDRA_VL0 = (uint16) len;  // total number of elements in result
  HYDRA.HYDRA_S00 = (uint16) 1;  // src1/src2/result address stride
  HYDRA.HYDRA_ISRC2 = (uint16) fit;
  HYDRA.HYDRA_ISRC1 = (uint16) row;
  HYDRA.HYDRA_IDEST = (uint16) res; //row
  HYDRA.HYDRA_ICODE = HOCA_11_15_ADD |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_3_DST_ADDRVEC_DIR | HOCA_1_2_DSTVEC_STRIDE_S00 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void hydra_memset16(void *dst, int16 val, uint16 n)
{
  uint16 *pointer = (uint16 *) dst;
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VL0 = (uint16)(n>>1);
  HYDRA.HYDRA_S00 = (uint16)(2);  // destination stride value
  HYDRA.HYDRA_ISRC2 = (uint16)(val);
  HYDRA.HYDRA_ISRC1 = (uint16)(val);
  HYDRA.HYDRA_IDEST = (uint16)pointer;
  HYDRA.HYDRA_ICODE = (1 << 11) | (14 << 7) | (0 << 4) | (0 << 1) | (0);  // 32-bit immediate copy, dest stride is S00, use VL0

  if (n & 1)
  {
    n--;
    *(pointer+n) = (uint16)val;
  }
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void vecTimesVec_int16Int16(uint16 len, int16 *vec1, int16 *vec2, int32 *result)
{ // scalar produc v1 * v2
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VL0 = (uint16) len;  // vec len
  HYDRA.HYDRA_S00 = (uint16) 1;  // src1/src2 matrix address stride
  HYDRA.HYDRA_ISRC2 = (uint16) vec2;
  HYDRA.HYDRA_ISRC1 = (uint16) vec1;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_MACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
    HOCA_1_3_MAC_DIR_ADDR_I32 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void vecTimesVec_int16Int16Stride1(uint16 len, int16 *vec1, int16 *vec2, uint16 stride1, int32 *result)
{ // scalar produc v1 * v2
  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VL0 = (uint16) len;  // vec len
  HYDRA.HYDRA_S00 = (uint16) 1;  // src1 address stride
  HYDRA.HYDRA_S01 = (uint16) stride1;  //src2 address stride
  HYDRA.HYDRA_ISRC2 = (uint16) vec2;
  HYDRA.HYDRA_ISRC1 = (uint16) vec1;
  HYDRA.HYDRA_IDEST = (uint16) result;
  HYDRA.HYDRA_ICODE = HOCA_11_15_MACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S01 |
    HOCA_1_3_MAC_DIR_ADDR_I32 |
    HOCA_0_VECLEN_VXX0;
  //instr_done();
  if_inst_fifo_notempty_chimera_goto_sleep();
}

void subtractBaseline(uint16 *rawImage, uint16 *baseline, int16 *deltaImage, uint16 rxCount, uint16 txCount)
{
  uint16 flags[1 + ( (MAX_RX * MAX_TX - 1) >> 4)];
  HYDRA.HYDRA_VFA0 = (uint16) flags;

  #if MAX_RX <= 64 //this is done just to save some cycles for small screens

    deltaImage += MAX_RX + 2; //accounts for 0 padding
    *HYDRA_MCFG0 = (1 << 12) | ((rxCount-1) << 6) | (rxCount-1);  // AWM mode for matrix, A_COL_NUM, BC_COL_NUM
    HYDRA.HYDRA_VL0 = (uint16) txCount * rxCount;  // total number of addresses in result
    HYDRA.HYDRA_S00 = (uint16) (MAX_RX);  // baseline and raw matrix address stride
    HYDRA.HYDRA_S01 = (uint16) (MAX_RX + 1);  // delta address stride
    if (CONFIG_IMAGE_DELTA_IS_POSITIVE)
    {
      HYDRA.HYDRA_ISRC2 = (uint16) baseline;
      HYDRA.HYDRA_ISRC1 = (uint16) rawImage;
    }
    else
    {
      HYDRA.HYDRA_ISRC2 = (uint16) rawImage;
      HYDRA.HYDRA_ISRC1 = (uint16) baseline;
    }
    HYDRA.HYDRA_IDEST = (uint16) deltaImage;
    HYDRA.HYDRA_ICODE = HOCA_11_15_SUB |
      HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
      HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
      HOCA_3_DST_ADDRVEC_DIR | HOCA_1_2_DSTVEC_STRIDE_S01 |
      HOCA_0_VECLEN_VXX0;

  #else //this would work also for small screens with rxCount <= 64, but we didn't want the overhead

    int16 *deltaImagePtr;
    uint16 start, length;

    for (start = 0; start < rxCount; start += 64)
    {

      length = rxCount - start;
      if (length > 64)
      {
        length = 64;
      }

      deltaImagePtr = deltaImage + start + MAX_RX + 2; //accounts for 0 padding
      *HYDRA_MCFG0 = (1 << 12) | ((length-1) << 6) | (length-1);  // AWM mode for matrix, A_COL_NUM, BC_COL_NUM
      HYDRA.HYDRA_VL0 = (uint16) txCount * length;  // total number of addresses in result
      HYDRA.HYDRA_S00 = (uint16) (MAX_RX);  // baseline and raw matrix address stride
      HYDRA.HYDRA_S01 = (uint16) (MAX_RX + 1);  // delta address stride
      if (CONFIG_IMAGE_DELTA_IS_POSITIVE)
      {
        HYDRA.HYDRA_ISRC2 = (uint16) (baseline + start);
        HYDRA.HYDRA_ISRC1 = (uint16) (rawImage + start);
      }
      else
      {
        HYDRA.HYDRA_ISRC2 = (uint16) (rawImage + start);
        HYDRA.HYDRA_ISRC1 = (uint16) (baseline + start);
      }
      HYDRA.HYDRA_IDEST = (uint16) deltaImagePtr;
      HYDRA.HYDRA_ICODE = HOCA_11_15_SUB |
        HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
        HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
        HOCA_3_DST_ADDRVEC_DIR | HOCA_1_2_DSTVEC_STRIDE_S01 |
        HOCA_0_VECLEN_VXX0;

      if_inst_fifo_full_chimera_goto_sleep();
  }

  #endif //MAX_RX <= 64

  if_inst_fifo_notempty_chimera_goto_sleep();

}

/* -----------------------------------------------------------------
Name: projectDeltaImage
Purpose: Compute the projection of the delta image along rows and columns
Inputs: sensor params, delta image
Outputs: projection to TX axis, projection to RX axis
Notes:
----------------------------------------------------------------- */
void projectDeltaImage(uint16 rxCount, uint16 txCount, int16 *deltaImage, int32 *projTX, int32 *projRX)
{
  uint16 r, c;
  int16 *pSource;
  int16 unit_vector[IFP_MAX2(MAX_RX , MAX_TX)];

  hydra_memset16((uint16 *)unit_vector, 1, IFP_MAX2(MAX_RX , MAX_TX));
  hydra_memset16((uint16 *)projTX, 0, MAX_TX * sizeof(*projTX) / sizeof(uint16));
  hydra_memset16((uint16 *)projRX, 0, MAX_RX * sizeof(*projRX) / sizeof(uint16));

  *HYDRA_MCFG0 = 0;
  HYDRA.HYDRA_VL0 = (uint16) rxCount;  // vec len
  HYDRA.HYDRA_S00 = (uint16) 1;  // src1/src2 matrix address stride
  HYDRA.HYDRA_ISRC2 = (uint16) unit_vector;

  pSource = deltaImage + MAX_RX + 2;
  for (r = 0; r < txCount; r++)
  {
    if_inst_fifo_full_chimera_goto_sleep();
    HYDRA.HYDRA_ISRC1 = (uint16) pSource;
    HYDRA.HYDRA_IDEST = (uint16) projTX;
    HYDRA.HYDRA_ICODE = HOCA_11_15_MACMM |
      HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
      HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S00 |
      HOCA_1_3_MAC_DIR_ADDR_I32 |
      HOCA_0_VECLEN_VXX0;

    projTX++;
    pSource += MAX_RX + 1;
  }
  if_inst_fifo_notempty_chimera_goto_sleep();

  HYDRA.HYDRA_VL0 = (uint16) txCount;  // vec len
  HYDRA.HYDRA_S01 = (uint16) 1;  // src1 address stride
  HYDRA.HYDRA_S00 = (uint16) MAX_RX + 1;  //src2 address stride
  HYDRA.HYDRA_ISRC1 = (uint16) unit_vector;

  pSource = deltaImage + MAX_RX + 2;

  for (c = 0; c < rxCount; c++)
  {
    if_inst_fifo_full_chimera_goto_sleep();
    HYDRA.HYDRA_ISRC2 = (uint16) pSource;
    HYDRA.HYDRA_IDEST = (uint16) projRX;
    HYDRA.HYDRA_ICODE = HOCA_11_15_MACMM |
    HOCA_10_SRC2_VECTOR | HOCA_9_SRC2_ADDRVEC_DIR | HOCA_7_8_SRC2VEC_STRIDE_S00 |
    HOCA_6_SRC1_ADDRVEC_DIR | HOCA_4_5_SRC1VEC_STRIDE_S01 |
    HOCA_1_3_MAC_DIR_ADDR_I32 |
    HOCA_0_VECLEN_VXX0;

    projRX++;
    pSource++;
  }

  if_inst_fifo_notempty_chimera_goto_sleep();
}

#endif
