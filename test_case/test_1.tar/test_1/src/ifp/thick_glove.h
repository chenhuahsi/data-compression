#ifndef _THICK_GLOVE_H_
#define _THICK_GLOVE_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2014  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: thick_glove.h
// Description: Process measured delta profile to extract single finger information if thick glove has been detected.
//  $Id:

#include "ifp_common.h"
#include "classifier.h"

#if CONFIG_HAS_THICK_GLOVE

typedef enum {
  no_thick_glove,
  thick_glove_possible,
  thick_glove_detected
} thick_glove_t;

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: void thick_glove_init()
Purpose: Initialize the module.
Inputs:
Outputs:
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void thick_glove_init(void);


/* -----------------------------------------------------------------
Name: void thick_glove_reinit()
Purpose: Re-initialize the thick glove module
Inputs:
Outputs:
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void thick_glove_reinit(void);

/* -----------------------------------------------------------------
 * Name: void thick_glove_configure()
 * Purpose: Configure the module.
 * Inputs: config parameters
 * Outputs: None
 * Effects: None.
 * Notes:
 * Example: None.
 * ----------------------------------------------------------------- */
void thick_glove_configure(singleFingerConfig_t* sfConfig);

/* -----------------------------------------------------------------
Name: is_thick_glove_present()
Purpose: Find out if thick glove is present or not; returns true even if
         there is just a possibility of thick glove
Inputs: None
Outputs: bool
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */

void get_thick_glove_present(int16* data_present);
/* -----------------------------------------------------------------
Name: doThickGloveProcessing()
Purpose: process classifications, trans and hybrid deltas to detect thick glove presence
         if there is thick glove, determine a thick glove position using hybrid delta profiles
Inputs: classifications, profiles
Outputs: up to 2 thick finger positions ((0,0) if no finger) ;
         returns # of single fingers detected if thick glove present << 1 | fresh data flag;
         fresh data + 0 fingers indicates single finger lift
         returns 0 otherwise
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void doThickGloveProcessing(sensorParams_t *sensorParams, int16 * deltaX, int16 * deltaY,
             classification_t *classifications, sensorPosition_t *SFSensorPositions, int16 *thickGloveSFResult);
#else
  static ATTR_INLINE void thick_glove_init(void) {};
  static ATTR_INLINE void thick_glove_reinit(void) {};
  static ATTR_INLINE void thick_glove_configure(singleFingerConfig_t* sfConfig ATTR_UNUSED) {};
  static ATTR_INLINE void doThickGloveProcessing(sensorParams_t *sensorParams ATTR_UNUSED, int16 * deltaX ATTR_UNUSED, int16 * deltaY ATTR_UNUSED,
             classification_t *classifications ATTR_UNUSED, sensorPosition_t *SFSensorPositions ATTR_UNUSED, int16 *thickGloveSFResult ATTR_UNUSED) {};
  static ATTR_INLINE void get_thick_glove_present(int16* data_present ATTR_UNUSED) {};
#endif
#endif
