/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Description: Utility functions for clump projections
   $Id: segmenter.c,v 1.10.2.7.2.20 2013/01/31 22:48:25 jjordan Exp $
----------------------------------------------------------------- */

#ifndef _CLUMP_PROJECTOR_H
#define _CLUMP_PROJECTOR_H

#include "ifp_common.h"

uint16 clumpProjector_getProjectionUV(clumps_t *clumps, uint16 clumpId, int16 blobId, int16 *deltaImage, uint16 *projU, uint16 *projV
#if CONFIG_HAS_CUSTOM_SPLITTER
, sensorParams_t *sensorParams
#endif
);
uint16 clumpProjector_getProjectionXY(clumps_t *clumps, uint16 clumpId, int16 blobId, int16 *deltaImage, uint16 *projX, uint16 *projY);
uint16 clumpProjector_getBlobMax(clumps_t *clumps, uint16 clumpId, int16 blobId, int16 *deltaImage);
void clumpProjector_rotateCoordinate(uint16 r, uint16 c, uint16 axis, uint16 *u, uint16 *v);
void clumpProjector_unrotateCoordinate(uint8p8 u, uint8p8 v, uint16 axis, uint8p8 *r, uint8p8 *c);

#endif
