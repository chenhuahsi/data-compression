/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

  $Id$
----------------------------------------------------------------- */

#include "ifp_common.h"

#if CONFIG_HAS_TDDI_AMP_MOISTURE

#include "ifp_bit_manipulation.h"
#include "ifp_string.h"
#include "moisture_filter_AMP.h"
#if defined(__CHIMERA__) && (__CHIMERA_VERSION__ >= 31 && __T100X_HAS_FPU__)
#include "math.h"
#endif
#ifdef WIN32
#include "math.h"
#endif

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

#define abs(x) ((x) < 0 ? -(x) : (x))
#define min(x,y) ((x) > (y) ? (y) : (x))
#define dist_sq(r0,c0,r1,c1) (abs(r0-r1)*abs(r0-r1)+abs(c0-c1)*abs(c0-c1))
#define get_offset(r,c) ((r)*(MAX_RX+1)+(c))
#define WATERMARK_MAX_IMAGES_SIZE ((MAX_TX+2)*(MAX_RX+1)+1)
#define WATERMARK_MAX_TRAVERSE_CNT (MAX_TX + MAX_TX + MAX_RX + MAX_RX - 2)
#define WATERMARK_MAX_TRAVERSE_DEBUG 10

// - module types -
// Eight directions in the 3x3 block around a pixel
typedef enum
{
  waterMarkDirection_0D,
  waterMarkDirection_45D,
  waterMarkDirection_90D,
  waterMarkDirection_135D,
  waterMarkDirection_180D,
  waterMarkDirection_225D,
  waterMarkDirection_270D,
  waterMarkDirection_315D,
  waterMarkDirection_unknown
} WaterMarkDirection_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/
  static uint16 moistureState;
  static uint16 mositureHysteresisCounter;
  static uint16 moistureConcaveThreshold_pct;
  static uint16 moisturePalmAreaThreshold_pct;
  static uint16 moistureDeescalation_frames;
  static uint16 minPeakSplitContrastThreshold;
  static uint16 minMoistureClumpFlatRatio;
  static uint16 minMoistureClumpEnergyRatio;

  // Debug variables
  static uint16 moistureAmpAreaDebug;
  static uint16 moistureAmpPerimeterDebug;

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/
#if CONFIG_HAS_TDDI_AMP_MOISTURE_ENHANCEMENT
  ATTR_INLINE static uint16 waterMark_nextOffset(uint16 currentOffset, WaterMarkDirection_t direction);
  ATTR_INLINE static WaterMarkDirection_t waterMark_getCurrentDirection(uint16 currentOffset, uint16 sourceOffset);
  ATTR_INLINE int16 waterMark_calcCurrentDeltaValue(int16 *deltaImage, uint16 currentOffset, WaterMarkDirection_t direction, uint16 forwardFlag);
  ATTR_INLINE static uint16 waterMark_appendNewNodeToTracingList(int16 *deltaImage, uint16 firstOffset, uint16 newOffset, uint16 *tracingOffsetList);
  static uint16 waterMark_calcExpendArray(int16 *deltaImage, uint16 *labelImage, uint16 maxPeakOffset, uint16 *expendSource);
  static uint16 waterMark_traverseAlongBestRouting(int16 *deltaImage, uint16 maxPeakOffset, uint16 minPeakOffset, uint16 *expendSource, int16 *bestRouting);
  static uint16 detectInClumps_waterMark(sensorParams_t *sensorParams, int16 *deltaImage, uint16 *labelImage, clumpInfo_t *info, uint16 secondaryPeakOffset, uint16 area);
#endif
  ATTR_INLINE static uint16 erode(int16 *imgPtr);
  ATTR_INLINE static uint16 isLocalMax(int16 *deltaPtr);
  static uint16 detectInClumps(ATTR_UNUSED sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/
#if CONFIG_HAS_TDDI_AMP_MOISTURE_ENHANCEMENT
/* -----------------------------------------------------------
Name: waterMark_nextPosition
Purpose: Get next position with given direciton
Inputs: currentOffset, direction
Outputs: valid
Effects: None.
Notes: This is a CPU circles sensitive function, optimize the runing circles as much as possiable.
       For less CPU circles, the sanity check of nextOffset did not run internally, 
       so users have to do sanity check by it-self when needed.
----------------------------------------------------------- */
ATTR_INLINE static uint16 waterMark_nextOffset(uint16 currentOffset, WaterMarkDirection_t direction)
{
  uint16 nextOffset = 0;
  switch (direction)
  {
    case waterMarkDirection_0D:
      nextOffset = currentOffset - MAX_RX - 1;
      break;
    case waterMarkDirection_45D:
      nextOffset = currentOffset - MAX_RX;
      break;
    case waterMarkDirection_90D:
      nextOffset = currentOffset + 1;
      break;
    case waterMarkDirection_135D:
      nextOffset = currentOffset + MAX_RX + 2;
      break;
    case waterMarkDirection_180D:
      nextOffset = currentOffset + MAX_RX + 1;
      break;
    case waterMarkDirection_225D:
      nextOffset = currentOffset + MAX_RX;
      break;
    case waterMarkDirection_270D:
      nextOffset = currentOffset - 1;
      break;
    case waterMarkDirection_315D:
      nextOffset = currentOffset - MAX_RX - 2;
      break;
    default:
      break;
  }
  return nextOffset;
}

/* -----------------------------------------------------------
Name: waterMark_getCurrentDirection
Purpose:
Inputs:
Outputs: current direction
Effects: None.
Notes:
----------------------------------------------------------- */
ATTR_INLINE static WaterMarkDirection_t waterMark_getCurrentDirection(uint16 currentOffset, uint16 sourceOffset)
{
  WaterMarkDirection_t direction = waterMarkDirection_unknown;

  if (currentOffset == (sourceOffset - MAX_RX - 1))
  {
    direction = waterMarkDirection_0D;
  }
  else if (currentOffset == (sourceOffset - MAX_RX))
  {
    direction = waterMarkDirection_45D;
  }
  else if (currentOffset == (sourceOffset + 1))
  {
    direction = waterMarkDirection_90D;
  }
  else if (currentOffset == (sourceOffset + MAX_RX + 2))
  {
    direction = waterMarkDirection_135D;
  }
  else if (currentOffset == (sourceOffset + MAX_RX + 1))
  {
    direction = waterMarkDirection_180D;
  }
  else if (currentOffset == (sourceOffset + MAX_RX))
  {
    direction = waterMarkDirection_225D;
  }
  else if (currentOffset == (sourceOffset - 1))
  {
    direction = waterMarkDirection_270D;
  }
  else if (currentOffset == (sourceOffset - MAX_RX - 2))
  {
    direction = waterMarkDirection_315D;
  }

  return direction;
}

/* -----------------------------------------------------------
Name: waterMark_calcCurrentDeltaValue
Purpose: Get the appropriate delta value depends on the poisiotn of the source offset
Inputs: deltaImage, currentOffset, direction, forwardFlag
Outputs: deltaValue
Effects: None.
Notes: Refer to JIRA FWTDDI-1058.
----------------------------------------------------------- */
ATTR_INLINE int16 waterMark_calcCurrentDeltaValue(int16 *deltaImage, uint16 currentOffset, WaterMarkDirection_t direction, uint16 forwardFlag)
{
  int16 deltaValue = 0;

  if (forwardFlag)
  {
    switch (direction)
    {
      case waterMarkDirection_0D:
      case waterMarkDirection_180D:
      case waterMarkDirection_90D:
      case waterMarkDirection_270D:
        deltaValue = (deltaImage[currentOffset] > 0) ? deltaImage[currentOffset] : 0;
        break;
      case waterMarkDirection_45D:
        // Add 1/8 current
        deltaValue = (deltaImage[currentOffset] > 0) ? (deltaImage[currentOffset] >> 3):0;
        // Add 3/8 left
        deltaValue += (deltaImage[currentOffset - 1] > 0) ? ((deltaImage[currentOffset - 1] * 3) >> 3):0;
        // Add 1/8 left_down
        deltaValue += (deltaImage[currentOffset + MAX_RX] > 0) ? (deltaImage[currentOffset + MAX_RX] >> 3):0;
        // Add 3/8 down
        deltaValue += (deltaImage[currentOffset + MAX_RX + 1] > 0) ? ((deltaImage[currentOffset + MAX_RX + 1] * 3) >> 3):0;
        break;
      case waterMarkDirection_135D:
        // Add 1/8 current
        deltaValue = (deltaImage[currentOffset] > 0) ? (deltaImage[currentOffset] >> 3):0;
        // Add 3/8 left
        deltaValue += (deltaImage[currentOffset - 1] > 0) ? ((deltaImage[currentOffset - 1] * 3) >> 3):0;
        // Add 1/8 left_up
        deltaValue += (deltaImage[currentOffset - MAX_RX - 2] > 0) ? (deltaImage[currentOffset - MAX_RX - 2] >> 3):0;
        // Add 3/8 up
        deltaValue += (deltaImage[currentOffset - MAX_RX - 1] > 0) ? ((deltaImage[currentOffset - MAX_RX - 1] * 3) >> 3):0;
        break;
      case waterMarkDirection_225D:
        // Add 1/8 current
        deltaValue = (deltaImage[currentOffset] > 0) ? (deltaImage[currentOffset] >> 3):0;
        // Add 3/8 up
        deltaValue += (deltaImage[currentOffset - MAX_RX - 1] > 0) ? ((deltaImage[currentOffset - MAX_RX - 1] * 3) >> 3):0;
        // Add 1/8 right_up
        deltaValue += (deltaImage[currentOffset - MAX_RX] > 0) ? (deltaImage[currentOffset - MAX_RX] >> 3):0;
        // Add 3/8 left
        deltaValue += (deltaImage[currentOffset + 1] > 0) ? ((deltaImage[currentOffset + 1] * 3) >> 3):0;
        break;
      case waterMarkDirection_315D:
        // Add 1/8 current
        deltaValue = (deltaImage[currentOffset] > 0) ? (deltaImage[currentOffset] >> 3):0;
        // Add 3/8 right
        deltaValue += (deltaImage[currentOffset + 1] > 0) ? ((deltaImage[currentOffset + 1] * 3) >> 3):0;
        // Add 1/8 right_down
        deltaValue += (deltaImage[currentOffset + MAX_RX + 2] > 0) ? (deltaImage[currentOffset + MAX_RX + 2] >> 3):0;
        // Add 3/8 down
        deltaValue += (deltaImage[currentOffset + MAX_RX + 1] > 0) ? ((deltaImage[currentOffset + MAX_RX + 1] * 3) >> 3):0;
        break;
      default:
        break;
    }
  }
  else
  {
    switch (direction)
    {
      case waterMarkDirection_45D:
      case waterMarkDirection_135D:
      case waterMarkDirection_225D:
      case waterMarkDirection_315D:
        // Add 3/4 current
        deltaValue = (deltaImage[currentOffset] > 0) ? (deltaImage[currentOffset] - (deltaImage[currentOffset] >> 2)):0;
        // Add 1/16 up
        deltaValue += (deltaImage[currentOffset - MAX_RX - 1] > 0) ? (deltaImage[currentOffset - MAX_RX - 1] >> 4):0;
        // Add 1/16 left
        deltaValue += (deltaImage[currentOffset - 1] > 0) ? (deltaImage[currentOffset - 1] >> 4):0;
        // Add 1/16 right
        deltaValue += (deltaImage[currentOffset + 1] > 0) ? (deltaImage[currentOffset + 1] >> 4):0;
        // Add 1/16 down
        deltaValue += (deltaImage[currentOffset + MAX_RX + 1] > 0) ? (deltaImage[currentOffset + MAX_RX + 1] >> 4):0;
        break;
      default:
        deltaValue = (deltaImage[currentOffset] > 0) ? deltaImage[currentOffset] : 0;
        break;
    }
  }

  return deltaValue;
}

/* -----------------------------------------------------------
Name: waterMark_appendNewNodeToTracingList
Purpose:
Inputs: deltaImage, firstListPoint, newOffset, tracingOffsetList
Outputs: new firstListPoint
Effects: None.
Notes: This is a CPU circles sensitive function, optimize the runing circles as much as possiable.
----------------------------------------------------------- */
ATTR_INLINE static uint16 waterMark_appendNewNodeToTracingList(int16 *deltaImage, uint16 firstOffset, uint16 newOffset, uint16 *tracingOffsetList)
{
  const uint16 maxEdgePixels = WATERMARK_MAX_TRAVERSE_CNT; // CPU circle saving by using const variable
  uint16 edgePixel, newFirstOffset = firstOffset;
  int16 newAmplitude = deltaImage[newOffset];
  // When the amplitdue on newOffset above all the pixels on the edge,
  // update the first-offset, point the new offset to the old first-offset.
  if (firstOffset == 0 || newAmplitude > deltaImage[firstOffset])
  {
    // Update the first-node
    newFirstOffset = newOffset;
    // Link the new-node to the previous first-node.
    tracingOffsetList[newOffset] = firstOffset;
  }
  else
  {
    // On normal conditions, add the new offset to appropriate position of the link-table
    uint16 lastOffset, nextOffset;
    lastOffset = firstOffset;
    for(edgePixel = 0; edgePixel < maxEdgePixels; edgePixel++)
    {
      nextOffset = tracingOffsetList[lastOffset];
      // When the new-node's amplitdue is higher than the next-node
      if (nextOffset == 0 || newAmplitude > deltaImage[nextOffset])
      {
        // Link previous-node to new-node
        tracingOffsetList[lastOffset] = newOffset;
        // Link the new-node to next-node
        tracingOffsetList[newOffset] = nextOffset;
        break;
      }
      // Update to next-node
      lastOffset = nextOffset;
    }
  }
  return newFirstOffset;
}

/* -----------------------------------------------------------
Name: waterMark_calcExpendArray
Purpose: Caculate the expend array from clump maxPeak 
Inputs: current, target
Outputs: dist, the last endpoint which has longest distance from max_peak
Effects: None.
Notes: None.
----------------------------------------------------------- */
static uint16 waterMark_calcExpendArray(int16 *deltaImage, uint16 *labelImage, uint16 maxPeakOffset, uint16 *expendSource)
{
  uint16 firstOffset, validClumpLabel, newOffset, pixelsCnt, currentMaxOffset;
  uint8 maxExpendSteps = 0;
  uint16 endPointOffset = maxPeakOffset;
  WaterMarkDirection_t nearbyDirection;
  const uint16 maxPixels = WATERMARK_MAX_IMAGES_SIZE;
  // In order to save CPU usage, spend more RAM for fast link-table caculation 
  uint16 tracingOffsetList[WATERMARK_MAX_IMAGES_SIZE];
  uint8 expendSteps[WATERMARK_MAX_IMAGES_SIZE];
  // Initialize the data
  memset16((uint16 *)expendSource, 0, WATERMARK_MAX_IMAGES_SIZE);
  memset16((uint16 *)tracingOffsetList, 0, WATERMARK_MAX_IMAGES_SIZE);
  memset16((uint16 *)expendSteps, 0, (WATERMARK_MAX_IMAGES_SIZE/2));
  firstOffset = maxPeakOffset;
  validClumpLabel = labelImage[maxPeakOffset];
  expendSource[maxPeakOffset] = 0xFFFF;
  // From the max peak, find the edge peak with highest amplitude, add the neibor pixels to the list, 
  // recode orignal edga offset as expend source-offset, continue to search unitl whole deltaImage traversed.
  for (pixelsCnt = 0; pixelsCnt < maxPixels; pixelsCnt++)
  {
    // Sanity check the current edge pixels, break out when no pixels anymore
    if (firstOffset == 0)
    {
      break;
    }
    // Pop-out the offset with maximum amplitude and find the pixles nearby
    // Set the firstOffset to nextOffset to remove the first node from the link-table
    // Since the tracingOffsetList was initialize with 0, so it will point to 0 by default.
    // In other words, the circle will break out when no new node was found below.
    currentMaxOffset = firstOffset;
    firstOffset = tracingOffsetList[currentMaxOffset];
    // Find the eight pixels nearby, add the valid one
    for (nearbyDirection = waterMarkDirection_0D; nearbyDirection < waterMarkDirection_unknown; nearbyDirection++)
    {
      newOffset = waterMark_nextOffset(currentMaxOffset, nearbyDirection);
      // Assert the newOffset is unsed and valid
      if(expendSource[newOffset] == 0 && labelImage[newOffset] == validClumpLabel)
      {
        // Record where the newOffset expend from
        expendSource[newOffset] = currentMaxOffset;
        // Record the distance and max steps offset
        expendSteps[newOffset] = expendSteps[currentMaxOffset] + 1;
        if (expendSteps[newOffset] > maxExpendSteps)
        {
          endPointOffset = newOffset;
          maxExpendSteps = expendSteps[newOffset];
        }
        // Append the newOffset to the list table from highest amplitude to lowest amplitude
        firstOffset = waterMark_appendNewNodeToTracingList(deltaImage, firstOffset, newOffset, tracingOffsetList);
      }
    }
  }
  return endPointOffset;
}

/* -----------------------------------------------------------
Name: waterMark_traverseAlongRouting
Purpose: Find the best routing from one of the minPeak to maxPeak
         caculate the contrast between lowest amplitude and minPeak.
Inputs: *deltaImage, *maxPeakLocation, *minPeakLocation, *expendSource
Outputs: contrast.
Effects: None.
Notes: None.
----------------------------------------------------------- */
static int16 bestRoutingDebug[WATERMARK_MAX_TRAVERSE_DEBUG];
static WaterMarkDirection_t bestRoutingDirectionDebug[WATERMARK_MAX_TRAVERSE_DEBUG];
static uint16 waterMark_traverseAlongBestRouting(int16 *deltaImage, uint16 maxPeakOffset, uint16 minPeakOffset, uint16 *expendSource, int16 *bestRouting)
{
  uint16 contrast = 0;
  uint16 length, currentOffset, sourceOffset;
  int16 frontDeltaValue, forwardDeltaValue, minDelta, localPeakDeltaValue = 0, minWaterMarkDeltaValue = 0;
  WaterMarkDirection_t currentDirection;
  // Find the deltaValue on minPeak position
  currentOffset = minPeakOffset;
  // Find the min deltaValue on whole traverse
  memset16((int16 *)bestRouting, 0, WATERMARK_MAX_TRAVERSE_CNT);
  for (length = 0; length < WATERMARK_MAX_TRAVERSE_CNT; length++)
  {
    // Break out when reach the maxPeak or invalid value
    if (currentOffset == maxPeakOffset || currentOffset == 0)
    {
      break;
    }
    sourceOffset = expendSource[currentOffset];
    // Find the direction by currentOffset and sourceOffset
    currentDirection = waterMark_getCurrentDirection(currentOffset, sourceOffset);
    frontDeltaValue = waterMark_calcCurrentDeltaValue(deltaImage, currentOffset, currentDirection, 0);
    forwardDeltaValue = waterMark_calcCurrentDeltaValue(deltaImage, currentOffset, currentDirection, 1);
    minDelta = min(frontDeltaValue, forwardDeltaValue);
    bestRouting[length] = minDelta;
    // Record the deltaValue on minPeak position
    if (length == 0)
    {
      localPeakDeltaValue = frontDeltaValue;
      minWaterMarkDeltaValue = minDelta;
    }
    else
    {
      minWaterMarkDeltaValue = min(minDelta, minWaterMarkDeltaValue);
    }
    currentOffset = sourceOffset;
  }
  // Cacualte the contrast between minor waterMark to min peak.
  contrast = (localPeakDeltaValue == 0) ? 0 : (256 - (((int32) minWaterMarkDeltaValue << 8) / localPeakDeltaValue));
  // Debug code, no effect
  if (contrast > minPeakSplitContrastThreshold)
  {
    memset16((int16 *)bestRoutingDebug, 0, WATERMARK_MAX_TRAVERSE_DEBUG);
    currentOffset = minPeakOffset;
    for (length = 0; length < WATERMARK_MAX_TRAVERSE_DEBUG; length++)
    {
      // Break out when reach the maxPeak or invalid value
      if (currentOffset == maxPeakOffset || currentOffset == 0)
      {
        break;
      }
      sourceOffset = expendSource[currentOffset];
      bestRoutingDebug[length] = bestRouting[length];
      bestRoutingDirectionDebug[length] = waterMark_getCurrentDirection(currentOffset, sourceOffset);
      currentOffset = sourceOffset;
    }
  }
  return contrast;
}

/* -----------------------------------------------------------
Name: detectInClumps_waterMark
Purpose: Detects moisture in clumps with "water Mark" methods.
Inputs: sensorParams, delta image, clumps
Outputs: True if moisture is detected in any clump
Effects: info->preventSplit is set when moisture detected.
Notes: None.
----------------------------------------------------------- */
static uint10p6 contrastDebug;
static int16 deltaExpendImageDebug[WATERMARK_MAX_TRAVERSE_DEBUG];
static uint16 waterMark_clumpFlatRatioDebug, waterMark_clumpEnergyRatioDebug;
static uint16 detectInClumps_waterMark(sensorParams_t *sensorParams, int16 *deltaImage, uint16 *labelImage, clumpInfo_t *info, uint16 secondaryPeakOffset, uint16 area)
{
  uint16 secondPeakValid = FALSE;
  uint16 endPointOffset = 0, maxPeakOffset = 0;
  uint16 expendSource[WATERMARK_MAX_IMAGES_SIZE];
  // caculate the expend array for whole clump on two conditions:
  // 1: secondary peak exists
  // 2: clump area larger than palm threshold
  if (secondaryPeakOffset != 0 || area > moisturePalmAreaThreshold_pct)
  {
    // Traverse all other peaks and do sanity check
    maxPeakOffset = get_offset(info->peakLocation.row, info->peakLocation.col);
    // Caculate the expend array
    endPointOffset = waterMark_calcExpendArray(deltaImage, labelImage, maxPeakOffset, expendSource);
  }
  //////////////////////////////////////////////////////
  // Step1 : Ghost finger supression - By validate secondary peak.
  if (secondaryPeakOffset != 0)
  {
    uint16 contrast;
    uint16 bestRouting[WATERMARK_MAX_TRAVERSE_CNT];
    // Travese along the best routing on expense array, calculate the linearity of the peak amplitude changes by compare the minimal amplitude and the candidate minPeak amplitude. When the contrast exceed the threshold, mark the minPeak as the valid one.
    // Different to the multiple dry fingers, when one finger touch on moisture panel, the amplitude changes in the route of the minPeaks should be in linear.
    contrast = waterMark_traverseAlongBestRouting(deltaImage, maxPeakOffset, secondaryPeakOffset, expendSource, bestRouting);
    // valid separated peak found, no need to continue
    if (contrast > minPeakSplitContrastThreshold)
    {
      contrastDebug = contrast;
      secondPeakValid = TRUE;
    }
  }
  // Prevent split when valid secondary peak exist
  info->preventSplit = (secondPeakValid==FALSE) ? TRUE:FALSE;
  //////////////////////////////////////////////////////
  // Step2 : mositure or palm separation when area larger than moisturePalmAreaThreshold_pct
  info->suspectMoisture = 0;
  if (area > moisturePalmAreaThreshold_pct && secondPeakValid == FALSE)
  {
    uint16 length;
    int16 currAmplitude, lastAmplitude = 0;
    int16 bestRouting[WATERMARK_MAX_TRAVERSE_CNT];
    int16 negativeEnergy = 0, positiveEnergy = 0, maxPeakAmplitdue = 0, validRouteLength = 0;
    memset16((uint16 *)deltaExpendImageDebug, 0, WATERMARK_MAX_TRAVERSE_DEBUG);
    // Find the bestRouting from far-edge to peak
    waterMark_traverseAlongBestRouting(deltaImage, maxPeakOffset, endPointOffset, expendSource, bestRouting);
    // Find the best routing's differential array, skip the first two to prvent edge effect
    for (length = 0; length < WATERMARK_MAX_TRAVERSE_CNT; length++)
    {
      currAmplitude = bestRouting[length];
      // Break out when reach the maxPeak or invalid value
      if (currAmplitude == 0)
      {
        break;
      }
      // Remove the edge pixles
      if (length > 2)
      {
        if ((currAmplitude - lastAmplitude) < 0)
        {
          negativeEnergy += currAmplitude - lastAmplitude;
        }
        else
        {
          positiveEnergy += currAmplitude - lastAmplitude;
        }
        // Log to debug array
        if (validRouteLength < WATERMARK_MAX_TRAVERSE_DEBUG)
        {
          deltaExpendImageDebug[validRouteLength] = currAmplitude - lastAmplitude;
        }
        validRouteLength++;
      }
      lastAmplitude = currAmplitude;
    }
    maxPeakAmplitdue = lastAmplitude;
    // Separate the mositure/palm
    if (validRouteLength > 4)
    {
      float ratio;
      uint16 waterMark_clumpFlatRatio, waterMark_clumpEnergyRatio;
      // A: In ordrer to distingush flat palm and mositure, should compare the positive energy on valid expend route.
      // Due to physical characterristics, the moisture clump must have lower ADC on far-end and higer ADC on near-end of the figner touches. That leads the mositure clump's delta-expend-route has much higher accumulate positive values than the flat palms.
      // We should also conside the effect of the route length and high/low ground mass.
      maxPeakAmplitdue = (maxPeakAmplitdue > 0) ? maxPeakAmplitdue : 0;
      ratio = (float)(positiveEnergy) / validRouteLength * sensorParams->cSat_LSB / maxPeakAmplitdue;
      waterMark_clumpFlatRatio = (ratio > 0) ? ((uint16)(ratio*10)) : 0;
      // B: In order to distingush coin/large-copper-slug with drift amplitude, should compare ratio of the positive energy and negetive engergy.
      // Due to physical characterristics, the amplitde of the moisture clump will mostly continues increase from far-end to near-end of the finger postion. On delta-expend-route, that represent the accumulate positive values much larger than negetive one.
      // On normal palm or coin or large-copper-slug, the values will continues up and down.
      negativeEnergy = (negativeEnergy < 0) ? (-negativeEnergy) : 1;
      ratio = (float)positiveEnergy/(negativeEnergy + positiveEnergy);
      waterMark_clumpEnergyRatio = (ratio > 0) ? ((uint16)(ratio*100)) : 0;
      // Caculate the mostiure/palm result base on A&B.
      if (waterMark_clumpFlatRatio > minMoistureClumpFlatRatio && waterMark_clumpEnergyRatio > minMoistureClumpEnergyRatio)
      {
        info->suspectMoisture = 1;
      }
      // Debug
      waterMark_clumpFlatRatioDebug = waterMark_clumpFlatRatio;
      waterMark_clumpEnergyRatioDebug = waterMark_clumpEnergyRatio;
    }
  }
  return secondPeakValid;
}
#endif

/* -----------------------------------------------------------
Name: erode
Purpose: Checks if any pixel in the 3x3 block around a pixel equals zero.
Inputs:  pointer to a pixel in label image
Outputs: True if any of the 8 neighboring pixels equals 0
         False otherwise.
Effects: None.
Notes: None.
----------------------------------------------------------- */
ATTR_INLINE static uint16 erode(int16 *imgPtr)
{
  imgPtr -= MAX_RX+2;

  return (imgPtr[0]          == 0) ||
         (imgPtr[1]          == 0) ||
         (imgPtr[2]          == 0) ||
         (imgPtr[MAX_RX+1]   == 0) ||
         (imgPtr[MAX_RX+3]   == 0) ||
         (imgPtr[2*MAX_RX+2] == 0) ||
         (imgPtr[2*MAX_RX+3] == 0) ||
         (imgPtr[2*MAX_RX+4] == 0);
}

/* -----------------------------------------------------------
Name: isLocalMax
Purpose: Determines whether the pixel is a local maximum
Inputs: pointer to a pixel in the delta image
Outputs: true/false
Effects: None.
Notes: Relative to the center pixel, the comparisons are:
              <= <= <=
              <=    <
              <  <  <
       The mix of strict and non-strict comparisons is to
       deal with flat surfaces. It will prevent every pixel
       from being labeled a local maximum, but allow at least
       one bottom-right corner pixel to be labeled a maximum.

       This routine does no bounds checking, so you cannot
       pass in pixels that are part of the padding around the
       deltaImage.
Example: None.
----------------------------------------------------------- */
ATTR_INLINE static uint16 isLocalMax(int16 *deltaPtr)
{
  int16 v;
  v = *deltaPtr;

  deltaPtr -= MAX_RX+2;

  return (deltaPtr[0]          <= v) && \
         (deltaPtr[1]          <= v) && \
         (deltaPtr[2]          <= v) && \
         (deltaPtr[MAX_RX+1]   <= v) && \
         (deltaPtr[MAX_RX+3]   <  v) && \
         (deltaPtr[2*MAX_RX+2] <  v) && \
         (deltaPtr[2*MAX_RX+3] <  v) && \
         (deltaPtr[2*MAX_RX+4] <  v);
}

/* -----------------------------------------------------------
Name: detectInClumps
Purpose: Detects moisture in clumps
Inputs: sensorParams, delta image, clumps
Outputs: True if moisture is detected in any clump
Effects: None.
Notes: None.
----------------------------------------------------------- */
static uint16 detectInClumps(ATTR_UNUSED sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps)
{
  uint16 clumpIdx, moistureDetected = FALSE;
  clumpInfo_t *info;
  uint16 peakSplitValid = FALSE;
  for (clumpIdx = 0; clumpIdx < MAX_OBJECTS; clumpIdx++)
  {
    info = &clumps->info[clumpIdx];
    if (info->peakCount > 0)
    {
      uint16 area = 0;
      uint16 perimeter = 0;
      uint16 secondaryPeakOffset = 0;
      uint16 maxPeakOffset = get_offset(info->peakLocation.row, info->peakLocation.col);
      pixelIndex_t p = info->firstPixel;
      while (p.row != 0)
      {
        uint16 r = p.row;
        uint16 c = p.col;
        uint16 offset = get_offset(r, c);
        area++;
        // Estimate the clump perimeter by counting the number of 8C eroded pixels
        if (erode(&(clumps->labelImage[offset])))
        {
          perimeter++;
        }
        if (isLocalMax(&deltaImage[offset]))
        {
          if (offset != maxPeakOffset && deltaImage[offset] > (deltaImage[maxPeakOffset] >> 2))
          {
            if (deltaImage[offset] > deltaImage[secondaryPeakOffset])
            {
              secondaryPeakOffset = offset;
            }
          }
        }
        p = clumps->listImage[offset];
      }
      #if CONFIG_HAS_TDDI_AMP_MOISTURE_ENHANCEMENT
        peakSplitValid = detectInClumps_waterMark(sensorParams, deltaImage, clumps->labelImage, info, secondaryPeakOffset, area);
      #endif
      // if area = perimeter, the entire clump was eroded
      if (peakSplitValid == FALSE && area > perimeter)
      {
        uint16 areaCalcThreshold;
        // Debug usage
        moistureAmpAreaDebug = area;
        moistureAmpPerimeterDebug = perimeter;
        if (area > moisturePalmAreaThreshold_pct * 3)
        {
          continue;
        }
        // Moisture clumps are usually concave in shape. For concave clumps,
        // (area/(perimeter^2)) < (0.48/(4*pi)) => (area * 26.16) < (perimeter^2)
        // 4*pi*256 = 3217, moistureConcaveThreshold_pct=65536/256/0.48
        areaCalcThreshold = (uint16)(((uint32) area * 3217 * moistureConcaveThreshold_pct) >> 16);
        if ((areaCalcThreshold < (perimeter * perimeter)) && ((areaCalcThreshold + areaCalcThreshold / 2) > (perimeter * perimeter)))
        {
          moistureDetected = TRUE;
        }
      }
    }
  }
  return moistureDetected;
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/
/* -----------------------------------------------------------
Name: moistureFilterAMP_configure()
Purpose: Configure algorithm parameters
Inputs: None
Outputs: None
----------------------------------------------------------- */
void moistureFilterAMP_configure(ampMoistureConfig_t *config)
{
  moistureConcaveThreshold_pct = (config->moistureConcaveThreshold > 0) ? 65536/config->moistureConcaveThreshold : 712;
  moisturePalmAreaThreshold_pct = config->palmArea_px;
}

/* -----------------------------------------------------------
Name: moistureFilterAMP_init()
Purpose: Reset state on startup
Inputs: None
Outputs: None
----------------------------------------------------------- */
void moistureFilterAMP_init()
{
  moistureState = FALSE;
  mositureHysteresisCounter = 0;
  moistureDeescalation_frames = 120;
  minPeakSplitContrastThreshold = 90;
  minMoistureClumpFlatRatio = 100;
  minMoistureClumpEnergyRatio = 96;

  moistureAmpAreaDebug = 0;
  moistureAmpPerimeterDebug = 0;
}

/* -----------------------------------------------------------
Name: moistureFilterAMP_reinit()
Purpose: Reset state on reset
Inputs: None
Outputs: None
----------------------------------------------------------- */
void moistureFilterAMP_reinit()
{
  moistureFilterAMP_init();
}

/* -----------------------------------------------------------
Name: moistureFilterAMP_detect
Purpose: Detects moisture in clumps
Inputs: sensorParams, delta image, clumps
Outputs: True if moisture is detected in any clump
         False otherwise.
Notes: None.
----------------------------------------------------------- */
uint16 moistureFilterAMP_detect(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps)
{
  uint16 moistureDetected = detectInClumps(sensorParams, deltaImage, clumps);
  // moisture is not detected on earlier frame, detect new mositure clump
  if (moistureState == FALSE)
  {
    if (moistureDetected)
    {
      moistureState = TRUE;
      mositureHysteresisCounter = 0;
    }
  }
  else // if moisture was detected in an earlier frame, check if moisture clump still exists in current frame
  {
    if (moistureDetected)
    {
      mositureHysteresisCounter = 0;
    }
    else
    {
      mositureHysteresisCounter++;
      if (mositureHysteresisCounter >= moistureDeescalation_frames) // number of deescalation frames
      {
        moistureState = FALSE;
        mositureHysteresisCounter = moistureDeescalation_frames;
      }
    }
  }
  return moistureState;
}

/* -----------------------------------------------------------
Name: moistureFilterAMP_filter
Purpose: Post-processes clumps containing moisture to avoid ghost fingers
Inputs: clumps
Outputs: None.
Effects: None.
Notes: None.
----------------------------------------------------------- */
void moistureFilterAMP_filter(clumps_t *clumps)
{
  uint16 i;
  for (i = 0; i < MAX_OBJECTS; i++)
  {
    if (clumps->info[i].peakCount > 0)
    {
      int16 peakRow = clumps->info[i].peakLocation.row;
      int16 peakCol = clumps->info[i].peakLocation.col;
      pixelIndex_t currentNode = clumps->info[i].firstPixel;
      pixelIndex_t nextNode = clumps->listImage[get_offset(currentNode.row, currentNode.col)];
      // Delete pixels that are farther than L1 distance of 4 from clump peak
      while (nextNode.row != 0)
      {
        int16 r = nextNode.row;
        int16 c = nextNode.col;
        uint16 offset = get_offset(r, c);
        if (dist_sq(peakRow, peakCol, r, c) > 20)
        {
          // Delete nextNode from list image
          clumps->listImage[get_offset(currentNode.row, currentNode.col)] = clumps->listImage[offset];
          clumps->labelImage[offset] = 0;
        }
        else
        {
          currentNode = nextNode;
        }
        nextNode = clumps->listImage[offset];
      }
      // Check if L1 distance between first pixel and clump peak > 4
      currentNode = clumps->info[i].firstPixel;
      if (dist_sq(peakRow, peakCol, (int16)currentNode.row, (int16)currentNode.col) > 20)
      {
        uint16 offset = get_offset(currentNode.row, currentNode.col);
        clumps->info[i].firstPixel = clumps->listImage[offset];
        clumps->labelImage[offset] = 0;
      }
    }
  }
}

#endif   // CONFIG_HAS_TDDI_AMP_MOISTURE
