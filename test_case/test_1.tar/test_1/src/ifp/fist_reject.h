#ifndef _FIST_REJECT_H
#define _FIST_REJECT_H
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------

#if CONFIG_HAS_FIST_REJECT
void fistReject_init(void);
void fistReject_reinit(void);
void fistReject_configure(fistRejectConfig_t *config);
fistFeatures_t fistReject_getFistFeatures(void);
void fistReject_detect(int16 *deltaXProfile, int16 *deltaYProfile, clumps_t *clumps, trackedObject_t *trackedObjects,
    classification_t *classifications, sensorParams_t *sensorParams);
#else
static fistFeatures_t fistFeatures;
static ATTR_INLINE void fistReject_init(void) {};
static ATTR_INLINE void fistReject_reinit(void) {};
static ATTR_INLINE void fistReject_configure(ATTR_UNUSED fistRejectConfig_t *config) {};
static ATTR_INLINE fistFeatures_t fistReject_getFistFeatures(void) { return fistFeatures; };
static ATTR_INLINE void fistReject_detect(ATTR_UNUSED int16 *deltaXProfile, ATTR_UNUSED int16 *deltaYProfile,
    ATTR_UNUSED clumps_t *clumps, ATTR_UNUSED trackedObject_t *trackedObjects,
    ATTR_UNUSED classification_t *classifications, ATTR_UNUSED sensorParams_t *sensorParams) {};
#endif

#endif // _fist_reject_H
