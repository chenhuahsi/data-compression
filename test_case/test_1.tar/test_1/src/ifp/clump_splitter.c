/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Description: Splits clumps in two when their profiles show two peaks
   $Id$
----------------------------------------------------------------- */

/* Clump Splitter Algorithm Overview --------------------------------

   The segmentation algorithm in segmenter.c splits objects mostly by
   looking for edges. If two objects are very close together, no
   obvious edge will be present. The clump splitter runs after the
   segmenter to find concavities that indicate two fingers were pushed
   really close together.

   The algorithm is to compute 1D projections of each clump, currently
   only in the X- and Y-directions. It looks for two peaks separated
   by a valley, and if the lower of the two peaks has enough relative
   prominence (take the height of the lower peak above the lowest
   valley between the peaks, divide by the height of the higher peak),
   then split the clump along the lowest valley between the peaks.

   Since relative prominence starts to fail for low-amplitude clumps,
   there are two additional checks: clumps are rejected if the peak
   projected pixel amplitude is too small, and secondary peaks are
   rejected if they're too small a fraction of the highest peak.

   Notes:

     The pixels on the split line are labeled empty and removed from
     the clump pixel lists.

     This algorithm doesn't try to split if more than 3 positive clumps
     are found. This is to prevent the algorithm from wasting CPU
     cycles when fingers aren't likely to be pinching. This can be
     changed in clumpSplitter_split().

     This algorithm only splits each clump at most once to prevent it
     from making spurious splits due to noise. Don't try to use this
     algorithm as-is for recognizing 4-finger swipes, as it's not
     designed for that.

------------------------------------------------------------------*/

#include "ifp_common.h"

#if !CONFIG_HAS_LINEAR_SWIPE_SPLITTER

#include "clump_splitter.h"
#include "clump_projector.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/
// Adjust this to control the prominence required for a split. The
// default value of 26 is about 10% relative prominence, which means
// that the second finger peak must rise out of the valley by at least
// 10% of the highest peak's height.
static uint8p8 minProminence;

/* =================================================================
   MODULE TYPES
==================================================================*/
struct prominence_t
{
  uint8p8 prominence;
  int16 split;
};

/* =================================================================
   MODULE VARIABLES
==================================================================*/

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/
static void splitClump(clumps_t *clumps, uint16 clumpIdx, uint16 splitIdx,
                       splitAxis_t axis, uint16 splitPos);
static void segmentProfile(uint16 *profile, int16 profileLen,
                           uint16 *peakVal, struct prominence_t *prominence);
static void isocelesValley(uint16* proj, uint16 index, uint8p8 *x, uint24p8 *y);
static struct prominence_t findProminence(uint16 *profile, uint16 peakVal,
                                          uint16 peakPos, int16 inc, int16 finish);
/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: splitClump
Purpose: Splits a clump into two clumps
Inputs: clumps structure,
        clumpIdx - the clump to split
        splitIdx - the split index to use
        axis - the angle to split on
        splitVal - the location of the split
Outputs: none
Effects: none
Notes: 1) Pixels with row/column equal to minR/minC will be left
       unassigned to any clump.
       2) The posPeakCounts are both set to 1, even though there
       may be more than one positive peak in the clumps. This
       could potentially confuse the classifier if it tries to
       use that information.
----------------------------------------------------------- */
static void splitClump(clumps_t *clumps, uint16 clumpIdx, uint16 splitIdx,
                       splitAxis_t axis, uint16 splitPos)
{
  clumpInfo_t *info;
  info = &clumps->info[clumpIdx];
  info->splitCount = 1;
  info->splitAxis = (uint16) axis;
  info->firstSplit = splitIdx;
  clumps->splits[splitIdx] = splitPos;
}

/* -----------------------------------------------------------
Name: segmentProfile
Purpose: Finds the index for where to split a profile into
         two peaks
Inputs: profile
        profileLen - length of the profile
Outputs: peakVal - amplitude of the peak pixel in the profile
         prominence - the prominence and split location.
                      returns prominence = 0 and split = -1 if
                      no secondary peaks are found.
Effects: none
Notes: If prominence to the left and right of the highest peak
       are equal, this chooses the secondary peak on the left
       (that is, the one with the lower index).
----------------------------------------------------------- */
static void segmentProfile(uint16 *profile, int16 profileLen,
                           uint16 *peakVal, struct prominence_t *prominence)
{
  uint16 pk = profile[0];
  uint16 pkPos = 0;

  {
    int16 i;
    uint16 *profPtr = profile;
    for (i = 0; i < profileLen; i++)
    {
      if (*profPtr > pk)
      {
        pk = *profPtr;
        pkPos = i;
      }
      profPtr++;
    }
  }

  {
    struct prominence_t promL, promR;
    promL = findProminence(profile, pk, pkPos, -1, -1);
    promR = findProminence(profile, pk, pkPos,  1, profileLen);

    if (promL.prominence > promR.prominence)
    {
      *prominence = promL;
    }
    else
    {
      *prominence = promR;
    }
  }

  if (prominence->prominence < minProminence)
  {
    prominence->prominence = 0;
    prominence->split = -1;
  }
  *peakVal = pk;
}

/* -----------------------------------------------------------
Name: isocelesValley
Purpose: For a given valley location, interpolate the tip of an
         isoceles triangle whose base is set by the higher
         adjacent pixel. This is used to refine the valley
         location.
Inputs: projection
        nearest index to valley (local minimum)
Outputs: interpolated valley position
Effects: none
Notes: none
----------------------------------------------------------- */
static void isocelesValley(uint16* proj, uint16 index, uint8p8 *x, uint24p8 *y)
{
    int16 a = proj[index-1] - proj[index];
    int16 b = proj[index+1] - proj[index];
    int16 slope = b < a ? a : b;
    int8p8 dx = (((int32) proj[index-1] - proj[index+1]) << 7) / slope; // correction (frac of pixel) relative to index
    uint24p8 dy = (int32) slope * (256 + dx);  // correction relative to proj[index-1]
    if (dy > ((uint24p8) proj[index - 1] << 8))
    {
      *y = 0;
    }
    else
    {
      *y = ((uint24p8) proj[index - 1] << 8) - dy;  // 16p0 * 8p8 = 24p8
    }
    *x = (index << 8) + dx;
}

/* -----------------------------------------------------------
Name: findProminence
Purpose: Finds the most prominent secondary peak in a range.
Inputs: profile
        peakVal - amplitude of the peak
        peakPos - position of the peak
        inc - increment (-1 or +1)
        finish - index past end of profile
                 (either -1 or profile length)
Outputs: prominence - relative prominence of secondary peak
                      and location of split. On failure,
                      returns split at -1 and prominence of 0.
Effects: none
Notes: 1) This scans in either direction from the peak looking
       for secondary peaks. It is intended to be called twice,
       once with a positive increment and once with a negative
       increment.
       2) This rejects any secondary peaks less than half the
       amplitude of the highest peak. That prevents us from
       reporting very prominent but low-amplitude peaks caused
       by noise.
----------------------------------------------------------- */
static struct prominence_t findProminence(uint16 *profile, uint16 peakVal,
                                          uint16 peakPos, int16 inc,
                                          int16 finish)
{
  int16 valleyPos = -1;
  uint16 peak = peakVal / 2;  // ignore peaks less than half as tall as the original peak
  peakPos += inc;

  // Aggressively limit scope to save direct RAM.
  {
    int16 minSoFarPos = -1;
    uint16 minSoFar = peakVal;  // find any valleys below the peak
    uint16 valley = peakVal;
    uint16 *profPtr = &profile[peakPos];
    int16 i;
    for (i = peakPos; i != finish; i += inc, profPtr += inc)
    {
      uint16 v = *profPtr;
      if (v <= minSoFar)
      {
        minSoFar = v;
        minSoFarPos = i;
      }
      else if (v > peak)
      {
        peak = v;
        if (minSoFar < valley)
        {
          valley = minSoFar;
          valleyPos = minSoFarPos;
        }
      }
    }
  }

  {
    struct prominence_t prominence;
    if (valleyPos >= 0)
    {
      uint8p8 refinedValleyPos;
      uint24p8 refinedValleyVal;
      isocelesValley(profile, (uint16) valleyPos, &refinedValleyPos, &refinedValleyVal);
      prominence.prominence = (uint8p8) (((((uint32) peak) << 8) - refinedValleyVal)/peak);
      prominence.split = refinedValleyPos;
    }
    else
    {
      prominence.prominence = 0;
      prominence.split = valleyPos;
    }
    return prominence;
  }
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: clumpSplitter_split
Purpose: Splits clumps in two if their profiles show peaks
Inputs: delta image, saturation level, clumps structure
Outputs: modified clumps structure
Effects: None.
Notes: 1) Clumps are only split along the X or Y dimension.
       2) This assumes that profiles will fit into 16-bit unsigned
       numbers. If this is not the case (huge sensor with high gain),
       then you will need to modify this code to use 32-bit profiles.
       3) Splitting does not occur if more than 3 positive clumps
       are present.
----------------------------------------------------------- */
void clumpSplitter_split(int16 *deltaImage, uint16 cSat_LSB,
                        clumps_t *clumps)
{
  uint16 skipClumps[MAX_OBJECTS];
  uint16 totalObjects = 0;
  uint16 i;
  uint16 splitIdx = 0;

  {
    uint16 posClumpCount = 0;
    uint16 *pSkip;
    clumpInfo_t *pInfo;

    pSkip = skipClumps;
    pInfo = clumps->info;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      uint16 peakFlag;
      uint16 posFlag;
      uint16 posPeakFlag;
      uint16 splitCount;
      peakFlag = (pInfo->peakCount > 0);
      posFlag = (pInfo->polarity == clumpPolarity_positive);
      splitCount = pInfo->splitCount;
      if (peakFlag)
      {
        splitIdx += splitCount;
        totalObjects += splitCount + 1;
      }
      pInfo++;
      posPeakFlag = peakFlag && posFlag;
      *pSkip++ = !posPeakFlag || (splitCount > 0);
      posClumpCount += posPeakFlag;
    }

    if (posClumpCount > 3)
    {
      return;
    }
  }

  for (i = 0; i < MAX_OBJECTS; i++)
  {
    uint16 profX[MAX_RX];
    uint16 profY[MAX_TX];

    if (skipClumps[i])
    {
      continue;
    }

    if (totalObjects >= MAX_OBJECTS)
    {
      break;
    }

    clumpProjector_getProjectionXY(clumps, i+1, 0, deltaImage, profX, profY);

    {
      struct prominence_t prominenceX, prominenceY;
      int16 splitPos;
      splitAxis_t splitAxis;
      uint16 maxX, maxY;

      segmentProfile(profX, MAX_RX, &maxX, &prominenceX);
      segmentProfile(profY, MAX_TX, &maxY, &prominenceY);

      splitPos = 0;
      if (prominenceX.prominence > prominenceY.prominence && maxX > cSat_LSB/2)
      {
        splitPos = prominenceX.split;
        splitAxis = splitAxis_0;
      }
      else if (prominenceY.split > 0 && maxY > cSat_LSB/2)
      {
        splitPos = prominenceY.split;
        splitAxis = splitAxis_90;
      }
      if (splitPos > 0)
      {
        splitClump(clumps, (uint16) i, splitIdx, splitAxis, (uint16) splitPos);
        splitIdx++;
        totalObjects++;
      }
    }
  }
}

void clumpSplitter_configure(clumpSplitterConfig_t *pcsConfig)
{
  minProminence = pcsConfig->prominence;
}
#endif // !CONFIG_HAS_LINEAR_SWIPE_SPLITTER
