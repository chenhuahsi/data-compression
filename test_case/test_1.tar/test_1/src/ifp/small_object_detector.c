/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: Determines whether a small object is touching
   $Id$
----------------------------------------------------------------- */

/* Small Object Detection Algorithm Overview -----------------------

   The small object detector is a standard feature-based classifier.
   It first calculates features (in this case the amplitude and area
   of the object), then it uses those features to classify the object
   as touching or not touching.

   The height is determined with an approximate rectangular pyramid
   fit. This evens out the variation of maximum pixel response as the
   object moves around the sensor.

           A

          /\
         /.|\
        / .| \
       /  .|  \
      /   .|   \
     /   ..|    \
    /  ..  |..   \
   / ..    |  ..  \
   --      |     --  ----> row
     --    |   --
       --  | --
         --|-

           |
           |
           V  column


   The equation fit for each axis is

       z(x) = max(0, height*(1 - abs(x-x0)/width))

   Several similar algorithms are used depending on the location of the
   peak. A 4 point fit using the following 12 points in the interior:
   000000
   00XX00
   0XXXX0
   0XXXX0
   00XX00
   000000

   A 3 point fit using the following 5 points near the edge:
   00000
   00X00
   0XXX0
   00X00
   -----

   A 2 and 3 point fit using the following 6 points on the edge:
   00000
   00X00
   0XXX0
   -----

   And a 2 and 3 point fit using the following 6 points on the edge:
   |0000
   |XX00
   |XXX0
   |XXX0
   +----

   The height of the pyramid is a good metric for the size of the
   touch. The area of the pyramid is not so good, because the actual
   signal tapers off more slowly than the pyramid when it gets close
   to zero. This means that the area gets overestimated at some
   points. To make up for this model fit error, in the 12 point
   fit we estimate the width using the height estimate (obtained
   from all the points) and the interior point furtherest from the
   estimated peak location. The resulting area metric is pretty good
   at distinguishing between touching (narrow) and hovering (wide)
   fingers.

   Areas are subtracted by one to extend dynamic range since widths
   cannot be smaller than 1.

   Different features may need to be calculated for different sensor
   types. It is relatively easy to substitute different metrics for
   the ones here--replace the fitIsoscelesTriangle*() functions with
   your own fit and adjust the decision boundary to compensate.

   The small object decision boundary follows the basic rule that the
   larger the object is, the more amplitude it needs to have to be
   declared touching. Although, this all depends on tuning the
   boundary with the desired objects.

   Headphone cable rejection is accomplished by looking at the widths
   in all directions (including diagonals) and rejecting anything
   that's too long.

------------------------------------------------------------------*/

#include "ifp_common.h"

#if CONFIG_HAS_SMALL_OBJECT_DETECTOR

#include "ifp_string.h"
#include "small_object_detector.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

#define SOD_MIN(x, y) (((x) < (y)) ? (x) : (y))
#define SOD_MAX(x, y) (((x) > (y)) ? (x) : (y))
#define SOD_DATA_LIMIT 8192

/* =================================================================
   MODULE TYPES
==================================================================*/

typedef struct
{
  uint16 height;
  uint4p12 width;
} smallFingerHeightWidth_t;

typedef struct
{
  smallFingerHeightWidth_t x;
  smallFingerHeightWidth_t y;
  smallFingerHeightWidth_t diag45;
  smallFingerHeightWidth_t diag315;
} smallFingerSize_t;

typedef struct
{
  uint16 scaleDownFlag : 1;
  uint16 startPixelOffset : 2;
  uint16 length : 3;
  uint16 onEdge : 1;
  uint16 nearEdge : 1;
  int16 sumOffset : 3;
} smallFingerPixelParams_t;

typedef struct
{
  int16 *deltaImage;
  int16 maxRow;
  int16 maxCol;
} sizedDelta_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

static uint32 compute4PtK(uint32 S2, int16 APeak, uint32 AEdge);

static void fitIsoscelesTriangle4Pts(uint16 *z, smallFingerHeightWidth_t *size);

static void fitIsoscelesTriangle3Pts(uint16 *z, smallFingerHeightWidth_t *size);

static void fitIsoscelesTriangle2PtsAndW(uint16 *z, uint4p12 defaultWidth, smallFingerHeightWidth_t *size);

static void fitIsoscelesTriangle3PtsCorner(uint16 *z, smallFingerHeightWidth_t *size);

static void prepareSmallFingerPixelParams1D(uint16 leftFlag, uint16 rightFlag,
                                            int16 leftVal, int16 rightVal,
                                            uint16 electrodeCount, uint16 peakElectrode,
                                            smallFingerPixelParams_t *vectorParams);

static void prepareSmallFingerPixelParams2D(smallFingerPixelParams_t *vectorParams1,
                                            smallFingerPixelParams_t *vectorParams2);

static uint16 extractSmallFingerPixels(sensorParams_t *params, pixelIndex_t peakLoc,
                                    int16 *deltaImage,
                                    uint16 *zx, uint16 *zy,
                                    uint16 *z45, uint16 *z315,
                                    smallFingerPixelParams_t *xVectorParams,
                                    smallFingerPixelParams_t *yVectorParams);

static void estimateSmallFingerSize4PtFit(uint16 *zx, uint16 *zy,
                                          smallFingerSize_t *size);

static void estimateSmallFingerNearEdgeSize3PtFit(uint16 *zx, uint16 *zy,
                                                  smallFingerSize_t *size);

static void estimateSmallFingerOnEdgeSize3PtFit(uint16 *zx, uint16 *zy,
                                                smallFingerPixelParams_t *xVectorParams,
                                                smallFingerPixelParams_t *yVectorParams,
                                                smallFingerSize_t *size);

static void estimateSmallFingerCornerSize3PtFit(uint16 *zx, uint16 *zy,
                                                smallFingerPixelParams_t *xVectorParams,
                                                smallFingerPixelParams_t *yVectorParams,
                                                smallFingerSize_t *size);

static void estimateSmallFingerDiagonalSize3PtFit(uint16 *z45, uint16 *z315,
                                                  smallFingerSize_t *size);

static void measureSmallFingerFeatures(sensorParams_t *params, int16 *deltaImage,
                                       pixelIndex_t peakLoc, smallObjectFeatures_t *soFeatures);

static uint16 isPointInRegion(smallObjectDetectorRegion_t *p,
                              smallObjectDetectorRegion_t *vertices, uint16 len);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: compute4PtK
Purpose: Compute the parameter k associated with the 4pt fit of z.
Inputs: S2 - mean of squares of z
        APeak - (-z[0] + z[1] + z[2] - z[3])/4
        AEdge - (z[0]*z[1] + z[2]*z[3])/2
Outputs: k - the parameter k associated with the 4pt fit of z.
----------------------------------------------------------- */
static uint32 compute4PtK(uint32 S2, int16 APeak, uint32 AEdge)
{
  uint32 k;
  // k = (S2 - AEdge)/APeak;

  if (APeak == 0)
  {
    // k would overflow
    return 0xFFFFFFFF;
  }

  k = S2 - AEdge;
  // 4*(S2 - AEdge) = z[0]^2 + z[1]^2 + z[2]^2 + z[3]^2 - 2*(z[0]*z[1] + z[2]*z[3])
  // = (z[0] - z[1])^2 + (z[2] - z[3])^2 --> k non-negative

  // this cannot overflow since 0 <= S2 <= 0x3FFF0001
  // (k << 1)/1 + 1 <= 0x7FFE0003
  // 0 <= k <= 0x3FFF0001
  k <<= 1;
  k /= (uint32) APeak;
  k += 1;
  k >>= 1;

  return k;
}

/* -----------------------------------------------------------
Name: fitIsoscelesTriangle4Pts
Purpose: Interpolate a small finger peak using a 4-point
         triangular fit. Find the interpolated peak amplitude
         and the width.
Inputs: z - array of peak and its three of its neighbors in order.
Outputs: size.height - the interpolated height
         size.width - the width
Notes: In this function, overflow checking has been conducted assuming
       each element of the z vector is 0 <= z[i] <= 32767
----------------------------------------------------------- */
static void fitIsoscelesTriangle4Pts(uint16 *z, smallFingerHeightWidth_t *size)
{
  uint32 k;
  uint32 S2, AEdge;
  uint16 S1;
  int16 APeak;
  int16 AStepTmp;
  uint16 AStep;
  uint16 zSecond;
  uint16 h;
  uint32 w;

  if (z[0] == 0 && z[1] == 0 && z[2] == 0 && z[3] == 0)
  {
    // invalid input
    size->height = 0;
    size->width = 0xFFFF;
    return;
  }

  // this can't overflow, range of S1 is 0 <= S1 <= 0x7FFF
  // before bitshift, uint32 will be at most 0x0001FFFE
  S1 = (uint16)(((uint32)z[0] + z[1] + z[2] + z[3] + 2) >> 2);

  // this can't overflow, range of APeak is -16383 <= APeak <= 16384
  // before bitshift, int32 will be at least -0x0000FFFC and at most 0x00010000
  APeak = (int16)((-((int32)z[0] + z[3]) + z[1] + z[2] + 2) >> 2);

  if (APeak <= 0)
  {
    // k <= 0, width calculation breaks down
    size->height = (uint16) S1;
    size->width = 0xFFFF;
    return;
  }

  // this can't overflow, range of AStepTmp is -16383 <= AStepTmp <= 16384
  // before bitshift, int32 will be at least -0x0000FFFC and at most 0x00010000
  AStepTmp = (int16)((-((int32)z[0] + z[1]) + z[2] + z[3] + 2) >> 2);
  AStep = (uint16)((AStepTmp < 0) ? -AStepTmp : AStepTmp);

  // find second largest interior point
  zSecond = (z[1] > z[2] ) ? z[2] : z[1];

  // this can't overflow, range of AEdge is 0 <= AEdge <= 0x3FFF0001
  // before bitshift, uint32 will be at most 0x7FFE0003
  AEdge  = (uint32)z[0] * z[1];
  AEdge += (uint32)z[2] * z[3];
  AEdge++;
  AEdge >>= 1;

  // this can't overflow, range of S2 is 0 <= S2 <= 0x3FFF0001
  // before bitshift, uint32 will be at most 0xFFFC0006
  S2  = (uint32)z[0] * z[0];
  S2 += (uint32)z[1] * z[1];
  S2 += (uint32)z[2] * z[2];
  S2 += (uint32)z[3] * z[3];
  S2 += 2;
  S2 >>= 2;

  // k = (S2 - AEdge) / APeak
  k = compute4PtK(S2, APeak, AEdge);

  // height = k + S1
  // width  = (AStep*(1 + S1/k) + height/2)/(height - min(z[1], z[2]))
  //        = (1/2 + AStep/k)/(1 - min(z[1], z[2])/(k + S1))

  if (k == 0)
  {
    // width calculation breaks down
    size->width = 0xFFFF;
    size->height = (uint16) S1;
    return;
  }

  if (k >= 0xFFFF || k + S1 >= 0xFFFF)
  {
    // height calculation overflows
    size->height = 0xFFFF;
    size->width = 0x0800; // 0.5 in 4.12
    return;
  }

  // this cannot overflow since
  // k + S1 < 0xFFFF
  h = k + S1;
  size->height = h;

  if ((int16)h - (int16)zSecond <= 0)
  {
    // width calculation breaks down
    size->width = 0xFFFF;
    return;
  }

  // 1 + S1/k in 4p12
  // this will not overflow, max at
  // (0x00007FFF << 13)/1 + 1 = 0x0FFFE001
  // (1 << 12) + 0x00FFFE00 = 0x01000E00
  w = (4096 + (((((uint32)S1 << 13)/k + 1)) >> 1));

  // check for overflow of width calculation numerator
  if ((w>>16)*AStep > (uint32)0xFFFF - (uint32)(h>>5))
  {
    // second step of width calculation overflows
    size->width = 0xFFFF;
    return;
  }

  // denominator checked for <= 0 and numerator checked for overflow above
  w = (w*AStep + ((uint32)h<<11))/(h - zSecond);

  // clip width at 0xFFFF
  size->width = (uint4p12) ((w > 0xFFFF) ? 0xFFFF : w);
  return;
}

/* -----------------------------------------------------------
Name: fitIsoscelesTriangle3Pts
Purpose: Interpolate a small finger peak using a triangle fit.
         Find the interpolated peak amplitude and the width.
Inputs: z - array of peak and its two neighbors in order.
Outputs: size.height - the interpolated height
         size.width - the width around the peak pixel
----------------------------------------------------------- */
static void fitIsoscelesTriangle3Pts(uint16 *z, smallFingerHeightWidth_t *size)
{
  uint16 height;
  uint32 width;
  uint16 zMid, zMin, zOther;
  uint16 slope, delta;

  zMid = z[1];
  zMin   = SOD_MIN(z[0], z[2]);
  zOther = SOD_MAX(z[0], z[2]);

  slope = zMid - zMin;

  if (slope == 0)
  {
    size->height = zMid;
    size->width = 0xFFFF;
    return;
  }

  delta = (zOther - zMin + 1) >> 1;
  height = zMid + delta;
  size->height = height;

  // fixed-point:
  // 15.12 =            16.13           / 16.0       /  2
  width    = ((((uint32) height) << 13) / slope + 1) >> 1;
  size->width = (uint4p12) ((width > 0xFFFF) ? 0xFFFF : width);
}

/* -----------------------------------------------------------
Name: fitIsoscelesTriangle2PtsAndW
Purpose: Interpolate a small finger peak using a triangle fit.
         Find the interpolated peak amplitude and the width.
Inputs: z - array of peak and its available neighbor in sensor order.
        defaultWidth - the width to assume on the sensor edge. This
                value must be >= 1.
Outputs: size.height - the interpolated height
         size.width - the width
----------------------------------------------------------- */
static void fitIsoscelesTriangle2PtsAndW(uint16 *z, uint4p12 defaultWidth, smallFingerHeightWidth_t *size)
{
  uint32 height = 0;
  uint16 minZ, maxZ;
  uint16 slope;

  if (z[0] > z[1])
  {
    maxZ = z[0];
    minZ = z[1];
  }
  else
  {
    maxZ = z[1];
    minZ = z[0];
  }

  slope = maxZ - minZ;

  if (maxZ == 0 || defaultWidth == 0)
  {
    // invalid input
    size->height = 0;
    size->width = 0xFFFF;
    return;
  }

  if ((slope != 0) && defaultWidth > ((uint32)maxZ << 12)/slope)
  {
    // defaultWidth is big enough that the interpolated peak must be beyond
    // the edge of the sensor. Since it could become arbitrarily large
    // if defaultWidth is large, limit it to the amplitude it could get to if
    // the object is exactly on the sensor edge

    uint16 heightAssumingObjectOnEdge;
    uint32 heightAssumingGivenWidth;

    heightAssumingObjectOnEdge = maxZ + (slope + 1)/2;
    // fixed-point:   [ 16.0 =          16.0 * 4.12               / 4.12 ]
    heightAssumingGivenWidth = ((uint32)slope*defaultWidth + 2048)/4096;

    height = SOD_MIN(heightAssumingObjectOnEdge, heightAssumingGivenWidth);
  }
  else if (defaultWidth > 2048)
  {
    // defaultWidth is small enough that the interpolated peak must be between
    // our two points.
    // height = (maxZ+minZ)/(2 - 1/defaultWidth)
    uint8p8 defaultWidthInv;
    // fixed-point:  [ 8.8 =               12.20    / 4.12 ]
    defaultWidthInv = (uint8p8) (((uint32) 1 << 20) / defaultWidth);
    // fixed-point:      [ 16.8      /        8.8 ]
    height = ((uint32)(maxZ+minZ)<<8)/(0x200 - defaultWidthInv);
  }
  else
  {
    // defaultWidth <= 1/2, above calculation breaksdown
    size->height = 0xFFFF;
  }

  size->height = (uint16)((height > 0xFFFF) ? 0xFFFF : height);
  size->width = defaultWidth;
}

/* -----------------------------------------------------------
Name: fitIsoscelesTriangle3PtsCorner
Purpose: Interpolate a small finger peak using a triangle fit.
         Find the interpolated peak amplitude and the width.
Inputs: z - array of peak and its two neighbors in order.
Outputs: size.height - the interpolated height
         size.width - the width
Notes: Function assumes peak pixel is at 0 index location of z.
----------------------------------------------------------- */
static void fitIsoscelesTriangle3PtsCorner(uint16 *z, smallFingerHeightWidth_t *size)
{
  uint16 zPeak, zMid, zFar;
  uint16 height;
  int16 slope1, slope2;
  uint32 width;

  zPeak = z[0];
  zMid  = z[1];
  zFar  = z[2];

  slope1 = zPeak - zMid;
  slope2 = zMid  - zFar;
  if (SOD_MAX(slope1, slope2) <= 0)
  {
    // invalid input
    size->height = zPeak;
    size->width = 0xFFFF;
    return;
  }

  if (slope1 < slope2)
  {
    // peak between first and second elements of z
    height = (zPeak + zMid + slope2 + 1) >> 1;
    // fixed-point:
    // 15.12 =            16.13       / 16.0       /  2
    width    = (((uint32)height << 13)/slope2 + 1) >> 1;
  }
  else
  {
    // assume peak exactly at first element of z
    height = zPeak;
    // fixed-point:
    // 15.12 =            16.13       / 16.0       /  2
    width    = (((uint32)height << 13)/slope1 + 1) >> 1;
  }

  size->height = height;
  size->width = (uint4p12)((width > 0xFFFF) ? 0xFFFF : width);
}

/* -----------------------------------------------------------
Name: estimateSmallFingerDiagonalSize3Pts
Purpose: Estimates the height and width of the diagonal
         axes of a small finger
Inputs: z45 - z vector associated with the 45 degree diagonal axis
        z315 - z vector associated with the 3155 degree diagonal axis
Outputs: size - struct holding the amplitude and widths for
                diag45, diag315 axes
----------------------------------------------------------- */
static void estimateSmallFingerDiagonalSize3PtFit(uint16 *z45, uint16 *z315,
                                                  smallFingerSize_t *size)
{
  // for diagonals, we're looking for a long skinny object and
  // therefore only want to know the maximum of the two widths. This
  // means we don't need to share widths between the two axes.
  fitIsoscelesTriangle3Pts(z45, &(size->diag45));
  fitIsoscelesTriangle3Pts(z315, &(size->diag315));
}

/* -----------------------------------------------------------
Name: estimateSmallFingerSize4Pts
Purpose: Estimates the height and width of a small finger in
         the interior of the sensor.
Inputs: zx - z vector associated with the x-axis
        zy - z vector associated with the y-axis
Outputs: size - struct holding the amplitude and widths for
                x, y
Notes: The x and y z-vectors are 4-element vector.
       The peak is between the second and third elements of zx and zy.
----------------------------------------------------------- */
static void estimateSmallFingerSize4PtFit(uint16 *zx, uint16 *zy,
                                          smallFingerSize_t *size)
{

  fitIsoscelesTriangle4Pts(zx, &(size->x));
  fitIsoscelesTriangle4Pts(zy, &(size->y));
}

/* -----------------------------------------------------------
Name: estimateSmallFingerNearEdgeSize3PtFit
Purpose: Estimates the height and width of a small finger near
         the edge of the sensor.
Inputs: zx - z vector associated with the x-axis
        zy - z vector associated with the y-axis
Outputs: size - struct holding the amplitude and widths for
                x, y
Notes: The x and y z-vectors are 3-element vector.
       The peak is +-0.5 pixels from the second elements of zx and zy.
----------------------------------------------------------- */
static void estimateSmallFingerNearEdgeSize3PtFit(uint16 *zx, uint16 *zy,
                                                  smallFingerSize_t *size)
{

  fitIsoscelesTriangle3Pts(zx, &(size->x));
  fitIsoscelesTriangle3Pts(zy, &(size->y));
}

/* -----------------------------------------------------------
Name: estimateSmallFingerOnEdgeSize3PtFit
Purpose: Estimates the height and width of a small finger on
         the edge of the sensor.
Inputs: zx - z vector associated with the x-axis
        zy - z vector associated with the y-axis
        xVectorParams - the pixel params structure associated with the x-axis
        yVectorParams - the pixel params structure associated with the y-axis
Outputs: size - struct holding the amplitude and widths for
                x, y
Notes: The vector along the edge of the sensor is a 3-element vector.
       The vector perpendicular to the edge of the sensor is a 2-element vector.
       The peak is +-0.5 pixels from the second element of the 3-element vector.
----------------------------------------------------------- */
static void estimateSmallFingerOnEdgeSize3PtFit(uint16 *zx, uint16 *zy,
                                                smallFingerPixelParams_t *xVectorParams,
                                                smallFingerPixelParams_t *yVectorParams,
                                                smallFingerSize_t *size)
{
  if (yVectorParams->onEdge && !xVectorParams->onEdge)
  {
    fitIsoscelesTriangle3Pts(zx, &(size->x));
    fitIsoscelesTriangle2PtsAndW(zy, size->x.width, &(size->y));
  }
  else
  {
    fitIsoscelesTriangle3Pts(zy, &(size->y));
    fitIsoscelesTriangle2PtsAndW(zx, size->y.width, &(size->x));
  }
}

/* -----------------------------------------------------------
Name: estimateSmallFingerCornerSize3PtFit
Purpose: Estimates the height and width of a small finger at
         the corner of the sensor.
Inputs: zx - z vector associated with the x-axis
        zy - z vector associated with the y-axis
        xVectorParams - the pixel params structure associated with the x-axis
        yVectorParams - the pixel params structure associated with the y-axis
Outputs: size - struct holding the amplitude and widths for
                x, y
Notes: The x and y z-vectors are 3-element vector.
       The peak is +-0.5 pixels from the first elements of zx and zy.
----------------------------------------------------------- */
static void estimateSmallFingerCornerSize3PtFit(uint16 *zx, uint16 *zy,
                                                smallFingerPixelParams_t *xVectorParams,
                                                smallFingerPixelParams_t *yVectorParams,
                                                smallFingerSize_t *size)
{

  if (xVectorParams->startPixelOffset)
  {
    uint16 zTmp = zx[0];
    zx[0] = zx[2];
    zx[2] = zTmp;
  }

  if (yVectorParams->startPixelOffset)
  {
    uint16 zTmp = zy[0];
    zy[0] = zy[2];
    zy[2] = zTmp;
  }

  fitIsoscelesTriangle3PtsCorner(zx, &(size->x));
  fitIsoscelesTriangle3PtsCorner(zy, &(size->y));
}

/* -----------------------------------------------------------
Name: prepareSmallFingerPixelParams1D
Purpose: Takes data from around the peak pixel and populates the
         pixel params structure accordingly for a single dimension.
Inputs: leftFlag - flag saying whether the left pixel was off the edge
        rightFlag - flag saying whether the right pixel was off the edge
        leftVal - value of pixel left of peak
        rightVal - value of pixel right of peak
        electrodeCount - number of pixel spanning sensor in this dimension
        peakElectrode - pixel number of peak pixel
Outputs: vectorParams - the pixel params structure associated with this axis
----------------------------------------------------------- */
static void prepareSmallFingerPixelParams1D(uint16 leftFlag, uint16 rightFlag,
                                    int16 leftVal, int16 rightVal,
                                    uint16 electrodeCount, uint16 peakElectrode,
                                    smallFingerPixelParams_t *vectorParams)
{

  vectorParams->scaleDownFlag = 0;
  vectorParams->startPixelOffset = 1;
  vectorParams->length = 4;
  vectorParams->onEdge = 0;
  vectorParams->nearEdge = 0;
  vectorParams->sumOffset = +1;

  if (leftFlag)
  {
    vectorParams->length = 3;
    vectorParams->startPixelOffset = 0;
    vectorParams->onEdge = 1;
    vectorParams->nearEdge = 0;
    vectorParams->sumOffset = +1;
  }
  else if (rightFlag)
  {
    vectorParams->startPixelOffset = 2;
    vectorParams->length = 3;
    vectorParams->onEdge = 1;
    vectorParams->nearEdge = 0;
    vectorParams->sumOffset = -1;
  }

  if (!vectorParams->onEdge)
  {
    if (leftVal > rightVal)
    {
      vectorParams->startPixelOffset = 2;
      vectorParams->sumOffset = -1;
    }
    if (peakElectrode - vectorParams->startPixelOffset == 0)
    {
      vectorParams->length = 3;
      vectorParams->startPixelOffset = 1;
      vectorParams->onEdge = 0;
      vectorParams->nearEdge = 1;
    }
    else if (peakElectrode - vectorParams->startPixelOffset == electrodeCount - 2)
    {
      vectorParams->length = 3;
      vectorParams->startPixelOffset = 1;
      vectorParams->onEdge = 0;
      vectorParams->nearEdge = 1;
    }
  }
}


/* -----------------------------------------------------------
Name: prepareSmallFingerPixelParams2D
Purpose: Takes pixel params structures from each dimension and makes
         fit modifications depending on the both structures
Inputs: vectorParams1 - IFP sensor parameters
        vectorParams2 - row/col of peak pixel
----------------------------------------------------------- */
static void prepareSmallFingerPixelParams2D(smallFingerPixelParams_t *vectorParams1,
                                            smallFingerPixelParams_t *vectorParams2)
{
  if (vectorParams1->onEdge && !vectorParams2->onEdge)
  {
    vectorParams2->startPixelOffset = 1;
    vectorParams2->length = 3;
    vectorParams1->startPixelOffset = SOD_MIN(vectorParams1->startPixelOffset, 1);
    vectorParams1->length = 2;
  }
  else if (vectorParams1->nearEdge && !vectorParams2->onEdge)
  {
    vectorParams2->startPixelOffset = 1;
    vectorParams2->length = 3;
  }
}

/* -----------------------------------------------------------
Name: extractSmallFingerPixels
Purpose: Takes the peak location and deltaImage and populates the
         z vectors used for fitting and the pixel params structures
         associated with the x and y axis fits.
Inputs: params - IFP sensor parameters
        peakLoc - row/col of peak pixel
        deltaImage - the deltaImage
Outputs: zx - the array for the x-axis z vector
         zy - the array for the y-axis z vector
         z45 - the array for the 45 degree diagonal axis z vector
         z315 - the array for the 315 degree diagonal axis z vector
         xVectorParams - the pixel params associated with the x-axis fit
         yVectorParams - the pixel params associated with the y-axis fit
----------------------------------------------------------- */
static uint16 extractSmallFingerPixels(sensorParams_t *params, pixelIndex_t peakLoc,
                                       int16 *deltaImage,
                                       uint16 *zx, uint16 *zy,
                                       uint16 *z45, uint16 *z315,
                                       smallFingerPixelParams_t *xVectorParams,
                                       smallFingerPixelParams_t *yVectorParams)
{
  uint16 peakRow, peakCol;
  int16 leftVal = 0;
  int16 rightVal = 0;
  uint16 leftFlag, rightFlag;
  int16 z16[4];
  int16 *z16Ptr;
  uint16 *zU16Ptr;
  int16 *deltaImagePtr;
  uint16 rowLength = MAX_RX + 1;
  uint16 idx;

  peakRow = peakLoc.row;
  peakCol = peakLoc.col;

  deltaImagePtr = deltaImage + peakRow*rowLength + peakCol;
  leftFlag = (peakCol <= 1);
  if (!leftFlag)
  {
    leftVal = *(deltaImagePtr - 1);
  }
  rightFlag = (peakCol >= params->rxCount);
  if (!rightFlag)
  {
    rightVal = *(deltaImagePtr + 1);
  }

  prepareSmallFingerPixelParams1D(leftFlag, rightFlag, leftVal, rightVal, params->rxCount, peakCol, xVectorParams);

  leftFlag = (peakRow <= 1);
  if (!leftFlag)
  {
    leftVal = *(deltaImagePtr - rowLength);
  }
  rightFlag = (peakRow >= params->txCount);
  if (!rightFlag)
  {
    rightVal = *(deltaImagePtr + rowLength);
  }

  prepareSmallFingerPixelParams1D(leftFlag, rightFlag, leftVal, rightVal, params->txCount, peakRow, yVectorParams);

  prepareSmallFingerPixelParams2D(xVectorParams, yVectorParams);
  prepareSmallFingerPixelParams2D(yVectorParams, xVectorParams);

  // create x slice for fitting
  deltaImagePtr = deltaImage + peakRow*rowLength + (peakCol - xVectorParams->startPixelOffset);
  z16Ptr = z16;
  for (idx = 0; idx < xVectorParams->length; idx++)
  {
    // ensure data limits are satisfied
    if (*deltaImagePtr > SOD_DATA_LIMIT || *deltaImagePtr < -SOD_DATA_LIMIT)
    {
      return 1;
    }
    *z16Ptr = *deltaImagePtr;
    z16Ptr++;
    deltaImagePtr++;
  }

  if (!(xVectorParams->onEdge ^ yVectorParams->onEdge)) // single bit flags so bitwise xor is okay
  {
    // sum slices with largest adjacent pixels
    deltaImagePtr = deltaImage + (peakRow + yVectorParams->sumOffset)*rowLength + (peakCol - xVectorParams->startPixelOffset);
    z16Ptr = z16;
    for (idx = 0; idx < xVectorParams->length; idx++)
    {
      // ensure data limits are satisfied
      if (*deltaImagePtr > SOD_DATA_LIMIT || *deltaImagePtr < -SOD_DATA_LIMIT)
      {
        return 1;
      }
      *z16Ptr += *deltaImagePtr;
      z16Ptr++;
      deltaImagePtr++;
    }
  }

  // take abs of x slice
  zU16Ptr = zx;
  z16Ptr = z16;
  for (idx = 0; idx < xVectorParams->length; idx++)
  {
    *zU16Ptr = SOD_MAX(*z16Ptr, 0);
    zU16Ptr++;
    z16Ptr++;
  }

  // create y slice for fitting
  deltaImagePtr = deltaImage + (peakRow - yVectorParams->startPixelOffset)*rowLength + peakCol;
  z16Ptr = z16;
  for (idx = 0; idx < yVectorParams->length; idx++)
  {
    // ensure data limits are satisfied
    if (*deltaImagePtr > SOD_DATA_LIMIT || *deltaImagePtr < -SOD_DATA_LIMIT)
    {
      return 1;
    }
    *z16Ptr = *deltaImagePtr;
    z16Ptr++;
    deltaImagePtr += rowLength;
  }
  if (!(xVectorParams->onEdge ^ yVectorParams->onEdge)) // single bit flags so bitwise xor is okay
  {
    // sum slices with largest adjacent pixels
    deltaImagePtr = deltaImage + (peakRow - yVectorParams->startPixelOffset)*rowLength + (peakCol + xVectorParams->sumOffset);
    z16Ptr = z16;
    for (idx = 0; idx < yVectorParams->length; idx++)
    {
      // ensure data limits are satisfied
      if (*deltaImagePtr > SOD_DATA_LIMIT || *deltaImagePtr < -SOD_DATA_LIMIT)
      {
        return 1;
      }
      *z16Ptr += *deltaImagePtr;
      z16Ptr++;
      deltaImagePtr += rowLength;
    }
  }

  // take abs of y slice
  zU16Ptr = zy;
  z16Ptr = z16;
  for (idx = 0; idx < yVectorParams->length; idx++)
  {
    *zU16Ptr = (uint16) SOD_MAX(*z16Ptr, 0);
    zU16Ptr++;
    z16Ptr++;
  }

  z315[1] = (uint16) SOD_MAX(deltaImage[peakRow*rowLength + peakCol], 0);
  z45[1] = z315[1];

  z315[0] = (uint16) SOD_MAX(deltaImage[(peakRow - 1)*rowLength + peakCol - 1], 0);
  z315[2] = (uint16) SOD_MAX(deltaImage[(peakRow + 1)*rowLength + peakCol + 1], 0);

  z45[0] = (uint16) SOD_MAX(deltaImage[(peakRow - 1)*rowLength + peakCol + 1], 0);
  z45[2] = (uint16) SOD_MAX(deltaImage[(peakRow + 1)*rowLength + peakCol - 1], 0);

  if (peakRow == 1)
  {
    if (peakCol < params->rxCount - 1)
    {
      z315[0] = (uint16) SOD_MAX(deltaImage[(peakRow + 2)*rowLength + peakCol + 2], 0);
    }
    if (peakCol > 2)
    {
      z45[0] = (uint16) SOD_MAX(deltaImage[(peakRow + 2)*rowLength + peakCol - 2], 0);
    }
  }
  else if (peakRow == params->rxCount)
  {
    if (peakCol > 2)
    {
      z315[2] = (uint16) SOD_MAX(deltaImage[(peakRow - 2)*rowLength + peakCol - 2], 0);
    }
    if (peakCol < params->rxCount - 1)
    {
      z45[2] = (uint16) SOD_MAX(deltaImage[(peakRow - 2)*rowLength + peakCol + 2], 0);
    }
  }

  if (z315[0] > SOD_DATA_LIMIT || z315[1] > SOD_DATA_LIMIT || z315[2] > SOD_DATA_LIMIT ||
      z45[0] > SOD_DATA_LIMIT || z45[1] > SOD_DATA_LIMIT || z45[2] > SOD_DATA_LIMIT)
  {
    return 1;
  }

  return 0;
}

/* -----------------------------------------------------------
Name: measureSmallFingerFeatures
Purpose: Measures features used for small finger classification
Inputs: params - sensor parameters structure
        deltaImage - the delta image
        peakLoc - location of the peak to examine
Outputs: soFeatures - struct holding the amplitude relative to
                      saturation, the area, and the maximum
                      widths in along xy and diagonal directions.
----------------------------------------------------------- */
static void measureSmallFingerFeatures(sensorParams_t *params, int16 *deltaImage,
                                       pixelIndex_t peakLoc,
                                       smallObjectFeatures_t *soFeatures)
{
  uint16 zx[4];
  uint16 zy[4];
  uint16 z45[3];
  uint16 z315[3];
  uint16 zxMax = 0;
  uint16 zyMax = 0;
  int16 zPeak;
  uint16 interpolatedHeight;
  smallFingerSize_t size;
  uint32 relativeAmplitude32;
  uint32 area32;
  uint16 area16;
  uint32 maxDiagonalWidth32;
  uint16 maxDiagonalWidth16;
  uint32 maxXYWidth32;
  uint16 maxXYWidth16;
  smallFingerPixelParams_t xVectorParams;
  smallFingerPixelParams_t yVectorParams;
  uint16 dataLimitFlag;

  memset16(soFeatures, 0, sizeof(*soFeatures) / sizeof(uint16));
  memset16(&xVectorParams, 0, sizeof(xVectorParams) / sizeof(uint16));
  memset16(&yVectorParams, 0, sizeof(yVectorParams) / sizeof(uint16));

  zPeak = *(deltaImage + peakLoc.row*(MAX_RX + 1) + peakLoc.col);

  if (zPeak <= 0)
  {
    soFeatures->relativeAmplitude = 0;
    soFeatures->area = 0xFF;
    soFeatures->maxDiagonalWidth = 0xFF;
    soFeatures->maxXYWidth = 0xFF;
    return;
  }

  dataLimitFlag = extractSmallFingerPixels(params, peakLoc, deltaImage, zx, zy, z45, z315, &xVectorParams, &yVectorParams);
  if (dataLimitFlag)
  {
    return;
  }
  // z data guaranteed to be less than 2*SOD_DATA_LIMIT

  {
    uint16 idx;
    for (idx = 0; idx < xVectorParams.length; idx++)
    {
      zxMax = SOD_MAX(zxMax, zx[idx]);
    }
    for (idx = 0; idx < yVectorParams.length; idx++)
    {
      zyMax = SOD_MAX(zyMax, zy[idx]);
    }
  }

  // bailout if either vector has a maximum of 0
  if (zxMax <= 0 || zyMax <= 0)
  {
    soFeatures->relativeAmplitude = 0;
    soFeatures->area = 0xFF;
    soFeatures->maxDiagonalWidth = 0xFF;
    soFeatures->maxXYWidth = 0xFF;
    return;
  }

  // first do the standard axes
  if (!(xVectorParams.nearEdge || yVectorParams.nearEdge || xVectorParams.onEdge || yVectorParams.onEdge))
  {
    // perform 4pt square fit of peak
    estimateSmallFingerSize4PtFit(zx, zy, &size);

    // average x and y height estimates
    // this cannot overflow
    interpolatedHeight = (uint16)((((uint32)size.x.height + (uint32)size.y.height) + 1) >> 1);
  }
  else if ((xVectorParams.nearEdge || yVectorParams.nearEdge) && !(xVectorParams.onEdge || yVectorParams.onEdge))
  {
    // perform 3pt square fit of peak
    estimateSmallFingerNearEdgeSize3PtFit(zx, zy, &size);

    // average x and y height estimates
    // this cannot overflow
    interpolatedHeight = (uint16)((((uint32)size.x.height + (uint32)size.y.height) + 1) >> 1);
  }
  else if (xVectorParams.onEdge ^ yVectorParams.onEdge)
  {
    // perform 3pt square fit of peak
    estimateSmallFingerOnEdgeSize3PtFit(zx, zy, &xVectorParams, &yVectorParams, &size);

    // average x and y height estimates
    // this cannot overflow
    //               0xFFFE8001 = (           0xFFFF    *    0xFFFF    +  0x8000)
    interpolatedHeight = (uint16)(((uint32)size.x.height*size.y.height + zPeak/2)/zPeak);
    interpolatedHeight = (uint16)(((uint32)interpolatedHeight*5 + 2) >> 2);
  }
  else
  {
    // perform 3pt,2pt rectangular fit of peak
    estimateSmallFingerCornerSize3PtFit(zx, zy, &xVectorParams, &yVectorParams, &size);

    // average x and y height estimates
    // these cannot overflow
    //               0xFFFE8001 = (    0xFFFF   *    0xFFFF    +  0x8000)
    interpolatedHeight = (uint16)(((uint32)zPeak*size.x.height + zxMax/2)/zxMax);
    interpolatedHeight = (uint16)(((uint32)interpolatedHeight*size.y.height + zyMax/2)/zyMax);
    interpolatedHeight = (uint16)(((uint32)interpolatedHeight*10 + 3)/6);
  }

  // then do the diagonal axes
  estimateSmallFingerDiagonalSize3PtFit(z45, z315, &size);

  // convert all 16-bit values to 8-bit values needed in soFeatures
  // relativeAmplitude goes to 0.8
  relativeAmplitude32 = ((uint32)interpolatedHeight << 8) + (uint16)params->cSat_LSB/2;
  if (params->cSat_LSB > 0) relativeAmplitude32 /= (uint16) params->cSat_LSB;
  soFeatures->relativeAmplitude = (uint16) SOD_MIN(254, relativeAmplitude32);

  // area goes to 2.6
  // note that 0xFFFF*0xFFFF + 0x800 = 0xFFFE0801, so this cannot overflow
  area32 = ((uint32) size.x.width * size.y.width + 0x800) >> 12;  // now 20.12
  area32 -= 0x900; // widths both >= 0xC00 (3/4 in 1.12) -> area >= 0x900 (9/16 in 1.12),
                   // adjust area to increase dynamic range in 2p6 bit precision
  area16 = (uint16) SOD_MIN(0x3FDF, area32); // now 2.12 -- clip at 0x3FFF - 0x20
  area16 = (area16 + 0x20) >> 6;
  soFeatures->area = (area16 == 0) ? 1 : area16; // save one bit to signify area has been calculated

  // maxDiagonalWidth goes to 2.6
  maxDiagonalWidth32 = SOD_MAX(size.diag45.width, size.diag315.width); // now 20.12
  maxDiagonalWidth16 = (uint16) SOD_MIN(0x3FDF, maxDiagonalWidth32); // now 2.12 -- clip at 0x3FFF - 0x20
  soFeatures->maxDiagonalWidth = (maxDiagonalWidth16 + 0x20) >> 6;

  // maxXYWidth goes to 2.6
  maxXYWidth32 = (uint32) SOD_MAX(size.x.width, size.y.width); // now 20.12
  maxXYWidth16 = (uint16) SOD_MIN(0x3FDF, maxXYWidth32); // now 2.12 -- clip at 0x3FFF - 0x20
  soFeatures->maxXYWidth = (maxXYWidth16 + 0x20) >> 6;
}

/* -----------------------------------------------------------
Name: isPointInRegion()
Purpose: Checks to see if a point is in the region defined
         by a polygon.
Inputs: p - the point to check
        vertices - array of vertex pairs
        len - length of array
Outputs: returns 0 if the point is not in the region, 1 if it is
Notes: Vertices in the -area direction from the point are not
       looked at and can be left out of the array.
----------------------------------------------------------- */
static uint16 isPointInRegion(smallObjectDetectorRegion_t *p, smallObjectDetectorRegion_t *vertices, uint16 len)
{
  /* this algorithm casts a ray from p in the +area direction and
   * counts crossings of segments in the polygon. If the number of
   * crossings is odd, then the point is in the polygon.
   */

  uint16 crossings = 0;
  uint4p12 area0, area1;
  uint0p16 amp0, amp1;
  uint16 i;
  smallObjectDetectorRegion_t *v = vertices;

  if (len < 2)
  {
    return 0;
  }

  area0 = v->area;
  amp0 = v->amplitude;
  v++;

  for (i = 1; i < len; i++, v++)
  {
    area1 = v->area;
    amp1 = v->amplitude;

    if (p->amplitude < amp0 || p->amplitude < amp1)
    {
      uint8p8 alpha;
      uint16 num;
      uint16 den;
      uint4p12 areaCrossing;
      num = p->amplitude - amp0;
      den = amp1 - amp0;
      if (den != 0)
      {
        alpha = (uint8p8) ((((uint32) num << 8) + (den >> 1)) / den);
        if (alpha < 0x100)
        {
          areaCrossing = (uint16) (((uint32) (0x100 - alpha) * area0 + 0x80) >> 8) +
                         (uint16) (((uint32) alpha * area1 + 0x80) >> 8);
          if (areaCrossing > p->area)
          {
            crossings++;
          }
        }
      }
    }
    area0 = area1;
    amp0 = amp1;
  }
  return (crossings & 0x1);
}

/* -----------------------------------------------------------------
Name: eraserPerformanceImprove
Purpose: Improve the performance of eraser & 1mm/2.5mm stylus, make the boundary clearer.
Inputs: relativeAmplitude32
Outputs: converted relativeAmplitude
Effects: None
Notes: called by smallObjectDetector_detect
------------------------------------------------------------------ */
static uint16 eraserPerformanceImprove(uint16 amp, uint16 rate, uint16 delta)
{
  uint32 local_amp;
  local_amp = ((uint32)amp * rate) >> 8;
  local_amp = (local_amp > (delta + 10)) ? (local_amp - delta) : 10;
  return (local_amp > 254) ? 254 : (uint16)local_amp;
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: smallObjectDetector_detect()
Purpose: Determines whether an object is a touching small finger
         or not
Inputs: params - sensor parameters
        deltaImage
        peakLoc - the location of the blob's peak pixel
        soCfg - the classifier configuration values
        hystFlag - set true if this object was a small finger on
                   the previous frame.
Outputs: returns a smallObjectClass_t which is any of smallObjectClass_none,
                smallObjectClass_touchingSmallObject, or
                smallObjectClass_wideSmallObject
         soFeatures - struct containing the calculated relative
                      amplitude, area, max width, and max diagonal
                      width for classifier tuning.
----------------------------------------------------------- */
uint16 smallObjectDetector_detect(sensorParams_t *params, int16 *deltaImage,
                                  pixelIndex_t peakLoc, smallObjectDetectorConfig_t *soCfg,
                                  int16 hystFlag, smallObjectFeatures_t *soFeatures,
                                  uint16 lastClass)
{
  smallObjectClass_t objClass;
  uint32 previousArea = soFeatures->area;

  measureSmallFingerFeatures(params, deltaImage, peakLoc, soFeatures);

  if (previousArea > 0)
  {
    previousArea *= 2;
    previousArea += soFeatures->area;
    previousArea += 1;
    soFeatures->area = previousArea / 3;
  }

  // classify the finger as touching, hovering, or unknown.

  // The decision boundary is defined as a polygon. Points within the
  // polygon are considered touching objects. Points outside are not.
  // In addition, if the width exceeds a threshold in any direction,
  // then the object could be a long, skinny object like a headphone
  // cable and is rejected.

  {
    uint4p12 maxSmallObjectWidth = soCfg->maxSmallObjectWidth;
    uint4p12 maxDiagonalSmallObjectWidth = soCfg->maxDiagonalSmallObjectWidth;
    uint16 isInRegion, isInRegionStylus, isInRegionEraser;

    if (hystFlag)
    {
      uint16 widthHysteresis = soCfg->widthHysteresis << 2;
      maxSmallObjectWidth = (uint16) (((uint32) maxSmallObjectWidth * widthHysteresis) >> 8);
      maxDiagonalSmallObjectWidth = (uint16) (((uint32) maxDiagonalSmallObjectWidth * widthHysteresis) >> 8);
    }

    {
      smallObjectDetectorRegion_t *region;
      smallObjectDetectorRegion_t point[1];

      memset16(point, 0, sizeof(*point) / sizeof(uint16));
      point->area = soFeatures->area;
      //
      // just a test, I found the difference on amplitude is not large enough to distinguish the 1mm/2.5mm stylus and eraser.
      // It seems the large difference I saw before is a mistake in TAC...
      // Just try this conversion, that, amp = amp * rate - delta, e.g. amp = amp * 4 - 0x80.
      // currently rate & delta are set in the config file, it should be able to tune in DS5 in future.
      //
      point->amplitude = eraserPerformanceImprove(soFeatures->relativeAmplitude, soCfg->eraserPerfImproveRate, soCfg->eraserPerfImproveDelta);
      region = hystFlag ? soCfg->hystRegion : soCfg->region;

      isInRegion = isPointInRegion(point, region, IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE);

      // check for styluses
      if (lastClass == smallObjectClass_stylus)
      {
        region = soCfg->stylusHystRegion;
      }
      else
      {
        region = soCfg->stylusRegion;
      }
      isInRegionStylus = isPointInRegion(point, region, IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE);

      // check for erasers
      if (lastClass == smallObjectClass_eraser)
      {
        region = soCfg->eraserHystRegion;
      }
      else
      {
        region = soCfg->eraserRegion;
      }
      isInRegionEraser = isPointInRegion(point, region, IFP_SMALL_OBJECT_DETECTOR_REGION_SIZE);
    }

    // reject hovering fingers and headphone cables outright
    if (soFeatures->maxXYWidth > maxSmallObjectWidth ||
        soFeatures->maxDiagonalWidth > maxDiagonalSmallObjectWidth)
    {
      objClass = smallObjectClass_wideSmallObject;
    }
    // otherwise, if the peak amplitude is high enough for this size
    // object, then it's touching
    else if (isInRegionStylus && isInRegionEraser)
    {
      objClass = lastClass;
    }
    else if (isInRegionStylus)
    {
      objClass = smallObjectClass_stylus;
    }
    else if (isInRegionEraser)
    {
      objClass = smallObjectClass_eraser;
    }
    else if (isInRegion)
    {
      objClass = smallObjectClass_touchingSmallObject;
    }
    else
    {
      objClass = smallObjectClass_none;
    }
  }
  return objClass;
}

#endif // CONFIG_HAS_SMALL_OBJECT_DETECTOR
