
#ifndef _DISPLAY_NOISE_REMOVER_H_
#define _DISPLAY_NOISE_REMOVER_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: display_noise_remover.h
// Description: Header file for display_noise_remover.c
//
// $Id:$

static ATTR_INLINE void displayNoiseRemover_init() {};
static ATTR_INLINE void displayNoiseRemover_reinit() {};

#if !CONFIG_HAS_HYBRID && !CONFIG_HAS_RX_MUXING && CONFIG_HAS_DISPLAY_NOISE_REMOVER
void displayNoiseRemover_configure(sensorParams_t *sensorParams, displayNoiseRemoverConfig_t *extConfig);
void displayNoiseRemover_remove(sensorParams_t *sensorParams, uint16 inhibitGlobalMedian, int16 *deltaImage);
#else
static ATTR_INLINE void displayNoiseRemover_configure(ATTR_UNUSED sensorParams_t *sensorParams, ATTR_UNUSED displayNoiseRemoverConfig_t *extConfig) {};
static ATTR_INLINE void displayNoiseRemover_remove(ATTR_UNUSED sensorParams_t *sensorParams, ATTR_UNUSED uint16 inhibitGlobalMedian, ATTR_UNUSED int16 *deltaImage) {};
#endif // !CONFIG_HAS_HYBRID


#endif  //_DISPLAY_NOISE_REMOVER_H_
