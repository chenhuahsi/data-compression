// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2014  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: thick_glove.cpp
// Description: Process classifications and abs delta profiles to extract thick glove information.
//  $Id:

#include "ifp_common.h"

#if CONFIG_HAS_THICK_GLOVE
#include "single_finger.h"
#include "thick_glove.h"

#if !defined(cfg_THICK_GLOVE_DEBUG)
#define cfg_THICK_GLOVE_DEBUG 0
#endif

//#define THICK_GLOVE_PERSISTENCE_MSECS 200
//#define THICK_GLOVE_HOLDOFF_FACTOR 2

#define THICK_GLOVE_PERSISTENCE_FRAMES_ACTIVE_MODE 16
#define THICK_GLOVE_PERSISTENCE_FRAMES_DOZE_MODE 1

// configuration parameters
static int16 thickGlovePersistenceFrames;  // # frames thick glove must persist before entering thick glove present state

typedef struct
{
  thick_glove_t previousFramePresence;
  thick_glove_t presence;
  int16 counter;
#if cfg_THICK_GLOVE_DEBUG
  int16 debugCounters[6];
#endif
} thick_glove_state_t;

static thick_glove_state_t thickGloveState;
/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/
//static int16 is_thick_glove_present() ATTR_THREAD(_thr_Calculation);
static void thick_glove_process(int16 thickGloveObjectPossible) ATTR_THREAD(_thr_Calculation);

/* -----------------------------------------------------------------
Name: void thick_glove_init()
Purpose: Initialize the module.
Inputs:
Outputs:
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void thick_glove_init(void)
{
  thickGloveState.presence = no_thick_glove;
  thickGloveState.previousFramePresence = no_thick_glove;
  thickGloveState.counter = THICK_GLOVE_PERSISTENCE_FRAMES_ACTIVE_MODE;
  thickGlovePersistenceFrames = THICK_GLOVE_PERSISTENCE_FRAMES_ACTIVE_MODE;
}

/* -----------------------------------------------------------------
Name: void thick_glove_reinit()
Purpose: Re-initialize the thick glove processor
Inputs:
Outputs:
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void thick_glove_reinit()
{
  thick_glove_init();
}

/* -----------------------------------------------------------------
 * Name: void thick_glove_configure()
 * Purpose: Configure the module.
 * Inputs: config parameters
 * Outputs: None
 * Effects: None.
 * Notes:
 * Example: None.
 * ----------------------------------------------------------------- */
void thick_glove_configure(singleFingerConfig_t * sfConfig)
{
  thickGlovePersistenceFrames = sfConfig->thickGlovePersistenceFrames;
}

/* -----------------------------------------------------------------
Name: get_thick_glove_present()
Purpose: Find out if thick glove is present or not; returns true even if
         there is just a possibility of thick glove
Inputs: None
Outputs: bool
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void get_thick_glove_present(int16* data_present)
{
  *data_present = (uint16)((thickGloveState.presence == thick_glove_detected) ||
          (thickGloveState.previousFramePresence == thick_glove_detected));
}

/* -----------------------------------------------------------------
Name: thick_glove_process()
Purpose: process thick glove, determining thick glove state
Inputs: possible thick glove flag; set if abs single finger shows finger
        but classifier shows no finger and no glove
Outputs: None
Effects: Updates delta statistics.
Notes: Processes and changes thick glove state if need be
Example: None.
----------------------------------------------------------------- */
static void thick_glove_process(int16 thickGloveObjectPossible)
{
  thickGloveState.previousFramePresence = thickGloveState.presence;

  if(thickGloveObjectPossible)
  {
    if(thickGloveState.presence == no_thick_glove)
    {
      #if cfg_THICK_GLOVE_DEBUG
      thickGloveState.debugCounters[0]++;
      #endif

      thickGloveState.presence = thick_glove_possible;
    }

    if (thickGloveState.presence == thick_glove_possible)
    {
      thickGloveState.counter--;
      if(!thickGloveState.counter)
      {
        thickGloveState.presence = thick_glove_detected;
        #if cfg_THICK_GLOVE_DEBUG
        thickGloveState.debugCounters[1]++;
        #endif
        thickGloveState.counter = thickGlovePersistenceFrames;
      }
    }
  }
  else // No Thick Glove Object Possible
  {
    if(thickGloveState.presence == thick_glove_detected)
    {
      thickGloveState.counter--;
      if(!thickGloveState.counter)
      {
        thickGloveState.presence = no_thick_glove;
        #if cfg_THICK_GLOVE_DEBUG
        thickGloveState.debugCounters[2]++;
        #endif
        thickGloveState.counter = thickGlovePersistenceFrames;
      }
    }
    else if (thickGloveState.presence == thick_glove_possible)
    {
      thickGloveState.counter++;
      if (thickGloveState.counter >= thickGlovePersistenceFrames)
      {
        thickGloveState.presence = no_thick_glove;
        #if cfg_THICK_GLOVE_DEBUG
        thickGloveState.debugCounters[3]++;
        #endif
      }
    }
  }
}
int16 thickGloveHold;
/* -----------------------------------------------------------------
Name: doThickGloveProcessing()
Purpose: process classifications and hybrid deltas to detect thick glove presence
         if there is thick glove, determine a position using hybrid delta profiles
Inputs: classifications, profiles
Outputs: up to 2 finger positions ((0,0) if no finger) ;
         returns # of single fingers detected if thick glove possible << 1 | fresh data flag;
         fresh data + 0 fingers indicates single finger lift
         returns 0 otherwise
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void doThickGloveProcessing(sensorParams_t *sensorParams, int16 * deltaX, int16 * deltaY,
           classification_t *classifications, sensorPosition_t *SFSensorPositions, int16 *thickGloveSFResult)
{
  int16 thickGloveObjectPossible = 1;
  uint16 thickGlovePresent = 0;
  int16 objIdx = 0;
  if(!deltaX || !deltaY) {
    *thickGloveSFResult = 0;
  }

  for (objIdx = 0; objIdx < MAX_OBJECTS; objIdx++) {
    // We first look for any object detected in IFP
    if((classifications[objIdx].touchType != touchType_none) &&
       (classifications[objIdx].touchFlag == 1)) {
     /*
      * Do not process thick glove under following conditions
      * --> IFP detects anything other than hybrid glove
      * Process thick glove under following conditions
      * --> If already in thick glove detected phase and current IFP object is Hybrid Glove
      */
      get_thick_glove_present(&thickGlovePresent);
      if (thickGlovePresent) {
        if ((classifications[objIdx].touchType != touchType_glove)) {
          thickGloveObjectPossible = 0;
          // Reset thick glove state when any object touches
          thick_glove_init();
          /*
           * If already in thick glove mode and IFP detects saturated finger
           * we set hover flag to be 1 so that lift event becomes necessary
           * before next thick glove detection is triggered
           */
//            hoverFlag = 1;
        }
      } else {
        thickGloveObjectPossible = 0;
        // Reset thick glove state when any object touches
        thick_glove_init();
      }
      #if cfg_THICK_GLOVE_DEBUG
        thickGloveState.debugCounters[5]++;
      #endif
      break;
    }
  }
  if(!thickGloveObjectPossible) thickGloveHold = 1;

  if(thickGloveObjectPossible) {
    // clear single finger sensor position report
//    uint16 * s = (uint16*)SFSensorPositions;
//    uint16 size = (sizeof(sensorPosition_t)*2)/sizeof(uint16);
//    do{ *s++ = 0;} while (--size);
    thickGloveObjectPossible = SF_process(deltaX, sensorParams->rxCount, deltaY, sensorParams->txCount, SF_dynamic_threshold_high, SUPPRESS_REPORT_IF_MORE_THAN_ONE, SF_thickGlove_client, SFSensorPositions);  // returns # fingers << 1 | freshData
  }

  if(thickGloveHold) thickGloveObjectPossible = false;

  // update state
  thick_glove_process(thickGloveObjectPossible >> 1); // if single finger detected
  get_thick_glove_present(&thickGlovePresent);
  if (thickGlovePresent) {
    if (thickGloveObjectPossible & 0x02) {
      classifications[0].touchType = touchType_glove;
      classifications[0].touchFlag = 1;
    }
    *thickGloveSFResult = thickGloveObjectPossible;
  }
  else
  {
    *thickGloveSFResult = 0;
  }
}
#endif
