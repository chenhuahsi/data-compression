// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: profile_baseline_updater.c
// Description: Adjusts the baseline to compensate for thermal drift and slow
//              environmental changes, and also to remove false artifacts caused
//              by baseline acquisition with moisture or object on the sensor
// $Id:$

/* =================================================================
   MODULE INCLUDES
==================================================================*/

#include "ifp_common.h"

#if CONFIG_HAS_HYBRID

#include "ifp_string.h"
#include "profile_baseline_updater.h"

/* =================================================================
   MODULE MACROS
==================================================================*/

#define min(a, b) (((a) > (b)) ? (b) : (a))

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static int16 thermalUpdateTimerX_ms;  //  time in thermal mode modulo update interval
static int16 thermalUpdateTimerY_ms;  //  time in thermal mode modulo update interval

// sensor parameters
static uint16 txCountAbs;  // number of used TXs; assume the same value between abs and trans
static uint16 rxCountAbs;  // number of used RXs; assume the same value between abs and trans

// configuration knobs
static int16 thermalUpdateIntervalX_ms;  // interval between thermal baseline updates
static int16 thermalUpdateIntervalY_ms;  // interval between thermal baseline updates
static int16 fastHalflifeAbs_ms;         // fast relax half-life

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/

/* local function prototypes */
static void removeOrZero(uint16 *rawProfile, uint16 *blPtr, uint16 blAcquired,
                         int16 *deltaProfile, uint16 maxSize, uint16 size);
static void relaxNCounts(uint16 *profile, uint16 nMax, uint16 arrayLength, uint16 *blEstimate);
static void applyExponentialDamping(uint16 frameTime_ms, uint16 *rawProfile, uint16 arrayLength, uint16 *blEstimate);

/* -----------------------------------------------------------------
Name: profileBaselineUpdater_init()
Purpose: Initialize the module.
Inputs:
Outputs:
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void profileBaselineUpdater_init(void)
{
  thermalUpdateTimerX_ms = 0;
  thermalUpdateTimerY_ms = 0;
}

/* -----------------------------------------------------------------
Name: profileBaselineUpdater_reinit()
Purpose: Re-initialize the Baseline Estimate.
Inputs:
Outputs:
Effects: None.
Notes: Resets baseline state to 'start'
Example: None.
----------------------------------------------------------------- */
void profileBaselineUpdater_reinit(void)
{
  thermalUpdateTimerX_ms = 0;
  thermalUpdateTimerY_ms = 0;
}

/* -----------------------------------------------------------------
Name: profileBaselineUpdater_configure()
Purpose: Configure the Baseline Updater module.
Inputs: thermalUpdateInterval_ms   - time between 1 LSB for slow relaxations
        fastHalflifeAbs_ms         - decay half-life of delta profile in fast
                                     relaxation
Outputs: None
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void profileBaselineUpdater_configure(sensorParams_t *sensorParams, profileBaselineUpdaterConfig_t *config)
{
  thermalUpdateIntervalX_ms = config->thermalUpdateIntervalX_ms;
  thermalUpdateIntervalY_ms = config->thermalUpdateIntervalY_ms;
  fastHalflifeAbs_ms = config->fastHalflife_ms;
  txCountAbs = sensorParams->txCount;
  rxCountAbs = sensorParams->rxCount;
}

/* -----------------------------------------------------------------
Name: profileBaselineUpdater_removeX(rawXProfile, absXaseline, deltaXProfile)
Purpose: Removes the baseline from the raw profile to create the delta profile
Inputs: raw profile
Outputs: pointer to modified delta profile or NULL
Effects: None.
Notes: deltaXProfile is an int16 array of size MAX_ABS_RX. Return NULL if
       rawProfile is NULL. If baseline unacquired, instead zero the delta array.
Example: None.
------------------------------------------------------------------- */
int16 *profileBaselineUpdater_removeX(uint16 *rawXProfile, absXBaseline_t *absXBaseline, int16 *deltaXProfile)
{
  if (MAX_ABS_RX == 1 || rawXProfile == NULL)
  {
    return NULL;
  }
  removeOrZero(rawXProfile, absXBaseline->estimate, absXBaseline->acquired, deltaXProfile, MAX_ABS_RX, rxCountAbs);
  return deltaXProfile;
}

/* -----------------------------------------------------------------
Name: profileBaselineUpdater_updateX
Purpose: Adjust baseline to compensate for drift, hold if an object is on the sensor,
         or damp away detected errors.
Inputs: relax command (relaxCommand_t enum), time since last frame (ms), raw abs profile, abs baseline
Outputs: None
Effects: Adjusts the baseline in-place.
Notes:
Example: None.
----------------------------------------------------------------- */
void profileBaselineUpdater_updateX(uint16 relaxCommand, uint16 frameTime_ms, uint16 *rawXProfile, absXBaseline_t *absXBaseline)
{
  if (MAX_ABS_RX == 1 || rawXProfile == NULL) return;

  /* update baseline */
  switch (relaxCommand)
  {
    case relaxCommand_thermal:
      /* mostly 0 with a +/- 1 correction every so often; allow more if long sampling times like during doze */
      thermalUpdateTimerX_ms += frameTime_ms;
      if (thermalUpdateTimerX_ms >= thermalUpdateIntervalX_ms)
      {
        relaxNCounts(rawXProfile, (uint16) thermalUpdateTimerX_ms / thermalUpdateIntervalX_ms, rxCountAbs, absXBaseline->estimate);
        thermalUpdateTimerX_ms %= thermalUpdateIntervalX_ms;
      }
      break;
    case relaxCommand_frozen:
      thermalUpdateTimerX_ms = 0;
      break;
    case relaxCommand_fast:
      applyExponentialDamping(frameTime_ms, rawXProfile, rxCountAbs, absXBaseline->estimate);
      thermalUpdateTimerX_ms = 0;
      break;
    case relaxCommand_rezero:
      memcpy16(absXBaseline->estimate, rawXProfile, rxCountAbs);
      memset16(&absXBaseline->estimate[rxCountAbs], 0, MAX_ABS_RX - rxCountAbs);
      absXBaseline->acquired = 1;
      thermalUpdateTimerX_ms = 0;
      break;
  }
}

/* -----------------------------------------------------------------
Name: profileBaselineUpdater_removeY(rawYProfile, absYaseline, deltaYProfile)
Purpose: Removes the baseline from the raw profile to create the delta profile
Inputs: raw profile
Outputs: pointer to modified delta profile or NULL
Effects: None.
Notes: deltaYProfile is an int16 array of size MAX_ABS_TX. Return NULL if
       rawProfile is NULL. If baseline unacquired, instead zero the delta array.
Example: None.
------------------------------------------------------------------- */
int16 *profileBaselineUpdater_removeY(uint16 *rawYProfile, absYBaseline_t *absYBaseline, int16 *deltaYProfile)
{
  if (MAX_ABS_TX == 1 || rawYProfile == NULL)
  {
    return NULL;
  }
  removeOrZero(rawYProfile, absYBaseline->estimate, absYBaseline->acquired, deltaYProfile, MAX_ABS_TX, txCountAbs);
  return deltaYProfile;
}

/* -----------------------------------------------------------------
Name: profileBaselineUpdater_updateY
Purpose: Adjust baseline to compensate for drift, hold if an object is on the sensor,
         or damp away detected errors.
Inputs: relax command (relaxCommand_t enum), time since last frame (ms), raw abs profile, abs baseline
Outputs: None
Effects: Adjusts the baseline in-place.
Notes:
Example: None.
----------------------------------------------------------------- */
void profileBaselineUpdater_updateY(uint16 relaxCommand, uint16 frameTime_ms, uint16 *rawYProfile, absYBaseline_t *absYBaseline)
{
  if (MAX_ABS_TX == 1 || rawYProfile == NULL) return;

  /* update baseline */
  switch (relaxCommand)
  {
    case relaxCommand_thermal:
      /* mostly 0 with a +/- 1 correction every so often; allow more if long sampling times like during doze */
      thermalUpdateTimerY_ms += frameTime_ms;
      if (thermalUpdateTimerY_ms >= thermalUpdateIntervalY_ms)
      {
        relaxNCounts(rawYProfile, (uint16) thermalUpdateTimerY_ms / thermalUpdateIntervalY_ms, txCountAbs, absYBaseline->estimate);
        thermalUpdateTimerY_ms %= thermalUpdateIntervalY_ms;
      }
      break;
    case relaxCommand_frozen:
      thermalUpdateTimerY_ms = 0;
      break;
    case relaxCommand_fast:
      applyExponentialDamping(frameTime_ms, rawYProfile, txCountAbs, absYBaseline->estimate);
      thermalUpdateTimerY_ms = 0;
      break;
    case relaxCommand_rezero:
      memcpy16(absYBaseline->estimate, rawYProfile, txCountAbs);
      memset16(&absYBaseline->estimate[txCountAbs], 0, MAX_ABS_TX - txCountAbs);
      absYBaseline->acquired = 1;
      thermalUpdateTimerY_ms = 0;
      break;
  }
}

/* -----------------------------------------------------------------
Name: removeOrZero(rawProfile, absBaseline, deltaProfile, maxSize, size)
Purpose: Removes the baseline from the raw profile to create the delta profile
Inputs: raw profile, baseline struct, delta array, max size (MAX_ABS_{RX,TX}), size ({rx,tx}Count)
Outputs: pointer to modified delta profile
Effects: None.
Notes: deltaProfile is an int16 array of size size. If baseline unacquired,
       instead zero the delta array.
Example: None.
------------------------------------------------------------------- */
static void removeOrZero(uint16 *rawProfile, uint16 *blPtr, uint16 blAcquired, int16 *deltaProfile, uint16 maxSize, uint16 size)
{
  if (blAcquired)
  {
    int16 *deltaPtr = deltaProfile;
    uint16 i;
    for (i = 0; i < size; i++)
    {
      int16 delta = *rawProfile - *blPtr;
      if (*rawProfile++ >= *blPtr++)
      {
        *deltaPtr++ = (delta < 0) ? 32767 : delta;
      }
      else
      {
        *deltaPtr++ = (delta < 0) ? delta : -32768;
      }
    }
  }
  else
  {
    int16 *deltaPtr = deltaProfile;
    uint16 i;
    for (i = 0; i < maxSize; i++)
    {
      *deltaPtr++ = 0;
    }
  }
}

/* ---------------------------------------------------------------------
Name: relaxNCounts
Purpose: Clip the delta profile to max magnitude nMax, then subtract blEstimate
Inputs: raw profile, max number of counts to relax, array length, baseline estimate
Outputs: None
Effects: Modifies baseline estimate in-place
Note: Internal to this file only.
---------------------------------------------------------------------- */
static void relaxNCounts(uint16 *profile, uint16 nMax, uint16 arrayLength, uint16 *blEstimate)
{
  uint16 i;
  for (i = 0; i < arrayLength; i++, blEstimate++, profile++)
  {
    int16 delta =  *profile - *blEstimate;
    if (delta > 0)
    {
      *blEstimate += min(nMax, (uint16) delta);
    }
    else
    {
      *blEstimate -= min(nMax, (uint16) -delta);
    }
  }
}

/* ---------------------------------------------------------------------
Name: applyExponentialDamping
Purpose: Exponentially damp delta image by adjusting the baseline
Inputs: sampling interval, raw profile, array length, baseline profile
Outputs: None
Effects: Modifies blEstimate in-place
Note: Internal to this file only.
---------------------------------------------------------------------- */
static void applyExponentialDamping(uint16 frameTime_ms, uint16 *rawProfile, uint16 arrayLength, uint16 *blEstimate)
{
  uint16 i;

  /* approximate ln(2) / fastHalflifeAbs_ms as 0p16
     http://www.wolframalpha.com/input/?i=Log%5B2%5D+*+2%5E16 */
  uint32 gain = 45426u * (uint32) frameTime_ms / fastHalflifeAbs_ms;  // 16p16
  /* clip gain below unity to prevent amplification */
  if (gain >= 0xFFFF)
  {
    gain = 0xFFFF;
  }

  for (i = 0; i < arrayLength; i++, blEstimate++, rawProfile++)
  {
    int16 delta = *rawProfile - *blEstimate;
    if (delta > 0)
    {
        uint16 correction = ((uint32) gain * (uint16) delta) >> 16; // 0p16 * 16p0 -> 16p0
        *blEstimate += (correction > 0) ? correction : 1;  // be sure to get that last ADC count
    }
    else if (delta < 0)
    {
        uint16 correction = ((uint32) gain * (uint16) (-delta)) >> 16; // 0p16 * 16p0 -> 16p0
        *blEstimate -= (correction > 0) ? correction : 1;  // be sure to get that last ADC count
    }
  }
}

#endif // CONFIG_HAS_HYBRID
