#ifndef _PROFILE_BASELINE_UPDATER_H_
#define _PROFILE_BASELINE_UPDATER_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: profile_baseline_updater.h
// Description: Interface for profile baseline updater
// $Id:$

#include "ifp_common.h"

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

#if CONFIG_HAS_HYBRID
void profileBaselineUpdater_init(void);
void profileBaselineUpdater_reinit(void);
void profileBaselineUpdater_configure(sensorParams_t *sensorParams, profileBaselineUpdaterConfig_t *config);
int16 *profileBaselineUpdater_removeX(uint16 *rawXProfile, absXBaseline_t *absXBaseline, int16 *deltaXProfile);
void profileBaselineUpdater_updateX(uint16 relaxCommand, uint16 frameTime_ms, uint16 *rawXProfile, absXBaseline_t *absXBaseline);
int16 *profileBaselineUpdater_removeY(uint16 *rawYProfile, absYBaseline_t *absYBaseline, int16 *deltaYProfile);
void profileBaselineUpdater_updateY(uint16 relaxCommand, uint16 frameTime_ms, uint16 *rawYProfile, absYBaseline_t *absYBaseline);
#else
static ATTR_INLINE void profileBaselineUpdater_init(void) {};
static ATTR_INLINE void profileBaselineUpdater_reinit(void) {};
static ATTR_INLINE void profileBaselineUpdater_configure(ATTR_UNUSED sensorParams_t *sensorParams, ATTR_UNUSED profileBaselineUpdaterConfig_t *config) {};
static ATTR_INLINE int16 *profileBaselineUpdater_removeX(ATTR_UNUSED uint16 *rawXProfile, ATTR_UNUSED absXBaseline_t *absXBaseline, ATTR_UNUSED int16 *deltaXProfile) { return NULL; };
static ATTR_INLINE void profileBaselineUpdater_updateX(ATTR_UNUSED uint16 relaxCommand, ATTR_UNUSED uint16 frameTime_ms, ATTR_UNUSED uint16 *rawXProfile, ATTR_UNUSED absXBaseline_t *absXBaseline) {};
static ATTR_INLINE int16 *profileBaselineUpdater_removeY(ATTR_UNUSED uint16 *rawYProfile, ATTR_UNUSED absYBaseline_t *absYBaseline, ATTR_UNUSED int16 *deltaYProfile) { return NULL; };
static ATTR_INLINE void profileBaselineUpdater_updateY(ATTR_UNUSED uint16 relaxCommand, ATTR_UNUSED uint16 frameTime_ms, ATTR_UNUSED uint16 *rawYProfile, ATTR_UNUSED absYBaseline_t *absYBaseline) {};
#endif // CONFIG_HAS_HYBRID

#endif  //_PROFILE_BASELINE_UPDATER_H_

