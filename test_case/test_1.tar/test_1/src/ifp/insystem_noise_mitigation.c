/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: hybrid nosie mitigation main module.
   $Id: filter_noise_blobs.h,v 1.1.4.3 2013/03/29 19:51:20 rfreeze Exp $
----------------------------------------------------------------- */
#include "ifp_common.h"

#include "profile_baseline_updater.h"
#include "insystem_noise_mitigation.h"

#if CONFIG_HAS_HYBRID_CHARGER_NOISE_MITIGATION
static uint16 mitigate;

#if defined (HYBRID_CHARGER_NOISE_MITIGATION_DEBUG) && (HYBRID_CHARGER_NOISE_MITIGATION_DEBUG)
int16 nHybridImage[MAX_TX][MAX_RX];
#endif

void hybridChargerNoiseMitigation_configure(hybridChargerNoiseMitigationConfig_t *config)
{
  mitigate = config->enable;
}

/* -----------------------------------------------------------
Name    : hybridNoiseMitigation
Purpose : Scale transCap delta by abs profile when noise is present
          to create new image for IFP.
Note    : FW-40707.
          Abs delta is assumed to be less susceptible to charger noise
          than transCap. Hybrid Tx Axis should be enabled.
          Config option
            - HYBRID_NOISE_MITIGATION
            - HYBRID_NOISE_MITIGATION_DEBUG
----------------------------------------------------------- */
void hybridChargerNoiseMitigation_filter(sensorParams_t* pParams, int16* pDeltaImage, int16* pDeltaYProfile)
{
  uint16 maxRxCnt = pParams->rxCount;
  uint16 maxTxCnt = pParams->txCount;
  uint16 uRxCnt;
  uint16 uTxCnt;
  uint16 uIndex;
  int16  deltaYProfileMax;
  uint16 stride = MAX_RX - maxRxCnt;

  if(mitigate) {
  #if defined (HYBRID_CHARGER_NOISE_MITIGATION_DEBUG) && (HYBRID_CHARGER_NOISE_MITIGATION_DEBUG)
  for (uTxCnt = 0; uTxCnt < maxTxCnt; uTxCnt++)
  {
    nHybridImage[uTxCnt][0] = pDeltaYProfile[uTxCnt];
  }
  #endif

  // find max profile location to normalize multiplication factor.
  deltaYProfileMax = 1;
  for (uTxCnt = 0; uTxCnt < maxTxCnt; uTxCnt++)
  {
    if (pDeltaYProfile[uTxCnt] > 0)
    {
      if (pDeltaYProfile[uTxCnt] > deltaYProfileMax)
      {
        deltaYProfileMax = pDeltaYProfile[uTxCnt];
      }
    }
    else
    {
      // ignore any negative delta perturbation.
      pDeltaYProfile[uTxCnt] = 0;
    }
  }

  // apply profile based scale factor to transCap along the receiver.
  uIndex = MAX_RX + 2;
  for (uTxCnt = 0; uTxCnt < maxTxCnt; uTxCnt++)
  {
    for (uRxCnt = 0; uRxCnt < maxRxCnt; uRxCnt++ )
    {
      pDeltaImage[uIndex] = (int16)(((int32)pDeltaImage[uIndex] * pDeltaYProfile[uTxCnt]) / deltaYProfileMax);

      #if defined (HYBRID_CHARGER_NOISE_MITIGATION_DEBUG) && (HYBRID_CHARGER_NOISE_MITIGATION_DEBUG)
      if (uRxCnt > 0)
      {
        nHybridImage[uTxCnt][uRxCnt] = pDeltaImage[uIndex];
      }
      #endif

      uIndex++;
    }
    uIndex += (stride + 1);
  }
  }
}
#endif // CONFIG_HAS_HYBRID_CHARGER_NOISE_MITIGATION
