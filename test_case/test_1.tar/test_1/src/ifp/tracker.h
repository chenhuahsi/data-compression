// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// $Id: tracker.h,v 1.4.44.1 2012/12/11 02:58:05 jjordan Exp $

#ifndef _TRACKER_H_
#define _TRACKER_H_

#include "ifp_common.h"

trackedObject_t *tracker_track(int16 *deltaImage, clumps_t *clumps,
                               uint16 timeSinceLast_ms, sensorParams_t *sensorParams);
void tracker_init();
void tracker_reinit();
void tracker_configure(trackerConfig_t *config);

#if CONFIG_HAS_LGM_MERGER
void tracker_first_drawer(void);
void tracker_next_drawer(void);
#endif

#endif
