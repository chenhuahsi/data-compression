#ifndef _IFP_BIT_MANIPULATION_H_
#define _IFP_BIT_MANIPULATION_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: ifp_bit_manipulation.h
// Description: Bit fields (objectBitmask_t) manipulation function library
//              Note: because functions are inline, they are defined in the .h

#include "ifp_common.h"   //For objectBitmask_t type

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* -----------------------------------------------------------
Name: powerOfTwo
Purpose: Calculates a bitmask corresponding to 2^v
Inputs: v
Outputs: 2^v
Effects: None.
Notes: On T1324, uses PO2 instruction if possible. Otherwise,
       falls back to an iterative shift that is compatible
       with T1321 without needing OneBase library routines.
----------------------------------------------------------- */
ATTR_INLINE static objectBitmask_t powerOfTwo(uint16 v)
{
  uint16 r;
  #if defined(__CHIMERA__) && __T100X_HAS_PO2__ == 1 && MAX_OBJECTS < 16
    asm("        po2 %0" : "=a" (r) : "0" (v) : "cc" );
  #else
    uint16 i;
    for (r = 1, i = 0; i < v; i++)
    {
      r <<= 1;
    }
  #endif
  return r;
}

/* -----------------------------------------------------------
Name: countSetBits16
Purpose: Counts the bits set in a uint16
Inputs: uint16 v
Outputs: Number of bits == 1 in v
Effects: None
Notes: On T1324, uses POPCOUNT instruction if possible.
       Otherwise, falls back to K&R set bit count.
----------------------------------------------------------- */
ATTR_INLINE static int16 countSetBits16(uint16 v)
{
  int16 c;
  #if defined(__CHIMERA__) && __T100X_HAS_POPCOUNT__ == 1
    asm("        popcount %0" : "=ay" (c) : "0" (v) : "cc" );
  #else
    for (c = 0; v; c++)
    {
      v &= v - 1; // clear the least-significant bit set
    }
  #endif
  return c;
}

/* -----------------------------------------------------------
Name: countSetBits32
Purpose: Counts the bits set in a uint32
Inputs: uint32 v
Outputs: Number of bits == 1 in v
Effects: None
Notes: Calls countSetBits16 twice.
----------------------------------------------------------- */
ATTR_INLINE static int16 countSetBits32(uint32 v)
{
  void *pv = (void *) &v;
  uint16 *pv16 = (uint16 *) pv;
  return countSetBits16(pv16[0]) + countSetBits16(pv16[1]);
}

/* -----------------------------------------------------------
Name: countSetBits
Purpose: Counts the bits set in a bitmask
Inputs: bitmask v
Outputs: Number of bits set in v
Effects: None
Notes: Uses countSetBits16 or 32 depending on MAX_OBJECTS.
----------------------------------------------------------- */
ATTR_INLINE static int16 countSetBits(objectBitmask_t v)
{
  #if MAX_OBJECTS < 16
    return countSetBits16(v);
  #else
    return countSetBits32(v);
  #endif
}

/* -----------------------------------------------------------
Name: findLowestSetBit
Purpose: Finds bit position of least-significant set bit
Inputs: v
Outputs: bit position of least-significant set bit
Effects: None.
Notes: On T1324, uses FFO instruction if possible. Otherwise,
       falls back to an iterative scan that is compatible
       with T1321.
----------------------------------------------------------- */
ATTR_INLINE static int16 findLowestSetBit(objectBitmask_t v)
{
  int16 c = -1;
  #if defined(__CHIMERA__) && __T100X_HAS_FFO__ == 1 && MAX_OBJECTS < 16
    asm("        neg y, a\n"
        "        and a, y\n"
        "        ffo a\n" : "=a" (c) : "a" (v) : "y", "cc");
  #else
    if (v)
    {
      objectBitmask_t mask;
      for (c = 0, mask = 1; !(v & mask); c++, mask <<= 1);
    }
  #endif
  return c;
}

/* -----------------------------------------------------------------
Name: numBits
Purpose: return floor(log2(v))
Inputs: bitmask v
Outputs: floor(log2(v)); if v == 0, then return 0xFFFF.
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
ATTR_INLINE static uint16 numBits(objectBitmask_t v)
{
  int16 numBits = 0;
  #if defined(__CHIMERA__) && __T100X_HAS_FFO__ == 1
    asm("        ffo %0\n" : "=ay" (numBits) : "0" (v) : "cc");
  #else
    if (v == 0)
    {
      numBits = 0xFFFF;
    }
    else
    {
      while ((v >>= 1) != 0)
      {
        numBits++;
      }
    }
  #endif
  return numBits;
}

/* -----------------------------------------------------------------
Name: isBitSet
Purpose: return 1 if bit n of v is set, 0 otherwise
Inputs: bitmask v, bit number n
Outputs: 1/0
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
ATTR_INLINE static uint16 isBitSet(objectBitmask_t v, uint16 n)
{
  //TODO: assembly needed here?
  return (v & powerOfTwo(n)) != 0;
}

/* -----------------------------------------------------------------
Name: setBit
Purpose: set bit n, return updated value of v
Inputs: bitmask v, bit number n
Outputs: v updated
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
ATTR_INLINE static objectBitmask_t setBit(objectBitmask_t v, uint16 n)
{
  return v | powerOfTwo(n);
}

/* -----------------------------------------------------------------
Name: clearBit
Purpose: clear bit n, return updated value of v
Inputs: bitmask v, bit number n
Outputs: v updated
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
ATTR_INLINE static objectBitmask_t clearBit(objectBitmask_t v, uint16 n)
{
  return v & (~powerOfTwo(n));
}

#endif  //_BIT_MANIPULATION_H_
