#ifndef _HYBRID_DISPLAY_NOISE_REMOVER_H_
#define _HYBRID_DISPLAY_NOISE_REMOVER_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: hybrid_display_noise_remover.h
// Description: Header file for hybrid_display_noise_remover.c
//
// $Id:$

#if CONFIG_HAS_HYBRID && !CONFIG_HAS_RX_MUXING && !(defined(__CHIMERA__) && (__CHIMERA_VERSION__ < 31 || !__T100X_HAS_FPU__))
void hybridDisplayNoiseRemover_configure(sensorParams_t *sensorParams, hybridDisplayNoiseRemoverConfig_t *extConfig);
void hybridDisplayNoiseRemover_remove(sensorParams_t *sensorParams, int16 *deltaImage, int16 *deltaAbsTx, int16 *deltaAbsRx);
#else
static ATTR_INLINE void hybridDisplayNoiseRemover_configure(ATTR_UNUSED sensorParams_t *sensorParams, ATTR_UNUSED hybridDisplayNoiseRemoverConfig_t *extConfig) {};
static ATTR_INLINE void hybridDisplayNoiseRemover_remove(ATTR_UNUSED sensorParams_t *sensorParams, ATTR_UNUSED int16 *deltaImage, ATTR_UNUSED int16 *deltaAbsTx, ATTR_UNUSED int16 *deltaAbsRx) {};
#endif

#endif  //_HYBRID_DISPLAY_NOISE_REMOVER_H_
