// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: ifp_stdio.h
// Description: Provides printf-like() support in PC and ChimSim builds
// $Id$

#ifndef _IFP_STDIO_H_
#define _IFP_STDIO_H_

// Because Chimera doesn't support variable-length argument lists and
// C doesn't allow you to query how many arguments a variadic macro
// has, we have to provide printf macros for each possible number of
// arguments. The convention is
//   printfN("format string", N arguments)
// for example,
//   printf2("Foo = %d, bar = %d\n", foo, bar);
// In ChimSim mode, the arguments all must fit into 32 bits but can be
// any datatype.

#ifdef __CHIMERA__

  extern volatile uint32 printf_arg1 __attribute__ ((unmangled));
  extern volatile uint32 printf_arg2 __attribute__ ((unmangled));
  extern volatile uint32 printf_arg3 __attribute__ ((unmangled));
  extern volatile uint32 printf_arg4 __attribute__ ((unmangled));
  extern volatile uint32 printf_arg5 __attribute__ ((unmangled));
  extern volatile uint32 printf_arg6 __attribute__ ((unmangled));
  extern volatile uint32 printf_arg7 __attribute__ ((unmangled));
  extern volatile uint32 printf_arg8 __attribute__ ((unmangled));

  // these are not intended to be called by your code.
  #define ChimccAsmInstr(x)  asm volatile (x "\n clr chimcc_temp_arg2 ; size == 1")
  #define ChimCCPrint(fmt,args...) ChimccAsmInstr(" pragma simt4: printf " #fmt ", (" #args ");")

  // these are:
  #define printf0(s)                         do { \
                                                  ChimCCPrint(s); \
                                                } while(0)
  #define printf1(s, a)                      do { \
                                                  printf_arg1 = (uint32) a;         \
                                                  ChimCCPrint(s, printf_arg1); \
                                                } while(0)
  #define printf2(s, a, b)                   do { printf_arg1 = (uint32) a; \
                                                  printf_arg2 = (uint32) b; \
                                                  ChimCCPrint(s, printf_arg1, printf_arg2); \
                                                } while(0)
  #define printf3(s, a, b, c)                do { printf_arg1 = (uint32) a; \
                                                  printf_arg2 = (uint32) b; \
                                                  printf_arg3 = (uint32) c; \
                                                  ChimCCPrint(s, printf_arg1, printf_arg2, printf_arg3); \
                                                } while(0)
  #define printf4(s, a, b, c, d)             do { printf_arg1 = (uint32) a; \
                                                  printf_arg2 = (uint32) b; \
                                                  printf_arg3 = (uint32) c; \
                                                  printf_arg4 = (uint32) d; \
                                                  ChimCCPrint(s, printf_arg1, printf_arg2, printf_arg3, printf_arg4); \
                                                } while(0)
  #define printf5(s, a, b, c, d, e)          do { printf_arg1 = (uint32) a; \
                                                  printf_arg2 = (uint32) b; \
                                                  printf_arg3 = (uint32) c; \
                                                  printf_arg4 = (uint32) d; \
                                                  printf_arg5 = (uint32) e; \
                                                  ChimCCPrint(s, printf_arg1, printf_arg2, printf_arg3, printf_arg4, printf_arg5); \
                                                } while(0)
  #define printf6(s, a, b, c, d, e, f)       do { printf_arg1 = (uint32) a; \
                                                  printf_arg2 = (uint32) b; \
                                                  printf_arg3 = (uint32) c; \
                                                  printf_arg4 = (uint32) d; \
                                                  printf_arg5 = (uint32) e; \
                                                  printf_arg6 = (uint32) f; \
                                                  ChimCCPrint(s, printf_arg1, printf_arg2, printf_arg3, printf_arg4, printf_arg5, printf_arg6); \
                                                } while(0)
  #define printf7(s, a, b, c, d, e, f, g)    do { printf_arg1 = (uint32) a; \
                                                  printf_arg2 = (uint32) b; \
                                                  printf_arg3 = (uint32) c; \
                                                  printf_arg4 = (uint32) d; \
                                                  printf_arg5 = (uint32) e; \
                                                  printf_arg6 = (uint32) f; \
                                                  printf_arg7 = (uint32) g; \
                                                  ChimCCPrint(s, printf_arg1, printf_arg2, printf_arg3, printf_arg4, printf_arg5, printf_arg6, printf_arg7); \
                                                } while(0)
  #define printf8(s, a, b, c, d, e, f, g, h) do { printf_arg1 = (uint32) a; \
                                                  printf_arg2 = (uint32) b; \
                                                  printf_arg3 = (uint32) c; \
                                                  printf_arg4 = (uint32) d; \
                                                  printf_arg5 = (uint32) e; \
                                                  printf_arg6 = (uint32) f; \
                                                  printf_arg7 = (uint32) g; \
                                                  printf_arg8 = (uint32) h; \
                                                  ChimCCPrint(s, printf_arg1, printf_arg2, printf_arg3, printf_arg4, printf_arg5, printf_arg6, printf_arg7, printf_arg8); \
                                                } while(0)

#elif (0 != BUILD_IFP_MODEL)
  #include "mex.h"

  // Because MSVC doesn't support variadic macros in C, we have to
  // explicitly define argument lists for these

  #define printf0(s) mexPrintf(s)
  #define printf1(s, a) mexPrintf(s, a)
  #define printf2(s, a, b) mexPrintf(s, a, b)
  #define printf3(s, a, b, c) mexPrintf(s, a, b, c)
  #define printf4(s, a, b, c, d) mexPrintf(s, a, b, c, d)
  #define printf5(s, a, b, c, d, e) mexPrintf(s, a, b, c, d, e)
  #define printf6(s, a, b, c, d, e, f) mexPrintf(s, a, b, c, d, e, f)
  #define printf7(s, a, b, c, d, e, f, g) mexPrintf(s, a, b, c, d, e, f, g)
  #define printf8(s, a, b, c, d, e, f, g, h) mexPrintf(s, a, b, c, d, e, f, g, h)
#else
  #include <stdio.h>
  // Because MSVC doesn't support variadic macros in C, we have to
  // explicitly define argument lists for these

  #define printf0(s) printf(s)
  #define printf1(s, a) printf(s, a)
  #define printf2(s, a, b) printf(s, a, b)
  #define printf3(s, a, b, c) printf(s, a, b, c)
  #define printf4(s, a, b, c, d) printf(s, a, b, c, d)
  #define printf5(s, a, b, c, d, e) printf(s, a, b, c, d, e)
  #define printf6(s, a, b, c, d, e, f) printf(s, a, b, c, d, e, f)
  #define printf7(s, a, b, c, d, e, f, g) printf(s, a, b, c, d, e, f, g)
  #define printf8(s, a, b, c, d, e, f, g, h) printf(s, a, b, c, d, e, f, g, h)
#endif

#endif // _IFP_STDIO_H_
