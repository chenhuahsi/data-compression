#include "ifp_common.h"
#include "side_touch.h"
#include "side_touch_util.h"

static sideTouchDifferentialConfig_t SDcfg;
int numFingersLeft, numFingersRight;
sideTouchSwipeRecord_t swipeRecordLeft, swipeRecordRight;
sideButtonsGestureReport_t gestureReport;
int16 sideFingersPresent;

//Constant (tunable) variables
int numSides; //number of sides we are using on the panel (left and right)
int neighbor;
int windowSize;
int T_OFFSET;
int sideInd; //determines whether we are looking at left or right side
int insideInd; //determines the second column from the side
float thetaPos; //multiple of standard deviation
int thetaNeg; //threshold for static finger

//FINGER TRACKING
int trackCounter;
sideFinger_t curr;
sideFinger_t old;

//Variables for getting the temporal difference
frameBuffer sideProfile;
int currTemporalDiff[4][MAX_RX]; // MAX_RX]; Current temporal difference
int savedTemporalDiff[4][MAX_RX];
int frameInd; //Determines index value
int currInd;
int fullness; //Determines how full the temporal difference array is

sideFinger_t fingerListLeft[MAX_OBJECTS];
sideFinger_t fingerListRight[MAX_OBJECTS];

// int sideFingerX[MAX_OBJECTS]; int sideFingerY[MAX_OBJECTS];
int totalFingers;
int frameCollectionSize;

//testing
int swiper;

void resetParameters();

#if CONFIG_HAS_SIDE_TOUCH
void sideTouch_run(uint16* rawImage)
{
  // T_OFFSET = 3; //12;
  // windowSize = 3; //6; //value needs to be one more than matlab in order to match it
  // neighbor = 4;
  // thetaPos = 5; //2;
  // thetaNeg = -1; //-2; //1;
  frameCollectionSize = windowSize + T_OFFSET;

  resetParameters();
  calculateTemporalDifference(rawImage);
  if (fullness >= frameCollectionSize) {
    detectFingers();
  }

  sideFingersPresent = ((numFingersLeft + numFingersRight) > 0);

  if (swiper > 0) {
    swiper = 0;

    //Pass variables
    gestureReport.leftSwipeUp = swipeRecordLeft.swipeUp;
    gestureReport.leftSwipeDown = swipeRecordLeft.swipeDown;
    gestureReport.leftSwipeLastPosition = swipeRecordLeft.swipeStartPosition;
    gestureReport.leftSwipeCurrentPosition = swipeRecordLeft.swipeCurrentPosition;
    gestureReport.rightSwipeUp = swipeRecordRight.swipeUp;
    gestureReport.rightSwipeDown = swipeRecordRight.swipeDown;
    gestureReport.rightSwipeLastPosition = swipeRecordRight.swipeStartPosition;
    gestureReport.rightSwipeCurrentPosition = swipeRecordRight.swipeCurrentPosition;

    //Blank Display
    *((volatile uint16 *)(0xE036)) = 0x1;
  }
}

void sideTouch_init() {
  resetParameters();
}

void sideTouch_reinit() {
  sideTouch_init();
}

void sideTouch_configure(sideTouchTemporalFilter_t *sideTouchTemporalFilterConfig) {

  //Temporal filter algorithm initialization
  windowSize  = sideTouchTemporalFilterConfig->windowSize;
  T_OFFSET    = sideTouchTemporalFilterConfig->tOffset;
  thetaPos    = sideTouchTemporalFilterConfig->sideFingerThreshold;
  thetaNeg    = sideTouchTemporalFilterConfig->staticFingerThreshold;
  neighbor    = sideTouchTemporalFilterConfig->neighbors;
  numSides = 2;

  SDcfg.stColNum = 30;
  SDcfg.stRowNum = 18;
  SDcfg.positionDefault = -1536;
  SDcfg.temporalFilterType = 1;
  SDcfg.spatialFilterType = 2;
  SDcfg.profileDiffPeakTh_pct = 16384;
  SDcfg.profileDiffPeakTh = 50;
  SDcfg.profileDiffFingerLift_pct = 16384;
  SDcfg.negToPosDistanceTh = 4;
  SDcfg.fingerValley_pct = 29491;
  SDcfg.noiseTh = 15;
  SDcfg.noiseTh_pct = 13107;
  SDcfg.largeObjectPositionTh = 4;
  SDcfg.largeObjectAreaTh = 3;
  SDcfg.tapPositionDiffTh = 256;
  SDcfg.tapTimeMaxTh = 20;
  SDcfg.tapTimeMinTh = 1;
  SDcfg.fingerTrackingDistTh = 100; //10000;
  SDcfg.swipeMinSpeedTh = 10;
}

void calculateTemporalDifference(uint16* rawImage) {
  frameData meanSecondWindow;
  frameData meanFirstWindow;
  int j; int i; int k;

  //Get finger data
  for (j = 0; j < MAX_RX; j++)
  {

    sideProfile.rawProfile2D[frameInd].singleFrame[0][j] = (uint16)*(rawImage); //left data
    sideProfile.rawProfile2D[frameInd].singleFrame[1][j] = (uint16)*(rawImage + MAX_RX); //2nd column from left data
    sideProfile.rawProfile2D[frameInd].singleFrame[2][j] = (uint16)*(rawImage + (MAX_RX * (MAX_TX - 2))); //2nd column from right data
    sideProfile.rawProfile2D[frameInd].singleFrame[3][j] = (uint16)*(rawImage + (MAX_RX * (MAX_TX - 1))); //right data
    rawImage++;
  }

  if (fullness < frameCollectionSize) {
    fullness++;
  }

  //reset just in case
  for (k = 0; k < 4; k++) {
    for (j = 0; j < MAX_RX; j++) {
      meanSecondWindow.singleFrame[k][j]  = 0;
      meanFirstWindow.singleFrame[k][j] = 0;
    }
  }

  if (fullness >= frameCollectionSize) {
    currInd = (frameInd + 1) % frameCollectionSize;
    int ind1 = currInd;
    int ind2 = (currInd + T_OFFSET) % frameCollectionSize;
    //Sum up all the frames for first and second windows
    for (i = 0; i < windowSize; i++) {
      for (k = 0; k < 4; k++) {
        for (j = 0; j < MAX_RX; j++) {
          meanSecondWindow.singleFrame[k][j] += sideProfile.rawProfile2D[(ind1+i)%frameCollectionSize].singleFrame[k][j];
          meanFirstWindow.singleFrame[k][j] += sideProfile.rawProfile2D[(ind2+i)%frameCollectionSize].singleFrame[k][j];
        }
      }
    }

    //Average the windows
    for (k = 0; k < 4; k++) {
      for (j = 0; j < MAX_RX; j++) {
        meanSecondWindow.singleFrame[k][j] = meanSecondWindow.singleFrame[k][j] / windowSize;
        meanFirstWindow.singleFrame[k][j] = meanFirstWindow.singleFrame[k][j] / windowSize;
      }
    }

  //Temporal difference calculation
    for (i = 0; i < 4; i++) {
      for (j = 0; j < MAX_RX; j++) {
        currTemporalDiff[i][j] = meanFirstWindow.singleFrame[i][j] - meanSecondWindow.singleFrame[i][j]; //temporal diff
        savedTemporalDiff[i][j] = currTemporalDiff[i][j];

      }
    }
  } //fullness of frame condition met

  if  (frameInd < (frameCollectionSize - 1)) {
    frameInd++;
  }
  else {
    frameInd = 0;
  }
}


void differentialFingerTracking(int16 *posPositionGau, int16 posNum, sideFinger_t *fingerList, int16 *peakPosition, int16 *isLargeObject )
{
  int16 i, j;
  int16 findMatch;
  int16 mIdx, minDist, dist;

  for (i = 0; i < posNum; i++)
  {
    findMatch = 0;
    mIdx = -1;
    minDist = MAX_RX * 256;
    for (j = 0; j < MAX_OBJECTS; j++)
    {
      if (fingerList[j].index > 0)
      {
        dist = abs_int16(posPositionGau[i] - fingerList[j].positionBuf[0]);
        if ((fingerList[j].stillExist == 0) && (dist <= SDcfg.fingerTrackingDistTh) &&
            (fingerList[j].positionBuf[0] > SDcfg.positionDefault) &&
            (fingerList[j].tapStatus == 0) && (fingerList[j].time > 0))
        {
          if (dist <= minDist)
          {
            findMatch = 1;
            minDist = dist;
            mIdx = j;
          }
        }
      }
    }
    if (findMatch == 1)
    {
      fingerList[mIdx].currentPosition = posPositionGau[i];
      fingerList[mIdx].peakPosition = peakPosition[i];

      //Large object is dummy variable right now
      if ((fingerList[mIdx].isLargeObject == 0) || (fingerList[mIdx].peakPosition < SDcfg.largeObjectPositionTh))
      {
          fingerList[mIdx].isLargeObject = isLargeObject[i];
      }

      fingerList[mIdx].stillExist = 1;
    }

    if (findMatch == 0)
    {
      for (j = 0; j < MAX_OBJECTS; j++)
      {
        if (fingerList[j].index == 0)
        {
            fingerList[j].index = j + 1;
            fingerList[j].time = 0;
            fingerList[j].currentPosition = posPositionGau[i];
            fingerList[j].peakPosition = peakPosition[i];
            fingerList[j].isLargeObject = isLargeObject[i];
            fingerList[j].positionBuf[0] = SDcfg.positionDefault;
            fingerList[j].positionBuf[1] = SDcfg.positionDefault;
            fingerList[j].positionBuf[2] = SDcfg.positionDefault;
            fingerList[j].startPosition = posPositionGau[i];
            fingerList[j].amplitude = 0;
            fingerList[j].swipeDownStatus = 0;
            fingerList[j].swipeUpStatus = 0;
            fingerList[j].stillExist = 1;
            break;
        }
      }
    }
  }
}

void differentialSwipeDetection(sideFinger_t *fingerList, int16 *posPosition, int16 posNum)
{
  int16 j, idx1;
  int16 mIdx;
  int16 refPosition;

  for (idx1 = 0; idx1 < posNum; idx1++)
  {
    for (mIdx = 0; mIdx < MAX_OBJECTS; mIdx++)
    {
      if ((fingerList[mIdx].index > 0) && (fingerList[mIdx].currentPosition == posPosition[idx1])) //Make sure it's a new finger pos
      {
        refPosition = SDcfg.positionDefault;
        for (j = 0; j < BUF_H; j++)
        {
          if (fingerList[mIdx].positionBuf[j] > SDcfg.positionDefault)
          {
            refPosition = fingerList[mIdx].positionBuf[j];
          }
        }
        if (((fingerList[mIdx].currentPosition - refPosition) >= SDcfg.swipeMinSpeedTh) &&
            (refPosition > SDcfg.positionDefault) && (fingerList[mIdx].tapStatus == 0) &&
            (fingerList[mIdx].currentPosition > fingerList[mIdx].positionBuf[0]))
        {
          fingerList[mIdx].swipeUpStatus = fingerList[mIdx].swipeUpStatus + 1;
          fingerList[mIdx].swipeDownStatus = 0;
        }
        else if ((refPosition-fingerList[mIdx].currentPosition >= SDcfg.swipeMinSpeedTh) &&
                (refPosition> SDcfg.positionDefault) && (fingerList[mIdx].tapStatus ==0) &&
                (fingerList[mIdx].positionBuf[0] > fingerList[mIdx].currentPosition))
        {
          fingerList[mIdx].swipeDownStatus = fingerList[mIdx].swipeDownStatus + 1;
          fingerList[mIdx].swipeUpStatus= 0;
        }
        else
        {
          //Do nothing. We want to report at finger lift.
          // fingerList[mIdx].swipeDownStatus = 0;// max_int16(fingerList[mIdx].swipeDownStatus-1, 0);
          // fingerList[mIdx].swipeUpStatus = 0;//max_int16(fingerList[mIdx].swipeUpStatus-1, 0);
        }
      }
    }
  }
}

int16 swipeCounter[2];
void reportSwipe(sideFinger_t *fingerList,sideTouchSwipeRecord_t *swipeRecord)
{
  int16 i;
  int16 swipeDistanceThreshold = 300; //480; //15;
  for (i = 0; i < MAX_OBJECTS; i++)
  {
    if ((fingerList[i].swipeUpStatus > 0) &&
        (abs_int16(fingerList[i].startPosition - fingerList[i].currentPosition) > swipeDistanceThreshold) &&
        (fingerList[i].stillExist == 0))
    {
      swipeRecord->swipeUp = fingerList[i].swipeUpStatus;
      swipeRecord->swipeStartPosition = fingerList[i].startPosition;
      swipeRecord->swipeCurrentPosition = fingerList[i].currentPosition;
      swipeCounter[0]++;
      swiper++;
    }
    if ((fingerList[i].swipeDownStatus > 0) &&
        (abs_int16(fingerList[i].startPosition - fingerList[i].currentPosition) > swipeDistanceThreshold) &&
        (fingerList[i].stillExist == 0))
    {
      swipeRecord->swipeDown = fingerList[i].swipeDownStatus;
      swipeRecord->swipeStartPosition = fingerList[i].startPosition;
      swipeRecord->swipeCurrentPosition = fingerList[i].currentPosition;
      swipeCounter[1]++;
      swiper++;
    }
  }
}

void detectFingers() {
  int side; int fingerIter; int j; int k; int numFingers = 0;
  int maxVal; int maxInd;
  fingerParams oldFinger; //for finding static fingers
  sideFinger_t finger[MAX_OBJECTS];

  int16 posPositionGauLeft[MAX_OBJECTS]; int16 posPositionGauRight[MAX_OBJECTS];
  int16 posPositionLeft[MAX_OBJECTS]; int16 posPositionRight[MAX_OBJECTS];
  int16 isLargeObject[MAX_OBJECTS] = {0};
  int16 posNumLeft = 0; int16 posNumRight = 0;

  for (j = 0; j < 10; j++) {
    finger[j].peakPosition = 0;
  }

  //Find fingers
  for (side = 0; side < numSides; side++) { //iterate between two sides to find fingers
    switch (side) {
      case 0: //left side
        sideInd = 0;
        insideInd = 1;
        break;

      case 1: //right side
        sideInd = 3;
        insideInd = 2;
        break;

      default:
        break;
    }

    numFingers = 0;
    //Limit the number of fingers on one side to be 5
    for (fingerIter = 0; fingerIter < 5; fingerIter++) {
      // //resetting all these values to default here so we don't mix up the data
      maxVal = -180;
      maxInd = 0;

      //Find where finger is located (max value and index)
      for (j = 0; j < MAX_RX; j++) {
        if (currTemporalDiff[sideInd][j] > maxVal) {
          maxVal = currTemporalDiff[sideInd][j];
          maxInd = j;
        }
      }

      //Check if this is actually a finger
      fingerParams newFinger = findFingerParams(sideInd, maxInd, currTemporalDiff);
      if (newFinger.sensorVal > thetaPos) {
        if ((currTemporalDiff[sideInd][maxInd] > currTemporalDiff[insideInd][maxInd])
         && (currTemporalDiff[insideInd][maxInd] < thetaPos)) { //Make sure it's not a finger on the inside

          //Record finger, index and side
          numFingers++;
          // finger[numFingers - 1].side     = sideInd;
          finger[numFingers - 1].peakPosition    = maxInd;

          //Find area of finger signal
          int startind = maxInd;
          while ((currTemporalDiff[sideInd][startind] > thetaPos) && (startind < MAX_RX)) {
            finger[numFingers - 1].prepareSemiTap++;
            startind++;
          }
          startind = maxInd;
          while ((currTemporalDiff[sideInd][startind] > thetaPos) && (startind >= 0)) {
            finger[numFingers - 1].prepareSemiTap++;
            startind--;
          }

          finger[numFingers - 1].currentPosition  = newFinger.precisePos;

          if (sideInd == 0) {
            posNumLeft++;
            posPositionGauLeft[numFingers - 1] = (int)(((newFinger.precisePos + 0.5) * 1920 / 32) + 0.5);
            posPositionLeft[numFingers - 1] = maxInd;
          }
          else {
            posNumRight++;
            posPositionGauRight[numFingers - 1] = (int)(((newFinger.precisePos + 0.5) * 1920 / 32) + 0.5);
            posPositionRight[numFingers - 1] = maxInd;
          }

          //Check neighbors to make sure they're within the border of the panel
          for (k = newFinger.firstNeighborInd; k <= newFinger.lastNeighborInd; k++){
            currTemporalDiff[sideInd][k] = -180;
          }
        }
      } //Done verifying finger
    } //Done finding fingers for one side

    // Static Finger
    int i;
    if (side == 0) { //left side
      numFingersLeft = posNumLeft;

      //Reset still exists
      for(i = 0; i < MAX_OBJECTS; i++)
      {
        fingerListLeft[i].stillExist = 0;
      }

      differentialFingerTracking(posPositionGauLeft, posNumLeft, fingerListLeft, posPositionLeft, isLargeObject);

      //Detect static fingers
      for (i = 0; i < MAX_OBJECTS; i++) {
        if ((fingerListLeft[i].stillExist == 0) && (fingerListLeft[i].index > 0)) {
          oldFinger = findFingerParams (side, fingerListLeft[i].peakPosition, savedTemporalDiff);
          if (oldFinger.sensorVal >= -thetaNeg) {
            numFingersLeft++;
            fingerListLeft[i].stillExist = 1; //finger exists
          }
        }
      }

      differentialSwipeDetection(fingerListLeft, posPositionGauLeft, posNumLeft);
      reportSwipe(fingerListLeft, &swipeRecordLeft);
      updateFingerListSingle(fingerListLeft, SDcfg.positionDefault);
    }
    else { //right side

      numFingersRight = posNumRight;

      //Reset still exists
      for(i = 0; i < MAX_OBJECTS; i++)
      {
        fingerListRight[i].stillExist = 0;
      }

      differentialFingerTracking(posPositionGauRight, posNumRight, fingerListRight, posPositionRight, isLargeObject);

      //Detect static fingers
      for (i = 0; i < MAX_OBJECTS; i++) {
        if ((fingerListRight[i].stillExist == 0) && (fingerListRight[i].index > 0)) {
          oldFinger = findFingerParams (side, fingerListRight[i].peakPosition, savedTemporalDiff);
          if (oldFinger.sensorVal >= -thetaNeg) {
            numFingersRight++;
            fingerListRight[i].stillExist = 1; //finger exists
          }
        }
      }

      differentialSwipeDetection(fingerListRight, posPositionGauRight, posNumRight);
      reportSwipe(fingerListRight, &swipeRecordRight);
      updateFingerListSingle(fingerListRight, SDcfg.positionDefault);
    }
  } //Done finding fingers for both sides
}

fingerParams findFingerParams (int edge, int maxInd, int temporalDiff[4][MAX_RX]) {
  fingerParams finger;
  finger.maxInd = maxInd;
  int i;
  int numExtend = 0;        // Number of neighbors the sensor response needs to be extended by
  int diffExtend = 0;       //Number of neighbors already accommodated for
  int beyondEdge = 0;       //Determines whether it's at the top of bottom of sensor
  int sumPosPdf = 0;          //Intermediary step for finger calculation (sum of responses)
  int extendArray[5];       //Responses of neighbors extrapolated beyond the sensor

  //Find edge vector size
  //Check boundaries and find min neighbor

  if ((maxInd - neighbor) < 0) finger.firstNeighborInd = 0;
  else finger.firstNeighborInd = maxInd - neighbor;
  if ((maxInd + neighbor) >= MAX_RX) finger.lastNeighborInd = MAX_RX - 1;
  else finger.lastNeighborInd = maxInd + neighbor;

  //Extend sensor response above edges
  if ((maxInd - neighbor) < 0) { //Finger at bottom of side
    beyondEdge = 1;
    numExtend = neighbor - maxInd;
    if (numExtend < 0) numExtend = -numExtend;
    diffExtend = maxInd;
    for (i = 0; i < numExtend; i++) {
      extendArray[numExtend - i - 1] = temporalDiff[edge][maxInd + diffExtend + (i + 1)];
    }
  }
  if ((maxInd + neighbor) >= MAX_RX) { //Finger at top of side
    beyondEdge = 2;
    numExtend = (maxInd + neighbor) - (MAX_RX - 1);
    if (numExtend < 0) numExtend = -numExtend;
    diffExtend = (MAX_RX - 1) - maxInd;
    for (i = 0; i < numExtend; i++) {
      extendArray[i] = temporalDiff[edge][maxInd - diffExtend - (i + 1)];
    }
  }

  //Calculate finger position
  //Sum all values together
  finger.sensorVal = 0;
  int countneg = 0; //Counts number of negative responses in the neighbors
  for (i = finger.firstNeighborInd; i <= finger.lastNeighborInd; i++) {
    //Calculating exact position
    if (temporalDiff[edge][i] <= 0) { //Don't include negative values in the calculation
      countneg++;
    }
    else {
      //Calculating sensor response
      finger.sensorVal += temporalDiff[edge][i];
    }
  }

  //If value is at the edge of the sensor
  if (beyondEdge != 0) {
    for (i = 0; i < numExtend; i++) {
      //Calculating exact position
      if (extendArray[i] > 0) { //Don't include negative values in the calculation
        finger.sensorVal += extendArray[i]; //Calculating sensor response
      }
      else countneg++;
    } //for loop for extension
  } //Has extension

  //Calculate final sensor response for finger location
  sumPosPdf = finger.sensorVal; //sumPosPdf is sum of all values before they're averaged
  if (finger.sensorVal != 0) {
    int denom;
    if (beyondEdge == 0) {
      denom = finger.lastNeighborInd - finger.firstNeighborInd + 1 - countneg;
      finger.sensorVal = finger.sensorVal/denom;
    }
    else {
      denom = finger.lastNeighborInd - finger.firstNeighborInd + numExtend + 1 - countneg;
      finger.sensorVal = finger.sensorVal/(float)denom;
    }
  }
  else { //If all values including neighbors are negative
    finger.sensorVal = temporalDiff[edge][maxInd];
  }

  //Find the precise position of index
  finger.precisePos = 0;
  if (sumPosPdf != 0) {
    for (i = finger.firstNeighborInd; i <= finger.lastNeighborInd; i++) {
      if (temporalDiff[edge][i] > 0) {
        finger.precisePos += (1.0*i * temporalDiff[edge][i] / sumPosPdf);
      }
    }

    //Calculate exact index for when finger is at the edge of the sensor
    if (beyondEdge == 1) {
      for (i = 0; i < numExtend; i++) {
        if (extendArray[i] > 0) {
          float newValue = ((1.0*(i-numExtend) * extendArray[i]) / sumPosPdf);
          finger.precisePos += newValue;
        }
      }
      if (finger.precisePos < 0) {
        finger.precisePos = 0;
      }
    }
    else if (beyondEdge == 2) {
      for (i = 0; i < numExtend; i++) {
        if (extendArray[i] > 0) {
          float newValue = (1.0*(i + MAX_RX) * extendArray[i] / sumPosPdf);
          finger.precisePos += newValue;
        }
      }
      if (finger.precisePos > (MAX_RX - 1)) finger.precisePos = MAX_RX - 1;
    }
  }

  else {
    //Set as invalid values since we don't need it
    //Will only occur when calculating static fingers
    finger.precisePos = -1;
  }

  return finger;
}
#endif

void resetParameters()
{
  //Do nothing
}

