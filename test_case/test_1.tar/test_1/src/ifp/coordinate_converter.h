#ifndef _coordinate_converter_H_
#define _coordinate_converter_H_
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: coordinate_converter.h
   Description: Header file for using the coordinate converter module.
----------------------------------------------------------------- */
// $Id: coordinate_converter.h,v 1.4 2012/07/21 19:34:04 mposadas Exp $

#include "ifp_common.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

/* =================================================================
   MODULE TYPES
==================================================================*/

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/
/* -----------------------------------------------------------
Name: coordConv_init()
Purpose: Initializes the coordinate converter
Inputs: none
Outputs: none
Effects: Resets internal state of coordinate converter, as at
         power-on.
Notes: This function must be called before using the coordinate
       converter module.
Example: none
----------------------------------------------------------- */
static ATTR_INLINE void coordConv_init(void) {};

/* -----------------------------------------------------------
Name: coordConv_reinit()
Purpose: Reinitializes the coordinate converter
Inputs: none
Outputs: none
Effects: Resets internal state of coordinate converter, as at a
         host rezero.
Notes: This function must be called if the host sends a rezero
       command.
Example: none
----------------------------------------------------------- */
static ATTR_INLINE void coordConv_reinit(void) {};

/* -----------------------------------------------------------
Name: coordConv_configure()
Purpose: Set host-defined parameters
Inputs: sensorParams - sensor parameters structure
        xMax, yMax - maximum X/Y pixel coordinates
        leftOffset_mm, rightOffset_mm, topOffset_mm, bottomOffset_mm -
          the offsets of last pixel from the edge of the sensor, in
          millimeters. Left/right correspond to the x coordinate, and
          top/bottom to the y coordinate
        txAxis - the axis corresponding to the transmitters
        sZThreshold - small Z threshold
        sZSFactor - small Z Scale Factor Q1.15
        lZSFactor - large Z Scale Factor Q1.15
        wxSFactor - wx Scale Factor Q4.4
        wxO - wx Offset
        wySFactor - wy Scale Factor Q4.4
        wyO - wy Offset
Outputs: none
Effects: Resets internal state of coordinate converter, as at a
         host rezero.
Notes: This function must be called if the host sends a rezero
       command.
Example: none
----------------------------------------------------------- */
void coordConv_configure(sensorParams_t *sensorParams,
                         coordConvConfig_t *config);

/* -----------------------------------------------------------
Name: coordConv_convertPositions()
Purpose: converts sensor to host coordinates
Inputs:  sensorPositions - positions in sensor units
Outputs: hostPositions - positions in host units
Effects: none
Notes: none
Example: none
----------------------------------------------------------- */
void coordConv_convertPositions(sensorPosition_t *sensorPositions,
                                hostPosition_t *hostPositions);

#if CONFIG_HAS_Z_JITTER_ADJUSTMENT || CONFIG_HAS_LL_LIFTING_LARGE_FINGER || CONFIG_HAS_LANDING_LARGE_FINGER_DROP
uint16 coordConv_computeZ(sensorPosition_t *sp);
#endif
#if CONFIG_HAS_W_LLJ_FILTER || CONFIG_HAS_LL_LIFTING_LARGE_FINGER || CONFIG_HAS_LANDING_LARGE_FINGER_DROP
uint16 coordConv_computeW(sensorPosition_t *sp);
#endif
#endif /* matches #iTwo fndef _coordinate_converter_H_ */
