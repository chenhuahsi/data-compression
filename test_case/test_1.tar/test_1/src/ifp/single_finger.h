#ifndef _SF_H_
#define _SF_H_
/* -----------------------------------------------------------------

                      COMPANY CONFIDENTIAL
                       INTERNAL USE ONLY

 Copyright (C) 1997 - 2014  Synaptics Incorporated.  All right reserved.

 This document contains information that is proprietary to Synaptics
 Incorporated. The holder of this document shall treat all information
 contained herein as confidential, shall use the information only for its
 intended purpose, and shall protect the information in whole or part from
 duplication, disclosure to any other party, or dissemination in any media
 without the written permission of Synaptics Incorporated.

 Synaptics Incorporated
 1251 McKay Drive
 San Jose, CA   95131
 (408) 904-1100

 Filename: single_finger.h
 Description: Process measured delta profile to extract single finger information.
 $Id:
---------------------------------------------------------------------*/

#include "ifp_common.h"

#if CONFIG_HAS_THICK_GLOVE || CONFIG_HIC_LPWG_MODE_B

typedef enum {
  SF_dynamic_threshold_low,
  SF_dynamic_threshold_medium,
  SF_dynamic_threshold_high
}SF_dynamic_thresholding_t;

/* Up to 16 clients */
typedef enum {
  SF_moisture0_client,
  SF_moisture1_client,
  SF_moisture2_client,
  SF_thickGlove_client,
  SF_ForceSF_client
}SF_client_id_t;


/* single finger reporting modes */
typedef enum {
  SUPPRESS_REPORT_IF_MORE_THAN_ONE,
  REPORT_ONE_WITH_MAX_ENERGY,
  REPORT_TWO_WITH_MAX_ENERGY
} SF_Report_t;

#if MAX_TX < MAX_RX
#define MAX_DELTA MAX_RX
#else
#define MAX_DELTA MAX_TX
#endif

#define DEFAULT_Z 100
/* In 8p8 format */
#define DEFAULT_xWIDTH 0x400
#define DEFAULT_yWIDTH 0x400

#define HYBRID_MOISTURE_Z 100
#define HYBRID_MOISTURE_xWIDTH 0x4
#define HYBRID_MOISTURE_yWIDTH 0x4

#define THICK_GLOVE_Z 150
#define THICK_GLOVE_xWIDTH 0x5
#define THICK_GLOVE_yWIDTH 0x5

#define FORCE_SINGLE_FINGER_Z 250
#define FORCE_SINGLE_FINGER_xWIDTH 0x6
#define FORCE_SINGLE_FINGER_yWIDTH 0x6

#if !defined(cfg_SINGLE_FINGER_REPORT_MODE)
  #define cfg_SINGLE_FINGER_REPORT_MODE SUPPRESS_REPORT_IF_MORE_THAN_ONE
#endif

/* Algorithm configuration */
#define SINGLE_FINGER_THRESHOLDING_ON               1
#define SINGLE_FINGER_DYNAMIC_THRESHOLDING_ON       1
#define SINGLE_FINGER_DYNAMIC_THRESHOLD_PERCENT_LOW    25
#define SINGLE_FINGER_DYNAMIC_THRESHOLD_PERCENT_MEDIUM 50
#define SINGLE_FINGER_DYNAMIC_THRESHOLD_PERCENT_HIGH   75
#define PALM_DYNAMIC_THRESHOLD_PERCENT 40

#define RX_KNEE_LOW_PIXEL_PERCENT                  50
#define TX_KNEE_LOW_PIXEL_PERCENT                  50
#define KNEE_FRAMES                                60

#define SINGLE_FINGER_ALLOW_NEGATIVE_FINGER         0
#define SINGLE_FINGER_REJECT_WIDE_FINGER            0
#define SINGLE_FINGER_MAX_FINGER_WIDTH              4

#if !defined(cfg_SF_THICK_GLOVE_THRESHOLD_FACTOR)
#define cfg_SF_THICK_GLOVE_THRESHOLD_FACTOR 4
#endif
/* minimum separation between 2 fingers */
#define SINGLE_FINGER_SEGMENTATION_PIXEL_THRESHOLD  2
#define SINGLE_FINGER_MAX_NUM_CLIENTS               6

/* states when looking for segment */
enum {
  SEEKING_ZERO,
  SEEKING_LEFT_EDGE,
  SEEKING_RIGHT_EDGE
};

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: void single_finger_init()
Purpose: Initialize the module.
Inputs:
Outputs:
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void single_finger_init(void);


/* -----------------------------------------------------------------
Name: void single_finger_reinit()
Purpose: Re-initialize the single finger processor
Inputs:
Outputs:
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void single_finger_reinit();

/* -----------------------------------------------------------------
Name: void single_finger_configure(singleFingerConfig_t * singleFingerParams)
Purpose: Configure the module.
Inputs: config parameters
Outputs: None
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void single_finger_configure(singleFingerConfig_t* sfConfig);


/* -----------------------------------------------------------------
Name: SF_process()
Purpose: checks x and y abs profiles and reports one or two fingers
Inputs:  deltaIn x 2, profile length x 2,
         client id, report mode
         thresholding level,
Outputs: report, fresh data flag, finger count, updates widths
Effects:
Notes:
Example:
----------------------------------------------------------------- */
int16 SF_process(const int16 * x_delta, uint16 x_profile_length, const int16 * y_delta, uint16 y_profile_length,
                 SF_dynamic_thresholding_t thresholding_level, SF_Report_t report_mode, SF_client_id_t clientId,
                 sensorPosition_t * report);
#else
  static ATTR_INLINE void single_finger_init(void) {};
  static ATTR_INLINE void single_finger_reinit() {};
  static ATTR_INLINE void single_finger_configure(singleFingerConfig_t* sfConfig ATTR_UNUSED) {};
#endif

#endif
