#ifndef _BUTTONS_0D_H_
#define _BUTTONS_0D_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: buttons_0D.h
// Description: Header file for button_0D.c
//
#if CONFIG_HAS_0D_BUTTONS
void buttons0D_init(void);
void buttons0D_reinit(void);
void buttons0D_configure(sensorParams_t *sensorParameters, buttons0DConfig_t *config);
void buttons0D_analyzeData(uint16 *buttonsRaw, classification_t *classifications, buttons0DReport_t *buttons0DReport, ifpTimeStamp_t timeSinceLast_ms, uint16 inhibitRelaxation);
void buttons0D_getButtons0DDiagnostics(ATTR_UNUSED buttons0DDiagnostics_t *buttons0DDiagnostics);
int16 *buttons0D_getDelta(void);
uint16 *buttons0D_getBaseline(void);
baselineState_t buttons0D_getBaselineState(void);
uint16 *buttons0D_getVariance(void);
#else
#include "ifp_string.h"
static INLINE void buttons0D_init(void) {};
static INLINE void buttons0D_reinit(void) {};
static INLINE void buttons0D_configure(ATTR_UNUSED sensorParams_t *sensorParameters, ATTR_UNUSED buttons0DConfig_t *config) {};
static INLINE void buttons0D_analyzeData(ATTR_UNUSED uint16 *buttonsRaw, ATTR_UNUSED classification_t *classifications, ATTR_UNUSED buttons0DReport_t *buttons0DReport, ATTR_UNUSED ifpTimeStamp_t timeSinceLast_ms, ATTR_UNUSED uint16 inhibitRelaxation) { memset16(buttons0DReport, 0, sizeof(buttons0DReport_t) / sizeof(uint16)); };
static INLINE void buttons0D_getButtons0DDiagnostics(ATTR_UNUSED buttons0DDiagnostics_t *buttons0DDiagnostics) { memset16(buttons0DDiagnostics, 0, sizeof(buttons0DDiagnostics_t) / sizeof(uint16)); };
static INLINE int16 *buttons0D_getDelta(void) { return NULL; };
static INLINE uint16 *buttons0D_getBaseline(void) { return NULL; };
static INLINE baselineState_t buttons0D_getBaselineState(void) { return baselineState_noBaseline; };
static INLINE uint16 *buttons0D_getVariance(void)
{
  static uint16 buttons0D_variances[MAX_BUTTONS];
  memset16(buttons0D_variances, 0, sizeof(buttons0D_variances) / sizeof(uint16));
  return buttons0D_variances;
};
#endif

#endif  //_BUTTONS_0D_H_
