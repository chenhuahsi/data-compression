#include "ifp_common.h"
#include "ifp_string.h"
#include "side_touch_util.h"
#include "ifp_stdio.h"

static rom_uint16 logTable[] = {
  // Matlab: round([-8 log([linspace(1/256,31/256,32) linspace(1/8,1,15) 1])]*4096)
  // Table is in 4.12-bit signed fixed point
  // Entries 0-31 are log(x) for 0 <= x < 1/8
  // Entries 32-47 are log(x) for 1/8 <= x <= 1
  // Entry 48 is log(1) repeated to save ROM in the interpolation routine
  32767, 22713, 19874, 18213, 17035, 16121, 15374, 14743, 14196, 13713,
  13282, 12891, 12535, 12207, 11903, 11621, 11357, 11108, 10874, 10653,
  10443, 10243, 10052, 9870, 9696, 9529, 9368, 9213, 9064, 8921, 8782,
  8647, 8517, 6857, 5678, 4764, 4017, 3386, 2839, 2357, 1925, 1535,
  1178, 850, 547, 264, 0, 0 };



//1D filter
//Note:
//1. repetative padding
//2. symmetric and odd number size filter
//3. assume coefficient of filt are normalized to smaller than 1 and utilizing full int16 bits
//---function out = filter1d(~, filt, inArr)----//
void filter1d(const int16 *filt, const int16 filtSize, const int16 *inArr, const int16 inArrSize, int16 *out)
{
    int16 i, j;
    int16 sIdx, eIdx;
    int16 halfFiltSize;
    int32 tmp;
    halfFiltSize= ((filtSize-1)>>1)+1;
    for (i=0; i<inArrSize; i++)
    {
        tmp = 0;
        sIdx = i;
        eIdx = i;
        tmp = (int32)filt[halfFiltSize-1]*(int32)inArr[i];
        for(j=1;j<halfFiltSize;j++)
        {
            sIdx--;
            sIdx = sIdx>0 ? sIdx:0;
            eIdx++;
            eIdx = eIdx<(inArrSize-1)? eIdx:(inArrSize-1);
            tmp = tmp+ ((int32)filt[halfFiltSize-j-1]*(int32)(inArr[sIdx])+((int32)filt[halfFiltSize+j-1]*(int32)inArr[eIdx]));
//             mexPrintf("filt[%d] = %d ; inArr[%d] = %d;  inArr[%d] = %d \n",halfFiltSize-j,filt[halfFiltSize-j],sIdx, inArr[sIdx],eIdx, inArr[eIdx] );
        }
        out[i] = (tmp+16384)>>15;
    }
}

//LoGfiltering: Filter inArr with a LoG filter with assigned sigma
//Note:
//1. Only support sigma = 1.5, 2, 3
//2. Sigma values are multiplied by 10
//---function logFiltered=LoGfiltering(~, inArr, sigma)----//
void LoGfiltering(int16 *inArr, int16 inNum, int16 sigma, int16 *out)
{
    int16 filtSize;
    int16 *filt;
    int16 LoGsigma1p5[17] = {-1, -13, -165,  -1281,  -5720, -13304, -10478,  14577,  32767,  14577, -10478, -13304,  -5720,  -1281,   -165,    -13, -1};
    int16 LoGsigma2[21] = { -3, -25, -165, -806, -2912,  -7559, -13304, -13298,   0,  21688,  32767,  21688,   0, -13298, -13304,  -7559,  -2912,   -806,   -165,    -25,     -3};
    int16 LoGsigma3[25] = { -165,   -491,  -1281,  -2912,  -5720,  -9572, -13304, -14526, -10478,  0,  14577,  27553,  32767,  27553,  14577,   0, -10478, -14526, -13304,  -9572,  -5720,  -2912,  -1281,   -491,   -165};

    if (sigma==15)
    {
        filtSize = 17;
        filt = LoGsigma1p5;
    }
    else if (sigma == 20)
    {
        filt = LoGsigma2;
        filtSize = 21;
    }
    else if (sigma == 30)
    {
        filt = LoGsigma3;
        filtSize = 25;
    }
    else
    {
        filt = LoGsigma1p5;
        filtSize = 17;
    }
    filter1d(filt,filtSize,inArr,inNum,out);
}

//Gaussian Filtering
//---function filtered=gaussianFiltering(~, inArr, sigma)----//
void gaussianFiltering(int16 *inArr, int16 inNum, int16 sigma, int16 *out)
{
    int16 filtSize;
    int16 *filt;

    int16 gaussianSigma3[9] ={1791,   2643,   3489,   4122,   4358,   4122,   3489,   2643,   1791};
    int16 gaussianSigma1p5[9] = {249,   1179,   3583,   6978,   8715,   6978,   3583,   1179,    249};
    int16 gaussianSigmap75[7] = { 6,    498,   7166,  17430,   7166,    498,      6  };
    int16 gaussianSigmap50[5] = { 9, 3538, 26145, 3538, 9 };

    if (sigma==150)
    {
        filtSize = 9;
        filt = gaussianSigma1p5;
    }
    else if (sigma == 300)
    {
        filt = gaussianSigma3;
        filtSize = 9;
    }
    else if (sigma == 75)
    {
        filt = gaussianSigmap75;
        filtSize = 7;
    }
    else if (sigma == 50)
    {
        filt = gaussianSigmap50;
        filtSize = 5;
    }
    else
    {
        filtSize = 9;
        filt = gaussianSigma1p5;
    }
    filter1d(filt,filtSize,inArr,inNum,out);
//     printf("guassian filtering sigma = %d\n", sigma);
}


//---function out = temporalFiltering(~, inArr, inBuf, temporalFilterType)----//
int temporalFiltering(uint16 *inArr,int16 inNum, uint16 inBuf[BUF_H][MAX_RX], sideTouchTemporalFilterType_t temporalFilterType, uint16 *out)
{
    //NEED TO CHECK BUFFER SIZE

    int i;

    if (BUF_H<3)
    {
      return 0;
    }
    switch (temporalFilterType)
    {
        case stFIR_211:
            for (i=0;i<inNum;i++)
            {
                out[i]=((inArr[i])<<1)+inBuf[0][i]+inBuf[1][i];
            }
            break;
        case stFIR_1111:
            for (i=0; i<inNum; i++)
            {
                out[i]=inArr[i]+inBuf[0][i]+inBuf[1][i]+inBuf[2][i];
            }
            break;
        case stFIR_none:
            for (i=0; i<inNum;i++)
            {
                out[i] = inArr[i];

            }
            break;
        default:
            for (i=0; i<inNum;i++)
            {
                out[i] = inArr[i];

            }
        break;
    }


    return 1;
}

//findLocalMinMax
//input:
//in: 1d input array
//threshold: threshold for the peak
//output:
//posPosition: a list of all peak positions
//negPosition: a list of all valley positions
//posNum: number of peaks
//negNum: number of valleys
//---function [posPosition,negPosition,posNum,negNum]=findLocalMinMax(~, in, threshold) ----//
void findLocalMinMax(int16 *in, int16 inSize, int16 threshold, int16 *posPosition, int16 *negPosition, int16* posNum, int16 *negNum)
{
    int16 i, minIdx = 0, maxIdx = 0;
    int16 prevIdx, nextIdx;
    *posNum = 0;
    *negNum = 0;
    //     printf1("find_locai_min_max: threshold = %d \n", threshold);

    for (i = 0; i<inSize; i++)
    {
        //         mexPrintf("in[%d] = %d \n",i, in[i]);

        prevIdx = i - 1;
        prevIdx = max_int16(0, prevIdx);
        nextIdx = i + 1;
        nextIdx = min_int16(inSize - 1, nextIdx);
        //only need special case for i == 0. i==cfg.rxCount-1 is covered by the else case
        if (i == 0)
        {
            if ((in[i] >= in[nextIdx]) & (in[i]> threshold))
            {
                //                 printf4("in[%d] = %d; *posNum  =%d ; maxIdx = %d \n",i, in[i], *posNum, maxIdx);
                posPosition[maxIdx] = i;
                (*posNum)++;
                *posNum = (*posNum)<MAX_OBJECTS ? (*posNum) : MAX_OBJECTS;
                maxIdx++;
            }
            if ((in[i] <= in[nextIdx]) & (in[i]< -threshold))
            {
                //                 printf4("in[%d] = %d; *negNum  =%d; minIdx = %d \n",i, in[i], *negNum, minIdx);
                negPosition[minIdx] = i;
                (*negNum)++;
                *negNum = (*negNum)<MAX_OBJECTS ? (*negNum) : MAX_OBJECTS;
                minIdx++;
            }

        }
        else
        {
            if ((in[i]>in[prevIdx]) & (in[i] >= in[nextIdx]) & (in[i]> threshold))
            {
                //                 printf4("in[%d] = %d; *posNum  =%d ; maxIdx = %d \n",i, in[i], *posNum, maxIdx);
                posPosition[maxIdx] = i;
                (*posNum)++;
                *posNum = (*posNum)<MAX_OBJECTS ? (*posNum) : MAX_OBJECTS;
                maxIdx++;
            }
            if ((in[i]<in[prevIdx]) & (in[i] <= in[nextIdx]) & (in[i]< -threshold))
            {
                //                 printf4("in[%d] = %d; *negNum  =%d; minIdx = %d \n",i, in[i], *negNum, minIdx);
                negPosition[minIdx] = i;
                (*negNum)++;
                *negNum = (*negNum)<MAX_OBJECTS ? (*negNum) : MAX_OBJECTS;
                minIdx++;
            }
        }
    }
}

//profileBlobArea
//Note: has extra locationNum as input
//location: a list of peak of blobs
//profile: 1d array
//noiseFloorTh: threshold for a pixel to be included in the blob are
//output:
//area: list of area for all peaks
//---function [area] = profileBlobArea(~,location,profile, noiseFloorTh, noiseFloorTh_pct)----//
void profileBlobArea(int16 *location,  int16 locationNum, int16 *profile, int16 inSize, int16 noiseFloorTh, int16 noiseFloorTh_pct, int16 *area)
{
    int i=0;
    int pidx = 0;
    int threshold;

    for(i=0; i<MAX_OBJECTS; i++)
    {
       area[i] = 0;
    }

    for (i=0; i<locationNum; i++)
    {
        area[i]=1;
        pidx = location[i]+1;
        threshold = (int16)(((int32)profile[location[i]]*(int32)noiseFloorTh_pct+15384)>>15);
//         mexPrintf("profile[location[i]]=%d, noiseFloorTh_pct= %d, threshold = %d, \n",profile[location[i]], noiseFloorTh_pct, threshold);

        threshold = threshold>noiseFloorTh? threshold:noiseFloorTh;
//         mexPrintf("noiseFloorTh_pct= %d, threshold = %d, \n",noiseFloorTh_pct, threshold);
//         mexPrintf("profile[%d]=%d, profile[%d]=%d\n",pidx, profile[pidx],pidx-1,profile[pidx-1]);
        while ((pidx < inSize) && (profile[pidx]>=threshold) && (profile[pidx]<profile[pidx-1]+noiseFloorTh))
        {
            area[i]++;
            pidx++;
//             mexPrintf("profile[%d]=%d, profile[%d]=%d\n",pidx, profile[pidx],pidx-1,profile[pidx-1]);
        }
    }

    for (i=0; i<locationNum; i++)
    {
        pidx = location[i]-1;
        threshold = (int16)(((int32)profile[location[i]]*(int32)noiseFloorTh_pct+15384)>>15);
        threshold = threshold>noiseFloorTh? threshold:noiseFloorTh;
//         mexPrintf("2nd i=%d;  pidx=%d \n",i, pidx );
        while ((pidx >=0 ) && (profile[pidx]>=threshold) && (profile[pidx]<profile[pidx+1]+noiseFloorTh))
        {
            area[i]++;
            pidx--;
//             mexPrintf("profile[%d]=%d, profile[%d]=%d\n",pidx, profile[pidx],pidx-1,profile[pidx-1]);

        }
    }
}

//---function [isLargeObject] = largeObjectDetection(~,location, profile, area, lastPixelValTh, largeObjectPositionTh, largeObjectAreaTh)----//
void largeObjectDetection(int16 *location, int16 locationNum, int16 *profile, int16 inSize, int16 *area, int16 lastPixelValTh,int16 largeObjectPositionTh, int16 largeObjectAreaTh, int16 *isLargeObject)
{
    int16 lastObjectIdx =0;
    int16 pixelVal = 0;
    int16 i;
    int16 profileDirection = 1;
    for(i=0; i<MAX_OBJECTS; i++)
    {
       isLargeObject[i] = 0;
    }
    if (locationNum>0)
    {
        if (profileDirection ==0)
        {
            lastObjectIdx =0;
            pixelVal = max_int16(profile[0],profile[1]) ;
            if ((location[lastObjectIdx]<=largeObjectPositionTh) && (area[lastObjectIdx]>=largeObjectAreaTh) && (pixelVal >= lastPixelValTh))
            {
                isLargeObject[lastObjectIdx] =1;
            }
        }
        else
        {
            lastObjectIdx =locationNum-1;
            pixelVal = max_int16(profile[inSize-1],profile[inSize-2]);
            if ((location[lastObjectIdx]>=largeObjectPositionTh) && (area[lastObjectIdx]>=largeObjectAreaTh) && (pixelVal >= lastPixelValTh))
            {
                isLargeObject[lastObjectIdx] =1;
            }
        }
    }
}

//mergeProfileBlobs
//Note: has extra in_num as input
//location: list of peak posision
//locationNum: number of blobs
//profile: input 1d array
//valley scale: decide how shallow the valley should be to merge two adjacent peaks
//---function [outLocation, locationNum] =  mergeProfileBlobs(~, inLocation, profile, valleyTh_pct)
void mergeProfileBlobs(int16 *location, int16 *locationNum, int16 *profile, int16 valleyTh_pct)
{
    int16 i,j;
    int16 mark[MAX_OBJECTS];
    int16 in_location[MAX_OBJECTS] = {-1};
    int16 valley;
    int16 valley_th;
    int16 len;
    len = *locationNum;
    int16 peak_ref;

    for (i=0;i<len;i++)
    {
        in_location[i] = location[i];
        location[i]=0;
    }
    for (i = 0; i<len; i++)
    {
        //         mexPrintf("in_location[%d]=%d \n",i, in_location[i]);
        if (in_location[i] >= 0)
        {
            mark[i] = 1;
        }
        //         mexPrintf("mark[%d]=%d \n", in_location[i],mark[in_location[i]]);
    }
    for (i = 0; i<len-1; i++)
    {
        valley = 32767;
        for (j=in_location[i]; j<in_location[i+1]; j++)
        {
            valley = min_int16(valley, profile[j]);
        }
        peak_ref = min_int16(profile[in_location[i]],profile[in_location[i+1]]);
        valley_th = (int16)( ((int32)valleyTh_pct*(int32)peak_ref)>>15 );
//        valley_th = min_int16(valley_th, peak_ref-noiseFloor);
//         mexPrintf("valley = %d, valley_th = %d \n", valley, valley_th);
//         mexPrintf("(int32)min_int16(profile[in_location[i]],profile[in_location[i+1]]))=%d\n", min_int16(profile[in_location[i]],profile[in_location[i+1]]) );
        if (valley>valley_th)
        {
//             mexPrintf("merge, i=%d \n", i);
            if (profile[in_location[i]]<=profile[in_location[i+1]])
            {
                mark[i]=0;
            }
            else
            {
                mark[i+1]=0;
            }
        }
//         mexPrintf("mark[%d]=%d \n",i,mark[i]);
    }
    j=0;
    for (i=0; i<len; i++)
    {
        if (mark[i] >0)
        {
            location[j] = in_location[i];
            j++;
        }
    }
    (*locationNum) = j;
}

//--function pixelArray = markBlobRegion(~, posPosition, profile,threshold)----//
//mark_blob_region
//Note: has extra posNum as input
//posPosition: list of peak location
//posNum: number of peaks
//profile: input 1d array
//threshold: threshod to decide whether to include a pixel in the blob
//output:
//pixel array: if a pixel i is included in a blob pixle_array[i]=1
void markBlobRegion(int16 *posPosition,   int16 posNum, int16 *profile, int16 inSize, int16 threshold, int16 *pixelArray)
{
    int16 i;
    int16 pidx;
    for (i=0; i<posNum; i++)
    {
        pixelArray[posPosition[i]] = 1;
    }
    for (i=0; i<posNum;i++)
    {
        pidx = posPosition[i]+1;
        while ((pidx<inSize) && (profile[pidx]>=threshold) && (profile[pidx]<= profile[pidx-1]))
        {
            pixelArray[pidx]=1;
            pidx++;
        }
        pidx = posPosition[i]-1;
        while ((pidx>=0) && (profile[pidx]>=threshold) && (profile[pidx]<=profile[pidx+1]))
        {
            pixelArray[pidx] = 1;
            pidx--;
        }
    }
}

//--------------------------------------//
//---function [deltaProfile]=calculateDelta(~, baseline, rawProfile)
void calculateDelta(uint16 *baseline, uint16 *rawProfile, int16 arrSize , int16 *deltaProfile)
{
    int16 i=0;
    for (i=0; i<arrSize; i++)
    {
        deltaProfile[i]=baseline[i]-rawProfile[i];
    }
}

//New!!
//---function [lFingerList, rFingerList] = setReportFlag(~, inLFingerList,inRFingerList, maxObjects)----//

//New!!
//---function [outBuf]=initBuffer(~, inProfile, outBufH, bufferType, temporalFilterType)----//
void initBuffer(uint16 inProfile[MAX_RX], sideTouchBufferType_t bufferType, sideTouchTemporalFilterType_t temporalFilterType, uint16 outBuf[BUF_H][MAX_RX])
{
    int16 i,j;
    for (i=0; i<MAX_RX;i++)
    {
        for (j=0; j<BUF_H;j++)
        {
            switch (bufferType)
            {
                case stBufType_rawProfileBuf:
                    outBuf[j][i]=inProfile[i];
                    break;
                case stBufType_baselineBuf:  //baselineBuf and temporalFilteredProfileBuf are doing the same thing
                case stBufType_temperalFilteredProfileBuf:
                    switch (temporalFilterType)
                    {
                        case stFIR_none:
                            outBuf[j][i]=inProfile[i];
                            break;
                        case stFIR_211:
                            outBuf[j][i]=inProfile[i]<<2;
                            break;
                        case stFIR_1111:
                            outBuf[j][i]=inProfile[i]<<2;
                            break;
                        default:
                            outBuf[j][i]=inProfile[i];
                            break;
                    }
                    break;
                default:
                    outBuf[j][i]=inProfile[i];
                    break;
            }
        }
    }
}

/*
//---function [lFingerList, rFingerList]=updateFingerList(obj, inLFingerList, inRFingerList, maxObjects, positionDefault)----//
void updateFingerList(sideFinger_t *lFingerList, sideFinger_t *rFingerList, int16 positionDefault)
{
    updateFingerListSingle(lFingerList, positionDefault);
    updateFingerListSingle(rFingerList, positionDefault);

}
*/

//---        function [fingerList]=updateFingerListSingle(~, inFingerList, maxObjects, positionDefault)----//

void updateFingerListSingle(sideFinger_t *fingerList, int16 positionDefault)
{
    int16 i,j;
    for (i=0;i<MAX_OBJECTS;i++)
    {
//         mexPrintf("fingerList[0].positionBuf[0:2]=%d, %d, %d \n",fingerList[0].positionBuf[0],fingerList[0].positionBuf[1], fingerList[0].positionBuf[2]);
        if (fingerList[i].stillExist ==1)
        {
            fingerList[i].time = fingerList[i].time+1;
            for (j=BUF_W-1;j>0;j--)
            {
                fingerList[i].positionBuf[j] = fingerList[i].positionBuf[j-1];
            }
            fingerList[i].positionBuf[0]= fingerList[i].currentPosition;
        }

        if (fingerList[i].stillExist ==0)
        {
            fingerList[i].index = 0;
            fingerList[i].time = 0;
            for (j=0;j<BUF_W;j++)
            {
                fingerList[i].positionBuf[j] = positionDefault;
            }
            fingerList[i].startPosition = positionDefault;
            fingerList[i].currentPosition = positionDefault;
            fingerList[i].amplitude = 0;
            fingerList[i].swipeDownStatus=0;
            fingerList[i].swipeUpStatus=0;
            fingerList[i].tapStatus =0;
            fingerList[i].stillExist=0;
            fingerList[i].semiTap=0;
            fingerList[i].prepareSemiTap = 0;
            fingerList[i].suppressEdge=0;
//             fingerList[i].area=0;
            fingerList[i].isLargeObject=0;
            fingerList[i].peakPosition=0;
            fingerList[i].filterStateFrameN=0;
            fingerList[i].maxAmplitude=0;
        }
    }
}

/*
//---function [lProfileBuf, rProfileBuf]=updateProfileBuf(~,lProfile, rProfile, inLProfileBuf, inRProfileBuf)----//
void updateProfileBuf(uint16 *lProfile, uint16 *rProfile, uint16 lProfileBuf[BUF_H][MAX_RX], uint16 rProfileBuf[BUF_H][MAX_RX])
{
    int16 i, j;
    for (i = 0; i<MAX_RX; i++)
    {
        for (j = BUF_H - 1; j>0; j--)
        {
            lProfileBuf[j][i] = lProfileBuf[j - 1][i];
            rProfileBuf[j][i] = rProfileBuf[j - 1][i];
        }
        lProfileBuf[0][i] = lProfile[i];
        rProfileBuf[0][i] = rProfile[i];
    }

}
*/
//---------------------------------------------------
int16 naturalLog(uint16 num, uint16 den)
{
  int16 v;
  v = 0;

  if (den != 0)
  {
    uint16 quotient;
    uint32 num32;
    uint16 tableIdx;
    uint16 fracPart;
    uint32 v1, v2;
    num32 = (uint32) ((den+1) / 2) + ((uint32) num * 16384);
    quotient = (uint16) (num32 / den); // 0.14-bit result
    if (quotient <= (uint16) (0.125*16384))
    {
      tableIdx = 0;
    }
    else
    {
      quotient >>= 4;
      tableIdx = 30;
    }
    tableIdx += quotient >> 6;
    fracPart = quotient & 0x3F;
    v1 = (uint32) logTable[tableIdx]*(0x40 - fracPart);
    v2 = (uint32) logTable[tableIdx+1]*fracPart;
    v = (int16) ((v1 + v2 + 0x20)/0x40);
  }
  return -v;
}

//---function [pos, width] = computeGaussianPeak(~, proj, projLength, peakIdx, prevWidth, minFingerWidth) ----//
int8p8 computeGaussianPeak(uint16* projection, int16 size, int16 peakIdx, int8p8 *gaussianWidth, int16 minFingerWidth)
{
  int16 widthFactor;

  int16 fracPos;
  // NB: postionState[i].gaussianWidth{X,Y} actually stores (-2 * width{X,Y}^-2).
  widthFactor = *gaussianWidth;
//   peakIdx = findMaxIndexArray(projection, (int16) size);

  if (size == 1)
  {
    fracPos = 0;
}
  else
  {
    int8p8 a = 0;
    int8p8 b = 0;
    if (peakIdx != 0)
    {
      uint16 zCurr = projection[peakIdx];
      uint16 zLeft = projection[peakIdx-1];     // Projection Left of peak
      a = naturalLog(zLeft, zCurr);
    }
    if (peakIdx != size - 1)
    {
      uint16 zCurr = projection[peakIdx];
      uint16 zRight = projection[peakIdx+1];    // Projection Right of peak
      b = naturalLog(zRight, zCurr);
    }

    if (peakIdx == 0)     // Left Edge
    {
      if (widthFactor >= -256)  // b would overflow an int16 -> clip it to sensor edge
      {
        b = 0x100;
      }
      else
      {
        b = (int16) (((int32)b << 8)/widthFactor);
      }
      fracPos = 0x80 - b;
    }
    else if (peakIdx == size - 1)  // Right Edge
    {
      if (widthFactor >= -256)  // a would overflow an int16 -> clip it to sensor edge
      {
        a = 0x100;
      }
      else
      {
        a = (int16) (((int32)a << 8)/widthFactor);
      }
      fracPos = -0x80 + a;
    }
    else // Center case
    {
      int32 sumAB;

      sumAB = (int32)a+b;

      // Check for divide-by-zero before the actual math
      if (sumAB == 0)
      {
        fracPos = 0;
      }
      else
      {
        int32 diffAB;
        if (sumAB < minFingerWidth)
        {
          widthFactor = minFingerWidth;
        }
        else
        {
          widthFactor = (int16)sumAB;
        }

        diffAB = (int32)(a - b) << 8;
        diffAB += (sumAB + 1) / 2;

        diffAB /= sumAB;

        // A minor precision improvement when the divide by 2
        // happens at the very end.
        fracPos = (diffAB + 1) / 2;
}
    }

    // Clipping fracPos between -0.5 < fracPos < 0.5
    if (fracPos > 0x80)
    {
      fracPos = 0x80;
    }
    else if (fracPos < -0x80)
    {
      fracPos = -0x80;
    }
  }

  *gaussianWidth = widthFactor;
  return max_int16(0, ((peakIdx << 8) + fracPos + 128)); // fixed 8.8 format.

}


int16 min_int16(int16 in1, int16 in2)
{
    int16 out;
    out = in1 < in2? in1: in2;
    return out;
}

int16 max_int16(int16 in1, int16 in2)
{
    int16 out;
    out = in1 > in2? in1: in2;
    return out;
}

int16 abs_int16(int16 a)
{
    int b;
    b = a>=0? a: (-a);
    return b;
}

