
#ifndef _MOISTURE_FILTER_H_
#define _MOISTURE_FILTER_H_
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: moisture_filter.h
   Description: Header for moisture_filter block external API
----------------------------------------------------------------- */

#if CONFIG_HAS_MOISTURE
void moistureFilter_configure(moistureFilterConfig_t *config);
void moistureFilter_filterClumps(int16 *deltaImage,
                                 int16 *deltaXProfile,
                                 int16 *deltaYProfile,
                                 sensorParams_t *sensorParams,
                                 clumps_t *clumps);
void moistureFilter_processClassifications(trackedObject_t *trackedObjects,
                                    classification_t *classifications);
#else
static ATTR_INLINE void moistureFilter_configure(ATTR_UNUSED moistureFilterConfig_t *config) {};
static ATTR_INLINE void moistureFilter_filterClumps(ATTR_UNUSED int16 *deltaImage,
                                                    ATTR_UNUSED int16 *deltaXProfile,
                                                    ATTR_UNUSED int16 *deltaYProfile,
                                                    ATTR_UNUSED sensorParams_t *sensorParams,
                                                    ATTR_UNUSED clumps_t *clumps) {};
static ATTR_INLINE void moistureFilter_processClassifications(ATTR_UNUSED trackedObject_t *trackedObjects,
                                                              ATTR_UNUSED classification_t *classifications) {};
#endif // CONFIG_HAS_MOISTURE

#endif  //_MOISTURE_FILTER_H_
