#ifndef _ROW_COL_NOISE_REMOVER_H_
#define _ROW_COL_NOISE_REMOVER_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: baseline_checker.h
// Description: Interface for baseline checker
// $Id: baseline_checker.h,v 1.6.44.1 2012/10/25 00:18:31 mposadas Exp $

#include "ifp_common.h"

#if CONFIG_HAS_ROW_COL_NOISE_REMOVER
void rowColumnNoiseRemover_configure(sensorParams_t *sensorParams, rowColumnNoiseRemoverConfig_t *rcNoiseRemoverConfig);
void rowColumnNoiseRemover_removeColumnNoise(int16 *deltaImage);
void rowColumnNoiseRemover_removeRowNoise(int16 *deltaImage);
#else
static ATTR_INLINE void rowColumnNoiseRemover_configure(sensorParams_t *sensorParams ATTR_UNUSED, rowColumnNoiseRemoverConfig_t *rcNoiseRemoverConfig ATTR_UNUSED) {};
static ATTR_INLINE void rowColumnNoiseRemover_removeColumnNoise(ATTR_UNUSED int16 *deltaImage) {};
static ATTR_INLINE void rowColumnNoiseRemover_removeRowNoise(ATTR_UNUSED int16 *deltaImage) {};
#endif

#endif  //_ROW_COL_NOISE_REMOVER_H_
