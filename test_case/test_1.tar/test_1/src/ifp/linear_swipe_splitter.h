#ifndef _LINEAR_SWIPE_SPLITTER_H
#define _LINEAR_SWIPE_SPLITTER_H

// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------

#include "ifp_common.h"

#if CONFIG_HAS_LINEAR_SWIPE_SPLITTER
void linearSwipeSplitter_configure(sensorParams_t *sensorParams, linearSwipeSplitterConfig_t *config );

void linearSwipeSplitter_split(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps);
#else
static ATTR_INLINE void linearSwipeSplitter_configure(ATTR_UNUSED sensorParams_t *sensorParams, ATTR_UNUSED linearSwipeSplitterConfig_t *config) {};
static ATTR_INLINE void linearSwipeSplitter_split(ATTR_UNUSED sensorParams_t *sensorParams, ATTR_UNUSED int16 *deltaImage, ATTR_UNUSED clumps_t *clumps) {};
#endif // CONFIG_IFP_LINEAR_SWIPE_SPLITTER


#endif //_LINEAR_SWIPE_SPLITTER_H
