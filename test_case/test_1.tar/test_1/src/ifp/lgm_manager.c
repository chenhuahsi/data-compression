//==============================================================================
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 Mckay Drive
// San Jose, CA 95131
// (408) 904-1100
//


#include "ifp_common.h"

#if CONFIG_HAS_LGM_CORRECTOR

#include "ifp_string.h"
#include "lgm_manager.h"


/* =================================================================
   MODULE MACROS
==================================================================*/

#define abs(x)       (((x) >= 0) ? (x) : -(x))

typedef struct LGMFlags
{
  uint16 bNegPixFound : 1;
  uint16 bTransAndAbsTouched : 1;
  uint16 spare : 14;
} LGMFlags_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/

static uint32 prevCapSum_LSB;

// configuration knobs, always positive eventhough they are assigned to int16
static int16 absXLGMObjectThreshold_LSB;
static int16 absYLGMObjectThreshold_LSB;
static int16 transLGMObjectThreshold_LSB;

/* =================================================================
   MODULE  INTERNAL FUNCTION DEFINITIONS
==================================================================*/

static uint16 isPreviousLGMObjectPresent(uint32 capSum_LSB);
static uint16 markTouchedElectrodes(int16 *x, uint16 len, int16 threshold, uint16 *indices, uint32 *runningSum);
static void moveZerosToEnd(touchedElectrodes_t *pSrc, uint16 cntx, uint16 cnty);

/* -----------------------------------------------------------------
Name:    isPreviousLGMObjectPresent ()
Purpose: Detects if there is more than 8% change in the sum of
         absolute delta measurements. The assumption is that if such
         a large change has occured between two frames, then either
         the object(s) touching has changed in size/area of sensor
         coverage, or the LGM conditions have changed. If the changes
         are smaller, then it is very possible that the conditions
         of the touching object nor the LGM situation have not changed.
Inputs:  current sum of absolute delta measurements
Outputs: TRUE or False
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
static uint16 isPreviousLGMObjectPresent(uint32 capSum_LSB)
{
  // It is important NOT to change < to <= in the if statement so that
  // if nothing is touching/hovering in consecutive frames, FALSE is returned.
  return (abs((int32)capSum_LSB - (int32)prevCapSum_LSB)
          < (int32)((10*prevCapSum_LSB)>>7));
}

/* -----------------------------------------------------------------
Name:    markTouchedElectrodes ()
Purpose: Find electrodes in an abs profile that are over a given threshold.
         Store the electrode indices (1-indexed), count how many are marked,
         and update a running sum.
Outputs: count (return value), indices array
Effects: runningSum updated with new contributions
Notes:   The running sum is not initialized here.
Example: None.
----------------------------------------------------------------- */
static uint16 markTouchedElectrodes(int16 *x, uint16 len, int16 threshold, uint16 *indices, uint32 *runningSum)
{
  uint16 i;
  uint16 count = 0;
  int16 *x0 = x;  // Save starting element; update this to x + 1 if we want to output as 0-indexed.
  for (i = 0; i < len; i++)
  {
    int16 val = *x++;
    if (val > threshold)
    {
      indices[count++] = (uint16)(x - x0);  // Avoid referencing i directly so that we can get FLOOP.
      *runningSum += val;
    }
  }
  return count;
}

/* -----------------------------------------------------------------
Name:    moveZerosToEnd()
Purpose: Move zeros in between masked electrodes to the end. In
         otherwords, move the masked electrode numbers next to each other.
         This improves the efficiency of the LGM corrector when it goes
         through the pixels in the bounding box. The end of valid elements
         is marked by a zero if NOT all the electrodes are being touched
Inputs:  touchedElectrodes_t *touchedIndices, uint16 cntx, uint16 cnty
         touchedElectrodes_t *touchedIndices: Indices of touched electrodes
               (one base) so that it will be clear that zero entries are
               invalid. This is helpful when masking electrodes that are
               considered as being touched in both the trans and abs domain.
         cntx, cnty: The number of elements in the input touchedIndices->x
               and y, respectively
Outputs: None
Effects: Changes the values of touchedElectrodes->x,xLength,y and yLength
         These new values will be used to create the bounding boxes whose
         pixels will be corrected for. These pixels are those which
         fall on the intersection of electrodes identified in
         touchedIndices->x, xLength and touchedIndices->y, yLength, where
         xLength and yLength mark the valid number of entries in
         touchedIndices->x and y resepctively
Notes:   None
Example: If touchedIndices->x = [1 2 3 0 5 0 6 7 0 0 0 0 0] ,cntx = 8,
         touchedIndices->y = [ 1 2 3 ] ,cnty = 3,
         then after the function has finished executing the new values
         will be
                                Marks the end of valid entries
                                           |
                                           x
         touchedIndices->x = [ 1 2 3 5 6 7 0 7 0 0 0 0 0]
         touchedIndices->xLength = 6
         touchedIndices->y = [ 1 2 3 ]
         touchedIndices->yLength = 3

----------------------------------------------------------------- */
static void   moveZerosToEnd(touchedElectrodes_t *touchedIndices, uint16 cntx, uint16 cnty)
{
  uint16 *pDest;
  uint16 *pSrc;
  uint16 j;
  uint16 lengthArray;
  uint16 lengths[2] = {0, 0};
  pDest = touchedIndices->x;

  lengthArray = cntx;
  for (j = 0; j < 2; j++)
  {
    pSrc = pDest;
    while (lengthArray > 0)
    {
      if ((*pSrc) > 0)
      {
        *pDest++ = *pSrc;
        lengths[j]++;
      }
      pSrc++;
      lengthArray--;
    }
    if (pDest != pSrc)
     *pDest = 0;
    pDest = touchedIndices->y;
    lengthArray = cnty;
  }

  touchedIndices->xLength = lengths[0];
  touchedIndices->yLength = lengths[1];
}

/*==================================================================
MODULE MAIN FUNCTIONS
===================================================================*/

/* -----------------------------------------------------------------
Name:    lgmManager_init()
Purpose: Initialize the static variables
Inputs:  None
Outputs: None
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
void lgmManager_init(void)
{
  prevCapSum_LSB = 0;
 //  ADCBitRanges.nADCBitsUsed = 12; set in lgmManager_configure()
}

/* -----------------------------------------------------------------
Name:    lgmManager_reinit()
Purpose:
Inputs:
Outputs:
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
void lgmManager_reinit(void)
{
  lgmManager_init();
}

/* -----------------------------------------------------------------
Name:    lgmManager_configure ()
Purpose: Sets the thresholds for identifying which electrodes are
         being touched in absolute and trans modes
Inputs:  None
Outputs: None
Effects: None.
Notes:   None
Example: None.
----------------------------------------------------------------- */
void lgmManager_configure(lgmManagerConfig_t *config)
{
  absXLGMObjectThreshold_LSB  = config->absXLGMObjectThreshold_LSB;
  absYLGMObjectThreshold_LSB  = config->absYLGMObjectThreshold_LSB;
  transLGMObjectThreshold_LSB = config->transLGMObjectThreshold_LSB;
}

/* -----------------------------------------------------------------
Name:    lgmManager_manage ()
Purpose: Creates parametrs that will be used by lgm_corrector.
Inputs:  1 - transcap delta Image (pDeltaImage),
         2,3 - absolute deltaProfiles (pdeltaXProfile, pdeltaYProfile),
         4 - sensorParams
         5 - Flag for disabling correction
         6 - pointer to where lgmManagerParams (that will be needed
             by the corrector) will be saved
Outputs: None
Effects: Will populate lgmManagerParams
         lgmManagerParams->skipCorrection: 1 if correctionDisabled is
             set, or if lgmManager decides that not enough information
             exists to proceed with correction. The corrector module
             will exit immediately without perfroming any correction
             if this flag is 1. Otherwise set to 0.
         lgmManagerParams->usePrevLGMCorrFactor: 1 if not enough
             information exists for calculating a new correction factor,
             however it is decided by the lgmManager that it is safe
             and valid to use the correction factor from the previous
             frame (previous object and LGM conditions exist).
             If the skipCorrection flag is 0 and this flag is 1,
             the corrector will use the correction factor from
             the previous frame on the current frame. Otherwise set to 0.
          lgmManagerParams->isPrevLGMObjStillPresent: 1 if sum of a
             bsolute delta ADC's (capacitances) don't change more
             than 8% from the previous frame. Sometimes the manager
             cannot fully decide if there is enough information
             available for correction or not. During the correction
             process the correcrtor module may decide this, in which
             case it will first look to this flag to see if it can
             use the correction factor from previous frame or not. If
             this flag is 1, it will do so, otherwise it will exit without
             perfroming any correction
          lgmManagerParams->lgmCorrElectrodes: Contains the indices of
             electrodes on  x and y axes and the number of valid
             entries in each to mark pixels which will be corrected
             for by the corrector
Notes:   None
Example: None.
----------------------------------------------------------------- */
void lgmManager_manage(int16 *pDeltaImage, int16 *pdeltaXProfile, int16 *pdeltaYProfile, sensorParams_t *pSensorParams, uint16 correctionDisabled, lgmManagerParams_t *lgmManagerParams)
{
  // Getting the masks
  uint16 cntx ; // really uint8
  uint16 cnty ; // really uint8

  // Initialize the values of arrays below to 0
  touchedElectrodes_t absTouchedElectrodes         IFP_STACKED;
  touchedElectrodes_t absAndTransTouchedElectrodes IFP_STACKED;

  // Other flags
  LGMFlags_t flags;

  //other variables
  uint16 i;
  uint16 j;
  uint32 capSum_LSB = 0;// sum of delta profiles for the touching/hovering object

  memset16(lgmManagerParams, 0, sizeof(lgmManagerParams_t) / sizeof(uint16));
  lgmManagerParams->skipCorrection = correctionDisabled;
  lgmManagerParams->usePrevLGMCorrFactor = 0;
  lgmManagerParams->isPrevLGMObjStillPresent = 0;

  // Don't do anything if config params are not set correctly
  if (absXLGMObjectThreshold_LSB <= 0 || absYLGMObjectThreshold_LSB <= 0)
  {
    lgmManagerParams->skipCorrection = 1;
    return;
  }

  if (correctionDisabled)
  {
    lgmManager_reinit();
    return;
  }

  *(uint16*)(void*)&flags = 0;

  memset16(&absTouchedElectrodes, 0, sizeof(absTouchedElectrodes) / sizeof(uint16));  //debug only
  memset16(&absAndTransTouchedElectrodes, 0, sizeof(absAndTransTouchedElectrodes) / sizeof(uint16));  //debug only

  // Save the x electrode indices that are considered as touched in absolute measurements
  cntx = markTouchedElectrodes(pdeltaXProfile, pSensorParams->rxCount, absXLGMObjectThreshold_LSB, absTouchedElectrodes.x, &capSum_LSB);
  absTouchedElectrodes.xLength = cntx;
  if (cntx < MAX_ABS_RX)
  {
    // Make sure last element is truncated by 0
    absTouchedElectrodes.x[cntx] = 0;
  }

  // Save the y electrode indices that are considered as touched in absolute measurements
  cnty = markTouchedElectrodes(pdeltaYProfile, pSensorParams->txCount, absYLGMObjectThreshold_LSB, absTouchedElectrodes.y, &capSum_LSB);
  absTouchedElectrodes.yLength = cnty;
  if (cnty < MAX_ABS_TX)
  {
    // Make sure last element is truncated by 0
    absTouchedElectrodes.y[cnty] = 0;
  }

  // Go through the deltaImage, save the indices of electrodes that are considered
  // to be touched in both trans and abs domain. This helps prevent creating ghosts
  // where there are hovering objects. Because hovering objects do not have
  // significant trans signal. Populate some of the lgm flags.
  for (j = 0; j < cnty; j++)
  {
    uint16 idx_start = (MAX_RX + 1) * absTouchedElectrodes.y[j];  // electrode indices already 1-indexed
    for (i = 0; i < cntx; i++)
    {
      uint16 idx = idx_start + absTouchedElectrodes.x[i];
      if (pDeltaImage[idx] < -pSensorParams->noiseFloor_LSB)
      {
        flags.bNegPixFound = 1;
        if ( pDeltaImage[idx] < -transLGMObjectThreshold_LSB)
        {
          absAndTransTouchedElectrodes.x[i] = absTouchedElectrodes.x[i];
          absAndTransTouchedElectrodes.y[j] = absTouchedElectrodes.y[j];
          flags.bTransAndAbsTouched = 1;
        }
      }
      else if (pDeltaImage[idx] > transLGMObjectThreshold_LSB)
      {
        absAndTransTouchedElectrodes.x[i] = absTouchedElectrodes.x[i];
        absAndTransTouchedElectrodes.y[j] = absTouchedElectrodes.y[j];
        flags.bTransAndAbsTouched = 1;
      }
    }
  }

  lgmManagerParams->isPrevLGMObjStillPresent = isPreviousLGMObjectPresent(capSum_LSB);

  if (flags.bTransAndAbsTouched == 0)
  {
    // We are either here because nothing is touching the sensor, or the object
    // has disappeared due to LGM. If object has disappeared, the correction factor
    // from previous frame maybe used if the same object under same LGM conditions
    // is still touching. Otherwise no correction should be perfromed.
    lgmManagerParams->lgmCorrElectrodes = absTouchedElectrodes;
    if (lgmManagerParams->isPrevLGMObjStillPresent == 1 && cntx!=0 && cnty !=0)
      lgmManagerParams->usePrevLGMCorrFactor = 1;
    else
      lgmManagerParams->skipCorrection = 1;
  }
  else
  {
    // If we are here it means that we were able to find electrodes which
    // exhibit signs of being touched in both trans and abs domain. In such a case
    // only pixels which fall on such electrodes should be corrected. This prevents
    // creating ghosts due to hovering objects (or even floating objects as long as
    // they do not intersect with electrodes of touching objects on BOTH axes,
    // one axis is fine)
    moveZerosToEnd(&absAndTransTouchedElectrodes, cntx, cnty);
    lgmManagerParams->lgmCorrElectrodes = absAndTransTouchedElectrodes;

    if (!flags.bNegPixFound)
    {
      // The correction scheme works based on the presence of negative pixels
      // If negative pixels do not exist within the bounding box of the touched
      // electrodes then the correction module will not have enough information
      // available for calculating a correction factor. In such a case the
      // module maybe able to use the correction factor from the prior frame if
      // the same object under same LGM conditions is present. Else do no correction.
      if (lgmManagerParams->isPrevLGMObjStillPresent == 0)
        lgmManagerParams->skipCorrection = 1;
      else
        lgmManagerParams->usePrevLGMCorrFactor = 1;
    }
  }

  // Store sum of delta profiles
  prevCapSum_LSB = capSum_LSB;
}

#endif // CONFIG_HAS_LGM_CORRECTOR
