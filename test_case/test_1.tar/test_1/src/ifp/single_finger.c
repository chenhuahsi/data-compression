// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: single_finger.c
// Description: Process measured delta profile to extract single finger inforamtion.
//  $Id:

#include "ifp_common.h"

#if CONFIG_HAS_THICK_GLOVE || CONFIG_HIC_LPWG_MODE_B
#include "single_finger.h"
#include "thick_glove.h"

/* =================================================================
   MODULE VARIABLES
==================================================================*/
#if SF_DEBUG
int16 SFCounter[4];
int16 histogram[2][28];
int16 coords[2][2];
uint16 prfLen[2];
int16 hover_DBGPJ[2] ATTR_UNUSED;
#endif

int16 previous_finger_count[SINGLE_FINGER_MAX_NUM_CLIENTS];
static singleFingerConfig_t singleFingerConfig;
uint16 dynamicThresholdPercent;
uint16 maxFingerWidth;
//int16 freshData;
uint16 reportMode;
uint16 palmThresholdPercent;
uint16 PalmCounter;
uint16 hoverCounter;
int16 hoverFlag;

/* =================================================================
   MODULE STATIC PROTOTYPES
==================================================================*/
static int16 SF_find_segments(uint16 profile_length, uint16 isX, const int16 * deltaIn, int16 threshold,
                             int16 *position0, uint16 client_ID);
static void SF_threshold_dynamically(const int16 * delta, uint16 profile_length, int16 * threshold);
static void SF_detect_Hover(uint16 profile_length,  uint16 isX, const int16 * deltaIn);

uint16 SFThreshold_Mult_factor_X;
uint16 SFThreshold_Mult_factor_Y;
/* =================================================================
   MODULE FUNCTIONS DEFINITIONS
==================================================================*/

void single_finger_init() {
  int16 i;

  dynamicThresholdPercent = SINGLE_FINGER_DYNAMIC_THRESHOLD_PERCENT_HIGH;
  maxFingerWidth = SINGLE_FINGER_MAX_FINGER_WIDTH;
//  freshData = 0;
  reportMode = cfg_SINGLE_FINGER_REPORT_MODE;
  for(i=0;i<SINGLE_FINGER_MAX_NUM_CLIENTS;i++)
  {
    previous_finger_count[i] = 0;
  }
  palmThresholdPercent = PALM_DYNAMIC_THRESHOLD_PERCENT;
  hoverFlag = 0;
  hoverCounter = 0;
  SFThreshold_Mult_factor_X = 4;
  SFThreshold_Mult_factor_Y = 4;
}

void single_finger_reinit() {
  single_finger_init();
};

void single_finger_configure(singleFingerConfig_t  *sfConfig)
{
  singleFingerConfig.thresholdXAxis = sfConfig->thresholdXAxis;
  singleFingerConfig.thresholdYAxis = sfConfig->thresholdYAxis;
  singleFingerConfig.thickGloveKneeFrames = sfConfig->thickGloveKneeFrames;
  singleFingerConfig.thickGloveKneeLowPxlPctX = sfConfig->thickGloveKneeLowPxlPctX;
  singleFingerConfig.thickGloveKneeLowPxlPctY = sfConfig->thickGloveKneeLowPxlPctY;
}

#if CONFIG_HAS_THICK_GLOVE
  extern int16 thickGloveHold;
#endif

static void SF_detect_Hover(uint16 profile_length, uint16 isX, const int16 * deltaIn)
{
  const int16 * src = deltaIn;
  int16 m = 0;
  uint16 i;
  int16 pixel = 0;

  int16 landingThresholdMin;
  int16 landingThresholdMax;

  if (isX) {
    landingThresholdMin = (int16)(((uint32)singleFingerConfig.thickGloveKneeLowPxlPctX * singleFingerConfig.thresholdXAxis) / 100);
    landingThresholdMax = singleFingerConfig.thresholdXAxis;
  } else {
    landingThresholdMin = (int16)(((uint32)singleFingerConfig.thickGloveKneeLowPxlPctY * singleFingerConfig.thresholdYAxis) / 100);
    landingThresholdMax = singleFingerConfig.thresholdYAxis;
  }

  for (i = 0; i < profile_length; i++) {
    #if HAS_SINGLE_LAYER
    if (!isX) {
      if ((i & 0x01) == 0x01) { //when odd number
        src++;
        continue;
      }
    }
    #endif

    pixel = *src++;
    if (pixel > m) {
      m = pixel;
    }
  }
#if CONFIG_HAS_THICK_GLOVE
  if (m < landingThresholdMin) thickGloveHold = 0;
#endif

  if (hoverFlag == 0) {
    uint16 thickGlovePresent = 0;
    get_thick_glove_present(&thickGlovePresent);
    if ((m > landingThresholdMin) && (m < landingThresholdMax) && (!thickGlovePresent)){
      hoverCounter++;
    } else if ((m < landingThresholdMin) || thickGlovePresent) {
      hoverCounter = 0;
    }

    if (hoverCounter >= singleFingerConfig.thickGloveKneeFrames) {
      hoverFlag = 1;
      #if SF_DEBUG
      hover_DBGPJ[0]++;
      #endif
    }
  } else {
    if (m < landingThresholdMin) {
      hoverCounter--;
      if (!hoverCounter) {
        hoverFlag = 0;
        hoverCounter = 0;
        #if SF_DEBUG
          hover_DBGPJ[1]++;
        #endif
      }
    }
  }
}

/* -----------------------------------------------------------------
Name: SF_find_segments()
Purpose: check a delta profile for 2 most energetic segments, calculates centroids of segments
Inputs: profile, profile_length, threshold
Outputs: positions in 8p8 format (0 is no finger); # segments found (0/1/2)
Effects: None.
Notes: None
Example: None.
----------------------------------------------------------------- */
static int16 SF_find_segments(uint16 profile_length,  uint16 isX, const int16 * deltaIn, int16 SFThreshold,
                             int16 *position0, uint16 client_ID)
{
  uint16 i;
  uint16 state = SEEKING_LEFT_EDGE;

  uint16 l = 0;    // start, length of current segment
  int32 e = 0, ws = 0;    // energy, weighted sum  of current segment
  int16 m = 0;            // max delta of current segment
  int16 zeroCounter = 0;

  int16 pixel;
  const int16 * src = deltaIn;
  int16 segmentCount = 0;
  int32 maxEnergy = 0;       // of up to 2 most energetic segments in profile

  uint16 numOfTraces = 0;

  *position0 = 0;

  #if SF_DEBUG
    // capture profile lengths; assumes x, y processed one after the other
    if(!prfLen[0])
    {
      prfLen[0] = profile_length;
    }
    else if (!prfLen[1])
    {
      prfLen[1] = profile_length;
    }
  #endif

  #if !SINGLE_FINGER_REJECT_WIDE_FINGER
    maxFingerWidth = profile_length;  // all widths allowed
  #endif

  if(SINGLE_FINGER_THRESHOLDING_ON == 0)
  {
    SFThreshold = 0;
  }

  if (client_ID == SF_thickGlove_client) {
    // This function detect landing event and sets hoverFlag accordingly
    SF_detect_Hover(profile_length, isX, deltaIn);
  }

  if (hoverFlag == 0) {
    // find 2 most energetic groups of non-zero pixels
    for (i = 0; i < profile_length; i++)
    {
      // This condition is required only for SLOC
      #if HAS_SINGLE_LAYER
      if (!isX) {
        if ((i & 0x01) == 0x01) { //when odd number
          src++;
          continue;
        }
      }
      #endif

      pixel = *src++;

      #if SINGLE_FINGER_ALLOW_NEGATIVE_FINGER
        if (pixel < 0)        // energy is independent of sign
        {
          pixel = -pixel;
        }
      #endif
      if (pixel <= SFThreshold)
      {
        pixel = 0;
      }
      if (pixel > m)
      {
        m = pixel;
      }

      if (pixel > (int16)((SFThreshold * palmThresholdPercent)/100)) {
        numOfTraces++;
      }

      switch (state)
      {
        case SEEKING_ZERO:
          if(pixel == 0) // found zero
          {
            // need SINGLE_FINGER__SEGMENTATION_PIXEL_THRESHOLD separation between segments
            if(zeroCounter) zeroCounter--;
            // segment separation achieved?
            if(!zeroCounter || i == profile_length - 1)
            {
              #if SF_DEBUG
                int16 index = 0;
                if(profile_length == prfLen[1])
                {
                   index = 1;
                }
                histogram[index][l]++; // update histogram
                if(histogram[index][l] > 1000)
                {
                  for (i=0;i<28;i++)
                  {
                    histogram[0][i] = 0;
                    histogram[1][i] = 0;
                  }
                }
                if(!isX) {
                  SFCounter[2]++;
                }
              #endif

              // index 0 contains segment with most energy
              if(e > maxEnergy && l <= maxFingerWidth)
              {
                segmentCount++;
                *position0 = (ws * 256) / e + 1;
                maxEnergy = e;
              }
              l = 0;
              e = 0;
              ws = 0;
              m = 0;
              state = SEEKING_LEFT_EDGE;
            }
          }
          else
          {
            l++;
            e += pixel;
            ws += i * (int32)pixel;
            state = SEEKING_RIGHT_EDGE;
          }
          break;
        case SEEKING_LEFT_EDGE:
          if(pixel != 0) // found left edge of group
          {
            #if SF_DEBUG
              if(!isX) {
                SFCounter[0]++;
              }
            #endif
            state = SEEKING_RIGHT_EDGE;
            l = 1;
            e = pixel;
            ws = (int32)pixel * i;
          }
          break;
        case SEEKING_RIGHT_EDGE:
          if(pixel == 0 )  // found potential segment
          {
//            if( i < profile_length)
            if( i <= profile_length - SINGLE_FINGER_SEGMENTATION_PIXEL_THRESHOLD - 1)
            {
              #if SF_DEBUG
                if(!isX) {
                  SFCounter[1]++;
                }
              #endif
              zeroCounter = SINGLE_FINGER_SEGMENTATION_PIXEL_THRESHOLD - 1;
              state = SEEKING_ZERO; // look for enough separation
            }
          }
          else
          {
            l++;
            e += pixel;
            ws += i * (int32)pixel;
          }
          break;
      } // switch
    } // for
  } //HoverFlag


  if (client_ID == SF_thickGlove_client) {
    if (numOfTraces > ((profile_length * 40)/100)) {
      PalmCounter++;
      return 0;
    }
  }

  if (l)
  {
    if((e > maxEnergy) && (l <= maxFingerWidth))
    {
      #if SF_DEBUG
        SFCounter[3]++;
      #endif
      segmentCount++;
      *position0 = (ws * 256) / e + 1;
    }
  }
  if(segmentCount >= 2)
  {
    segmentCount = 2;
  }
  return segmentCount;
}

/* -----------------------------------------------------------------
Name: SF_threshold_dynamically()
Purpose: thresholds a delta profile dynamically
Inputs: profile, profile_length, threshold
Outputs: adjusted threshold
Effects: None.
Notes: None
Example: None.
----------------------------------------------------------------- */
static void SF_threshold_dynamically(const int16 * delta, uint16 profile_length, int16 * threshold)
{
  int16 dynamicThreshold = 0;
  const int16 * s = delta;
  uint16 i;
  // see if threshold is exceeded anywhere
  for (i = 0; i < profile_length; i++)
  {
    int16 singlePixel = *s++;
    #if SINGLE_FINGER_ALLOW_NEGATIVE_FINGER
    if(singlePixel < 0) {
      singlePixel= -singlePixel;
    }
    #endif
    if(singlePixel > *threshold) {
      dynamicThreshold = 1;
      #if SF_DEBUG
//      SFCounter[3]++;
      #endif
      break;
    }
  }

  // if threshold was exceeded, adjust threshold
  if(dynamicThreshold  == 1)
  {
    int32 max = 0;
    int16 temp;
    s = delta;
    for (i = 0; i < profile_length; i++)
    {
      temp = *s++;
      #if SINGLE_FINGER_ALLOW_NEGATIVE_FINGER
      if (temp < 0)
      {
        temp = -temp;
      }
      #endif
      if (max < temp)
      {
        max = temp;
      }
    }
    *threshold = (max*dynamicThresholdPercent) / 100;
  }
}

#if SF_DEBUG
int16 unadjustedSFThreshold[2];
int16 maxSegmentDelta[2][2];
#endif

/* -----------------------------------------------------------------
Name: SF_process()
Purpose: checks x and y abs profiles and reports one or two fingers
Inputs:  deltaIn x 2, profile length x 2
Outputs: report, fresh data flag, finger count
Effects:
Notes:
Example:
----------------------------------------------------------------- */
int16 SF_process(const int16 * x_hybrid_data, uint16 x_profile_length, const int16 * y_hybrid_data, uint16 y_profile_length,
                 SF_dynamic_thresholding_t thresholding_level, SF_Report_t report_mode, SF_client_id_t clientId,
                 sensorPosition_t * report)
{
  int16 finger_count = 0;
  int16 freshData;
  int16 segmentCount[2];
  int16 xPos, yPos;

  // get thresholds
  int16 SFThreshold[2];
  SFThreshold[0] = singleFingerConfig.thresholdXAxis;
  SFThreshold[1] = singleFingerConfig.thresholdYAxis;

  #if SF_DEBUG
    unadjustedSFThreshold[0] = SFThreshold[0];
    unadjustedSFThreshold[1] = SFThreshold[1];
  #endif
  if (clientId == SF_moisture2_client) {
    SFThreshold[0] *= SFThreshold_Mult_factor_X;
    SFThreshold[1] *= SFThreshold_Mult_factor_Y;
  }

  // calculate delta
  if(SINGLE_FINGER_THRESHOLDING_ON)
  {
    if (SINGLE_FINGER_DYNAMIC_THRESHOLDING_ON)
    {
      switch(thresholding_level)
      {
      case   SF_dynamic_threshold_low:
                dynamicThresholdPercent = SINGLE_FINGER_DYNAMIC_THRESHOLD_PERCENT_LOW;
              break;
      case   SF_dynamic_threshold_medium:
               dynamicThresholdPercent = SINGLE_FINGER_DYNAMIC_THRESHOLD_PERCENT_MEDIUM;
              break;
      case   SF_dynamic_threshold_high:
               dynamicThresholdPercent = SINGLE_FINGER_DYNAMIC_THRESHOLD_PERCENT_HIGH;
              break;
      }

      reportMode = report_mode;

      if (clientId != SF_ForceSF_client)
      {
        SF_threshold_dynamically(x_hybrid_data, x_profile_length, &SFThreshold[0]);
        SF_threshold_dynamically(y_hybrid_data, y_profile_length, &SFThreshold[1]);
      }
    }
  }
  else
  {
    SFThreshold[0] = 0;
    SFThreshold[1] = 0;
  }

  if (clientId != SF_thickGlove_client) {
    hoverFlag = 0;
  }

  // find two most energetic fingers
  segmentCount[0] = SF_find_segments(x_profile_length, 1, x_hybrid_data, SFThreshold[0], &xPos, clientId);
  segmentCount[1] = SF_find_segments(y_profile_length, 0, y_hybrid_data, SFThreshold[1], &yPos, clientId);

  // set detected finger count
  if(segmentCount[0] == 2 && segmentCount[1] == 2)
  {
    finger_count = 2;
  }
  else if(segmentCount[0] && segmentCount[1])
  {
    finger_count = 1;
  }
  report[0].z = 0;
  // set report

  if( (finger_count == 1) || ((finger_count == 2) && ( (reportMode == REPORT_ONE_WITH_MAX_ENERGY) || (reportMode == REPORT_TWO_WITH_MAX_ENERGY))))
  {
    report[0].xPosition = xPos + 128;
    report[0].yPosition = yPos + 128;
    report[0].z = DEFAULT_Z;
    report[0].xWidth = DEFAULT_xWIDTH;
    report[0].yWidth = DEFAULT_yWIDTH;
  }

  // adjust finger count to reported finger count
  if (!report[0].z)
  {
    finger_count = 0;
  }

  // report fresh data if finger or lift
  freshData = (finger_count || previous_finger_count[clientId & 0xF]) ? 1 : 0;
  previous_finger_count[clientId & 0xF] = finger_count;
  return (freshData | (finger_count << 1));
}
#endif
