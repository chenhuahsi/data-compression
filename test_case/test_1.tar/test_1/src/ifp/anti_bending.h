#ifndef _ANTI_BENDING_H_
#define _ANTI_BENDING_H_
/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

  Description: Correct the effects of sensor bending
----------------------------------------------------------------- */

#include "ifp_common.h"

#if CONFIG_HAS_ANTI_BENDING
void antiBending_configure(sensorParams_t *sp, antiBendingConfig_t *config);
void antiBending_correctImage(sensorParams_t *sp, int16 *deltaImage);
#else
static ATTR_INLINE void antiBending_configure(ATTR_UNUSED sensorParams_t *sp, ATTR_UNUSED antiBendingConfig_t *config) {};
static ATTR_INLINE void antiBending_correctImage(ATTR_UNUSED sensorParams_t *sp, ATTR_UNUSED int16 *deltaImage) {};
#endif

#if CONFIG_HAS_ANTI_BENDING && CONFIG_HAS_HYBRID
void antiBending_correctXProfile(sensorParams_t *sp, int16 *deltaXProfile);
void antiBending_correctYProfile(sensorParams_t *sp, int16 *deltaYProfile);
#else
static ATTR_INLINE void antiBending_correctXProfile(ATTR_UNUSED sensorParams_t *sp, ATTR_UNUSED int16 *deltaXProfile) {};
static ATTR_INLINE void antiBending_correctYProfile(ATTR_UNUSED sensorParams_t *sp, ATTR_UNUSED int16 *deltaYProfile) {};
#endif  //  CONFIG_HAS_ANTI_BENDING && CONFIG_HAS_HYBRID

#endif  // _ANTI_BENDING_H_
