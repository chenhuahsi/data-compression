//-----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//-----------------------------------------------------------------
// Filename: metal_detection.c
// Description: Header file for metal_detection.c

#include "metal_detection.h"
#include "ifp_string.h"
#define get_abs16(a) (a < 0 ? (-a) : (a))
#define get_uabs16(a) (a < 0 ? (uint16)(-(a)) : (uint16)(a))

#if CONFIG_IFP_SUPPRESS_METAL

// sensor params
uint16 ADCMetalInImgRowNum = 0;
uint16 ADCMetalInImgColNum = 0;
int16 ADCMetalMinThreshold = 0;
int16 ADCMetalMaxThreshold = 0;
int16 ADCMetalHgmThreshold = 0;
int16 ADCMetalBumpinessThreshold = 0;
int16 ADCMetalCounterThreshold = 0;
int16 ADCMetalCounter = 0;
int16 ADCMetalCounterHGM = 0;
int16 ADCMetalFrameCounterThreshold = 0;
int16 ADCMetalFrameCounter = 0;
int16 ADCMetalState = 0;
int16 ADCMetalPreviousState = 0;
int16 ADCMetalNoRelaxInMetalState = 0;
int16 ADCMetalDetectEnable = 0;
int16 ADCMetalBumpinessSummary = 0;
int16 ADCMetalBumpinessSummaryAvg = 0;
int16 ADCMetalIsBigArea = 0;
int16 ADCMetalIsFlat = 0;
int16 ADCMetalIsHGM = 0;
int16 ADCMetalIsSkin = 0;
int16 ADCMetalDebugCase = 0;
int16 ADCMetalEnableHysteresis = 0;
int16 ADCMetalHysteresisRatio = 0;
int16 ADCMetalMaxDeltaImage = 0;
int16 ADCMetalBigDeltaImageCounter = 0;
int16 ADCMetalImageCounterThresholdForSkin = 0;

static metalDetectConfig_t metal_DetectParam;

//* -------------------------
//  Private functions
//---------------------------
static void _restoreThreshold()
{
    #if defined(cfg_hasMetalDetection_ADCMinThreshold)
    ADCMetalMinThreshold = cfg_hasMetalDetection_ADCMinThreshold;
    #else
    ADCMetalMinThreshold = metal_DetectParam.adcMin;
    #endif

    #if defined(cfg_hasMetalDetection_ADCMaxThreshold)
    ADCMetalMaxThreshold = cfg_hasMetalDetection_ADCMaxThreshold;
    #else
    ADCMetalMaxThreshold = metal_DetectParam.adcMax;
    #endif

    #if defined(cfg_hasMetalDetection_ADCHgmThreshold)
    ADCMetalHgmThreshold = cfg_hasMetalDetection_ADCHgmThreshold;
    #else
    ADCMetalHgmThreshold = metal_DetectParam.adcHGM;
    #endif

    #if defined(cfg_hasMetalDetection_ADCCounterThreshold)
    #  if (cfg_hasMetalDetection_ADCCounterThreshold > 0) && (cfg_hasMetalDetection_ADCCounterThreshold <= 100)
    ADCMetalCounterThreshold = (uint16)((int32)ADCMetalInImgRowNum *  ADCMetalInImgColNum * cfg_hasMetalDetection_ADCCounterThreshold) / 100; // pay attention to overflow!!!
    #  else
    ADCMetalCounterThreshold = (uint16)((int32)ADCMetalInImgRowNum *  ADCMetalInImgColNum * 40) / 100;
    #  endif
    #else
    ADCMetalCounterThreshold = (uint16)((int32)ADCMetalInImgRowNum *  ADCMetalInImgColNum * metal_DetectParam.pixelCounter) / 100; // pay attention to overflow!!!
    #endif

    #if defined(cfg_hasMetalDetection_MaxBumpinessAvgThreshold)
    ADCMetalBumpinessThreshold = cfg_hasMetalDetection_MaxBumpinessAvgThreshold;
    #else
    ADCMetalBumpinessThreshold = metal_DetectParam.bumpiness;
    #endif
}

//* -------------------------
//  Public functions
//---------------------------
void metal_detect_configure(metalDetectConfig_t* metalDetectConfig)
{
  memcpy16(&metal_DetectParam, metalDetectConfig, sizeof(metalDetectConfig_t)/sizeof(uint16));
}

// return metal detected state.
int16 metal_detection_getState(void)
{
    return ADCMetalState;
}

// TODO need optimization
void metal_detection_init(sensorParams_t *sensorParams)
{
    ADCMetalInImgRowNum = sensorParams->txCount;
    ADCMetalInImgColNum = sensorParams->rxCount;

    ADCMetalCounter = 0;
    ADCMetalFrameCounter = 0;
    ADCMetalBumpinessSummary = 0;
    ADCMetalState = 0;
    ADCMetalPreviousState = 0;

    ADCMetalIsBigArea = 0;
    ADCMetalIsFlat = 0;
    ADCMetalIsSkin = 0;

    ADCMetalMaxDeltaImage = 0;
    ADCMetalBigDeltaImageCounter = 0;

    // init other settings after RowNum and ColNum
    #if defined(cfg_hasMetalDetection_ADCFrameCounterThreshold)
    ADCMetalFrameCounterThreshold = cfg_hasMetalDetection_ADCFrameCounterThreshold;
    #else
    ADCMetalFrameCounterThreshold = metal_DetectParam.frameCounterThreshold;
    #endif

    #if defined(cfg_hasMetalDetection_NoRelaxInMetalState)
    ADCMetalNoRelaxInMetalState = cfg_hasMetalDetection_NoRelaxInMetalState;
    #else
    ADCMetalNoRelaxInMetalState = ((metal_DetectParam.metalDetectControl&0x02) == 0x02)? 1:0;
    #endif

    #if defined(cfg_hasMetalDetection_HysteresisRatio)
    ADCMetalEnableHysteresis = (cfg_hasMetalDetection_HysteresisRatio > 0)? 1:0;
    ADCMetalHysteresisRatio = cfg_hasMetalDetection_HysteresisRatio;
    #else
    ADCMetalEnableHysteresis = ((metal_DetectParam.metalDetectControl&0x04) == 0x04)? 1:0;
    ADCMetalHysteresisRatio = metal_DetectParam.hysteresisRatio;
    #endif

    #if defined(cfg_hasMetalDetection)
    ADCMetalDetectEnable = (cfg_hasMetalDetection>0)? 1:0;
    #else
    ADCMetalDetectEnable = metal_DetectParam.metalDetectControl & 0x01;
    #endif

    #if defined (cfg_hasMetalDetection)
    ADCMetalImageCounterThresholdForSkin = 4;
    #else
    ADCMetalImageCounterThresholdForSkin = metal_DetectParam.skinCounter;
    #endif

    _restoreThreshold();
}

void metal_detection_detect(int16* mDeltaImage)
{
    uint16 rowSkip = MAX_RX - ADCMetalInImgColNum;
    uint16 i = ADCMetalInImgRowNum;
    int16 *deltaImage = mDeltaImage;
           deltaImage += (MAX_RX + 1) + 1;  // account for border

    ADCMetalCounter = 0; // this counter should be initialized to ZERO in each frame!!!
    ADCMetalCounterHGM = 0;
    ADCMetalBumpinessSummary = 0;
    ADCMetalBumpinessSummaryAvg = 0;
    ADCMetalIsBigArea = 0;
    ADCMetalIsFlat = 0;
    ADCMetalIsSkin = 0;
    ADCMetalIsHGM = 0;
    ADCMetalMaxDeltaImage = 0;
    ADCMetalBigDeltaImageCounter = 0;
    if(!ADCMetalDetectEnable)
    {
        ADCMetalFrameCounter = 0;
        ADCMetalState = 0;
        ADCMetalPreviousState = 0;
        ADCMetalDebugCase = 0;
        return;
    }
    ADCMetalPreviousState = ADCMetalState;

    int* lineImage = deltaImage;
    int16 deltaImageData = 0;
    uint16 j = 0;
    int* previousLine;
    int* thisLine;
    int* nextLine;
    int16 lineLength = (ADCMetalInImgColNum + rowSkip + 1);
    int16 pixelBumpiness = 0;

    for(i = 0; i < ADCMetalInImgRowNum; i++)  // 15
    {
        previousLine = lineImage - lineLength;
        thisLine = lineImage;
        nextLine = lineImage + lineLength;

        for(j = 0; j < ADCMetalInImgColNum; j++) // 26
        {
            deltaImageData = lineImage[j];
            if((deltaImageData > ADCMetalMinThreshold) && (deltaImageData < ADCMetalMaxThreshold))
            {
                ADCMetalCounter++;
            }
            else if(deltaImageData >= ADCMetalMaxThreshold)
            {
                ADCMetalBigDeltaImageCounter++;
                if(deltaImageData >= ADCMetalHgmThreshold)
                    ADCMetalCounterHGM++;
            }

            if(deltaImageData > ADCMetalMaxDeltaImage)
            {
                ADCMetalMaxDeltaImage = deltaImageData;
            }

            // compute the bumpiness
            // we use the delta image directly, instead of raw image
            pixelBumpiness = 0;
            if(i != 0)
            {
                pixelBumpiness += thisLine[j] - previousLine[j];
            }
            if(i != (ADCMetalInImgRowNum - 1))
            {
                pixelBumpiness += thisLine[j] - nextLine[j];
            }
            ADCMetalBumpinessSummary += get_abs16(pixelBumpiness);
        }
        lineImage += lineLength;
    }

    ADCMetalIsBigArea = (ADCMetalCounter >= ADCMetalCounterThreshold)? 1 : 0;
    if(ADCMetalIsBigArea)
    {
        ADCMetalBumpinessSummaryAvg = (int16)(((uint32)ADCMetalBumpinessSummary << 4) / ADCMetalCounter);
        //ADCMetalIsFlat = (ADCMetalBumpinessSummary < ADCMetalBumpinessThreshold)? 1 : 0;
        ADCMetalIsFlat = (ADCMetalBumpinessSummaryAvg < ADCMetalBumpinessThreshold)? 1 : 0;
        ADCMetalIsSkin = ((ADCMetalMaxDeltaImage > ADCMetalMaxThreshold)
                       && (ADCMetalBigDeltaImageCounter >= ADCMetalImageCounterThresholdForSkin))? 1 : 0;
    }
    ADCMetalIsHGM = (ADCMetalCounterHGM >= ADCMetalCounterThreshold * 2 / 3) ? 1 : 0;

    if(ADCMetalIsHGM || (ADCMetalIsBigArea && ADCMetalIsFlat && !ADCMetalIsSkin))
    {
        if(!ADCMetalState)
        {
            ADCMetalDebugCase = 1;

            ADCMetalFrameCounter++;
            if(ADCMetalFrameCounter >= ADCMetalFrameCounterThreshold)
            {
                ADCMetalState = 1;
                ADCMetalFrameCounter = 0;

                ADCMetalDebugCase = 2;
            }
        }
        else
        {
            ADCMetalFrameCounter = 0;

            ADCMetalDebugCase = 3;
        }
    }
    else
    {
        if(ADCMetalState)
        {
            ADCMetalDebugCase = 4;

            ADCMetalFrameCounter++;
            if(ADCMetalFrameCounter >= ADCMetalFrameCounterThreshold)
            {
                ADCMetalState = 0;
                ADCMetalFrameCounter = 0;

                ADCMetalDebugCase = 5;
            }
        }
        else
        {
            ADCMetalFrameCounter = 0;

            ADCMetalDebugCase = 6;
        }
    }

    if(ADCMetalEnableHysteresis && (ADCMetalHysteresisRatio != 0))
    {
        if(ADCMetalState && !ADCMetalPreviousState)
        {
            ADCMetalMinThreshold = ADCMetalMinThreshold * ADCMetalHysteresisRatio / 100;
            ADCMetalMaxThreshold = (int16)((int32)ADCMetalMaxThreshold * 100 / ADCMetalHysteresisRatio); // extend
            ADCMetalHgmThreshold = (int16)((int32)ADCMetalHgmThreshold * ADCMetalHysteresisRatio / 100);
            ADCMetalCounterThreshold = ADCMetalCounterThreshold * ADCMetalHysteresisRatio / 100;
            ADCMetalBumpinessThreshold = (int16)((int32)ADCMetalBumpinessThreshold * 100 / ADCMetalHysteresisRatio); // extend
        }
        else if(!ADCMetalState && ADCMetalPreviousState)
        {
            _restoreThreshold();
        }
    }
}
#endif

