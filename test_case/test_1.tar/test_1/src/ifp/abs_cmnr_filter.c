// -----------------------------------------------------------------
// Abs CMNR Filter
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//

#include "ifp_common.h"

#if CONFIG_HAS_ABS_CMNR_FILTER

#include "abs_cmnr_filter.h"

// TODO:  Make this a generic NxN spatial filter class


static absFilterConfig_t mAFConfig;

static int16 absFilter_computeCMNR(int16* pAbs, const uint16 num);
static void absFilter_applyCMNR(int16* pAbs, int16 cmnr, const uint16 num);

static int16 absFilter_computeCMNR(int16* pAbs, const uint16 num)
{
  int16 cmnr = 0;
  int32 sumADC = 0;
  uint16 numPixels = 0;

  uint16 i;
  for (i=0; i < num; i++)
  {
    sumADC += *pAbs;
    numPixels++;
    pAbs++;
  }

  if (numPixels)
  {
    cmnr = sumADC/numPixels;
  }

  return cmnr;
}


static void absFilter_applyCMNR(int16* pAbs, int16 cmnr, const uint16 num)
{
  uint16 i;
  for (i=0; i < num; i++)
  {
    if ((*pAbs >= 0) && (*pAbs <= cmnr))
    {
      // Limit the correction
      *pAbs = 0;
    }
    else if ((*pAbs < 0) && (*pAbs >= cmnr))
    {
      // Limit the correction
      *pAbs = 0;
    }
    else
    {
      *pAbs -= cmnr;
    }
    pAbs++;
  }
}


void absFilter_init()
{
}


void absFilter_reinit()
{
  absFilter_init();
}


void absFilter_configure(absFilterConfig_t* config)
{
  mAFConfig.enableX = config->enableX;
  mAFConfig.enableY = config->enableY;
}


void absFilter_applyFilter(int16* absPtr, const uint16 num, const uint16 isX)
{
  int16 cmnr;

  if (!isX && !mAFConfig.enableY)
  {
    return;
  }
  if (isX && !mAFConfig.enableX)
  {
    return;
  }

  cmnr = absFilter_computeCMNR(absPtr, num);
  if (cmnr)
  {
    absFilter_applyCMNR(absPtr, cmnr, num);
  }
}

#endif // CONFIG_HAS_ABS_CMNR_FILTER
