// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: position_estimator.c
// Description: Computes position and width of fingers,pen,palm of the sensor pitch units
//              Reports position information for 1 - MAX_OBJECTS.
//
// $Id:$

#include "ifp_common.h"
#include "ifp_string.h"
#include "position_estimator.h"
#include "clump_projector.h"
#if CONFIG_HAS_NOTCH_CUT
#ifndef MAX_CIRCLE_POINTS
#define MAX_CIRCLE_POINTS 20
#endif
#define sqrtf(x) ((x) == 0.0f ? (x) : __builtin_sqrtf(x))
#define CUTOUT_INFLUENCE_DISTANCE 2
#define MAX_FRAMES_WTHOUT_CIRCLE_FIT 20
#define MU 2.f
#define LAMBDA 2.f
#define NU 4.f
#define MU_LAMBDA 4.f
#define MU_NU 8.f
#define SQUARE(x) ((x)*(x))
#define MIN(a,b)  ((a) > (b) ?  (b) : (a))
#define MAX(a,b)  ((a) < (b) ?  (b) : (a))
#define ABS(x)    ((x) > 0 ? (x) : (-(x)))
#define ROUND_8P8(x) ( ( (x) + ((x) > 0 ? (int8p8)128 : (int8p8)(-128) ) ) >> 8)
#endif // CONFIG_HAS_NOTCH_CUT

/* =================================================================
   MODULE TYPES
==================================================================*/

typedef enum
{
  edgeState_bothEdgesPresent = 0,
  edgeState_leftEdgeMissing = 1,
  edgeState_rightEdgeMissing = 2,
  edgeState_bothEdgesMissing = 3,
} edgeState_t;

typedef struct
{
  int8p8 firstEstimate;
  uint16 recomputeOffset;
  uint16 bothEdgesMissing;
  uint8p8 position;
  int32 L;
  int32 G;
  int8p8 wL;
  int8p8 wG;
  uint16 projLen;
  uint16 edgeState;
} positionInfo_t;

typedef struct
{
  int8p8 gaussianWidth;
  int8p8 largeObjectWidth;
} width_t;
#if CONFIG_HAS_NOTCH_CUT
struct circlePosition {
  float x;
  float y;
  float r;
};
#endif // CONFIG_HAS_NOTCH_CUT

/* =================================================================
   MODULE VARIABLES
==================================================================*/

static struct positionState_t
{
  width_t wX, wY;
  struct pos_t
  {
    int8p8 offset;
    int8p8 position;
  } x, y;
#if CONFIG_HAS_NOTCH_CUT
  int8p8 circleCenterX;
  int8p8 circleCenterY;
  uint4p12 circleR;
  int16 peakAmplitude;
  uint4p12 sigmaR;
#endif // CONFIG_HAS_NOTCH_CUT
  uint16 prevTouchType : 8;
#if CONFIG_HAS_NOTCH_CUT
  uint16 framesSinceCircleFit : 5;
  uint16 reportAtNotch : 1;
#endif // CONFIG_HAS_NOTCH_CUT FIXME: Added it into above same define
  uint16 edgeStateX : 2;
  uint16 edgeStateY : 2;
#if CONFIG_HAS_GLOVE_MIN_SIZE
  uint16 nextTouchType : 4;
#endif
} positionState[MAX_OBJECTS];

static int16 gaussianWidthX;
static int16 gaussianWidthY;
static int16 minFingerWidthX;
static int16 minFingerWidthY;
#if CONFIG_HAS_GLOVE_MIN_SIZE
static int16 minGloveWidthX;
static int16 minGloveWidthY;
#endif
#if CONFIG_HAS_NOTCH_CUT
uint16 circleFitEn;
static int8p8 circleCenterX;
static int8p8 circleCenterY;
static uint4p12 circleR;
static int16 peakAmplitude;
static uint4p12 sigmaR;
static uint0p16 contourPeakFrac;

static uint16 cutOutInfluenceRows[(MAX_TX + OBJECT_BITMASK_SIZE - 1) / OBJECT_BITMASK_SIZE];
static uint16 cutOutInfluenceCols[(MAX_RX + OBJECT_BITMASK_SIZE - 1) / OBJECT_BITMASK_SIZE];
#endif // CONFIG_HAS_NOTCH_CUT
static struct positionConfig_t
{
  uint8p8 zMin;
  uint8p8 zMax;
  int1p15 corrAtZMin;
} xConfig, yConfig;

static rom_uint16 logTable[] = {
  // Matlab: round([-8 log([linspace(1/256,31/256,32) linspace(1/8,1,15) 1])]*4096)
  // Table is in 4.12-bit signed fixed point
  // Entries 0-31 are log(x) for 0 <= x < 1/8
  // Entries 32-47 are log(x) for 1/8 <= x <= 1
  // Entry 48 is log(1) repeated to save ROM in the interpolation routine
  32767, 22713, 19874, 18213, 17035, 16121, 15374, 14743, 14196, 13713,
  13282, 12891, 12535, 12207, 11903, 11621, 11357, 11108, 10874, 10653,
  10443, 10243, 10052, 9870, 9696, 9529, 9368, 9213, 9064, 8921, 8782,
  8647, 8517, 6857, 5678, 4764, 4017, 3386, 2839, 2357, 1925, 1535,
  1178, 850, 547, 264, 0, 0 };

#if CONFIG_GRIPSUPPRESSION_RULE2
#include "../grip_suppression.h"
static uint16 left_sensor, right_sensor, peak_sensor;
static uint16 ratioPeak;
#endif

/* =================================================================
   MODULE STATIC PROTOTYPES
==================================================================*/
ATTR_INLINE static void clearStateInfo(uint16 objIdx);
static void returnSensorPosition(sensorPosition_t *sensorPositions, trackedObject_t *trackedObjects, uint16 objIdx, uint16 getCentroidPosition);
static uint16 findMaxIndexArray(uint16 *pA, int16 size);
static int8p8 computeLargeObjectPosition(uint16* proj, positionInfo_t *pos);
static int16 naturalLog(uint16 num, uint16 den);
static int8p8 computeGaussianPeak(uint16* proj, positionInfo_t *pos, int16 minFingerWidth);
ATTR_INLINE static uint8p8 blendingFunction(int8p8 w);
static uint16 isAllZero(uint16 *proj, uint16 count);
static void computeStylusProjection(uint16 projX[], uint16 projY[], int16 deltaImage[], clumps_t *clumps, uint16 clumpId);
static int8p8 correctPosition(int8p8 pos, uint8p8 zNormalized, int16 length, struct positionConfig_t *posConfig, int8p8 offset);
static int8p8 calcPosition(positionInfo_t *pos, uint16 *proj, uint16 edgeState, width_t w, int16 minFingerWidth);
static void calcOffset(positionInfo_t *pos, int8p8 largeObjectWidth, int8p8 *offset);
#if CONFIG_HAS_NOTCH_CUT
static float computeMeanFloat(float *input, uint16 numElements);
static float computeRangeFloat(float *input, uint16 numElements);
static void calcFingerPosition(sensorParams_t *sensorParams, uint16 *projX, uint16 *projY, clumps_t *clumps, int16 *deltaImage, trackedObject_t *trackedObjects, uint16 trackInd, sensorPosition_t *sensorPositions, objectBitmask_t circleFitFlags);
static objectBitmask_t computeCircleFitFlags(sensorParams_t *sensorParams, clumps_t *clumps, trackedObject_t *trackedObjects);
static void updatePositionWithCircleFit(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps, uint16 clumpId, uint16 trackInd, int8p8 *posX, int8p8 *posY, positionInfo_t *posInfoX, positionInfo_t *posInfoY);
static void findContourPointsAndCutoutDistance(int16 *deltaImage, sensorParams_t *sensorParams, clumps_t *clumps, uint16 clumpId, int16 level, float *ptsX, float *ptsY, float *ptsWt, uint16 *ptsCount);
static void findNeighborhoodContourPoints(int16 *deltaImage, sensorParams_t *sensorParams, int16 level, float *ptsX, float *ptsY, float *ptsWt, uint16 *ptsCount, uint16 rCurrent, uint16 cCurrent, int8p8 xCurrent, int8p8 yCurrent);
static void fitCircle(float *ptsX, float *ptsY, float *ptsWt, uint16 ptsCount, float prevR, int8p8 prevX, int8p8 prevY, struct circlePosition *pos);
static void optimize3x3withRegularization(float *ptsX, float *ptsY, float *ptsWt, uint16 ptsCount, struct circlePosition * p, objectBitmask_t regMode);
static void choleskyFactorization3x3(float *m);
static uint8p8 findCutoutDistance(sensorParams_t *sensorParams, int8p8 positionX, int8p8 positionY);
static uint8p8 computeCircleFitBlendWeight(uint8p8 posCutoutDist, uint8p8 rC);
static uint16 isCornerIsland(int16 *deltaImage, sensorParams_t *sensorParams, int16 level, uint16 r, uint16 c);
static uint16 arePointsSufficient(float *ptsX, float *ptsY, uint16 ptsCount, uint16 prevReportAtNotch);
static void correctPositionPriorForCollinearPoints(sensorParams_t *sensorParams, float *ptsX, float *ptsY, uint16 ptsCount, int8p8 *posX, int8p8 *posY);
static uint16 isWholePixelCutout(sensorParams_t *sensorParams, uint16 positionX, uint16 positionY);
static uint4p12 updateSigma(uint4p12 currentSigma, uint4p12 calculatedSigma);
static void fitLine(float *ptsX, float *ptsY, uint16 ptsCount, float *m, float *c);
static float getMaxDistanceFromPointsToLine(float *ptsX, float *ptsY, uint16 ptsCount, float m, float c);
#else
static void calcFingerPosition(sensorParams_t *sensorParams, uint16 *projX, uint16 *projY, trackedObject_t *trackedObjects, uint16 trackInd, sensorPosition_t *sensorPositions);
#endif // CONFIG_HAS_NOTCH_CUT
static int16 sinApprox(int16 pos);
/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/
static int16 sinApprox(int16 pos)
{
  int16 p = pos & 0x3f; // 10.6
  int16 quadrant = (pos >> 6) & 0x3;
  int16 pSquared;
  int16 v1;
  uint16 v;

  if (quadrant & 1) p = 64 - p;
  pSquared = p*p; // 4.12

  //sin(pi/2*x) ~= x * (1.570791011 - 0.6458928493*x^2 + 0.0794343442*x^4)
  v1 = 2603; // 1.15
  v1 = (int16) (((int32) v1 * pSquared) >> 15); // 5.27 -> 4.12
  v1-= 2646; // 4.12
  v1 = (int16) (((int32) v1 * pSquared) >> 12); // 8.24 -> 4.12
  v1+= 6434; // 4.12
  v = (uint16) (((int32) v1 * p) >> 3); // 14.18 -> 1.15
  if (v & 0x8000) v = 0x7FFF;

  if (quadrant > 1)
    return (int16) -v;
  else
    return (int16) v;
}
/* ------------------------------------------------------------------------
Name: clearStateInfo()
Purpose: Clear persistent state information.
Inputs: track index
Outputs: None.
Effects: Clears persistent state information.
Notes: Clear persistent state information: offset, edgeState,
       but keep widths and position.
Example: None.
------------------------------------------------------------------------- */
ATTR_INLINE static void clearStateInfo(uint16 objIdx)
{
  positionState[objIdx].edgeStateX = edgeState_bothEdgesPresent;
  positionState[objIdx].edgeStateY = edgeState_bothEdgesPresent;
  positionState[objIdx].x.offset = 0;
  positionState[objIdx].y.offset = 0;
}

/* ------------------------------------------------------------------------
Name: returnSensorPosition()
Purpose: Return sensor position (x,y).
Inputs: sensorPositions, trackedObjects, object Index
Outputs: sensorPositions
Effects: None.
Notes: When we have only negatives in a projection due to LGM affects or
       if Palm is detected return centroid position and do not compute new
       positions.
Example: None.
------------------------------------------------------------------------- */
static void returnSensorPosition(sensorPosition_t *sensorPositions, trackedObject_t *trackedObjects, uint16 objIdx, uint16 getCentroidPosition)
{
  sensorPositions[objIdx].xWidth = positionState[objIdx].wX.largeObjectWidth;
  sensorPositions[objIdx].yWidth = positionState[objIdx].wY.largeObjectWidth;
  sensorPositions[objIdx].z = trackedObjects[objIdx].zerothMoment;

  if (getCentroidPosition == 1)
  {
    sensorPositions[objIdx].xPosition = trackedObjects[objIdx].xCentroid - 128;
    sensorPositions[objIdx].yPosition = trackedObjects[objIdx].yCentroid - 128;
  }
  else
  {
    sensorPositions[objIdx].xPosition = positionState[objIdx].x.position;
    sensorPositions[objIdx].yPosition = positionState[objIdx].y.position;
  }
}

/* ------------------------------------------------------------------------
Name: findMaxIndexArray()
Purpose: Finds the index of the maximum value in the array.
Inputs: Pointer to array, size of array
Outputs: Index of maximum value in the array
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static uint16 findMaxIndexArray(uint16 *pA, int16 size)
{
  uint16 maxV = *pA;
  uint16 maxIndex = 0;
  uint16 index = 0;
  while (size--)
  {
    if (*pA >= maxV)
    {
      maxV = *pA;
      maxIndex = index;
    }
    index++;
    pA++;
  }
  return maxIndex;
}

/* ------------------------------------------------------------------------
Name: computeLargeObjectPosition()
Purpose: Computes the position of an object larger than a few pixels wide.
Inputs:  proj - the X/Y projection
         *pos - Pointer to X or Y state
Outputs: position (signed 8.8 integer)
Effects: None.
Notes: The algorithm finds the peak of the projection and then calculates
       the outermost points where the projection crosses 75% of maximum
       amplitude. The average of these two points is the position, and
       the distance between them is the width.

       When the finger is near the sensor edge, the algorithm no longer
       works. For that case, we remember the previous width estimate and
       use the available edge to make a position estimate. Even on the
       edge, the width estimate is updated if the finger is obviously
       larger than the stored width.

       Since this can create a jump in reported position if the width of
       the touch changes before both edges are available again, we also
       track an offset between the position calculated with the new
       width and position calculated with the old width. This function
       tells the calling code when to update that offset.

       The offset is recomputed when:
         1) The finger transitions from edge to interior of the sensor
         2) Is still on the edge but the width estimate has grown
            larger than the previous estimate.
------------------------------------------------------------------------- */
static int8p8 computeLargeObjectPosition(uint16* proj, positionInfo_t *pos)
{
  uint16 peakIdx;
  uint16 peak;
  uint16 peakThreshold;
  uint16 edgeThreshold;
  edgeState_t currEdgeState;
  int16 i;
  int8p8 fracPos = 0;
  int8p8 newWidth;
  int16 leftIdx = 0;
  int16 leftEdge = 0;
  int16 rightIdx = pos->projLen - 1;
  int16 rightEdge = pos->projLen - 1;
  int8p8 x1 = 0;
  int8p8 x2 = 0;

  if (pos->projLen < 1)
  {
    pos->recomputeOffset = FALSE;
    pos->firstEstimate = 0;
    pos->edgeState = edgeState_bothEdgesMissing;
    return 0;
  }

  peakIdx = findMaxIndexArray(proj, (int16) pos->projLen);
  peak = proj[peakIdx];
  pos->recomputeOffset = FALSE;
  pos->bothEdgesMissing = FALSE;

  // Isolate the peak and edge thresholds setting the edge threshold
  // lower than the peak threshold. If the edge threshold is as high as
  // the peak threshold, when large fingers with smooth edges enter the
  // sensor from an edge, both edges are detected even before the
  // whole finger is inside the sensor. This leads to the recomputeOffset
  // flag being set prematurely causing incorrect offsets.
  peakThreshold = (peak >> 1) + (peak >> 2); // peak * 0.75
  edgeThreshold = (peak >> 1); // peak * 0.5

  // Search from either side in and find the first index that crosses
  // the peak threshold to find the width
  for (i = 0; i < (int16) pos->projLen; i++)
  {
    if (proj[i] > peakThreshold)
    {
      leftIdx = i;
      break;
    }
  }

  for (i = pos->projLen-1; i >= 0; i--)
  {
    if (proj[i] > peakThreshold)
    {
      rightIdx = i;
      break;
    }
  }

  x2 = 256*leftIdx;
  x1 = 256*rightIdx;

  if (leftIdx != 0)
    {
    x2 -= 256;
    x2 += (int8p8) ((int32) 256*((int16) peakThreshold - (int16) proj[leftIdx-1])/(proj[leftIdx]-proj[leftIdx-1]));
  }
  if (rightIdx != (int16) pos->projLen - 1)
    {
    x1 += 256;
    x1 -= (int8p8) ((int32) 256*((int16) peakThreshold - (int16) proj[rightIdx+1])/(proj[rightIdx]-proj[rightIdx+1]));
  }
  newWidth = x1 - x2;

  // Search from either side in and find the first index that crosses
  // the edge threshold to detect missing edges
       for (i = 0; i < (int16) pos->projLen; i++)
       {
    if (proj[i] > edgeThreshold)
           {
      leftEdge = i;
               break;
           }
       }

       for (i = pos->projLen-1; i >= 0; i--)
       {
    if (proj[i] > edgeThreshold)
           {
      rightEdge = i;
               break;
           }
       }

#if CONFIG_GRIPSUPPRESSION_RULE2
    {
       uint32 tempsig=0;
       uint16 GripPeakThreshold;
       left_sensor=right_sensor=peak_sensor=0xffff;
       ratioPeak=0;
       left_sensor =leftIdx;
       right_sensor=rightIdx;
       peak_sensor = peakIdx;

       GripPeakThreshold = ((uint32)peak * 10) / 100;
       GripPeakThreshold=(GripPeakThreshold>10)?GripPeakThreshold:10;
       for (i = 0; i < (int16) pos->projLen; i++)
       {
       if (proj[i] > GripPeakThreshold)
           {
               left_sensor = i;
               break;
           }
       }

       for (i = pos->projLen-1; i >= 0; i--)
       {
       if (proj[i] > GripPeakThreshold)
           {
               right_sensor = i;
               break;
           }
       }
       if(right_sensor==(uint16)pos->projLen-1)
      {
       tempsig=(uint32)proj[pos->projLen-2];
       tempsig*=100;
       tempsig/=(uint32)proj[pos->projLen-1];
       ratioPeak=(uint16)tempsig;
      }
      else if(left_sensor==0)
       {
        tempsig=(uint32)proj[1];
        tempsig*=100;
        tempsig/=(uint32)proj[0];
        ratioPeak=(uint16)tempsig;
       }
      else
      {
        ratioPeak =0;
      }

     }
#endif


  if (leftEdge == 0 && rightEdge == (int16) pos->projLen - 1)
  {
    currEdgeState = edgeState_bothEdgesMissing;
    pos->bothEdgesMissing = TRUE;
    fracPos = x2 + newWidth/2;
  }
  else if (leftEdge == 0)
  {
    currEdgeState = edgeState_leftEdgeMissing;
    if (newWidth < pos->wL)
    {
      newWidth = pos->wL;
    }
    fracPos = x1 - newWidth/2;
  }
  else if (rightEdge == (int16) pos->projLen - 1)
  {
    currEdgeState = edgeState_rightEdgeMissing;
    if (newWidth < pos->wL)
    {
      newWidth = pos->wL;
    }
    fracPos = x2 + newWidth/2;
  }
  else
  {
    currEdgeState = edgeState_bothEdgesPresent;
    fracPos = x2 + newWidth/2;
  }

  // Was the position off the edge on the last frame and in the sensor
  // interior this frame? If so, update firstEstimate for offset calculations
  // and set the recompute offset flag.
  if (currEdgeState == edgeState_bothEdgesPresent)
  {
    switch(pos->edgeState)
    {
    case edgeState_leftEdgeMissing:
      pos->firstEstimate = x1 - pos->wL/2;
      pos->recomputeOffset = TRUE;
      break;
    case edgeState_rightEdgeMissing:
      pos->firstEstimate = x2 + pos->wL/2;
      pos->recomputeOffset = TRUE;
      break;
    default:
      pos->firstEstimate = fracPos;
      break;
    }
  }
  else
  {
    pos->firstEstimate = fracPos;
  }

  pos->wL = newWidth;
  pos->edgeState = currEdgeState;
  return fracPos;
}

/* ------------------------------------------------------------------------
Name: naturalLog()
Purpose: performs a calculation log(num/den).
Inputs: numerator, denominator
Outputs: v Q4.12
Effects: None.
Example: None.
Notes: Requires that numerator <= denominator
------------------------------------------------------------------------- */
int16 naturalLog(uint16 num, uint16 den)
{
  int16 v;
  v = 0;

  if (den != 0)
  {
    uint16 quotient;
    uint32 num32;
    uint16 tableIdx;
    uint16 fracPart;
    uint32 v1, v2;
    num32 = (uint32) ((den+1) / 2) + ((uint32) num * 16384);
    quotient = (uint16) (num32 / den); // 0.14-bit result
    if (quotient <= (uint16) (0.125*16384))
    {
      tableIdx = 0;
    }
    else
    {
      quotient >>= 4;
      tableIdx = 30;
    }
    tableIdx += quotient >> 6;
    fracPart = quotient & 0x3F;
    v1 = (uint32) logTable[tableIdx]*(0x40 - fracPart);
    v2 = (uint32) logTable[tableIdx+1]*fracPart;
    v = (int16) ((v1 + v2 + 0x20)/0x40);
  }
  return -v;
}

#if CONFIG_HAS_NOTCH_CUT
/* ------------------------------------------------------------------------
Name: computeMeanFloat()
Purpose: calculates the mean of the input array of length numElements.
     The value of numElements must be <= 32767
Inputs: inputArray
    numElements
Outputs: arrayMean
Effects: None.
Example: None.
Notes:
------------------------------------------------------------------------- */
static float computeMeanFloat(float *inputArray, uint16 numElements) {
  if (numElements > 0x7FFF) {
#if !defined(__CHIMERA__) && defined(MATLAB_MEX_FILE)
    mexErrMsgIdAndTxt("IFP:IFPVectorUtil:valueError",
      "Tried to calculate mean of array of length more than 32767");
#else
    return 0.f;
#endif
  }
  else if (numElements == 0) {
    return 0.f;
  }
  uint16 i;
  double arraySum = 0.0;
  for (i = 0; i < numElements; i++) {
    arraySum += *inputArray++;
  }
  return (float)(arraySum / numElements);
}

/* ------------------------------------------------------------------------
Name: computeRangeFloat()
Purpose: finds the range of the input array of length numElements.
The value of numElements must be <= 32767
Inputs: inputArray
        numElements
Outputs: arrayRange
Effects: None.
Example: None.
Notes:
------------------------------------------------------------------------- */
static float computeRangeFloat(float *inputArray, uint16 numElements)
{
  if (numElements > 0x7FFF)
  {
#if !defined(__CHIMERA__) && defined(MATLAB_MEX_FILE)
    mexErrMsgIdAndTxt("IFP:IFPVectorUtil:valueError",
      "Tried to calculate mean of array of length more than 32767");
#else
    return 0.f;
#endif
  }
  else if (numElements == 0)
  {
    return 0.f;
  }
  uint16 i;
  float arrayMin = *inputArray, arrayMax = *inputArray;
  for (i = 1; i < numElements; i++)
  {
    inputArray++;
    if (*inputArray < arrayMin)
    {
      arrayMin = *inputArray;
    }
    else if (*inputArray > arrayMax)
    {
      arrayMax = *inputArray;
    }
  }
  return arrayMax - arrayMin;
}

#endif

/* ------------------------------------------------------------------------
Name: computeGaussianPeak()
Purpose: Returns position using the gaussian position algorithm.
Inputs:  proj - the X/Y projection
         *pos - Pointer to X or Y state
         gaussianWidth - previous gaussianWidth
         minFingerWidth - min finger width
Outputs: position (signed 8.8 integer)
Effects: None.
Notes:
PsuedoCode:
let xPeakIdx = index of maximum value in projection
if xPeakIdx == 0
    z0 = projection[0]
    zr = projection[1]
    v = log(zr/z0)   // note: all logs are natural log
    xFracPos = 1/2 + (*lastWidthSquared) * v
else if xPeakIdx == size - 1
    z0 = projection[size-1]
    zl = projection[size-2]
    u = log(zl/z0)
    xFracPos = -1/2 + (*lastWidthSquared) * u
else
    zl = projection[xPeakIdx-1]
    z0 = projection[xPeakIdx]
    zr = projection[xPeakIdx+1]
    u = log(zl/z0)
    v = log(zr/z0)
    xFracPos = 1/2 * (u-v)/(u+v)
    (*lastWidthSquared) = -1/(u+v)
end
clip xFrac to between -0.75 and 0.75
position = xPeakIdx + xFrac
return position

Example: None.
------------------------------------------------------------------------- */
static int8p8 computeGaussianPeak(uint16* proj, positionInfo_t *pos, int16 minFingerWidth)
{
  int16 peakIdx;
  int16 fracPos;
  int16 size = (int16) pos->projLen;
  // NB: postionState[i].gaussianWidth{X,Y} actually stores (-2 * width{X,Y}^-2).
  int16 widthFactor = pos->wG;
  peakIdx = findMaxIndexArray(proj, size);

  if (size == 1)
  {
    fracPos = 0;
  }
  else
  {
    int8p8 a = 0;
    int8p8 b = 0;
    if (peakIdx != 0)
    {
      uint16 zCurr = proj[peakIdx];
      uint16 zLeft = proj[peakIdx-1];     // Projection Left of peak
      a = naturalLog(zLeft, zCurr);
    }
    if (peakIdx != size - 1)
    {
      uint16 zCurr = proj[peakIdx];
      uint16 zRight = proj[peakIdx+1];    // Projection Right of peak
      b = naturalLog(zRight, zCurr);
    }

    if (peakIdx == 0)     // Left Edge
    {
      if (widthFactor >= -256)  // b would overflow an int16 -> clip it to sensor edge
      {
        b = 0x100;
      }
      else
      {
        b = (int16) (((int32)b << 8)/widthFactor);
      }
      fracPos = 0x80 - b;
    }
    else if (peakIdx == size - 1)  // Right Edge
    {
      if (widthFactor >= -256)  // a would overflow an int16 -> clip it to sensor edge
      {
        a = 0x100;
      }
      else
      {
        a = (int16) (((int32)a << 8)/widthFactor);
      }
      fracPos = -0x80 + a;
    }
    else // Center case
    {
      int32 sumAB;

      sumAB = (int32)a+b;

      // Check for divide-by-zero before the actual math
      if (sumAB == 0)
      {
        fracPos = 0;
      }
      else
      {
        int32 diffAB;
        if (sumAB < minFingerWidth)
        {
          widthFactor = minFingerWidth;
        }
        else
        {
          widthFactor = (int16)sumAB;
        }

        diffAB = (int32)(a - b) << 8;
        diffAB += (sumAB + 1) / 2;

        diffAB /= sumAB;

        // A minor precision improvement when the divide by 2
        // happens at the very end.
        fracPos = (diffAB + 1) / 2;
      }
    }

    // Clipping fracPos between -0.75 < fracPos < 0.75
    if (fracPos > 192)
    {
      fracPos = 192;
    }
    else if (fracPos < -192)
    {
      fracPos = -192;
    }
  }

  pos->wG = widthFactor;
  return ((peakIdx << 8) + fracPos); // fixed 8.8 format.
}

/* ------------------------------------------------------------------------
Name: blendingFunction()
Purpose: Returns a blending coefficient that decides which algorithm is used
         based on width, which is corrected for projection effects.
Inputs:Width Q8.8
Outputs:Blending coeficient Q8.8
Effects: None.
Notes: Intialize sensorPositions structure to all zeros and positionState
to hold default values. Projecting at 45 or -45 degrees means that one unit
of distance is 1 / sqrt(2) physical pitches away.
Example: None.
------------------------------------------------------------------------- */
ATTR_INLINE static uint8p8 blendingFunction(int8p8 w)
{
  uint16 a = 0;

  // blend
  if (w > 640)  // 2.5
  {
    a = 256;
  }
  else if (w >= 384)  // 1.5
  {
    a = w - 384;
  }
  return a;
}

/* ------------------------------------------------------------------------
Name: isAllZero()
Purpose: determine if all elements of an array are zero
Inputs: array, number of elements
Outputs:
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static uint16 isAllZero(uint16 *proj, uint16 count)
{
  uint16 allZerosFlag = 1;
  uint16 i;
  for(i = 0; i < count; i++, proj++)
  {
    if(*proj != 0)
    {
      allZerosFlag = 0;
      break;
    }
  }
  return allZerosFlag;
}

/* ------------------------------------------------------------------------
Name: computeStylusProjection()
Purpose: calculate row and column projections for a clump within a 3-by-3 pixel area
         around the peak location
Inputs: projX, projY - projection arrays, must be initialized to zero
        deltaImage
        clumps
        clumpId - the clumpId to project
Outputs: projX, projY
Effects: None.
Example: None.
Notes: Stylus pixels are guaranteed to be positive, so this does not use
       absolute values of pixels for projections.
       We assume that stylus blobs take up a whole clump. That is, we cannot
       have multiple styluses in a clump.
------------------------------------------------------------------------- */
static void computeStylusProjection(uint16 projX[], uint16 projY[], int16 deltaImage[], clumps_t *clumps, uint16 clumpId)
{
  uint16 row,col;
  clumpInfo_t *clumpInfo;
  uint16 *labelPtr;
  int16 *deltaPtr;
  uint16 *projPtrX, *projPtrY;
  uint16 addr;
  uint16 r, c;
  uint16 STRIDE = (MAX_RX+1) - 3;

  clumpInfo = &clumps->info[clumpId - 1];
  // get peak's NE neighbor
  row = clumpInfo->peakLocation.row - 1;
  col = clumpInfo->peakLocation.col - 1;
  addr = row*(MAX_RX+1) + col;
  labelPtr = &clumps->labelImage[addr];
  deltaPtr = &deltaImage[addr];

  projPtrX = &projX[col-1]; // adjust for image padding
  projPtrY = &projY[row-1];

  for (r = 3; r > 0; r--, labelPtr+=STRIDE, deltaPtr+=STRIDE)
  {
    for (c = 3; c > 0; c--, labelPtr++, deltaPtr++)
    {
      if ((*labelPtr & 0xFF) == clumpId)
      {
        *projPtrX += (*deltaPtr > 0) ? *deltaPtr : 0;
        *projPtrY += (*deltaPtr > 0) ? *deltaPtr : 0;
      }
      projPtrX++;
    }
    projPtrX -= 3;
    projPtrY++;
  }
}

/* ------------------------------------------------------------------------
Name: correctPosition()
Purpose: Adds a small offset to the position to reduce systematic errors
Inputs: pos - original position, in signed 8.8 format, pitch units
        zNormalized - the zeroth moment of the finger in units of
                      saturation capacitances, 8.8 unsigned format
        length - (sensorParams->rxCount-1) for x and (sensorParams->txCount-1) for y
        *posConfig - Pointer to struct containing the following fields:
              zMin - the minimum Z expected to be seen, in units of
                     saturation capacitance, 8.8 unsigned format
              zMax - the maximum Z to apply the correction for, in
                     units of saturation capacitance, 8.8 unsigned format
              corrAtZMin - the amount of correction to apply at the
                           minimum Z, in signed 1.15 format.
        offset - Offset necessary to maintain relative motion after starting on
                 the edge or moving past the edge.
Outputs: corrected position
Effects: None.
Example: None.
Notes: The algorithm is

  corr = corrAtZMin * (zMax-zNormalized)/(zMax-zMin);
  posFrac = pos - floor(pos);
  pos += corr*sin(2*pi*posFrac);

In other words, it corrects the computed position by adding a some multiple
of sin(2*pi*fractional part of position) to it. The scale factor varies
linearly from corrAtZMin at zMin down to 0 at zMax.

This is obviously not a perfect correction. It's intended to increase
linearity of a stylus to the point where error is smaller than the
jitter and therefore not noticeable.

------------------------------------------------------------------------- */
int8p8 correctPosition(int8p8 pos, uint8p8 zNormalized, int16 length, struct positionConfig_t *posConfig, int8p8 offset)
{
  // First pixel should be at (0.5, 0.5).
  pos -= 128;

  if (zNormalized < posConfig->zMax && pos > 256 && pos < length*256)
  {
    int16 corr;
    uint32 zFrac;
    int16 sinPosFrac;

    if (posConfig->zMax <= posConfig->zMin)
    {
      return pos;
    }

    if (zNormalized < posConfig->zMin)
    {
      zNormalized = posConfig->zMin;
    }
    zFrac = ((uint32)(posConfig->zMax-zNormalized)<<16)/(posConfig->zMax-posConfig->zMin);
    corr = (int16)(((int32)posConfig->corrAtZMin * zFrac)>>16);

    sinPosFrac = sinApprox(pos);
    pos += (int16) (((int32) corr * sinPosFrac + 0x200000L)>>22);

  }
  pos += offset;  // Adjust position with offset
  return pos;
}

/* ------------------------------------------------------------------------
Name: calcPosition()
Purpose: Calculates X or Y position
Inputs: *pos - Pointer to X or Y positionInfo_t struct
        *proj - Pointer to X or Y projection
        edgeState
        width_t struct
        minFingerWidth
Outputs: Position
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static int8p8 calcPosition(positionInfo_t *pos, uint16 *proj, uint16 edgeState,
                           width_t w, int16 minFingerWidth)
{
  uint16 bCoef;
  pos->edgeState = edgeState;
  pos->wL = w.largeObjectWidth;
  pos->wG = w.gaussianWidth;
  pos->L = computeLargeObjectPosition(proj, pos);
  bCoef = blendingFunction(pos->wL);
  pos->G = computeGaussianPeak(proj, pos, minFingerWidth);
  pos->position = (int16)(((256-bCoef)*pos->G + bCoef * pos->L)/256); // 8.8
  return (pos->position + 0x100); // coordinate system starts at 1, positions computed starting at 0
}

/* ------------------------------------------------------------------------
Name: calcOffset()
Purpose: If recompute offset flag is set, compute blended position based on estimated position and re-compute offset.
Inputs: *pos - Pointer to X or Y state
        largeObjectWidth
        *offset - Pointer to original offset
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static void calcOffset(positionInfo_t *pos, int8p8 largeObjectWidth, int8p8 *offset)
{
    uint16 bCoef;
    int16 estimatedPos;
    bCoef = blendingFunction(largeObjectWidth);
  estimatedPos = ((256-bCoef)*pos->G + bCoef*(int32)pos->firstEstimate)/256;
  *offset = estimatedPos - pos->position;
}

/* ------------------------------------------------------------------------
Name: calcFingerPosition()
Purpose: Determine finger position
Inputs: sensorParams,
        *projX - Pointer to X projection
        *projY - Pointer to Y projection
        trackedObjects
        trackInd
        sensorPositions
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */
#if CONFIG_HAS_NOTCH_CUT
static void calcFingerPosition(sensorParams_t *sensorParams, uint16 *projX, uint16 *projY,
                               clumps_t *clumps, int16 *deltaImage,
                               trackedObject_t *trackedObjects, uint16 trackInd,
                               sensorPosition_t *sensorPositions,
                               objectBitmask_t circleFitFlags)
#else
static void calcFingerPosition(sensorParams_t *sensorParams, uint16 *projX, uint16 *projY,
                               trackedObject_t *trackedObjects, uint16 trackInd,
                               sensorPosition_t *sensorPositions)
#endif //CONFIG_HAS_NOTCH_CUT
{
  if (isAllZero(projX, sensorParams->rxCount) || isAllZero(projY, sensorParams->txCount))
  {
    //Update sensorPositions, return centroid positions from tracker
    returnSensorPosition(sensorPositions, trackedObjects, trackInd, 1);
  }
  else
  {
    positionInfo_t X, Y;
    int8p8 offsetX, offsetY;
    int8p8 positionX, positionY;
    struct positionState_t *curState = &positionState[trackInd];

    X.projLen = sensorParams->rxCount;
    Y.projLen = sensorParams->txCount;

    // Compute X and Y positions
  #if CONFIG_HAS_GLOVE_MIN_SIZE
    positionX = calcPosition(&X, projX, curState->edgeStateX, curState->wX,
      curState->nextTouchType == touchType_glove ? minGloveWidthX : minFingerWidthX);
  #else
    positionX = calcPosition(&X, projX, curState->edgeStateX, curState->wX, minFingerWidthX);
  #endif
#if CONFIG_GRIPSUPPRESSION_RULE2
    Touch_SensorInfor[trackInd].Rx_width=right_sensor-left_sensor+1;
    Touch_SensorInfor[trackInd].Rx_max=right_sensor;
    Touch_SensorInfor[trackInd].Rx_min=left_sensor;
    Touch_SensorInfor[trackInd].Rx_peak = peak_sensor;
    Touch_SensorInfor[trackInd].Rx_Ratio = ratioPeak;
#endif
  #if CONFIG_HAS_GLOVE_MIN_SIZE
    positionY = calcPosition(&Y, projY, curState->edgeStateY, curState->wY,
      curState->nextTouchType == touchType_glove ? minGloveWidthY : minFingerWidthY);
  #else
    positionY = calcPosition(&Y, projY, curState->edgeStateY, curState->wY, minFingerWidthY);
  #endif
#if CONFIG_GRIPSUPPRESSION_RULE2
    Touch_SensorInfor[trackInd].Tx_width=right_sensor-left_sensor+1;
    Touch_SensorInfor[trackInd].Tx_max=right_sensor;
    Touch_SensorInfor[trackInd].Tx_min=left_sensor;
    Touch_SensorInfor[trackInd].Tx_peak = peak_sensor;
    Touch_SensorInfor[trackInd].Tx_Ratio = ratioPeak;
#endif
#if CONFIG_HAS_NOTCH_CUT
    // Calculate circle fit if necessary
    {
      struct position_t
      {
        int8p8 offset;
        int8p8 position;  // at the end, convert to x, y for report
      } x, y;
      uint16 clumpId = trackedObjects[trackInd].clumpId;

      x.position = X.position + 0x100;
      y.position = Y.position + 0x100;
      if (circleFitFlags & (1 << (clumpId -1))) {
        updatePositionWithCircleFit(sensorParams, deltaImage, clumps, clumpId, trackInd, &x.position, &y.position, &X, &Y);
      }
      else {
        int16 peakValue;
        uint16 peakOffset;

        positionState[trackInd].reportAtNotch = 1;  // We have left the zone, so allow reporting again.
        peakOffset = clumps->info[clumpId - 1].peakLocation.row *(MAX_RX + 1) + clumps->info[clumpId - 1].peakLocation.col;
        peakValue = deltaImage[peakOffset];

        if (peakValue > curState->peakAmplitude) {
          curState->peakAmplitude = peakValue;
        }
        else {
          // Find the approximate amplitude at half pitch - shift from the peak
          // This gives us the maximum value for which we need to update peakAmplitude
          int16 halfPitchShiftAmplitude = curState->peakAmplitude * 3 / 4;

          if (peakValue < halfPitchShiftAmplitude) {
            curState->peakAmplitude = (int16)((int32)peakValue * curState->peakAmplitude / halfPitchShiftAmplitude);
          }
        }
      }
    }
#endif //CONFIG_HAS_NOTCH_CUT
    // Compute offsets; these are necessary to maintain relative motion after
    // starting on the edge or moving past the edge. Compute an offset only
    // if both edges are present in the other axis to prevent an offset from
    // being calculated using an incorrect projection.
    offsetX = curState->x.offset;
    offsetY = curState->y.offset;
    if ((X.recomputeOffset == TRUE) && (Y.edgeState == edgeState_bothEdgesPresent))
    {
      calcOffset(&X, curState->wX.largeObjectWidth, &offsetX);
    }
    if ((Y.recomputeOffset == TRUE) && (X.edgeState == edgeState_bothEdgesPresent))
    {
      calcOffset(&Y, curState->wY.largeObjectWidth, &offsetY);
    }

    // Add offsets to improve linearity of small fingers
    {
      positionX = correctPosition(positionX, trackedObjects[trackInd].zerothMoment, (int16)sensorParams->rxCount-1, &xConfig, offsetX);
      positionY = correctPosition(positionY, trackedObjects[trackInd].zerothMoment, (int16)sensorParams->txCount-1, &yConfig, offsetY);
    }

    // If both edges are missing, report position in previous frame
    if (curState->prevTouchType != touchType_none)
    {
      if (X.bothEdgesMissing == TRUE)
      {
        positionX = curState->x.position;
      }
      if (Y.bothEdgesMissing == TRUE)
      {
        positionY = curState->y.position;
      }
    }

    // Update internal state
    curState->x.position = positionX;
    curState->y.position = positionY;
    if (((X.edgeState == edgeState_bothEdgesPresent) && (Y.edgeState == edgeState_bothEdgesPresent))
#if CONFIG_HAS_REPORT_PALM_UPDATE_WX_WY && !(CONFIG_HAS_EXTREME_NOISE_REMOVER && CONFIG_EXT_CENTROID_POSITIONING)
     || (curState->prevTouchType == touchType_palm)
#endif
    )
    {
      curState->wX.largeObjectWidth = X.wL;
      curState->wY.largeObjectWidth = Y.wL;
      curState->wX.gaussianWidth = X.wG;
      curState->wY.gaussianWidth = Y.wG;
    }
    curState->edgeStateX = X.edgeState;
    curState->edgeStateY = Y.edgeState;
    curState->x.offset = offsetX;
    curState->y.offset = offsetY;

    // Output
    returnSensorPosition(sensorPositions, trackedObjects, trackInd, 0);
  }
}

#if CONFIG_HAS_NOTCH_CUT
/* ------------------------------------------------------------------------
Name: choleskyFactorization3x3()
Purpose: Compute the Cholesky factorization matrix for a 3x3 input matrix
Inputs: m - 3x3 matrix (as array of length 9)
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static void choleskyFactorization3x3(float *m)
{
  m[0] = sqrtf(m[0]);
  m[1] = m[1] / m[0];
  m[2] = m[2] / m[0];
  m[4] = sqrtf(m[4] - (m[1] * m[1]));
  m[5] = (m[5] - (m[2] * m[1])) / m[4];
  m[8] = sqrtf(m[8] - (m[2] * m[2] + m[5] * m[5]));

  // m[3] = m[1];
  // m[6] = m[2];
  // m[7] = m[5];
}


/* ------------------------------------------------------------------------
Name: optimize3x3withRegularization()
Purpose: Compute the Gauss-Newton least squares optimization
for a 3x3 input matrix with a linear regularization term
Inputs: ptsX
        ptsY
        ptsWt
        ptsCount
        circlePosition
        regMode
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */

static void optimize3x3withRegularization(float *ptsX, float *ptsY, float *ptsWt, uint16 ptsCount, struct circlePosition * p, objectBitmask_t regMode)
{
  uint16 i, j, radiusMode, positionMode;
  float prevR, prevX, prevY;

  radiusMode = regMode & 0x01;
  positionMode = regMode & 0x02;


  prevX = p->x;
  prevY = p->y;
  prevR = p->r;


  // Optimize
  for (j = 0; j < 10; j++)
  {
    float v1, v2, v3, y0, y1, y2;
    float A[9], B[3];
    // Av = B, where A = Jr*Jr.' and B = Jr*r
    // Initialize arrays
    memset16(A, 0, sizeof(A) / sizeof(uint16));
    memset16(B, 0, sizeof(B) / sizeof(uint16));

    // Array multiplication
    for (i = 0; i < ptsCount; i++)
    {
      float D, Jr1, Jr2, Jr3, r;
      D = sqrtf(SQUARE(ptsX[i] - p->x) + SQUARE(ptsY[i] - p->y));

      Jr1 = (p->x - ptsX[i]) / D;
      Jr2 = (p->y - ptsY[i]) / D;
      Jr3 = -1;

      r = D - p->r;

      B[0] += Jr1 * ptsWt[i] * r;
      B[1] += Jr2 * ptsWt[i] * r;
      B[2] += Jr3 * ptsWt[i] * r;

      A[0] += Jr1 * ptsWt[i] * Jr1;

      A[1] += Jr1 * Jr2;
      A[4] += Jr2 * ptsWt[i] * Jr2;

      A[2] += Jr1 * Jr3;
      A[5] += Jr2 * Jr3;
      A[8] += Jr3 * ptsWt[i] * Jr3;
    }

    if (radiusMode) {
      // Regularizing w.r.t. radius
      A[8] += MU_NU;
      B[2] += MU_NU*(p->r - prevR);
    }
    if (positionMode) {
      // Regularizing w.r.t. position
      A[0] += MU_LAMBDA;
      A[4] += MU_LAMBDA;

      B[0] += MU_LAMBDA*(p->x - prevX);
      B[1] += MU_LAMBDA*(p->y - prevY);
    }

    // Find Cholesky factorization of A
    choleskyFactorization3x3(A);

    y0 = B[0] / A[0];
    y1 = (B[1] - A[1] * y0) / A[4];
    y2 = (B[2] - A[2] * y0 - A[5] * y1) / A[8];

    v3 = y2 / A[8];
    v2 = (y1 - A[5] * v3) / A[4];
    v1 = (y0 - v3 * A[2] - v2 * A[1]) / A[0];

    // Update
    p->x -= v1;
    p->y -= v2;
    p->r -= v3;

    if ((ABS(v1) < 0.001) && (ABS(v2) < 0.001) && (ABS(v3) < 0.001)) {
      break;
    }
  }

}


/* ------------------------------------------------------------------------
Name: computeCircleFitFlags()
Purpose: Determine which clumps are in the cutout region and set the
corresponding flags
Inputs: sensorParams
    clumps
    trackedObjects
Outputs: circleFitFlags
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static objectBitmask_t computeCircleFitFlags(sensorParams_t *sensorParams, clumps_t *clumps, trackedObject_t *trackedObjects) {
  objectBitmask_t circleFitFlags = 0;

  if (sensorParams->cutOutLength > 0)
  {
    uint16 i,c;

    for (c = 0; c < MAX_RX; c++)
    {
      if ((cutOutInfluenceCols[c / OBJECT_BITMASK_SIZE]) & (1 << (c % OBJECT_BITMASK_SIZE)))
      {
        uint16 r;
        for (r = 0; r < MAX_TX; r++)
        {
          if ((cutOutInfluenceRows[r / OBJECT_BITMASK_SIZE]) & (1 << (r % OBJECT_BITMASK_SIZE)))
          {
            uint16 label = clumps->labelImage[(r + 1)*(MAX_RX + 1) + c + 1];
            if (label > 0 && label <= MAX_OBJECTS && clumps->info[label - 1].polarity == polarity_positive)
            {
              circleFitFlags |= 1 << (label - 1);
            }
          }
        }
      }
    }

    for (i = 0; i < MAX_OBJECTS; i++) // Iterating over trackInd, not clumpId
    {
      uint16 clumpId = (trackedObjects + i)->clumpId;
      if (clumpId > 0)
      {
        if (circleFitFlags & (1 << (clumpId -1)))
        {
          positionState[i].framesSinceCircleFit = 0;
        }
        else if (trackedObjects[i].trackedFrames < 15)
        {
          circleFitFlags |= 1 << (clumpId - 1);
          positionState[i].framesSinceCircleFit = 0;
        }
        else if (positionState[i].framesSinceCircleFit == MAX_FRAMES_WTHOUT_CIRCLE_FIT)
        {
          circleFitFlags |= 1 << (clumpId - 1);
          // While updating every MAX_FRAMES_WITHOUT_CIRCLE_FIT frames, ensure that
          // the previous circle fit position is cleared
          positionState[i].circleCenterX = circleCenterX;
          positionState[i].circleCenterY = circleCenterY;
          positionState[i].framesSinceCircleFit = 0;
        }
        else
        {
          positionState[i].framesSinceCircleFit++;
        }
      }
    }
  }
  return circleFitFlags;
}

/* ------------------------------------------------------------------------
Name: updatePositionWithCircleFit()
Purpose: Estimate position with circle fit and update accordingly
Inputs: sensorParams
clumps
circleFitFlags - flag noting which clumps are in the cutout region
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static void updatePositionWithCircleFit(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps, uint16 clumpId, uint16 trackInd, int8p8 *posX, int8p8 *posY, positionInfo_t *posInfoX, positionInfo_t *posInfoY) {

  int16 peakValue, circleThreshold;
  uint16 offset, ptsCount;
  uint8p8 cutoutDist, blendWeight;

  float ptsX[MAX_CIRCLE_POINTS], ptsY[MAX_CIRCLE_POINTS], ptsWt[MAX_CIRCLE_POINTS];

  offset = clumps->info[clumpId - 1].peakLocation.row*(MAX_RX + 1) + clumps->info[clumpId - 1].peakLocation.col;
  peakValue = deltaImage[offset];
  if (peakValue > positionState[trackInd].peakAmplitude) {
    positionState[trackInd].peakAmplitude = peakValue;
  }

  // Get contour points threshold, clipping to noise floor
  circleThreshold = (int16) (((uint32) positionState[trackInd].peakAmplitude * contourPeakFrac + 32768) >> 16);
  if (circleThreshold < sensorParams->noiseFloor_LSB)
  {
    circleThreshold = sensorParams->noiseFloor_LSB;
  }

  findContourPointsAndCutoutDistance(deltaImage, sensorParams, clumps, clumpId, circleThreshold, ptsX, ptsY, ptsWt, &ptsCount);


  // Only update if there are sufficient contour points found
  if (arePointsSufficient(ptsX, ptsY, ptsCount, positionState[trackInd].reportAtNotch) == (uint16)1) {
    struct circlePosition circPos;
    float expectedR, calculatedSigma;

    positionState[trackInd].reportAtNotch = 1;
    expectedR = sqrtf(((float) naturalLog((uint16)circleThreshold,(uint16)(positionState[trackInd].peakAmplitude))) / -4096.f);
    expectedR *= (float)(positionState[trackInd].sigmaR) / 4096.f;

    // Use previous center to initialize circle fit if the object existed in the previous frame
    // Else, initialize with position estimate
    if (positionState[trackInd].circleCenterX != circleCenterX)
    {
      fitCircle(ptsX, ptsY, ptsWt, ptsCount, expectedR, positionState[trackInd].circleCenterX, positionState[trackInd].circleCenterY, &circPos);
    }
    else
    {
      int8p8 priorX, priorY;
      priorX = *posX;
      priorY = *posY;
      correctPositionPriorForCollinearPoints(sensorParams, ptsX, ptsY, ptsCount, &priorX, &priorY);
      fitCircle(ptsX, ptsY, ptsWt, ptsCount, expectedR, priorX, priorY, &circPos);
    }

    calculatedSigma = circPos.r / sqrtf(((float) naturalLog((uint16)circleThreshold,(uint16)(positionState[trackInd].peakAmplitude))) / -4096.f);
    positionState[trackInd].sigmaR = updateSigma(positionState[trackInd].sigmaR, (uint4p12)(calculatedSigma*4096.f + 0.5));

    positionState[trackInd].circleCenterX = (int8p8)(circPos.x*256.f + 0.5);
    positionState[trackInd].circleCenterY = (int8p8)(circPos.y*256.f + 0.5);
    positionState[trackInd].circleR = (uint4p12)(circPos.r*4096.f + 0.5);

    cutoutDist = findCutoutDistance(sensorParams, positionState[trackInd].circleCenterX, positionState[trackInd].circleCenterY);
    blendWeight = computeCircleFitBlendWeight(cutoutDist, positionState[trackInd].circleR >> 4);

    *posX = (int16)(((int32)(256 - blendWeight)*(*posX) + (int32)blendWeight * positionState[trackInd].circleCenterX) / 256);
    *posY = (int16)(((int32)(256 - blendWeight)*(*posY) + (int32)blendWeight * positionState[trackInd].circleCenterY) / 256);

    if (blendWeight > 230) {
      posInfoX->recomputeOffset = FALSE;
      posInfoY->recomputeOffset = FALSE;
    }
  }
  else {
    positionState[trackInd].reportAtNotch = 0;
  }
}

/* ------------------------------------------------------------------------
Name: findContourPointsAndCutoutDistance()
Purpose: Find contour points to fit a circle to. In addition,
     find the minimum distance to the cutout from
     any point within the clump
Inputs: deltaImage
    sensorParams
    clumps
    clumpId
    level - threshold for finding contour points
    ptsX
    ptsY
    ptsWt
    ptsCount
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static void findContourPointsAndCutoutDistance(int16 *deltaImage, sensorParams_t *sensorParams, clumps_t *clumps,
  uint16 clumpId, int16 level,
  float *ptsX, float *ptsY, float *ptsWt, uint16 *ptsCount) {
  pixelIndex_t currentNode;
  uint16 i;
  uint16 activatedPixelCount = 0;

  currentNode = clumps->info[clumpId - 1].firstPixel;
  while (currentNode.row != 0) {
    uint16 row = currentNode.row;
    uint16 col = currentNode.col;
    uint16 offset = row*(MAX_RX + 1) + col;
    if (deltaImage[offset] > level) {
      activatedPixelCount++;
    }
    currentNode = clumps->listImage[offset];
  }

  currentNode = clumps->info[clumpId - 1].firstPixel;
  *ptsCount = 0;

  while ((currentNode.row != 0) && (*ptsCount < MAX_CIRCLE_POINTS)) {
    uint16 row = currentNode.row;
    uint16 col = currentNode.col;
    uint16 offset = row*(MAX_RX + 1) + col;

    // Only look for pixels above the threshold level
    if ( (deltaImage[offset] > level) && ( (activatedPixelCount < 2) || (isCornerIsland(deltaImage, sensorParams, level, row, col)==0)) ){
      int8p8 xCurrent, yCurrent;
      uint16 useCurrent = 1;

      xCurrent = (int8p8)(col << 8); //8.8
      yCurrent = (int8p8)(row << 8); //8.8

      for (i = 0; i < sensorParams->cutOutLength; i++) {
        // If the current location is cut out
        if ((row == (sensorParams->cutOutRows[i] + 1)) && (col == (sensorParams->cutOutCols[i] + 1))) {
          // Ignore pixels that are completely cut out
          if (sensorParams->cutOutFraction[i] == 0) {
            useCurrent = 0;
          }
          // Else, update centroid
          else {
            xCurrent += sensorParams->centroidOffsetCol[i];
            yCurrent += sensorParams->centroidOffsetRow[i];
          }
        }
      }

      if (useCurrent == 1) {
        findNeighborhoodContourPoints(deltaImage, sensorParams, level, ptsX, ptsY, ptsWt, ptsCount, row, col, xCurrent, yCurrent);
      }
    }
    currentNode = clumps->listImage[offset];
  }
}

/* ------------------------------------------------------------------------
Name: findNeighborhoodContourPoints()
Purpose: Find all contour points in the neighborhood of
     the current pixel
Inputs: deltaImage
    sensorParams
    level - threshold for finding contour points
    ptsX
    ptsY
    ptsWt
    ptsCount
    rCurrent - row index of pixel of interest
    cCurrent - column index of pixel of interest
    xCurrent - x coordinate of pixel centroid
    yCurrent - y coordinate of pixel centroid
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static void findNeighborhoodContourPoints(int16 *deltaImage, sensorParams_t *sensorParams, int16 level,
  float *ptsX, float *ptsY, float *ptsWt, uint16 *ptsCount,
  uint16 rCurrent, uint16 cCurrent, int8p8 xCurrent, int8p8 yCurrent) {
  uint16 i, offset;
  uint16 rNeigh = 0, cNeigh = 0;
  float respCurrent;

  offset = rCurrent*(MAX_RX + 1) + cCurrent;
  respCurrent = (float)deltaImage[offset];

  for (i = 0; (i < 4) && (*ptsCount < MAX_CIRCLE_POINTS) ; i++) { //Set up for 4C, change for 8C
    switch (i) {
    case 0:
      rNeigh = rCurrent - 1;
      cNeigh = cCurrent;
      break;
    case 1:
      rNeigh = rCurrent;
      cNeigh = cCurrent - 1;
      break;
    case 2:
      rNeigh = rCurrent;
      cNeigh = cCurrent + 1;
      break;
    case 3:
      rNeigh = rCurrent + 1;
      cNeigh = cCurrent;
      break;
    default:
      break;
    }

    // Ignore neighbors in zeropadded area
    if ((rNeigh > 0) && (rNeigh <= sensorParams->txCount) && (cNeigh > 0) && (cNeigh <= sensorParams->rxCount)) {
      offset = rNeigh*(MAX_RX + 1) + cNeigh;

      // Only look for neighbors at or below threshold
      if (deltaImage[offset] <= level) {
        int8p8 xNeigh, yNeigh;
        uint16 j;
        uint16 useNeighbor = 1;

        // xNeigh and yNeigh are the coordinates of the centroid of the neighbor
        xNeigh = (int8p8)(cNeigh << 8); //8.8
        yNeigh = (int8p8)(rNeigh << 8); //8.8

        for (j = 0; j < sensorParams->cutOutLength; j++) {

          if ((rNeigh == (sensorParams->cutOutRows[j] + 1)) && (cNeigh == (sensorParams->cutOutCols[j] + 1))) {
            // Ignore pixels that are completely cut out
            if (sensorParams->cutOutFraction[j] == 0) {
              useNeighbor = 0;
            }
            // Else, update centroid
            else {
              xNeigh += sensorParams->centroidOffsetCol[j];
              yNeigh += sensorParams->centroidOffsetRow[j];
            }
          }
        }

        if (useNeighbor == 1) {
          float respNeigh = (float)deltaImage[offset];
          float alpha = (respCurrent - (float)(level)) / (respCurrent - respNeigh);
          float xCurrentf, yCurrentf, xNeighf, yNeighf;
          alpha = SQUARE(alpha);
          xCurrentf = (float)xCurrent / 256.f;
          yCurrentf = (float)yCurrent / 256.f;
          xNeighf = (float)xNeigh / 256.f;
          yNeighf = (float)yNeigh / 256.f;
          ptsX[*ptsCount] = alpha*xNeighf + (1.f - alpha)*xCurrentf;
          ptsY[*ptsCount] = alpha*yNeighf + (1.f - alpha)*yCurrentf;
          ptsWt[*ptsCount] = 1.f;
          (*ptsCount)++;

        }
      }
    }
  }
}

/* ------------------------------------------------------------------------
Name: fitCircle()
Purpose: Fit a circle to the given input points
Inputs:
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static void fitCircle(float *ptsX, float *ptsY, float *ptsWt, uint16 ptsCount,
  float prevR, int8p8 prevX, int8p8 prevY,
  struct circlePosition *pos)
{
  pos->x = (float)prevX / 256.f;
  pos->y = (float)prevY / 256.f;
  pos->r = prevR;

  if (ptsCount == 2) {
    // If only two points are available, fit with radius and position regularization
    optimize3x3withRegularization(ptsX, ptsY, ptsWt, ptsCount, pos, (objectBitmask_t)3);
  }
  else {
    // Else, regularize to radius only
    optimize3x3withRegularization(ptsX, ptsY, ptsWt, ptsCount, pos, (objectBitmask_t)1);
  }
}

/* ------------------------------------------------------------------------
Name: findCutoutDistance()
Purpose: Find distance to cutout from a given point
Inputs: sensorParams
    positionX
    positionY
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static uint8p8 findCutoutDistance(sensorParams_t *sensorParams, int8p8 positionX, int8p8 positionY) {
  uint16 i;
  int8p8 cutoutX, cutoutY;
  int16p16 distX, distY;
  uint16p16 currentSqDist, minSqDist;
  float minDistf;

  cutoutX = (int8p8)((sensorParams->cutOutCols[0] + 1) << 8); //8.8
  cutoutY = (int8p8)((sensorParams->cutOutRows[0] + 1) << 8); //8.8
  distX = positionX - cutoutX;
  distY = positionY - cutoutY;
  minSqDist = SQUARE(distX) + SQUARE(distY);

  for (i = 1; i < sensorParams->cutOutLength; i++) {
    cutoutX = (int8p8)((sensorParams->cutOutCols[i] + 1) << 8); //8.8
    cutoutY = (int8p8)((sensorParams->cutOutRows[i] + 1) << 8); //8.8
    distX = positionX - cutoutX;
    distY = positionY - cutoutY;
    currentSqDist = SQUARE(distX) + SQUARE(distY);
    if (currentSqDist < minSqDist) {
      minSqDist = currentSqDist;
    }
  }

  minDistf = sqrtf((float)(minSqDist));
  return (uint8p8)(minDistf);
}

/* ------------------------------------------------------------------------
Name: computeCircleFitBlendWeight()
Purpose: Get the blend weight for circle fit
Inputs: posCutoutDist - distance to cutout from Gauss + COM estimated position
        rC
Outputs: blendWeight (unsigned 8.8)
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static uint8p8 computeCircleFitBlendWeight(uint8p8 posCutoutDist, uint8p8 rC) {
  // If any portion of the estimated circle lies within the cutout, use the circle fit estimate only.
  // Otherwise, the blend weight drops off proportional to distance from the circle center to the cutout.
  // If the distance is twice the radius or greater, the circle fit position estimate is not used.
  uint8p8 blendWeight;


  if (posCutoutDist < rC) {
    blendWeight = 256;
  }
  else if (posCutoutDist < 2 * rC) {
    uint16p16 tempVar;
    tempVar = ((uint16p16)(posCutoutDist - rC)) << 8;
    blendWeight = 256 - (uint8p8)(tempVar / rC);
  }
  else {
    blendWeight = 0;
  }

  return blendWeight;
}

/* ------------------------------------------------------------------------
Name: isCornerIsland()
Purpose: Check if given location is a corner, and if so, check whether it is an "island"
Inputs: deltaImage
        sensorParams
        level - threshold for circle fit
        r
        c
Outputs: cornerIslandFlag (unsigned 16)
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static uint16 isCornerIsland(int16 *deltaImage, sensorParams_t *sensorParams,
                             int16 level, uint16 r, uint16 c)
{
  uint16 cornerIslandFlag = 0;
  if ((r == 1 || r == sensorParams->txCount) &&
      (c == 1 || c == sensorParams->rxCount))
  {
    uint16 i;
    uint16 index = (r - 1) * (MAX_RX + 1) + c;  // start at the top, then cumsum offsets
    uint16 neighborOffset[4] = {0, MAX_RX, 2, MAX_RX};  // top, left, right, bottom
    cornerIslandFlag = 1;
    for (i = 0; i < 4; i++)
    {
      index += neighborOffset[i];
      if (deltaImage[index] > level)
      {
        cornerIslandFlag = 0;
        break;
      }
    }
  }
  return cornerIslandFlag;
}

/* ------------------------------------------------------------------------
Name: arePointsSufficient()
Purpose: Check if points are sufficiently spread spatially to be reliable
Inputs: ptsX
        ptsY
        ptsCount
Outputs: pointsSufficientFlag (unsigned 16)
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static uint16 arePointsSufficient(float *ptsX, float *ptsY, uint16 ptsCount, uint16 prevReportAtNotch) {
  uint16 pointsSufficientFlag = 0;
  uint16 ptsCountThresh = 1;
  float maxDistanceSqThresh = 0.1f;

  if (!prevReportAtNotch)
  {
    maxDistanceSqThresh *= 4;
  }

  if (ptsCount > ptsCountThresh)
  {
    // As an approximation to maximum distance, use diagonal of bounding box
    float maxDistanceSq = SQUARE(computeRangeFloat(ptsX, ptsCount)) + SQUARE(computeRangeFloat(ptsY, ptsCount));


    if (maxDistanceSq > maxDistanceSqThresh)
    {
      pointsSufficientFlag = 1;
    }
  }

  return pointsSufficientFlag;
}

/* ------------------------------------------------------------------------
Name: correctPositionPriorForCollinearPoints()
Purpose: Check whether the points are collinear
         If so, get the new position prior based on the closest edge/cutout
         while moving perpendicular to the direction of collinearity
Inputs: sensorParams
        ptsX
        ptsY
        ptsCount
        pos
Outputs: None.
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static void correctPositionPriorForCollinearPoints(sensorParams_t *sensorParams, float *ptsX, float *ptsY, uint16 ptsCount, int8p8 *posX, int8p8 *posY) {
  float xRange, yRange, xP, yP, minRange;
  int8p8 xM, yM, xStep, yStep;
  uint16 correctFlag = 0;

  minRange = 0.2f;

  xRange = computeRangeFloat(ptsX, ptsCount);
  yRange = computeRangeFloat(ptsY, ptsCount);

  if ((xRange < minRange) || (yRange < minRange)) {
    // Points are collinear along either x or y
    correctFlag = 1;

    xP = computeMeanFloat(ptsX, ptsCount);
    yP = computeMeanFloat(ptsY, ptsCount);

    xM = (int8p8)(xP * 256.f + 0.5f); //Rounding float to int8p8
    yM = (int8p8)(yP * 256.f + 0.5f); //Sufficient since xM and yM are guaranteed to be positive

    if (xRange < yRange) {
      xStep = 256;
      yStep = 0;
    }
    else {
      xStep = 0;
      yStep = 256;
    }
  }
  else
  {
    float m, c, maxDistance;
    fitLine(ptsX, ptsY, ptsCount, &m, &c);
    maxDistance = getMaxDistanceFromPointsToLine(ptsX, ptsY, ptsCount, m, c);

    if (maxDistance < minRange / 2)
    {
      // Points are collinear
      // Find the points with largest separation
      // Get distance from the origin in the direction
      // perpendicular to line of collinearity
      // Preserve sign, ignore scale
      uint16 i;
      uint16 minIndex = 0, maxIndex = 0;
      float minPerpDist, maxPerpDist;

      correctFlag = 1;
      minPerpDist = ptsX[0] + m*ptsY[0];
      maxPerpDist = minPerpDist;

      for (i = 1; i < ptsCount; i++)
      {
        float perpDist = ptsX[i] + m*ptsY[i];
        if (perpDist < minPerpDist)
        {
          minPerpDist = perpDist;
          minIndex = i;
        }
        else if (perpDist > maxPerpDist)
        {
          maxPerpDist = perpDist;
          maxIndex = i;
        }
      }

      // Find the midpoint of the line segment connecting
      // the two most extreme points

      xM = (int8p8)((ptsX[minIndex] + ptsX[maxIndex]) *  128.f + 0.5f);
      yM = (int8p8)((ptsY[minIndex] + ptsY[maxIndex]) *  128.f + 0.5f);

      // Find x and y step size to move a unit in the perpendicular direction
      xStep = (int8p8)(1 / sqrtf(SQUARE(m) + 1) * 256.f + 0.5f);
      yStep = (int8p8)(-m / sqrtf(SQUARE(m) + 1) * 256.f + (m > 0? -0.5f : 0.5f)); //round based on sign of -m
    }
  }

  if (correctFlag == 1)
  {
    int8p8 i;
    for (i = 1; i < 100; i++)
    {
      // This loop will not run through completion
      uint16 xR = (uint16)ROUND_8P8(xM + i*xStep);
      uint16 yR = (uint16)ROUND_8P8(yM + i*yStep);

      if ((xR < 1) || (xR > sensorParams->rxCount) || (yR < 1) || (yR > sensorParams->txCount) || isWholePixelCutout(sensorParams, xR, yR))
      {
        *posX = xM + i*xStep;
        *posY = yM + i*yStep;
        break;
      }

      xR = (uint16)ROUND_8P8(xM - i*xStep);
      yR = (uint16)ROUND_8P8(yM - i*yStep);

      if ((xR < 1) || (xR > sensorParams->rxCount) || (yR < 1) || (yR > sensorParams->txCount) || isWholePixelCutout(sensorParams, xR, yR))
      {
        *posX = xM - i*xStep;
        *posY = yM - i*yStep;
        break;
      }
    }
  }
}

/* ------------------------------------------------------------------------
Name: isWholePixelCutout()
Purpose: Checks whether the given pixel is wholly cutout
Inputs: sensorParams
        positionX
        positionY
Outputs: wholePixelCutoutFlag
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static uint16 isWholePixelCutout(sensorParams_t *sensorParams, uint16 positionX, uint16 positionY) {
  uint16 i;

  for (i = 0; i < sensorParams->cutOutLength; i++) {
    // If the current location is cut out
    if ((positionY == (sensorParams->cutOutRows[i] + 1)) && (positionX == (sensorParams->cutOutCols[i] + 1)) && (sensorParams->cutOutFraction[i] == 0)) {
      return (uint16)1;
    }
  }

  return (uint16)0;
}

/* ------------------------------------------------------------------------
Name: updateSigma()
Purpose: Update sigma smoothly while clipping at predetermined limits
Inputs: currentSigma
        calculatedSigma
Outputs: sigma
Effects: None.
Example: None.
------------------------------------------------------------------------- */
static uint4p12 updateSigma(uint4p12 currentSigma, uint4p12 calculatedSigma)
{
  uint4p12 sigma;
  int4p12 deltaSigma = calculatedSigma - currentSigma;
  int4p12 quarterSigma = (currentSigma + 2) / 4;
  if (deltaSigma < -quarterSigma)
  {
    int4p12 eigthSigma = (currentSigma + 4) / 8;
    sigma = currentSigma - eigthSigma;
  }
  else if (deltaSigma > quarterSigma)
  {
    int4p12 eigthSigma = (currentSigma + 4) / 8;
    sigma = currentSigma + eigthSigma;
  }
  else
  {
    sigma = currentSigma + (deltaSigma + 1) / 2;
  }
  return sigma;
}

/* ------------------------------------------------------------------------
Name: fitLine()
Purpose: Fit a line y = mX + c to in input points using the least squares
         method
Inputs: ptsX
        ptsY
        ptsCount
        m - slope of line
        c - intercept of line
Outputs: None.
Effects: None.
Notes: None.
Example: None.
------------------------------------------------------------------------- */
static void fitLine(float *ptsX, float *ptsY, uint16 ptsCount, float *m, float *c)
{
  // Assume the following degenerate cases do not occur:
  // -all points collapse to a single point
  // -all points collinear in y direction
  uint16 i;
  float xMean, yMean;
  double mNumerator = 0.0, mDenominator = 0.0;

  xMean = computeMeanFloat(ptsX, ptsCount);
  yMean = computeMeanFloat(ptsY, ptsCount);

  for (i = 0; i < ptsCount; i++) {
    mNumerator += (double)((ptsX[i] - xMean)*(ptsY[i] - yMean));
    mDenominator += (double)(SQUARE(ptsX[i] - xMean));
  }

  *m = (float)(mNumerator / mDenominator);
  *c = yMean - *m * xMean;
}

/* ------------------------------------------------------------------------
Name: getMaxDistanceFromPointsToLine()
Purpose: Fit a line y = mX + c to in input points using the least squares
method
Inputs: ptsX
        ptsY
        ptsCount
        m - slope of line
        c - intercept of line
Outputs: maxDistance
Effects: None.
Notes: None.
Example: None.
------------------------------------------------------------------------- */
static float getMaxDistanceFromPointsToLine(float *ptsX, float *ptsY, uint16 ptsCount, float m, float c)
{
  uint16 i;
  float maxDistance = 0.f;
  for (i = 0; i < ptsCount; i++)
  {
    float distance = ABS(m*ptsX[i] - ptsY[i] + c);
    if (distance > maxDistance)
    {
      maxDistance = distance;
    }
  }

  return maxDistance / sqrtf(SQUARE(m) + 1);
}

#endif // CONFIG_HAS_NOTCH_CUT
/* ------------------------------------------------------------------------
Name: positionEstimator_init()
Purpose: Initialize the position estimator module.
Inputs: None.
Outputs: None.
Effects: None.
Notes: Intialize positionState structure to hold default values
Example: None.
------------------------------------------------------------------------- */
void positionEstimator_init(void)
{
  uint16 objIdx;
  memset16(positionState, 0, sizeof(positionState) / sizeof(uint16));

  for (objIdx = 0; objIdx < MAX_OBJECTS; objIdx++)
  {
    //Initializing internal position state information
    positionState[objIdx].wX.gaussianWidth = gaussianWidthX;
    positionState[objIdx].wY.gaussianWidth = gaussianWidthY;
    positionState[objIdx].wX.largeObjectWidth = 512U;
    positionState[objIdx].wY.largeObjectWidth = 512U;
#if CONFIG_HAS_NOTCH_CUT
    positionState[objIdx].circleCenterX = circleCenterX;
    positionState[objIdx].circleCenterY = circleCenterY;
    positionState[objIdx].circleR = circleR;
    positionState[objIdx].peakAmplitude = peakAmplitude;
    positionState[objIdx].sigmaR = sigmaR;
    positionState[objIdx].framesSinceCircleFit = 0;
    positionState[objIdx].reportAtNotch = 1;
#endif //CONFIG_HAS_NOTCH_CUT
  }
}

/* ------------------------------------------------------------------------
Name: positionEstimator_reinit()
Purpose: Re-initialize the position estimator module on rezero.
Inputs: None.
Outputs: None.
Effects: None.
Notes: Re-Intialize sensorPositions structure to all zeros and positionState
to hold default values
Example: None.
------------------------------------------------------------------------- */
void positionEstimator_reinit(void)
{
  positionEstimator_init();
}

/* -----------------------------------------------------------------
Name: positionEstimator_configure()
Purpose: Configure position estimator
Inputs: None.
Outputs: None.
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
#if CONFIG_HAS_NOTCH_CUT
void positionEstimator_configure(sensorParams_t *sensorParams, positionEstConfig_t *peConfig)
#else
void positionEstimator_configure(positionEstConfig_t *peConfig)
#endif
{
  axisName_t txAxis = (axisName_t) peConfig->txAxis;

  switch(txAxis)
  {
    default: // invalid values result in "portrait" orientation
    case axisName_xAxis: // intentional fall-through
      gaussianWidthX = (int16) peConfig->gaussianWidthX;
      gaussianWidthY = (int16) peConfig->gaussianWidthY;
      minFingerWidthX = peConfig->minFingerWidthX;
      minFingerWidthY = peConfig->minFingerWidthY;
      #if CONFIG_HAS_GLOVE_MIN_SIZE
      minGloveWidthX = peConfig->minGloveWidthX;
      minGloveWidthY = peConfig->minGloveWidthY;
      #endif
      #if CONFIG_HAS_NOTCH_CUT
      circleCenterX = peConfig->circleCenterX;
      circleCenterY = peConfig->circleCenterY;
      #endif
      xConfig.zMin = peConfig->sineCorrCfg.zMinX;
      xConfig.zMax = peConfig->sineCorrCfg.zMaxX;
      xConfig.corrAtZMin = peConfig->sineCorrCfg.ampAtZMinX;
      yConfig.zMin = peConfig->sineCorrCfg.zMinY;
      yConfig.zMax = peConfig->sineCorrCfg.zMaxY;
      yConfig.corrAtZMin = peConfig->sineCorrCfg.ampAtZMinY;
    break;
    case axisName_yAxis:
      gaussianWidthX = (int16) peConfig->gaussianWidthY;
      gaussianWidthY = (int16) peConfig->gaussianWidthX;
      minFingerWidthX = peConfig->minFingerWidthY;
      minFingerWidthY = peConfig->minFingerWidthX;
      #if CONFIG_HAS_GLOVE_MIN_SIZE
      minGloveWidthX = peConfig->minGloveWidthY;
      minGloveWidthY = peConfig->minGloveWidthX;
      #endif
      #if CONFIG_HAS_NOTCH_CUT
      circleCenterX = peConfig->circleCenterX;
      circleCenterY = peConfig->circleCenterY;
      #endif
      xConfig.zMin = peConfig->sineCorrCfg.zMinY;
      xConfig.zMax = peConfig->sineCorrCfg.zMaxY;
      xConfig.corrAtZMin = peConfig->sineCorrCfg.ampAtZMinY;
      yConfig.zMin = peConfig->sineCorrCfg.zMinX;
      yConfig.zMax = peConfig->sineCorrCfg.zMaxX;
      yConfig.corrAtZMin = peConfig->sineCorrCfg.ampAtZMinX;
    break;
  }
#if CONFIG_HAS_NOTCH_CUT
  circleFitEn = peConfig->circleFitEn;
  circleR = peConfig->circleR;
  peakAmplitude = peConfig->peakAmplitude;
  sigmaR = peConfig->sigmaR;
  contourPeakFrac = peConfig->contourPeakFrac;

  {
    uint16 i;
    for (i = 0; i < (MAX_TX + OBJECT_BITMASK_SIZE - 1) / OBJECT_BITMASK_SIZE; i++)
    {
      cutOutInfluenceRows[i] = 0;
    }
    for (i = 0; i < (MAX_RX + OBJECT_BITMASK_SIZE - 1) / OBJECT_BITMASK_SIZE; i++)
    {
      cutOutInfluenceCols[i] = 0;
    }

    for (i = 0; i < sensorParams->cutOutLength; i++)
    {
      uint16 index;

      for (index = MAX(0, (int)(sensorParams->cutOutRows[i]) - CUTOUT_INFLUENCE_DISTANCE);
        index <= MIN(MAX_TX - 1, (sensorParams->cutOutRows[i]) + CUTOUT_INFLUENCE_DISTANCE);
        index++)
      {
        uint16 arrayPosition = index / OBJECT_BITMASK_SIZE;
        cutOutInfluenceRows[arrayPosition] = cutOutInfluenceRows[arrayPosition] | (1 << (index % OBJECT_BITMASK_SIZE));
      }

      for (index = MAX(0, (int)(sensorParams->cutOutCols[i]) - CUTOUT_INFLUENCE_DISTANCE);
        index <= MIN(MAX_RX - 1, (sensorParams->cutOutCols[i]) + CUTOUT_INFLUENCE_DISTANCE);
        index++)
      {
        uint16 arrayPosition = index / OBJECT_BITMASK_SIZE;
        cutOutInfluenceCols[arrayPosition] = cutOutInfluenceCols[arrayPosition] | (1 << (index % OBJECT_BITMASK_SIZE));
      }
    }
  }
#endif // CONFIG_HAS_NOTCH_CUT
}

/* -----------------------------------------------------------------
Name: positionEstimator_reportGaussianWidth()
Purpose: Returns computed gaussian width
Inputs: None.
Outputs: widthX, widthY - the widths of the 0th finger.
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void positionEstimator_reportGaussianWidth(uint16 *widthX, uint16 *widthY)
{
  // FIXME: instead of always reporting with index 0, this should
  // report the width of the finger with the lowest index or highest Z
  // FIXME: postionState[i].gaussianWidth{X,Y} is actually -2 * width{X,Y}^-2..
  // Compute actual width properly.
  struct positionState_t *pos = &positionState[0];
  *widthX = pos->wX.gaussianWidth;
  *widthY = pos->wY.gaussianWidth;
}

/* ------------------------------------------------------------------------
Name: positionEstimator_calcPositions()
Purpose: Returns calculated positions
Inputs: sensorParams
        deltaImage
        clumps
        trackedObjects
        classifications
        sensorPositions
Outputs: None.
Effects: None.
Notes: None.
Example: None.
------------------------------------------------------------------------- */
void positionEstimator_calcPositions(sensorParams_t *sensorParams,
                                     int16 *deltaImage,
                                     clumps_t *clumps,
                                     trackedObject_t *trackedObjects,
                                     classification_t *classifications,
                                     sensorPosition_t *sensorPositions)
{
  uint16 trackInd;
#if CONFIG_HAS_NOTCH_CUT
  objectBitmask_t circleFitFlags = 0;
#endif
  trackedObject_t *track = trackedObjects;
  classification_t *classification = classifications;

  memset16(sensorPositions, 0, MAX_OBJECTS * sizeof(*sensorPositions) / sizeof(uint16));

#if CONFIG_HAS_NOTCH_CUT
    if(circleFitEn)
    {
      circleFitFlags = computeCircleFitFlags(sensorParams, clumps, trackedObjects);
    } else
    {
      circleFitFlags = 0;
    }
#endif //CONFIG_HAS_NOTCH_CUT
  for (trackInd = 0; trackInd < MAX_OBJECTS; trackInd++, track++, classification++)
  {
    uint16 clumpId = track->clumpId;
    #if CONFIG_HAS_NOTCH_CUT
    if (classification->touchType == touchType_none) {
      positionState[trackInd].circleCenterX = circleCenterX;
      positionState[trackInd].circleCenterY = circleCenterY;
      positionState[trackInd].framesSinceCircleFit = 0;
    }
    #endif // CONFIG_HAS_NOTCH_CUT

    if (clumpId == 0)
    {
      clearStateInfo(trackInd);
      continue;
    }

    if (classification->newTouchFlag)
    {
      clearStateInfo(trackInd);
    }

  #if CONFIG_HAS_GLOVE_MIN_SIZE
    positionState[trackInd].nextTouchType = classification->touchType;
  #endif

    if (!classification->touchFlag)
    {
      uint16 prevTouchType = positionState[trackInd].prevTouchType;
      if (prevTouchType == touchType_finger ||
          prevTouchType == touchType_glove ||
          prevTouchType == touchType_smallObject ||
          prevTouchType == touchType_stylus ||
       #if CONFIG_HAS_REPORT_PALM_UPDATE_WX_WY && !(CONFIG_HAS_EXTREME_NOISE_REMOVER && CONFIG_EXT_CENTROID_POSITIONING)
          prevTouchType == touchType_palm ||
       #endif
          prevTouchType == touchType_eraser)
      {
        // On lift, clear some state, retain other state to ride out dropouts.
        clearStateInfo(trackInd);
        positionState[trackInd].prevTouchType = (uint16) classifications[trackInd].touchType;
      }
    }
    else if (classification->touchType == touchType_finger ||
             classification->touchType == touchType_glove ||
             classification->touchType == touchType_smallObject||
             classification->touchType == touchType_stylus ||
          #if CONFIG_HAS_REPORT_PALM_UPDATE_WX_WY && !(CONFIG_HAS_EXTREME_NOISE_REMOVER && CONFIG_EXT_CENTROID_POSITIONING)
             classification->touchType == touchType_palm ||
          #endif
             classification->touchType == touchType_eraser)
    {
      uint16 projX[MAX_RX];
      uint16 projY[MAX_TX];

      // Compute projections. Note that the clump projector takes an absolute
      // value. Thus, we require rigorous same-signedness of clumps.
      if (classification->touchType == touchType_smallObject ||
          classification->touchType == touchType_stylus ||
          classification->touchType == touchType_eraser)
      {
        memset16(projX, 0, sizeof(projX) / sizeof(uint16));
        memset16(projY, 0, sizeof(projY) / sizeof(uint16));
        computeStylusProjection(projX, projY, deltaImage, clumps, clumpId);
      }
      else
      {
        int16 blobId = track->blobId;
        clumpProjector_getProjectionXY(clumps, clumpId, blobId, deltaImage, projX, projY);
      }
#if CONFIG_HAS_NOTCH_CUT
      calcFingerPosition(sensorParams, projX, projY, clumps, deltaImage, trackedObjects, trackInd, sensorPositions, circleFitFlags);
#else
      calcFingerPosition(sensorParams, projX, projY, trackedObjects, trackInd, sensorPositions);
#endif
      // prevTouchType updated after sensorPositions are calculated because prevTouchType determines
      // position in both edges missing case
      positionState[trackInd].prevTouchType = classification->touchType;

      // Handle objects that were determined by circleFit to have
      // unreliable estimate - clear corresponding sensorPosition
      // and classification
#if CONFIG_HAS_NOTCH_CUT
      if (positionState[trackInd].reportAtNotch == 0) {
        memset16(sensorPositions + trackInd, 0, sizeof(*sensorPositions) / sizeof(uint16));
        classifications[trackInd].touchFlag = 0;
        positionState[trackInd].circleCenterX = circleCenterX;
        positionState[trackInd].circleCenterY = circleCenterY;
      }
#endif
    }
    else
    {
      // palm
      returnSensorPosition(sensorPositions, trackedObjects, trackInd, 1);
    }
  }
}
