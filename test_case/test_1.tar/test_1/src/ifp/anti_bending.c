/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

  Description: Correct the effects of sensor bending
----------------------------------------------------------------- */

/* =================================================================
   MODULE INCLUDES
==================================================================*/

#include "ifp_common.h"

#if CONFIG_HAS_ANTI_BENDING

#include "ifp_string.h"
#include "ifp_vector_util.h"
#include "ifp_bit_manipulation.h"
#include "anti_bending.h"
#if (defined(CONFIG_IFP_ANTIBENDING_FOR_CLOSEDCOVER) && CONFIG_IFP_ANTIBENDING_FOR_CLOSEDCOVER)
#include "position_reporter.h"
#endif
/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

#define MIN_INT16 (-0x8000)
#define AB_FIT_ORDER 5


/* =================================================================
   MODULE VARIABLES
==================================================================*/
typedef struct
{
  int16 coeffRightShiftBits;
  int16 coeffTxRightShiftBits;
  int16 fittingRightShiftBits;
  int16 fittingTxRightShiftBits;
  int16 xArray[AB_FIT_ORDER*MAX_RX];
  int16 mArray[AB_FIT_ORDER*MAX_RX];
#if CONFIG_HAS_HYBRID
  int16 xArrayTx[AB_FIT_ORDER*MAX_TX];
  int16 mArrayTx[AB_FIT_ORDER*MAX_TX];
#endif
} antiBendingData_t;

static antiBendingConfig_t abConfig;
static antiBendingData_t abData;
static uint16 binomialCoefficients[3];

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

#ifdef __CHIMERA__
#ifdef __cplusplus
    extern "C" {
#endif
void matTimesVec_s32(uint16 rows, uint16 cols, int16 *mat, int16 *vec, int32 *result);
void matTimesVec_s16_high(uint16 rows, uint16 cols, int16 *mat, int16 *vec, int16 *result);
#ifdef __cplusplus
    }
#endif
#else
static void matTimesVec_s32(uint16 rows, uint16 cols, int16 *mat, int16 *vec, int32 *result);
static void matTimesVec_s16_high(uint16 rows, uint16 cols, int16 *mat, int16 *vec, int16 *result);
#endif  // __CHIMERA__

static void estimateCoeff(int16 *row, uint16 rowLen, int16 *coeff);
static void applyCorrection(int16 *row, uint16 rowLen, int16 *xxArray, int16 *coeff, int16 isTx);

static ATTR_INLINE void calculateLaplacianRow(int16 *outRow, int16 *inRow, uint16 len);
static void calculateLaplacian(sensorParams_t* sp, int16 *laplacian, int16 *delta);
static ATTR_INLINE void maskRowThreshold(int16 *outRow, int16 *inRow, uint16 len, int16 threshold);
static ATTR_INLINE uint16 maskDeltaThreshold(int16 *outRow, int16 *touchRxPtr, int16 *inRow, uint16 len, int16 threshold);
static ATTR_INLINE void dilate2DRow(int16 *out, int16 *in, uint16 len);

static void createTouchMap(sensorParams_t *sp, int16 *buffer, int16 laplacianThreshold, int16 *deltaImage, int16 deltaThreshold);
static void interpolateOverTouchedProfile(int16 *touchMask, int16 *delta, uint16 profileLen);
static void interpolateOverTouched(sensorParams_t* sensorParams, int16 *touchMask, int16 *delta);
static void linearInterpolation(int16 *mask, int16 *data, int16 size);
static void preProcessImage(sensorParams_t *sp, int16 *fingerlessImage, int16 *deltaImage, int16 laplacianThreshold, int16 deltaThreshold);

#if CONFIG_HAS_HYBRID
static void estimateCoeffTx(int16 *row, uint16 rowLen, int16 *coeff);
static ATTR_INLINE void dilate1DRow(int16 *out, int16 *in, uint16 len);
static void createTouchProfile(int16 *buffer, int16 *deltaProfile, uint16 profileLen, int16 laplacianThreshold, int16 deltaThreshold);
static void preProcessProfile(int16 *fingerlessProfile, int16 *deltaProfile, uint16 profileLen, int16 laplacianThreshold, int16 deltaThreshold);
#endif  // CONFIG_HAS_HYBRID

#if CONFIG_IFP_FORCE_DETECT
extern void force_createWindowMask(int16 *touchMap);
#endif

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/


static uint16 floorLog2(uint32 v)
{
  int16 numBits = 0;
  if (v == 0)
  {
    numBits = 0xFFFF;
  }
  else
  {
    while ((v >>= 1) != 0)
    {
      numBits++;
    }
  }
  return numBits;
}

static uint16 roundLog2_approx(uint32 v)
{
  uint16 numBits = floorLog2(v);
  v -= ((uint32) 1) << numBits;
  if (numBits == floorLog2(v) + 1)
    numBits += 1;
  return numBits;
}

#if !defined(__CHIMERA__)   //- in Onebase, have assembly-optimized functions
void matTimesVec_s32(uint16 rows, uint16 cols, int16 *mat, int16 *vec, int32 *result)
{
  uint16 r, c;
  for (r = 0; r < rows; r++)
  {
    int16 *vecPtr = vec;
    int32 sum = 0;
    for (c = 0; c < cols; c++)
    {
      sum += (int32)(*mat++)*(int32)(*vecPtr++);
    }
    *result++ = sum;
  }
}

void matTimesVec_s16_high(uint16 rows, uint16 cols, int16 *mat, int16 *vec, int16 *result)
{
  uint16 r, c;
  for (r = 0; r < rows; r++)
  {
    int16 *vecPtr = vec;
    int32 sum = 0;
    for (c = 0; c < cols; c++)
    {
      sum += (int32)(*mat++)*(int32)(*vecPtr++);
    }
    *result++ = sum >> 16;
  }
}
#endif

/* -----------------------------------------------------------
Name: estimateCoeff
Purpose: Estimate max likelihood coefficients for an array
         to be approximated by the basis functions in xArray, where
         the matrix inv(xArray' * xArray) * xArray' is stored in mArray.
Inputs: input array
        array length
Outputs: fit coefficients (length AB_FIT_ORDER)
Effects: None.
Notes: Right-shift coefficients by coeffRightShiftBits to fit in 16 bits.
----------------------------------------------------------- */
void estimateCoeff(int16 *row, uint16 rowLen, int16 *coeff)
{
  int32 tempCoeff[AB_FIT_ORDER];  // intermediate higher precision
  matTimesVec_s32(AB_FIT_ORDER, rowLen, abData.mArray, row, tempCoeff);

  // Reduce precision.
  {
    uint16 i;
    int16 roundTerm = powerOfTwo(abData.coeffRightShiftBits - 1);
    for (i = 0; i < AB_FIT_ORDER; i++)
    {
      coeff[i] = (tempCoeff[i] + roundTerm) >> abData.coeffRightShiftBits;
    }
  }
}

/* -----------------------------------------------------------
Name: applyCorrection
Purpose: Subtract fit from original function.
Inputs: input array
        array length
        fit coefficients
Outputs: None.
Effects: Modifies input array in-place.
Notes: None.
----------------------------------------------------------- */
void applyCorrection(int16 *row, uint16 rowLen, int16 *xxArray, int16 *coeff, int16 isTx)
{
  int16 fit[MAX_RX+MAX_TX];
  matTimesVec_s16_high(rowLen, AB_FIT_ORDER, xxArray, coeff, fit);

  // Finally subtract fit from row in-place.
  {
    uint16 i;
    uint16 shift = (isTx > 0)?(abData.fittingTxRightShiftBits - abData.coeffTxRightShiftBits - 16):(abData.fittingRightShiftBits - abData.coeffRightShiftBits - 16); // NB: matTimesVec right-shifts by 16.
    int16 roundTerm = powerOfTwo(shift - 1);
    int16 *rowPtr = row;
    int16 *fitPtr = fit;
    for (i = 0; i < rowLen; i++)
    {
      *rowPtr++ -= (*fitPtr++ + roundTerm) >> shift;
    }
  }
}

/* -----------------------------------------------------------
Purpose: Calculate the second order difference within a row
Inputs: input array
        row length
Outputs: output array
Effects:
Notes: Skip the leading and trailing zero-padding. The row
       length should not include either of these zeros.
----------------------------------------------------------- */
static ATTR_INLINE void calculateLaplacianRow(int16 *outRow, int16 *inRow, uint16 len)
{
  uint16 i;

  *outRow++ = inRow[0] - inRow[1];  // first deriv, non-central
  *outRow++ = -inRow[0] + 2 * inRow[1] - inRow[2];  // second deriv, central
  *outRow++ = (-inRow[0] + 2 * inRow[2] - inRow[4]) / 2;  // [1, 2, 1]-smoothed second deriv, central
  for (i = 0; i < len - 6; i++)
  {
    *outRow++ = (-inRow[0] - 2 * inRow[1] + inRow[2] + 4 * inRow[3] + inRow[4] - 2 * inRow[5] - inRow[6]) / 4;  // [1, 4, 6, 4, 1]-smoothed second deriv, central
    inRow++;
  }
  *outRow++ = (-inRow[1] + 2 * inRow[3] - inRow[5]) / 2;  // [1, 2, 1]-smoothed second deriv, central
  *outRow++ = -inRow[3] + 2 * inRow[4] - inRow[5];  // second deriv, central
  *outRow++ = inRow[5] - inRow[4];  // first deriv, non-central
}

// -----------------------------------------------------------------
// Name:    calculateLaplacian()
// Purpose: Calculate the second derivative of the image along rows
// Inputs:  sensor params
//          output buffer where to write laplacian image
//          delta image
// Outputs: None.
// Effects:
// Notes:   None.
// Example: None.
// -----------------------------------------------------------------
static void calculateLaplacian(sensorParams_t *sp, int16 *laplacian, int16 *delta)
{
  uint16 row;
  int16 *deltaPtr = delta + (MAX_RX + 1) + 1;  // skip zero-padding
  int16 *lapPtr = laplacian + (MAX_RX + 1) + 1;  // skip zero-padding

  for (row = 0; row < sp->txCount; row++)
  {
    calculateLaplacianRow(lapPtr, deltaPtr, sp->rxCount);
    deltaPtr += MAX_RX + 1;
    lapPtr += MAX_RX + 1;
  }
}

// -----------------------------------------------------------------
// Name:    linearInterpolation()
// Purpose: Linear Interpolation of touched regions.
// Inputs:  data = pointer to array of known values
//          mask = pointer to mask array that contains 0 where the value
//                 is known and 1 where interpolation is needed,
//                 to be overwritten with data at known sites and interpolated
//                 values at queried sites.
//          size = Length of mask
// Outputs:
// Effects: Overwrites mask array with interpolated delta row.
// Notes:
// Example: None.
// -----------------------------------------------------------------
static void linearInterpolation(int16 *mask, int16 *data, int16 size)
{
  int16 idx;
  int16 ntIdx = -1;  // most recent index in which no touch was detected
  int32 linearEstimate = 0;

  // For touched left edge, need to look ahead to first untouched pixel.
  for (idx = 0; idx < size; idx++)
  {
    if (!mask[idx])
    {
      ntIdx = idx;
      break;
    }
  }
  if (ntIdx == -1) return;

  // Fill in touched left edge with first untouched value.
  if (ntIdx > 0)  // left edge touched and at least one pixel untouched
  {
    int16 firstUntouchedVal = data[ntIdx];
    for(idx = 0; idx < ntIdx; idx++)
    {
      mask[idx] = firstUntouchedVal;
    }
  }

  for (idx = ntIdx; idx < size; idx++)
  {
    if (mask[idx] != 1)  // No touch region
    {
      int16 pixel = data[idx];
      mask[idx] = pixel;  // Overwrite mask with data in no-touch regions

      if (ntIdx < idx-1)
      {
        // Previous pixels in this row contained a touch, linearly interpolate
        int16 slope = (8*(pixel - linearEstimate)) / (idx - ntIdx);
        linearEstimate *= 8;

        while (ntIdx < idx-1)
        {
          ntIdx++;
          linearEstimate += slope;
          // Overwrite mask with the interpolated value at touched regions
          mask[ntIdx] = (linearEstimate / 8);  // adjust for precision;
        }
      }
      linearEstimate = pixel;
      ntIdx = idx;
    }
  }

  // Fill in right touched edge with last untouched value.
  if (ntIdx != size - 1)  // right edge missing
  {
    int16 lastUntouchedVal = data[ntIdx];
    for (idx = ntIdx + 1; idx < size; idx++)
    {
      mask[idx] = lastUntouchedVal;
    }
  }
}

static ATTR_INLINE void maskRowThreshold(int16 *outRow, int16 *inRow, uint16 len, int16 threshold)
{
  uint16 i;
  for (i = 0; i < len; i++)  // skip last non-zero col
  {
    if ((*inRow >= threshold) || (*inRow <= -threshold))
    {
      *outRow = 1;
    }
    inRow++;
    outRow++;
  }
}

static ATTR_INLINE uint16 maskDeltaThreshold(int16 *outRow, int16 *touchRxPtr, int16 *inRow, uint16 len, int16 threshold)
{
  uint16 i;
  uint16 aboveThreshold = 0;
  for (i = 0; i < len; i++)  // skip last non-zero col
  {
    if ((*inRow >= threshold) || (*inRow <= -threshold))
    {
      *outRow = 1;
      *touchRxPtr = 1;
      aboveThreshold = 1;
    }
    inRow++;
    touchRxPtr++;
    outRow++;
  }

  return aboveThreshold;
}

static ATTR_INLINE void dilate2DRow(int16 *out, int16 *in, uint16 len)
{
  uint16 j;
  for (j = 0; j < len; j++)
  {
    *out++ = in[0] ||
             in[-(MAX_RX + 1)] ||
             in[MAX_RX + 1] ||
             in[-1] ||
             in[1];
    in++;
  }
}

void createTouchMap(sensorParams_t *sp, int16 *buffer, int16 laplacianThreshold, int16 *deltaImage, int16 deltaThreshold)
{
  // Create a whole new image for the touchMap just to avoid tricky indexing.
  int16 touchMap[(MAX_RX + 1) * (MAX_TX + 2) + 1];
  memset16_large(touchMap, 0, sizeof(touchMap) / sizeof(uint16));

  // Split delta and laplacian checks into separate loops to prevent register
  // thrashing.
  // NB: Output of 1x3 kernel not valid on left and right edges.
  {
    uint16 row;
    int16 *touchPtr = touchMap + (MAX_RX + 1) + 1;  // skip zero-padding
    int16 *lapPtr = buffer + (MAX_RX + 1) + 1;  // skip zero-padding

    for (row = 0; row < sp->txCount; row++)
    {
      maskRowThreshold(touchPtr, lapPtr, sp->rxCount, laplacianThreshold);
      touchPtr += MAX_RX + 1;
      lapPtr += MAX_RX + 1;
    }
  }

  //disable delta threshold when it is set to 0
  if (deltaThreshold > 0)
  {
    uint16 row;
    int16 touchTx[MAX_TX + 2];
    int16 touchRx[MAX_RX + 2];
    int16 *touchTxPtr;
    int16 *touchRxPtr;
    int16 *touchPtr = touchMap + (MAX_RX + 1) + 1;  // skip zero-padding
    int16 *deltaPtr = deltaImage + (MAX_RX + 1) + 1;  // skip zero-padding
    memset16_large(touchTx, 0, MAX_TX + 2);
    memset16_large(touchRx, 0, MAX_RX + 2);
    touchTxPtr = touchTx + 1;
    touchRxPtr = touchRx + 1;
    for (row = 0; row < sp->txCount; row++)
    {
      *touchTxPtr++ = maskDeltaThreshold(touchPtr, touchRxPtr, deltaPtr, sp->rxCount, deltaThreshold);
      touchPtr += MAX_RX + 1;
      deltaPtr += MAX_RX + 1;
    }

    touchPtr = touchMap;
    touchTxPtr = touchTx;
    for (row = 0; row < MAX_TX + 2; row++)
    {
      if (*touchTxPtr++)
      {
        uint16 col;
        touchRxPtr = touchRx;
        for (col = 0; col < MAX_RX + 1; col++)
        {
          if (*touchRxPtr++)
          {
            *touchPtr = 1;
          }
          touchPtr++;
        }
      }
      else
      {
        touchPtr += MAX_RX + 1;
      }
    }
  }

  // Dilate directly into output buffer
  {
    uint16 row;
    int16 *touchPtr = touchMap + (MAX_RX + 1) + 1;
    int16 *dilatedPtr = buffer + (MAX_RX + 1) + 1;
    for (row = 0; row < sp->txCount; row++)
    {
      dilate2DRow(dilatedPtr, touchPtr, sp->rxCount);
      touchPtr += MAX_RX + 1;
      dilatedPtr += MAX_RX + 1;
    }
  }

#if CONFIG_IFP_FORCE_DETECT
  force_createWindowMask(touchMap);
#endif

}

// -----------------------------------------------------------------
// Name:    interpolateOverTouchedProfile()
// Purpose: Excise fingers and interpolate over them.
// Inputs:  sensor params, touch mask (1 where touched), delta image
// Outputs: delta image with fingers removed and interpolated over
// Effects: touch mask is overwritten with fingerless delta
// -----------------------------------------------------------------
void interpolateOverTouchedProfile(int16 *touchMask, int16 *delta, uint16 profileLen)
{
  int16 *deltaPtr = delta;
  int16 *touchPtr = touchMask;

  {
    // Find the number of touched pixels in a row to allow optimization.
    uint16 numTouched = 0;
    {
      uint16 col;
      int16 *localTouchPtr = touchPtr;
      for (col = 0; col < profileLen; col++)
      {
        if (*localTouchPtr++) numTouched++;
      }
    }

    // Overwrite row of touchMask with interpolated delta.
    if (numTouched == 0 || numTouched == profileLen)  // optimization
    {
      memcpy16(touchPtr, deltaPtr, profileLen);
    }
    else
    {
      linearInterpolation(touchPtr, deltaPtr, profileLen);
    }
  }
}

// -----------------------------------------------------------------
// Name:    interpolateOverTouched()
// Purpose: Excise fingers and interpolate over them.
// Inputs:  sensor params, touch mask (1 where touched), delta image
// Outputs: delta image with fingers removed and interpolated over
// Effects: touch mask is overwritten with fingerless delta
// -----------------------------------------------------------------
void interpolateOverTouched(sensorParams_t *sp, int16 *touchMask, int16 *delta)
{
  uint16 row;
  int16 *deltaPtr = delta + (MAX_RX + 1) + 1;
  int16 *touchPtr = touchMask + (MAX_RX + 1) + 1;

  for (row = 0; row < sp->txCount; row++)
  {
    interpolateOverTouchedProfile(touchPtr, deltaPtr, sp->rxCount);

    deltaPtr += MAX_RX + 1;
    touchPtr += MAX_RX + 1;
  }
}

// Take input image, generate laplacian image, remove finger pixels, replace
// with linear fit across missing terms.
void preProcessImage(sensorParams_t *sp, int16 *fingerlessImage, int16 *deltaImage, int16 laplacianThreshold, int16 deltaThreshold)
{
  // Temporarily fill fingerlessImage with laplacian of delta.
  memset16_large(fingerlessImage, 0, (MAX_TX + 2) * (MAX_RX + 1) + 1);
  calculateLaplacian(sp, fingerlessImage, deltaImage);

  // Then overwrite fingerlessImage with dilated touch mask.
  createTouchMap(sp, fingerlessImage, laplacianThreshold, deltaImage, deltaThreshold);

  // Then finally overwrite fingerlessImage with delta interpolated over where
  // fingers are.
  interpolateOverTouched(sp, fingerlessImage, deltaImage);
}

#if CONFIG_HAS_HYBRID
/* -----------------------------------------------------------
Name: estimateCoeffTx
Purpose: Estimate max likelihood coefficients for an array
         to be approximated by the basis functions in xArray, where
         the matrix inv(xArray' * xArray) * xArray' is stored in mArray.
Inputs: input array
        array length
Outputs: fit coefficients (length AB_FIT_ORDER)
Effects: None.
Notes: Right-shift coefficients by coeffTxRightShiftBits to fit in 16 bits.
----------------------------------------------------------- */
void estimateCoeffTx(int16 *row, uint16 rowLen, int16 *coeff)
{
  int32 tempCoeff[AB_FIT_ORDER];  // intermediate higher precision
  matTimesVec_s32(AB_FIT_ORDER, rowLen, abData.mArrayTx, row, tempCoeff);

  // Reduce precision.
  {
    uint16 i;
    int16 roundTerm = powerOfTwo(abData.coeffTxRightShiftBits - 1);
    for (i = 0; i < AB_FIT_ORDER; i++)
    {
      coeff[i] = (tempCoeff[i] + roundTerm) >> abData.coeffTxRightShiftBits;
    }
  }
}

static ATTR_INLINE void dilate1DRow(int16 *out, int16 *in, uint16 len)
{
  uint16 j;
  *out++ = in[0] || in[1];
  in++;

  for (j = 1; j < len-1; j++)
  {
    *out++ = in[0] || in[-1] || in[1];
    in++;
  }
  *out = in[0] || in[-1];
}

void createTouchProfile(int16 *buffer, int16 *deltaProfile, uint16 profileLen, int16 laplacianThreshold, int16 deltaThreshold)
{
  // Create a whole new image for the touchMap just to avoid tricky indexing.
  int16 touchMap[MAX_ABS_RX + MAX_ABS_TX];
  memset16_large(touchMap, 0, sizeof(touchMap) / sizeof(uint16));

  // Split delta and laplacian checks into separate loops to prevent register
  // thrashing.
  // NB: Output of 1x3 kernel not valid on left and right edges.
    {
    int16 *touchPtr = touchMap;  // skip zero-padding
    int16 *lapPtr = buffer;  // skip zero-padding
    maskRowThreshold(touchPtr, lapPtr, profileLen, laplacianThreshold);
  }
  //disable deltaThrehsold when it is set to 0
  if (deltaThreshold > 0)
  {
    int16 *touchPtr = touchMap;  // skip zero-padding
    int16 *deltaPtr = deltaProfile;  // skip zero-padding
    maskRowThreshold(touchPtr, deltaPtr, profileLen, deltaThreshold);
  }

  // Dilate directly into output buffer
  {
    int16 *touchPtr = touchMap;
    int16 *dilatedPtr = buffer;
    {
      dilate1DRow(dilatedPtr, touchPtr, profileLen);
    }
  }
}

// Take input image, generate laplacian image, remove finger pixels, replace
// with linear fit across missing terms.
void preProcessProfile(int16 *fingerlessProfile, int16 *deltaProfile, uint16 profileLen, int16 laplacianThreshold, int16 deltaThreshold)
{
  // Temporarily fill fingerlessImage with laplacian of delta.
  memset16_large(fingerlessProfile, 0, MAX_ABS_RX+MAX_ABS_TX);
  calculateLaplacianRow(fingerlessProfile, deltaProfile, profileLen);

  // Then overwrite fingerlessImage with dilated touch mask.
  createTouchProfile(fingerlessProfile, deltaProfile, profileLen, laplacianThreshold, deltaThreshold);

  // Then finally overwrite fingerlessImage with delta interpolated over where
  // fingers are.
  interpolateOverTouchedProfile(fingerlessProfile, deltaProfile, profileLen);
}

#endif  // CONFIG_HAS_HYBRID

void constructAntiBendingMatricesSingleAxis(uint16 electrodeCount, int16 *xTxInv, int16 *xArray, int16 *mArray, int16 *coeffRightShiftBitsOutput, int16 *fittingRightShiftBitsOutput)
{
  int32 mArray32[AB_FIT_ORDER*(MAX_RX+MAX_TX)];
  uint16 i;

  uint32 N = electrodeCount - 1;
  int16 coeffShift = floorLog2(N*N*N*N) + 1 - 15;
  uint32 coeffShiftRound = 1<<(coeffShift-1);
  int16 coeffRightShiftBits = roundLog2_approx(N) + 5;
  uint32 coeffRightShiftBitsRound = 1<<(coeffRightShiftBits-1);
  uint32 maxAbsMArray32 = 0;
  uint16 fittingRightShiftBits;

  for (i = 0; i < electrodeCount; i++)
  {
    uint32 x = i;
    uint32 x2 = x*x;
    uint32 x3 = x2*x;
    uint32 x4 = x3*x;
    uint32 Nm1mx = N - i;
    uint32 Nm1mx2 = Nm1mx*Nm1mx;
    uint32 Nm1mx3 = Nm1mx2*Nm1mx;
    uint32 Nm1mx4 = Nm1mx3*Nm1mx;

    xArray[i*AB_FIT_ORDER + 4] = (binomialCoefficients[0] * x4 + coeffShiftRound) >> coeffShift;
    xArray[i*AB_FIT_ORDER + 3] = (binomialCoefficients[1] * x3 * Nm1mx + coeffShiftRound) >> coeffShift;
    xArray[i*AB_FIT_ORDER + 2] = (binomialCoefficients[2] * x2 * Nm1mx2 + coeffShiftRound) >> coeffShift;
    xArray[i*AB_FIT_ORDER + 1] = (binomialCoefficients[1] * x * Nm1mx3 + coeffShiftRound) >> coeffShift;
    xArray[i*AB_FIT_ORDER + 0] = (binomialCoefficients[0] * Nm1mx4 + coeffShiftRound) >> coeffShift;

    mArray32[i + electrodeCount*0] = (int32)xTxInv[0]*xArray[i*AB_FIT_ORDER + 0] + (int32)xTxInv[1]*(int32)xArray[i*AB_FIT_ORDER + 1] + (int32)xTxInv[2]*xArray[i*AB_FIT_ORDER + 2] + (int32)xTxInv[3]*xArray[i*AB_FIT_ORDER + 3] + (int32)xTxInv[4]*xArray[i*AB_FIT_ORDER + 4];
    mArray32[i + electrodeCount*1] = (int32)xTxInv[1]*xArray[i*AB_FIT_ORDER + 0] + (int32)xTxInv[5]*(int32)xArray[i*AB_FIT_ORDER + 1] + (int32)xTxInv[6]*xArray[i*AB_FIT_ORDER + 2] + (int32)xTxInv[7]*xArray[i*AB_FIT_ORDER + 3] + (int32)xTxInv[3]*xArray[i*AB_FIT_ORDER + 4];
    mArray32[i + electrodeCount*2] = (int32)xTxInv[2]*xArray[i*AB_FIT_ORDER + 0] + (int32)xTxInv[6]*(int32)xArray[i*AB_FIT_ORDER + 1] + (int32)xTxInv[8]*xArray[i*AB_FIT_ORDER + 2] + (int32)xTxInv[6]*xArray[i*AB_FIT_ORDER + 3] + (int32)xTxInv[2]*xArray[i*AB_FIT_ORDER + 4];
    mArray32[i + electrodeCount*3] = (int32)xTxInv[3]*xArray[i*AB_FIT_ORDER + 0] + (int32)xTxInv[7]*(int32)xArray[i*AB_FIT_ORDER + 1] + (int32)xTxInv[6]*xArray[i*AB_FIT_ORDER + 2] + (int32)xTxInv[5]*xArray[i*AB_FIT_ORDER + 3] + (int32)xTxInv[1]*xArray[i*AB_FIT_ORDER + 4];
    mArray32[i + electrodeCount*4] = (int32)xTxInv[4]*xArray[i*AB_FIT_ORDER + 0] + (int32)xTxInv[3]*(int32)xArray[i*AB_FIT_ORDER + 1] + (int32)xTxInv[2]*xArray[i*AB_FIT_ORDER + 2] + (int32)xTxInv[1]*xArray[i*AB_FIT_ORDER + 3] + (int32)xTxInv[0]*xArray[i*AB_FIT_ORDER + 4];

    maxAbsMArray32 = ((uint32)IFP_ABS(mArray32[i + electrodeCount*0]) > maxAbsMArray32) ? (uint32)IFP_ABS(mArray32[i + electrodeCount*0]) : maxAbsMArray32;
    maxAbsMArray32 = ((uint32)IFP_ABS(mArray32[i + electrodeCount*1]) > maxAbsMArray32) ? (uint32)IFP_ABS(mArray32[i + electrodeCount*1]) : maxAbsMArray32;
    maxAbsMArray32 = ((uint32)IFP_ABS(mArray32[i + electrodeCount*2]) > maxAbsMArray32) ? (uint32)IFP_ABS(mArray32[i + electrodeCount*2]) : maxAbsMArray32;
    maxAbsMArray32 = ((uint32)IFP_ABS(mArray32[i + electrodeCount*3]) > maxAbsMArray32) ? (uint32)IFP_ABS(mArray32[i + electrodeCount*3]) : maxAbsMArray32;
    maxAbsMArray32 = ((uint32)IFP_ABS(mArray32[i + electrodeCount*4]) > maxAbsMArray32) ? (uint32)IFP_ABS(mArray32[i + electrodeCount*4]) : maxAbsMArray32;
  }

  {
    uint16 mArrayShift;
    uint32 mArrayShiftRound;
    int32 sumB_0_4 = 0;
    mArrayShift = floorLog2(maxAbsMArray32) + 1 - 15;
    mArrayShiftRound = 1<<(mArrayShift-1);

    for (i = 0; i < electrodeCount; i++)
    {
      mArray[i + electrodeCount*0] = (mArray32[i + electrodeCount*0] + mArrayShiftRound) >> mArrayShift;
      mArray[i + electrodeCount*1] = (mArray32[i + electrodeCount*1] + mArrayShiftRound) >> mArrayShift;
      mArray[i + electrodeCount*2] = (mArray32[i + electrodeCount*2] + mArrayShiftRound) >> mArrayShift;
      mArray[i + electrodeCount*3] = (mArray32[i + electrodeCount*3] + mArrayShiftRound) >> mArrayShift;
      mArray[i + electrodeCount*4] = (mArray32[i + electrodeCount*4] + mArrayShiftRound) >> mArrayShift;

      sumB_0_4 += mArray[i + electrodeCount*0];
    }

    {
      int16 testCoeff;
      int32 y;
      testCoeff = (sumB_0_4 + coeffRightShiftBitsRound) >> coeffRightShiftBits;
      y = (int32)xArray[0] * testCoeff;
      fittingRightShiftBits = roundLog2_approx(y);

      fittingRightShiftBits += coeffRightShiftBits;
    }
  }

  *coeffRightShiftBitsOutput = coeffRightShiftBits;
  *fittingRightShiftBitsOutput = fittingRightShiftBits;
}


void constructAntiBendingMatrices(sensorParams_t *sp)
{
  memset16(abData.xArray, 0, AB_FIT_ORDER*MAX_RX);
  memset16(abData.mArray, 0, AB_FIT_ORDER*MAX_RX);
  constructAntiBendingMatricesSingleAxis(sp->rxCount, abConfig.xTxInv, abData.xArray, abData.mArray, &abData.coeffRightShiftBits, &abData.fittingRightShiftBits);

#if CONFIG_HAS_HYBRID
  memset16(abData.xArrayTx, 0, AB_FIT_ORDER*MAX_TX);
  memset16(abData.mArrayTx, 0, AB_FIT_ORDER*MAX_TX);
  constructAntiBendingMatricesSingleAxis(sp->txCount, abConfig.xTxInvTx, abData.xArrayTx, abData.mArrayTx, &abData.coeffTxRightShiftBits, &abData.fittingTxRightShiftBits);
#endif  // CONFIG_HAS_HYBRID
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/
void antiBending_configure(sensorParams_t *sp, antiBendingConfig_t *config)
{
  binomialCoefficients[0] = 1;
  binomialCoefficients[1] = 4;
  binomialCoefficients[2] = 6;
  abConfig = *config;
  memset16(&abData, 0, sizeof(abData) / sizeof(uint16));
  constructAntiBendingMatrices(sp);
}

/* -----------------------------------------------------------
Name: antiBending_correctImage
Purpose: Correct bending by fitting each tx with a low-order polynomial.
Inputs: sensor params
        delta image
Outputs: None
Effects: delta image modified in-place.
----------------------------------------------------------- */
void antiBending_correctImage(sensorParams_t *sp, int16 *deltaImage)
{
  int16 fingerlessImage[(MAX_TX + 2) * (MAX_RX + 1) + 1];
  uint16 i;
  uint16 offset = (MAX_RX + 1) + 1; // skip 0-padding
  int16 isTx = 0;

  #if (defined(CONFIG_IFP_ANTIBENDING_FOR_CLOSEDCOVER) && CONFIG_IFP_ANTIBENDING_FOR_CLOSEDCOVER)
  if (getClosedCoverStatus())
  {
    preProcessImage(sp, fingerlessImage, deltaImage, abConfig.logTouchThreshold_closedCover_LSB, abConfig.deltaTouchThreshold_closedCover_LSB);
  }
  else
  #endif
  {
    preProcessImage(sp, fingerlessImage, deltaImage, abConfig.logTouchThreshold_LSB, abConfig.deltaTouchThreshold_LSB);
  }

  for (i = 0; i < sp->txCount; i++, offset += MAX_RX + 1)
  {
    int16 coeff[AB_FIT_ORDER];
    estimateCoeff(&fingerlessImage[offset], sp->rxCount, coeff);
    applyCorrection(&deltaImage[offset], sp->rxCount, abData.xArray, coeff, isTx);
  }
}

#if CONFIG_HAS_HYBRID

/* -----------------------------------------------------------
Name: antiBending_correctXProfile
Purpose: Correct bending by fitting the X profile with a low-order polynomial.
Inputs: sensor params
        delta X profile
Outputs: None
Effects: delta profile modified in-place.
----------------------------------------------------------- */
void antiBending_correctXProfile(sensorParams_t *sp, int16 *deltaXProfile)
{
  int16 fingerlessProfile[MAX_ABS_RX+MAX_ABS_TX];  // sub-functions need to be able to operate on either X or Y, so overallocate
  int16 isTx = 0;

  if (deltaXProfile == NULL) return;

  preProcessProfile(fingerlessProfile, deltaXProfile, sp->rxCount, abConfig.xProfileLogTouchThreshold_LSB, abConfig.xProfileDeltaTouchThreshold_LSB);
  {
    int16 coeff[AB_FIT_ORDER];
    estimateCoeff(&fingerlessProfile[0], sp->rxCount, coeff);
    applyCorrection(&deltaXProfile[0], sp->rxCount, abData.xArray, coeff, isTx);
  }
}

/* -----------------------------------------------------------
Name: antiBending_correctYProfile
Purpose: Correct bending by fitting the Y profile with a low-order polynomial
Inputs: sensor params
        delta Y profile
Outputs: None
Effects: delta profile modified in-place.
----------------------------------------------------------- */
void antiBending_correctYProfile(sensorParams_t *sp, int16 *deltaYProfile)
{
  int16 fingerlessProfile[MAX_ABS_RX+MAX_ABS_TX];  // sub-functions need to be able to operate on either X or Y, so overallocate
  int16 isTx = 1;

  if (deltaYProfile == NULL) return;

  preProcessProfile(fingerlessProfile, deltaYProfile, sp->txCount, abConfig.yProfileLogTouchThreshold_LSB, abConfig.yProfileDeltaTouchThreshold_LSB);
  {
    int16 coeff[AB_FIT_ORDER];
    estimateCoeffTx(&fingerlessProfile[0], sp->txCount, coeff);
    applyCorrection(&deltaYProfile[0], sp->txCount, abData.xArrayTx, coeff, isTx);
  }
}

#endif  // CONFIG_HAS_HYBRID

#endif  // CONFIG_HAS_ANTI_BENDING
