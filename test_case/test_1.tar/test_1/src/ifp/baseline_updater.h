#ifndef _BASELINE_UPDATER_H_
#define _BASELINE_UPDATER_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: baseline_updater.h
// Description: Interface for baseline updater
// $Id:$

#include "ifp_common.h"

void baselineUpdater_init(void);
void baselineUpdater_reinit(void);
void baselineUpdater_configure(baselineUpdaterConfig_t *config);
void baselineUpdater_remove(sensorParams_t *sensorParams, uint16 *rawImage, imageBaseline_t *baseline, int16 *deltaImage);
void baselineUpdater_update(sensorParams_t *sensorParams, uint16 relaxCommand, uint16 frameTime_ms, uint16 *rawImage, imageBaseline_t *baseline);

#endif  //_BASELINE_UPDATER_H_
