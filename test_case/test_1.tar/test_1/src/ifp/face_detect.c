/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: Removes blobs that are likely to be noise. This should
                be considered a temporary fix while we work around
                problems in the tracker design
   $Id: face_detect.cpp,v 1.1.4.4.14.2 2013/11/13 22:43:05 swilliam Exp $
----------------------------------------------------------------- */

#include "ifp_common.h"
#include "face_detect.h"

#if CONFIG_HAS_FACE_DETECT
//Direction for profile
uint16 rxProfileEnabled;
uint16 txProfileEnabled;

//Filter initialization
uint16 fn_test;   // number of samples to use for filter test [int8] (default: 15)
uint16 fn_redo;   // test maximum which triggers filter reset [int8] (default: 10)

//Face detected state info
uint16 reset_filters;
uint16 face_detected;
uint16 filterInitialized;
uint16 zeroAccumulator;
uint16 loop_int;
int16 sign_cnt;
static uint16 initFrameCount;

//Face detect filter shift coefficients
int16 fs_init;   // initialize filters with 2^(fs_init) samples [int8] (default: 5)
int16 fs_fast;   // fast-filter accumulates 2^(fs_fast) samples [int8] (default: 3)
int16 fs_slow;   // slow-filter accumulates 2^(fs_slow) samples [int8] (default: 7)
int16 fs_prec;   // right shift filter-difference by (fs_prec) bits [int8] (default: 6)

//Face-detect entry and exit hysteresis
uint16 fn_set;    // number of consecutive face-detect samples to set face-detect bit [uint8] (default: 15)
uint16 fn_unset;  // number of consecutive blank samples to unset face-detect bit [uint8] (default: 25)

//TX VARIABLES
//Edge Exclusion.
uint16 fn_front_omit_tx;   // half-count of front-edge-rx to exclude from algorithm [uint8] (default: 2)
uint16 fn_end_omit_tx;   // half-count of end-edge-rx to exclude from algorithm [uint8] (default: 2)

//Face detect thresholds
uint16 ft_update_tx; // threshold at/below which to flag rx as allowing slow-filter update [int32] (default: 15)
uint16 ft_hold_tx;   // threshold at/above which to flag rx as halting slow-filter update [int32] (default: 25)
uint16 ft_hover_tx;  // threshold at/above which to flag rx as hover, but less than touch [int32] (default: 40)
uint16 ft_touch_tx;  // threshold at/above which to flag rx as touched [int32] (default: 250)

uint16 fn_update_tx; // number of update-flagged receivers to allow slow-filter update [uint8] (default: 1)
uint16 fn_hold_tx;   // number of hold-flagged receivers to halt slow-filter update [uint8] (default: 2)
uint16 fn_hover_tx;  // number of hover-flagged receivers to even consider setting face-detect [uint8] (default: 12)
uint16 fn_touch_tx;  // number of touch-flagged receivers allowed when considering face-detect [uint8] (default: 0)

static uint16 profileLengthTX;
static int16 max_filt_diff_tx;
int32 filt_slow_tx[MAX_TX];
int32 filt_fast_tx[MAX_TX];
int32 filt_diff_tx[MAX_TX];
uint16 face_detected_tx;
uint16 slow_update_tx;
uint16 fast_update_tx;
uint16 cnt_set_tx;
uint16 cnt_unset_tx;
uint16 tx_update;
uint16 tx_hold;
uint16 tx_hover;
uint16 tx_touch;
uint16 tx_negative;
int32 diff_sum_tx;

//RX VARIABLES
//Edge Exclusion.
uint16 fn_front_omit_rx;   // half-count of front-edge-rx to exclude from algorithm [uint8] (default: 2)
uint16 fn_end_omit_rx;   // half-count of end-edge-rx to exclude from algorithm [uint8] (default: 2)

//Face detect thresholds
uint16 ft_update_rx; // threshold at/below which to flag rx as allowing slow-filter update [int32] (default: 15)
uint16 ft_hold_rx;   // threshold at/above which to flag rx as halting slow-filter update [int32] (default: 25)
uint16 ft_hover_rx;  // threshold at/above which to flag rx as hover, but less than touch [int32] (default: 40)
uint16 ft_touch_rx;  // threshold at/above which to flag rx as touched [int32] (default: 250)

uint16 fn_update_rx; // number of update-flagged receivers to allow slow-filter update [uint8] (default: 1)
uint16 fn_hold_rx;   // number of hold-flagged receivers to halt slow-filter update [uint8] (default: 2)
uint16 fn_hover_rx;  // number of hover-flagged receivers to even consider setting face-detect [uint8] (default: 12)
uint16 fn_touch_rx;  // number of touch-flagged receivers allowed when considering face-detect [uint8] (default: 0)

static uint16 profileLengthRX;
static int16 max_filt_diff_rx;

int32 filt_slow_rx[MAX_RX];
int32 filt_fast_rx[MAX_RX];
int32 filt_diff_rx[MAX_RX];

uint16 face_detected_rx;
uint16 slow_update_rx;
uint16 fast_update_rx;

uint16 cnt_set_rx;
uint16 cnt_unset_rx;
uint16 rx_update;
uint16 rx_hold;
uint16 rx_hover;
uint16 rx_touch;
uint16 rx_negative;
int32 diff_sum_rx;

int32 bitShift(int32 input, int16 shift);
void faceDetect_setFilters(uint32* rawProfileRX, uint32* rawProfileTX);
void faceDetect_initFilters(uint32* rawProfileRX, uint32* rawProfileTX);
void facetDetect_detect(uint32* rawProfileRX, uint32* rawProfileTX);

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/
/* -----------------------------------------------------------------
Name: faceDetect_init()
Purpose: Initialize the noise peak filter variable, as at
         ASIC power-on.
Inputs:  None.
Outputs: None.
Effects: None.
Notes:
Example: None.
----------------------------------------------------------------- */
void faceDetect_init()
{
  reset_filters = 1;
  face_detected = 0;
  filterInitialized = 0;
  zeroAccumulator = 0;

  if (rxProfileEnabled) {
    face_detected_rx = 0;
    slow_update_rx = 1;
    fast_update_rx = 0;
    cnt_set_rx = fn_set;
    cnt_unset_rx = fn_unset;
  }

  if (txProfileEnabled) {
    face_detected_tx = 0;
    slow_update_tx = 1;
    fast_update_tx = 0;
    cnt_set_tx = fn_set;
    cnt_unset_tx = fn_unset;
  }
}

/* -----------------------------------------------------------------
Name: faceDetect_reinit()
Purpose: Re-initialize the noise peak filter variable at rezero command
Inputs:  None.
Outputs: None.
Effects: None.
Notes:   None.
Example: None.
----------------------------------------------------------------- */
void faceDetect_reinit()
{
  faceDetect_init();
}

/* -----------------------------------------------------------------
Name: faceDetect_configure()
Purpose: Configure the internal variables
Inputs:  None.
Outputs: None.
Effects: None.
Notes:   None.
Example: None.
----------------------------------------------------------------- */
void faceDetect_configure(faceDetectConfig_t *faceDetectConfig)
{

  rxProfileEnabled = faceDetectConfig->enable_Face_Detection_RX;
  txProfileEnabled = faceDetectConfig->enable_Face_Detection_TX;
  //Face detect filter shift coefficients
  fs_init = 5; //faceDetectConfig->fs_init;   // half-count of edge-rx to exclude from algorithm [uint8] (default: 2)
  fs_fast = 3; //faceDetectConfig->fs_fast;   // fast-filter accumulates 2^(fs_fast) samples [int8] (default: 3)
  fs_slow = 9; //faceDetectConfig->fs_slow;   // slow-filter accumulates 2^(fs_slow) samples [int8] (default: 7)
  fs_prec = 7; //faceDetectConfig->fs_prec;   // right shift filter-difference by (fs_prec) bits [int8] (default: 6)

  //Filter initialization
  fn_test = faceDetectConfig->fn_test;    // number of samples to use for filter test [int8] (default: 15)
  fn_redo = faceDetectConfig->fn_redo;   // test maximum which triggers filter reset [int8] (default: 10)

  //Face-detect entry and exit hysteresis
  fn_set =  faceDetectConfig->fn_set; /// number of consecutive face-detect samples to set face-detect bit [uint8] (default: 15)
  fn_unset = faceDetectConfig->fn_unset; // number of consecutive blank samples to unset face-detect bit [uint8] (default: 25)

  //TX VARIABLES
  //Edge Exclusion
  fn_front_omit_tx = faceDetectConfig->fn_front_omit_tx;   // half-count of edge-rx to exclude from algorithm [uint8] (default: 2)
  fn_end_omit_tx = faceDetectConfig->fn_end_omit_rx;   // half-count of edge-rx to exclude from algorithm [uint8] (default: 2)

  //Face detect thresholds
  ft_update_tx = faceDetectConfig->ft_update_tx; // threshold at/below which to flag rx as allowing slow-filter update [int32] (default: 15)
  ft_hold_tx = faceDetectConfig->ft_hold_tx;     // threshold at/above which to flag rx as halting slow-filter update [int32] (default: 25)
  ft_hover_tx = faceDetectConfig->ft_hover_tx;   // threshold at/above which to flag rx as hover, but less than touch [int32] (default: 40)
  ft_touch_tx = faceDetectConfig->ft_touch_tx;   // threshold at/above which to flag rx as touched [int32] (default: 250)
  fn_update_tx = faceDetectConfig->fn_update_tx; // number of update-flagged receivers to allow slow-filter update [uint8] (default: 1)
  fn_hold_tx = faceDetectConfig->fn_hold_tx;    // number of hold-flagged receivers to halt slow-filter update [uint8] (default: 2)
  fn_hover_tx = faceDetectConfig->fn_hover_tx;  // number of hover-flagged receivers to even consider setting face-detect [uint8] (default: 12)
  fn_touch_tx = faceDetectConfig->fn_touch_tx;  // number of touch-flagged receivers allowed when considering face-detect [uint8] (default: 0)


  //RX VARIABLES
  //Edge Exclusion
  fn_front_omit_rx = faceDetectConfig->fn_front_omit_rx;   // half-count of edge-rx to exclude from algorithm [uint8] (default: 2)
  fn_end_omit_rx = faceDetectConfig->fn_end_omit_rx;   // half-count of edge-rx to exclude from algorithm [uint8] (default: 2)

  //Face detect thresholds
  ft_update_rx = faceDetectConfig->ft_update_rx; // threshold at/below which to flag rx as allowing slow-filter update [int32] (default: 15)
  ft_hold_rx = faceDetectConfig->ft_hold_rx;     // threshold at/above which to flag rx as halting slow-filter update [int32] (default: 25)
  ft_hover_rx = faceDetectConfig->ft_hover_rx;   // threshold at/above which to flag rx as hover, but less than touch [int32] (default: 40)
  ft_touch_rx = faceDetectConfig->ft_touch_rx;   // threshold at/above which to flag rx as touched [int32] (default: 250)
  fn_update_rx = faceDetectConfig->fn_update_rx; // number of update-flagged receivers to allow slow-filter update [uint8] (default: 1)
  fn_hold_rx = faceDetectConfig->fn_hold_rx;    // number of hold-flagged receivers to halt slow-filter update [uint8] (default: 2)
  fn_hover_rx = faceDetectConfig->fn_hover_rx;  // number of hover-flagged receivers to even consider setting face-detect [uint8] (default: 12)
  fn_touch_rx = faceDetectConfig->fn_touch_rx;  // number of touch-flagged receivers allowed when considering face-detect [uint8] (default: 0)

  // profileLengthRX = MAX_RX; //sensorParameters->rxCount;
}

uint16 isFaceDetected(uint16* rawProfileRX)
{
  uint32 rawDataRX[MAX_RX];
  uint32 rawDataTX[MAX_TX];

  uint16 i,j;

  for (i = 0; i < MAX_TX; i++) {
    for (j = 0; j < MAX_RX; j++) {
      if (rxProfileEnabled) {
        rawDataRX[j] += (int32)*rawProfileRX;
      }
      if (txProfileEnabled) {
        rawDataTX[i] += (int32)*rawProfileRX;
      }
      rawProfileRX++;
    }
  }

  if (rxProfileEnabled && txProfileEnabled) {
    profileLengthRX = MAX_RX;
    profileLengthTX = MAX_TX;
    facetDetect_detect(rawDataRX, rawDataTX);
  }
  else if (rxProfileEnabled) {
    profileLengthRX = MAX_RX;
    facetDetect_detect(rawDataRX, rawDataTX);
  }
  else if (txProfileEnabled) {
    profileLengthTX = MAX_TX;
    facetDetect_detect(rawDataRX, rawDataTX);
  }

  return face_detected;
}

// Helper Bit-Shift Operation
int32 bitShift(int32 input, int16 shift)
{
  int32 value;
  if(shift < 0)
  {
    shift = -shift;
    value = input >> shift;
  }
  else
  {
    value = input << shift;
  }
  return value;
}

// The following function sets the filters by sampling a smaller number of
// samples than would be required to initialize the slow filter. Then, it is
// up-shifted to the appropriate size / precision of the slow filter. The
// fast-filter is set by down-shifting the slow-filter to the fast-filter's
// precision.
void faceDetect_setFilters(uint32* rawProfileRX, uint32* rawProfileTX)
{
  uint16 i;
  if (!rxProfileEnabled) {
    (void)rawProfileRX;
  }
  if (!txProfileEnabled) {
    (void)rawProfileTX;
  }
   //Accumulate 2^(fs_init) unique profile-samples inside slow-filter.
    if(!zeroAccumulator)
    {
      if (rxProfileEnabled) {
      for(i = 0; i < profileLengthRX; i++)
      {
        filt_slow_rx[i] = 0;
      }
      }

      if (txProfileEnabled) {
      for(i = 0; i < profileLengthTX; i++)
      {
        filt_slow_tx[i] = 0;
      }
      }

      initFrameCount = 1 << fs_init;
      zeroAccumulator = 1;
    }

    if(initFrameCount != 0)
    {
      initFrameCount--;

      if (rxProfileEnabled) {
      for(i = fn_front_omit_rx; i < (profileLengthRX - fn_end_omit_rx); i++)
      {
        filt_slow_rx[i] += rawProfileRX[i];
      }
      }

      if (txProfileEnabled) {
      for(i = fn_front_omit_tx; i < (profileLengthTX - fn_end_omit_tx); i++)
      {
        filt_slow_tx[i] += rawProfileTX[i];
      }
      }

      return;
    }
    else
    {
      filterInitialized = 1;
    }
    //Left-shift slow-filter so that it looks like the accumulation of
    //2^(fs_slow) profile-samples. Initialize the fast-filter by right-
    //shifting the slow-filter so that it looks like the accumulation of
    //2^(fs_fast) profile-samples.
    if (rxProfileEnabled) {
    for(i = fn_front_omit_rx; i < (profileLengthRX-fn_end_omit_rx); i++)
    {
      filt_slow_rx[i] = bitShift(filt_slow_rx[i],fs_slow-fs_init);
      filt_fast_rx[i] = bitShift(filt_slow_rx[i],fs_fast-fs_slow);
    }
    }

    if (txProfileEnabled) {
    for(i = fn_front_omit_tx; i < (profileLengthTX-fn_end_omit_tx); i++)
    {
      filt_slow_tx[i] = bitShift(filt_slow_tx[i],fs_slow-fs_init);
      filt_fast_tx[i] = bitShift(filt_slow_tx[i],fs_fast-fs_slow);
    }
    }

    if(filterInitialized == 1)
    {
      loop_int = fn_test;
      sign_cnt = 0;

      if (rxProfileEnabled) {
      diff_sum_rx = 0;
      }

      if (txProfileEnabled) {
      diff_sum_tx = 0;
      }
    }
}
/* -----------------------------------------------------------
Name: faceDetect_initFilters
Purpose:
  Filter initialization is (ideally) only carried out once. Because it is
  so important for it to be correct, to return good profile difference
  data, it is validated. Initialization and verification should not be
  performed immediately on phone boot-up, but should happen after the abs-
  baseline is stable enough to capture. Verification is done by counting
  the number of sign-changes for a small number of new samples. If the
  difference has too many samples above or below zero, the filter is
  re-initialized.
Inputs:
Outputs:
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------- */
void faceDetect_initFilters(uint32* rawProfileRX, uint32* rawProfileTX)
{
  uint16 i;
  uint16 sign_cnt_abs;

  if (!rxProfileEnabled) {
    (void)rawProfileRX;
  }
  if (!txProfileEnabled) {
    (void)rawProfileTX;
  }

  if(filterInitialized) //Filter initialized, now test filter
  {
    if(loop_int)
    {
      loop_int--;

      if (rxProfileEnabled) {
        diff_sum_rx = 0;
        for(i = fn_front_omit_rx; i < (profileLengthRX-fn_end_omit_rx); i++)
        {
          filt_slow_rx[i] = filt_slow_rx[i] - bitShift(filt_slow_rx[i],-fs_slow) + rawProfileRX[i];
          filt_fast_rx[i] = filt_fast_rx[i] - bitShift(filt_fast_rx[i],-fs_fast) + rawProfileRX[i];
          filt_diff_rx[i] = bitShift(filt_fast_rx[i],fs_slow-fs_fast) - filt_slow_rx[i];
          filt_diff_rx[i] = bitShift(filt_diff_rx[i],-fs_prec);
          diff_sum_rx += filt_diff_rx[i];
        }

        if (diff_sum_rx > 0)
          sign_cnt++;
        if (diff_sum_rx < 0)
          sign_cnt--;
      }

      if (txProfileEnabled) {
        diff_sum_tx = 0;
        for(i = fn_front_omit_tx; i < (profileLengthTX-fn_end_omit_tx); i++)
        {
          filt_slow_tx[i] = filt_slow_tx[i] - bitShift(filt_slow_tx[i],-fs_slow) + rawProfileTX[i];
          filt_fast_tx[i] = filt_fast_tx[i] - bitShift(filt_fast_tx[i],-fs_fast) + rawProfileTX[i];
          filt_diff_tx[i] = bitShift(filt_fast_tx[i],fs_slow-fs_fast) - filt_slow_tx[i];
          filt_diff_tx[i] = bitShift(filt_diff_tx[i],-fs_prec);
          diff_sum_tx += filt_diff_tx[i];
        }

        if (diff_sum_tx > 0)
          sign_cnt++;
        if (diff_sum_tx < 0)
          sign_cnt--;
        }
    }
    else
    {
      if(sign_cnt < 0)
      {
      sign_cnt_abs = -sign_cnt;
      }

      else
      {
      sign_cnt_abs = sign_cnt;
      }

      if (sign_cnt_abs <= fn_redo)
      {
        reset_filters = 0;
        return;
      }
      else
      {
        reset_filters = 1;
        zeroAccumulator = 0;
        filterInitialized = 0;
      }
    }
  }
  else
  {
    if (rxProfileEnabled && txProfileEnabled) {
      faceDetect_setFilters(rawProfileRX, rawProfileTX);
    }
    else if (rxProfileEnabled) {
      faceDetect_setFilters(rawProfileRX, rawProfileTX);
    }
    else if (txProfileEnabled) {
      faceDetect_setFilters(rawProfileRX, rawProfileTX);
    }
  }
}

void facetDetect_detect(uint32* rawProfileRX, uint32* rawProfileTX)
{
  uint16 i;
  if (rxProfileEnabled) {
    rx_update = 0;
    rx_negative = 0;
    rx_hold = 0;
    rx_hover = 0;
    rx_touch = 0;
    max_filt_diff_rx = 0x8000; //-32768
  }

  if (txProfileEnabled) {
    tx_update = 0;
    tx_negative = 0;
    tx_hold = 0;
    tx_hover = 0;
    tx_touch = 0;
    max_filt_diff_tx = 0x8000; //-32768
  }

  if(reset_filters)
  {
    if (rxProfileEnabled && txProfileEnabled) {
      faceDetect_initFilters(rawProfileRX, rawProfileTX);
    }
    else if (rxProfileEnabled) {
      faceDetect_initFilters(rawProfileRX, rawProfileTX);
    }
    else if (txProfileEnabled) {
      faceDetect_initFilters(rawProfileRX, rawProfileTX);
    }
    return;
  }

  if (rxProfileEnabled) {
    for(i = fn_front_omit_rx; i < (profileLengthRX-fn_end_omit_rx); i++)
    {
      // Update the filters with a new sample. Note that each filter basically
      // tracks (2^fs_slow) and (2^fs_fast) samples, respectively. They are
      // both low-pass filters, with one filter being faster than the other.
      // They are updated by subtracting the average and adding a new profile
      // sample.
      filt_fast_rx[i] = (filt_fast_rx[i] - bitShift(filt_fast_rx[i], -fs_fast) + rawProfileRX[i]);
      if(fast_update_rx)
      {
        filt_slow_rx[i] = bitShift(filt_fast_rx[i],(fs_slow-fs_fast));
      }
      else if (slow_update_rx)
      {
        filt_slow_rx[i] = (filt_slow_rx[i] - bitShift(filt_slow_rx[i],-fs_slow) + rawProfileRX[i]);
      }

      //The filter difference provides a filtered delta response, immune to
      //slow thermal changes and (somewhat) immune to noise, allowing face-
      //detect to perform in negative SNR conditions. To subtract correctly,
      //the fast-filter is up-shifted to the precision of the slow filter.
      //The difference is down-shifted because the least-significant bits of
      //the data are too noisy to be useful.

      filt_diff_rx[i] = bitShift(filt_fast_rx[i],(fs_slow-fs_fast)) - filt_slow_rx[i];
      filt_diff_rx[i] = bitShift(filt_diff_rx[i],-fs_prec);

      //Each receiver response gets binned into the following categories:
        //
        //  update: receiver is at or below update threshold.
        //  hold:   receiver is at or above hold threshold.
        //  hover:  receiver is at or above hover threshold, but below touch.
        //  touch   receiver is at or above touch threshold.
        //
      //Threshold is determined by the ft_* parameter, count is stored in
      //the rx_* parameter.

      if (filt_diff_rx[i] <= ft_update_rx)
      {
        rx_update++;
      }
      if (filt_diff_rx[i] >= ft_hold_rx)
      {
        rx_hold++;
      }
      if (filt_diff_rx[i] >= ft_touch_rx)
      {
        rx_touch++;
      }
      else if (filt_diff_rx[i] >= ft_hover_rx)
      {
        rx_hover++;
      }
      if ((int16)filt_diff_rx[i] > max_filt_diff_rx)
      {
        max_filt_diff_rx = filt_diff_rx[i];
      }
      if((filt_diff_rx[i] < -(int16)ft_touch_rx/4))
      {
        rx_negative++;
      }
    }
  }

  if (txProfileEnabled) {
    for(i = fn_front_omit_tx; i < (profileLengthTX-fn_end_omit_tx); i++)
    {
      // Update the filters with a new sample. Note that each filter basically
      // tracks (2^fs_slow) and (2^fs_fast) samples, respectively. They are
      // both low-pass filters, with one filter being faster than the other.
      // They are updated by subtracting the average and adding a new profile
      // sample.
      filt_fast_tx[i] = (filt_fast_tx[i] - bitShift(filt_fast_tx[i], -fs_fast) + rawProfileTX[i]);
      if(fast_update_tx)
      {
        filt_slow_tx[i] = bitShift(filt_fast_tx[i],(fs_slow-fs_fast));
      }
      else if (slow_update_tx)
      {
        filt_slow_tx[i] = (filt_slow_tx[i] - bitShift(filt_slow_tx[i],-fs_slow) + rawProfileTX[i]);
      }

      //The filter difference provides a filtered delta response, immune to
      //slow thermal changes and (somewhat) immune to noise, allowing face-
      //detect to perform in negative SNR conditions. To subtract correctly,
      //the fast-filter is up-shifted to the precision of the slow filter.
      //The difference is down-shifted because the least-significant bits of
      //the data are too noisy to be useful.

      filt_diff_tx[i] = bitShift(filt_fast_tx[i],(fs_slow-fs_fast)) - filt_slow_tx[i];
      filt_diff_tx[i] = bitShift(filt_diff_tx[i],-fs_prec);

      //Each receiver response gets binned into the following categories:
        //
        //  update: receiver is at or below update threshold.
        //  hold:   receiver is at or above hold threshold.
        //  hover:  receiver is at or above hover threshold, but below touch.
        //  touch   receiver is at or above touch threshold.
        //
      //Threshold is determined by the ft_* parameter, count is stored in
      //the rx_* parameter.

      if (filt_diff_tx[i] <= ft_update_tx)
      {
        tx_update++;
      }
      if (filt_diff_tx[i] >= ft_hold_tx)
      {
        tx_hold++;
      }
      if (filt_diff_tx[i] >= ft_touch_tx)
      {
        tx_touch++;
      }
      else if (filt_diff_tx[i] >= ft_hover_tx)
      {
        tx_hover++;
      }
      if ((int16)filt_diff_tx[i] > max_filt_diff_tx)
      {
        max_filt_diff_tx = filt_diff_tx[i];
      }
      if(filt_diff_tx[i] < -(int16)ft_touch_tx/4)
      {
        tx_negative++;
      }
    }
  }

  // Disable and update the slow-filter based on the hold and update
  // counters. This conditional logic favors allowing updates more than
  // disallowing updates to reduce the chances of getting stuck in face-
  // detect mode. Switching the order of the if statements would result
  // in better performance, with the risk of getting stuck in face-detect.
  if (rxProfileEnabled) {
    if (rx_hold >= fn_hold_rx)
    {
      slow_update_rx = 0;
    }
    if (rx_update >= fn_update_rx && rx_touch ==  0)
    {
      slow_update_rx = 1;
    }

    //too much engative signals, do fast relax
    if((rx_negative > 0 && rx_touch == 0)
      || (max_filt_diff_rx > 10000)) //&& slow_update_rx
    {
      fast_update_rx = 1;
    }
    else
    {
      fast_update_rx = 0;
    }
  }

  if (txProfileEnabled) {
    if (tx_hold >= fn_hold_tx)
    {
      slow_update_tx = 0;
    }
    if (tx_update >= fn_update_tx && tx_touch == 0)
    {
      slow_update_tx = 1;
    }

    //too much engative signals, do fast relax
    if((tx_negative > 0
        && slow_update_tx
        && tx_touch == 0)
      || max_filt_diff_tx > 9000)
    {
      fast_update_tx = 1;
    }
    else
    {
      fast_update_tx = 0;
    }
  }

  // The following logic only updates face-detect if touch is below a
  // limit, typically, no touch is allowed. Hysteresis is built-in to
  // avoid noise. A certain number of samples is needed to either set, or
  // unset the face-detect mode, so individual samples may 0ly
  // set / unset their respective face-detect conditions, without setting
  // the user-side face-detect bit.

  if (rxProfileEnabled) {
    if (rx_touch <= fn_touch_rx)
    {
      if (rx_hover >= fn_hover_rx)
      {
        cnt_unset_rx = fn_unset;
        cnt_set_rx--;
        if (!cnt_set_rx)
        {
          cnt_set_rx = fn_set;
          face_detected_rx = 1;
        }
      }
      if (rx_update >= fn_update_rx)
      {
        cnt_set_rx = fn_set;
        cnt_unset_rx--;
        if (!cnt_unset_rx)
        {
          cnt_unset_rx = fn_unset;
          face_detected_rx = 0;
        }
      }
    }

    else
    {
      cnt_set_rx = fn_set;
      cnt_unset_rx = fn_unset;
    }
  }

  if (txProfileEnabled) {
    if (tx_touch <= fn_touch_tx)
    {
      if (tx_hover >= fn_hover_tx)
      {
        cnt_unset_tx = fn_unset;
        cnt_set_tx--;
        if (!cnt_set_tx)
        {
          cnt_set_tx = fn_set;
          face_detected_tx = 1;
        }
      }
      if (tx_update >= fn_update_tx)
      {
        cnt_set_tx = fn_set;
        cnt_unset_tx--;
        if (!cnt_unset_tx)
        {
          cnt_unset_tx = fn_unset;
          face_detected_tx = 0;
        }
      }
    }

    else
    {
      cnt_set_tx = fn_set;
      cnt_unset_tx = fn_unset;
    }
  }

  if (rxProfileEnabled && txProfileEnabled) {
    face_detected = (face_detected_rx && face_detected_tx);
  }
  else if (rxProfileEnabled) {
    face_detected = face_detected_rx;
  }
  else if (txProfileEnabled) {
    face_detected = face_detected_tx;
  }
}
#endif // CONFIG_HAS_FACE_DETECT
