// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: classifier.c
// Description: Computes object features and classifies them according to
//              the features and previous state.
// $Id: classifier.c,v 1.5.8.2.4.23 2013/01/30 18:45:56 jjordan Exp $

#include "ifp_common.h"
#include "ifp_string.h"
#include "classifier.h"
#include "small_object_detector.h"
#include "adaptive_lgm.h"
#include "position_reporter.h"
// - module types -

typedef enum
{
  class_none,
  class_unknown,
  class_saturatedFinger,
  class_liftingSaturatedFinger,
  class_smallFinger,
  class_wideSmallFinger,
  class_liftingSmallFinger,
  class_landingSaturatedFinger,
  class_liftingWhileLandingSaturatedFinger,
  class_landingSmallFinger,
  class_liftingWhileLandingSmallFinger,
  class_stylus,
  class_liftingStylus,
  class_eraser,
  class_liftingEraser,
  class_negativeFinger,
  class_palm,
  class_hoveringFinger,
  class_glovedFinger,
  class_consistencyError,
  class_cdmArtifact
} objectClass_t;

#define MAX_FRAME_COUNT 255   // keep this in sync if you change the size of frameCount below
#define MAX_LANDING_OBJECT_FRAME_COUNT 255 // keep this in sync if you change the size
                                          // of landingObjectFrameCount below
#define MAX_SMALL_FINGER_FRAME_COUNT 255  // keep this in sync if you change the size
                                          // of smallFingerFrameCount below
#define MAX_ABS_ABSENT_FRAME_COUNT 15  // keep this in sync if you change the size
typedef struct
{
  uint8p8 oldZ;
  int16 prevPeakVal;
  uint16 lastRelativeAmplitude : 8; // this is uint0p8
  objectClass_t objClass : 8;
  uint16 frameCount : 8;   // fix MAX_FRAME_COUNT if you change this size
  uint16 landingObjectFrameCount: 8; // fix MAX_LANDING_OBJECT_FRAME_COUNT if you change this size
  uint16 smallFingerFrameCount : 8; // fix MAX_SMALL_FINGER_FRAME_COUNT if you change this size
  uint16 smallFingerArea : 8;
  uint16 landingGlovedFinger : 7; // coordinate this with the number of frames a gloved finger landing event lasts and classifierResults_t
  uint16 formerGlovedFinger : 1;
  uint16 formerSaturatedFinger : 1;
  uint16 absAbsentFrameCount : 4; // number of frames with abs absent - sync with MAX_ABS_ABSENT_FRAME_COUNT if size changes
#if CONFIG_HAS_GLOVE_STABLE_FRAMES
  struct {
    uint16 count;
     int16 peaks[16];
  } stableFrames;
#endif
} classifierState_t;

typedef struct
{
  int16 peakVal;
  uint16 smallFingerArea:8;
  uint16 landingGlovedFinger:7; // coordinate this with the number of frames a gloved finger landing event lasts and classifierState_t
  uint16 hoveringFinger:1;
  uint16 glovedFinger:1;
  uint16 saturatedFinger:1;
  uint16 formerSaturatedFinger:1;
  uint16 landingSaturatedFinger:1;
  uint16 smallFinger:1;
  uint16 landingSmallFinger:1;
  uint16 stylus:1;
  uint16 eraser:1;
  uint16 wideSmallFinger:1;
  uint16 negativeFinger:1;
  uint16 stableFinger:1;
  uint16 stableSmallObject:1;
  uint16 palm:1;
  uint16 absAbsent:1;
  uint16 cdmArtifact:1;
#if CONFIG_HAS_GLOVE_SUSTAINER
  int16 obj_normalFingerThreshold_LSB;
#endif
} classifierResults_t;

typedef struct
{
  int16 *deltaImage;
  int16 *deltaXProfile;
  int16 *deltaYProfile;
} deltaData_t;

// - local persistent variables -

static uint16 normalFingerThreshold_LSB;
static uint16 smallFingerThreshold_LSB;
#if CONFIG_HAS_GLOVE_SUSTAINER
static struct GS_t GS;
#endif
#if CONFIG_HAS_GLOVE_STABLE_FRAMES
static struct GSF_t GSF;
#endif
static uint16 smallFingerBorderSize_px;
static uint16 smallFingerMaxSize_px;
static uint16 negativeFingerThreshold_LSB;
static uint16 palmThreshold_LSB;
static uint16 palmArea_px;
static uint8p8 negFingerLGMThreshold;
static int16 absXObjectThreshold_LSB;
static int16 absYObjectThreshold_LSB;
#if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
static int16 absXObjectThreshold_LSB_glove;
static int16 absYObjectThreshold_LSB_glove;
#endif
static uint0p16 stabilityThreshold_pct;
static uint16 glovedFingerThreshold_LSB;
static uint16 glovedFingerLanding_frames;
static uint0p16 avePeakRatio_pct;
static uint0p16 cdmArtifactAmplitude_pct;
#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
  static smallObjectDetectorConfig_t smallObjectDetectorConfig;
#endif
static smallObjectFeatures_t smallObjectFeatures;
static uint16 fingerLandingMaxFrames;
static uint8p8 landingFingerMinDeltaZ;
static uint16 smallFingerLandingMaxFrames;
static uint8p8 landingSmallFingerMinDeltaZ;
static uint16 maxAbsAbsent;

static uint16 eraserStuckStylusReport;
static uint16 stylusStuckEraserReport;
static uint16 liftingStuckReport;
static uint16 palmStuckReport;

#define STUCK_REPORT_CNT 10

static classifierState_t classifierState[MAX_OBJECTS];

#if CONFIG_IFP_ALGM_FITCURVE_ENABLE
//To collect the related data for LGM
static uint16 collectLGMDataEnable = 0;  //Enable it via RAM Backdoor or $F51 to collect LGM data to fit curve
#endif
// - internal function declarations -
static void computePosProd(uint16 rxCount, uint16 txCount, pixelIndex_t peak, int16 *deltaImage, uint32 *posProd);

static void computeSpatialSum(uint16 rxCount, uint16 txCount, pixelIndex_t peak, int16 *deltaImage, int16 *spatialSumVal, uint16 *numPxs);

static void classifierTests(sensorParams_t *sensorParams,
                            deltaData_t deltaData,
                            clumpInfo_t *clump,
                            uint16 *labelImage,
                            pixelIndex_t *listImage,
                            classifierState_t *state,
                            trackedObject_t *track,
                            classifierResults_t *results);

static void classifierTransitionMatrix(classifierResults_t *results,
                                       classifierState_t *state);

static void classifierClassification(classifierState_t *state,
                                     classification_t *classification);

static void classifierReclassifyUnknown(clumpInfo_t *clump,
                                     classifierState_t *state,
                                     classifierResults_t *results,
                                     classification_t *classification);

static uint16 findTrackIndex(trackedObject_t *trackedObjects, uint16 clumpId, uint16 blobId);

// - internal function definitions -

#if CONFIG_HAS_OBJECT_THRESHOLD_SPOILER
static struct {
  uint16 SpoilIt    : 1;
} Spoiler;

static inline void checkSpoiler(sensorParams_t* sensorParams, int16 *deltaXProfile, int16 *deltaYProfile)
{
  Spoiler.SpoilIt = 0;
  if (sensorParams->Spoiler.Enable)
  {
    if (sensorParams->LGMDetector.LGM)
    {
      if (deltaYProfile && sensorParams->Spoiler.Sufficient.HybridTx)
      {
        uint16 row;
        int16 *delta = deltaYProfile + 1;
        for (row = sensorParams->txCount - 2; row; row--)
        {
          if (sensorParams->Spoiler.Sufficient.HybridTx <= *delta)
          {
            Spoiler.SpoilIt = 1;
            break;
          }
          delta++;
        }
      }
      if (!Spoiler.SpoilIt && deltaXProfile && sensorParams->Spoiler.Sufficient.HybridRx)
      {
        uint16 col;
        int16 *delta = deltaXProfile + 1;
        for (col = sensorParams->rxCount - 2; col; col--)
        {
          if (sensorParams->Spoiler.Sufficient.HybridRx <= *delta)
          {
            Spoiler.SpoilIt = 1;
            break;
          }
          delta++;
        }
      }
    }
  }
}
#endif

/* -----------------------------------------------------------------
Name: computePosProd
Purpose: Returns the product of (rx sum of positive deltas) * (tx sum of positive deltas)
Inputs: sensor params, rx of interest, tx of interest, delta image
Outputs: positive sum, negative sum
Effects: None
Notes: Internal to this file only.
------------------------------------------------------------------ */
static void computePosProd(uint16 rxCount, uint16 txCount, pixelIndex_t peak, int16 *deltaImage, uint32 *posProd)
{
  uint16 rx = peak.col;
  uint16 tx = peak.row;
  uint16 i = rxCount;
  uint16 rxSum = 0;
  uint16 txSum = 0;
  int16 *dPtr;

  dPtr = deltaImage + (MAX_RX + 1) * tx;
  for (i = 0; i < rxCount; i++)
  {
    int16 delta = *dPtr++;
    rxSum += (delta >= 0) ? (uint16) delta : 0u;
  }
  dPtr = deltaImage + rx;
  for (i = 0; i < txCount; i++)
  {
    int16 delta = *dPtr;
    txSum += (delta >= 0) ? (uint16) delta : 0u;
    dPtr += MAX_RX + 1;
  }
  *posProd = rxSum * (uint32) txSum;
}

/* -----------------------------------------------------------------
Name: findTrackIndex
Purpose: Returns the index of the trackedObject matching clumpId and blobId
Inputs: tracked objects, clumpId, blobId
Outputs: index of tracked object
Effects: None
Notes: Internal to this file only. Returns MAX_OBJECTS if track not found.
------------------------------------------------------------------ */
uint16 findTrackIndex(trackedObject_t *trackedObjects, uint16 clumpId, uint16 blobId)
{
  uint16 trackInd;
  trackedObject_t *track;
  for (trackInd = 0, track = &trackedObjects[0]; trackInd < MAX_OBJECTS; trackInd++, track++)
  {
    if ((track->clumpId == clumpId) && (track->blobId == blobId))
    {
      break;
    }
  }
  return trackInd;
}

/* -----------------------------------------------------------------
Name: computeSpatialSum
Purpose: Returns the sum of a 3x3 set pf delta pixels centered at the
peak location. Takes into account edge and corner effects.
Inputs: sensor params, rx of interest, tx of interest, delta image
Outputs: spatial sum, pixels included in sum
Effects: None
Notes: Internal to this file only.
------------------------------------------------------------------ */
static void computeSpatialSum(uint16 rxCount, uint16 txCount, pixelIndex_t peak, int16 *deltaImage, int16 *spatialSumVal, uint16 *numPxs)
{
  uint16 rx = peak.col;
  uint16 tx = peak.row;
  uint16 i;
  int16 *dPtr;
  uint16 intRx = (rx > 1 && rx < rxCount);
  uint16 intTx = (tx > 1 && tx < txCount);

  *spatialSumVal = 0;

  dPtr = deltaImage + rx  - 1 + (MAX_RX + 1) * (tx - 1);
  for (i = 0; i < 3; i++)
  {
    *spatialSumVal += *(dPtr++);
  }

  dPtr = deltaImage + rx  - 1 + (MAX_RX + 1) * tx;
  for (i = 0; i < 3; i++)
  {
    *spatialSumVal += *(dPtr++);
  }

  dPtr = deltaImage + rx  - 1 + (MAX_RX + 1) * (tx + 1);
  for (i = 0; i < 3; i++)
  {
    *spatialSumVal += *(dPtr++);
  }

  *numPxs = (2 + intRx)*(2 + intTx);
}

/* -----------------------------------------------------------------
Name: classifierTests
Purpose: Performs tests of the data to determine classification
Inputs: sensor params, stucture of data deltas, clump structure,
list image, state stucture, and results structure
Outputs: results structure
Effects: sets the fields of results structure according to the
tests performed
Notes: Internal to this file only.
------------------------------------------------------------------ */
static void classifierTests(sensorParams_t *sensorParams,
                            deltaData_t deltaData,
                            clumpInfo_t *clump,
                            uint16 *labelImage,
                            pixelIndex_t *listImage,
                            classifierState_t *state,
                            trackedObject_t *track,
                            classifierResults_t *results)
{
  uint16 obj_normalFingerThreshold_LSB;
  uint16 obj_smallFingerThreshold_LSB;
  uint16 obj_smallFingerBorderSize_px;
  uint16 obj_smallFingerMaxSize_px;
  int16  obj_negativeFingerThreshold_LSB;
  uint16 obj_palmArea_px;
  uint16 obj_absXObjectThreshold_LSB, obj_absYObjectThreshold_LSB;
  uint0p16 obj_stabilityThreshold_pct;
  uint16 obj_palmThreshold_LSB;
  pixelIndex_t peak;
  int16 peakVal;
  int16 i;
  int16 *deltaImage;
  int16 noiseFloorVal;
#if CONFIG_IFP_CLOSEDCOVER
  uint16 coverEnable ATTR_UNUSED = 0;
  uint0p16 coverThresholdldPct ATTR_UNUSED = 0;
#endif
  // compute features for this clump
#if CONFIG_HAS_ADAPTIVE_LGM
  obj_normalFingerThreshold_LSB = ((uint32)normalFingerThreshold_LSB*sensorParams->cSat_LSB) >> 16;
  obj_smallFingerThreshold_LSB = ((uint32)smallFingerThreshold_LSB*sensorParams->cSat_LSB) >> 16;
  obj_negativeFingerThreshold_LSB = ((uint32)negativeFingerThreshold_LSB*sensorParams->cSat_LSB) >> 16;
  obj_palmThreshold_LSB = ((uint32)palmThreshold_LSB*sensorParams->cSat_LSB) >> 16;
#else
  obj_normalFingerThreshold_LSB = normalFingerThreshold_LSB;
  obj_smallFingerThreshold_LSB = smallFingerThreshold_LSB;
  obj_negativeFingerThreshold_LSB = negativeFingerThreshold_LSB;
  obj_palmThreshold_LSB = palmThreshold_LSB;
#endif

#if CONFIG_HAS_GLOVE_SUSTAINER
  if (sensorParams->GloveNF.OnlyGlove)
  {
    if (GS.FingerAmpThreshold)
    {
      obj_normalFingerThreshold_LSB = GS.FingerAmpThreshold;
    }
    if (GS.SmallFingerAmpThreshold)
    {
      obj_smallFingerThreshold_LSB = GS.SmallFingerAmpThreshold;
    }
  }
#endif

  obj_smallFingerBorderSize_px = smallFingerBorderSize_px;
  obj_smallFingerMaxSize_px = smallFingerMaxSize_px;
  obj_palmArea_px = palmArea_px;
  obj_absXObjectThreshold_LSB = absXObjectThreshold_LSB;
  obj_absYObjectThreshold_LSB = absYObjectThreshold_LSB;
#if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
  uint16 obj_absXObjectThreshold_LSB_glove = absXObjectThreshold_LSB_glove;
  uint16 obj_absYObjectThreshold_LSB_glove = absYObjectThreshold_LSB_glove;
#endif
  obj_stabilityThreshold_pct = stabilityThreshold_pct;

  deltaImage = deltaData.deltaImage;
#if CONFIG_IFP_CLOSEDCOVER
    coverEnable = getClosedCoverStatus();
    if(coverEnable)
    {
      // change fingerthreshold for small window on cover
      coverThresholdldPct = getClosedCoverThresholdPct();
      obj_normalFingerThreshold_LSB = ((uint32)obj_normalFingerThreshold_LSB * coverThresholdldPct) >> 16;;
    }
#endif
  switch(state->objClass)
  {
    case class_saturatedFinger:
    case class_landingSaturatedFinger:
      obj_normalFingerThreshold_LSB /= 2;
      break;
    case class_smallFinger:
    case class_landingSmallFinger:
    case class_eraser:
    case class_stylus:
      obj_smallFingerThreshold_LSB /= 2;
      obj_smallFingerBorderSize_px = 0;
      obj_smallFingerMaxSize_px = 0xFFFF;
      break;
    case class_liftingSmallFinger:
      obj_smallFingerBorderSize_px = 0;
      break;
    case class_negativeFinger:
      obj_negativeFingerThreshold_LSB = 0;
      break;
    case class_palm:
      // Adjust the threshold to instead of set obj_palmArea_px as 0 when last state was palm.
      // Set the palm low threshold is (noiseFloor_LSB + 1) to avoid the palm threshold is too low after adjusting.
      //obj_palmArea_px = 0;
      obj_palmThreshold_LSB /= 2;
      noiseFloorVal = sensorParams->noiseFloor_LSB;
      obj_palmThreshold_LSB = (obj_palmThreshold_LSB > (uint16)noiseFloorVal) ? obj_palmThreshold_LSB : (uint16)(noiseFloorVal + 1);
      break;
    case class_glovedFinger:
      obj_stabilityThreshold_pct *= 2;
      break;
    case class_unknown:
    default:
      // for all other cases, no hysteresis
      break;
  }
  if (state->objClass == class_saturatedFinger ||
      state->objClass == class_landingSaturatedFinger ||
      state->objClass == class_liftingSaturatedFinger ||
      state->objClass == class_liftingWhileLandingSaturatedFinger ||
      state->objClass == class_smallFinger ||
      state->objClass == class_landingSmallFinger ||
      state->objClass == class_glovedFinger ||
      state->objClass == class_palm)
  {
    obj_absXObjectThreshold_LSB /= 2;
    obj_absYObjectThreshold_LSB /= 2;
  #if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
    obj_absXObjectThreshold_LSB_glove /= 2;
    obj_absYObjectThreshold_LSB_glove /= 2;
  #endif
  }

  results->landingGlovedFinger = state->landingGlovedFinger;
  results->formerSaturatedFinger = state->formerSaturatedFinger;

  peak = clump->peakLocation;
  peakVal = deltaImage[peak.row * (MAX_RX + 1) + peak.col];

  {
    //palm detection
    uint16 palmAreaBlobAccum[MAX_OBJECTS];
    uint16 palmAreaAccum = 0;
    memset16(palmAreaBlobAccum, 0, MAX_OBJECTS);
    // Count the valid pixels
  if (peakVal > 0)
  {
    float pixelFraction = 0;
    pixelIndex_t curPixel;
    curPixel = clump->firstPixel;
    while(curPixel.row != 0) {
      uint16 idx = curPixel.row * (MAX_RX + 1) + curPixel.col;
      int16 val = deltaImage[idx];
      if (val >= (int16) obj_palmThreshold_LSB)
      {
        palmAreaBlobAccum[(labelImage[idx] >> 8) & 0xF]++;
        if (clump->suspectMoisture)
        {
          pixelFraction += (float)val/peakVal;
        }
        else
        {
          pixelFraction += 1;
        }
      }
      curPixel = listImage[idx];
    }
    palmAreaAccum = (uint16)pixelFraction;
  }
    // check the palm area
    if (palmAreaAccum > obj_palmArea_px)
    {
      uint16 obj_palmArea_px_threshold = 0;
    #if CONFIG_HAS_CUSTOM_PALM_DETECTION
      if (sensorParams->customPalmDetection.Enable)
      {
        obj_palmArea_px_threshold = obj_palmArea_px * (clump->splitCount + 1);
      }
      else
    #endif
      {
        obj_palmArea_px_threshold = (clump->splitCount > 0) ? (obj_palmArea_px + (obj_palmArea_px >> 1)) : obj_palmArea_px;
      }
      if (palmAreaAccum > obj_palmArea_px_threshold)
      {
        results->palm = 1;
      }
      else
      {
        for (i = 0; i < MAX_OBJECTS; i++)
        {
          if (palmAreaBlobAccum[i] > obj_palmArea_px)
  {
    results->palm = 1;
            break;
          }
        }
      }
    }
  }

  //saturated finger
  if (peakVal >= (int16) obj_normalFingerThreshold_LSB)
  {
    int8p8 landingSpeedThreshold = 256; //it should be safely larger than the finger scale of the land-lift jitter filter
    uint16 fastMovingLanding = (track->speedx > landingSpeedThreshold)  || (track->speedy > landingSpeedThreshold) ||
                        (track->speedx < -landingSpeedThreshold) || (track->speedy < -landingSpeedThreshold);
    if (state->landingObjectFrameCount > fingerLandingMaxFrames || ((int32)track->zerothMoment - state->oldZ) < landingFingerMinDeltaZ || fastMovingLanding)
    {
      results->saturatedFinger = 1;
    }
    else
    {
      results->landingSaturatedFinger = 1;
    }
  }
  else
  {
    results->formerSaturatedFinger = 0;
  };

  if (peakVal <= -obj_negativeFingerThreshold_LSB)
  {
    /* Negative fingers can be caused by real fingers on the same tx and
       rx. Don't flag a bad baseline for those. */
    uint32 posProd;  // (sum along tx) * (sum along rx)
    computePosProd(sensorParams->rxCount, sensorParams->txCount, clump->peakLocation, deltaImage, &posProd);
    results->negativeFinger = (uint32) -peakVal > ((uint32) negFingerLGMThreshold * posProd) >> 11;  /* negFingerLGMThreshold has gain of 2^-3 and is 8p8, so shift 2^11 */
  }

#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
  {
    if (peakVal >= (int16) obj_smallFingerThreshold_LSB && clump->splitCount == 0)
    {
      pixelIndex_t curPixel;
      uint16 minRow = 0xFFFF;
      uint16 maxRow = 0;
      uint16 minCol = 0xFFFF;
      uint16 maxCol = 0;
      int16 smallPixelThreshold;

      smallPixelThreshold = peakVal/2;

      curPixel = clump->firstPixel;
      while(curPixel.row != 0) {
        int16 val;
        uint16 idx;

        idx = curPixel.row*(MAX_RX+1)+curPixel.col;
        val = deltaImage[idx];
        if (val > smallPixelThreshold)
        {
          if (curPixel.row > maxRow)
          {
            maxRow = curPixel.row;
          }
          if (curPixel.row < minRow)
          {
            minRow = curPixel.row;
          }
          if (curPixel.col > maxCol)
          {
            maxCol = curPixel.col;
          }
          if (curPixel.col < minCol)
          {
            minCol = curPixel.col;
          }
        }
        curPixel = listImage[idx];
      }

      if ((maxRow - minRow < obj_smallFingerMaxSize_px) &&
          (maxCol - minCol < obj_smallFingerMaxSize_px) &&
          (peak.row > obj_smallFingerBorderSize_px) &&
          (peak.row < sensorParams->txCount + 1 - obj_smallFingerBorderSize_px) &&
          (peak.col > obj_smallFingerBorderSize_px) &&
          (peak.col < sensorParams->rxCount + 1 - obj_smallFingerBorderSize_px))
      {
        int16 hystFlag;
        smallObjectClass_t smallObjectClass, lastClass;
        hystFlag = ((state->objClass == class_smallFinger) || (state->objClass == class_stylus) || (state->objClass == class_eraser));
        smallObjectFeatures.area = state->smallFingerArea;

        if (state->objClass == class_smallFinger)
          lastClass = smallObjectClass_touchingSmallObject;
        else if (state->objClass == class_stylus)
          lastClass = smallObjectClass_stylus;
        else if (state->objClass == class_eraser)
          lastClass = smallObjectClass_eraser;
        else
          lastClass = smallObjectClass_none;

        smallObjectClass = (smallObjectClass_t) smallObjectDetector_detect(
          sensorParams, deltaImage, clump->peakLocation,
          &smallObjectDetectorConfig, hystFlag, &smallObjectFeatures,
          (uint16) lastClass);

        results->smallFingerArea = smallObjectFeatures.area;
        if (smallObjectClass == smallObjectClass_touchingSmallObject)
        {
          results->smallFinger = 1;
        }
        else if (smallObjectClass == smallObjectClass_wideSmallObject)
        {
          results->wideSmallFinger = 1;
        }
        else if (smallObjectClass == smallObjectClass_stylus)
        {
          results->stylus = 1;
        }
        else if (smallObjectClass == smallObjectClass_eraser)
        {
          results->eraser = 1;
        }
      }
    }

    if (results->landingSmallFinger || results->smallFinger || results->stylus || results->eraser)
    {
      uint8p8 relAmp = smallObjectFeatures.relativeAmplitude;
      uint8p8 lastAmp = state->lastRelativeAmplitude;
      uint8p8 relAmpChange, num, den;
      if (relAmp > lastAmp)
      {
        num = relAmp - lastAmp;
        den = relAmp;
      }
      else
      {
        num = lastAmp - relAmp;
        den = lastAmp;
      }
      if(den!=0){
        relAmpChange = (uint8p8) (((uint32) num << 8)/den);
      }else{
        relAmpChange = 0;
      }
      results->stableSmallObject = (relAmpChange < 38);
      state->lastRelativeAmplitude = relAmp;
    }

    if ((results->landingSmallFinger == 0) && (results->smallFinger == 0) && (results->stylus == 0) && (results->eraser == 0))
    {
      state->smallFingerFrameCount = 0;
    }
    else
    {
      if (state->smallFingerFrameCount < MAX_SMALL_FINGER_FRAME_COUNT)
      {
        state->smallFingerFrameCount++;
      }
    }

    {
      //small finger landing
      int8p8 landingSpeedThresholdSmallObject = 256; //it should be safely larger than the finger scale of the land-lift jitter filter
      uint16 fastMovingLandingSmallObject = (track->speedx > landingSpeedThresholdSmallObject)  || (track->speedy > landingSpeedThresholdSmallObject) ||
                            (track->speedx < -landingSpeedThresholdSmallObject) || (track->speedy < -landingSpeedThresholdSmallObject);
      if (results->smallFinger
          && state->landingObjectFrameCount <= smallFingerLandingMaxFrames
          && ((int32)track->zerothMoment - state->oldZ) >= landingSmallFingerMinDeltaZ
          && !fastMovingLandingSmallObject)
      {
        results->smallFinger = 0;
        results->landingSmallFinger = 1;
      }
    }
  }
#endif

  results->absAbsent = 0;
#if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
  uint16 absAbsent_glove = 0;
#endif
  if (CONFIG_HAS_HYBRID)
  {
    int16 *deltaXProfile = deltaData.deltaXProfile;
    int16 *deltaYProfile = deltaData.deltaYProfile;

    if (MAX_ABS_RX > 1 && NULL != deltaXProfile && obj_absXObjectThreshold_LSB > 0)
    {
      uint16 c = peak.col - 1; // no zero-padding
      if ((deltaXProfile[c] < (int16) obj_absXObjectThreshold_LSB) &&
          (c == 0 || deltaXProfile[c-1] < absXObjectThreshold_LSB) &&
          (c == sensorParams->rxCount - 1 || deltaXProfile[c+1] < absXObjectThreshold_LSB)
        #if CONFIG_HAS_OBJECT_THRESHOLD_SPOILER
          && !(Spoiler.SpoilIt
            && sensorParams->Spoiler.HybridRx
            && (
                 (sensorParams->Spoiler.EdgeRx && (peak.col == 1 || peak.col == sensorParams->rxCount))
              || (sensorParams->Spoiler.EdgeTx && (peak.row == 1 || peak.row == sensorParams->txCount))
            )
          )
        #endif
        )
      {
        results->absAbsent = 1;
      }
    }
    if (!results->absAbsent && MAX_ABS_TX > 1 && NULL != deltaYProfile && obj_absYObjectThreshold_LSB > 0)
    {
      uint16 r = peak.row - 1; // no zero-padding
      if ((deltaYProfile[r] < (int16) obj_absYObjectThreshold_LSB) &&
          (r == 0 || deltaYProfile[r-1] < absYObjectThreshold_LSB) &&
          (r == sensorParams->txCount - 1 || deltaYProfile[r+1] < absYObjectThreshold_LSB))
      {
        results->absAbsent = 1;
      }
    }

  #if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
    if (MAX_ABS_RX > 1 && NULL != deltaXProfile && obj_absXObjectThreshold_LSB_glove > 0)
    {
      uint16 c = peak.col - 1; // no zero-padding
      if ((deltaXProfile[c] < (int16) obj_absXObjectThreshold_LSB_glove) &&
          (c == 0 || deltaXProfile[c-1] < absXObjectThreshold_LSB_glove) &&
          (c == sensorParams->rxCount - 1 || deltaXProfile[c+1] < absXObjectThreshold_LSB_glove)
        #if CONFIG_HAS_OBJECT_THRESHOLD_SPOILER
          && !(Spoiler.SpoilIt
            && sensorParams->Spoiler.HybridRx
            && (
                 (sensorParams->Spoiler.EdgeRx && (peak.col == 1 || peak.col == sensorParams->rxCount))
              || (sensorParams->Spoiler.EdgeTx && (peak.row == 1 || peak.row == sensorParams->txCount))
            )
          )
        #endif
        )
      {
        absAbsent_glove = 1;
      }
    }
    if (!absAbsent_glove && MAX_ABS_TX > 1 && NULL != deltaYProfile && obj_absYObjectThreshold_LSB_glove > 0)
    {
      uint16 r = peak.row - 1; // no zero-padding
      if ((deltaYProfile[r] < (int16) obj_absYObjectThreshold_LSB_glove) &&
          (r == 0 || deltaYProfile[r-1] < absYObjectThreshold_LSB_glove) &&
          (r == sensorParams->txCount - 1 || deltaYProfile[r+1] < absYObjectThreshold_LSB_glove))
      {
        absAbsent_glove = 1;
      }
    }
  #endif

    // abs consistency passed (when it could have failed) ==> suppress negative finger
    if (((MAX_ABS_RX > 1 && NULL != deltaXProfile && obj_absXObjectThreshold_LSB > 0) ||
         (MAX_ABS_TX > 1 && NULL != deltaYProfile && obj_absYObjectThreshold_LSB > 0)) &&
        !results->absAbsent
        #if CONFIG_HAS_OBJECT_THRESHOLD_SPOILER
          && !(Spoiler.SpoilIt
            && sensorParams->Spoiler.HybridTx
            && (
                 (sensorParams->Spoiler.EdgeRx && (peak.col == 1 || peak.col == sensorParams->rxCount))
              || (sensorParams->Spoiler.EdgeTx && (peak.row == 1 || peak.row == sensorParams->txCount))
            )
          )
        #endif
        )
    {
        results->negativeFinger = 0;
    }
  }

  {
    if (peak.row > 0)
    {
      int16 pkAmp = (peakVal < 0) ? -peakVal : peakVal;
      if (pkAmp > 0)
      {
        uint16 txCount = sensorParams->txCount;
        uint16 row;
        int16 colPk = 0;
        int16 *deltaPtr = &deltaImage[MAX_RX + peak.col];  // start at peak - 1
        for (row = 0; row <= txCount; row++, deltaPtr += MAX_RX - 2)
        {
            int16 val = *deltaPtr++;
            if (val > colPk) colPk = val;

            val = *deltaPtr++;
            if (val > colPk) colPk = val;

            val = *deltaPtr++;
            if (val > colPk) colPk = val;
        }
        results->cdmArtifact = pkAmp <= (int16) (((uint32)colPk*cdmArtifactAmplitude_pct) >> 16);
      }
    }
  }

  #if CONFIG_HAS_SPLIT_GLOVE_CLUMPS
  if (glovedFingerThreshold_LSB && clump->splitCount <= (sensorParams->tolerateSplitClumps ? 1 : 0) && state->prevPeakVal > 0)
  #else
  if (glovedFingerThreshold_LSB && clump->splitCount == 0 && state->prevPeakVal > 0)
  #endif
      {
      #if CONFIG_HAS_GLOVE_STABLE_FRAMES
        if (GSF.NumFrames)
        {
          uint16 i;
          int16 *peak = &state->stableFrames.peaks[0];
          int16 min, max;
          min = max = peakVal;
          for (i = 0; min /* 0 if not filled yet */ && i <= GSF.NumFrames; i++, peak++)
          {
            if (*peak < min)
            {
              min = *peak;
            }
            if (max < *peak)
            {
              max = *peak;
            }
          }
          if (min != 0 && max - min <= (int16)(((uint32) obj_stabilityThreshold_pct * max) >> 16))
          {
            results->stableFinger = 1;
          }
        }
        else
      #endif
        {
          int16 absPeakValChange = state->prevPeakVal - peakVal;
          absPeakValChange = (absPeakValChange < 0) ? (-absPeakValChange) : (absPeakValChange);
          if (absPeakValChange <= (int16) (((uint32) obj_stabilityThreshold_pct*state->prevPeakVal) >> 16))
          {
              results->stableFinger = 1;
          }
        }
      }

  #if CONFIG_HAS_SPLIT_GLOVE_CLUMPS
  if (glovedFingerThreshold_LSB && clump->splitCount <= (sensorParams->tolerateSplitClumps ? 1 : 0) && state->prevPeakVal == 0)
  #else
  if (glovedFingerThreshold_LSB && clump->splitCount == 0 && state->prevPeakVal == 0)
  #endif
  {
    results->landingGlovedFinger = glovedFingerLanding_frames + 1;  // (re)start countdown
      }

  if (glovedFingerThreshold_LSB
    #if CONFIG_HAS_SPLIT_GLOVE_CLUMPS
      && clump->splitCount <= (sensorParams->tolerateSplitClumps ? 1 : 0)
    #else
      && clump->splitCount == 0
    #endif
      && peakVal >= (int16) glovedFingerThreshold_LSB &&
          peakVal < (int16) obj_normalFingerThreshold_LSB &&
        #if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
          !absAbsent_glove
        #else
          !results->absAbsent
        #endif
          )
      {
        int16 spatialSumVal = 0;
        uint16 numPxs = 0;
        computeSpatialSum(sensorParams->rxCount, sensorParams->txCount, clump->peakLocation, deltaImage, &spatialSumVal, &numPxs);
        if ((int32) spatialSumVal > (int32)((((uint32) peakVal*avePeakRatio_pct) >> 16) * numPxs))
        {
          results->hoveringFinger = 1;
        }
      }

  if (results->hoveringFinger && results->stableFinger &&
      (state->objClass == class_glovedFinger ||
       ((results->landingGlovedFinger > 0) && !state->formerGlovedFinger)))
  {
        results->glovedFinger = 1;
      #if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
        results->absAbsent = 0;
      #endif
    }

  results->peakVal = peakVal;
#if CONFIG_HAS_GLOVE_SUSTAINER
  results->obj_normalFingerThreshold_LSB = obj_normalFingerThreshold_LSB;
#endif
}

/* -----------------------------------------------------------------
Name: classifierTransitionMatrix
Purpose: Determines the classification for the current object in the
current frame
Inputs: zeroed results structure, state structure
Outputs: state structure
Effects: state structure's objClass field is set and frameCount
field possibly modified
Notes: Internal to this file only.
------------------------------------------------------------------ */
static void classifierTransitionMatrix(classifierResults_t *results,
                                       classifierState_t *state)
{
  objectClass_t nextClass;
  uint16 clrStuck = 1;

  switch(state->objClass)
  {
    case class_saturatedFinger:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_saturatedFinger; //intentional: once landed you need to lift to reenter landing state
      }
      else
      {
        nextClass = class_liftingSaturatedFinger;
      }
      break;
    case class_landingSaturatedFinger:
      if (results->absAbsent)
      {
        nextClass = class_liftingWhileLandingSaturatedFinger; //intentional: it will trigger a recovery
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_landingSaturatedFinger;
      }
      else
      {
        nextClass = class_liftingWhileLandingSaturatedFinger; //it will trigger a recovery
      }
      break;
    case class_liftingWhileLandingSaturatedFinger: // intentional fall-through (uncomment to further specialize)
      //if (results->absAbsent)
      //{
      //  nextClass = class_consistencyError;
      //}
      //else if (results->palm == 1)
      //{
      //  nextClass = class_palm;
      //}
      //else if (results->saturatedFinger == 1)
      //{
      //  nextClass = class_saturatedFinger;
      //}
      //else if (results->landingSaturatedFinger == 1)
      //{
      //  nextClass = class_landingSaturatedFinger;
      //}
      //else
      //{
      //  nextClass = class_liftingSaturatedFinger;
      //}
      //break;
    case class_liftingSaturatedFinger:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_landingSaturatedFinger;
      }
      else if (results->hoveringFinger == 1)
      {
        nextClass = class_hoveringFinger;
      }
      else
      {
        nextClass = class_liftingSaturatedFinger;
      }
      break;
    case class_smallFinger:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->smallFinger == 1)
      {
        nextClass = class_smallFinger;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_saturatedFinger; // intentional: finger has been reported already, cannot enter landing state again, keep reporting
      }
      else if (results->landingSmallFinger == 1)
      {
        nextClass = class_smallFinger; // intentional: finger has been reported already, cannot enter landing state again, keep reporting
      }
      else
      {
        if(liftingStuckReport++ < STUCK_REPORT_CNT)
        {
          nextClass = class_smallFinger;
          clrStuck = 0;
        }
        else
          nextClass = class_liftingSmallFinger;
      }
      break;
    case class_landingSmallFinger:
      if (results->absAbsent)
      {
        nextClass = class_liftingWhileLandingSmallFinger; //it will trigger a recovery
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->smallFinger == 1)
      {
        nextClass = class_smallFinger;
      }
      else if (results->landingSmallFinger == 1)
      {
        nextClass = class_landingSmallFinger;
      }
      else if (results->eraser == 1 && results->stableSmallObject)
      {
        nextClass = class_eraser;
      }
      else if (results->stylus == 1 && results->stableSmallObject)
      {
        // the eraser use to be detected as stylus for the first 1-2 frames, so add a buffer here to prevent incorrect reporting
        if(eraserStuckStylusReport++ < STUCK_REPORT_CNT)
        {
          nextClass = class_landingSmallFinger;
          clrStuck = 0;
        }
        else
          nextClass = class_stylus;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_landingSaturatedFinger;
      }
      else
      {
        nextClass = class_liftingWhileLandingSmallFinger; //it will trigger a recovery
      }
      if(clrStuck && eraserStuckStylusReport)
        eraserStuckStylusReport = 0;
      break;
    case class_wideSmallFinger:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->negativeFinger == 1)
      {
        nextClass = class_negativeFinger;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_landingSaturatedFinger;
      }
      else if (results->smallFinger == 1)
      {
        // increase this value for artifact filtering on land:
        if (state->smallFingerFrameCount > 0)
        {
          nextClass = class_smallFinger;
        }
        else
        {
          nextClass = class_wideSmallFinger;
        }
      }
      else if (results->landingSmallFinger == 1)
      {
        // increase this value for artifact filtering on land:
        if (state->smallFingerFrameCount > 0)
        {
          nextClass = class_landingSmallFinger;
        }
        else
        {
          nextClass = class_wideSmallFinger;
        }
      }
      else if (results->wideSmallFinger == 1)
      {
        nextClass = class_wideSmallFinger;
      }
      else if (results->hoveringFinger == 1)
      {
        nextClass = class_hoveringFinger;
      }
      else
      {
        nextClass = class_unknown;
      }
      break;
    case class_liftingSmallFinger: //the reason to avoid going to landing from lifting is to avoid amplifying gaps in reporting when pen drops
                                   //if pen is stable enough one can leave the following code commented as an intentional fall-through
      //if (results->absAbsent)
      //{
      //  nextClass = class_consistencyError;
      //}
      //else if (results->palm == 1)
      //{
      //  nextClass = class_palm;
      //}
      //else if (results->smallFinger == 1 || results->landingSmallFinger == 1)
      //{
      //  nextClass = class_smallFinger;
      //}
      //else if (results->saturatedFinger == 1 || results->landingSaturatedFinger == 1)
      //{
      //  nextClass = class_saturatedFinger;
      //}
      //else
      //{
      //  nextClass = class_liftingSmallFinger;
      //}
      //break;
    case class_liftingWhileLandingSmallFinger:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->smallFinger == 1)
      {
        nextClass = class_smallFinger;
      }
      else if (results->landingSmallFinger == 1)
      {
        nextClass = class_landingSmallFinger;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_landingSaturatedFinger;
      }
      else if (results->eraser == 1)    // Eraser may be recognized as stylus when landing slowly
      {
        nextClass = class_eraser;
      }
      else if (results->stylus == 1)
      {
        nextClass = class_stylus;
      }
      else if (results->hoveringFinger == 1) // FWTDDI-1383
      {
        nextClass = class_hoveringFinger;
      }
      else
      {
        nextClass = class_liftingSmallFinger;
      }
      break;
    case class_stylus:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->saturatedFinger == 1) // Finger may be recognized as stylus when landing slowly
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->eraser == 1) // Eraser may be recognized as stylus when landing slowly
      {
        // the 2.5mm stylus sometimes may also be detected as eraser for 1-2 frames while acrossing the middle of the panel vertically,
        // so we add a buffer here to prevent incorrect reporting
        if(stylusStuckEraserReport++ < STUCK_REPORT_CNT)
        {
          nextClass = class_stylus;
          clrStuck = 0;
        }
        else
          nextClass = class_eraser;
      }
      else if (results->stylus == 1)
      {
        nextClass = class_stylus;
      }
      else if (results->smallFinger == 1) // when eraser is disabled, then eraser may be recognized as small Finger
      {
        // Noted, we have to add same workaround for smallFinger as Eraser because stylus may be enabled individually
        if(stylusStuckEraserReport++ < STUCK_REPORT_CNT)
        {
          nextClass = class_stylus;
          clrStuck = 0;
        }
        else
          nextClass = class_smallFinger;
      }
      else
      {
        if(liftingStuckReport++ < STUCK_REPORT_CNT)
        {
          nextClass = class_stylus;
          clrStuck = 0;
        }
        else
          nextClass = class_liftingStylus;
      }
      if(clrStuck && stylusStuckEraserReport)
        stylusStuckEraserReport = 0;
      break;
    case class_liftingStylus:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->stylus == 1)
      {
        nextClass = class_stylus;
      }
      else if (results->eraser == 1)
      {
        nextClass = class_eraser;
      }
      else
      {
        nextClass = class_liftingStylus;
      }
      break;
    case class_eraser:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->saturatedFinger == 1) // Finger may be recognized as stylus/eraser when landing slowly
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->eraser == 1)
      {
        nextClass = class_eraser;
      }
      else
      {
        if(liftingStuckReport++ < STUCK_REPORT_CNT)
        {
          nextClass = class_eraser;
          clrStuck = 0;
        }
        else
          nextClass = class_liftingEraser;
      }
      break;
    case class_liftingEraser:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->eraser == 1)
      {
        nextClass = class_eraser;
      }
      else
      {
        nextClass = class_liftingEraser;
      }
      break;
    case class_negativeFinger:
      if (results->negativeFinger)
      {
        nextClass = class_negativeFinger;
      }
      else
      {
        nextClass = class_unknown;
      }
      break;
    case class_consistencyError:
      nextClass = class_consistencyError;
      break;
    case class_hoveringFinger:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->negativeFinger == 1)
      {
        nextClass = class_negativeFinger;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_landingSaturatedFinger;
      }
      else if (results->eraser == 1 && results->stableSmallObject)
      {
        if (state->smallFingerFrameCount > 0)
        {
          nextClass = class_eraser;
        }
        else
        {
          nextClass = class_hoveringFinger;
        }
      }
      else if (results->stylus == 1 && results->stableSmallObject)
      {
        if (state->smallFingerFrameCount > 0)
        {
          nextClass = class_stylus;
        }
        else
        {
          nextClass = class_hoveringFinger;
        }
      }
      //else if (results->smallFinger == 1)
      //{
      //  nextClass = class_smallFinger;
      //}
      // else if (results->landingSmallFinger == 1)
      //{
      //  nextClass = class_landingSmallFinger;
      //}
      else if (results->glovedFinger == 1)
      {
        nextClass = class_glovedFinger;
      }
      else if (results->hoveringFinger == 1)
      {
        nextClass = class_hoveringFinger;
        state->formerGlovedFinger = 0;
      }
      else
      {
        if(liftingStuckReport++ < STUCK_REPORT_CNT)
        {
          nextClass = class_hoveringFinger;
          clrStuck = 0;
        }
        else
          nextClass = class_unknown;
      }
      break;
    case class_glovedFinger:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->negativeFinger == 1)
      {
        nextClass = class_negativeFinger;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_saturatedFinger; //intentional, the object has already been reported
      }
      else if (results->glovedFinger == 1)
      {
        nextClass = class_glovedFinger;
      }
      else if (results->hoveringFinger == 1)
      {
        nextClass = class_hoveringFinger;
      }
      else
      {
        if(liftingStuckReport++ < STUCK_REPORT_CNT)
        {
          nextClass = class_glovedFinger;
          clrStuck = 0;
        }
        else
          nextClass = class_unknown;
      }
      break;
    case class_palm:
      if (results->absAbsent)
      {
        if (state->absAbsentFrameCount >= maxAbsAbsent)
        {
          nextClass = class_consistencyError;
        }
        else
        {
          nextClass = state->objClass;
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->negativeFinger == 1)
      {
        nextClass = class_negativeFinger;
      }
      else
      {
        if (palmStuckReport++ < STUCK_REPORT_CNT)
        {
          nextClass = class_palm;
          clrStuck = 0;
        }
        else
        {
          nextClass = class_unknown;
        }
      }
      if (clrStuck && palmStuckReport)
        palmStuckReport = 0;
      break;
    case class_cdmArtifact:
    case class_none: // intentional fall-through
    case class_unknown:  // intentional fall-through
    default:             // intentional fall-through
      if (results->cdmArtifact)
      {
        nextClass = class_cdmArtifact;
      }
      else if (results->negativeFinger == 1)
      {
        nextClass = class_negativeFinger;
      }
      else if (results->absAbsent)
      {
        if (state->objClass == class_none)
        {
          nextClass = class_unknown; //don't trigger fast-relaxation because of motion artifacts
        }
        else
        {
          if (state->absAbsentFrameCount >= maxAbsAbsent)
          {
            nextClass = class_consistencyError;
          }
          else
          {
            nextClass = state->objClass;
          }
        }
      }
      else if (results->palm == 1)
      {
        nextClass = class_palm;
      }
      else if (results->negativeFinger == 1)
      {
        nextClass = class_negativeFinger;
      }
      else if (results->saturatedFinger == 1)
      {
        nextClass = class_saturatedFinger;
      }
      else if (results->landingSaturatedFinger == 1)
      {
        nextClass = class_landingSaturatedFinger;
      }
      else if (results->eraser == 1 && results->stableSmallObject)
      {
        nextClass = class_eraser;
      }
      else if (results->stylus == 1 && results->stableSmallObject)
      {
        nextClass = class_stylus;
      }
      else if (results->smallFinger == 1)
      {
        nextClass = class_smallFinger;
      }
      else if (results->landingSmallFinger == 1)
      {
        nextClass = class_landingSmallFinger;
      }
      else if (results->glovedFinger == 1)
      {
        nextClass = class_glovedFinger;
      }
      else if (results->hoveringFinger == 1)
      {
        nextClass = class_hoveringFinger;
      }
      else
      {
        nextClass = class_unknown;
      #if CONFIG_HAS_GLOVE_SUSTAINER
        if (state->objClass == class_glovedFinger)
        {
          if (GS.UseExtraFingerAmp && results->peakVal >= (GS.ExtraFingerAmpThreshold ?: (int16)(results->obj_normalFingerThreshold_LSB / 2)))
          {
            nextClass = (int16)class_saturatedFinger;
          }
          else if (GS.UseExtraGloveAmp && results->peakVal >= (GS.ExtraGloveAmpThreshold ?: (int16)glovedFingerThreshold_LSB))
          {
            nextClass = class_glovedFinger;
          }
        }
      #endif
      }
      break;
  }

  if(clrStuck && liftingStuckReport)
    liftingStuckReport = 0;

  state->objClass = nextClass;
}

/* -----------------------------------------------------------------
Name: classifierClassification
Purpose: Sets the appropriate fields within the classification
structure
Inputs: state structure, and classification structure
Outputs: classification structure
Effects: classification structure's touchType, touchFlag,
bufferTouchFlag and recoverTouchFlag fields are set
Notes: Internal to this file only.
------------------------------------------------------------------ */
static void classifierClassification(classifierState_t *state,
                                     classification_t *classification)
{
  touchType_t touchType;
  uint16 touchFlag;
  uint16 bufferTouchFlag = 0; //initialize
  uint16 recoverTouchFlag = 0; //initialize

  switch(state->objClass)
  {
    case class_unknown:
      touchType = touchType_none;
      touchFlag = 0;
      break;
    case class_saturatedFinger:
      touchFlag = 1;
      touchType = touchType_finger;
      break;
    case class_liftingSaturatedFinger:
      touchFlag = 0;
      touchType = touchType_finger;
      break;
    case class_landingSaturatedFinger:
      touchFlag = 1;
      bufferTouchFlag = 1;
      touchType = touchType_finger;
      break;
    case class_liftingWhileLandingSaturatedFinger:
      touchFlag = 1;
      recoverTouchFlag = 1;
      touchType = touchType_finger;
      break;
    case class_smallFinger:
      touchFlag = 1;
      touchType = touchType_smallObject;
      break;
    case class_landingSmallFinger:
      touchFlag = 1;
      touchType = touchType_smallObject;
      bufferTouchFlag = 1;
      break;
    case class_liftingSmallFinger:
      touchFlag = 0;
      touchType = touchType_smallObject;
      break;
    case class_stylus:
      touchFlag = 1;
      touchType = touchType_stylus;
      break;
    case class_liftingStylus:
      touchFlag = 0;
      touchType = touchType_stylus;
      break;
    case class_eraser:
      touchFlag = 1;
      touchType = touchType_eraser;
      break;
    case class_liftingEraser:
      touchFlag = 0;
      touchType = touchType_eraser;
      break;
    case class_liftingWhileLandingSmallFinger:
      touchFlag = 1;
      touchType = touchType_smallObject;
      recoverTouchFlag = 1;
      break;
    case class_wideSmallFinger: //intentional fall-through
    case class_hoveringFinger:         // intentional fall-through
      touchFlag = 0;
      touchType = touchType_finger;
      break;
    case class_negativeFinger: //intentional fall-through
    case class_consistencyError:
      touchFlag = 0;
      touchType = touchType_baselineError;
      break;
    case class_palm:
      touchFlag = 1;
      touchType = touchType_palm;
      break;
    case class_glovedFinger:
      if (state->frameCount > 0)
      {
        touchFlag = 1;
      }
      else
      {
        touchFlag = 0;
      }
      touchType = touchType_glove;
      break;
    case class_cdmArtifact: //intentional fall-through
    case class_none: // intentional fall-through
    default:             // intentional fall-through
      touchFlag = 0;
      touchType = touchType_none;
      break;
  }
  classification->touchType = touchType;
  classification->touchFlag = touchFlag;
  classification->bufferTouchFlag = bufferTouchFlag;
  classification->recoverTouchFlag = recoverTouchFlag;
  classification->newTouchFlag = (state->frameCount == 1);

}

//* -----------------------------------------------------------------
//Name: classifierReclassifyUnkown
//Purpose: Sets the appropriate fields within the classification
//structure for an unknown object
//Inputs: clump structure, state structure, results structure, and
//classification structure
//Outputs: classification structure
//Effects: classification structure's touchType and touchFlag fields
//are set, unknown reclassified as a non touching finger after a few frames
//Notes: Internal to this file only.
//------------------------------------------------------------------ */
static void classifierReclassifyUnknown(clumpInfo_t *clump,
                                     classifierState_t *state,
                                     classifierResults_t *results,
                                     classification_t *classification)
{
      if (state->objClass == class_unknown && state->frameCount > 10 && clump->peakCount > 0 && clump->polarity == clumpPolarity_positive && !(results->absAbsent))
      {
        classification->touchType = touchType_finger;
        classification->touchFlag = 0; //notice touchFlag = 0
        classification->recoverTouchFlag = 0;
        classification->bufferTouchFlag = 0;
      }

}

// - external functions -

void classifier_init(void)
{
  memset16(classifierState, 0, sizeof(classifierState) / sizeof(uint16));
  memset16(&smallObjectFeatures, 0, sizeof(smallObjectFeatures) / sizeof(uint16));
}

void classifier_reinit(void)
{
  classifier_init();
}

void classifier_configure(classifierConfig_t *config)
{
#if CONFIG_HAS_ADAPTIVE_LGM
  normalFingerThreshold_LSB = config->normalFingerThreshold_pct;
  negativeFingerThreshold_LSB = config->negativeFingerThreshold_pct;
  palmThreshold_LSB = config->palmThreshold_pct;
  glovedFingerThreshold_LSB = config->glovedFingerThreshold_pct;

  smallFingerThreshold_LSB = config->smallFingerThreshold_pct;
#else
  uint16 csat = config->saturationLevel_LSB;
  normalFingerThreshold_LSB = ((uint32)csat*config->normalFingerThreshold_pct) >> 16;
  negativeFingerThreshold_LSB = ((uint32)csat*config->negativeFingerThreshold_pct) >> 16;
  palmThreshold_LSB = ((uint32)csat*config->palmThreshold_pct) >> 16;
  glovedFingerThreshold_LSB = ((uint32)csat*config->glovedFingerThreshold_pct) >> 16;

  smallFingerThreshold_LSB = ((uint32)csat*config->smallFingerThreshold_pct) >> 16;
#endif

  smallFingerBorderSize_px = config->smallFingerBorderSize_px;
  smallFingerMaxSize_px = config->smallFingerMaxSize_px;

  palmArea_px = config->palmArea_px;
  negFingerLGMThreshold = config->negFingerLGMThreshold;
  absXObjectThreshold_LSB = config->absXObjectThreshold_LSB;
  absYObjectThreshold_LSB = config->absYObjectThreshold_LSB;
#if CONFIG_HAS_GLOVE_OBJECT_THRESHOLD
  absXObjectThreshold_LSB_glove = config->absXObjectThreshold_LSB_glove;
  absYObjectThreshold_LSB_glove = config->absYObjectThreshold_LSB_glove;
#endif
  stabilityThreshold_pct = config->stabilityThreshold_pct;

  glovedFingerLanding_frames = config->glovedFingerLanding_frames;
  avePeakRatio_pct = config->avePeakRatio_pct;
  cdmArtifactAmplitude_pct = config->cdmArtifactAmplitude_pct;
  fingerLandingMaxFrames = config->fingerLandingMaxFrames;
  landingFingerMinDeltaZ = config->landingFingerMinDeltaZ;
  smallFingerLandingMaxFrames = config->smallFingerLandingMaxFrames;
  landingSmallFingerMinDeltaZ = config->landingSmallFingerMinDeltaZ;
  maxAbsAbsent = config->maxAbsAbsent;
#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
  smallObjectDetectorConfig = config->smallObjectDetectorConfig;
#endif
#if CONFIG_HAS_GLOVE_SUSTAINER
  GS = config->GS;
  GS.UseExtraFingerAmp &= GS.Enable;
  GS.UseExtraGloveAmp  &= GS.Enable;
  GS.FingerAmpThreshold      = ((uint32)csat*(uint16)GS.FingerAmpThreshold)/65536;      GS.FingerAmpThreshold      *= GS.Enable;
  GS.SmallFingerAmpThreshold = ((uint32)csat*(uint16)GS.SmallFingerAmpThreshold)/65536; GS.SmallFingerAmpThreshold *= GS.Enable;
  GS.ExtraFingerAmpThreshold = ((uint32)csat*(uint16)GS.ExtraFingerAmpThreshold)/65536;
  GS.ExtraGloveAmpThreshold  = ((uint32)csat*(uint16)GS.ExtraGloveAmpThreshold)/65536;
#endif
#if CONFIG_HAS_GLOVE_STABLE_FRAMES
  GSF = config->GSF;
#endif
}

#if CONFIG_HAS_EXTREME_NOISE_REMOVER
void classifier_setExtremeNoiseconfigure(classifierConfig_t *config)
{

  fingerLandingMaxFrames = config->fingerLandingMaxFrames;
  landingFingerMinDeltaZ = config->landingFingerMinDeltaZ;
}
#endif

smallObjectFeatures_t classifier_getSmallObjectFeatures(void)
{
#if CONFIG_IFP_ALGM_FITCURVE_ENABLE
  // Collect LGM data to fit curve
  uint16 lgmMaxDeltaValTest;
  uint16 lgmRelatedAreaTest;
  uint16 lgmFingerPredictMaxValTest;
  uint16 lgmRealFingerThresholdTest;

  collectLGMDataEnable = getALGMTuningEnableStatus();

  if(collectLGMDataEnable)
  {
    collectLGMData(&lgmMaxDeltaValTest, &lgmRelatedAreaTest, &lgmFingerPredictMaxValTest, &lgmRealFingerThresholdTest);

    smallObjectFeatures.relativeAmplitude = (lgmMaxDeltaValTest > 255) ? 255 : lgmMaxDeltaValTest;
    smallObjectFeatures.area = (lgmRelatedAreaTest > 255) ? 255 : lgmRelatedAreaTest;
    smallObjectFeatures.maxXYWidth = (lgmFingerPredictMaxValTest > 255) ? 255 : lgmFingerPredictMaxValTest;
    smallObjectFeatures.maxDiagonalWidth = (lgmRealFingerThresholdTest > 255) ? 255 : lgmRealFingerThresholdTest;
  }
#endif
  return smallObjectFeatures;
}

void classifier_classify(sensorParams_t *sensorParams,
                         int16 *deltaImage,
                         int16 *deltaXProfile,
                         int16 *deltaYProfile,
                         clumps_t *clumps,
                         trackedObject_t *trackedObjects,
                         classification_t *classifications)
{
#if CONFIG_HAS_OBJECT_THRESHOLD_SPOILER
  checkSpoiler(sensorParams, deltaXProfile, deltaYProfile);
#endif
  uint16 clumpId;
  clumpInfo_t *clump;
  deltaData_t deltaData;
  uint16 motionThresholds[MAX_RX];

  {
    uint16 i;
    trackedObject_t *t;

    // determine which columns of the image have motion that could
    // cause CDM artifacts
    for (i = 0; i < MAX_RX; i++)
    {
      motionThresholds[i] = 0;
    }

    t = trackedObjects;
    for (i = 0; i < MAX_OBJECTS; t++, i++)
    {
      if (t->clumpId > 0)
      {
        uint16 fastMoving;
        uint16 justArrived;

        fastMoving = (t->speedx > 0x20) || (t->speedy > 0x20) ||
                     (t->speedx < -0x20) || (t->speedy < -0x20);
        justArrived = (classifierState[i].frameCount == 0);

        if (fastMoving || justArrived)
        {
          // mark all this blob's columns with the size of the blob
          // causing the motion
          pixelIndex_t peak = clumps->info[t->clumpId-1].peakLocation;
          pixelIndex_t next = clumps->info[t->clumpId-1].firstPixel;
          uint16 peakIdx;
          int16 peakAmp;
          peakIdx = peak.col + peak.row*(MAX_RX+1);
          peakAmp = deltaImage[peakIdx];
          peakAmp = (peakAmp > 0) ? peakAmp : (-peakAmp);
          while (next.row != 0)
          {
            uint16 idx = next.col + next.row*(MAX_RX+1);
            if ((uint16) peakAmp > motionThresholds[next.col-1])
            {
              motionThresholds[next.col-1] = peakAmp;
            }
            next = clumps->listImage[idx];
          }
        }
      }
    }
  }

  deltaData.deltaImage = deltaImage;
  deltaData.deltaXProfile = deltaXProfile;
  deltaData.deltaYProfile = deltaYProfile;

  memset16(classifications, 0, MAX_OBJECTS * sizeof(*classifications) / sizeof(uint16));
  memset16(&smallObjectFeatures, 0, sizeof(smallObjectFeatures) / sizeof(uint16));

  // Clear state for empty tracks
  {
    int16 objIdx;
    trackedObject_t *track;
    classifierState_t *state;

    for (objIdx = 0, track = &trackedObjects[0], state = &classifierState[0];
      objIdx < MAX_OBJECTS;
      objIdx++, track++, state++)
    {
      clumpId = track->clumpId;
      if (clumpId == 0 || track->trackedFrames == 1)
      {
        if ((clumpId == 0) && (state->objClass == class_landingSaturatedFinger || state->objClass == class_landingSmallFinger))
        {
            classification_t *recoveredClassification;   //if a landing object desappears completely the touch will be recovered here
            recoveredClassification = &classifications[objIdx];
            classifierClassification(state, recoveredClassification);
            recoveredClassification->touchFlag = 1;
            recoveredClassification->bufferTouchFlag = 0;
            recoveredClassification->recoverTouchFlag = 1;
            recoveredClassification->newTouchFlag = 0;
        }
        memset16(state, 0, sizeof(*state) / sizeof(uint16)); //clear the state
      }
      if (clumpId != 0)
      {
        if (state->frameCount < MAX_FRAME_COUNT)
        {
          state->frameCount++;
        }
        //if (state->landingObjectFrameCount < MAX_LANDING_OBJECT_FRAME_COUNT &&
        //    (state->objClass == class_landingSaturatedFinger ||
        //     state->objClass == class_landingSmallFinger))
        //{
        //  state->landingObjectFrameCount++;
        //}
        //else
        //{
        //  state->landingObjectFrameCount = 0;
        //}

        if (state->objClass == class_liftingSaturatedFinger || //lifting objects can land again
            state->objClass == class_liftingSmallFinger ||
            state->objClass == class_liftingWhileLandingSaturatedFinger ||
            state->objClass == class_liftingWhileLandingSmallFinger)
        {
          state->landingObjectFrameCount = 1;
        }
        else //increment counter
        {
          if (state->landingObjectFrameCount < MAX_LANDING_OBJECT_FRAME_COUNT)
          {
            state->landingObjectFrameCount++;
          }
        }

        //if (state->landingGlovedFinger > 0)
        //{
        //  state->landingGlovedFinger--;
        //}
        if (state->landingGlovedFinger > glovedFingerLanding_frames + 1)
        {
          state->landingGlovedFinger = glovedFingerLanding_frames + 1;
        }
        if (state->objClass == class_glovedFinger)
        {
          state->formerGlovedFinger = 1;
        }
        if (state->objClass == class_landingSaturatedFinger ||
            state->objClass == class_saturatedFinger)
        {
          state->formerSaturatedFinger = 1;
        }
      }
    }
  }

  // All blobs in a clump share the same features.
  for (clumpId = 1, clump = &clumps->info[0];
       clumpId <= MAX_OBJECTS;
       clumpId++, clump++)
  {
    uint16 trackInd;
    classifierResults_t results;
    trackedObject_t *track;
    classifierState_t *state;

    if (clump->peakCount < 1) continue;

    // Unfortunately, the previous classification can vary from blob
    // to blob, which affects hysteresis. Just apply hysteresis based
    // on first blob.
    trackInd = findTrackIndex(trackedObjects, clumpId, 0);
    // Bail if the object is not found. This can happen if the number
    // of blobs exceeds MAX_OBJECTS.
    if (trackInd >= MAX_OBJECTS) continue;

    track = &trackedObjects[trackInd];

    memset16(&results, 0, sizeof(results) / sizeof(uint16)); //clear test results
    classifierTests(sensorParams, deltaData, clump, clumps->labelImage, clumps->listImage,
      &classifierState[trackInd], track, &results);

    classifierState[trackInd].smallFingerArea = results.smallFingerArea;

    state = &classifierState[trackInd]; //update oldZ
    state->oldZ = track->zerothMoment;

    {
      uint16 blobId;
      uint16 cdmArtifact;
      int16 peakAmp = 0;
      cdmArtifact = (uint16) results.cdmArtifact;

      peakAmp = (results.peakVal > 0) ? results.peakVal : (-results.peakVal);

      // Each blob can join or leave a clump, so can have different history,
      // which can lead to different classification.
      for (blobId = 0; blobId <= clump->splitCount; blobId++)
      {
        classifierState_t *state;
        classification_t *classification;

        trackInd = findTrackIndex(trackedObjects, clumpId, blobId);
        if (trackInd >= MAX_OBJECTS) continue;

        state = &classifierState[trackInd];
        classification = &classifications[trackInd];

        results.cdmArtifact = ((uint16) cdmArtifact) &&
          motionThresholds[clump->peakLocation.col-1] > (uint16) peakAmp;

        // run the state machine to see what class this object will be
        // reported as in this frame
        if (results.absAbsent)
        {
          if (state->absAbsentFrameCount < MAX_ABS_ABSENT_FRAME_COUNT)
          {
            state->absAbsentFrameCount++;
          }
        }
        else
        {
          if (state->absAbsentFrameCount > 0)
          {
            state->absAbsentFrameCount--;
          }
        }
        classifierTransitionMatrix(&results, state);
        classifierClassification(state,
                                 classification);
        classifierReclassifyUnknown(clump, state, &results,
                                 classification);
        state->prevPeakVal           = results.peakVal;
        state->landingGlovedFinger   = results.landingGlovedFinger;
        state->formerSaturatedFinger = results.formerSaturatedFinger;
      #if CONFIG_HAS_GLOVE_STABLE_FRAMES
        if (GSF.NumFrames)
        {
          state->stableFrames.peaks[state->stableFrames.count] = results.peakVal;
          state->stableFrames.count++;
          if (state->stableFrames.count == GSF.NumFrames + 1)
          {
            state->stableFrames.count = 0;
          }
        }
      #endif
      }
    }
  }
}
