/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Description: Removes blobs that are likely to be noise. This should
                be considered a temporary fix while we work around
                problems in the tracker design
   $Id:
----------------------------------------------------------------- */

#include "ifp_common.h"
#include "ifp_string.h"
#include "ifp_vector_util.h"
#include "filter_noise_blobs.h"

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static uint0p16 noisePeakThreshold_pct;
//volatile int16 prevThresholds[MAX_RX];  // Global
static int16 prevThresholds[MAX_RX];

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

static uint32 fnb_sqrt(uint32 x);


/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/
/* -----------------------------------------------------------
Name: fnb_sqrt
Purpose: Finds the square root
Inputs: x
Outputs: fnb_sqrt(x)
Effects: None.
Notes: None.
----------------------------------------------------------- */
static uint32 fnb_sqrt(uint32 x)
{
  uint32 result;
  uint32 bit;

  result = 0;
  bit = ((uint32) 1 << 30); // Chimsim creates the '1' as 16 bit by default

  while (bit > x)
  {
    bit >>= 2;
  }

  while (bit != 0)
  {
    if (x >= result + bit)
    {
      x-= (result + bit);
      result = (result >> 1) + bit;
    }
    else
    {
      result >>= 1;
    }
    bit >>= 2;
  }
  return result;
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/
void filterNoiseBlobs_init(void)
{
  memset16(prevThresholds, 1, sizeof(prevThresholds) / sizeof(int16));
}

void filterNoiseBlobs_reinit(void)
{
  filterNoiseBlobs_init();
}

/* -----------------------------------------------------------------
Name: filterNoiseBlobs_configure()
Purpose: Configure the internal variables
Inputs:  None.
Outputs: None.
Effects: None.
Notes:   None.
Example: None.
----------------------------------------------------------------- */
void filterNoiseBlobs_configure(filterNoiseBlobsConfig_t *config)
{
  noisePeakThreshold_pct = config->noisePeakThreshold_pct;
}

/* -----------------------------------------------------------
Name: filterNoiseBlobs
Purpose: Filter noisy clumps
Inputs: sensorParams, deltaImage, clumps
Outputs: Filtered clumps
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------- */
void filterNoiseBlobs_filter(sensorParams_t *sensorParams,
                             int16 *deltaImage,
                             clumps_t *clumps)
{
  uint16 r, c;
  uint16 k;
  int16 threshold;
  int32 colAverages[MAX_RX];
  int32 stdev[MAX_RX];

  uint16 txCount = sensorParams->txCount;
  uint16 rxCount = sensorParams->rxCount;
  int16 index = MAX_RX+2;

  // memset16(colAverages, 1, sizeof(colAverages) / sizeof(int32));
  // memset16(stdev, 1, sizeof(stdev) / sizeof(int32));
  // Local memset. //_DS_TODO: Sort this out into a function. There doesn't seem to be an existing memset32 function I can use.
  uint16 i;
  uint32 *ptr = (uint32 *) colAverages;
  for (i = 0; i < sizeof(colAverages)/sizeof(uint32); i++)
  {
    *ptr++ = 0;
  }

  ptr = (uint32 *) stdev;
  for (i = 0; i < sizeof(stdev)/sizeof(uint32); i++)
  {
    *ptr++ = 0;
  }


  // Calculate the average of each Rx
  for (c = 1; c <= rxCount; c++, index++) //_DS_TODO: Refactor to use 0-indexed for loops.
  {
    colAverages[c-1] = sum16Stride(deltaImage+index, txCount, MAX_RX+1);
  }

  for (c = 1; c <= rxCount; c++)
  {
    colAverages[c-1] = ((int32) colAverages[c-1] / txCount);
  }

  // Calculate the variance along each Rx. StdDev = fnb_sqrt(Variance).
  index = MAX_RX+2;
    for (c = 1; c <= rxCount; c++, index++)
    {
    stdev[c-1] = var16Stride(deltaImage+index, txCount, MAX_RX+1, colAverages[c-1]);
  }

  for (c = 1; c <= rxCount; c++)
  {
    stdev[c-1] = fnb_sqrt((uint32) stdev[c-1]);

    // threshold = average + stddev*tuningValue
    // A high threshold indicates there is significant activity on that Rx.
    //   Activity could be a finger or noise. The stddev term is intended to handle
    //   the case where the noise is very high.
    threshold = (int16)(colAverages[c-1] + ((int32) noisePeakThreshold_pct * stdev[c-1]) / 64); //_DS_TODO: (uint0p16) * (int32) = 32p16 (truncated to 16p16), >> 6 = 16p10, then added to an int32, then cast to int16

    // _DS_TODO: Why magic number of 20?
    // If Current frame is touched (or very noisy) AND previous frame was touched
    //   (or very noisy), then IIR filter the threshold.
    if ((prevThresholds[c-1] > 20) && (threshold > 20))
    {
      threshold = ((int16) 2*threshold)/16 + ((int16) 14*prevThresholds[c-1]/16);
    }
    prevThresholds[c-1] = (int16) threshold;
  }

  for (k = 0; k < MAX_OBJECTS; k++)
  {
    r = clumps->info[k].peakLocation.row;
    c = clumps->info[k].peakLocation.col;

    if( c>0 ) //Ensure that the peak location is on a valid column
    {
      if (deltaImage[r*(MAX_RX+1) + c] < prevThresholds[c-1])
      { // Remove clump
        memset16(&clumps->info[k], 0, sizeof(clumps->info[0]) / sizeof(uint16));
      }
    }
  }
}
