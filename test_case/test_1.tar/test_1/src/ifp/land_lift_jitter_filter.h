
#ifndef _LAND_LIFT_JITTER_FILTER_H_
#define _LAND_LIFT_JITTER_FILTER_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: land_lift_jitter_filter.h
// Description: Header file for land_lift_jitter_filter.c
//
// $Id: land_lift_jitter_filter.h,v 1.3 2012/07/21 19:34:04 mposadas Exp $

void landLiftJitterFilter_init();
void landLiftJitterFilter_reinit();
void landLiftJitterFilter_configure(landLiftJitterFilterConfig_t *config);
void landLiftJitterFilter_filterPositions(sensorPosition_t *sensorPosition, classification_t *classifications, uint16 simpleMode);

#endif  //_LAND_LIFT_JITTER_FILTER_H_
