#ifndef _MOISTURE_DETECTOR_H
#define _MOISTURE_DETECTOR_H
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: Determines whether moisture is present
   $Id$
----------------------------------------------------------------- */

#include "ifp_common.h"

#if CONFIG_HAS_MOISTURE
void moistureDetector_init();
void moistureDetector_reinit();
void moistureDetector_configure(moistureDetectorConfig_t *mdConfig, sensorParams_t *sensorParams);
uint16 moistureDetector_detect(sensorParams_t *sensorParams,
  int16 *deltaImage, int16 *deltaXProfile, int16 *deltaYProfile,
  uint16 *rawImage, clumps_t *clumps);
void moistureDetector_computeTagsImage(int16 *rawSrc, int16 *dstTags);
#else
static ATTR_INLINE void moistureDetector_init() {};
static ATTR_INLINE void moistureDetector_reinit() {};
static ATTR_INLINE void moistureDetector_configure(ATTR_UNUSED moistureDetectorConfig_t *mdConfig, ATTR_UNUSED sensorParams_t *sensorParams) {};
static ATTR_INLINE uint16 moistureDetector_detect(ATTR_UNUSED sensorParams_t *sensorParams,
  ATTR_UNUSED int16 *deltaImage, ATTR_UNUSED int16 *deltaXProfile,
  ATTR_UNUSED int16 *deltaYProfile, ATTR_UNUSED uint16 *rawImage, ATTR_UNUSED clumps_t *clumps) { return moistureAction_none; };
static ATTR_INLINE void moistureDetector_computeTagsImage(ATTR_UNUSED int16 *rawSrc, ATTR_UNUSED int16 *dstTags) {};
#endif // CONFIG_HAS_MOISTURE

#endif // _MOISTURE_DETECTOR_H
