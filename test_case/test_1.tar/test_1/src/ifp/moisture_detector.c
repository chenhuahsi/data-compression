/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

  Description: Determines whether moisture is present
  $Id$
----------------------------------------------------------------- */

#include "ifp_common.h"

#if CONFIG_HAS_MOISTURE

#include "ifp_string.h"
#include "moisture_detector.h"

/* =================================================================
   MODULE FEATURE DEFINITION
==================================================================*/
#if !defined(MOISTURE_HAS_TAGS_HISTOGRAM)
  #define MOISTURE_HAS_TAGS_HISTOGRAM  0
#endif

/* =================================================================
   MODULE TYPES
==================================================================*/

typedef enum
{
  moistureState_wiped,
  moistureState_low,
  moistureState_escalating,
  moistureState_high,
} moistureState_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/

static moistureDetectorConfig_t config;
static sensorParams_t params;
static moistureState_t moistureState;
static uint16 counter;
static uint16 previousObjectPresentAbs;
static uint16 moistureGloballyDetected;

#if MOISTURE_HAS_TAGS_HISTOGRAM
  #define HISTOGRAM_SLOTS 8
  int16 tagsHistogramShape[HISTOGRAM_SLOTS];
  int16 tagsHistogram[HISTOGRAM_SLOTS];
#endif

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

ATTR_INLINE static uint16 isPixelPunchedOut(pixelIndex_t pix, pixelIndex_t *punchOutPixels, int16 maxLen);
ATTR_INLINE static uint16 detectTags(sensorParams_t *sensorParams, uint16 *rawImage, int16 threshold);
ATTR_INLINE static uint16 detectAbsProfile(int16 *deltaProfile, uint16 length, int16 threshold);
ATTR_INLINE static uint16 detectAbsNegative(int16 *deltaProfile, uint16 length, int16 threshold, uint16 absPosSumMinRatio);
static uint16 detectInClumps(sensorParams_t *sensorParams, clumps_t *clumps, int16 *deltaXProfile, int16 *deltaYProfile, moistureDetectorConfig_t *config);

#if MOISTURE_HAS_TAGS_HISTOGRAM
  ATTR_INLINE static void initialize_histogram(void);
  ATTR_INLINE static int16 updateHistogram(int16 pixel, int16 threshold);
#endif
/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

#if MOISTURE_HAS_TAGS_HISTOGRAM
// At start of sweep
void initialize_histogram(void)
{
  int16 i;
  for (i = 0; i < HISTOGRAM_SLOTS; i++)
  {
      tagsHistogram[i] = tagsHistogramShape[i]; // default
  }
}

// For every pixel; returns 0/1/2 if pixel is below-threshold / above-threshold+histogram-full / above-threshold+punched-out
// Used for non-localized punchout
int16 updateHistogram(int16 pixel, int16 threshold)
{
  int16 base, increment, i;
  base = threshold;
  increment = base >> 1;

  if (pixel > threshold)
  {
    for (i = 0; i<HISTOGRAM_SLOTS; i++)
    {
      base += increment;
      if ((pixel > base && (i < HISTOGRAM_SLOTS - 1)) || !tagsHistogram[i])
      {
        continue;
      }
      if (tagsHistogram[i])
      {
        tagsHistogram[i]--;
        return 2;
      }
    }
    return 1;
  }
  return 0;
}
#endif

/* -----------------------------------------------------------
Name: isPixelPunchedOut()
Purpose: Determine whether a given pixel in the raw image is punched out
Inputs: pixel to check, array of of pixels punched out (terminated with 0xFFFF), maximum length of punch-out array
Outputs: None
Notes: The punch-out pixels are zero-indexed to match the raw image.
----------------------------------------------------------- */
static uint16 isPixelPunchedOut(pixelIndex_t pix, pixelIndex_t *punchOutPixels, int16 maxLen)
{
  if (punchOutPixels->row == 0xFF && punchOutPixels->col == 0xFF)
  {
      return 0;
  }
  else
  {
    pixelIndex_t punchPix;
    int16 i;
    for (i = maxLen; i > 0; i--)
    {
      punchPix = *punchOutPixels++;
      if (punchPix.row == pix.row && punchPix.col == pix.col) return 1;
      if (punchPix.row == 0xFF || punchPix.col == 0xFF) break;  // terminated by sentinel
    }
    return 0;
  }
}

static uint16 detectTags(sensorParams_t *sensorParams, uint16 *rawImage, int16 threshold)
{
  uint16 i, j;
  uint16 *rawPtr = rawImage + config.punchoutEdgeWidth*(MAX_RX+1);
  int16 rowSkip = MAX_RX - sensorParams->rxCount + 1 + config.punchoutEdgeWidth*2;  // +1 from not going to edge
  int16 value = 0;

  #if MOISTURE_HAS_TAGS_HISTOGRAM
    int16 histogramThreshold = (threshold * 8) / 10;
    initialize_histogram();
  #endif

  for (i = config.punchoutEdgeWidth; i < sensorParams->txCount - 1 - config.punchoutEdgeWidth; i++, rawPtr += rowSkip)
  {
    for (j = config.punchoutEdgeWidth; j < sensorParams->rxCount - 1 - config.punchoutEdgeWidth; j++, rawPtr++)
    {
      pixelIndex_t pix = {i, j};
      value = (int16) rawPtr[0] - rawPtr[1] - rawPtr[MAX_RX] + rawPtr[MAX_RX + 1];
      value = (value < 0) ? -value : value;

      #if MOISTURE_HAS_TAGS_HISTOGRAM
        if (!isPixelPunchedOut(pix, config.tagsPunchOuts, sizeof(config.tagsPunchOuts) / sizeof(config.tagsPunchOuts[0])))
        {
          if (config.maxNumberNonLocalizedPunchouts)
          {
            int16 status = updateHistogram(value, histogramThreshold);
            if (status != 2)
            {
              if (value >= threshold) // ok if below threshold
              {
                return 1;
              }
            }
          }
          else
          {
            if (value >= threshold)
            {
              return 1;
            }
          }
        }
      #else
        if ((value >= threshold) &&
            !isPixelPunchedOut(pix, config.tagsPunchOuts,
                               sizeof(config.tagsPunchOuts) / sizeof(config.tagsPunchOuts[0])))
        {
          return 1;
        }
      #endif // MOISTURE_HAS_TAGS_HISTOGRAM
    }
  }
  return 0;
}

static uint16 detectAbsProfile(int16 *deltaProfile, uint16 length, int16 threshold)
{
  uint16 i;
  int16 min = 32767;
  int16 max = -32768;
  for (i = 0; i < length; i++, deltaProfile++)
  {
    int16 val = *deltaProfile;
    if (val < min) min = val;
    if (val > max) max = val;
  }
  return (max - min) >= threshold;
}

static uint16 detectAbsNegative(int16 *deltaProfile, uint16 length, int16 threshold, uint16 absPosSumMinRatio)
{
  uint16 i;
  int16 minDelta = 32767;
  uint32 posSum = 0;
  for (i = 0; i < length; i++, deltaProfile++)
  {
    int16 val = *deltaProfile;
    if (val < minDelta) minDelta = val;
    if (val > 0) posSum += val;
  }
  return (minDelta <= threshold) &&
         (absPosSumMinRatio == 0 || posSum < (uint32) absPosSumMinRatio * (-minDelta));
}

static uint16 detectInClumps(sensorParams_t *sensorParams, clumps_t *clumps, int16 *deltaXProfile, int16 *deltaYProfile, moistureDetectorConfig_t *config)
{
  objectBitmask_t absAbsent = 0;
  objectBitmask_t objBit;
  uint16 absentProximityCount[MAX_OBJECTS];
  uint16 i;

  for (i = 0, objBit = 1; i < MAX_OBJECTS; i++, objBit <<= 1)
  {
    clumpInfo_t *clump = &clumps->info[i];
    pixelIndex_t peak;
    uint16 c;
    uint16 r;

    if (clump->peakCount < 1) continue;

    peak = clump->peakLocation;
    c = peak.col - 1; // no zero-padding
    r = peak.row - 1; // no zero-padding
    if ((deltaXProfile[c] < (int16) config->absXObjectThreshold_LSB) &&
        ((c == 0 || deltaXProfile[c-1] < (int16) config->absXObjectThreshold_LSB) &&
         (c == sensorParams->rxCount - 1 || deltaXProfile[c+1] < (int16) config->absXObjectThreshold_LSB)))
    {
      absAbsent |= objBit;
      continue;
    }
    if ((deltaYProfile[r] < (int16) config->absYObjectThreshold_LSB) &&
        ((r == 0 || deltaYProfile[r-1] < (int16) config->absYObjectThreshold_LSB) &&
         (r == sensorParams->txCount - 1 || deltaYProfile[r+1] < (int16) config->absYObjectThreshold_LSB)))
    {
      absAbsent |= objBit;
    }
  }

  memset16(absentProximityCount, 0, MAX_OBJECTS);
  for (i = 0, objBit = 1; i < MAX_OBJECTS - 1; i++, objBit <<= 1)
  {
    pixelIndex_t clump1Peak;
    uint16 j;
    objectBitmask_t obj2Bit;

    if ((absAbsent & objBit) == 0) continue;

    clump1Peak = clumps->info[i].peakLocation;
    for (j = i + 1, obj2Bit = objBit << 1; j < MAX_OBJECTS; j++, obj2Bit <<= 1)
    {
      pixelIndex_t clump2Peak;
      int16 dx, dy;
      if ((absAbsent & obj2Bit) == 0) continue;
      clump2Peak = clumps->info[j].peakLocation;

      dx = clump1Peak.row - clump2Peak.row;
      dy = clump1Peak.col - clump2Peak.col;
      if ((uint16) (dx * dx) + (uint16) (dy * dy) <= config->moistureClumpDistanceSq_px2)
      {
        absentProximityCount[i]++;
        absentProximityCount[j]++;
      }
    }
  }

  // If there's a high density of suspicious peaks anywhere then we
  // probably have moisture or anti-moisture (baseline error from wiped
  // moisture).
  for (i = 0; i < MAX_OBJECTS; i++)
  {
    if (absentProximityCount[i] >= config->moistureClumpDensity) return 1;
  }

  return 0;
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: moistureDetector_init()
Purpose: Reset state on startup
Inputs: None
Outputs: None
----------------------------------------------------------- */
void moistureDetector_init()
{
  moistureState = moistureState_low;
  counter = 0;
  previousObjectPresentAbs = 0;
  moistureGloballyDetected = 0;
}

/* -----------------------------------------------------------
Name: moistureDetector_reinit()
Purpose: Reset state on reset
Inputs: None
Outputs: None
----------------------------------------------------------- */
void moistureDetector_reinit()
{
  moistureDetector_init();
}

/* -----------------------------------------------------------
Name: moistureDetector_configure()
Purpose: Set configuration parameters
Inputs: moisture detector config struct
Outputs: None
----------------------------------------------------------- */
void moistureDetector_configure(moistureDetectorConfig_t *mdConfig, sensorParams_t *sensorParams)
{
  config = *mdConfig;
  params = *sensorParams;

  #if MOISTURE_HAS_TAGS_HISTOGRAM
    tagsHistogramShape[HISTOGRAM_SLOTS - 1] = config.maxNumberNonLocalizedPunchouts;
  #endif

}

/* -----------------------------------------------------------
Name: moistureDetector_detect()
Purpose: Determines whether moisture is present
Inputs: sensorParams - sensor parameters
        deltaImage
        deltaXProfile
        deltaYProfile
        rawImage
Outputs: returns the action should that be taken on based on moisture presence (moistureAction_t enum)
----------------------------------------------------------- */
uint16 moistureDetector_detect(sensorParams_t *sensorParams, int16 *deltaImage, int16 *deltaXProfile, int16 *deltaYProfile, uint16 *rawImage, clumps_t *clumps)
{
  uint16 moisturePresent;
  uint16 fingerPresent;
  uint16 objectPresentAbs;
  uint16 forceFastRelax = 0;

  if (MAX_ABS_RX == 1 || MAX_ABS_TX == 1 || deltaImage == NULL ||
      deltaXProfile == NULL || deltaYProfile == NULL)
  {
    return moistureAction_none;
  }

  // Check current frame
  {
    uint16 objectPresentTrans;
    // Keep monitoring tags to see if we can trust it.
    objectPresentTrans = detectTags(sensorParams, rawImage, (int16) config.tagsThreshold_LSB);
    objectPresentAbs = detectAbsProfile(deltaXProfile, sensorParams->rxCount, (int16) config.absXObjectThreshold_LSB) &&
                       detectAbsProfile(deltaYProfile, sensorParams->txCount, (int16) config.absYObjectThreshold_LSB);
    moisturePresent = objectPresentTrans && !objectPresentAbs;
    fingerPresent = objectPresentTrans && objectPresentAbs;
  }

  // We can't detect moisture and finger together with our global
  // checks above, but we can with local moisture detection.
  if (moisturePresent) moistureGloballyDetected = 1;
  if (fingerPresent)
  {
    moisturePresent = detectInClumps(sensorParams, clumps, deltaXProfile,
                                     deltaYProfile, &config);
  }

  // Transition states
  switch(moistureState)
  {
    case moistureState_low:
    {
      if (moisturePresent) {
        moistureState = moistureState_escalating;
        counter = 1;
      }
    }
    break;
    case moistureState_escalating:
    {
      if (moisturePresent)  // ==> !fingerPresent
      {
        if (++counter >= config.escalationFrames)
        {
          moistureState = moistureState_high;
          counter = 0;  // frames sensor clear
        }
      }
      else if (!fingerPresent)
      {
        moistureState = moistureState_low;
        moistureGloballyDetected = 0;
      }
    }
    break;
    case moistureState_high:
    {
      uint16 absNegative =
        detectAbsNegative(deltaXProfile, sensorParams->rxCount, -(int16) config.absXLiftThreshold_LSB, (uint16) config.absPosSumMinRatio) ||
        detectAbsNegative(deltaYProfile, sensorParams->txCount, -(int16) config.absYLiftThreshold_LSB, (uint16) config.absPosSumMinRatio);
      if (absNegative)
      {
        counter = 0;
        forceFastRelax = 1;
      }
      else if (moisturePresent || fingerPresent)
      {
        counter = 0;  // frames sensor clear
      }
      else
      {
        if (++counter >= config.deescalationFrames)
        {
          moistureState = moistureState_wiped;
          counter = 0;  // frames since entering wiped
          forceFastRelax = 1;
          moistureGloballyDetected = 0;
        }
      }
    }
    break;
    case moistureState_wiped:  // watch for subsequent wipes
    {
      uint16 absNegative =
        detectAbsNegative(deltaXProfile, sensorParams->rxCount, -(int16) config.absXLiftThreshold_LSB, (uint16) config.absPosSumMinRatio) ||
        detectAbsNegative(deltaYProfile, sensorParams->txCount, -(int16) config.absYLiftThreshold_LSB, (uint16) config.absPosSumMinRatio);
      if ((!objectPresentAbs && previousObjectPresentAbs) || absNegative)  // detect lift
      {
        counter = 0;  // frames since wipe
        forceFastRelax = 1;
      }
      else
      {
        if (++counter >= config.refractoryFrames)  // frames since wipe
        {
          moistureState = moistureState_low;
          moistureGloballyDetected = 0;
        }
      }
    }
    break;
  }
  previousObjectPresentAbs = objectPresentAbs;

  // Report
  {
    moistureAction_t moistureAction;

    if (forceFastRelax)
    {
      moistureAction = moistureAction_fastRelax;
    }
    else
    {
      switch (moistureState)
      {
        case moistureState_escalating:  // intentional fall-through
        case moistureState_high:  // intentional fall-through
          moistureAction = moistureGloballyDetected ? moistureAction_filterAndFreeze : moistureAction_filter;
          break;
        case moistureState_low:
        case moistureState_wiped:  // intentional fall-through
        default:  // invalid; intentional fall-through
          moistureAction = moistureAction_none;
          break;
      }
    }
    return moistureAction;
  }
}

/* -----------------------------------------------------------
Name: moistureDetector_computeTagsImage()
Purpose: Create the tag image for RT76 production test
Inputs: rawSrc
        dstTags
Outputs: None
----------------------------------------------------------- */
void moistureDetector_computeTagsImage(int16 *rawSrc, int16 *dstTags)
{
  uint16 i, j;
  int16 *rawPtr = rawSrc+config.punchoutEdgeWidth*(MAX_RX+1);
  int16 *tagPtr = dstTags;
  uint16 numCols = params.rxCount;
  uint16 numRows = params.txCount;
  int16 rowSkip = MAX_RX - params.rxCount + 1 + config.punchoutEdgeWidth*2;  // +1 from not going to edge
  int16 value = 0;

  #if MOISTURE_HAS_TAGS_HISTOGRAM
    int16 histogramThreshold = (config.tagsThreshold_LSB * 8) / 10;
    initialize_histogram();
  #endif

  // initialize the tagPtr with -100
  for (i = 0; i < MAX_TX-1; i++)
  {
    for (j = 0; j < MAX_RX-1; j++)
    {
      *tagPtr++ = -100;
    }
    tagPtr++;
  }

  tagPtr = dstTags+config.punchoutEdgeWidth*(MAX_RX+1);

  for (i = config.punchoutEdgeWidth; i < numRows - 1 - config.punchoutEdgeWidth; i++)
  {
    for (j = config.punchoutEdgeWidth; j < numCols - 1 - config.punchoutEdgeWidth; j++)
    {
      pixelIndex_t pix = {i, j};
      value = -200; // nominal value for pixel that is punched out
      if (!isPixelPunchedOut(pix, config.tagsPunchOuts,
                             sizeof(config.tagsPunchOuts) / sizeof(config.tagsPunchOuts[0])))
      {
        value = (int16) rawPtr[0] - rawPtr[1] - rawPtr[MAX_RX] + rawPtr[MAX_RX + 1];
        value = (value < 0) ? -value : value;

        #if MOISTURE_HAS_TAGS_HISTOGRAM
          if (config.maxNumberNonLocalizedPunchouts)
          {
            int16 status = updateHistogram(value, histogramThreshold);
            if (status == 2)
            {
              value = -300; // ok if below reduced threshold or above it and punched out
            }
          }
        #endif
      }

      *tagPtr++ = value;
      rawPtr++;
    }
    // Now RT76 shows MAX_RX/MAX_TX image. skip unused pixels here
    tagPtr += rowSkip;
    rawPtr += rowSkip;
  }
}

#endif // CONFIG_HAS_MOISTURE
