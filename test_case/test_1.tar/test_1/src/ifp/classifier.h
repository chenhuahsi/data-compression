#ifndef _CLASSIFIER_H
#define _CLASSIFIER_H
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: classifier.h
// Description: Computes object features and classifies them according to
//              the features and previous state.
// $Id: classifier.h,v 1.4.44.1 2013/01/02 22:32:24 nfotopou Exp $

void classifier_init(void);
void classifier_reinit(void);
void classifier_configure(classifierConfig_t *config);
smallObjectFeatures_t classifier_getSmallObjectFeatures(void);
void classifier_classify(sensorParams_t *sensorParams,
                         int16 *deltaImage,
                         int16 *deltaXProfile,
                         int16 *deltaYProfile,
                         clumps_t *clumps,
                         trackedObject_t *trackedObjects,
                         classification_t *classifications);

#if CONFIG_HAS_EXTREME_NOISE_REMOVER
void classifier_setExtremeNoiseconfigure(classifierConfig_t *config);
#endif

#endif // _CLASSIFIER_H
