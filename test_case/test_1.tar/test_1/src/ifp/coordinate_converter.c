/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: coordinate_converter.c
   Description: Coordinate converter module adjusts positions from
                sensor pitch units to host-defined units.
----------------------------------------------------------------- */

#include "ifp_common.h"
#include "ifp_string.h"
#include "coordinate_converter.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

/* =================================================================
   MODULE TYPES
==================================================================*/
typedef struct
{
  int24p8 scale;
  int8p8 offset;
  int16 max;
  int16 wOffset;
  int16 wScale;
} axisVars_t;

typedef struct
{
  axisVars_t x;
  axisVars_t y;
  uint16 swapAxesFlag;
  uint8p8 smallZScale;
  uint8p8 largeZScale;
  uint16p16 largeZOffset;
} coordConvVars_t;

typedef struct
{
  int8p8 inPos;
  int8p8 inWidth;
  uint16 outPos;
  uint16 outWidth;
} posAndWidth_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static coordConvVars_t ccConfig;

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

static int16 clipS16(int16 value, int16 minimum, int16 maximum);
static void setLinearVars(axisVars_t *c, uint16 pixels, int8p8 clipLow, int8p8 clipHigh, int16 max);
ATTR_INLINE static void setWidthVars(axisVars_t *c, int16 wOffset, uint8p8 wScale);
static void calcPosAndWidth(axisVars_t *c, posAndWidth_t *pw);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: clipS16
Purpose: Clips a value between a minimum and maximum
Inputs: value - the value to clip
        minimum - the minimum value to clip at
        maximum - the maximum value to clip at
Outputs: the clipped value
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------- */

static int16 clipS16(int16 value, int16 minimum, int16 maximum)
{
  uint16 clippedValue;

  if (value < minimum)
  {
    clippedValue = minimum;
  }
  else if (value > maximum)
  {
    clippedValue = maximum;
  }
  else
  {
    clippedValue = value;
  }
  return clippedValue;
}

static void setLinearVars(axisVars_t *c, uint16 pixels, int8p8 clipLow, int8p8 clipHigh, int16 max)
{
  // In the code below, BL = bottom left, TR = top right.
  // The bottom left corner is at (0,0) in sensor coordinates.
  // The top right corner is at (xPixels, yPixels) in sensor
  // coordinates.

  int8p8 blCorner_px;
  int8p8 trCorner_px;

  blCorner_px = clipLow;
  trCorner_px = (pixels<<8) - clipHigh;
  c->offset = blCorner_px;
  c->max = max;
  if (trCorner_px - blCorner_px != 0)
  {
    c->scale = (((int32)max)<<16)/(trCorner_px-blCorner_px);
  }
  else
  {
    c->scale = 1;
  }
}

ATTR_INLINE static void setWidthVars(axisVars_t *c, int16 wOffset, uint8p8 wScale)
{
  c->wOffset = wOffset;
  c->wScale = wScale;
}

static void calcPosAndWidth(axisVars_t *c, posAndWidth_t *pw)
{
  int32 w;
  int16 pos;
  uint16 w16;

  pos = (int16) ((((int32)(pw->inPos - c->offset))*c->scale + 0x8000L) / 0x10000L);
  pw->outPos = (uint16) clipS16(pos, 0, c->max);

  w = ((int32)pw->inWidth * c->wScale) >> 8;
  w += ((int32)c->wOffset << 8) + 0x80;

  if (w > 65535)
  {
    w16 = 255;
  }
  else if (w < 0)
  {
    w16 = 0;
  }
  else
  {
    w16 = (uint16) (w >> 8);
  }
  pw->outWidth = w16;
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: coordConv_configure()
Purpose: Set host-defined parameters
Inputs: sensorParams - sensor parameters structure
        ccConfig - coordConvConfig_t struct ptr
Outputs: none
Effects: Resets internal state of coordinate converter, as at a
         host rezero.
Notes: This function must be called if the host sends a rezero
       command.
Example: none
----------------------------------------------------------- */
void coordConv_configure(sensorParams_t *sensorParams,
                         coordConvConfig_t *extConfig)
{
  axisName_t txAxis = (axisName_t) extConfig->txAxis;

  ccConfig.swapAxesFlag = (txAxis != axisName_yAxis);
  switch(txAxis)
  {
    default: // invalid values result in "portrait" orientation
    case axisName_xAxis: // intentional fall-through
      setLinearVars(&ccConfig.x, sensorParams->txCount, extConfig->txClipLow, extConfig->txClipHigh, extConfig->xMax);
      setLinearVars(&ccConfig.y, sensorParams->rxCount, extConfig->rxClipLow, extConfig->rxClipHigh, extConfig->yMax);
      break;
    case axisName_yAxis:
      setLinearVars(&ccConfig.x, sensorParams->rxCount, extConfig->rxClipLow, extConfig->rxClipHigh, extConfig->xMax);
      setLinearVars(&ccConfig.y, sensorParams->txCount, extConfig->txClipLow, extConfig->txClipHigh, extConfig->yMax);
      break;
  }

  setWidthVars(&ccConfig.x, extConfig->wxOffset, extConfig->wxScaleFactor);
  setWidthVars(&ccConfig.y, extConfig->wyOffset, extConfig->wyScaleFactor);

  ccConfig.smallZScale= extConfig->smallZScaleFactor;
  ccConfig.largeZScale = extConfig->largeZScaleFactor;

  // the algorithm assumes that largeZScale is smaller than
  // smallZScale, so we just use a safe value of largeZOffset in that
  // case.
  if ((ccConfig.smallZScale == 0) ||
      (ccConfig.largeZScale >= ccConfig.smallZScale))
  {
    ccConfig.largeZOffset = 0;
  }
  else
  {
    uint32 scaleRatio;
    uint32 scaleFrac;
    scaleRatio = (((uint32) ccConfig.largeZScale << 8) / ccConfig.smallZScale);
    scaleFrac = (uint32) 0x100 - scaleRatio;
    ccConfig.largeZOffset = (uint24p8) extConfig->smallZThreshold * scaleFrac;  // 8p8 * 8p8 = 16p16
  }
}

/* -----------------------------------------------------------
Name: coordConv_convertPositions()
Purpose: converts sensor to host coordinates
Inputs: sensorPositions - positions in sensor units
Outputs: hostPositions - positions in host units
Effects: none
Notes: none
Example: none
----------------------------------------------------------- */
void coordConv_convertPositions(sensorPosition_t *sensorPositions,
                                hostPosition_t *hostPositions)
{
  int16 objIdx;

  hostPosition_t *hp = hostPositions;
  sensorPosition_t *sp = sensorPositions;

  for (objIdx = 0; objIdx < MAX_OBJECTS; objIdx++, hp++, sp++)
  {
    memset16(hp, 0, sizeof(*hp)/sizeof(uint16));
    if (sp->z != 0)
    {
      posAndWidth_t pwInX, pwInY;
      posAndWidth_t *pwOutX, *pwOutY;
      uint16 z;

      pwInX.inPos = sp->xPosition;
      pwInX.inWidth = sp->xWidth;
      pwInY.inPos = sp->yPosition;
      pwInY.inWidth = sp->yWidth;

      if (ccConfig.swapAxesFlag == FALSE)
      {
        pwOutX = &pwInX;
        pwOutY = &pwInY;
      }
      else
      {
        pwOutX = &pwInY;
        pwOutY = &pwInX;
      }

      calcPosAndWidth(&ccConfig.x, pwOutX);
      calcPosAndWidth(&ccConfig.y, pwOutY);

      // Round up to prevent z = 0.
      {
        uint16 zSmall = (uint16) (((uint32)sp->z * ccConfig.smallZScale + 65535) >> 16);
        uint16 zLarge = (uint16) (((uint32)sp->z * ccConfig.largeZScale + ccConfig.largeZOffset + 65535) >> 16);
        z = (zSmall < zLarge) ? zSmall : zLarge;
      }

      hp->xPosition = pwOutX->outPos;
      hp->xWidth = pwOutX->outWidth;
      hp->yPosition = pwOutY->outPos;
      hp->yWidth = pwOutY->outWidth;
      hp->z = z;
    }
  }
}

#if CONFIG_HAS_Z_JITTER_ADJUSTMENT || CONFIG_HAS_LL_LIFTING_LARGE_FINGER || CONFIG_HAS_LANDING_LARGE_FINGER_DROP
uint16 coordConv_computeZ(sensorPosition_t *sp)
{
  uint16 zSmall = (uint16) (((uint32)sp->z * ccConfig.smallZScale + 65535) >> 16);
  uint16 zLarge = (uint16) (((uint32)sp->z * ccConfig.largeZScale + ccConfig.largeZOffset + 65535) >> 16);
  return (zSmall < zLarge) ? zSmall : zLarge;
}
#endif
#if CONFIG_HAS_W_LLJ_FILTER || CONFIG_HAS_LL_LIFTING_LARGE_FINGER || CONFIG_HAS_LANDING_LARGE_FINGER_DROP
uint16 coordConv_computeW(sensorPosition_t *sp)
{
  posAndWidth_t pwInX, pwInY;
  posAndWidth_t *pwOutX, *pwOutY;

  pwInX.inPos = sp->xPosition;
  pwInX.inWidth = sp->xWidth;
  pwInY.inPos = sp->yPosition;
  pwInY.inWidth = sp->yWidth;

  if (ccConfig.swapAxesFlag == FALSE)
  {
    pwOutX = &pwInX;
    pwOutY = &pwInY;
  }
  else
  {
    pwOutX = &pwInY;
    pwOutY = &pwInX;
  }

  calcPosAndWidth(&ccConfig.x, pwOutX);
  calcPosAndWidth(&ccConfig.y, pwOutY);

  return (pwInX.outWidth < pwInY.outWidth) ? pwInY.outWidth : pwInX.outWidth;
}
#endif
