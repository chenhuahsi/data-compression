#ifndef _UNISON_NOISE_REMOVER_H
#define _UNISON_NOISE_REMOVER_H
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2013  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: Header for unison noise remover entry point
   $Id$
----------------------------------------------------------------- */

#include "ifp_common.h"

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* -----------------------------------------------------------
Name: unisonNoiseRemover_remove()
Purpose: Estimate and remove unison noise from a delta image
Inputs: sensorParams
        deltaImage
        clumps
Outputs: modifies deltaImage in place
Notes: This requires a valid clumps struct and thus must be
       run *after* segmentation. It will not remove unison
       noise properly if run with an empty clumps struct.
----------------------------------------------------------- */
void unisonNoiseRemover_remove(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps);

#endif // _UNISON_NOISE_REMOVER_H
