#ifndef _SMALL_OBJECT_DETECTOR_H
#define _SMALL_OBJECT_DETECTOR_H
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: Header for small object detection entry point
   $Id$
----------------------------------------------------------------- */

#include "ifp_common.h"

/* =================================================================
   MODULE TYPES
==================================================================*/
typedef enum
{
  smallObjectClass_none,
  smallObjectClass_touchingSmallObject,
  smallObjectClass_wideSmallObject,
  smallObjectClass_stylus,
  smallObjectClass_eraser,
  smallObjectClass_headphoneCable
} smallObjectClass_t;

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* -----------------------------------------------------------
Name: smallObjectDetector_detect()
Purpose: Determines whether an object is a touching small finger
         or not
Inputs: params - sensor parameters
        deltaImage
        peakLoc - the location of the blob's peak pixel
        soCfg - the classifier configuration values
        hystFlag - set true if this object was a small finger on
                   the previous frame.
Outputs: returns a smallObjectClass_t which is any of smallObjectClass_none,
                smallObjectClass_touchingSmallObject, or
                smallObjectClass_wideSmallObject
         soFeatures - struct containing the calculated relative
                      amplitude, area, max width, and max diagonal
                      width for classifier tuning.
Note: This must only be applied to objects that are known to be small,
      as it can incorrectly classify touching objects that are very
      flat around the peak pixel.
----------------------------------------------------------- */
#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
uint16 smallObjectDetector_detect(sensorParams_t *params, int16 *deltaImage,
                                  pixelIndex_t peakLoc, smallObjectDetectorConfig_t *soCfg,
                                  int16 hystFlag, smallObjectFeatures_t *soFeatures,
                                  uint16 lastClass);
#else
uint16 smallObjectDetector_detect(ATTR_UNUSED sensorParams_t *params, ATTR_UNUSED int16 *deltaImage,
                                  ATTR_UNUSED pixelIndex_t peakLoc, ATTR_UNUSED smallObjectDetectorConfig_t *soCfg,
                                  ATTR_UNUSED int16 hystFlag, ATTR_UNUSED smallObjectFeatures_t *soFeatures,
                                  ATTR_UNUSED uint16 lastClass) { return smallObjectClass_none; };
#endif

#endif // _SMALL_OBJECT_DETECTOR_H
