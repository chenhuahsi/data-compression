/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Description: Utility functions for CDM decoding
   $Id$
----------------------------------------------------------------- */

#include "ifp_common.h"

#include "cdm_decoder.h"

#define MAX_IMAGE_BUFFER_COLS MAX_RX

static ATTR_INLINE uint16 sumVector(uint16 *v, uint16 stride, uint16 len)
{
  uint16 i;
  uint16 sum = 0;
  for (i = 0; i < len; i++)
  {
    sum += *v;
    v += stride;
  }
  return sum;
}

static ATTR_INLINE void doOneCDM16Pixel(uint16 sum, uint16 *src, uint16 *dst, uint16 i0, uint16 i1, uint16 i2, uint16 i3, uint16 i4, uint16 i5)
{
  // This calculates (sum - i0 - i1 - i2 - i3 - i4 - i5)/2
  //
  // i0 - i5 are the columns of the -1s in each row of the CDM matrix.
  //
  // Note that sum is divided by 2 before this routine is called so
  // the net result is to divide by 4.
  uint16 t;
  t = sum;
  t -= src[i0];
  t -= src[i1];
  t -= src[i2];
  t -= src[i3];
  t -= src[i4];
  t -= src[i5];
  t >>= 1;
  *dst = t;
}

void decodeCDM16(uint16 *image, uint16 numEnabledTX, uint16 numEnabledRX)
{
  uint16 y[16];
  uint16 *x = image;
  uint16 startCluster = 0;
  uint16 rx;
  uint16 STRIDE = MAX_IMAGE_BUFFER_COLS;
  uint16 nextBlockIncrement = 16*MAX_IMAGE_BUFFER_COLS - numEnabledRX;
  while(startCluster < numEnabledTX)
  {
    uint16 rows = numEnabledTX - startCluster;
    if (rows > 16)
    {
      rows = 16;
    }
    for (rx = 0; rx < numEnabledRX; rx++)
    {
      uint16 s;
      uint16 i;
      uint16 *src;
      uint16 *dst;

      src = x;
      dst = y;
      for (i = 0; i < 16; i++)
      {
        *dst = *src;
        dst++;
        src += STRIDE;
      }

      s = sumVector(y, 1, 16);
      s += 2; // change truncation to round-up at 0.5
      s >>= 1;
      s += 6*4096/2;

      doOneCDM16Pixel(s, y, &x[ 0*STRIDE], 0, 1, 2, 3, 4, 5);
      doOneCDM16Pixel(s, y, &x[ 1*STRIDE], 0, 1, 6, 7, 8, 9);
      doOneCDM16Pixel(s, y, &x[ 2*STRIDE], 0, 2, 6,10,11,12);
      doOneCDM16Pixel(s, y, &x[ 3*STRIDE], 0, 3, 7,10,13,14);
      doOneCDM16Pixel(s, y, &x[ 4*STRIDE], 0, 4, 8,11,13,15);
      doOneCDM16Pixel(s, y, &x[ 5*STRIDE], 0, 5, 9,12,14,15);
      doOneCDM16Pixel(s, y, &x[ 6*STRIDE], 1, 2, 6,13,14,15);
      doOneCDM16Pixel(s, y, &x[ 7*STRIDE], 1, 3, 7,11,12,15);
      doOneCDM16Pixel(s, y, &x[ 8*STRIDE], 1, 4, 8,10,12,14);
      doOneCDM16Pixel(s, y, &x[ 9*STRIDE], 1, 5, 9,10,11,13);
      doOneCDM16Pixel(s, y, &x[10*STRIDE], 2, 3, 8, 9,10,15);
      doOneCDM16Pixel(s, y, &x[11*STRIDE], 2, 4, 7, 9,11,14);
      doOneCDM16Pixel(s, y, &x[12*STRIDE], 2, 5, 7, 8,12,13);
      doOneCDM16Pixel(s, y, &x[13*STRIDE], 3, 4, 6, 9,12,13);
      doOneCDM16Pixel(s, y, &x[14*STRIDE], 3, 5, 6, 8,11,14);
      doOneCDM16Pixel(s, y, &x[15*STRIDE], 4, 5, 6, 7,10,15);

      if (rows < 16)
      {
        src = &x[(16-rows)*STRIDE];
        dst = x;
        for (i = 0; i < rows; i++)
        {
          *dst = *src;
          src += STRIDE;
          dst += STRIDE;
        }
      }
      x++;
    }
    startCluster += 16;
    x += nextBlockIncrement;
  }
}

static ATTR_INLINE void doOneCDM10Pixel(uint16 sum, uint16 *src, uint16 *dst, uint16 i0,
                                   uint16 i1, uint16 i2, uint16 i3)
{
  // This calculates [(sum - i0)/2 - i1 - i2 - i3]/(3/2)
  //                = (sum - i0 - 2*i1 - 2*i2 - 2*i3)/3
  //
  // i0 is the column of the CDM matrix with a 0. i1-i3 are the
  // columns with -1.
  uint16 SCALE = (uint16) (65536.0 / (3.0 / 2.0) + 0.5);
  uint16 t;
  t = sum;
  t -= src[i0];
  t >>= 1;
  t -= src[i1];
  t -= src[i2];
  t -= src[i3];
  t = (uint16) (((uint32) t * SCALE) >> 16);
  *dst = t;
}

void decodeCDM10(uint16 *image, uint16 numEnabledTX, uint16 numEnabledRX)
{
  uint16 y[10];
  uint16 *x = image;
  uint16 startCluster = 0;
  uint16 rx;
  uint16 STRIDE = MAX_IMAGE_BUFFER_COLS;
  uint16 nextBlockIncrement = 10*MAX_IMAGE_BUFFER_COLS - numEnabledRX;
  while(startCluster < numEnabledTX)
  {
    uint16 rows = numEnabledTX - startCluster;
    if (rows > 10)
    {
      rows = 10;
    }
    for (rx = 0; rx < numEnabledRX; rx++)
    {
      uint16 s;
      uint16 i;
      uint16 *src;
      uint16 *dst;

      src = x;
      dst = y;
      for (i = 0; i < 10; i++)
      {
        *dst = *src;
        dst++;
        src += STRIDE;
      }

      s = sumVector(y, 1, 10);
      s += 2; // change truncation to round-up at 0.5
      s += 3*4096;

      doOneCDM10Pixel(s, y, &x[ 0*STRIDE], 0, 1, 2, 3);
      doOneCDM10Pixel(s, y, &x[ 1*STRIDE], 1, 0, 8, 9);
      doOneCDM10Pixel(s, y, &x[ 2*STRIDE], 2, 0, 6, 7);
      doOneCDM10Pixel(s, y, &x[ 3*STRIDE], 3, 0, 4, 5);
      doOneCDM10Pixel(s, y, &x[ 4*STRIDE], 4, 3, 7, 9);
      doOneCDM10Pixel(s, y, &x[ 5*STRIDE], 5, 3, 6, 8);
      doOneCDM10Pixel(s, y, &x[ 6*STRIDE], 6, 2, 5, 9);
      doOneCDM10Pixel(s, y, &x[ 7*STRIDE], 7, 2, 4, 8);
      doOneCDM10Pixel(s, y, &x[ 8*STRIDE], 8, 1, 5, 7);
      doOneCDM10Pixel(s, y, &x[ 9*STRIDE], 9, 1, 4, 6);

      if (rows < 10)
      {
        src = &x[(10-rows)*STRIDE];
        dst = x;
        for (i = 0; i < rows; i++)
        {
          *dst = *src;
          src += STRIDE;
          dst += STRIDE;
        }
      }
      x++;
    }
    startCluster += 10;
    x += nextBlockIncrement;
  }
}

void decodeCDM4(uint16 *image, uint16 numEnabledTX, uint16 numEnabledRX)
{
  uint16 fullClusters = numEnabledTX & 0xFFFC;
  int16 extraRows = numEnabledTX - fullClusters;
  uint16 *y = image;
  uint16 startCluster = 0;
  uint16 rx;
  uint16 STRIDE = MAX_IMAGE_BUFFER_COLS;
  uint16 nextBlockIncrement = 4*MAX_IMAGE_BUFFER_COLS - numEnabledRX;
  uint16 OFFSET = 4097; // add DC bias and round up when dividing
  while(startCluster < fullClusters)
  {
    for (rx = 0; rx < numEnabledRX; rx++, y++)
    {
      uint16 s = OFFSET;
      s += y[0*STRIDE];
      s += y[1*STRIDE];
      s += y[2*STRIDE];
      s += y[3*STRIDE];
      s >>= 1;

      y[0*STRIDE] = s - y[0*STRIDE];
      y[1*STRIDE] = s - y[1*STRIDE];
      y[2*STRIDE] = s - y[2*STRIDE];
      y[3*STRIDE] = s - y[3*STRIDE];
    }
    startCluster += 4;
    y += nextBlockIncrement;
  }
  if (extraRows > 0)
  {
    for (rx = 0; rx < numEnabledRX; rx++, y++)
    {
      uint16 s = OFFSET;
      s += y[0*STRIDE];
      s += y[1*STRIDE];
      s += y[2*STRIDE];
      s += y[3*STRIDE];
      s >>= 1;

      switch(extraRows)
      {
        case 3:
          y[2*STRIDE] = s - y[2*STRIDE];
        case 2:
          y[1*STRIDE] = s - y[1*STRIDE];
        case 1:
          y[0*STRIDE] = s - y[0*STRIDE];
      }
    }
  }
}
