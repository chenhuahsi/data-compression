/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2015 - 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 *
 */

/* -----------------------------------------------------------------
   Description: Noise mitigation for TDDI-AMP sensor in severely
                noisy environment. Chang segmenter configuration for 
                less finger split and use centroid positioning by 
                changing object type to palm and reporting every 
                object as fingers.
                Apply IIR with the fixed alpha which may be changed 
                to the adjustable values according to noise IM.

   $Id: extreme_noise_remover.c
----------------------------------------------------------------- */

#include "ifp_common.h"

#if CONFIG_HAS_EXTREME_NOISE_REMOVER

#include "extreme_noise_remover.h"
#include "segmenter.h"
#include "classifier.h"

static int16 extMinPeak_LSB;
static uint8p8 extMergeThreshold_pct;
static int16 extfingerLandingMaxFrames;
static uint8p8 extlandingFingerMinDeltaZ;
static float extAlpha;
static uint16 extRxCnt;
static uint16 extTxCnt;
static uint16 noiseStatePrev;
static int16 deltaPrev[(MAX_TX+2)*(MAX_RX+1)+1];

/* -----------------------------------------------------------------
Name: updateDeltaIIR()
Purpose: IIR filetering to the deltaImage with specified coefficient.
----------------------------------------------------------------- */
void updateDeltaIIR(int16 *deltaCurr)
{
  uint16 i, j, currIndex;

  for (i = 1; i <= extTxCnt; i++)
  {
    for (j = 1; j <= extRxCnt; j++)
    {
      currIndex = i*(MAX_RX+1)+j;
      deltaCurr[currIndex] = (int16)((1.f-extAlpha) * deltaCurr[currIndex] + 
                                  extAlpha  * deltaPrev[currIndex]);
      deltaPrev[currIndex] = deltaCurr[currIndex];
    }
  }
}


/* -----------------------------------------------------------------
Name: initDeltaIIR()
Purpose: initialize IIR fileter
----------------------------------------------------------------- */
void initDeltaIIR(int16 *deltaCurr)
{
  uint16 i, j, currIndex;

  for (i = 1; i <= extTxCnt; i++)
  {
    for (j = 1; j <= extRxCnt; j++)
    {
      currIndex = i*(MAX_RX+1)+j;
      deltaPrev[currIndex] = deltaCurr[currIndex];
    }
  }
}
void updateAlphaIIR()
{
  // extAlpha can be allocated per noise metric strength
}

void extreme_noise_remover_configure(segmenterConfig_t *sgConfig, classifierConfig_t *clsConfig, sensorParams_t *sensorParams, extremeNoiseRemoverConfig_t *eNoiseRemoverConfig)
{
  extMinPeak_LSB = sgConfig->minPeak_LSB;
  extMergeThreshold_pct = sgConfig->mergeThreshold_pct;
  extfingerLandingMaxFrames = clsConfig->fingerLandingMaxFrames;
  extlandingFingerMinDeltaZ = clsConfig->landingFingerMinDeltaZ;
  extRxCnt = sensorParams->rxCount;
  extTxCnt = sensorParams->txCount;
  extAlpha = ((float)eNoiseRemoverConfig->alpha)/256;
}

/* -----------------------------------------------------------------
Name: setSegmenterParams()
Purpose: Configure different parameters for segmenter per transition 
----------------------------------------------------------------- */
void setSegmenterParams(uint16 noiseStateCurr)
{
  if (noiseStateCurr != noiseStatePrev)
  {
    segmenterConfig_t config;
    classifierConfig_t tmpClassConfig;

    tmpClassConfig.fingerLandingMaxFrames = extfingerLandingMaxFrames;
    tmpClassConfig.landingFingerMinDeltaZ = extlandingFingerMinDeltaZ;

    if (noiseStateCurr)
    {
      config.minPeak_LSB = 50;
      config.mergeThreshold_pct = 0;

      if(tmpClassConfig.fingerLandingMaxFrames > 1)
         tmpClassConfig.fingerLandingMaxFrames = 1;   //prevent finger drop off
      if(tmpClassConfig.landingFingerMinDeltaZ > 12)
         tmpClassConfig.landingFingerMinDeltaZ = 12;  //prevent finger index switch (0.05)

         segmenter_configure(&config);
         classifier_setExtremeNoiseconfigure(&tmpClassConfig);
    }
    else
    {
      config.minPeak_LSB = extMinPeak_LSB;
      config.mergeThreshold_pct = extMergeThreshold_pct;
      tmpClassConfig.fingerLandingMaxFrames = extfingerLandingMaxFrames;
      tmpClassConfig.landingFingerMinDeltaZ = extlandingFingerMinDeltaZ;
      segmenter_configure(&config);
      classifier_setExtremeNoiseconfigure(&tmpClassConfig);
    }
    noiseStatePrev = noiseStateCurr;
  }
}

/* -----------------------------------------------------------------
Name: rephraseTouchType()
Purpose: Reassign classified object type to designated one. This routine
         is used to get centroid position when PositionEstimator calculates
         position of classified objects.
Note: If PositioEstimator revised to use different logic when extracting
      information for palm object, this routine shoud be updated accordingly.
----------------------------------------------------------------- */
void rephraseTouchType(trackedObject_t *tObjs, classification_t *cObjs, uint16 touchType, uint16 *originalTouchType)
{
  uint16 trackInd;
  trackedObject_t *track = tObjs;
  classification_t *classification = cObjs;

  for (trackInd = 0; trackInd < MAX_OBJECTS; trackInd++, track++, classification++)
  {
    uint16 clumpId = track->clumpId;

    if (clumpId == 0) continue;

    if ((classification->touchFlag) &&
        (classification->touchType == touchType_finger ||
         classification->touchType == touchType_glove  ||
         classification->touchType == touchType_smallObject||
         classification->touchType == touchType_stylus ||
         classification->touchType == touchType_eraser ||
         classification->touchType == touchType_palm))
    {
      if(touchType != touchType_none)
      {
        originalTouchType[trackInd] = classification->touchType;
        classification->touchType = touchType;
      } else if(originalTouchType[trackInd] != touchType_none)
      {
        classification->touchType = originalTouchType[trackInd];
        originalTouchType[trackInd] = touchType_none;
      }
    }
  }
}

#endif // CONFIG_HAS_EXTREME_NOISE_REMOVER
