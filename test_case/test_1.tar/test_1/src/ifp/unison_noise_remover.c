/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2013  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: Removes unison noise from the delta image
   $Id$
----------------------------------------------------------------- */

/* Unison Noise Removal Algorithm Overview -------------------------

   TBD.

------------------------------------------------------------------*/

#include "ifp_common.h"
#include "unison_noise_remover.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

/* =================================================================
   MODULE TYPES
==================================================================*/

/* =================================================================
   MODULE VARIABLES
==================================================================*/

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/
static void computeUnisonNoisePerRow(uint16 txCount, uint16 rxCount,
                                     int16 noiseFloor_LSB,
                                     int16 deltaImage[],
                                     int16 *unisonNoisePerRow);

static void removeUnisonNoise(int16 deltaImage[], clumps_t *clumps,
                              int16 clumpId, int16 *unisonNoisePerRow);

static int countClumps(clumps_t *clumps);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* ------------------------------------------------------------------------
Name: computeUnisonNoisePerRow()
Purpose: Estimates the unison noise on each row by averaging pixels under
         the noise floor.
Inputs: txCount, rxCount, noiseFloor_LSB, delta image
Outputs: unisonNoisePerRow - array of unison noise estimates
Effects: None.
Notes: This differs from averaging unlabeled pixels because of dam pixels
       between clumps.
Example: None.
------------------------------------------------------------------------- */
static void computeUnisonNoisePerRow(uint16 txCount, uint16 rxCount,
                                     int16 noiseFloor_LSB,
                                     int16 deltaImage[],
                                     int16 *unisonNoisePerRow)
{
  uint16 rowNum;
  int16 *pDelta;
  uint16 stride = MAX_RX + 1 - rxCount;
  pDelta = &deltaImage[MAX_RX+2];

  for (rowNum = 0; rowNum < txCount; rowNum++)
  {
    int32 sum = 0;
    int16 nPixels = 0;
    // Aggressively limit variable scope to save direct RAM.
    {
      uint16 colNum;
      for (colNum = rxCount; colNum > 0; colNum--)
      {
        if (*pDelta < noiseFloor_LSB && *pDelta > -noiseFloor_LSB)
        {
          sum += *pDelta;
          nPixels++;
        }
        pDelta++;
      }
    }
    pDelta += stride;

    {
      int16 unisonNoise;
      if (nPixels == 0)
      {
        unisonNoise = 0;
      }
      else if (sum >= 0)
      {
        unisonNoise = (sum + nPixels/2) / nPixels;
      }
      else  // (nPixels != 0) && (sum < 0)
      {
        unisonNoise = -((-sum + nPixels/2) / nPixels);  // control signed integer division rounding
      }
      unisonNoisePerRow[rowNum] = unisonNoise;
    }
  }
}

/* ------------------------------------------------------------------------
Name: removeUnisonNoise()
Purpose: Subtract estimated unison noise from a specified clump
Inputs: deltaImage, clumps struct,
        clumpId - the clump to subtract noise from
        unisonNoisePerRow - array of unison noise estimate values
Outputs: deltaImage
Effects: None.
Notes: unisonNoisePerRow excludes padding rows in delta image.
Example: None.
------------------------------------------------------------------------- */
static void removeUnisonNoise(int16 *deltaImage, clumps_t *clumps,
                              int16 clumpId, int16 *unisonNoisePerRow)
{
  uint16 rowNum, colNum;
  clumpInfo_t *clumpInfo;

  clumpInfo = &clumps->info[clumpId];
  rowNum = clumpInfo->firstPixel.row;
  colNum = clumpInfo->firstPixel.col;

  while(colNum != 0)
  {
    uint16 offset = rowNum * (MAX_RX + 1) + colNum;
    int16 correction = unisonNoisePerRow[rowNum-1];
    int16 *value = &deltaImage[offset];
    *value = (*value >= correction) ? (*value - correction) : 0;
    rowNum = clumps->listImage[offset].row;
    colNum = clumps->listImage[offset].col;
  }
}

/* -----------------------------------------------------------
Name: countClumps()
Purpose: Count the number of clumps present
Inputs: clumps
Outputs: number of clumps present
----------------------------------------------------------- */
static int countClumps(clumps_t *clumps)
{
  uint16 i;
  uint16 count = 0;
  clumpInfo_t *info = &clumps->info[0];
  for (i = 0; i < MAX_OBJECTS; i++, info++)
  {
    if (info->peakCount > 0)
    {
      count++;
    }
  }
  return count;
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: unisonNoiseRemover_remove()
Purpose: Estimate and remove unison noise from a delta image
Inputs: sensorParams
        deltaImage
        clumps
Outputs: modifies deltaImage in place
Notes: Only corrects unison noise under positive clumps, since
       they are the only clumps that the position estimator
       actually looks at.
----------------------------------------------------------- */
void unisonNoiseRemover_remove(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps)
{
  int16 unisonNoisePerRow[MAX_TX];

  if (countClumps(clumps) == 0)
  {
    return;
  }

  computeUnisonNoisePerRow(sensorParams->txCount, sensorParams->rxCount,
                           sensorParams->noiseFloor_LSB, deltaImage,
                           unisonNoisePerRow);

  {
    int clumpId;
    clumpInfo_t *clumpInfo = &clumps->info[0];
    for (clumpId = 0; clumpId < MAX_OBJECTS; clumpId++, clumpInfo++)
    {
      if (clumpInfo->peakCount > 0 && clumpInfo->polarity == clumpPolarity_positive)
      {
        removeUnisonNoise(deltaImage, clumps, clumpId, unisonNoisePerRow);
      }
    }
  }
}
