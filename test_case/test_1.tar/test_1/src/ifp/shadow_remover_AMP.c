/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Description: Removes shadow artifacts from delta image
----------------------------------------------------------------- */

#include "ifp_common.h"
#include "shadow_remover_AMP.h"

#if CONFIG_HAS_SHADOW_REMOVER_AMP

/* =================================================================
   MODULE VARIABLES
==================================================================*/
 uint0p16 minFingerThreshold;
// shadowDirection_t shadowDirection;
//uint16 shadowThreshold;

/* =================================================================
   MODULE STATIC FUNCTIONS DECLARATIONS
==================================================================*/
// static void removeColShadows(int16* deltaImage, sensorParams_t* sensorParams, int16 fingerThreshold);
static void removeRowShadows(int16* deltaImage, sensorParams_t* sensorParams, int16 fingerThreshold);
static uint16 check3x3Block(int16 *ptr, int16 threshold, int16 flag);
static void calcLinearLeastSquaresFit(int16 *array, uint16 arraySize, uint16 stepSize, int16 noiseFloor);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/
// // -----------------------------------------------------------------
// // Name:    removeColShadows()
// // Purpose: Remove shadows along cols
// // Inputs:  deltaImage - pointer to delta image to be overwritten with
// //                       its estimate without shadows along cols
// //          sensorParams - sensor parameters
// //          fingerThreshold - finger threshold
// // Outputs: None.
// // Effects: None.
// // Notes:   None.
// // Example: None.
// // -----------------------------------------------------------------
// static void removeColShadows(int16* deltaImage,
//                              sensorParams_t* sensorParams,
//                              int16 fingerThreshold)
// {
//   uint16 col;
//   uint16 maxRows = sensorParams->txCount;
//   uint16 maxCols = sensorParams->rxCount;

//   for (col = 1; col <= maxCols; col++)
//   {
//     uint16 row = 1;
//     uint16 startRow = 1;

//     while (row < maxRows+1)
//     {
//       // Traverse down the col till a finger blob is encountered
//       while ((row <= maxRows) && (!check3x3Block(&deltaImage[row*(MAX_RX+1) + col], fingerThreshold)))
//       {
//         row++;
//       }

//       if (row > 1)
//       {
//         // Subtract the least squares estimate of the shadow region from the delta image
//         calcLinearLeastSquaresFit(&deltaImage[startRow*(MAX_RX+1) + col],
//                                   row-startRow,
//                                   MAX_RX+1,
//                                   sensorParams->noiseFloor_LSB >> 1);
//       }

//       // If a blob is found, traverse down the col till the end of the blob is reached
//       while ((row <= maxRows) && (check3x3Block(&deltaImage[row*(MAX_RX+1) + col], fingerThreshold)))
//       {
//         row++;
//       }
//       startRow = row;
//     }
//   }
// }

// -----------------------------------------------------------------
// Name:    removeRowShadows()
// Purpose: Remove shadows along rows
// Inputs:  deltaImage - pointer to delta image to be overwritten with
//                       its estimate without shadows along rows
//          sensorParams - sensor parameters
//          fingerThreshold - finger threshold
// Outputs: None.
// Effects: None.
// Notes:   None.
// Example: None.
// -----------------------------------------------------------------
static void removeRowShadows(int16* deltaImage,
                             sensorParams_t* sensorParams,
                             int16 fingerThreshold)
{
  uint16 row;
  uint16 maxRows = sensorParams->txCount;
  uint16 maxCols = sensorParams->rxCount;
  int16 flag;

  for (row = 1; row <= maxRows; row++)
  {
    uint16 col = 1;
    uint16 startCol = 1;
    uint16 blobFound = 0;
    uint16 offset = row*(MAX_RX+1);

    while (col < maxCols+1)
    {
      // Traverse across the row till a finger blob is encountered
      if(row == 1)
        flag = 0x1;
      else if(row == maxRows)
        flag = 0x2;
      else
        flag = 0x3;
      while ((col <= maxCols) && (!check3x3Block(&deltaImage[offset + col], fingerThreshold, flag)))
      {
        col++;
      }

      // No finger found? then, there's no shadow! check the next row.
      // Finger on the edge? then, do not clear the shadow because the calculation on edge is different.
      // Noted, we still need to clear the pixels between the end of blob and the end of row!
      // That's why I add blobFound here
      if((col == maxCols + 1) && (blobFound == 0))
        break;
      else if ((col > 0) && ((col < maxCols) || (blobFound > 0)))
      {
        // Subtract the least squares estimate of the shadow region from the delta image
        if (col > 1)
          calcLinearLeastSquaresFit(&deltaImage[offset + startCol],
                                  col-startCol,
                                  1,
                                  sensorParams->noiseFloor_LSB >> 3);
        blobFound++;
      }

      // If a blob is found, traverse across the row till the end of the blob is reached
      while ((col <= maxCols) && (check3x3Block(&deltaImage[offset + col], fingerThreshold, flag)))
      {
        col++;
      }
      startCol = col;
    }
  }
}

/* -----------------------------------------------------------
Name: check3x3Block
Purpose: Checks if a pixel or the 3x3 block around it is above a threshold
Inputs:  pointer to a pixel in input image, threshold
Outputs: True if the pixel or any of its 8 neighbors are greater than threshold,
         False otherwise
Effects: None.
Notes: None.
----------------------------------------------------------- */
static uint16 check3x3Block(int16 *ptr, int16 threshold, int16 flag)
{
  int16 *tmpPtr;
  uint16 preRet = 0;
  ptr -= MAX_RX+2;
  if(flag & 0x1)
  {
    preRet |= (ptr[3*MAX_RX+4] >= threshold);
  }
  if(flag & 0x2)
  {
    tmpPtr = ptr - MAX_RX;
    preRet |= (tmpPtr[0] >= threshold);
  }
  return preRet || (ptr[0]          >= threshold) ||
         (ptr[1]          >= threshold) ||
         (ptr[2]          >= threshold) ||
         (ptr[MAX_RX+1]   >= threshold) ||
         (ptr[MAX_RX+2]   >= threshold) ||
         (ptr[MAX_RX+3]   >= threshold) ||
         (ptr[2*MAX_RX+2] >= threshold) ||
         (ptr[2*MAX_RX+3] >= threshold) ||
         (ptr[2*MAX_RX+4] >= threshold);
}

// -----------------------------------------------------------------
// Name:    calcLinearLeastSquaresFit()
// Purpose: Finds the difference between input array and its linear least squares estimate.
// Inputs:  array - pointer to input array, to be replaced with output
//          arraySize - size of array
//          stepSize - step to increment pointer to access next element of array
// Outputs: None.
// Effects: None.
// Notes:   None.
// Example: None.
// -----------------------------------------------------------------
static void calcLinearLeastSquaresFit(int16 *array,
                                      uint16 arraySize,
                                      uint16 stepSize,
                                      int16 noiseFloor)
{
  if (arraySize > 1)
  {
    uint16 firstEl = 0;
    uint16 lastEl = firstEl + ((arraySize-1) * stepSize);

    // Restrict the shadow removal to the region above noise floor.
    // Traverse the array from left to right
    while ((firstEl < lastEl) && (array[firstEl] < noiseFloor))
    {
      firstEl += stepSize;
    }

    // Traverse the array from right to left
    while ((lastEl > firstEl) && (array[lastEl] < noiseFloor))
    {
      lastEl -= stepSize;
    }

    // Replace array with its linear least squares estimate
    if (firstEl < lastEl)
    {
      int4p12 slope;
      int8p8 xMean;
      int16 i, xSum = 0, ySum = 0, count = 0;
      int24p8 yMean, xTx = 0, xTy = 0;
      int16 *pArray = &array[firstEl];
      int16 n = ((lastEl - firstEl)/stepSize) + 1;
      int16 k = firstEl/stepSize;

      for (i = 0; i < n; i++)
      {
        xSum += k + i;
        ySum += *pArray;
        count++;
        pArray += stepSize;
      }

      if (count > 2)
      // Correct for shadows only if we have enough points to estimate the linear fit
      {
        xMean = (int8p8) ((int32) 256*xSum / count);
        yMean = (int24p8) ((int32) 256*ySum / count);

        pArray = &array[firstEl];
        for (i = 0; i < n; i++)
        {
          int8p8 xPrime = (int8p8)((int32)(k + i) * 256) - xMean;
          int24p8 yPrime = (int24p8)((int32)*pArray * 256) - yMean;
          xTx += (int24p8)(((int32)xPrime * xPrime) >> 8);
          xTy += (int24p8)((int32)(k + i) * yPrime);
          pArray += stepSize;
        }

        if (xTx != 0)
        {
          slope = (int4p12)((int32)(xTy << 6) / (xTx >> 6));
          pArray = array;
          for (i = 0; i < (int16)arraySize; i++)
          {
            int8p8 mx = (int8p8) (((int32)slope * (256*i - xMean)) >> 12);
            int16 leastSqEstimate = (int16)(((int32)mx + yMean + 256) >> 8);
            if (leastSqEstimate > 0)
            {
              if (leastSqEstimate > *pArray)
              {
                *pArray = 0;
              }
              else
              {
                *pArray -= leastSqEstimate;
              }
            }
            pArray += stepSize;
          }
        }
      }
      else
      {
        pArray = &array[firstEl];
        for (i = 0; i < n; i++)
        {
          *pArray = noiseFloor;
          pArray += stepSize;
        }
      }
    }
  }
}

/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/
/* -----------------------------------------------------------
Name: shadowRemoverAMP_configure
Purpose: Configures shadowRemoverAMP
Inputs: shadowRemoverAMPConfig_t structure
Outputs: None.
Effects: Must be called *before* init() or reinit().
Notes: None.
----------------------------------------------------------- */
void shadowRemoverAMP_configure(ampShadowRemoverConfig_t *config)
{
  minFingerThreshold = config->minFingerThreshold;
}

/* -----------------------------------------------------------
Name: shadowRemoverAMP_remove
Purpose: Removes shadow artifacts from delta image
Inputs: deltaImage, sensorParams
Outputs: None.
Effects: Shadow artifacts in the delta image are removed.
Notes: None.
----------------------------------------------------------- */
void shadowRemoverAMP_remove(int16* deltaImage,
                             sensorParams_t* sensorParams)
{
    int16 fingerThreshold = ((uint32)minFingerThreshold * sensorParams->cSat_LSB) >> 16;
    // Remove shadows along rows
    removeRowShadows(deltaImage, sensorParams, fingerThreshold);
}

#endif   //- #if CONFIG_HAS_SHADOW_REMOVER_AMP
