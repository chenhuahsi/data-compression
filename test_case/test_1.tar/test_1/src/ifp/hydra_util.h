#ifndef _IFP_HYDRA_UTIL_H_
#define _IFP_HYDRA_UTIL_H_
// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// -----------------------------------------------------------------
//
//
// Filename: hydra_util.h
// Description: Header file for hydra_util.c
//
// $Id:$

#if !defined(_SYNA_TYPES_H) && !defined(SILICON_H) && !defined(_IFP_H)
  #error uint16, and friends are not defined. Make sure to include hydra_util.h after one of the files that provide these definitions. For example stdlib.h, silicon.h, or ifp.h.
#endif

#include "calc_config.h"

#ifndef CONFIG_INHIBIT_HYDRA
#define CONFIG_INHIBIT_HYDRA 0
#endif

//__T100X_HAS_HYDRA__
//0 - No Hydra Coprocessor present
//1 - Hydra spec revision 1.1 / Hydra 1
//2 - Hydra spec revision 2.5 / Hydra 2
//3 - Hydra spec revision 2.13 / Hydra 2
//4 - Hydra spec revision 2.50 / Hydra 2e

#if defined(__CHIMERA__) && (__T100X_HAS_HYDRA__ > 2 && CONFIG_INHIBIT_HYDRA == 0)
  void hydra_enable(void);
  void hydra_disable(void);
#else
  static ATTR_INLINE void hydra_enable() {};
  static ATTR_INLINE void hydra_disable() {};
#endif

#if defined(__CHIMERA__) && (__T100X_HAS_HYDRA__ > 2 && CONFIG_INHIBIT_HYDRA == 0)

// Matrix-Vector and Matric-Matrix float multiplication examples
// Assembly needs protection from C++ name mangling.
#ifdef __cplusplus
    extern "C" {
#endif
void matTimesVec_floatFloat(uint16 rows, uint16 cols, float *mat, float *vec, float *result);
void matTimesMat_floatFloat(uint16 rowsA, uint16 colsA, uint16 colsBC, float *mat, float *vec, float *result);
#ifdef __cplusplus
    }
#endif

// Vector addition and subtraction examples (int16)
void subtractFit(int16 *row, int16 *fit, int16 *res, uint16 *flags, uint16 len);
void addFit(int16 *row, int16 *fit, int16 *res, uint16 *flags, uint16 len);
void subtractFitDelta(int16 *row, uint16 rowLen, int16 *fit, uint16 *flags);
void subtractFitRaw(uint16 *row, uint16 rowLen, int16 *fit, uint16 *flags, uint16 flipSign);
void subtractFitIndexed(int16 *row, int16 *fit, int16 *res, uint16 *index, uint16 *flags, uint16 len);
void subtractFitMasked(int16 *row, int16 *fit, int16 *res, uint16 *mask, uint16 *flags, uint16 len);

// Scalar product examples
void vecTimesVec_floatFloat(uint16 len, float *vec1, float *vec2, float *result);
void vecTimesVec_floatFloatIndexed(uint16 len, uint16* index, float *vec1, float *vec2, float *result);
void vecTimesVec_floatFloatMasked(uint16 len, uint16* mask, float *vec1, float *vec2, float *result);
void vecTimesVec_floatFloatDoubleIndexed(uint16 len, uint16* index1, uint16* index2, float *vec1, float *vec2, float *result);
void vecTimesVec_floatFloatDoubleStride(uint16 len, uint16 stride1, uint16 stride2, float *vec1, float *vec2, float *result);
void vecTimesVec_int16Int16(uint16 len, int16 *vec1, int16 *vec2, int32 *result);
void vecTimesVec_int16Int16Stride1(uint16 len, int16 *vec1, int16 *vec2, uint16 stride1, int32 *result);

// Element-wise vector multiplication examples
void multiply_floatFloat(uint16 len, float *vec1, float *vec2, float *result);
void multiply_floatFloatMasked(uint16 len, uint16 *mask, float *vec1, float *vec2, float *result);
void multiply_floatFloatIndexed(uint16 len,  uint16 *indexSrc, uint16 *indexDest, float *vec1, float *vec2, float *result);

// Hydra memset (4 times faster then regular memset asymptotically, starts being faster for n ~ 20 )
void hydra_memset16(void *pointer, int16 val, uint16 n);

// Delta Image projection for trans-abs comparison and consistency checks
void projectDeltaImage(uint16 rxCount, uint16 txCount, int16 *deltaImage, int32 *projTX, int32 *projRX);

void subtractBaseline(uint16 *rawImage, uint16 *baseline, int16 *deltaImage, uint16 rxCount, uint16 txCount);
#endif

#endif //_IFP_HYDRA_UTIL_H_
