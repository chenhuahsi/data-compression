//==============================================================================
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2014  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 Mckay Drive
// San Jose, CA 95131
// (408) 904-1100
//

/*
 * LGMCORRECTOR.h
 *
 *
 */

#ifndef _LGM_CORRECTOR_H_
#define _LGM_CORRECTOR_H_

#if CONFIG_HAS_LGM_CORRECTOR
void lgmCorrector_init(void);
void lgmCorrector_reinit(void);
void lgmCorrector_correct(int16 *pDeltaImage, int16 *pdeltaXProfile, int16 *pdeltaYProfile,  sensorParams_t *pSensorParams, lgmManagerParams_t *lgmManagerParams);
#else
static ATTR_INLINE void lgmCorrector_init(void) {};
static ATTR_INLINE void lgmCorrector_reinit(void) {};
static ATTR_INLINE void lgmCorrector_correct(ATTR_UNUSED int16 *pDeltaImage,
                                             ATTR_UNUSED int16 *pdeltaXProfile,
                                             ATTR_UNUSED int16 *pdeltaYProfile,
                                             ATTR_UNUSED sensorParams_t *pSensorParams,
                                             ATTR_UNUSED lgmManagerParams_t *lgmManagerParams) {};
#endif // CONFIG_HAS_LGM_CORRECTOR

#endif
