/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Description: Splits clumps in two when their profiles show two peaks
   $Id$
----------------------------------------------------------------- */

/* Linear Swipe Splitter Algorithm Overview --------------------------------
 *
 * The segmentation algorithm splits clumps by projecting to a profile
 * and then fitting valleys between peaks. Projections are taken at -45,
 * 0, 45 and 90 degree angles by summing pixels belonging to the clump
 * along those axes. The split lines will in general cross pixels, which
 * then implicitly have partial membership in two blobs.
 *
 * Which of the four angles is chosen for the split depends on the
 * calculation of a figure of merit for each profile. The current FoM
 * is maximum contrast between a valley height and the height of its
 * lower adjacent peaker.

------------------------------------------------------------------*/

#include "ifp_common.h"

#if CONFIG_HAS_LINEAR_SWIPE_SPLITTER

#include "ifp_string.h"
#include "linear_swipe_splitter.h"
#include "clump_projector.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/

#define NUMFINGERS 5
#define MIN(a, b) ((a < b) ? a : b)
#define MAX(a, b) ((a > b) ? a : b)

/* =================================================================
   MODULE TYPES
==================================================================*/

typedef struct {
    uint10p6 merit;
    uint8p8 valleyPositions[NUMFINGERS];
    uint16 peakValues[NUMFINGERS];
    uint16 valleyValues[NUMFINGERS];
    uint10p6 contrasts[NUMFINGERS];
    uint16 splitCount : 4;
    uint16 firstSplit : 4;
    uint16 splitAxis : 2;  // in C, cannot portably use enums in bitfields
    uint16 valleyCount : 4;
} splitCandidate_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/

// configuration knobs
static uint0p16 lengthTailArea_pct;  // Fraction of z to ignore at each end for projected length computation
static uint8p8 clumpLengthThresholds[4];  // Minimum clump lengths eligible for splitting
static uint0p16 minPeakSplitThreshold_pct; // Min peak values of projected profile for split to be possible
static uint10p6 minContrastThreshold;  // contrast threshold for splits along 0 or 90 degrees. Individual
                                       // contrast should be greater than the threshold for a clump to be split
static uint10p6 minContrastThresholdDiag;  // contrast threshold for splits along 45 or -45 degrees
static uint16 minContrastPeakAmp;    // Knee value based on % of cSat_LSB for projected profiles to
                                     // be split
static uint16 unscaledMinContrastPeakAmp;    // When applying adaptive LGM algorithm, cSat_LSB may be adaptively
                                             // changed every frame, unscaledMinContrastPeakAmp saves the value 
                                             // from config and minContrastPeakAmp saves the value of 
                                             // (unscaledMinContrastPeakAmp * compensationFactor)

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/
static void isocelesValley(uint16* proj, uint16 index, uint8p8 *x);

static uint8p8 computeProjectedLength(uint16 *profile, uint16 arrayLength, uint0p16 lengthTailArea_pct);

static void splitClumpAlongAxisOrPerp(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps, uint16 clumpId, splitAxis_t axis, splitCandidate_t *candidate);

static void computeValleyPartition(uint16 *profile, uint16 arrayLength, uint16 minPeakSplitThreshold, uint16 valleyClipThreshold, splitCandidate_t *candidate);

static void computeContrast(uint16 *profile, uint16 arrayLength, uint10p6 minContrastThreshold, uint16 minContrastPeakAmp, splitCandidate_t *candidate);

ATTR_INLINE static uint16 copySplitData(splitCandidate_t *candidate, uint16 clumpId, uint16 firstSplit, clumps_t *clumps);

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: linearSwipeSplitter_configure
Purpose: Configures linear_swipe_splitter
Inputs: sensor params and linear swipe splitter config
        linearSwipeSplitterConfig_t contains:
        clumpLengthThreshold_mm - the min splittable clump length
        lengthTailArea_pct - fraction of z to ignore at each end of projection for length calculation
        minPeakSplitThreshold_pct - the min splittable peak amplitude relative to max peak
        minContrastThreshold - contrast threshold for splits along 0/90 degrees
        minContrastThresholdDiag - contrast threshold for splits along 45/-45 degrees
        minContrastPeakAmp_pct - raise contrast threshold for max peak amplitudes smaller than this fraction of cSat
Outputs: None.
Effects: Must be called *before* init() or reinit().
Notes: None.
----------------------------------------------------------- */
void linearSwipeSplitter_configure(sensorParams_t *sensorParams, linearSwipeSplitterConfig_t *config)
{
    uint4p12 diagPitch_mm;
    {
        /* Approximate sqrt(a^2 + b^2) w/ nearly a approximately equal to b. */
        int4p12 diff = (int4p12) sensorParams->rxPitch_mm - sensorParams->txPitch_mm;
        int4p12 temp = (uint4p12) (sensorParams->txPitch_mm + (diff >> 1));
        diagPitch_mm = (uint4p12) (((uint32) temp * 46341) >> 15);  // temp * sqrt(2)
    }

    clumpLengthThresholds[splitAxis_0] = (uint8p8) (((uint32) config->clumpLengthThreshold_mm << 16) / sensorParams->rxPitch_mm);  // 12p20 / 4p12 = 8p8
    clumpLengthThresholds[splitAxis_90] = (uint8p8) (((uint32) config->clumpLengthThreshold_mm << 16) / sensorParams->txPitch_mm);  // 12p20 / 4p12 = 8p8
    clumpLengthThresholds[splitAxis_45] = (uint8p8) (((uint32) config->clumpLengthThreshold_mm << 16) / diagPitch_mm * 2);  // 12p20 / 4p12 = 8p8
    clumpLengthThresholds[splitAxis_minus_45] = clumpLengthThresholds[splitAxis_45];

    lengthTailArea_pct    = config->lengthTailArea_pct;
    minContrastThreshold  = config->minContrastThreshold;
    minContrastThresholdDiag    = config->minContrastThresholdDiag;

    unscaledMinContrastPeakAmp  = ((uint32)(config->minContrastPeakAmp_pct) * sensorParams->cSat_LSB)/65536; // 0.55 * cSat_LSB
    minPeakSplitThreshold_pct   = config->minPeakSplitThreshold_pct;
}

/* -----------------------------------------------------------
Name: linearSwipeSplitter_split
Purpose: Splits clumps if their profiles show peaks and valleys
Inputs: delta image, clumps structure
Outputs: modified clumps structure
Effects: None.
Notes: 1) Clumps are split along the X or Y dimension or the two
       diagonals.
       2) This assumes that profiles will fit into 16-bit unsigned
       numbers. If this is not the case (huge sensor with high gain),
       then you will need to modify this code to use 32-bit profiles.
       3) A single clump can only be split into NUMFINGERS (5) blobs.
----------------------------------------------------------- */
void linearSwipeSplitter_split(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps)
{
    uint16 firstSplit = 0;
    uint16 clumpId;

    minContrastPeakAmp = unscaledMinContrastPeakAmp;

    for (clumpId = 1; clumpId <= MAX_OBJECTS; clumpId++)
    {
        if ((clumps->info[clumpId - 1].polarity == clumpPolarity_positive)
         && (clumps->info[clumpId - 1].peakCount > 1)
         && (clumps->info[clumpId - 1].preventSplit == 0))
        {
            splitCandidate_t candidate_0, candidate_45;

            /* Choose between 0 vs 90, 45 vs -45 inside splitClumpAlongAxisOrPerp
               based on length, then choose overall winner here based on merit. */
            splitClumpAlongAxisOrPerp(sensorParams, deltaImage, clumps, clumpId, splitAxis_0, &candidate_0);
            splitClumpAlongAxisOrPerp(sensorParams, deltaImage, clumps, clumpId, splitAxis_45, &candidate_45);

            // If merit > 0, then all fields are populated and we want to copy the results out.
            // NB: firstSplit will keep incrementing as necessary.
            if (candidate_0.merit > minContrastThreshold && candidate_0.merit >= candidate_45.merit)
            {
                firstSplit = copySplitData(&candidate_0, clumpId, firstSplit, clumps);
            }
            else if (candidate_45.merit > minContrastThresholdDiag)
            {
                firstSplit = copySplitData(&candidate_45, clumpId, firstSplit, clumps);
            }
        }
    }
}

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: splitClumpAlongAxisOrPerp
Purpose: Splits a clump along a given axis or its perpendicular
Inputs: sensorParams structure
        deltaImage
        clumps structure,
        clumpId - the clump to split
        splitAxis - direction to split along
Outputs: candidate - structure containing info on possible splits
Effects: none
Notes: none
----------------------------------------------------------- */
static void splitClumpAlongAxisOrPerp(sensorParams_t *sensorParams, int16 *deltaImage, clumps_t *clumps, uint16 clumpId, splitAxis_t axis, splitCandidate_t *candidate)
{
    uint16 projU[MAX_TX + MAX_RX - 1];
    uint16 projV[MAX_TX + MAX_RX - 1];
    uint16 arrayLength, otherArrayLength;
    splitAxis_t oldAxis;
    splitAxis_t otherAxis = splitAxis_90;

    if (axis == splitAxis_0)
    {
        otherAxis = splitAxis_90;
        arrayLength = sensorParams->rxCount;
        otherArrayLength = sensorParams->txCount;
    }
    else if (axis == splitAxis_90)
    {
        otherAxis = splitAxis_0;
        arrayLength = sensorParams->txCount;
        otherArrayLength = sensorParams->rxCount;
    }
    else if (axis == splitAxis_45)
    {
        otherAxis = splitAxis_minus_45;
        arrayLength = MAX_TX + sensorParams->rxCount - 1;
        otherArrayLength = arrayLength;
    }
    else // (axis == splitAxis_minus_45)
    {
        otherAxis = splitAxis_45;
        arrayLength = MAX_TX + sensorParams->rxCount - 1;
        otherArrayLength = arrayLength;
    }

    memset16(candidate, 0, sizeof(*candidate) / sizeof(uint16));

    // Project
    oldAxis = (splitAxis_t) clumps->info[clumpId - 1].splitAxis;
    clumps->info[clumpId - 1].splitAxis = (uint16) axis;
    #if CONFIG_HAS_CUSTOM_SPLITTER
    sensorParams->Splitter.Length_U = arrayLength;
    sensorParams->Splitter.Length_V = otherArrayLength;
    #endif
    clumpProjector_getProjectionUV(clumps, clumpId, -1, deltaImage, &projU[0], &projV[0]
    #if CONFIG_HAS_CUSTOM_SPLITTER
    , sensorParams
    #endif
    );
    clumps->info[clumpId - 1].splitAxis = (uint16) oldAxis;

    {
        // Choose longer axis
        uint16 longerProfileArrayLength;
        uint16 *longerProfile;
        uint8p8 lengthU, lengthV;
        lengthU = computeProjectedLength(&projU[0], arrayLength, lengthTailArea_pct);
        lengthV = computeProjectedLength(&projV[0], otherArrayLength, lengthTailArea_pct);

    #if CONFIG_HAS_CUSTOM_SPLITTER
      if (sensorParams->Splitter.Enable && sensorParams->Splitter.TakeDeeper)
      {
        uint16 uv;
        splitCandidate_t c[2];
        memset16(c, 0, sizeof(c) / sizeof(uint16));
        c[0].splitAxis = axis;
        c[1].splitAxis = otherAxis;
        for (uv = 0; uv < 2; uv++)
        {
          uint8p8 l = lengthU;
          splitAxis_t a = axis;
          uint16 *p = &projU[0];
          uint16 al = arrayLength;
          if (uv)
          {
            l = lengthV;
            a = otherAxis;
            p = &projV[0];
            al = otherArrayLength;
          }
          if (l > clumpLengthThresholds[a])
          {
            computeValleyPartition(p, al, minPeakSplitThreshold_pct, (uint16) sensorParams->noiseFloor_LSB, &c[uv]);
            if (c[uv].valleyCount)
            {
              computeContrast(     p, al, minContrastThreshold,      minContrastPeakAmp,                    &c[uv]);
              uint16 i;
              uint16 *contrast = c[uv].contrasts;
              uint16 maxMerit = 0;
              for (i = 0; i < NUMFINGERS; i++, contrast++)
              {
                  if (*contrast > maxMerit) maxMerit = *contrast;
              }
              c[uv].merit = maxMerit;
            }
          }
        }

        *candidate = c[0].merit < c[1].merit ? c[1] : c[0];
      }
      else
    #endif
      {
        if (lengthU > lengthV &&
            lengthU > clumpLengthThresholds[axis])
        {
            candidate->splitAxis = (uint16) axis;
            longerProfile = &projU[0];
            longerProfileArrayLength = arrayLength;
        }
        else if (lengthV > lengthU &&
                 lengthV > clumpLengthThresholds[otherAxis])
        {
            candidate->splitAxis = (uint16) otherAxis;
            longerProfile = &projV[0];
            longerProfileArrayLength = otherArrayLength;
        }
        else
        {
            return;
        }

        // Compute peaks and valleys
        computeValleyPartition(longerProfile, longerProfileArrayLength, minPeakSplitThreshold_pct, (uint16) sensorParams->noiseFloor_LSB, candidate);

        if (candidate->valleyCount > 0)
        {
            // Check to see if each split is valid by checking
            // individual contrast measures with contrastThreshold.
            computeContrast(longerProfile, longerProfileArrayLength, minContrastThreshold, minContrastPeakAmp, candidate);

            // We'll define the merit as the max contrast.
            {
                uint16 i;
                uint16 *contrast = candidate->contrasts;
                uint16 maxMerit = 0;
                for (i = 0; i < NUMFINGERS; i++, contrast++)
                {
                    if (*contrast > maxMerit) maxMerit = *contrast;
                }
                candidate->merit = maxMerit;
            }
        }
      }
    }
}

/* -----------------------------------------------------------
Name: isocelesValley
Purpose: For a given valley location, interpolate the tip of an
         isoceles triangle whose base is set by the higher
         adjacent pixel. This is used to refine the valley
         location.
Inputs: projection
        nearest index to valley (local minimum)
Outputs: interpolated valley position
Effects: none
Notes: none
----------------------------------------------------------- */
static void isocelesValley(uint16* proj, uint16 index, uint8p8 *x)
{
    int8p8 dx;
    int16 a = proj[index-1] - proj[index];
    int16 b = proj[index+1] - proj[index];
    int16 slope = b < a ? a : b;
    dx = (((int32) proj[index-1] - proj[index+1]) << 7) / slope; // correction (frac of pixel) relative to index
    *x = (index << 8) + dx;
}

/* -----------------------------------------------------------
Name: computeProjectedLength
Purpose: For a given clump projection, estimate the distance
         between the Xth and (1-X)th percentiles in the
         cumulative sum.
Inputs: projection
        fraction of tail to ignore on each end
Outputs: clump length in pixels
Effects: none
Notes: We clip the length from below at 2 pixels.
----------------------------------------------------------- */
static uint8p8 computeProjectedLength(uint16 *profile, uint16 arrayLength, uint0p16 lengthTailArea_pct)
{
    uint32 leftTailCutoff, rightTailCutoff;
    uint16 minIndex, maxIndex;
    uint16 minTotal, maxTotal;  // tail sums at minIndex and maxIndex
    uint8p8 projectedWidth = 0, computedWidth;

    // Compute tail cutoff as fraction of total.
    {
        uint16 i;
        uint32 total = 0;
        uint16 *profPtr = profile;
        for(i = 0; i < arrayLength; i++)
        {
            total += *profPtr++;
        }
        // total surely fits in 24 bits, though it can definitely exceed 16.
        // To make sure that the intermediate multiply fits in 32 bits, only
        // use lengthTailArea_pct as 0p8. Then 0p8 * 24p0 = 24p8.
        leftTailCutoff = (((lengthTailArea_pct >> 8) * total)) >> 8;
        rightTailCutoff = total - leftTailCutoff;
    }

    // Accumulate from left until we hit tail area and (total - tail area).
    {
        uint16 i;
        uint32 total = 0;
        uint16 *profPtr = profile;
        for(i = 0; i < arrayLength; i++, profPtr++)
        {
            total += *profPtr;
            if (total >= leftTailCutoff) break;
        }
        minIndex = i;
        minTotal = total;
        total -= *profPtr; // back it up and try the same index again
        for(i = minIndex; i < arrayLength; i++, profPtr++)
        {
            total += *profPtr;
            if (total >= rightTailCutoff) break;
        }
        maxIndex = i;
        maxTotal = total;
    }

    if (minIndex != maxIndex)
    {
        // Find the interpolated positions.
        uint8p8 minPos = 0, maxPos = 0;
        if (minIndex > 0)
        {
            uint16 slope = profile[minIndex];
            uint16 dy = (uint16) (minTotal - leftTailCutoff);
            uint8p8 dx = (dy << 8) / slope;
            minPos = (minIndex << 8) - dx;
        }
        else
        {
            minPos = 0;
        }
        if (maxIndex < arrayLength)
        {
            uint16 slope = profile[maxIndex];
            uint16 dy = (uint16) (maxTotal - rightTailCutoff);
            uint8p8 dx = (dy << 8) / slope;
            maxPos = (maxIndex << 8) - dx;
        }
        else
        {
            maxPos = arrayLength;
        }
        // The difference between maxPos and the minPos is the width.
        projectedWidth = (uint8p8) (maxPos - minPos);
    }
    // Set minimum projected length to at least 2. We are not interested
    // in smaller widths and also to make sure that aspect ratio computation does not blow up.
    computedWidth = MAX(projectedWidth, 2 << 8);
    return computedWidth;
}

/* -----------------------------------------------------------
Name: computeValleyPartition
Purpose: Find peaks and valleys in a clump projection
Inputs: projection
        min fraction of max peak to consider for secondary peaks
        value at which to clip valleys
Outputs: update peakValues, valleyPositions, and valleyValues in candidate
Effects: none
Notes: Will stop splitting at NUMFINGERS-1 (4) splits.
----------------------------------------------------------- */
static void computeValleyPartition(uint16 *profile, uint16 arrayLength, uint0p16 minPeakSplitThreshold_pct,
                                   uint16 valleyClipThreshold, splitCandidate_t *candidate)
{
    // walk across the profile noting when we switch between nondescending and
    // nonascending states to produce a consistent set of alternating peaks and
    // valleys.
    // To be considered as a peak, the projected value should be greater than
    // minPeakSplitThreshold_pct * maxPeakVal. The valleys less than
    uint16 i;
    uint16 tempPeakIndex = 0, tempValleyIndex = 0;
    uint16 tempPeakPos[NUMFINGERS], tempValleyPos[NUMFINGERS];
    uint16 searchingForPeak = 1;
    uint16 curVal, maxVal, maxValPos=0, minVal, minValPos=0;
    uint16 minPeakSplitThreshold;

    // Set peak threshold relative to highest peak.
    {
        uint16 maxPeakVal = 0;
        uint16 *prof = profile;
        for (i = 0; i < arrayLength; i++, prof++)
        {
            if (*prof > maxPeakVal) maxPeakVal = *prof;
        }
        minPeakSplitThreshold = (uint16) (((uint32)minPeakSplitThreshold_pct * maxPeakVal) >> 16);
    }

    if (minPeakSplitThreshold < 2)
    {
        minPeakSplitThreshold = 2;
    }

    if (valleyClipThreshold >= minPeakSplitThreshold)
    {
        valleyClipThreshold = minPeakSplitThreshold - 1;
    }

    // Initialize maxVal to a lowest value and minVal to a high value to start with.
    maxVal = 0; minVal = 65535;

    for(i = 0; i < arrayLength; i++)
    {
        curVal = profile[i];
        if (curVal > maxVal)
        {
            maxVal = curVal;
            maxValPos = i;
        }
        if (curVal < minVal)
        {
            minVal = curVal;
            minValPos = i;
        }
        // Check for monotonicity
        if (searchingForPeak)
        {
            if (curVal < maxVal && maxVal >= minPeakSplitThreshold && tempPeakIndex < NUMFINGERS)
            {
                candidate->peakValues[tempPeakIndex] = maxVal;
                tempPeakPos[tempPeakIndex] = maxValPos;
                minVal = curVal;
                minValPos = i;
                tempPeakIndex++;
                searchingForPeak = 0;
            }
        }
        else
        {
            if (curVal > minVal && tempValleyIndex < NUMFINGERS-1)
            {
                tempValleyPos[tempValleyIndex] = minValPos;
                maxVal = curVal;
                maxValPos = i;
                tempValleyIndex++;
                searchingForPeak = 1;
            }
        }
    }
    // handle a peak being at the last pixel
    if (searchingForPeak && maxVal >= minPeakSplitThreshold && tempPeakIndex < NUMFINGERS)
    {
        candidate->peakValues[tempPeakIndex] = maxVal;
        tempPeakPos[tempPeakIndex] = maxValPos;
    }

    // Filtering pass
    {
        uint16 valleyCount = 0;
        for(i = 0; i < tempValleyIndex; i++)
        {
            // Double check to ensure that the valley position is to the right of the peak position
            if (tempValleyPos[i] > tempPeakPos[i])
            {
                uint8p8 valleyRefinedPos;
                isocelesValley(profile, tempValleyPos[i], &valleyRefinedPos);
                candidate->valleyPositions[valleyCount] = valleyRefinedPos;
                candidate->valleyValues[valleyCount++] = MAX(profile[tempValleyPos[i]], valleyClipThreshold);
            }
        }
        candidate->valleyCount = valleyCount;
    }
}

/* -----------------------------------------------------------
Name: computeContrast
Purpose: For each valley, compute contrast relative to lower adjacent peak
         and threshold.
Inputs: projection
        minContrastThreshold - contrast threshold unless max peak is small
        minContrastPeakAmp - if peak amp smaller than this, reduce contrast threshold
        candidate
Outputs: candidate
Effects: none
Notes: updates contrasts array and splitCount fields of candidate
----------------------------------------------------------- */
static void computeContrast(uint16 *profile, uint16 arrayLength, uint10p6 minContrastThreshold, uint16 minContrastPeakAmp, splitCandidate_t *candidate)
{
    uint16 splitCount = 0;
    uint16 valleyIndex;
    uint10p6 contrastThreshold = 0xFFFF;

    // Compute contrast threshold, which is minContrastThreshold unless it's
    // smaller than ~minContrastPeakAmp.
    {
        uint16 *prof;
        uint16 i;
        uint16 maxPeakVal = 0;
        for (i = 0, prof = profile; i < arrayLength; i++, prof++)
        {
            if (*prof > maxPeakVal) {
                maxPeakVal = *prof;
            }
        }
        if (maxPeakVal > 0)
        {
            contrastThreshold = MAX(minContrastThreshold, (uint16) (((uint32) minContrastPeakAmp << 6) / maxPeakVal));
        }
    }

    // Compute contrasts, but set contrast to 0 if it's below threshold.
    for (valleyIndex = 0; valleyIndex < candidate->valleyCount; valleyIndex++)
    {
        uint16 minPeakVal = MIN(candidate->peakValues[valleyIndex], candidate->peakValues[valleyIndex + 1]);
        uint10p6 contrast = ((uint32) minPeakVal << 6) / candidate->valleyValues[valleyIndex];  // 26p6 / 16p0 = 10p6
        if (contrast >= contrastThreshold)
        {
            candidate->contrasts[valleyIndex] = contrast;
            splitCount++;
        }
    }
    candidate->splitCount = splitCount;
}

/* -----------------------------------------------------------
Name: copySplitData
Purpose: Copy relevant fields from candidate to clumps
Inputs: candidate
        clumpId
        firstSplit - where to start writing in clump->splits[]
        clumps structure
Outputs: firstSplit - where to start writing future splits
Effects: updates clumps in-place
Notes: none
----------------------------------------------------------- */
ATTR_INLINE static uint16 copySplitData(splitCandidate_t *candidate, uint16 clumpId, uint16 firstSplit, clumps_t *clumps)
{
    uint16 splitIndex;
    clumps->info[clumpId - 1].splitAxis  = (uint16) candidate->splitAxis;
    clumps->info[clumpId - 1].splitCount = candidate->splitCount;
    clumps->info[clumpId - 1].firstSplit = firstSplit;
    for (splitIndex = 0; splitIndex < NUMFINGERS; splitIndex++)
    {
        if (firstSplit < MAX_OBJECTS && candidate->contrasts[splitIndex] > 0)
        {
            clumps->splits[firstSplit++] = candidate->valleyPositions[splitIndex];
        }
    }
    return firstSplit;
}

#endif /* CONFIG_HAS_LINEAR_SWIPE_SPLITTER */
