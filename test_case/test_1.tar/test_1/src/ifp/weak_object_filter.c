/* -----------------------------------------------------------------

            COMPANY CONFIDENTIAL
             INTERNAL USE ONLY

  Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

  This document contains information that is proprietary to Synaptics
  Incorporated. The holder of this document shall treat all information
  contained herein as confidential, shall use the information only for its
  intended purpose, and shall protect the information in whole or part from
  duplication, disclosure to any other party, or dissemination in any media
  without the written permission of Synaptics Incorporated.

  Synaptics Incorporated
  1251 McKay Drive
  San Jose, CA   95131
  (408) 454-5100

----------------------------------------------------------------- */

#include "ifp_common.h"
#include "weak_object_filter.h"
#include "clump_projector.h"
#if CONFIG_HAS_WEAK_OBJECT_FILTER
/* =================================================================
   MODULE VARIABLES
==================================================================*/

static uint8p8 peakFraction;

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: weakObjectFilter_configure
Purpose: Configures weakObjectFilter parameters
Inputs: the minimum allowed amplitude as expressed as a fraction of the max peak amplitude
Outputs: None.
Effects: stores internal config
Notes: None.
----------------------------------------------------------- */
void weakObjectFilter_configure(weakObjectFilterConfig_t *wofConfig)
{
  peakFraction = wofConfig->peakFraction;
}

/* -----------------------------------------------------------
Name: weakObjectFilter_filter
Purpose: Filters blob classifications, discarding low peaks
Inputs: classifications, tracked objects, clumps, and delta image
Outputs: classifications
Effects: classifications are modified in-place.
Notes: None.
----------------------------------------------------------- */
void weakObjectFilter_filter(classification_t *classifications,
                             trackedObject_t *trackedObjects,
                             clumps_t *clumps,
                             int16 *deltaImage)
{
  int16 peakVals[MAX_OBJECTS];
  int16 maxPeakVal = -32768;

  // Extract peak pixel values for each blob.
  {
    uint16 trackInd;
    for (trackInd = 0; trackInd < MAX_OBJECTS; trackInd++)
    {
      uint16 clumpId = trackedObjects[trackInd].clumpId;
      if (clumpId == 0)  // no clump
      {
        peakVals[trackInd] = 0;
      }
      else
      {
        uint16 blobId = trackedObjects[trackInd].blobId;
        peakVals[trackInd] = clumpProjector_getBlobMax(clumps, clumpId, blobId, deltaImage);
      }
    }
  }

  // Find max.
  {
    uint16 i;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (peakVals[i] > maxPeakVal)
      {
        maxPeakVal = peakVals[i];
      }
    }
  }

  // Filter out relatively small blobs.
  {
    int16 threshold = (int16) (((int24p8) peakFraction * maxPeakVal) >> 8);
    uint16 i;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (peakVals[i] < threshold)
      {
        classifications[i].touchFlag = 0;
      }
    }
  }
}
#endif //CONFIG_HAS_WEAK_OBJECT_FILTER
