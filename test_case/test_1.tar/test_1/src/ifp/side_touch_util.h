#ifndef _SIDE_TOUCH_UTIL_H_
#define _SIDE_TOUCH_UTIL_H_
#include "ifp_common.h"

// #define MAX_FILT  30

// typedef enum{
//     stFIR_none,
//     stFIR_211,
//     stFIR_1111,
// }sideTouchTemporalFilterType_t;


void filter1d(const int16 *filt, const int16 filtSize, const int16 *inArr, const int16 inArrSize, int16 *out);
void LoGfiltering(int16 *inArr, int16 inNum, int16 sigma, int16 *out);
void gaussianFiltering(int16 *inArr, int16 inNum, int16 sigma, int16 *out);
int temporalFiltering(uint16 *inArr,int16 inNum, uint16 inBuf[BUF_H][MAX_RX], sideTouchTemporalFilterType_t temporalFilterType, uint16 *out);
void findLocalMinMax(int16 *in, int16 inSize, int16 threshold, int16 *posPosition, int16 *negPosition, int16* posNum, int16 *negNum);
void profileBlobArea(int16 *location,  int16 locationNum, int16 *profile, int16 inSize, int16 noiseFloorTh, int16 noiseFloorTh_pct, int16 *area);
void largeObjectDetection(int16 *location, int16 locationNum, int16 *profile, int16 inSize, int16 *area, int16 lastPixelValTh,int16 largeObjectPositionTh, int16 largeObjectAreaTh, int16 *isLargeObject);
void mergeProfileBlobs(int16 *location, int16 *locationNum, int16 *profile, int16 valleyScale);
void markBlobRegion(int16 *posPosition,   int16 posNum, int16 *profile, int16 inSize, int16 threshold, int16 *pixelArray);
void calculateDelta(uint16 *baseline, uint16 *rawProfile, int16 arrSize , int16 *deltaProfile);
void initBuffer(uint16 inProfile[MAX_RX],  sideTouchBufferType_t bufferType, sideTouchTemporalFilterType_t temporalFilterType, uint16 outBuf[BUF_H][MAX_RX]);

// void updateFingerList(sideFinger_t *lFingerList, sideFinger_t *rFingerList, int16 positionDefault);
void updateFingerListSingle(sideFinger_t *fingerList, int16 positionDefault);
// void updateProfileBuf(uint16 *lProfile, uint16 *rProfile, uint16 lProfileBuf[BUF_H][MAX_RX], uint16 rProfileBuf[BUF_H][MAX_RX]);
int8p8 computeGaussianPeak(uint16* projection, int16 size, int16 peakIdx, int8p8 *gaussianWidth, int16 minFingerWidth);

int16 min_int16(int16 in1, int16 in2);
int16 max_int16(int16 in1, int16 in2);
int16 abs_int16(int16 a);

#endif
