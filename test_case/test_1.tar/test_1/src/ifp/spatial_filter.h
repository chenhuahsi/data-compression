#ifndef _SPATIAL_FILTER_H_
#define _SPATIAL_FILTER_H_

// -----------------------------------------------------------------
// Spatial Filter
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2014  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// $Id: spatial_filter.h,v 1.1.2.2 2014/06/16 18:13:04 izhong Exp $
//



#include "ifp_common.h"

void spatialFilter_configure(spatialFilterConfig_t *config, spatialFilterType_t type);
int16 spatialFilter_filterPixel(int16 *ptr, uint16 row0, spatialFilterType_t type
  #if CONFIG_HAS_SPATIAL_FILTER_NORMALIZER
  , int16 divider
  #endif
  );
void spatialFilter_processFrame(sensorParams_t *params, int16 *delta, spatialFilterDelta_t mode, spatialFilterType_t type);

#endif  // end _SPATIAL_FILTER_H_
