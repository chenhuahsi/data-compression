/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Dr.
   San Jose, CA 95131
   (408) 904-1100

   Filename: pen_recorrector.h
   Description: Header for external API of recorrector of pen signals that
                have been mutilated by other correction algorithms
----------------------------------------------------------------- */
#ifndef _PEN_RECORRECTOR_H
#define _PEN_RECORRECTOR_H

#if CONFIG_HAS_SMALL_OBJECT_DETECTOR
void penRecorrector_init(void);
void penRecorrector_reinit(void);
void penRecorrector_configure(penRecorrectorConfig_t *config);
void penRecorrector_setPenTarget(trackedObject_t *trackedObjects,
                                 clumps_t *clumps,
                                 classification_t *classifications);
void penRecorrector_recorrectPen(sensorParams_t *sensorParams,
                                 uint16 *rawImage,
                                 imageBaseline_t *baseline,
                                 int16 *deltaImage);
#else
static ATTR_INLINE void penRecorrector_init(void) {};
static ATTR_INLINE void penRecorrector_reinit(void) {};
static ATTR_INLINE void penRecorrector_configure(ATTR_UNUSED penRecorrectorConfig_t *config) {};
static ATTR_INLINE void penRecorrector_setPenTarget(
                                 ATTR_UNUSED trackedObject_t *trackedObjects,
                                 ATTR_UNUSED clumps_t *clumps,
                                 ATTR_UNUSED classification_t *classifications) {};
static ATTR_INLINE void penRecorrector_recorrectPen(
                                 ATTR_UNUSED sensorParams_t *sensorParams,
                                 ATTR_UNUSED uint16 *rawImage,
                                 ATTR_UNUSED imageBaseline_t *baseline,
                                 ATTR_UNUSED int16 *deltaImage) {};
#endif // CONFIG_HAS_SMALL_OBJECT_DETECTOR

#endif // _PEN_RECORRECTOR_H
