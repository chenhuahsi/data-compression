#ifndef _POSITION_ESTIMATOR_H
#define _POSITION_ESTIMATOR_H

// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: positionEstimator.h
// Description: Header file for positionEstimator.c
//
// $Id: position_estimator.h,v 1.6.8.1.4.2 2012/12/05 02:47:44 jjordan Exp $

#include "ifp_common.h"

void positionEstimator_init(void);
void positionEstimator_reinit(void);
void positionEstimator_calcPositions(sensorParams_t *sensorParams,
                                     int16 *deltaImage,
                                     clumps_t *clumps,
                                     trackedObject_t *trackedObjects,
                                     classification_t *classifications,
                                     sensorPosition_t *sensorPositions);
#if CONFIG_HAS_NOTCH_CUT
void positionEstimator_configure(sensorParams_t *sensorParams, positionEstConfig_t *peConfig);
#else
void positionEstimator_configure(positionEstConfig_t *peConfig);
#endif
void positionEstimator_reportGaussianWidth(uint16 *widthX, uint16 *widthY);
#endif //POSITION_ESTIMATOR_H
