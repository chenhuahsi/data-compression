/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100

   Description: Tracks objects as they move
   $Id: segmenter.c,v 1.10.2.7.2.20 2013/01/31 22:48:25 jjordan Exp $
----------------------------------------------------------------- */

/* Tracker algorithm overview --------------------------------------

   The tracker calculates the pairwise distance between each object in
   the current frame and the previous frame. It then greedily picks
   off the best matches until all objects have been matched.

   Matching is not entirely distance-based. There is a simple
   "drumming" filter that rejects matches that would require sudden
   acceleration.

   When the number of splits of objects decreases, the tertiary distance
   between two combined objects from the previous frame and one object from
   the current frame is computed. If this is small than the pairwise distance
   of a current object, the previous objects are assumed to have merged and
   marked as used.

   The position estimate used for this algorithm is the centroid of
   the blob.

------------------------------------------------------------------*/
#define cfg_hasHungarianTrackingAlgorithm 0 // hungarian match causes finger index swap under high noise

#include "ifp_common.h"
#include "ifp_string.h"
#include "ifp_bit_manipulation.h"
#include "tracker.h"
#include "tracker_internal.h"
#include "clump_projector.h"

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/
#define HUNG_MIN(a,b) (((a)<(b))?(a):(b))

/* =================================================================
   MODULE TYPES
==================================================================*/

/* =================================================================
   MODULE VARIABLES
==================================================================*/
static trackedObject_t trackedObjects[MAX_OBJECTS];
static drummingParams_t drumFilter;
static uint16 oldNumObjects;
static uint16 oldNumSplits;
static uint8p8 maxDistPerMs_px;
#if CONFIG_HAS_LESSER_BLOB_TRACKER
static uint16 mindBlobsLess;
#endif

#if CONFIG_HAS_LGM_MERGER
#define NUM_OF_DRAWERS 2
static struct {
  uint16 current;
  struct {
    trackedObject_t trackedObjects[MAX_OBJECTS];
    uint16 oldNumObjects;
    uint16 oldNumSplits;
  } drawers[NUM_OF_DRAWERS];
} cupboard;
static void stash(void)
{
  memcpy16(cupboard.drawers[cupboard.current].trackedObjects, trackedObjects, sizeof(trackedObjects) / sizeof(uint16));
  cupboard.drawers[cupboard.current].oldNumObjects = oldNumObjects;
  cupboard.drawers[cupboard.current].oldNumSplits = oldNumSplits;
}
static void pick(void)
{
  memcpy16(trackedObjects, cupboard.drawers[cupboard.current].trackedObjects, sizeof(trackedObjects) / sizeof(uint16));
  oldNumObjects = cupboard.drawers[cupboard.current].oldNumObjects ;
  oldNumSplits = cupboard.drawers[cupboard.current].oldNumSplits;
}

void tracker_first_drawer(void)
{
  cupboard.current = 0;
}
void tracker_next_drawer(void)
{
  cupboard.current++;
}
#endif

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

static void calcObjectStatistics(int16 *deltaImage, clumps_t *clumps, sensorParams_t *sensorParams, blobStats_t *stats);
static void initDistanceMatrix(uint8p8 *matrix);
static void initMergeMatrix(uint8p8 *matrix);
static void initMergeTrackIdxs(int16 *trackIdxs);
static uint8p8 calculateRelativeDZ(uint8p8 z1, uint8p8 z2);
static void makeDistanceMatrix(trackedObject_t *oldTracks, blobStats_t *newStats, uint16 timeSinceLast_ms,
 ATTR_UNUSED uint16 tertDistFlag, uint8p8 maxDistPerMs_px, dists_t *dist);
#if cfg_hasHungarianTrackingAlgorithm
static void optMatch(trackedObject_t *trackedObjects, blobStats_t *stats, dists_t *dist, uint16 timeSinceLast_ms, drummingParams_t *drummingParams);
static void hungarian(dists_t *d, int16 xMatches[]);
#else
static void greedyMatch(trackedObject_t *trackedObjects, blobStats_t *stats, dists_t *dist, uint16 timeSinceLast_ms,
 drummingParams_t *drummingParams, ATTR_UNUSED uint16 tertDistFlag);
static uint8p8 findMinDist(dists_t *dist, int16 *track, int16 *clump);
static uint8p8 findMinMergeMatrix(dists_t *dist, int16 clump, int16 *track1, int16 *track2);
#endif
static int16 findEmptyTrack(trackedObject_t *trackedObjects, dists_t *dist, uint16 start);
static void assignTracksToNewObjects(trackedObject_t *trackedObjects, blobStats_t *stats, dists_t *dist);
static void freeUnusedTracks(trackedObject_t *trackedObjects);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

static void calcObjectStatistics(int16 *deltaImage, clumps_t *clumps, sensorParams_t *sensorParams, blobStats_t *stats)
{
  uint16 clumpId;
  blobStats_t *statsPtr = stats;

  memset16(stats, 0, sizeof(*stats)*MAX_OBJECTS / sizeof(uint16));

  for (clumpId = 1; clumpId < MAX_OBJECTS + 1; clumpId++)
  {
    clumpInfo_t *info;
    uint16 blobId;
    uint16 splitCount;

    info = &clumps->info[clumpId - 1];
    if (info->peakCount == 0)
    {
      continue;
    }

    splitCount = info->splitCount;
    for (blobId = 0; blobId <= splitCount; blobId++)
    {
      uint16 projX[MAX_RX];
      uint16 projY[MAX_TX];
      uint16 xMin = MAX_RX;
      uint16 xMax = 0;
      uint16 yMin = MAX_TX;
      uint16 yMax = 0;
      uint16 pixelCount;
      pixelCount = clumpProjector_getProjectionXY(clumps, clumpId, (int16) blobId, deltaImage, projX, projY);

      // Aggressively control scope to help compiler determine when variables
      // are live. Live local variables have direct RAM reserved for them.
      {
        uint32 z = 0;
        uint8p8 x, y;
        {
          uint16 *projPtr = projX;
          uint32 sumX = 0;
          uint16 i;
          for (i = 0; i < MAX_RX; i++)
          {
            z += *projPtr;
            xMin = (*projPtr != 0 && i < xMin) ? i : xMin;
            xMax = (*projPtr != 0 && i > xMax) ? i : xMax;
            sumX += (uint32) i * (*projPtr++);
          }
          if (z == 0) z = 1;
          x = (uint8p8) ((sumX << 8) / z);
        }

        {
          uint16 *projPtr = projY;
          uint32 sumY = 0;
          uint16 i;
          for (i = 0; i < MAX_TX; i++)
          {
            yMin = (*projPtr != 0 && i < yMin) ? i : yMin;
            yMax = (*projPtr != 0 && i > yMax) ? i : yMax;
            sumY += (uint32) i * (*projPtr++);
          }
          y = (uint8p8) ((sumY << 8) / z);
        }

        statsPtr->x = x + 0x100;
        statsPtr->y = y + 0x100;
        xMin += 1;
        xMax += 1;
        yMin += 1;
        yMax += 1;
        statsPtr->xMin = xMin << 8;
        statsPtr->xMax = xMax << 8;
        statsPtr->yMin = yMin << 8;
        statsPtr->yMax = yMax << 8;
        z = (sensorParams->cSat_LSB > 0) ? (z << 8) / sensorParams->cSat_LSB : (z << 8); // Normalize z with cSat
        statsPtr->z = ((z & 0xFFFF0000) == 0) ? (uint8p8) z : 0xFFFF;
      }
      statsPtr->blobId = blobId;
      statsPtr->clumpId = clumpId;
      statsPtr->pixelCount = pixelCount;
      statsPtr->polarity = info->polarity;

      statsPtr++;

      if (statsPtr > stats + MAX_OBJECTS - 1) goto endOfLoop;
    }
  }
  endOfLoop:
  return;
}

static void clearTrackClumpIds(trackedObject_t *trackedObjects)
{
  uint16 i;
  trackedObject_t *trackPtr = trackedObjects;
  for (i = 0; i < MAX_OBJECTS; i++)
  {
    (trackPtr++)->clumpId = 0;
  }
}

static void initDistanceMatrix(uint8p8 *matrix)
{
  uint16 i;
  for (i = 0; i < MAX_OBJECTS*MAX_OBJECTS; i++)
  {
    *matrix++ = 65535;
  }
}

static void initMergeMatrix(uint8p8 *matrix)
{
  uint16 i;
  for (i = 0; i < MAX_OBJECTS*TRACKER_NUM_MERGE_PAIRS; i++)
  {
    *matrix++ = 65535;
  }
}

static void initMergeTrackIdxs(int16 *trackIdxs)
{
  uint16 i;
  for (i = 0; i < MAX_OBJECTS*TRACKER_NUM_MERGE_PAIRS; i++)
  {
    *trackIdxs++ = -1;
  }
}

static uint8p8 calculateRelativeDZ(uint8p8 z1, uint8p8 z2)
{
  uint8p8 reldz;
  if (z1 > z2)
  {
    uint8p8 dz = z1 - z2;
    reldz = ((uint32) dz << 8) / z1;
  }
  else
  {
    uint8p8 dz = z2 - z1;
    reldz = ((uint32) dz << 8) / z2;
  }
  return reldz;
}

#if cfg_hasHungarianTrackingAlgorithm
static void hungarian(dists_t *d, int16 xMatches[])
{
  uint8p8 *distance = d->matrix;
  int16 yMatches[MAX_OBJECTS];
  uint8p8 u[MAX_OBJECTS];
  uint8p8 v[MAX_OBJECTS];
  uint8p8 dist[MAX_OBJECTS];
  int16 prev[MAX_OBJECTS];
  int16 seen[MAX_OBJECTS];
  uint16 maxMatch = 0;
  uint16 i, j, s = 0;

  /* Construct dual feasible solution. */
  memset16(u, 0, MAX_OBJECTS);
  for (j = 0; j < MAX_OBJECTS; j++)
  {
    v[j] = distance[j];
    if (isBitSet(d->usedBlobsBits, j))
    {
      for (i = 1; i < MAX_OBJECTS; i++)
        v[j] = HUNG_MIN(v[j], distance[i*MAX_OBJECTS + j]);
    }
  }

  /* Initialize primal solution. */
  memset16(xMatches, 0xFFFF, MAX_OBJECTS);
  memset16(yMatches, 0xFFFF, MAX_OBJECTS);
  i = j = MAX_OBJECTS;
  while (1)
  {
    if (!isBitSet(d->usedTracksBits, (i-1)) && !isBitSet(d->usedBlobsBits, (j-1)))
    {
      xMatches[i-1] = j-1;
      yMatches[j-1] = i-1;
      maxMatch++;
      i--;
      j--;
    }
    else
    {
      if (isBitSet(d->usedTracksBits, i-1)) i--;
      if (isBitSet(d->usedBlobsBits, j-1)) j--;
    }
    if (i == 0 || j == 0) break;
  }

  /* Repeat until primal solution is feasible. */
  while (maxMatch < MAX_OBJECTS)
  {
    int16 i = 0, j = 0, k;
    uint8p8 *d_sk, *d_ik;

    /* Find an unmatched left node. */
    while (xMatches[s] != -1) s++;

    /* Initialize Dijkstra. */
    memset16(prev, 0xFFFF, MAX_OBJECTS);
    memset16(seen, 0, MAX_OBJECTS);
    d_sk = &distance[s*MAX_OBJECTS];
    for (k = 0; k < MAX_OBJECTS; k++)
    {
//      dist[k] = *d_sk - u[s] - v[k];
      dist[k] = *d_sk - v[k];
      dist[k] = (dist[k] > u[s]) ? (dist[k] - u[s]) : (u[s] - dist[k]);
      d_sk++;
      if (!isBitSet(d->usedBlobsBits, (uint16)k) &&
          !isBitSet(d->usedTracksBits, (uint16)s))
        seen[k] = 1;
    }

    while (1)
    {
      uint8p8 u_i;

      /* Find closest. */
      j = -1;
      for (k = 0; k < MAX_OBJECTS; k++)
      {
        if (seen[k]) continue;
        if (j == -1 || dist[k] < dist[j]) j = k;
      }
      seen[j] = 1;

      /* Termination condition. */
      if (yMatches[j] == -1) break;

      /* Relax neighbors. */
      i = yMatches[j];
      d_ik = &distance[i*MAX_OBJECTS];
      u_i = u[i];
      for (k = 0; k < MAX_OBJECTS; k++, d_ik++)
      {
        uint32 newDist;
        if (seen[k]) continue;
        newDist = *d_ik - v[k];
        newDist += dist[j];
        newDist = (newDist > u_i) ? (newDist - u_i) : (u_i - newDist);
//        newDist = dist[j] - u_i - v[k] + *d_ik;
        if (((newDist & 0xFFFF0000) == 0) && (dist[k] > newDist))
        {
          dist[k] = (uint8p8)newDist;
          prev[k] = j;
        }
      }
    }

    /* Update dual variables. */
    for (k = 0; k < MAX_OBJECTS; k++)
    {
      int16 i = yMatches[k];
      if (!seen[k] || k == j) continue;
      u[i] += dist[j] - dist[k];
      v[k] -= dist[j] - dist[k];
    }
    u[s] += dist[j];

    /* Augment along path. */
    if (isBitSet(d->usedBlobsBits, (uint16)j) ||
        isBitSet(d->usedTracksBits, (uint16)s))
    {
      while (prev[j] >= 0)
      {
        int16 d = prev[j];
        yMatches[j] = yMatches[d];
        xMatches[yMatches[j]] = j;
        j = d;
      }
    }
    yMatches[j] = s;
    xMatches[s] = j;

    maxMatch++;
  }
}
#endif

static void makeDistanceMatrix(trackedObject_t *oldTracks, blobStats_t *newStats,
                               uint16 timeSinceLast_ms, ATTR_UNUSED uint16 tertDistFlag,
                               uint8p8 maxDistPerMs_px, dists_t *dist)
{
  uint16 track1;
  uint16 track2;
  uint16 blob;
  blobStats_t *statsPtr;
  trackedObject_t *track1Ptr;
  trackedObject_t *track2Ptr;
  uint8p8 liftDist;

  // calculate a distance roughly equal to the maximum distance a
  // finger can move in one frame. Add this to the motion for fingers
  // that dramatically change size.
  {
    uint32 liftDist32;
    timeSinceLast_ms = (timeSinceLast_ms > 255) ? 255 : timeSinceLast_ms;
    // Both values are less than 256, so the product will fit in 16 bits:
    liftDist = (uint8p8) ((uint32) maxDistPerMs_px * timeSinceLast_ms);
    // This result may overflow 16 bits and must be clipped:
    liftDist32 = ((uint32) liftDist * liftDist) >> 8;
    liftDist = ((liftDist32 & 0xFFFF0000) != 0) ? 0xFFFF : (uint16) liftDist32;
  }

  initDistanceMatrix(dist->matrix);
  initMergeMatrix(dist->mergeMatrix);
  initMergeTrackIdxs(dist->mergeTrackIdx1);
  initMergeTrackIdxs(dist->mergeTrackIdx2);

  // in case there are no trackedObjects, we need to set the used blob rows
  // or else we'll miss them later when searching the matrix
  statsPtr = newStats;
  dist->usedBlobsBits = 0;
  for (blob = 0; blob < MAX_OBJECTS; blob++)
  {
    if ((statsPtr++)->z > 0)
      dist->usedBlobsBits = setBit(dist->usedBlobsBits, blob);
  }

  dist->usedTracksBits = 0;
  track1Ptr = oldTracks;
  // calculate the distances for all pairs of trackedObjects/blobs
  for (track1 = 0; track1 < MAX_OBJECTS; track1++, track1Ptr++)
  {
    if (track1Ptr->clumpId == 0)
    {
      continue;
    }
    dist->usedTracksBits = setBit(dist->usedTracksBits, track1);

    statsPtr = newStats;
    for (blob = 0; blob < MAX_OBJECTS; blob++, statsPtr++)
    {
      uint32 distSquared;
      int8p8 dx;
      int8p8 dy;
      uint32 dA;
      uint8p8 reldz;
      uint8p8 scaledLiftDist;
      uint32 scaledAreaDist32;
      uint16 scaledAreaDist;
      // ignore empty blobs and objects of opposite polarity
      if ((statsPtr->z == 0) ||
          (statsPtr->polarity != track1Ptr->polarity))
      {
        continue;
      }
      dx = track1Ptr->xCentroid - statsPtr->x;
      dy = track1Ptr->yCentroid - statsPtr->y;

      reldz = calculateRelativeDZ(track1Ptr->zerothMoment, statsPtr->z);
        // reldz will be less than 0x100, so this will fit in 16 bits:
      scaledLiftDist = (uint8p8) (((uint32) reldz * liftDist) >> 8);

      dA = (uint32) track1Ptr->pixelCount + statsPtr->pixelCount;
        dA *= dA;
        dA <<= 8;
        dA /= (uint32) track1Ptr->pixelCount*statsPtr->pixelCount;
        dA -= 0x400;
        scaledAreaDist32 = (( dA * liftDist) >> 8);
        scaledAreaDist = (scaledAreaDist32 > 0x7FFF) ? 0x7FFF : scaledAreaDist32;

      distSquared = ((uint32)((int32)dx*dx))>>8;
      distSquared += ((uint32)((int32)dy*dy))>>8;
      distSquared += scaledLiftDist;
        distSquared += scaledAreaDist;
      dist->matrix[track1*MAX_OBJECTS + blob] = ((distSquared & 0xFFFF0000) == 0) ? (uint8p8) distSquared : 0xFFFF;
    }
  }

  if (CONFIG_HAS_SMALL_OBJECT_DETECTOR && tertDistFlag)
  {
    uint16 i;
    statsPtr = newStats;
    // calculate the distances for all pairs of trackedObjects/blobs
    for (blob = 0; blob < MAX_OBJECTS; blob++, statsPtr++)
    {
      if (statsPtr->z == 0)
      {
        continue;
      }

      track1 = 0;
      track2 = 1;
      track1Ptr = oldTracks;
      track2Ptr = oldTracks + 1;
      for (i = 0; i < MAX_OBJECTS*(MAX_OBJECTS - 1)/2; i++)
      {
        uint16 calcCheck;

        // ignore empty blobs and objects of opposite polarity
        calcCheck = ((track1Ptr->clumpId > 0) && (statsPtr->polarity == track1Ptr->polarity) &&
                     (track2Ptr->clumpId > 0) && (statsPtr->polarity == track2Ptr->polarity)
                    );
        calcCheck = (calcCheck && !((track1Ptr->xCentroid > statsPtr->xMax) || (track1Ptr->xCentroid < statsPtr->xMin) ||
                                    (track1Ptr->yCentroid > statsPtr->yMax) || (track1Ptr->yCentroid < statsPtr->yMin) ||
                                    (track2Ptr->xCentroid > statsPtr->xMax) || (track2Ptr->xCentroid < statsPtr->xMin) ||
                                    (track2Ptr->yCentroid > statsPtr->yMax) || (track2Ptr->yCentroid < statsPtr->yMin)
                                   )
                    );
        if (calcCheck)
        {
          uint32 distSquared;
          uint32 oldZ = (uint32)track1Ptr->zerothMoment + track2Ptr->zerothMoment;

          {
            int8p8 dx;
            uint32 x = (uint32)track1Ptr->xCentroid*track1Ptr->zerothMoment + (uint32)track2Ptr->xCentroid*track2Ptr->zerothMoment;
            x /= oldZ;
            dx = ((x & 0xFFFF8000) == 0) ? (int8p8) x : 0x7FFF;
            dx -= statsPtr->x;
            distSquared = ((uint32)((int32)dx*dx))>>8;
          }

          {
            int8p8 dy;
            uint32 y = (uint32)track1Ptr->yCentroid*track1Ptr->zerothMoment + (uint32)track2Ptr->yCentroid*track2Ptr->zerothMoment;
            y /= oldZ;
            dy = ((y & 0xFFFF8000) == 0) ? (int8p8) y : 0x7FFF;
            dy -= statsPtr->y;
            distSquared += ((uint32)((int32)dy*dy))>>8;
          }

          {
            uint8p8 reldz;
            uint16 scaledLiftDist;
            uint8p8 z = ((oldZ & 0xFFFF0000) == 0) ? (uint8p8) oldZ : 0xFFFF;
            reldz = calculateRelativeDZ(z, statsPtr->z);
            // reldz will be less than 0x100, so this will fit in 16 bits:
            scaledLiftDist = (uint16) (((uint32) reldz * liftDist) >> 8);
            distSquared += scaledLiftDist;
          }

          {
            uint32 dA;
            uint16 scaledAreaDist;
            uint32 scaledAreaDist32;
            uint16 oldPixelCount = track1Ptr->pixelCount + track2Ptr->pixelCount;

            dA = (uint32) oldPixelCount + statsPtr->pixelCount;
            dA *= dA;
            dA <<= 7;
            dA /= (uint32) oldPixelCount*statsPtr->pixelCount;
            dA -= 0x200;
            scaledAreaDist32 = ((dA * liftDist) >> 7);
            scaledAreaDist = (scaledAreaDist32 > 0x80) ? 0x80 : scaledAreaDist32;
            distSquared += scaledAreaDist;
          }

          distSquared = ((distSquared & 0xFFFF000) == 0) ? (uint8p8) distSquared : 0xFFFF;

          {
            int16 j;
            int16 mergeMatrixPos = -1;
            uint8p8 *mergeMatrixPtr = dist->mergeMatrix + blob*TRACKER_NUM_MERGE_PAIRS;
            for (j = 0; j < 3; j++)
            {
              if (distSquared < *mergeMatrixPtr)
              {
                mergeMatrixPos = j;
                break;
              }
              mergeMatrixPtr++;
            }
            //FIXME: check this logic
            if (mergeMatrixPos >= 0)
            {
              int16 *mergeTrackIdx1Ptr = dist->mergeTrackIdx1 + blob*TRACKER_NUM_MERGE_PAIRS;
              int16 *mergeTrackIdx2Ptr = dist->mergeTrackIdx2 + blob*TRACKER_NUM_MERGE_PAIRS;
              mergeMatrixPtr = dist->mergeMatrix + blob*TRACKER_NUM_MERGE_PAIRS;
              for (j = 2; j > mergeMatrixPos; j--)
              {
                *(mergeMatrixPtr + j) = *(mergeMatrixPtr + j - 1);
                *(mergeTrackIdx1Ptr + j) = *(mergeTrackIdx1Ptr + j - 1);
                *(mergeTrackIdx2Ptr + j) = *(mergeTrackIdx2Ptr + j - 1);
              }
              *(mergeMatrixPtr + mergeMatrixPos) = distSquared;
              *(mergeTrackIdx1Ptr + mergeMatrixPos) = track1;
              *(mergeTrackIdx2Ptr + mergeMatrixPos) = track2;
            }
          }
        }

        // increment track indices
        track2++;
        track2Ptr++;
        if (track2 >= MAX_OBJECTS)
        {
          track1++;
          track1Ptr++;
          track2 = track1 + 1;
          track2Ptr = track1Ptr + 1;
        }
      }
    }
  }
}


#if cfg_hasHungarianTrackingAlgorithm
static void optMatch(trackedObject_t *trackedObjects, blobStats_t *stats, dists_t *dist, uint16 timeSinceLast_ms, drummingParams_t *drummingParams)
{
  int8p8 frameRateScale;
  uint16 track, blob;
  int16 matches[MAX_OBJECTS];

  if (timeSinceLast_ms < 1)
    timeSinceLast_ms = 1;

  frameRateScale = (8 << 8) / timeSinceLast_ms;

  hungarian(dist, matches);

  for (track = 0; track < MAX_OBJECTS; track++)
  {
    blob = matches[track];

    if (dist->matrix[blob + track*MAX_OBJECTS] >= 0xFFFF)
      continue;

    // filter out matches that may be drumming
    {
      trackedObject_t *trackPtr;
      blobStats_t *statsPtr;
      int8p8 dx, dy;
      uint32 distSquared;
      int8p8 vx, vy;
      uint32 accelSquared;

      trackPtr = &trackedObjects[track];
      statsPtr = &stats[blob];

      dx = (int8p8)statsPtr->x - (int8p8)trackPtr->xCentroid;
      dy = (int8p8)statsPtr->y - (int8p8)trackPtr->yCentroid;

      distSquared  = ((uint32)((int32)dx*dx)>>8);
      distSquared += ((uint32)((int32)dy*dy)>>8);

      vx = (int8p8) (((int32) frameRateScale * dx) / 256);
      vy = (int8p8) (((int32) frameRateScale * dy) / 256);

      //  It has been observed that fast taps can appear for single frames at 60
      //  Hz sensing but not 100Hz, no matter how hard you try. Thus at 60 Hz,
      //  there is a fundamental ambiguity between a fast swipe and drum. We
      //  bias toward drumming by performing the acceleration check with an
      //  initial old velocity of 0, which sets an effective maximum initial
      //  physical velocity. Above ~80 Hz (12 ms), we can be sure that single-
      //  frame drumming cannot occur and we will allow an arbitrary starting
      //  velocity and then restrict acceleration on subsequent frames, where
      //  the velocity has been properly measured.
      if (trackPtr->trackedFrames == 1 && timeSinceLast_ms < 12)
      {
        accelSquared = 0;
      }
      else
      {
        int8p8 accelx, accely;
        accelx = vx - trackPtr->speedx;
        accely = vy - trackPtr->speedy;
        // Since oldspeed is initialized to zero, swipes can cause
        // accelerations when the finger first lands. Attenuate
        // acceleration estimates based on age to prevent this.
        accelx -= accelx >> trackPtr->trackedFrames;
        accely -= accely >> trackPtr->trackedFrames;
        accelSquared  = (uint32) ((int32) accelx * accelx) >> 8;
        accelSquared += (uint32) ((int32) accely * accely) >> 8;
      }

      if ((distSquared < drummingParams->minDistSquared) || (accelSquared < drummingParams->minAccelSquared) ||
          ((trackPtr->pixelCount > drummingParams->palmSize) && (statsPtr->pixelCount > drummingParams->palmSize)))
      {
        trackPtr->xCentroid = statsPtr->x;
        trackPtr->yCentroid = statsPtr->y;
        trackPtr->zerothMoment = statsPtr->z;
        trackPtr->clumpId = statsPtr->clumpId;
        trackPtr->blobId = statsPtr->blobId;
        trackPtr->speedx = vx;
        trackPtr->speedy = vy;
        trackPtr->pixelCount = statsPtr->pixelCount;
        if (trackPtr->trackedFrames < 15)
        {
          trackPtr->trackedFrames++;
        }

        dist->usedBlobsBits = clearBit(dist->usedBlobsBits, (uint16)blob);
        dist->usedTracksBits = clearBit(dist->usedTracksBits, (uint16)track);
      }
    }
  }
}

#else

static void greedyMatch(trackedObject_t *trackedObjects, blobStats_t *stats, dists_t *dist, uint16 timeSinceLast_ms, drummingParams_t *drummingParams, ATTR_UNUSED uint16 tertDistFlag)
{
  int8p8 frameRateScale;

  if (timeSinceLast_ms < 1)
  {
    timeSinceLast_ms = 1;
  }

  frameRateScale = (8 << 8) / timeSinceLast_ms;

  while(1)
  {
    int16 track;
    int16 track1 = -1;
    int16 track2 = -1;
    int16 blob;
    uint8p8 minDist;

    minDist = findMinDist(dist, &track, &blob);
    if (track < 0)
    {
      break;
    }

    if (
    #if CONFIG_HAS_LESSER_BLOB_TRACKER
      !mindBlobsLess &&
    #endif
      CONFIG_HAS_SMALL_OBJECT_DETECTOR && tertDistFlag)
    {
      uint8p8 minDist2D = findMinMergeMatrix(dist, blob, &track1, &track2);
      if (minDist2D < minDist)
      {
        if (trackedObjects[track1].zerothMoment < trackedObjects[track2].zerothMoment)
        {
          track = track2;
        }
        else
        {
          track = track1;
          track1 = track2;
        }
      }
      else
      {
        track1 = -1;
      }
    }

    // filter out matches that may be drumming
    {
      trackedObject_t *trackPtr;
      blobStats_t *statsPtr;
      int8p8 oldSpeedX, oldSpeedY;
      int8p8 dx, dy;
      uint32 distSquared;
      int8p8 vx, vy;
      int8p8 vx_attenuated, vy_attenuated;
      int8p8 accelx, accely;
      uint32 accelSquared;

      trackPtr = &trackedObjects[track];
      statsPtr = &stats[blob];

      oldSpeedX = trackPtr->speedx;
      oldSpeedY = trackPtr->speedy;

      dx = statsPtr->x - trackPtr->xCentroid;
      dy = statsPtr->y - trackPtr->yCentroid;

      distSquared  = ((uint32)((int32)dx*dx)>>8);
      distSquared += ((uint32)((int32)dy*dy)>>8);

      if (SIGNED_RIGHT_SHIFT_IS_ARITHMETIC)
      {
        vx = (int8p8) (((int32) frameRateScale * dx) >> 8);
        vy = (int8p8) (((int32) frameRateScale * dy) >> 8);

        // since oldspeed is initialized to zero, swipes can cause
        // accelerations when the finger first lands. Attenuate
        // acceleration estimates based on age to prevent this

        vx_attenuated = vx >> trackPtr->trackedFrames;
        vy_attenuated = vy >> trackPtr->trackedFrames;
      }
      else
      {
        vx = (int8p8) (((int32) frameRateScale * dx) / 256);
        vy = (int8p8) (((int32) frameRateScale * dy) / 256);
        vx_attenuated = vx / (1 << trackPtr->trackedFrames);
        vy_attenuated = vy / (1 << trackPtr->trackedFrames);
      }

      accelx = vx - vx_attenuated - oldSpeedX;
      accely = vy - vy_attenuated - oldSpeedY;
        accelSquared  = (uint32) ((int32) accelx * accelx) >> 8;
        accelSquared += (uint32) ((int32) accely * accely) >> 8;

      if (track1 >= 0 || (distSquared < drummingParams->minDistSquared) ||
          (accelSquared < drummingParams->minAccelSquared) ||
          (trackPtr->pixelCount > drummingParams->palmSize) ||
          (statsPtr->pixelCount > drummingParams->palmSize))
      {
        trackPtr->xCentroid = statsPtr->x;
        trackPtr->yCentroid = statsPtr->y;
        trackPtr->zerothMoment = statsPtr->z;
        trackPtr->clumpId = statsPtr->clumpId;
        trackPtr->blobId = statsPtr->blobId;
        trackPtr->speedx = vx;
        trackPtr->speedy = vy;
        trackPtr->pixelCount = statsPtr->pixelCount;
        if (trackPtr->trackedFrames < 15)
        {
          trackPtr->trackedFrames++;
        }

        dist->usedBlobsBits = clearBit(dist->usedBlobsBits, (uint16)blob);
        dist->usedTracksBits = clearBit(dist->usedTracksBits, (uint16)track);
        if (track1 >= 0)
        {
          dist->usedTracksBits = clearBit(dist->usedTracksBits, (uint16)track1);
        }
      }
      else
      {
        dist->matrix[blob + track*MAX_OBJECTS] = 65535;
      }
    }
  }
}

static uint8p8 findMinDist(dists_t *dist, int16 *track, int16 *blob)
{
  uint8p8 minDist = 0xFFFFU;
  uint16 t, c;

  *track = -1;
  *blob = -1;

  for (t = 0; t < MAX_OBJECTS; t++)
  {
    if (isBitSet(dist->usedTracksBits, t) == 0)
    {
      continue;
    }

    for (c = 0; c < MAX_OBJECTS; c++)
    {
      uint8p8 d;
      if (isBitSet(dist->usedBlobsBits, c) == 0)
      {
        continue;
      }
      d = dist->matrix[t*MAX_OBJECTS + c];
      if (d < minDist)
      {
        minDist = d;
        *track = t;
        *blob = c;
        if (minDist < 0x0040) // 0.25 pitches ~ 1 mm
        {
          return minDist;
        }
      }
    }
  }

  return minDist;
}

static uint8p8 findMinMergeMatrix(dists_t *dist, int16 clump, int16 *track1, int16 *track2)
{
  uint16 i;
  uint8p8 *mergeMatrixPtr;
  int16 *mergeTrackIdx1Ptr;
  int16 *mergeTrackIdx2Ptr;
  uint8p8 minDist = 0xFFFFU;

  if (isBitSet(dist->usedBlobsBits, (uint16) clump) == 0)
  {
    return minDist;
  }

  *track1 = -1;
  *track2 = -1;
  mergeMatrixPtr = dist->mergeMatrix + clump*TRACKER_NUM_MERGE_PAIRS;
  mergeTrackIdx1Ptr = dist->mergeTrackIdx1 + clump*TRACKER_NUM_MERGE_PAIRS;
  mergeTrackIdx2Ptr = dist->mergeTrackIdx2 + clump*TRACKER_NUM_MERGE_PAIRS;
  for (i = 0; i < TRACKER_NUM_MERGE_PAIRS; i++, mergeMatrixPtr++, mergeTrackIdx1Ptr++, mergeTrackIdx2Ptr++)
  {
    int16 trackIdx1 = *mergeTrackIdx1Ptr;
    int16 trackIdx2 = *mergeTrackIdx2Ptr;
    if (trackIdx1 >= 0 && trackIdx2 >= 0 && (isBitSet(dist->usedTracksBits, (uint16) trackIdx1) == 1) && (isBitSet(dist->usedTracksBits, (uint16) trackIdx2) == 1))
    {
      minDist = *mergeMatrixPtr;
      *track1 = trackIdx1;
      *track2 = trackIdx2;
      return minDist;
    }
  }

  return minDist;
}
#endif //cfg_hasHungarianTrackingAlgorithm

static int16 findEmptyTrack(trackedObject_t *trackedObjects, dists_t *dist, uint16 start)
{
  int16 track = -1;
  uint16 i;
  trackedObject_t *trackPtr = &trackedObjects[start];
  for (i = start; i < MAX_OBJECTS; i++, trackPtr++)
  {
    if ((trackPtr->clumpId == 0) &&
        (isBitSet(dist->usedTracksBits, i) == 0))
    {
      track = i;
      break;
    }
  }
  return track;
}

static void assignTracksToNewObjects(trackedObject_t *trackedObjects, blobStats_t *stats, dists_t *dist)
{
  uint16 i;
  int16 tid = -1;

  for (i = 0; i < MAX_OBJECTS; i++)
  {
    if (isBitSet(dist->usedBlobsBits, i))
    {
      tid = findEmptyTrack(trackedObjects, dist, (uint16) (tid + 1));
      if (tid >= 0)
      {
        trackedObject_t *trackPtr;
        blobStats_t *s;
        s = &stats[i];
        dist->usedTracksBits = setBit(dist->usedTracksBits, (uint16)tid);

        trackPtr = &trackedObjects[tid];
        trackPtr->trackedFrames = 1;
        trackPtr->missingFrames = 0;
        trackPtr->pixelCount = s->pixelCount;
        trackPtr->polarity = s->polarity;
        trackPtr->clumpId = s->clumpId;
        trackPtr->blobId = s->blobId;
        trackPtr->xCentroid = s->x;
        trackPtr->yCentroid = s->y;
        trackPtr->zerothMoment = s->z;
        trackPtr->speedx = 0;
        trackPtr->speedy = 0;
      }
    }
  }
}

static void freeUnusedTracks(trackedObject_t *trackedObjects)
{
  uint16 i;

  trackedObject_t *trackPtr = trackedObjects;

  for (i = 0; i < MAX_OBJECTS; i++, trackPtr++)
  {
    if ((trackPtr->clumpId == 0) && (trackPtr->zerothMoment > 0))
    {
      if (trackPtr->missingFrames < 1)
      {
        trackPtr->missingFrames++;
      }
      else
      {
        memset16(trackPtr, 0, sizeof(*trackPtr) / sizeof(uint16));
      }
    }
  }
}

/* =================================================================
   MODULE NON-STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------
Name: tracker_init
Purpose: Initializes tracker
Inputs: None
Outputs: None.
Effects: Clears all trackedObjects, so if called while some trackedObjects are
         active, they may switch track IDs.
Notes: None.
----------------------------------------------------------- */
void tracker_init()
{
  oldNumObjects = 0;
  oldNumSplits = 0;
  memset16(trackedObjects, 0, MAX_OBJECTS * sizeof(*trackedObjects) / sizeof(uint16));

#if CONFIG_HAS_LGM_MERGER
  memset16(&cupboard, 0, sizeof(cupboard) / sizeof(uint16));
#endif
}

/* -----------------------------------------------------------
Name: tracker_reinit
Purpose: Reinitializes tracker after rezero or configuration
         update.
Inputs: None
Outputs: None.
Effects: Clears all trackedObjects, so if called while some trackedObjects are
         active, they may switch track IDs.
Notes: None.
----------------------------------------------------------- */
void tracker_reinit()
{
  tracker_init();
}

/* -----------------------------------------------------------
Name: tracker_configure
Purpose: Configures tracker
Inputs: trackerConfig_t structure with accelDrumming and
        mindistDrumming parameter values
Outputs: None.
Effects: Must be called *before* init() or reinit().
Notes: None.
----------------------------------------------------------- */
void tracker_configure(trackerConfig_t *trackerConfig)
{
  uint16 v;
  uint32 v32;

  maxDistPerMs_px = trackerConfig->maxDistPerMs_px;

  // convert to 8.8 and divide by four, to approximately convert
  // millimeters to sensor pitches and approximate old behavior.
  v = trackerConfig->mindistDrumming<<6;
  v32 = ((uint32)v*v)>>8;
  drumFilter.minDistSquared = (uint8p8) v32;

  // convert to 8.8 and divide by four
  v = trackerConfig->accelDrumming<<6;
  v32 = ((uint32)v*v)>>8;
  drumFilter.minAccelSquared = (uint8p8) v32;

  drumFilter.palmSize = 135;

#if CONFIG_HAS_LESSER_BLOB_TRACKER
  mindBlobsLess = trackerConfig->mindBlobsLess;
#endif
}

/* -----------------------------------------------------------
Name: tracker_track
Purpose: Tracks objects from one frame to another
Inputs: deltaImage
        clumps structure
        timeSinceLast_ms - time since the last frame
Outputs: None.
Effects: None.
Notes: None.
----------------------------------------------------------- */
trackedObject_t *tracker_track(int16 *deltaImage, clumps_t *clumps, uint16 timeSinceLast_ms, sensorParams_t *sensorParams)
{
#if CONFIG_HAS_LGM_MERGER
  pick();
#endif

  blobStats_t stats[MAX_OBJECTS];
  uint16 newNumObjects = 0;
  uint16 newNumSplits = 0;
  uint16 tertDistFlag;

  {
    uint16 i;
    clumpInfo_t *clumpInfoPtr = clumps->info;
    newNumSplits = 0;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      newNumSplits += clumpInfoPtr->splitCount;
      newNumObjects += (clumpInfoPtr->peakCount > 0);
      clumpInfoPtr++;
    }
    newNumObjects += newNumSplits;
  }

  tertDistFlag = (oldNumObjects > 0 && newNumSplits < oldNumSplits);

  calcObjectStatistics(deltaImage, clumps, sensorParams, stats);
  {
    // limit the scope of the *huge* distance matrix to save stack RAM
    dists_t dist;

    makeDistanceMatrix(trackedObjects, stats, timeSinceLast_ms, tertDistFlag, maxDistPerMs_px, &dist);
    clearTrackClumpIds(trackedObjects);

    #if cfg_hasHungarianTrackingAlgorithm
      optMatch(trackedObjects, stats, &dist, timeSinceLast_ms, &drumFilter);
    #else
      greedyMatch(trackedObjects, stats, &dist, timeSinceLast_ms, &drumFilter, tertDistFlag);
    #endif

    assignTracksToNewObjects(trackedObjects, stats, &dist);
    freeUnusedTracks(trackedObjects);
  }
  oldNumSplits = newNumSplits;
  oldNumObjects = newNumObjects;

#if CONFIG_HAS_LGM_MERGER
  stash();
#endif
  return trackedObjects;
}
