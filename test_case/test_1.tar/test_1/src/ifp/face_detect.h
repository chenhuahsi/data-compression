#ifndef _FACE_DETECT_H_
#define _FACE_DETECT_H_
/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   1251 McKay Drive
   San Jose, CA   95131
   (408) 454-5100

   Description: Header for noise blob filter. This is a temporary
                workaround for tracker design issues.
   $Id: filter_noise_blobs.h,v 1.1.4.3 2013/03/29 19:51:20 rfreeze Exp $
----------------------------------------------------------------- */
#include "ifp_common.h"

/* =================================================================
   MODULE FUNCTION DECLARATIONS
==================================================================*/

/* -----------------------------------------------------------
Name: faceDetect_detect
Purpose:
Inputs:
Outputs: blobs - the blobs, with noise blobs filtered out
Effects: None.
Notes: None
Example: None.
----------------------------------------------------------- */
#if CONFIG_HAS_FACE_DETECT
  void faceDetect_configure(faceDetectConfig_t *faceDetectConfig);
  void faceDetect_reinit();
  void faceDetect_init();
  uint16 isFaceDetected(uint16* rawProfileRX);
#else
  static ATTR_INLINE void faceDetect_configure(faceDetectConfig_t *faceDetectConfig ATTR_UNUSED) {;}
  static ATTR_INLINE void faceDetect_reinit() {;}
  static ATTR_INLINE void faceDetect_init() {;}
  static ATTR_INLINE uint16 isFaceDetected(uint16* rawProfileRX ATTR_UNUSED) { return 0; }
#endif

#endif /* matches #ifndef _FACE_DETECT_H_ */
