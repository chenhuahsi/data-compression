// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100
//
// -----------------------------------------------------------------
//
// Checks if the current baseline looks fishy. It will report a baseline
// error in such case, which will be used by baseline_manager to decide
// what to do.

/* =================================================================
   MODULE INCLUDES
==================================================================*/

#include "ifp_common.h"
#include "baseline_checker.h"
//#include "tags_calculator.h"
#include "ifp_string.h"

/* =================================================================
   MODULE VARIABLES
==================================================================*/
// configuration knobs
static baselineCheckerConfig_t bcConfig;

// What caused a baseline error. Each variable contains the number of
// times a baselineError was produced by different reasons.
static baselineErrorCounts_t n_baselineError;

// Saved bumpiness of the baseline.
static int32 bumpBL;

/* =================================================================
   MODULE STATIC FUNCTIONS DECLARATIONS
==================================================================*/

static uint16 bumpinessCheck(sensorParams_t *sensorParams, int16 negativeFingerThreshold,
  uint16 *baselineEstimate, uint16 *rawImage, int16 *deltaImage,
  uint16 liftBumpinessThreshold, uint16 bumpinessScaleDownBits,
  sensorDirection_t bumpinessDirection);
static uint16 globalEnergyRatioCheck(sensorParams_t *sensorParams, uint16 *rawImage,
    imageBaseline_t *imageBaseline, int16 sumNoiseThreshold, uint16 energyRatioThreshold);
ATTR_INLINE static uint16 absPositivityCheck(uint16 *rawProfile,
  uint16 *baselineEstimate, uint16 length, int16 threshold,
  int16 posSumMinRatio);
static uint16 anyValuesBelowThreshold(int16 *array, uint16 length, int16 threshold);
ATTR_INLINE static void saturatingIncrementUint16(uint16 *x);

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: bumpinessCheck
Purpose: Compute the bumpiness of the baseline and compare with that of
         the raw image, to see if it is significantly more bumpy. If it is
         and there are negative pixels, detect a bad baseline.
Inputs: sensor parameters, threshold for when a pixels is considered negative,
        current baseline, raw image, delta image, threshold for bumpiness,
        bits to adjust bumpiness for a bigger dynamic range, sensor direction
        to use for bumpiness computation.
Outputs: boolean check failure.
Effects: None.
Notes: Internal to this file only.
------------------------------------------------------------------ */
static uint16 bumpinessCheck(sensorParams_t *sensorParams,
                             int16 negativeFingerThreshold,
                             uint16 *baselineEstimate,
                             uint16 *rawImage,
                             int16 *deltaImage,
                             uint16 liftBumpinessThreshold,
                             uint16 bumpinessScaleDownBits,
                             sensorDirection_t bumpinessDirection)
{
  uint16 liftDetected = 0;  // so far
  int32 bumpRaw;

  if (bumpinessDirection == sensorDirection_none || negativeFingerThreshold == 0 || liftBumpinessThreshold == 0)
    {
    return liftDetected;  // check is disabled
  }

  if (!anyValuesBelowThreshold(deltaImage + (MAX_RX + 1), (MAX_RX + 1) * MAX_TX,
                               negativeFingerThreshold))
  {
    return liftDetected;  // nothing in the delta negative enough to think there is a lift
  }

  if (bumpBL == -1)  // -1 means we are not up-to-date
  {
    bumpBL = (int32) baselineChecker_computeBumpiness(sensorParams, baselineEstimate, bumpinessDirection);
  }
  bumpRaw = (int32) baselineChecker_computeBumpiness(sensorParams, rawImage, bumpinessDirection);
  liftDetected = ((bumpBL - bumpRaw) >> bumpinessScaleDownBits) > liftBumpinessThreshold;

  return liftDetected;
}

/* -----------------------------------------------------------------
Name: globalEnergyRatioCheck
Purpose: Compute the sum of positive deltas and the sum of negative
         deltas and threshold their ratio to detect a bad baseline.
Inputs: sensor parameters, raw image, current baseline, threshold for
        total noise (sum of abs of computed delta), threshold for energy
        ratio (negatives / positives).
Outputs: boolean check failure.
Effects: None.
Notes: Internal to this file only.
------------------------------------------------------------------ */
static uint16 globalEnergyRatioCheck(sensorParams_t *sensorParams, uint16 *rawImage,
                                     imageBaseline_t *imageBaseline,
                                     int16 sumNoiseThreshold, uint16 energyRatioThreshold)
{
  uint32 posSum = 0;
  uint32 negSum = 0;
  uint16 i = sensorParams->txCount;
  uint16 *blImage = imageBaseline->estimate;
  uint16 rowSkip = MAX_RX - sensorParams->rxCount;
  do
  {
    uint16 j = sensorParams->rxCount;
    do
    {
      int16 delta;
      if (CONFIG_IMAGE_DELTA_IS_POSITIVE)
      {
        delta = *rawImage++ - *blImage++;
      }
      else
      {
        delta = *blImage++ - *rawImage++;
      }
      if (delta > 0)
      {
        posSum += (uint16) delta;
      }
      else
      {
        negSum += (uint16) -delta;
      }
    } while (--j);
    blImage += rowSkip;
    rawImage += rowSkip;
  } while (--i);
  return (negSum + posSum > (uint32) sumNoiseThreshold) &&
         (negSum > energyRatioThreshold * posSum);
}

/* -----------------------------------------------------------------
Name: absPositivityCheck
Purpose: Check for sufficiently negative values in an abs delta profile.
Inputs: raw image, current baseline, array length, negativity threshold,
        ratio of (sum of positives) to min
Outputs: boolean--true if error detected
Effects: None
Notes: Internal to this file only.
       If any element of the delta profile is sufficiently negative
       flag an error UNLESS the profile is overwhelmingly positive,
       as large objects can be driven as a weak guard in LGM
       conditions and cause negativity on untouched portions of the
       sensor. This LGM-related negativity is large relative to the
       noise floor but is generally a tiny fraction of the positivity.
------------------------------------------------------------------ */
ATTR_INLINE static uint16 absPositivityCheck(uint16 *rawProfile, uint16 *baselineEstimate,
                                             uint16 length, int16 minThreshold, int16 posSumMinRatio)
{
  int16 minDelta = 0;
  int32 posSum = 0;

  // Find profile min and sum of positive elements, taking potential signed int
  // overflow into account.
  {
    uint16 i;
    uint16 *rawPtr = rawProfile;
    uint16 *blPtr = baselineEstimate;
    for (i = 0; i < length; i++, rawPtr++, blPtr++)
    {
      int16 delta = *rawPtr - *blPtr;
      if (*rawPtr > *blPtr && delta < 0) delta = 32767;
      else if (*rawPtr < *blPtr && delta > 0) delta = -32768;

      if (delta < minDelta) minDelta = delta;
      if (delta > 0) posSum += delta;
    }
  }

  return ((minDelta < minThreshold) &&
          (posSumMinRatio == 0 || posSum < (int32) posSumMinRatio * (-minDelta)));
}

/* -----------------------------------------------------------------
Name: anyValuesBelowThreshold
Purpose: Determine if there is any value in an array less than a threshold
Inputs: array, length, threshold,
Outputs: boolean--true if value exists below threshold
Effects: None
Notes: None
------------------------------------------------------------------ */
static uint16 anyValuesBelowThreshold(int16 *array, uint16 length, int16 threshold)
{
  uint16 i;
  for (i = 0; i < length; i++)
  {
    if (*array++ < threshold) return 1;
  }
  return 0;
}

/* -----------------------------------------------------------------
Name: saturatingIncrementUint16
Purpose: Increment the value of x, capping it at unit16's maximum.
Inputs: array of uint16, index (as uint16).
Outputs: None.
Effects: *x = min(*x + 1, 2^16-1).
Notes: Internal to this file only.
------------------------------------------------------------------ */
ATTR_INLINE static void saturatingIncrementUint16(uint16 *x)
{
  if (*x < 65535)
  {
    (*x)++;
  }
}

/* =================================================================
   MODULE NON-STATIC FUNCTION DEFINITIONS
==================================================================*/

/* -----------------------------------------------------------------
Name: baselineChecker_init()
Purpose: Initialize the module.
Inputs:
Outputs:
Effects: None.
Notes: Resets error counting to 0.
Example: None.
----------------------------------------------------------------- */
void baselineChecker_init(void)
{
  // Zero variables that config() does not assign values to
  memset16(&n_baselineError, 0, sizeof(n_baselineError) / sizeof(uint16));
  bumpBL = -1;  // special value: we never computed it before
}

/* -----------------------------------------------------------------
Name: baselineChecker_reinit()
Purpose: Re-initialize the Baseline Checker
Inputs:
Outputs:
Effects: None.
Notes: Same as init()
Example: None.
----------------------------------------------------------------- */
void baselineChecker_reinit(void)
{
  baselineChecker_init();
}

/* -----------------------------------------------------------------
Name: baselineChecker_configure()
Purpose: Configure the Baseline Checker module.
Inputs: baseline checker's bcConfig structure.
        The bcConfig structure should contain:
          energyRatioThreshold       - pos/neg energy ratio threshold
          absXNegThreshold_LSB       - abs X profile negativity threshold
          absYNegThreshold_LSB       - abs Y profile negativity threshold
          absPosSumMinRatio
          tagsTouchThreshold_pct
          negativeFingerThreshold_pct
          liftBumpinessThreshold
          bumpinessScaleDownBits
Outputs: None
Effects: Store configuration in module globals
Notes: None.
Example: None.
----------------------------------------------------------------- */
void baselineChecker_configure(baselineCheckerConfig_t *inConfig)
{
  bcConfig = *inConfig;
}

/* -----------------------------------------------------------------
Name: baselineChecker_check
Purpose: Check for object that might prevent baseline update and errors,
         which might require fast relaxation.
Inputs: sensor parameters, raw image, current baseline, current X
        and Y abs baselines, delta, classifications
Outputs: boolean object present, boolean errors present
Effects: None.
Notes: None.
Example: None.
----------------------------------------------------------------- */
void baselineChecker_check(sensorParams_t *sensorParams,
                           ifpFrame_t *frame,
                           imageBaseline_t *imageBaseline,
                           absXBaseline_t *absXBaseline,
                           absYBaseline_t *absYBaseline,
                           int16 *deltaImage,
                           classification_t *classifications,
                           uint16 *objectsPresent,
                           uint16 *errorsPresent)
{
  uint16 hasObject = 0;
  uint16 hasError = 0;
  uint16 energyRatioThreshold = bcConfig.energyRatioThreshold;

  // Update bumpBL
  if (imageBaseline->modified) bumpBL = -1;  // special value: needs update

  /* see what the classifier says is on the sensor */
  {
    uint16 i;
    classification_t *classPtr = classifications;

    for (i = 0; i < MAX_OBJECTS; i++)
    {
      touchType_t touchType = (touchType_t) (classPtr++)->touchType;
      hasObject |= (touchType == touchType_finger ||
                  touchType == touchType_glove ||
                  touchType == touchType_thickGlove ||
                  touchType == touchType_smallObject ||
                  touchType == touchType_stylus ||
                  touchType == touchType_eraser ||
                  touchType == touchType_palm);
      /* TODO: hand edges, moisture, noise, LGM, ... */
      if (touchType == touchType_baselineError)
      {
        saturatingIncrementUint16(&n_baselineError.classification);
        hasError = 1;
      }
    }
  }

  /* If TAGS says that sensor is empty, take negatives more seriously,
     as we can't have any LGM artifacts. This means that we should
     lower the energy ratio threshold and even treat individual
     negative pixels as errors. But TAGS isn't necessarily sensitive to
     tiny things like pens. Only treat individual negative pixels as
     errors if the frame is demonstrably smoother than the baseline,
     indicating a lift. */
  if (bcConfig.negativeFingerThreshold_pct != 0 && bcConfig.liftBumpinessThreshold != 0 &&
      imageBaseline->acquired && (frame->rawImage != NULL) && !hasError)
  {
    int16 negativeFingerThreshold = -((int16) (((uint26p6) bcConfig.negativeFingerThreshold_pct * sensorParams->cSat_LSB) >> 6));

    /* Is the raw image significantly smoother than the baseline and we also
       have individual negative pixels? */
    if (bumpinessCheck(sensorParams, negativeFingerThreshold,
                       imageBaseline->estimate, frame->rawImage, deltaImage,
                       bcConfig.liftBumpinessThreshold, bcConfig.bumpinessScaleDownBits,
                       (sensorDirection_t) bcConfig.bumpinessDirection))
    {
      saturatingIncrementUint16(&n_baselineError.bumpiness);
      hasError = 1;
    }
#if 0 // TBD
    else if (bcConfig.tagsTouchThreshold_pct > 0)
    {
      int16 tagsTouchThreshold_LSB = (int16) (((uint24p8) bcConfig.tagsTouchThreshold_pct * sensorParams->cSat_LSB) >> 8);
      tagsStats_t stats = tagsCalculator_computeStats(sensorParams, frame->rawImage);
      if (stats.max < tagsTouchThreshold_LSB)
      {
        /* If sensor is empty but we didn't detect a localized negative blip, we'll
           try to look harder for diffuse negativity.
           (This is roughly the metal plate check.) */
        energyRatioThreshold = (energyRatioThreshold & 0xFFF8) ? (energyRatioThreshold >> 2) : 1;
                               // max(x / 4, 1)
      }
    }
#endif
  }

  if (imageBaseline->acquired && (frame->rawImage != NULL) && energyRatioThreshold > 0 && !hasError)
  {
    int16 sumNoiseThreshold = (int16) (((int32) sensorParams->noiseFloor_LSB * sensorParams->rxCount * sensorParams->txCount) >> 2);
    if (globalEnergyRatioCheck(sensorParams, frame->rawImage, imageBaseline, sumNoiseThreshold, energyRatioThreshold) != 0)
    {
      if (energyRatioThreshold == bcConfig.energyRatioThreshold)
      {
        saturatingIncrementUint16(&n_baselineError.globalEnergyRatio);
      }
      else  // we modified the value of energyRatioThreshold as part of the metal plate check
      {
        saturatingIncrementUint16(&n_baselineError.metalPlate);
      }
      hasError = 1;
    }
  }
  if (MAX_ABS_RX > 1 && absXBaseline->acquired && (frame->rawProfileRX != NULL) &&
      bcConfig.absXNegThreshold_LSB > 0 &&
      !hasError)
  {
    if (absPositivityCheck(frame->rawProfileRX, absXBaseline->estimate, sensorParams->rxCount,
                           -((int16) bcConfig.absXNegThreshold_LSB), (int16) bcConfig.absPosSumMinRatio) != 0)
    {
      saturatingIncrementUint16(&n_baselineError.absPositivityRX);
      hasError = 1;
    }
  }
  if (MAX_ABS_TX > 1 && absYBaseline->acquired && (frame->rawProfileTX != NULL) &&
      bcConfig.absYNegThreshold_LSB > 0 &&
      !hasError)
  {
    if (absPositivityCheck(frame->rawProfileTX, absYBaseline->estimate, sensorParams->txCount,
                           -((int16) bcConfig.absYNegThreshold_LSB), (int16) bcConfig.absPosSumMinRatio) != 0)
    {
      saturatingIncrementUint16(&n_baselineError.absPositivityTX);
      hasError = 1;
    }
  }
  *objectsPresent = hasObject;
  *errorsPresent = hasError;
}

/* -----------------------------------------------------------------
Name: baselineChecker_getErrorCounts
Purpose: See the type of errors that caused baseline errors.
Inputs: None.
Outputs: Struct baselineErrorCounts with the number of times each
         error happened.
Effects: None.
Notes: None.
Example: None.
------------------------------------------------------------------ */
void baselineChecker_getErrorCounts(baselineErrorCounts_t *n_errors)
{
  *n_errors = n_baselineError;
}

/* -----------------------------------------------------------------
Name: baselineChecker_computeBumpiness
Purpose: Compute the bumpiness on a raw image, which is approximately the sum
         of absolute values of first derivatives (x and y).
Inputs: sensor params, raw image, sensor direction to use for bumpiness computation
Outputs: bumpiness metric
Effects: None
Notes: This is not the same as the bumpiness metric in baseline_check.c,
       but I think that the spirit is the same. In baseline_check.c, the
       x and y derivatives are summed for each pixel before taking the
       absolute value, but it's annoying because the separate derivative
       arrays are not the same size. Hence, I take the absolute value of
       each derivative before summing.
       Note that the image here is assumed to be not zero-padded and
       it doesn't require any TAGS punchouts.
------------------------------------------------------------------ */
uint32 baselineChecker_computeBumpiness(sensorParams_t *sp, uint16 *image,
                                        sensorDirection_t bumpinessDirection)
{
  uint32 bumpSum = 0;

  // sum(abs(diffX(image)))
  if (bumpinessDirection == sensorDirection_rows ||
      bumpinessDirection == sensorDirection_rowsAndCols)
  {
    uint16 i;
    for (i = 0; i < sp->txCount; i++)
    {
      uint16 *image_p = &image[i * MAX_RX];
      uint16 j = sp->rxCount - 1;
      do
      {
        int16 grad = image_p[1] - image_p[0];
        image_p++;
        bumpSum += (grad > 0) ? (uint16) grad : (uint16) -grad;
      } while (--j);
    }
  }

  // sum(abs(diffY(image)))
  if (bumpinessDirection == sensorDirection_cols ||
      bumpinessDirection == sensorDirection_rowsAndCols)
  {
    uint16 i;
    for (i = 0; i < sp->txCount - 1; i++)
    {
      uint16 *image_p = &image[i * MAX_RX];
      uint16 j = sp->rxCount;
      do
      {
        int16 grad = image_p[MAX_RX] - image_p[0];
        image_p++;
        bumpSum += (grad > 0) ? (uint16) grad : (uint16) -grad;
      } while (--j);
    }
  }

  return bumpSum;
}
