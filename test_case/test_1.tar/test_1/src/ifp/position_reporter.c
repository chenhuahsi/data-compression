/* -----------------------------------------------------------------

                        COMPANY CONFIDENTIAL
                         INTERNAL USE ONLY

   Copyright (C) 1997 - 2012  Synaptics Incorporated.  All right reserved.

   This document contains information that is proprietary to Synaptics
   Incorporated. The holder of this document shall treat all information
   contained herein as confidential, shall use the information only for its
   intended purpose, and shall protect the information in whole or part from
   duplication, disclosure to any other party, or dissemination in any media
   without the written permission of Synaptics Incorporated.

   Synaptics Incorporated
   3120 Scott Blvd
   Santa Clara, CA   95054
   (408) 454-5100

   Filename: position_reporter.c
   Description: Packs positions into reported data structure.
                Also implements palm filtering, reduced reporting mode.

 $Id: position_reporter.c,v 1.4.8.2 2012/08/29 18:34:07 jjordan Exp $
----------------------------------------------------------------- */

#include "ifp_common.h"
#include "ifp_string.h"
#include "position_reporter.h"
#include "ifp_bit_manipulation.h"
#if CONFIG_GRIPSUPPRESSION_RULE2
#include "../grip_suppression.h"
#endif

/* =================================================================
   MODULE MACROS/CONSTANTS
==================================================================*/
#define THICK_GLOVE_DIST 2
#define THICK_GLOVE_FRAME_COUNT 12
/* =================================================================
   MODULE TYPES
==================================================================*/

typedef struct {
  int16 x;
  int16 y;
  hostClassification_t c; //Takashi: Fixed reduced reporting so that changing touch type updates finger position report.
} xy_t;

typedef enum
{
  palmFilterState_none,
  palmFilterState_reject
} palmFilterState_t;

typedef enum
{
  skinModeFilterState_none,
  skinModeFilterState_reject
} skinModeFilterState_t;

/* =================================================================
   MODULE VARIABLES
==================================================================*/

static int16 reportedIndices[MAX_OBJECTS];
static objectBitmask_t freeReportedIndices;
static objectBitmask_t liftedIndices;
static xy_t exceptionsPositions[MAX_OBJECTS];
static hostClassification_t exceptionsClasses[MAX_OBJECTS];
static xy_t lastReportedPosition[MAX_OBJECTS];
static int16 deadZoneSizeX;
static int16 deadZoneSizeY;
static uint16 forceFreshReport;
static struct palmFilterInfo {
  uint16 mode;  // palmFilterMode_t; cannot portably use enums in structs
  uint16 allowStylus;
  uint16 state;  // palmFilterState_t; cannot portably use enums in structs
  objectBitmask_t exceptions;
} palmFilter;
static uint16 maxReportedObjects;
static uint16 maxReportedObjectsAlt;
static uint16 reportedObjectTypes;  // bitmask, where bit number is hostClassification_t value
static int16 xMax;
static int16 yMax;
static uint16 origin;
#if CONFIG_EDGE_SUPPRESSION
static int16 existedTouch[MAX_OBJECTS];
static int16 edgeSuppressionDist;
#endif
#if CONFIG_IFP_CLOSEDCOVER
static closedCoverParams_t coverParamsPositionRep;
#endif
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
static uint32 posReportFilter;
#endif
#if CONFIG_HAS_REPORTS_GONE_BY_FORCE_UPDATE
static uint16 hadObjectsBeforeForceUpdate;
#endif
// skinModeFilter:
// type: 1 -'reject all touches': suppresses reporting of all specified objects in
//       "skinModeSuppressObjectTypes" when finger is touching. When all fingers are lifted,
//        will continue to reject already rejected objects
//       2 - 'reject new touches': will only suppress reporting of specified objects if they
//       land during a frame when a landed finger has already been detected. After all
//       fingers lift, rejected objects will continue to be rejected.
static struct skinModeFilterInfo {
  uint16 type;
  uint16 state;               // state of filter: 'none', 'reject'
  objectBitmask_t exceptions; //BitMask of objects reported during skinMode
  objectBitmask_t rejections; //BitMask of objects rejected during skinMode
} skinModeFilter;
static uint16 skinModeSuppressObjectTypes;  // bitmask, where bit number is hostClassification_t value
                                            // type of objects to suppress during skinMode

// These are the host classifications that map cleanly to internal
// classifications.
struct {
  uint16 touchType;  // touchType_t
  uint16 hostClass;  // hostClassification_t
  uint16 reportedObjectBit;
} ATTR_ROM classMap[] = {
  {touchType_finger, hostClassification_finger, 1 << hostClassification_finger},
  {touchType_smallObject, hostClassification_smallObject, 1 << hostClassification_smallObject},
  {touchType_glove, hostClassification_glove, 1 << hostClassification_glove},
  {touchType_palm, hostClassification_palm, 1 << hostClassification_palm},
  {touchType_stylus, hostClassification_stylus, 1 << hostClassification_stylus},
  {touchType_eraser, hostClassification_eraser, 1 << hostClassification_eraser},
};

typedef struct
{
  touchType_t touchType;
  int8p8 xPos;
  int8p8 yPos;
} priorState_t;
static priorState_t priorState[MAX_OBJECTS];
static uint16 frameCnt;

/* =================================================================
   MODULE FUNCTIONS DECLARATIONS
==================================================================*/

static objectBitmask_t classMaskToObjMask(hostClassification_t *objClass, uint16 classBitmask);
static void clearStates();

/* =================================================================
   MODULE STATIC FUNCTIONS DEFINITIONS
==================================================================*/
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
int16 metal_detection_getState(void);
#else
#define metal_detection_getState() 0
#endif

/* -----------------------------------------------------------
Purpose: Given a bitmask of (1 << hostClassification_t), find which objects have any of those classifications
Inputs: array of host classifications, bitmask of host classifications of interest
Outputs: bitmask of which objects match classification mask
Effects: none
Notes: none
----------------------------------------------------------- */
static objectBitmask_t classMaskToObjMask(hostClassification_t *objClass, uint16 classBitmask)
{
  objectBitmask_t objMask = 0;
  uint16 i;
  objectBitmask_t objBit = 1;
  for (i = 0; i < MAX_OBJECTS; i++, objBit <<= 1, objClass++)
  {
    if ((powerOfTwo(*objClass) & classBitmask) != 0)
    {
      objMask |= objBit;
    }
  }
  return objMask;
}

/* -----------------------------------------------------------------
Name: clearStates
Purpose: Clear prior report states (used by thick glove)
Inputs: None
Outputs: None
Effects: None
Notes: None
Example: None.
----------------------------------------------------------------- */
static void clearStates(void)
{
  uint16 i;

  for (i = 0; i < MAX_OBJECTS; i++)
  {
    priorState[i].touchType = touchType_none;
    priorState[i].xPos = -1*ONE_8p8;
    priorState[i].yPos = -1*ONE_8p8;
  }
}

// - external functions

/* -----------------------------------------------------------
Name: posReporter_init()
Purpose: Initializes the position reporter
Inputs: none
Outputs: none
Effects: Resets internal state of coordinate converter, as at
         power-on.
Notes: This function must be called before using the position
       reporter module.
Example: none
----------------------------------------------------------- */
void posReporter_init(void)
{
  // When we reinit, we reset our internal state, but not the host's. If a
  // finger was down at reinit, we want to remember that so that we can signal
  // its lift by asserting attention.
  memset16(reportedIndices, -1, sizeof(reportedIndices) / sizeof(uint16));
  posReporter_reinit();
}

/* -----------------------------------------------------------
Name: posReporter_reinit()
Purpose: Reinitializes the position reporter
Inputs: none
Outputs: none
Effects: Resets internal state of position reporter, as at a
         host rezero.
Notes: This function must be called if the host sends a rezero
       command.
Example: none
----------------------------------------------------------- */
void posReporter_reinit(void)
{
  memset16(lastReportedPosition, -1, sizeof(lastReportedPosition) / sizeof(uint16));
#if CONFIG_EDGE_SUPPRESSION
  memset16(existedTouch, -1, sizeof(existedTouch) / sizeof(uint16));
#endif

  { //Takashi: Fixed reduced reporting so that changing touch type updates finger position report.
    uint16 i;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      lastReportedPosition[i].c = hostClassification_none;
    }
  }

  freeReportedIndices = (objectBitmask_t) -1;
  liftedIndices = (objectBitmask_t) 0;

  palmFilter.state = palmFilterState_none;
  palmFilter.exceptions = 0;

  skinModeFilter.state = skinModeFilterState_none;
  skinModeFilter.exceptions = 0;
  skinModeFilter.rejections = 0;

  // thick glove states
  frameCnt = 0;
  clearStates();
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
  posReportFilter = 0;
#endif
}

/* -----------------------------------------------------------
Name: posReporter_configure()
Purpose: Set host-defined parameters
Inputs: deadZoneSizeX, deadZoneSizeY: the half-width of the
          region the finger must leave in order for the freshReport
          flag to be set
        forceFreshReport: forces freshReport flag to be set on
          every frame.
        palmFilterMode: none, reject all touches, or
          reject new touches
        palmFilterAllowStylus: true or false, whether to allow
          a stylus to be reported while a palm is detected if the
          palm filter is enabled.
        maxReportedObjects: how many elements of the reported
          fingers structure to populate and set the freshReport
          flag based on.
        maxReportedObjectsAlt: alternate value that can be
          swapped into the role of maxReportedObjects at
          runtime via the useMaxReportedObjectsAlt flag to
          posReporter_makeReport.
        reportedObjectTypes: bitmask of 'touching
          finger', 'stylus', 'palm', 'unknown' as desired,
          specifies which objects to put in the reported fingers
          structure.
        skinModeFilterType: none, reject all touches, or
          reject new touches. (Skin Mode filter is meant to specify if
          the reporting of any object type should be suppressed in
          the presence of touching fingers)
        skinModeSuppressObjectTypes: Type of objects to suppress
          during skinMode.
Outputs: none
Effects: none
Notes:   none
Example: none
----------------------------------------------------------- */
void posReporter_configure(positionRepConfig_t* config)
{
  deadZoneSizeX = (int16) config->deadZoneSizeX;
  deadZoneSizeY = (int16) config->deadZoneSizeY;
  forceFreshReport       = config->forceFreshReport;
  palmFilter.mode        = config->palmFilterMode;
  palmFilter.allowStylus = config->palmFilterAllowStylus;
  maxReportedObjects     = config->maxReportedObjects;
  maxReportedObjectsAlt  = config->maxReportedObjectsAlt;
  reportedObjectTypes    = config->reportedObjectTypes;
  skinModeFilter.type    = config->skinModeFilterType;
  skinModeSuppressObjectTypes = config->skinModeSuppressObjectTypes;
  xMax                   = config->xMax;
  yMax                   = config->yMax;
  origin                 = config->origin;
#if CONFIG_EDGE_SUPPRESSION
  edgeSuppressionDist    = (int16)config->edgeSuppressionDist;
#endif
#if CONFIG_IFP_CLOSEDCOVER
  memcpy16(&coverParamsPositionRep, &config->closedCoverParams, sizeof(coverParamsPositionRep) / sizeof(uint16));
#endif
#if CONFIG_HAS_REPORTS_GONE_BY_FORCE_UPDATE
  hadObjectsBeforeForceUpdate |= config->reportGoneByForceUpdate << 1;
#endif
}
/* -----------------------------------------------------------
Name: isInClosedCoverSmallWindowZone()
Purpose: whether is in cover small window zone
Inputs: position(x,y)
Outputs: 1 - in zone; 0 - not in zone
Effects: none
Notes: none
Example: none
----------------------------------------------------------- */
#if CONFIG_IFP_CLOSEDCOVER
static uint16 isInClosedCoverSmallWindowZone(int16 xPos, int16 yPos)
{
    return ((xPos >= (int16)coverParamsPositionRep.closedCoverXmin) &&
            (xPos <= (int16)coverParamsPositionRep.closedCoverXmax) &&
            (yPos >= (int16)coverParamsPositionRep.closedCoverYmin) &&
            (yPos <= (int16)coverParamsPositionRep.closedCoverYmax));
}

uint16 getClosedCoverStatus(void)
{
  return (coverParamsPositionRep.closedCoverEnable);
}

uint0p16 getClosedCoverThresholdPct(void)
{
  return ((uint0p16)(coverParamsPositionRep.closedCoverThreshold<<8));
}
#endif
void setPosReporterDynamicConfig(ifpMode_t *pMode)
{
  #if CONFIG_IFP_CLOSEDCOVER
  coverParamsPositionRep.closedCoverEnable = pMode->closedCoverEnabled & 0x01;
  #endif
  reportedObjectTypes = pMode->reportedObjectTypes;
}

/* -----------------------------------------------------------
Name: posReporter_makeReport()
Purpose: builds a position report structure
Inputs: hostPositions - positions in host units
        sensorPositions - positions in sensor units
        classifications - object classifications
        holdLiftedIndices - while true, indices of lifted
            fingers are not reused for new objects
Outputs: report - the report data structure
Effects: none
Notes: none
Example: none
----------------------------------------------------------- */
void posReporter_makeReport(hostPosition_t *hostPositions,
                            sensorPosition_t *sensorPositions,
                            classification_t *classifications,
                            uint16 holdLiftedIndices,
                            uint16 useMaxReportedObjectsAlt,
                            reportData_t *report)
{
  hostClassification_t objClass[MAX_OBJECTS];
  objectBitmask_t objReportFlag = 0;
  objectBitmask_t freshData;

  uint16 objectsPresentFlag = 0;
  uint16 maxReportedObjectsCurr;
  uint16 touchFlagPresent = 0;
  uint16 thickGlovePresent = 0;
  uint16 thickGlovePresentIndex = 0;
  uint16 thickGlovePrior = 0;
  uint16 thickGlovePriorIndex = 0;

  objectBitmask_t palmMask = 0;
  objectBitmask_t newLiftedIndices;
  uint16 i;

  // -- determine whether there are any objects to report --

  {
    objectBitmask_t objBitmask;
    hostClassification_t *curObjClass = objClass;
    classification_t *curInClass = classifications;
    uint16 i;

    for (i = 0, objBitmask = 1; i < MAX_OBJECTS; i++, objBitmask <<= 1, curInClass++, curObjClass++)
    {
      objectsPresentFlag |= (curInClass->touchType != touchType_none);  // independent of what's reported

      *curObjClass = hostClassification_none;
      if (curInClass->touchFlag && !curInClass->bufferTouchFlag)
      {
        uint16 i;
        // Search reportedObjectType to check whether a report of this type is allowed.
        for (i = 0; i < sizeof(classMap) / sizeof(*classMap); i++)
        {
          if (curInClass->touchType == classMap[i].touchType)
          {
            if (reportedObjectTypes & classMap[i].reportedObjectBit)
            {
              *curObjClass = (hostClassification_t) classMap[i].hostClass;
              objReportFlag |= objBitmask;
            }
            break;  // whether reported or not, no other touchType is relevant
          }
        }
      }
    }
  }

  // thick glove flags
  for (i = 0; i < MAX_OBJECTS; i++)
  {
    touchFlagPresent |= classifications[i].touchFlag;
    if (classifications[i].touchType == touchType_thickGlove)
    {
        thickGlovePresent = 1;
        thickGlovePresentIndex = i;
    }
    if (priorState[i].touchType == touchType_thickGlove)
    {
        thickGlovePrior = 1;
        thickGlovePriorIndex = i;
    }
  }

  // check for transition from thick glove
  if (touchFlagPresent && !thickGlovePresent && thickGlovePrior)
  {
    uint16 ind = 0;
    uint16 dist = 32767;
    uint16 dist2;

    // determine prior reported index
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (classifications[i].touchFlag &&
          ((classifications[i].touchType == touchType_finger) ||
           (classifications[i].touchType == touchType_glove) ||
           (classifications[i].touchType == touchType_smallObject)))
      {
        dist2 = IFP_ABS(sensorPositions[i].xPosition - priorState[thickGlovePriorIndex].xPos) + IFP_ABS(sensorPositions[i].yPosition - priorState[thickGlovePriorIndex].yPos);
        if (dist2 < dist)
        {
          dist = dist2;
          ind = i;
        }
      }
    }
    // recycle prior thick glove index if its position is close enough to the current classified position
    if (dist < THICK_GLOVE_DIST)
    {
      objectBitmask_t outMask;
      int16 reportIdx;

      // reset prior reported indices
      for (i = 0; i < MAX_OBJECTS; i++)
      {
        reportedIndices[i] = -1;
      }
      reportedIndices[ind] = thickGlovePriorIndex;
      freeReportedIndices = (objectBitmask_t) -1;
      reportIdx = findLowestSetBit(thickGlovePriorIndex+1);
      outMask = powerOfTwo((uint16) reportIdx);
      freeReportedIndices &= ~outMask;
      // reset new touch flag
      classifications[ind].newTouchFlag = 0;
    }
  }

  // check for thick glove mode (it will be the only reported touch flag)
  // note: this processing will need to occur for the duration of thick glove mode, not just the transition
  if (thickGlovePresent)
  {
    uint16 ind = 0;
    uint16 dist = 32767;
    uint16 dist2;

    // determine prior report index
    ind = thickGlovePresentIndex;
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if ((priorState[i].touchType == touchType_thickGlove) ||
          (priorState[i].touchType == touchType_finger) ||
          (priorState[i].touchType == touchType_glove) ||
          (priorState[i].touchType == touchType_smallObject))
      {
        dist2 = IFP_ABS(sensorPositions[thickGlovePresentIndex].xPosition - priorState[i].xPos) + IFP_ABS(sensorPositions[thickGlovePresentIndex].yPosition - priorState[i].yPos);
        if (dist2 < dist)
        {
          dist = dist2;
          ind = i;
        }
      }
    }
    // use thick glove index if prior index corresponds to non-glove and is far enough away from current thick glove position
    if ((priorState[ind].touchType != touchType_glove) &&
        (priorState[ind].touchType != touchType_thickGlove) &&
        (dist > THICK_GLOVE_DIST))
    {
        ind = thickGlovePresentIndex;
    }

    // set report index using determined index only if prior index corresponds to glove or is far enough away from current thick glove position
    if ((priorState[ind].touchType == touchType_glove) ||
        (priorState[ind].touchType == touchType_thickGlove) ||
        (dist > THICK_GLOVE_DIST))
    {
      objectBitmask_t outMask;
      int16 reportIdx;

      reportIdx = findLowestSetBit(thickGlovePresentIndex+1);
      outMask = powerOfTwo((uint16) reportIdx);
      objReportFlag |= outMask;
      objClass[thickGlovePresentIndex] = hostClassification_glove;  // reclassify as glove for report
      // reset prior reported indices
      for (i = 0; i < MAX_OBJECTS; i++)
      {
        reportedIndices[i] = -1;
      }
      reportedIndices[thickGlovePresentIndex] = ind;
      freeReportedIndices = (objectBitmask_t) -1;
      freeReportedIndices &= ~outMask;
      // reset new touch flag
      classifications[thickGlovePresentIndex].newTouchFlag = 0;
      // reset prior positions
      if (!thickGlovePrior)
      {
        lastReportedPosition[thickGlovePresentIndex].x = lastReportedPosition[ind].x;
        lastReportedPosition[thickGlovePresentIndex].y = lastReportedPosition[ind].y;
      }
    }
    else
    {  // inhibit thick glove
      touchFlagPresent = 0;  // thick glove is a single, sole classification, so disable touch present flag
    }
  }

  // --- palm filter ---
  // Find palms, reported or not.
  {
    int16 i;
    objectBitmask_t bit;
    classification_t *cla = classifications;
    for (i = 0, bit = 1; i < MAX_OBJECTS; i++, bit <<= 1)
    {
      if ((cla++)->touchType == touchType_palm)
      {
        palmMask |= bit;
      }
    }
  }
  {
    struct palmFilterInfo *pf = &palmFilter;

    if ((pf->mode == palmFilterMode_rejectAllTouches) ||
        (pf->mode == palmFilterMode_rejectNewTouches))
    {
      objectBitmask_t palmMask = classMaskToObjMask(objClass, 1 << hostClassification_palm);

      switch(pf->state)
      {
      case palmFilterState_none:
        if (palmMask != 0)
        {
          pf->exceptions &= ~palmMask;
          pf->state = palmFilterState_reject;
        }
        else
        {
          // if no palm is found, then track which fingers are down now to
          // possibly exclude them from filtering when a palm arrives
          if (pf->mode == palmFilterMode_rejectNewTouches)
          {
            pf->exceptions = objReportFlag;
          }
          else // palmFilterMode_rejectAllTouches
          {
            pf->exceptions = 0;
          }
        }
        break;
      case palmFilterState_reject:
        // remove exceptions once they have lifted.
        pf->exceptions &= objReportFlag;

        if (palmMask == 0)
        {
          // wait for all non-excepted objects to go away before
          // transitioning back to the 'none' state.
          if ((objReportFlag & ~pf->exceptions) == 0)
          {
            pf->state = palmFilterState_none;
          }
        }
        break;
      }

      if (pf->allowStylus)
      {
        objectBitmask_t stylusMask = classMaskToObjMask(objClass, (1 << hostClassification_stylus) | (1 << hostClassification_eraser));
        pf->exceptions |= stylusMask;
      }

      if (pf->state == palmFilterState_reject)
      {
        uint16 i;
        objectBitmask_t objBitmask;
        hostClassification_t *curObjClass = objClass;
        for (i = 0, objBitmask = 1, curObjClass = objClass;
             i < MAX_OBJECTS;
             i++, objBitmask <<= 1, curObjClass++)
        {
          if ((pf->exceptions & objBitmask) == 0)
          {
            *curObjClass = hostClassification_none;
            objReportFlag &= ~objBitmask;
          }
        }
      }
    }
    #if CONFIG_IFP_SUPPRESS_METAL_HISTO
      posReportFilter = (posReportFilter << 1) | ((((pf->state == palmFilterState_reject) && (pf->exceptions == 0)) || metal_detection_getState()) ? 0x1 : 0x0);
    #endif
  }

  // ---skin mode filter ---
  {
    struct skinModeFilterInfo *sf = &skinModeFilter;

    if ((sf->type == skinModeFilterType_rejectAllTouches) ||
        (sf->type == skinModeFilterType_rejectNewTouches))
    {
      uint16 fingerFound = classMaskToObjMask(objClass, 1 << hostClassification_finger) != 0;
      objectBitmask_t suppressMask = classMaskToObjMask(objClass, skinModeSuppressObjectTypes);

      switch(sf->state)
      {
      case skinModeFilterState_none:
        if (fingerFound != 0)
        {
          if (sf->type == skinModeFilterType_rejectNewTouches)
          {
            sf->rejections = (suppressMask) & ~(sf->exceptions);
          }
          else
          {
            sf->rejections = suppressMask;
          }
          sf->exceptions = objReportFlag & ~(sf->rejections);
          sf->state = skinModeFilterState_reject;
        }
        else
        {
          sf->rejections = 0;
          if (sf->type == skinModeFilterType_rejectNewTouches)
          {
            sf->exceptions = objReportFlag;
          }
          else
          {
            sf->exceptions = 0;
          }
        }
        break;
      case skinModeFilterState_reject:
        if (fingerFound == 0)
        {
          sf->rejections = suppressMask & sf->rejections;
          if (sf->rejections == 0)
          {
            sf->state = skinModeFilterState_none;
          }
        }
        else
        {
          if (sf->type == skinModeFilterType_rejectNewTouches)
            sf->rejections = suppressMask & ~(sf->exceptions);
          else
            sf->rejections = suppressMask;
        }
        sf->exceptions = objReportFlag & ~(sf->rejections);
        break;
      }

      if (sf->state == skinModeFilterState_reject)
      {
        uint16 i;
        objectBitmask_t objBitmask;
        hostClassification_t *curObjClass = objClass;
        for (i = 0, objBitmask = 1, curObjClass = objClass;
             i < MAX_OBJECTS;
             i++, objBitmask <<= 1, curObjClass++)
        {
          if ((sf->exceptions & objBitmask) == 0)
          {
            *curObjClass = hostClassification_none;
            objReportFlag &= ~objBitmask;
          }
        }
      }

    }
  }

  // --- freeze exceptions that are now palms ---
  {
    xy_t *exceptionsPosPtr;
    hostPosition_t *hostPosPtr;
    uint16 i;
    objectBitmask_t objBitmask;
    objectBitmask_t exceptionsNowPalmsMask = palmMask & palmFilter.exceptions;

    exceptionsPosPtr = exceptionsPositions;
    hostPosPtr = hostPositions;

    for (i = 0, objBitmask = 1;
         i < MAX_OBJECTS;
         i++, objBitmask <<= 1, exceptionsPosPtr++, hostPosPtr++)
    {
      if (exceptionsNowPalmsMask & objBitmask)
      {
        // report last non-palm position and classification
        hostPosPtr->xPosition = exceptionsPosPtr->x;
        hostPosPtr->yPosition = exceptionsPosPtr->y;
        objClass[i] = exceptionsClasses[i];
      }
      else if (palmFilter.exceptions & objBitmask)
      {
        // update exceptions non-palm position and classification
        exceptionsPosPtr->x = hostPosPtr->xPosition;
        exceptionsPosPtr->y = hostPosPtr->yPosition;
        exceptionsClasses[i] = objClass[i];
      }
    }
  }


  // --- reduced reporting mode ---
  {
    xy_t *lastPosPtr;
    hostPosition_t *hostPosPtr;
    uint16 i;
    objectBitmask_t objBitmask;

    lastPosPtr = lastReportedPosition;
    hostPosPtr = hostPositions;

    freshData = 0;

    for (i = 0, objBitmask = 1;
         i < MAX_OBJECTS;
         i++, objBitmask <<= 1, lastPosPtr++, hostPosPtr++)
    {
      int lastX, lastY;
      int hostX, hostY;

      lastX = lastPosPtr->x;
      lastY = lastPosPtr->y;
      hostX = hostPosPtr->xPosition;
      hostY = hostPosPtr->yPosition;

      if ((objReportFlag & objBitmask) == 0)
      {
        lastX = -1;
        lastY = -1;
      }
      else
      {
        if (lastPosPtr->x == -1)
        {
          freshData |= objBitmask;
          lastX = hostX;
          lastY = hostY;
        }
        else
        {
          int16 xDist;
          int16 yDist;

          xDist = lastX - hostX;
          if (xDist < 0)
          {
            xDist = -xDist;
          }
          yDist = lastY - hostY;
          if (yDist < 0)
          {
            yDist = -yDist;
          }
          if ((deadZoneSizeX < 255 || deadZoneSizeY < 255) &&
              (xDist >= deadZoneSizeX || yDist >= deadZoneSizeY))
          {
            freshData |= objBitmask;
            lastX = hostX;
            lastY = hostY;
          }
          //Takashi: Fixed reduced reporting so that changing touch type updates finger position report.
          // Finger may be recognized as stylus/eraser when it is landing slowly, and easer may also be detected as stylus.
          // This flag is added to check whether detection is changed,
          // we have to report the new touchType to the host in time even though the object is not moved
          if(lastPosPtr->c != objClass[i])
          {
            freshData |= objBitmask;
          }
        }
      }
      lastPosPtr->x = lastX;
      lastPosPtr->y = lastY;
      lastPosPtr->c = objClass[i];
    }
  }

  // --- remap new reported objects ---
  maxReportedObjectsCurr = useMaxReportedObjectsAlt ? maxReportedObjectsAlt : maxReportedObjects;
  {
    int16 *riPtr;
  #if CONFIG_EDGE_SUPPRESSION
    int16 *etPtr;
  #endif
    objectBitmask_t usedMask = 0;
    objectBitmask_t outMask;
    objectBitmask_t maxReportedObjectsMask = powerOfTwo(maxReportedObjectsCurr) - 1;
    uint16 i;
    objectBitmask_t objBitmask;
    classification_t *curInClass = classifications;

    riPtr = reportedIndices;
  #if CONFIG_EDGE_SUPPRESSION
    etPtr = existedTouch;
  #endif

    for (i = 0, objBitmask = 1; i < MAX_OBJECTS; i++, objBitmask <<=1, riPtr++, curInClass++)
    {
      if (objBitmask & objReportFlag)
      {
        if ((*riPtr != -1) && curInClass->newTouchFlag)
        {
          // if new touch, force use of new report index
          liftedIndices |= powerOfTwo((uint16) *riPtr);
          *riPtr = -1;
        }
        if (*riPtr == -1)
        {
          // if we run out of reportable indices, free up lifted indices,
          // even if they haven't been seen by the host yet.
          if ((freeReportedIndices & maxReportedObjectsMask) == 0)
          {
            freeReportedIndices |= liftedIndices;
            liftedIndices = 0;
          }
          if (freeReportedIndices != 0)
          {
            int16 reportIdx;
            reportIdx = findLowestSetBit(freeReportedIndices);
            outMask = powerOfTwo((uint16) reportIdx);
            *riPtr = reportIdx;
          #if CONFIG_EDGE_SUPPRESSION
            *etPtr = reportIdx;
          #endif
            usedMask |= outMask;
            freeReportedIndices &= ~outMask;
          }
        }
      }
    #if CONFIG_EDGE_SUPPRESSION
      etPtr++;
    #endif
    }
  }

  // --- free up any newly-unused indices for departed reported objects ---

  {
    uint16 i;
    objectBitmask_t objBitmask;
    newLiftedIndices = 0;

    for (i = 0, objBitmask = 1; i < MAX_OBJECTS; i++, objBitmask <<= 1)
    {
      if (reportedIndices[i] != -1)
      {
        if (objClass[i] == hostClassification_none)
        {
          newLiftedIndices |= powerOfTwo((uint16) reportedIndices[i]);
          reportedIndices[i] = -1;
        #if CONFIG_EDGE_SUPPRESSION
          existedTouch[i] = -1;
        #endif
          freshData |= objBitmask;
        }
      }
    }
  }

  // -- free indices from lifts on prior frames --

  if (!holdLiftedIndices)
  {
    freeReportedIndices |= liftedIndices;
    liftedIndices = (objectBitmask_t) 0;
  }
  liftedIndices |= newLiftedIndices;

  // -- build the report structure and set the freshData flag --

  // first clear the report structure, which is easiest to do
  // unconditionally here because of the random index remapping that
  // occurs below
  memset16(report, 0, sizeof(*report) / sizeof(uint16));

  // now fill out the mapped objects
  {
    uint16 i;
    objectBitmask_t objBitmask;
    for (i = 0, objBitmask = 1; i < MAX_OBJECTS; i++, objBitmask <<= 1)
    {
      int16 reportIdx;
    #if CONFIG_EDGE_SUPPRESSION
      int16 existedTouchIdx;
    #endif

      reportIdx = reportedIndices[i];
    #if CONFIG_EDGE_SUPPRESSION
      existedTouchIdx = existedTouch[i];
    #endif

      if (reportIdx < (int16) maxReportedObjectsCurr)
      {
        if (freshData & objBitmask)
        {
          report->freshData = TRUE;
        }
        if (reportIdx != -1)
        {
          reportPos_t *rep = &report->pos[reportIdx];
          hostPosition_t *hostPos = &hostPositions[i];
          rep->classification = objClass[i];

          if(origin == 0x08) //top left ,
          {
            rep->xMeas = xMax - hostPos->xPosition;
            rep->yMeas = yMax - hostPos->yPosition;
          }
          else if(origin == 0x04) //top right
          {
            rep->xMeas = hostPos->xPosition;
            rep->yMeas = yMax - hostPos->yPosition;
          }
          else if(origin == 0x02) // bottom left
          {
            rep->xMeas = xMax - hostPos->xPosition;
            rep->yMeas = hostPos->yPosition;
          }
          else if(origin == 0x01)// bottom right
          {
            rep->xMeas = hostPos->xPosition;
            rep->yMeas = hostPos->yPosition;
          }
          else
          {
            rep->xMeas = xMax - hostPos->xPosition;
            rep->yMeas = yMax - hostPos->yPosition;
          }
          rep->xWidth = hostPos->xWidth;
          rep->yWidth = hostPos->yWidth;
          rep->txPos = sensorPositions[i].yPosition;
          rep->rxPos = sensorPositions[i].xPosition;
          rep->z = hostPos->z;

        #if CONFIG_IFP_KNUCKLE
        rep->trackId = i;
        #endif

        #if CONFIG_EDGE_SUPPRESSION
          if (existedTouchIdx != -1)   //- still on edge
          {
            if ((rep->xMeas < edgeSuppressionDist) || (rep->xMeas > (xMax-edgeSuppressionDist)))
            {
              rep->xMeas = 0;
              rep->yMeas = 0;
              rep->xWidth = 0;
              rep->yWidth = 0;
              rep->txPos = 0;
              rep->rxPos = 0;
              rep->z = 0;
              rep->classification = hostClassification_none;
            }
            else
            {
              existedTouch[i] = -1;
            }
          }
        #endif

        #if CONFIG_GRIPSUPPRESSION_RULE2
          Touch_SensorInfor_Report[reportIdx].Tx_width = Touch_SensorInfor[i].Tx_width;
          Touch_SensorInfor_Report[reportIdx].Tx_max = Touch_SensorInfor[i].Tx_max;
          Touch_SensorInfor_Report[reportIdx].Tx_min = Touch_SensorInfor[i].Tx_min;
          Touch_SensorInfor_Report[reportIdx].Tx_peak = Touch_SensorInfor[i].Tx_peak;
          Touch_SensorInfor_Report[reportIdx].Tx_Ratio = Touch_SensorInfor[i].Tx_Ratio;
          Touch_SensorInfor_Report[reportIdx].Rx_width = Touch_SensorInfor[i].Rx_width;
          Touch_SensorInfor_Report[reportIdx].Rx_peak = Touch_SensorInfor[i].Rx_peak;
          Touch_SensorInfor_Report[reportIdx].Rx_Ratio = Touch_SensorInfor[i].Rx_Ratio;
          Touch_SensorInfor_Report[reportIdx].Rx_max = Touch_SensorInfor[i].Rx_max;
          Touch_SensorInfor_Report[reportIdx].Rx_min = Touch_SensorInfor[i].Rx_min;
        #endif

        }
      }
      else
      {
        // already filled with zeros at the beginning of the function
      }

      report->objectsPresent = objectsPresentFlag;

      if (forceFreshReport == TRUE)
      {
        report->freshData = TRUE;
      }
    }
#if CONFIG_IFP_SUPPRESS_METAL_HISTO
    if(posReportFilter)
    {
      for(i = 0; i < MAX_OBJECTS; i++)
      {
        reportPos_t *fingerIndex = &report->pos[i];
        if (fingerIndex->classification != hostClassification_none && fingerIndex->z > 0)
        {
          {
            fingerIndex->classification = hostClassification_none;
            fingerIndex->z = 0;
          }
        }
      }
    }
#endif
  }

  // set prior state
  if (touchFlagPresent > 0)
  {
    for (i = 0; i < MAX_OBJECTS; i++)
    {
      if (report->pos[i].classification != hostClassification_none)
      {
        if (thickGlovePresent == 0)
        {
          switch (report->pos[i].classification)
          {
          case hostClassification_finger:
            priorState[i].touchType = touchType_finger;
            break;
          case hostClassification_glove:
            priorState[i].touchType = touchType_glove;
            break;
          case hostClassification_smallObject:
            priorState[i].touchType = touchType_smallObject;
            break;
          default:
            priorState[i].touchType = touchType_none;
            break;
          }
        }
        else
        {
          priorState[i].touchType = touchType_thickGlove;
        }
        priorState[i].xPos = report->pos[i].rxPos;
        priorState[i].yPos = report->pos[i].txPos;
      }
      else
      {
        priorState[i].touchType = touchType_none;
        priorState[i].xPos = -1*ONE_8p8;
        priorState[i].yPos = -1*ONE_8p8;
      }
    }
    // reset frame count
    frameCnt = 0;
  }
  else
  {
    // update frame count used to clear prior state
    if (frameCnt < THICK_GLOVE_FRAME_COUNT)
    {
      frameCnt++;
      if (frameCnt == THICK_GLOVE_FRAME_COUNT)
      {
        clearStates();
      }
    }
  }
  // handle closedCover mode for small window.
#if CONFIG_IFP_CLOSEDCOVER
  if( getClosedCoverStatus() &&
     (coverParamsPositionRep.closedCoverXmin || coverParamsPositionRep.closedCoverXmax ||
     coverParamsPositionRep.closedCoverYmin || coverParamsPositionRep.closedCoverYmax ))
  {
     uint16 i;
     reportPos_t *fingerIndex = &report->pos[0];
     for(i=0; i< MAX_OBJECTS;++i)
     {
       if (fingerIndex->classification != hostClassification_none)
       {
         if (!(isInClosedCoverSmallWindowZone(fingerIndex->xMeas , fingerIndex->yMeas)))
         {
            fingerIndex->classification = hostClassification_none;
         }
       }
       fingerIndex++;
     }
  }
#endif

#if CONFIG_HAS_REPORTS_GONE_BY_FORCE_UPDATE
  if ((hadObjectsBeforeForceUpdate & 3) == 3)
  {
    report->freshData = TRUE;
  }
  hadObjectsBeforeForceUpdate = report->objectsPresent;
#endif
}
