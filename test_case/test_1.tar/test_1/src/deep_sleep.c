#include "calc2.h"
#include "platform.h"
#include "deep_sleep.h"

#define LEN(x) (sizeof(x)/sizeof(x[0]))


uint16 deepSleep_sleep()
{
  PLFrame_t *f;
  commCommandType_t cmds[] = {CMD_EXIT, CMD_ENTER_DEEP_SLEEP, CMD_EXIT_DEEP_SLEEP, CMD_CHANGE_SENSING_MODE};
  commCommand_t cmd;
  uint16 force_rezero = 0;

  COMM_setDeepSleep(1);

  PL_enterMode(mode_deepSleep);
  f=PL_getFrame(frame_deepsleep);
  PL_releaseFrame(f);

  while(1)
  {
    cmd = COMM_waitForCommand(cmds, LEN(cmds));
    if (cmd.cmd == CMD_ENTER_DEEP_SLEEP || cmd.cmd == CMD_EXIT_DEEP_SLEEP || cmd.cmd == CMD_CHANGE_SENSING_MODE)
    {
      COMM_ackCommand(cmd);
      if (cmd.cmd == CMD_CHANGE_SENSING_MODE)
      {
        calcDynamicConfig_t dcfg;
        COMM_getDynamicConfig(&dcfg);
        PL_setParam(PLTouchSensingMode,dcfg.touchSensingMode);
        force_rezero = 1;
      }
    }
    if (cmd.cmd == CMD_EXIT || cmd.cmd == CMD_EXIT_DEEP_SLEEP)
    {
      break;
    }
  }
  PL_enterMode(mode_idle);
  COMM_setDeepSleep(0);

  return force_rezero;
}
