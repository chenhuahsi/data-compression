// -----------------------------------------------------------------
// Grip Suppression
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//

#ifndef GRIP_SUPPRESSION_H_
#define GRIP_SUPPRESSION_H_

#include "calc2.h"
#define NULL_PTR ((void *)0)

#if CONFIG_GRIPSUPPRESSION
void gripSuppression_apply(reportData_t *reportDataPtr);
void gripSuppression_init(calcStaticConfig_t *cfg);
void gripSuppression_enabled(uint16 enable);
#else
ATTR_INLINE void gripSuppression_apply(ATTR_UNUSED touchReport_t *reportDataPtr){};
ATTR_INLINE void gripSuppression_init(ATTR_UNUSED calcStaticConfig_t *cfg){};
ATTR_INLINE void gripSuppression_enabled(ATTR_UNUSED uint16 enable){};
#endif

#if CONFIG_GRIPSUPPRESSION_RULE2
void GripInit();
void GripConfig(ifpConfig_t *ifpConfig);
void applyGripSuppressionRule2(reportData_t *reportData);

typedef struct
{
  uint16 Tx_max;
  uint16 Tx_min;
  uint16 Tx_peak;
  uint16 Tx_Ratio;
  uint16 Tx_width;
  uint16 Rx_max;
  uint16 Rx_min;
  uint16 Rx_width;
  uint16 Rx_peak;
  uint16 Rx_Ratio;
}Pos_SensorInfo;

extern Pos_SensorInfo Touch_SensorInfor[MAX_OBJECTS];
extern Pos_SensorInfo Touch_SensorInfor_Report[MAX_OBJECTS];
#endif

#endif /* GRIP_SUPPRESSION_H_ */
