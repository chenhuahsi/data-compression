/* -----------------------------------------------------------------
 * Gesture Detector - Scans touch position data for gestures
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 *
 */

#include <math.h>
#include <string.h>
#include "calc_print.h"
#include "gesture_detector.h"
#include "user_defined_gesture.h"

#if CONFIG_HAS_WAKEUPGESTURE

#if CONFIG_HAS_LPWG_MULTITAP
  uint16 multitap_report_rate;
  GestureData gesture;
  fingerPosInfo_t fdPtr[MAX_NUM_FINGER_FOR_GESTURE];

  #if CONFIG_LPWG_MULTITAP_REJECTZONE
    uint16 dbg_OverTapCnt;
    uint16 dbg_OverTap_Fail;
    uint16 FingerInBuffer;
  #endif

  #if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
    doTapInfo_t doTapInfo;
    doTapInfo_t doMultiTapInfo;
  #endif

  #if CONFIG_LPWG_MULTITAP_MAXNUM
    int16 multipletapsXpos[CONFIG_LPWG_MULTITAP_MAXNUM];
    int16 multipletapsYpos[CONFIG_LPWG_MULTITAP_MAXNUM];
  #endif
  #if CONFIG_HAS_LPWG_DUALMULTITAP
    GestureData gesture2;
    int16 multipletapsXpos2[CONFIG_LPWG_MULTITAP_MAXNUM];
    int16 multipletapsYpos2[CONFIG_LPWG_MULTITAP_MAXNUM];
    #if CONFIG_LPWG_DUALMULTITAP_MININTERTAP_ENABLE
      uint16 gmultitap_intertap_under_min2;
    #endif
    #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
      uint16 gmultitap_interruptdelay2_pending;
      uint16 gmultitap_interruptdelay2_tapcnt;
      uint16 gmultitap_interruptdelay2_fingerpress;
    #endif
    #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
      uint16 gmultitap_sync_pending_vote1;
      uint16 gmultitap_sync_pending_vote2;
    #endif
  #endif

  #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
    uint16 gmultitap1_failedcount;
    uint16 gmultitap1_failreason_distance_intertap;
    uint16 gmultitap1_failreason_distance_pressrel;
    uint16 gmultitap1_failreason_timeout_intertap;
    uint16 gmultitap1_failreason_multifinger;
    uint16 gmultitap1_failreason_delaytime;

    #if CONFIG_LPWG_MULTITAP_FAIL_PALM
      uint16 gmultitap1_failreason_palm_state;
      uint16 gmultitap1_failreason_parm_state_ispressing;
    #endif
    #if CONFIG_LPWG_MULTITAP_ACTIVEAREA_ENABLE
      uint16 gmultitap1_failreason_active_area;
      uint16 gmultitap1_failreason_active_area_ispressing;
    #endif
    #if CONFIG_LPWG_MULTITAP_FAIL_TAP
      uint16 gmultitap1_failreason_tap_count;
    #endif
    uint16 gmultitap1_failreason_multifinger_ispressing;
  #endif

  #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
    uint16 gmultitap2_failedcount;
    uint16 gmultitap2_failreason_distance_intertap;
    uint16 gmultitap2_failreason_distance_pressrel;
    uint16 gmultitap2_failreason_timeout_intertap;
    uint16 gmultitap2_failreason_multifinger;
    uint16 gmultitap2_failreason_delaytime;
    #if CONFIG_LPWG_MULTITAP_FAIL_PALM
      uint16 gmultitap2_failreason_palm_state;
      uint16 gmultitap2_failreason_parm_state_ispressing;
    #endif
    #if CONFIG_LPWG_MULTITAP_ACTIVEAREA_ENABLE
      uint16 gmultitap2_failreason_active_area;
      uint16 gmultitap2_failreason_active_area_ispressing;
    #endif
    #if CONFIG_LPWG_MULTITAP_FAIL_TAP
      uint16 gmultitap2_failreason_tap_count;
    #endif
    uint16 gmultitap2_failreason_multifinger_ispressing;
    #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
      uint16 gmultitap2_failreason_realtime_interrrupt;
    #endif
  #endif

  #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
    uint16 gmultitap_failreason_realtime_interrrupt;
    uint16 gmultitap1_failreason_realtime_interrrupt;
  #endif

  #if CONFIG_LPWG_MULTITAP_INTRRDELAY
    uint16 gmultitap_interruptdelay1_pending;
    uint16 gmultitap_interruptdelay1_tapcnt;
    uint16 gmultitap_interruptdelay1_fingerpress;
  #endif

  #if CONFIG_LPWG_MULTITAP_FAIL_PALM
    static void doGesturesProc(uint16 numFingers, hostClassification_t classification);
  #else
    static void doGesturesProc(uint16 numFingers);
  #endif

  static void doTap(uint16 xPos, uint16 yPos, uint16 currFinger);
  static uint16 checkTapTimeExpire(void);
  static uint16 checkTapDistance(uint16 xPos, uint16 yPos);
  static uint16 checkInterTapDistance(uint16 xPos, uint16 yPos);
  static void clearGestureTapStatus(void);
  static void processLPWG(uint16 xPos, uint16 yPos, uint16 currFinger);

  static uint16 isClose(int16 xd, int16 yd, uint16 xMax, uint16 yMax);

  #if CONFIG_LPWG_MULTITAP_MININTERTAP_ENABLE
    static uint16 checkTapMinTimeExpire(void);
  #endif

  #if CONFIG_LPWG_MULTITAP_INTRRDELAY
    static uint16 checkInterruptDelayTimeExpire(void);
    static void clearGestureTapInterruptDelayStatus(void);
  #endif

  #if CONFIG_HAS_LPWG_DUALMULTITAP
    static void doTap_DualMultiTap(uint16 xPos, uint16 yPos, uint16 currFinger);
    static uint16 checkTapTimeExpire_DualMultiTap(void);
    static uint16 checkTapDistance_DualMultiTap(uint16 xPos, uint16 yPos);
    static uint16 checkInterTapDistance_DualMultiTap(uint16 xPos, uint16 yPos);
    static void clearGestureTapStatus_DualMultiTap(void);
    static void processLPWG_DualMultiTap(uint16 xPos, uint16 yPos, uint16 currFinger);

    #if CONFIG_LPWG_DUALMULTITAP_MININTERTAP_ENABLE
      static uint16 checkTapMinTimeExpire_DualMultiTap(void);
    #endif
    #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
      static uint16 checkInterruptDelayTimeExpire_DualMultiTap(void);
      static void clearGestureTapInterruptDelayStatus_DualMultiTap(void);
    #endif
    #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
      static void clearGestureTapSyncStatus(void);
      static void checkGestureTapSyncStatus_DualMultiTap(void);
      static void checkGestureTapSyncStatus(void);
    #endif
  #endif //CONFIG_HAS_LPWG_DUALMULTITAP

  #if (defined(cfg_StartupFastRelaxation) && cfg_StartupFastRelaxation)
    #define PROCESS_GESTURE_FOR_SFR   globalFlags.gestureExitsSFR
  #else
    #define PROCESS_GESTURE_FOR_SFR   0
  #endif

  #define DOUBLE_TAP_DETECTED (gesture.tap == DOUBLE_TAP)

  static void resetDetectedLPWG (void) {
    #if !CONFIG_HAS_LPWG_DUALMULTITAP
      gesture.tap = 0;
    #endif
  }
#endif

//============== multitap ================

#define atan_pi (int16) (3.14159f*256)
#define true 1
#define false 0

#define UP_VEE_ENABLE                 0x01
#define DOWN_VEE_ENABLE               0x02
#define LEFT_VEE_ENABLE               0x04
#define RIGHT_VEE_ENABLE              0x08

#define UP_VEE_DETECTED               0x01
#define DOWN_VEE_DETECTED             0x02
#define LEFT_VEE_DETECTED             0x04
#define RIGHT_VEE_DETECTED            0x08

// These constants are the ascii values of the letters
#define LPWG_UNICODE_c      0x0063
#define LPWG_UNICODE_e      0x0065
#define LPWG_UNICODE_m      0x006d
#define LPWG_UNICODE_s      0x0073
#define LPWG_UNICODE_w      0x0077
#define LPWG_UNICODE_z      0x007a

#define UNICODE_LOOKSLIKE_m 0x01
#define UNICODE_LOOKSLIKE_w 0x02

#define LEN(x) (sizeof(x)/sizeof(x[0]))
#define abs16(x) (((x) < 0) ? -(x) : (x))
#define swap(x, y) {(x)^=(y); (y)^=(x); (x)^=(y);}

typedef enum {
  LPWG_STATE_INIT = 0,
  LPWG_STATE_START_TRACKING,
  LPWG_STATE_STOP_TRACKING,
} LPWGStates_t;

typedef enum {
  DT_INIT = 0,
  DT_FIRST_TAP = 1,
  DT_WAIT_FOR_SECOND = 2,
  DT_WAIT_FOR_LIFT = 3,
} doubleTapState_t;

typedef enum {
  STATE_RESTART_SWIPE_DETECTION = 0,
  STATE_CAPTURE_DIRECTION,
  STATE_CONTINUE_DETECTION,
} swipeState_t;

typedef enum {
  DIRECTION_POS,
  DIRECTION_NEG,
} polarity_t;

typedef enum {
  LPWG_SWIPE_POS_X = 1,
  LPWG_SWIPE_NEG_X = 2,
  LPWG_SWIPE_POS_Y = 4,
  LPWG_SWIPE_NEG_Y = 8,
} swipePolarity_t;

typedef enum {
  DIRECTION_UNKNOWN = 0,
  DIRECTION_UP,
  DIRECTION_UP_RIGHT,
  DIRECTION_RIGHT,
  DIRECTION_DOWN_RIGHT,
  DIRECTION_DOWN,
  DIRECTION_DOWN_LEFT,
  DIRECTION_LEFT,
  DIRECTION_UP_LEFT,
} vectorDirections_t;

typedef enum {
  ORIGIN_LOWER_LEFT = 0,
  ORIGIN_LOWER_RIGHT,
  ORIGIN_UPPER_RIGHT,
  ORIGIN_UPPER_LEFT,
}sensorOrigin_t;

/* Persistent vars */
static struct {
  uint16 txPitch_mm; // 4.12
  uint16 rxPitch_mm; // 4.12
  lpwgParams_t cfg;
  uint16 lpwgFramePeriod;
} params;

typedef struct {
  uint16 circularMotion;
  uint16 prevCircleDir;
  uint16 circleClkWiseNum;
  uint16 circleCntClkWiseNum;
  uint16 circleTurnOppositeNum;
  uint16 sumLastWiseClkDist;
}circleDir_s;

typedef struct {
  swipeState_t State;
  uint16 swipeSumSideDist;
  uint16 swipeSideHasCurve;
  uint16 SwipeEpoch;
  uint16 xSwipeStart;
  uint16 ySwipeStart;
  uint16 xFlickNeg                : 1; // Flick: 1 = Finger's moving in the negative X direction.
  uint16 yFlickNeg                : 1; // Flick: 1 = Finger's moving in the negative Y direction.
  uint16 firstSwipeDetected       : 1; // Used for swipe with lift, not for swipe without lift
} swipeCtrl_s;

typedef struct {
  LPWGStates_t State;
  uint16 minSpeedPerFrame;
  uint16 xPos[1];
  uint16 yPos[1];
  uint16 sumTotalDist;
  uint16 reportMinSpeedPerFrameMm;
  uint16 mightBe;
  uint16 distStartToPrevPos;
  uint16 xLastSeenNmm;
  uint16 yLastSeenNmm;
  circleDir_s dirCtrl;
} circleCtrl_s;

typedef struct {
  LPWGStates_t State;
  uint16 sideHasCurve;
  uint16 maxSpeedPerFrame;
  uint16 reportMinSpeedPerFrameMm;
  uint16 mightBe;
  uint16 sumSideDist;
  uint16 sumTotalDist;
  uint16 xPos[4];
  uint16 yPos[4];
  uint16 triangleNotAlongAxis;
  uint16 triangleStartToEnd;
  uint16 minSpeedPerFrame;
  uint16 xTrianglePrevDir;
  uint16 yTrianglePrevDir;
} triangleCtrl_s;

typedef struct {
  LPWGStates_t State;
  uint16 sideHasCurve;
  uint16 validVeeDepth;
  uint16 maxSpeedPerFrame;
  uint16 mightBe;
  uint16 sumTotalDist;
  uint16 xPos[3];
  uint16 yPos[3];
  uint16 veeNotAlongAxis;
  uint16 minSpeedPerFrame;
  uint16 xVeePrevDir;
  uint16 yVeePrevDir;
  uint16 reportMinSpeedPerFrameMm;
  uint16 lastTimeStamp;
} veeCtrl_s;

typedef struct {
  LPWGStates_t State;
  uint16 xPos[4];
  uint16 yPos[4];
  uint16 sumSideDist;
  uint16 sumTotalDist;
  uint16 reportMinSpeedPerFrameMm;
  uint16 sideHasCurve;
  uint16 distStartToPrevPos;
  uint16 xLastSeenNmm;
  uint16 yLastSeenNmm;
  uint16 maxSpeedPerFrame;
  circleDir_s dirCtrl;
  uint16 LastDistancePosx;
  uint16 LastDistancePosy;
  uint16 LastDistanceDir;
  uint16 lpwgSstartCapLeftDir;
  uint16 ContactPoint[8];
  uint16 circleBasedGestureDirFlag;
  uint16 unicodeXPrevPosBfr1Mm;
  uint16 unicodeYPrevPosBfr1Mm;
  uint16 prevVectorDir;
  uint16 mightBe_m;
  uint16 mightBe_w;
  uint16 unicode_mORw;
  uint16 mORwFalseTriggerCounter;
  uint16 mightBe_c;
  uint16 mightBe_e;
  uint16 mightBe_z;
  uint16 mightBe;
  uint16 lpwgSstartCapLeftDirX;
  uint16 lpwgSstartCapLeftDirY;
  uint16 theBottomYBeforeTurnLeft;
} unicodeCtrl_s;

static struct {
  // control params for all gestures.
  uint32 lastTimeStamp;
  uint16 enabled : 1;
  uint16 lastTimeStampValid : 1;
  uint16 falseActivations;
  uint32 activeDuration;
  int16 primaryIdx;
  struct touch lastSeenPrimaryPos;
  uint16 prevTouchFlag;
  uint16 touchReportRate;
  doubleTapState_t dtState ATTR_UNUSED;
  int16 dtFirstTapTx ATTR_UNUSED;  // 12.4, mm
  int16 dtFirstTapRx ATTR_UNUSED;  // 12.4, mm
  uint32 dtFirstTapTime ATTR_UNUSED;
  swipeCtrl_s swipeCtrl ATTR_UNUSED;
  circleCtrl_s circleCtrl ATTR_UNUSED;
  triangleCtrl_s triangleCtrl ATTR_UNUSED;
  veeCtrl_s veeCtrl ATTR_UNUSED;
  unicodeCtrl_s unicodeCtrl ATTR_UNUSED;
} state;

static uint16 estimateMagnitude(int16 x, int16 y);

//============== multitap ================
#if CONFIG_HAS_LPWG_MULTITAP

static uint16 isClose(int16 xd, int16 yd, uint16 xMax, uint16 yMax)
{
  if(CONFIG_LPWG_MULTITAP_XYDISTANCE)
  {
    return ((uint16)(abs16(xd)) <= xMax) && ((uint16)(abs16(yd)) <= yMax);
  }
  else
  {
    return (estimateMagnitude(xd, yd) <= xMax);
  }
}


#if CONFIG_LPWG_MULTITAP_FAIL_PALM
void doGesturesProc(uint16 numFingers, hostClassification_t classification)
#else
void doGesturesProc(uint16 numFingers)
#endif
{
  uint16 currIndex = 0;

  gesture.tap = NO_TAP;
  #if CONFIG_HAS_LPWG_DUALMULTITAP
    gesture2.tap = NO_TAP;
  #endif

  #if (defined(WAKEUP_GESTURE_TIMEOUT)&&WAKEUP_GESTURE_TIMEOUT)
    LPWG_TimeoutMax = LPWG_TIMEOUT_MAX*TIMEOUT_FACTOR;
  #endif

  if (gesture.numFingerPrev == 0)
  {
    // Save the starting point index
    gesture.prevIndex = currIndex;
  }

  if (currIndex != gesture.prevIndex)
  {
    // Start over if the finger at index which was being considered has lifted and new finger has landed at different index
    // It could possibly be a drumming finger
    #if (defined(WAKEUP_GESTURE_TIMEOUT)&&WAKEUP_GESTURE_TIMEOUT)
      LPWG_Timer = 0;
    #endif
  }

  gesture.prevIndex = currIndex;

  #if (defined(WAKEUP_GESTURE_TIMEOUT)&&WAKEUP_GESTURE_TIMEOUT)
    if(LPWG_Timer>= LPWG_TimeoutMax)
    {
      LPWG_Timer = 0;
      resetDetectedLPWG();
    }
  #endif

  #if CONFIG_LPWG_MULTITAP_FAIL_PALM
  if (numFingers < 2 && classification != hostClassification_palm)
  #else
  if (numFingers < 2)
  #endif
  {
    uint16 xPos = 0;
    uint16 yPos = 0;
    uint16 currFinger = (numFingers == 1) ? 1 : 0;

    if (currFinger)
    {
      xPos = fdPtr[0].xPosition;
      yPos = fdPtr[0].yPosition;
      #if (defined(WAKEUP_GESTURE_TIMEOUT)&&WAKEUP_GESTURE_TIMEOUT)
        LPWG_Timer ++;
      #endif
    }
    else
    {
      xPos = gesture.xLastSeen;
      yPos = gesture.yLastSeen;
      #if (defined(WAKEUP_GESTURE_TIMEOUT)&&WAKEUP_GESTURE_TIMEOUT)
        LPWG_Timer = 0;
      #endif
    }

    processLPWG(xPos, yPos, currFinger);
    #if CONFIG_HAS_LPWG_DUALMULTITAP
      processLPWG_DualMultiTap(xPos, yPos, currFinger);
    #endif

    if (currFinger)
    {
      /*
       * Shared variable: Tap and Flick;
       * LPWG swipe also uses it
       */
      gesture.xLastSeen = xPos;
      gesture.yLastSeen = yPos;

      if (gesture.numFingerPrev == 0)
      {
        gesture.xStartPos = xPos;
        gesture.yStartPos = yPos;
        #if CONFIG_HAS_LPWG_DUALMULTITAP
          gesture2.xStartPos = xPos;
          gesture2.yStartPos = yPos;
        #endif
      }
    }
  }
  else
  {
    // cancel pending gestures "Tap", "Press" and "Flick".
    #if CONFIG_LPWG_MULTITAP_FAIL_PALM
    if (gesture.useWakeupGestureParameters && classification == hostClassification_palm)
    {
      if(!gmultitap1_failreason_parm_state_ispressing)
      {
        gmultitap1_failreason_parm_state_ispressing = 1;
        gmultitap1_failedcount++;
        gmultitap1_failreason_palm_state++;
        COMM_updateMultiTapFailReason1Buffer(gmultitap1_failedcount, MULTITAP_FAILREASON_PALM_STATE);
        #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
          #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
            if(gmultitap1_failreason_realtime_interrrupt == 0)
              gmultitap1_failreason_realtime_interrrupt = MULTITAP_FAILREASON_PALM_STATE;
          #endif
        #endif
      }
      #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
        if(!gmultitap2_failreason_parm_state_ispressing)
        {
          gmultitap2_failreason_parm_state_ispressing = 1;
          gmultitap2_failedcount++;
          gmultitap2_failreason_palm_state++;
          COMM_updateMultiTapFailReason2Buffer(gmultitap2_failedcount, MULTITAP_FAILREASON_PALM_STATE);
          #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
            #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
              if(gmultitap2_failreason_realtime_interrrupt == 0)
                gmultitap2_failreason_realtime_interrrupt = MULTITAP_FAILREASON_PALM_STATE;
            #endif
          #endif 
          #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
            clearGestureTapInterruptDelayStatus_DualMultiTap();
          #endif
        }
      #endif
    }
    else
    {
    #endif
    #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
      if(gesture.useWakeupGestureParameters)
      {
        if(!gmultitap1_failreason_multifinger_ispressing)
        {
          gmultitap1_failreason_multifinger_ispressing = 1;
          gmultitap1_failedcount++;
          gmultitap1_failreason_multifinger++;
          COMM_updateMultiTapFailReason1Buffer(gmultitap1_failedcount, MULTITAP_FAILREASON_MULTIFINGER);
          #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
            if(gmultitap1_failreason_realtime_interrrupt == 0)
              gmultitap1_failreason_realtime_interrrupt = MULTITAP_FAILREASON_MULTIFINGER;
          #endif
        }
      }
    #endif

    #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
      if(gesture.useWakeupGestureParameters)
      {
        if(!gmultitap2_failreason_multifinger_ispressing)
        {
          gmultitap2_failreason_multifinger_ispressing = 1;
          gmultitap2_failedcount++;
          gmultitap2_failreason_multifinger++;
          COMM_updateMultiTapFailReason2Buffer(gmultitap2_failedcount, MULTITAP_FAILREASON_MULTIFINGER);
          #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
          if(gmultitap2_failreason_realtime_interrrupt == 0)
            gmultitap2_failreason_realtime_interrrupt = MULTITAP_FAILREASON_MULTIFINGER;
          #endif
          #if CONFIG_LPWG_MULTITAP_FAIL_TAP
          if(!dbg_OverTap_Fail)
          {
            dbg_OverTapCnt = 0;
          #endif
            #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
              clearGestureTapInterruptDelayStatus_DualMultiTap();
            #endif
          #if CONFIG_LPWG_MULTITAP_FAIL_TAP
          }
          #endif
        }
      }
    #endif
    #if CONFIG_LPWG_MULTITAP_FAIL_PALM
    }
    #endif

    gesture.trigTap = 0;
    gesture.tapCnt = 0;
    gesture.secondTap = 0;

    #if defined(WAKEUP_GESTURE_TIMEOUT)&&WAKEUP_GESTURE_TIMEOUT
      LPWG_Timer = 0;
    #endif

    clearGestureTapStatus();
    #if CONFIG_HAS_LPWG_DUALMULTITAP
      clearGestureTapStatus_DualMultiTap();
    #endif
  }

  gesture.numFingerPrev = numFingers;

  #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
    if (numFingers == 0)
    {
      gmultitap1_failreason_multifinger_ispressing = 0;
      #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
        gmultitap2_failreason_multifinger_ispressing = 0;
      #endif
      #if CONFIG_LPWG_MULTITAP_FAIL_PALM
        if(classification != hostClassification_palm)
        {
          gmultitap1_failreason_parm_state_ispressing = 0;
          #if CONFIG_HAS_LPWG_DUALMULTITAP
            gmultitap2_failreason_parm_state_ispressing = 0;
          #endif
        }
      #endif
    }
  #endif
}

void processLPWG(uint16 xPos, uint16 yPos, uint16 currFinger)
{
  uint16 gestureType = params.cfg.gestureType;
  uint16 inZone = (xPos >= params.cfg.doubleTapZoneX0 &&
                   xPos <= params.cfg.doubleTapZoneX1 &&
                   yPos >= params.cfg.doubleTapZoneY0 &&
                   yPos <= params.cfg.doubleTapZoneY1);

  gesture.LPWG = 0;
  if(gestureType & LPWG_MULTITAP_ENABLE)
  {
    if(inZone)
    {
      doTap(xPos, yPos, currFinger);
      if(gesture.tap == MULTI_TAP)
      {
        // It makes abs0 attn, don't set it for f51 multitap
        #if !CONFIG_LPWG_MULTITAP_HOSTSYNC
          gesture.LPWG = 1;
        #endif
        #if CONFIG_HAS_LPWG_POWERREDUCTION
          #if CONFIG_LPWG_POWERREDUCTION_FORCEDOZE_ENABLE
            params.cfg.ForceDozeLPWG_byObjectPresent_Trigger=0;
            params.cfg.ForceDozeLPWG_byObjectPresent_DoRepeatForceDoze=0;
          #endif
        #endif
      }
    }
    else
    {
      // Cancel the pending gesture
      gesture.trigTap = 0;
      gesture.secondTap=0;
      gesture.tapCnt=0;
    }
  }

  if(gesture.tap != MULTI_TAP)
  {
    resetDetectedLPWG();
  }
}

#if cfg_DBG_MULTITAP
uint16 dbg_multitap2_success;
uint16 dbg_multitap2_trigtap;
uint16 dbg_multitap2_tapcnt;
uint16 dbg_multitap2_secondtap;
uint16 dbg_multitap2_intdelay_success;
#endif

#if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
void clearDoTapInfo(void)
{
  doTapInfo.first_tap =0;
  doTapInfo.pre_xpos=0;
  doTapInfo.pre_ypos=0;
  doTapInfo.sum_xpos =0;
  doTapInfo.sum_ypos =0;
  doTapInfo.doTap_event  =0;
}

void clearDoMultiTapInfo(void)
{
  doMultiTapInfo.first_tap =0;
  doMultiTapInfo.pre_xpos=0;
  doMultiTapInfo.pre_ypos=0;
  doMultiTapInfo.sum_xpos =0;
  doMultiTapInfo.sum_ypos =0;
  doMultiTapInfo.doTap_event  =0;
}
#endif

#if CONFIG_HAS_LPWG_DUALMULTITAP
#if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
void clearGestureTapSyncStatus(void)
{
  gmultitap_sync_pending_vote1 = 0;
  gmultitap_sync_pending_vote2 = 0;
}

void checkGestureTapSyncStatus_DualMultiTap(void)
{
  if(gmultitap_sync_pending_vote1||!CONFIG_HAS_LPWG_MULTITAP)
  {
    clearGestureTapSyncStatus();
  }
  else
  {
    gmultitap_sync_pending_vote2 = 1;
  }
}

void checkGestureTapSyncStatus(void)
{
  // check another tap is already failed
  if(gmultitap_sync_pending_vote2 ||!CONFIG_HAS_LPWG_DUALMULTITAP)
  {
    clearGestureTapSyncStatus();
  }
  else
  {
    gmultitap_sync_pending_vote1 = 1;
  }
}
#endif // CONFIG_LPWG_DUALMULTITAP_FIRSTONLY

void processLPWG_DualMultiTap(uint16 xPos, uint16 yPos, uint16 currFinger)
{
  uint16 gestureType = params.cfg.gestureType;
  uint16 inZone = (xPos >= params.cfg.doubleTapZoneX0 &&
                   xPos <= params.cfg.doubleTapZoneX1 &&
                   yPos >= params.cfg.doubleTapZoneY0 &&
                   yPos <= params.cfg.doubleTapZoneY1);

  gesture2.LPWG = 0;

  if((gestureType & LPWG_MULTITAP_ENABLE)&&CONFIG_HAS_LPWG_DUALMULTITAP)
  {
    if(inZone)
    {
      doTap_DualMultiTap(xPos, yPos, currFinger);
      if(gesture2.tap == MULTI_TAP)
      {
        // It makes abs0 attn, don't set it for f51 multitap
        #if !CONFIG_LPWG_MULTITAP_HOSTSYNC
          gesture2.LPWG = 1;
        #endif
      }
    }
    else
    {
      // Cancel the pending gesture
      gesture2.trigTap = 0;
      gesture2.secondTap =0;
      gesture2.tapCnt =0;
    }
  }

  if(gesture2.tap != MULTI_TAP)
  {
    resetDetectedLPWG();
  }
}

#if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
void clearGestureTapInterruptDelayStatus_DualMultiTap()
{
  gmultitap_interruptdelay2_pending = 0;
  gmultitap_interruptdelay2_tapcnt= 0;
  gmultitap_interruptdelay2_fingerpress = 0;
}
#endif

void doTap_DualMultiTap(uint16 xPos ATTR_UNUSED, uint16 yPos ATTR_UNUSED, uint16 currFinger ATTR_UNUSED)
{
  tapEvents_t event = NONE; // Assume there will be no event this time.

  #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
    if(gmultitap_sync_pending_vote2)
      return;
  #endif

  #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
    if(params.cfg.MultiTapInterruptDelayTimeEnable_DualMultiTap)
    {
      if(gmultitap_interruptdelay2_pending && checkInterruptDelayTimeExpire_DualMultiTap() && !gmultitap_interruptdelay2_fingerpress)
      {
        #if CONFIG_LPWG_MULTITAP_FAIL_TAP
        if(!dbg_OverTap_Fail)
        {
        #endif
          //multitap success!!, pass the interrupt delay condition
          gesture2.tap = MULTI_TAP;
          #if CONFIG_LPWG_MULTITAP_FAIL_TAP
            dbg_OverTapCnt = 0;
          #endif

          //clear all state
          clearGestureTapStatus_DualMultiTap();
          //clear int delay variables 2
          #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
            clearGestureTapInterruptDelayStatus_DualMultiTap();
          #endif
          #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
            gesture.tap = 0;
            clearGestureTapStatus();

            //clear int delay variables
            clearGestureTapInterruptDelayStatus();
            clearGestureTapSyncStatus();
          #endif

          #if cfg_DBG_MULTITAP
            dbg_multitap2_intdelay_success++;
          #endif
          return;
        #if CONFIG_LPWG_MULTITAP_FAIL_TAP
        }
        #endif // CONFIG_LPWG_MULTITAP_FAIL_TAP
      }
      #if CONFIG_LPWG_MULTITAP_FAIL_TAP
        if (dbg_OverTap_Fail && gmultitap_interruptdelay2_pending && checkInterruptDelayTimeExpire_DualMultiTap()
            && (dbg_OverTapCnt >  params.cfg.MultiTapCount_DualMultiTap))
        {
          dbg_OverTap_Fail = 0;
          //multitap failure!!, fails the interrupt delay condition
          //clear all state
          clearGestureTapStatus_DualMultiTap();
          //clear interrupt dealy status
          #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
            clearGestureTapInterruptDelayStatus_DualMultiTap();
          #endif
          #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
            gesture.tap = 0;
            clearGestureTapStatus();
            //clear int delay variables

            clearGestureTapInterruptDelayStatus();
            clearGestureTapSyncStatus();
          #endif

          #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
            #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
            if(gmultitap2_failreason_realtime_interrrupt == 0)
            {
            #endif
              gmultitap2_failedcount++;
              gmultitap2_failreason_delaytime++;
              COMM_updateMultiTapFailReason2Buffer(gmultitap2_failedcount, MULTITAP_FAILREASON_TAP_COUNT);
            #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
              gmultitap2_failreason_realtime_interrrupt = MULTITAP_FAILREASON_TAP_COUNT;//MULTITAP_FAILREASON_DELAYTIME;
            }
            #endif
          #endif

          #if CONFIG_LPWG_MULTITAP_FAIL_TAPCOUNT
            #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
            if(gmultitap2_failreason_realtime_interrrupt == MULTITAP_FAILREASON_TAP_COUNT)
            {
              if( ((1<<(gmultitap2_failreason_realtime_interrrupt-1))
                  & (params.cfg.MultiTapFailRealTimeInterruptEnable_HIGH
                  | params.cfg.MultiTapFailRealTimeInterruptEnable_LOW)) )
              {
            #endif
              COMM_updateMultiTapFailOverTapCount(dbg_OverTapCnt);
            #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
              }
            }
            #endif
          #endif
          dbg_OverTapCnt = 0;
          return;
        }
      #endif // CONFIG_LPWG_MULTITAP_FAIL_TAP
    }
  #endif

  if (currFinger)
  {
    #if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
      if(gesture.numFingerPrev != 0)
      {
        if(doMultiTapInfo.doTap_event == 0)
        {
          if(doMultiTapInfo.first_tap ==0)
          {
            doMultiTapInfo.pre_xpos = gesture2.xStartPos;
            doMultiTapInfo.pre_ypos = gesture2.yStartPos;
            doMultiTapInfo.first_tap =1;
          }

          doMultiTapInfo.sum_xpos += abs16((int)(xPos - doMultiTapInfo.pre_xpos));
          doMultiTapInfo.sum_ypos += abs16((int)(yPos - doMultiTapInfo.pre_ypos));

          if((doMultiTapInfo.sum_xpos >=params.cfg.MultiTapPressReleaseDistance_DualMultiTap)
             ||(doMultiTapInfo.sum_ypos >= params.cfg.MultiTapPressReleaseDistance_DualMultiTap))
          {
            doMultiTapInfo.doTap_event = 1;
          }
          doMultiTapInfo.pre_xpos = xPos;
          doMultiTapInfo.pre_ypos = yPos;
        }
      }
    #endif

    if(gesture.numFingerPrev == 0)
    { // skwak, it could be shared
      // Finger has just touched.  If far away from where it was lifted,
      // set event to MISS.  Otherwise, leave event at NONE.
      #if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
        clearDoMultiTapInfo();
      #endif

      #if CONFIG_LPWG_DUALMULTITAP_MININTERTAP_ENABLE
        if (checkTapMinTimeExpire_DualMultiTap())
        {
          gmultitap_intertap_under_min2=1;
        }
      #endif

      #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
        if(params.cfg.MultiTapInterruptDelayTimeEnable_DualMultiTap)
        {
          if(gmultitap_interruptdelay2_pending)
          {
            gmultitap_interruptdelay2_fingerpress=1;
            #if CONFIG_LPWG_MULTITAP_FAIL_TAP
              gmultitap_interruptdelay2_tapcnt = 0;
            #endif
          }
        }
      #endif

      if (!checkInterTapDistance_DualMultiTap(xPos, yPos))
      {
        event = MISS;
        #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
          if(gesture2.secondTap != 0)
          {// first tap don't have to check sync status. it causes next intertap start position problem.
            checkGestureTapSyncStatus_DualMultiTap();
          }
        #endif

        #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
          if(gesture2.secondTap != 0)
          {// first tap don't have to check sync status. it causes next intertap start position problem.
            #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
            if(gmultitap2_failreason_realtime_interrrupt == 0)
            {
            #endif
              gmultitap2_failreason_distance_intertap++;
              gmultitap2_failedcount++;
              COMM_updateMultiTapFailReason2Buffer(gmultitap2_failedcount, MULTITAP_FAILREASON_DISTANCE_INTERTAP);
            #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
              gmultitap2_failreason_realtime_interrrupt = MULTITAP_FAILREASON_DISTANCE_INTERTAP;
            }
            #endif
            #if CONFIG_LPWG_MULTITAP_FAIL_TAP
              dbg_OverTapCnt = 0;
            #endif
          }
        #endif

        gesture2.secondTap = 0;
        #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
          clearGestureTapInterruptDelayStatus_DualMultiTap();
        #endif
      }
      gesture2.trigTap = 1;
      gesture2.tapCnt = 0;
    }
  }
  else
  {
    if(gesture.numFingerPrev == 1)
    {
      gesture2.tapCnt = 0;
      // Finger has just lifted.  If close to where it touched down, set event
      // to LIFT; if far, set event to MISS.
      event = ((checkTapDistance_DualMultiTap(xPos, yPos)) ? LIFT : MISS);

      #if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
        event = ( (doMultiTapInfo.doTap_event ==0) ? LIFT : MISS);
      #endif

      #if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
        if (event==MISS)
        {
          #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
            if(!gmultitap2_failreason_multifinger_ispressing)
            {
              #if CONFIG_LPWG_MULTITAP_DISTANCE
                #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
                if(gmultitap2_failreason_realtime_interrrupt == 0)
                {
                #endif
                  gmultitap2_failedcount++;
                  gmultitap2_failreason_distance_pressrel++;
                  COMM_updateMultiTapFailReason2Buffer(gmultitap2_failedcount, MULTITAP_FAILREASON_DISTANCE_PRESSREL);
                #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
                  gmultitap2_failreason_realtime_interrrupt = MULTITAP_FAILREASON_DISTANCE_PRESSREL;
                }
                #endif
              #endif

              #if CONFIG_LPWG_MULTITAP_FAIL_TAP
                dbg_OverTapCnt = 0;
              #endif
            }
          #endif

          gesture2.secondTap = 0;
          gesture2.trigTap = 0;
          #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
            checkGestureTapSyncStatus_DualMultiTap();
          #endif
          #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
            #if CONFIG_LPWG_MULTITAP_FAIL_TAP
            if(!dbg_OverTap_Fail)
            {
            #endif
              clearGestureTapInterruptDelayStatus_DualMultiTap();
            #if CONFIG_LPWG_MULTITAP_FAIL_TAP
            }
            #endif
          #endif
        }
        if (event==LIFT)
        {
          if( params.cfg.MultiTapCount_DualMultiTap == 1)
          {
            gesture2.tap = MULTI_TAP;
            #if CONFIG_LPWG_MULTITAP_FAIL_TAP
              dbg_OverTapCnt = 0;
            #endif
            return;
          }
        }
      #endif
      // Update startPos.
      gesture2.xStartPos = xPos;
      gesture2.yStartPos = yPos;
    }
  }

  if (!gesture2.trigTap)
  {
    #if CONFIG_LPWG_MULTITAP_FAIL_TAP && CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
      if (dbg_OverTap_Fail&&gmultitap_interruptdelay2_pending &&!checkInterruptDelayTimeExpire_DualMultiTap())
      {
        gmultitap_interruptdelay2_tapcnt++;
      }
    #endif
    return;
  }

  if ((checkTapTimeExpire_DualMultiTap()
    #if CONFIG_LPWG_DUALMULTITAP_MININTERTAP_ENABLE
      || gmultitap_intertap_under_min2
    #endif
      )
    #if CONFIG_LPWG_MULTITAP_FAIL_TAP && CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
      && (!gmultitap_interruptdelay2_pending)
    #endif
  )
  {
    event = TIMEOUT;
    gesture2.secondTap =0;
    gesture2.tapCnt = 0;
    gesture2.trigTap = 0;
    #if CONFIG_LPWG_DUALMULTITAP_MININTERTAP_ENABLE
      if(gmultitap_intertap_under_min2)
        gmultitap_intertap_under_min2 = 0;
    #endif

    #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
      checkGestureTapSyncStatus_DualMultiTap();
    #endif

    #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
      #if CONFIG_LPWG_MULTITAP_FAIL_TAP
      if(!dbg_OverTap_Fail)
      {
      #endif
        clearGestureTapInterruptDelayStatus_DualMultiTap();
      #if CONFIG_LPWG_MULTITAP_FAIL_TAP
      }
      #endif
    #endif

    #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
      #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
      if(gmultitap2_failreason_realtime_interrrupt == 0)
      {
      #endif
        gmultitap2_failedcount++;
        gmultitap2_failreason_timeout_intertap++;
        COMM_updateMultiTapFailReason2Buffer(gmultitap2_failedcount, MULTITAP_FAILREASON_TIMEOUT_INTERTAP);
      #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
        gmultitap2_failreason_realtime_interrrupt = MULTITAP_FAILREASON_TIMEOUT_INTERTAP;
      }
      #endif
    #if CONFIG_LPWG_MULTITAP_FAIL_TAP
      dbg_OverTapCnt = 0;
    #endif
  #endif
  }
  else
  {
    // System timer is not very accurate. Instead, use frame rate.
    gesture2.tapCnt++;
    #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
      gmultitap_interruptdelay2_tapcnt++;
    #endif
  }

  if (!gesture2.secondTap)
  {
    if (event == LIFT)
    {
      // If only LPWG is enabled, we do not want to introduce 'hold' delay in declaring tap gesture. This block of code should be
      // executed in LPWG mode only.
      if(gesture.useWakeupGestureParameters)
      {
        multipletapsXpos2[gesture2.secondTap ] = xPos;
        multipletapsYpos2[gesture2.secondTap ] = yPos;
        gesture2.secondTap = 1;
        #if CONFIG_LPWG_MULTITAP_FAIL_TAP
          dbg_OverTapCnt = 1;
        #endif
      }
    }
  }
  else
  {
    if (event != NONE)
    {
      if (event == TIMEOUT)
      {
        if (currFinger)
        {
          #if CONFIG_HAS_LPWG_TAPANDHOLD
            gesture2.tap = TAP_AND_HOLD;
          #endif
        }
      }
      else if (event == LIFT)
      {      // If double tap is not enabled in normal mode but present in LPWG mode, set this flag only if
        // reporting mode is LPWG or SFR is on
        if(gesture.useWakeupGestureParameters)
        {
          #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
            if(params.cfg.MultiTapInterruptDelayTimeEnable_DualMultiTap)
            {
              #if CONFIG_LPWG_MULTITAP_FAIL_TAP
                if(gmultitap_interruptdelay2_pending && gmultitap_interruptdelay2_fingerpress && (!checkInterruptDelayTimeExpire_DualMultiTap()))
                {
                  dbg_OverTapCnt++;
                  gmultitap_interruptdelay2_tapcnt = 0;
                  gmultitap_interruptdelay2_fingerpress = 0;
                  dbg_OverTap_Fail = 1;
                  return;
                }
              #else
                if(gmultitap_interruptdelay2_pending && gmultitap_interruptdelay2_fingerpress)
                {
                  //multitap failure!!, fails the interrupt delay condition
                  //clear all state
                  clearGestureTapStatus_DualMultiTap();
                  //clear interrupt dealy status
                  #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
                    clearGestureTapInterruptDelayStatus_DualMultiTap();
                  #endif
                  #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
                    checkGestureTapSyncStatus();
                  #endif
                  #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
                    #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
                    if(gmultitap2_failreason_realtime_interrrupt == 0)
                    {
                    #endif
                      gmultitap2_failedcount++;
                      gmultitap2_failreason_delaytime++;
                      COMM_updateMultiTapFailReason2Buffer(gmultitap2_failedcount, MULTITAP_FAILREASON_DELAYTIME);
                    #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
                      gmultitap2_failreason_realtime_interrrupt = MULTITAP_FAILREASON_DELAYTIME;
                    }
                    #endif
                  #endif
                  return;
                }
              #endif // CONFIG_LPWG_MULTITAP_FAIL_TAP
            }
          #endif

          if (gesture2.secondTap < params.cfg.MultiTapCount_DualMultiTap)
          {
            multipletapsXpos2[gesture2.secondTap] = xPos;
            multipletapsYpos2[gesture2.secondTap] = yPos;
          }
          gesture2.secondTap++;
          #if CONFIG_LPWG_MULTITAP_FAIL_TAP
            dbg_OverTapCnt++;
          #endif
          if (gesture2.secondTap ==  params.cfg.MultiTapCount_DualMultiTap)
          {
            #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
            if(params.cfg.MultiTapInterruptDelayTimeEnable_DualMultiTap)
            {
              gmultitap_interruptdelay2_pending = 1;
              gmultitap_interruptdelay2_tapcnt = 0;
            }
            else
            #endif
            {
              gesture2.tap = MULTI_TAP;
              //clear all state
              clearGestureTapStatus_DualMultiTap();

              #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
                gesture.tap = 0;
                clearGestureTapStatus();
                clearGestureTapSyncStatus();
              #endif
            }
            #if cfg_DBG_MULTITAP
              dbg_multitap2_success++;
            #endif
          }
        }
      }
    }
  }
  #if cfg_DBG_MULTITAP
    dbg_multitap2_trigtap=gesture2.trigTap;
    dbg_multitap2_tapcnt=gesture2.tapCnt;
    dbg_multitap2_secondtap=gesture2.secondTap;
  #endif
}

#if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
uint16 checkInterruptDelayTimeExpire_DualMultiTap(void)
{
  return ((uint16)gmultitap_interruptdelay2_tapcnt >= COMM_getMultiTapInterruptDelayTimeConvertedIntoFramesLPWG_DualMultiTap(multitap_report_rate));
}
#endif

#if CONFIG_LPWG_DUALMULTITAP_MININTERTAP_ENABLE
uint16 checkTapMinTimeExpire_DualMultiTap(void)
{
  if(gesture2.tapCnt == 0)
    return 0;
  else
    return ((uint16)gesture2.tapCnt < COMM_getMultiTapMinTapTimeConvertedIntoFramesLPWG_DualMultiTap(multitap_report_rate));
}
#endif

uint16 checkTapTimeExpire_DualMultiTap(void)
{
#if CONFIG_LPWG_DUALMULTITAP_MININTERTAP_ENABLE
  return ((uint16)gesture2.tapCnt >= COMM_getMultiTapMaxTapTimeConvertedIntoFramesLPWG_DualMultiTap(multitap_report_rate));
#else
  return (((uint16)gesture2.tapCnt < COMM_getMultiTapMinTapTimeConvertedIntoFramesLPWG_DualMultiTap(multitap_report_rate))
          ||((uint16)gesture2.tapCnt >= COMM_getMultiTapMaxTapTimeConvertedIntoFramesLPWG_DualMultiTap(multitap_report_rate)));
#endif
}

uint16 checkTapDistance_DualMultiTap(uint16 xPos, uint16 yPos)
{
  uint16 tmpX = 0;
  uint16 tmpY = 0;

  if(gesture.useWakeupGestureParameters)
  {
    tmpX = COMM_gettenthToUnits(params.cfg.MultiTapPressReleaseDistance_DualMultiTap,1);
    tmpY = COMM_gettenthToUnits(params.cfg.MultiTapPressReleaseDistance_DualMultiTap,0);
  }
  return (isClose((xPos-gesture2.xStartPos), (yPos-gesture2.yStartPos), tmpX, tmpY));
}

uint16 checkInterTapDistance_DualMultiTap(uint16 xPos, uint16 yPos)
{
  uint16 tmpX = 0;
  uint16 tmpY = 0;

  if(gesture.useWakeupGestureParameters)
  {
    tmpX = COMM_getxMmToUnits(params.cfg.MultiTapInterTapDistance_DualMultiTap) ;
    tmpY = COMM_getyMmToUnits(params.cfg.MultiTapInterTapDistance_DualMultiTap) ;
  }
  return (isClose((xPos-gesture2.xStartPos), (yPos-gesture2.yStartPos), tmpX, tmpY));
}
#endif // CONFIG_HAS_LPWG_DUALMULTITAP

#if cfg_DBG_MULTITAP
uint16 DBG_multitap_secondTap;
uint16 dbg_multitap1_success;
uint16 dbg_multitap1_trigtap;
uint16 dbg_multitap1_tapcnt;
uint16 dbg_multitap1_secondtap;
uint16 dbg_multitap1_intdelay_success;
#endif

#if CONFIG_LPWG_MULTITAP_INTRRDELAY
void clearGestureTapInterruptDelayStatus()
{
  gmultitap_interruptdelay1_pending = 0;
  gmultitap_interruptdelay1_tapcnt= 0;
  gmultitap_interruptdelay1_fingerpress = 0;
}
#endif

void clearGestureTapStatus(void)
{
  gesture.secondTap =0;
  gesture.tapCnt =0;
  gesture.trigTap =0;
}

#if CONFIG_HAS_LPWG_DUALMULTITAP
void clearGestureTapStatus_DualMultiTap(void)
{
  gesture2.secondTap =0;
  gesture2.tapCnt =0;
  gesture2.trigTap =0;
}
#endif

static void tapInit(void)
{
  clearGestureTapStatus();
  #if CONFIG_HAS_LPWG_DUALMULTITAP
    clearGestureTapStatus_DualMultiTap();
  #endif
  #if CONFIG_LPWG_MULTITAP_INTRRDELAY
    clearGestureTapInterruptDelayStatus();
  #endif
  #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
    clearGestureTapInterruptDelayStatus_DualMultiTap();
  #endif
  #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
    clearGestureTapSyncStatus();
  #endif
  #if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
    clearDoTapInfo();
    clearDoMultiTapInfo();
  #endif
}

uint16 gWakeupGestureParametersprev;

#if defined(cfg_applyForcedRelaxLPWGpending) && cfg_applyForcedRelaxLPWGpending
  extern uint16 gForceRelaxLPWGpending;
  extern uint16 gWakeupGestureOnlyNotice;
#endif

#if CONFIG_LPWG_MULTITAP_MININTERTAP_ENABLE
uint16 gmultitap_intertap_under_min;
#endif
void doTap(uint16 xPos ATTR_UNUSED, uint16 yPos ATTR_UNUSED, uint16 currFinger ATTR_UNUSED)
{
  tapEvents_t event = NONE; // Assume there will be no event this time.

  if(gesture.useWakeupGestureParameters && !gWakeupGestureParametersprev)
  {
    tapInit();
  }
  gWakeupGestureParametersprev = gesture.useWakeupGestureParameters;

  #if CONFIG_LPWG_MULTITAP_INTRRDELAY
    #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
      if(gmultitap_sync_pending_vote1)
        return; // do nothing
    #endif
    if(params.cfg.MultiTapInterruptDelayTimeEnable)
    {
      if(gmultitap_interruptdelay1_pending && checkInterruptDelayTimeExpire() && !gmultitap_interruptdelay1_fingerpress)
      {
        //multitap success!!, pass the interrupt delay condition
        gesture.tap = MULTI_TAP;
        #if CONFIG_LPWG_MULTITAP_FAIL_TAP
          dbg_OverTapCnt = 0;
        #endif

        //clear all state
        clearGestureTapStatus();

        //clear int delay variables
        clearGestureTapInterruptDelayStatus();

        //sync up to another tap variables
        #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
          gesture2.tap = 0;
          clearGestureTapStatus_DualMultiTap();
          #if CONFIG_LPWG_DUALMULTITAP_INTRRDELAY
            //clear int delay variables
            clearGestureTapInterruptDelayStatus_DualMultiTap();
          #endif
          clearGestureTapSyncStatus();
        #endif

        #if cfg_DBG_MULTITAP
          dbg_multitap1_intdelay_success++;
        #endif

        return;
      }
    }
  #endif

  if(currFinger)
  {
    #if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
      if(gesture.numFingerPrev != 0)
      {
        if(doTapInfo.doTap_event == 0)
        {
          if(doTapInfo.first_tap ==0)
          {
            doTapInfo.pre_xpos = gesture.xStartPos;
            doTapInfo.pre_ypos = gesture.yStartPos;
            doTapInfo.first_tap =1;
          }
          doTapInfo.sum_xpos += abs16((int)(xPos - doTapInfo.pre_xpos));
          doTapInfo.sum_ypos += abs16((int)(yPos - doTapInfo.pre_ypos));

          if((doTapInfo.sum_xpos >= params.cfg.MultiTapPressReleaseDistance)
             ||(doTapInfo.sum_ypos >= params.cfg.MultiTapPressReleaseDistance))
          {
            doTapInfo.doTap_event = 1;
          }
          doTapInfo.pre_xpos = xPos;
          doTapInfo.pre_ypos = yPos;
        }
      }
    #endif

    if (gesture.numFingerPrev == 0)
    {
      // Finger has just touched.  If far away from where it was lifted,
      // set event to MISS.  Otherwise, leave event at NONE.
      #if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
        clearDoTapInfo();
      #endif

      #if CONFIG_LPWG_MULTITAP_MININTERTAP_ENABLE
        if (checkTapMinTimeExpire())
        {
          gmultitap_intertap_under_min=1;
        }
      #endif

      #if defined(cfg_applyForcedRelaxLPWGpending) && cfg_applyForcedRelaxLPWGpending
        if(gWakeupGestureOnlyNotice == 1 && gForceRelaxLPWGpending == 0)//first finger in wake up gesture only mode, so pend it
        {
          gWakeupGestureOnlyNotice = 0; // clear
          gForceRelaxLPWGpending=1; // set
        }
      #endif

      #if CONFIG_LPWG_MULTITAP_INTRRDELAY
        if(params.cfg.MultiTapInterruptDelayTimeEnable)
        {
          if(gmultitap_interruptdelay1_pending)
          {
            gmultitap_interruptdelay1_fingerpress=1;
          }
        }
      #endif

      if (!checkInterTapDistance(xPos, yPos))
      {
        event = MISS;
        #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
          if(gesture.secondTap != 0)
          {// first tap don't have to check sync status. it causes next intertap start position problem.
            checkGestureTapSyncStatus();
          }
        #endif

        #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
          if(gesture.secondTap != 0)
          {// first tap don't have to check sync status. it causes next intertap start position problem.
            #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
            if(gmultitap1_failreason_realtime_interrrupt == 0)
            {
            #endif
              gmultitap1_failreason_distance_intertap++;
              gmultitap1_failedcount++;
              COMM_updateMultiTapFailReason1Buffer(gmultitap1_failedcount, MULTITAP_FAILREASON_DISTANCE_INTERTAP);
            #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
              gmultitap1_failreason_realtime_interrrupt = MULTITAP_FAILREASON_DISTANCE_INTERTAP;
            }
            #endif
          }
        #endif

        gesture.secondTap = 0;
        #if CONFIG_LPWG_MULTITAP_INTRRDELAY
          clearGestureTapInterruptDelayStatus();
        #endif
      }

      gesture.trigTap = 1;
      gesture.tapCnt = 0;
    }
  }
  else
  {
    if (gesture.numFingerPrev == 1)
    {
      gesture.tapCnt = 0;
      // Finger has just lifted.  If close to where it touched down, set event
      // to LIFT; if far, set event to MISS.
      event = ((checkTapDistance(xPos, yPos)) ? LIFT : MISS);

      #if CONFIG_LPWG_MULTITAP_CALC_DISTANCE
        event = ( (doTapInfo.doTap_event == 0) ? LIFT : MISS);
      #endif

      if(event==MISS)
      {
        #if CONFIG_LPWG_MULTITAP_DISTANCE
          #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
            if(!gmultitap1_failreason_multifinger_ispressing)
            {
              #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
              if(gmultitap1_failreason_realtime_interrrupt == 0)
              {
              #endif
                gmultitap1_failedcount++;
                gmultitap1_failreason_distance_pressrel++;
                COMM_updateMultiTapFailReason1Buffer(gmultitap1_failedcount, MULTITAP_FAILREASON_DISTANCE_PRESSREL);

              #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
                gmultitap1_failreason_realtime_interrrupt = MULTITAP_FAILREASON_DISTANCE_PRESSREL;
              }
              #endif
            }
          #endif
        #endif // CONFIG_LPWG_MULTITAP_DISTANCE

        gesture.secondTap = 0;
        gesture.trigTap = 0;

        #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
          checkGestureTapSyncStatus();
        #endif
        #if CONFIG_LPWG_MULTITAP_INTRRDELAY
          clearGestureTapInterruptDelayStatus();
        #endif
      }

      if (event==LIFT)
      {
        if( params.cfg.MultiTapCount==1)
        {  // For multitap =1
          gesture.tap = MULTI_TAP;
          #if CONFIG_LPWG_MULTITAP_FAIL_TAP
            dbg_OverTapCnt = 0;
          #endif
          return;
        }
      }
      // Update startPos.
      gesture.xStartPos = xPos;
      gesture.yStartPos = yPos;
    }
  }

  if (!gesture.trigTap)
  {
    return;
  }

  // If the tap/intertap timer has expired, set event to TIMEOUT,
  // overriding a MISS or LIFT.
  if (checkTapTimeExpire()
    #if CONFIG_LPWG_MULTITAP_MININTERTAP_ENABLE
      || gmultitap_intertap_under_min
    #endif
  )
  {
    event = TIMEOUT;
    gesture.secondTap =0;
    gesture.tapCnt = 0;
    gesture.trigTap = 0;

    #if CONFIG_LPWG_MULTITAP_MININTERTAP_ENABLE
      if(gmultitap_intertap_under_min)
        gmultitap_intertap_under_min = 0;
    #endif

    #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
      checkGestureTapSyncStatus();
    #endif

    #if CONFIG_LPWG_MULTITAP_INTRRDELAY
      clearGestureTapInterruptDelayStatus();
    #endif

    #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
      #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
      if(gmultitap1_failreason_realtime_interrrupt == 0)
      {
      #endif
        gmultitap1_failedcount++;
        gmultitap1_failreason_timeout_intertap++;
        COMM_updateMultiTapFailReason1Buffer(gmultitap1_failedcount, MULTITAP_FAILREASON_TIMEOUT_INTERTAP);

      #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
        gmultitap1_failreason_realtime_interrrupt = MULTITAP_FAILREASON_TIMEOUT_INTERTAP;
      }
      #endif
    #endif
  }
  else
  {
    // System timer is not very accurate. Instead, use frame rate.
    gesture.tapCnt++;
    #if CONFIG_LPWG_MULTITAP_INTRRDELAY
      gmultitap_interruptdelay1_tapcnt++;
    #endif
  }

  if (!gesture.secondTap)
  {
    if (event == LIFT)
    {
      // If only LPWG is enabled, we do not want to introduce 'hold' delay in declaring tap gesture. This block of code should be
      // executed in LPWG mode only.
      if(gesture.useWakeupGestureParameters)
      {
        multipletapsXpos[gesture.secondTap ] = xPos;
        multipletapsYpos[gesture.secondTap ] = yPos;
        gesture.secondTap = 1;
      }
    }
  }
  else
  {
    if (event == TIMEOUT)
    {
      if (currFinger)
      {
        #if CONFIG_HAS_LPWG_TAPANDHOLD
          gesture2.tap = TAP_AND_HOLD;
        #endif
      }
    }
    else if (event == LIFT)
    {
      // If double tap is not enabled in normal mode but present in LPWG mode, set this flag only if
      // reporting mode is LPWG or SFR is on
      if(gesture.useWakeupGestureParameters)
      {
        #if CONFIG_LPWG_MULTITAP_INTRRDELAY
          if(params.cfg.MultiTapInterruptDelayTimeEnable)
          {
            if(gmultitap_interruptdelay1_pending && gmultitap_interruptdelay1_fingerpress)
            {
              //multitap failure !!, fails the interrupt delay condition
              //clear all state
              clearGestureTapStatus();
              //clear interrupt dealy status
              clearGestureTapInterruptDelayStatus();

              #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
                checkGestureTapSyncStatus();
              #endif
              #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
                #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
                if(gmultitap1_failreason_realtime_interrrupt == 0)
                {
                #endif
                  gmultitap1_failedcount++;
                  gmultitap1_failreason_delaytime++;
                  COMM_updateMultiTapFailReason1Buffer(gmultitap1_failedcount, MULTITAP_FAILREASON_DELAYTIME);

                #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
                  gmultitap1_failreason_realtime_interrrupt = MULTITAP_FAILREASON_DELAYTIME;
                }
                #endif
              #endif
              return;
            }
          }
        #endif

        if (gesture.secondTap <  params.cfg.MultiTapCount)
        {
          multipletapsXpos[gesture.secondTap] = xPos;
          multipletapsYpos[gesture.secondTap] = yPos;
        }

        gesture.secondTap++;

        #if cfg_DBG_MULTITAP
          DBG_multitap_secondTap = gesture.secondTap;
        #endif

        if (gesture.secondTap ==  params.cfg.MultiTapCount)
        {
          #if CONFIG_LPWG_MULTITAP_INTRRDELAY
          if(params.cfg.MultiTapInterruptDelayTimeEnable)
          {
            gmultitap_interruptdelay1_pending = 1;
            gmultitap_interruptdelay1_tapcnt = 0;
          }
          else
          #endif
          {
            gesture.tap = MULTI_TAP;
            #if CONFIG_LPWG_MULTITAP_FAIL_TAP
              dbg_OverTapCnt = 0;
            #endif
            //clear all state
            clearGestureTapStatus();

            #if CONFIG_LPWG_DUALMULTITAP_FIRSTONLY
              gesture2.tap = 0;
              clearGestureTapSyncStatus();
              clearGestureTapStatus_DualMultiTap();
            #endif
          }

          #if cfg_DBG_MULTITAP
            dbg_multitap1_success++;
          #endif
        }
      }
    }
  }

  #if cfg_DBG_MULTITAP
    dbg_multitap1_trigtap=gesture.trigTap;
    dbg_multitap1_tapcnt=gesture.tapCnt;
    dbg_multitap1_secondtap=gesture.secondTap;
  #endif
}

#if CONFIG_LPWG_MULTITAP_INTRRDELAY
uint16 checkInterruptDelayTimeExpire(void)
{
  return ((uint16)gmultitap_interruptdelay1_tapcnt >= COMM_getMultiTapInterruptDelayTimeConvertedIntoFramesLPWG(multitap_report_rate));
}
#endif

#if CONFIG_LPWG_MULTITAP_MININTERTAP_ENABLE
uint16 checkTapMinTimeExpire(void)
{
  if(gesture.tapCnt == 0)
    return 0;
  else
    return ((uint16)gesture.tapCnt < COMM_getMultiTapMinTapTimeConvertedIntoFramesLPWG(multitap_report_rate));
}
#endif

uint16 checkTapTimeExpire(void)
{
#if CONFIG_LPWG_MULTITAP_MININTERTAP_ENABLE
  return ((uint16)gesture.tapCnt >= COMM_getMultiTapMaxTapTimeConvertedIntoFramesLPWG(multitap_report_rate));
#else
  return (((uint16)gesture.tapCnt < COMM_getMultiTapMinTapTimeConvertedIntoFramesLPWG(multitap_report_rate))
           || ((uint16)gesture.tapCnt >= COMM_getMultiTapMaxTapTimeConvertedIntoFramesLPWG(multitap_report_rate)));
#endif
}

uint16 checkTapDistance(uint16 xPos, uint16 yPos)
{
  uint16 tmpX = 0;
  uint16 tmpY = 0;

  if(gesture.useWakeupGestureParameters)
  {
    tmpX = COMM_gettenthToUnits(params.cfg.MultiTapPressReleaseDistance,1);
    tmpY = COMM_gettenthToUnits(params.cfg.MultiTapPressReleaseDistance,0);
  }
  return (isClose((xPos-gesture.xStartPos), (yPos-gesture.yStartPos), tmpX, tmpY));
}

uint16 checkInterTapDistance(uint16 xPos, uint16 yPos)
{
  uint16 tmpX = 0;
  uint16 tmpY = 0;

  if(gesture.useWakeupGestureParameters)
  {
    tmpX = COMM_getxMmToUnits(params.cfg.MultiTapInterTapDistance);
    tmpY = COMM_getyMmToUnits(params.cfg.MultiTapInterTapDistance);
  }
  return (isClose((xPos-gesture.xStartPos), (yPos-gesture.yStartPos), tmpX, tmpY));
}

void doGestures(touchReport_t *report)
{
  uint16 numFingers = 0,i =0, inZone;
  #if CONFIG_LPWG_MULTITAP_REJECTZONE
    uint16 xPos = 0;
    uint16 yPos = 0;
  #endif
  #if CONFIG_LPWG_MULTITAP_ACTIVEAREA_ENABLE
    uint16 active_area_finger_counter = 0;
  #endif
  hostClassification_t obj_classification = hostClassification_none;
  reportPos_t *temp_ReportPos;
  temp_ReportPos=(reportPos_t*)(&report->touch.pos[0]);
  multitap_report_rate = report->frameRate;

  #if CONFIG_HAS_LPWG_POWERREDUCTION
    #if CONFIG_LPWG_POWERREDUCTION_FORCEDOZE_ENABLE
      if(params.cfg.ForceDozeLPWG_byObjectPresent_Trigger >= CONFIG_LPWG_POWERREDUCTION_FORCEDOZE_THREAHOLD)
      {
        if(report->touch.objectsPresent)
        {
          params.cfg.ForceDozeLPWG_byObjectPresent_DoRepeatForceDoze = 1;
        }
        else
        {
          params.cfg.ForceDozeLPWG_byObjectPresent_Trigger=0;
          params.cfg.ForceDozeLPWG_byObjectPresent_DoRepeatForceDoze=0;
        }
      }
    #endif
  #endif

  gesture.useWakeupGestureParameters = (state.enabled) || PROCESS_GESTURE_FOR_SFR;

  while(i < MAX_OBJECTS)
  {
    if(temp_ReportPos->classification != hostClassification_none)
    {
      if(numFingers < MAX_NUM_FINGER_FOR_GESTURE)
      {
        fdPtr[numFingers].xPosition = temp_ReportPos->xMeas;
        fdPtr[numFingers].yPosition = temp_ReportPos->yMeas;
        fdPtr[numFingers].classification = temp_ReportPos->classification;

        #if CONFIG_LPWG_MULTITAP_REJECTZONE
          xPos = fdPtr[numFingers].xPosition;
          yPos = fdPtr[numFingers].yPosition;

          #if CONFIG_LPWG_MULTITAP_ACTIVEAREA_ENABLE
            active_area_finger_counter++;
          #endif

          inZone = (xPos >= params.cfg.doubleTapZoneX0 &&
                    xPos <= params.cfg.doubleTapZoneX1 &&
                    yPos >= params.cfg.doubleTapZoneY0 &&
                    yPos <= params.cfg.doubleTapZoneY1);
          FingerInBuffer = ((((xPos >params.cfg.doubleTapZoneX0)&&(xPos <(params.cfg.doubleTapZoneX0) + params.cfg.BufferZoneSize)))||
                             ((xPos <params.cfg.doubleTapZoneX1)&&(xPos >((params.cfg.doubleTapZoneX1) - params.cfg.BufferZoneSize)))||
                             ((yPos >params.cfg.doubleTapZoneY0)&&(yPos <((params.cfg.doubleTapZoneY0) + params.cfg.BufferZoneSize)))||
                             ((yPos <params.cfg.doubleTapZoneY1)&&(yPos >((params.cfg.doubleTapZoneY1) - params.cfg.BufferZoneSize))));
          numFingers++;

          if(!inZone)
          {
            numFingers--;
            // Cancel the pending gesture
            if(FingerInBuffer)
            {
              gesture.trigTap = 0;
              gesture.secondTap=0;
              gesture.tapCnt=0;
              #if CONFIG_HAS_LPWG_DUALMULTITAP
                gesture2.trigTap = 0;
                gesture2.secondTap=0;
                gesture2.tapCnt=0;
              #endif
              FingerInBuffer = false;
            }

            #if CONFIG_LPWG_MULTITAP_ACTIVEAREA_ENABLE
              if(gesture.useWakeupGestureParameters)
              {
                if(!gmultitap1_failreason_active_area_ispressing)
                {
                  gmultitap1_failreason_active_area_ispressing = 1;
                  gmultitap1_failedcount++;
                  gmultitap1_failreason_active_area++;
                  COMM_updateMultiTapFailReason1Buffer(gmultitap1_failedcount, MULTITAP_FAILREASON_ACTIVE_AREA);
                  #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
                    #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
                      if(gmultitap1_failreason_realtime_interrrupt == 0)
                      {
                        gmultitap1_failreason_realtime_interrrupt = MULTITAP_FAILREASON_ACTIVE_AREA;
                        #if CONFIG_LPWG_MULTITAP_ACTIVEAREA_COORD
                          COMM_updateActiveArea_XY(xPos, yPos);
                        #endif
                      }
                    #endif
                  #endif
                }
              }
              #if CONFIG_HAS_LPWG_DUALMULTITAP
                if(gesture.useWakeupGestureParameters)
                {
                  if(!gmultitap2_failreason_active_area_ispressing)
                  {
                    gmultitap2_failreason_active_area_ispressing = 1;
                    gmultitap2_failedcount++;
                    gmultitap2_failreason_active_area++;
                    COMM_updateMultiTapFailReason2Buffer(gmultitap2_failedcount, MULTITAP_FAILREASON_ACTIVE_AREA);
                    #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
                      #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
                        if(gmultitap2_failreason_realtime_interrrupt == 0)
                        {
                          gmultitap2_failreason_realtime_interrrupt = MULTITAP_FAILREASON_ACTIVE_AREA;
                          #if CONFIG_LPWG_MULTITAP_ACTIVEAREA_COORD
                            COMM_updateActiveArea_XY(xPos, yPos);
                          #endif
                        }
                      #endif
                    #endif
                  }
                }
              #endif
            #endif
          }
        #endif
      }
    }
    temp_ReportPos++;
    i++;
  }

  #if CONFIG_LPWG_MULTITAP_ACTIVEAREA_ENABLE
    #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORT
      if (active_area_finger_counter == 0)
      {
        #if CONFIG_LPWG_MULTITAP_ACTIVEAREA_ENABLE
          gmultitap1_failreason_active_area_ispressing = 0;
          #if CONFIG_HAS_LPWG_DUALMULTITAP
            gmultitap2_failreason_active_area_ispressing = 0;
          #endif
        #endif
      }
    #endif
  #endif

  for(i=0; i< MAX_NUM_FINGER_FOR_GESTURE; i++)
  {
    if(fdPtr[i].classification == hostClassification_palm)
    {
      obj_classification = hostClassification_palm;
      fdPtr[i].classification = 0;
    }
  }
  /*** Processing ***/
  #if CONFIG_LPWG_MULTITAP_FAIL_PALM
    doGesturesProc(numFingers, obj_classification);
  #else
    doGesturesProc(numFingers);
  #endif

  #if CONFIG_LPWG_MULTITAP_FAILREASON_REPORTINTERRUPT
    if(gmultitap1_failreason_realtime_interrrupt != 0)
    {
      if( ((1<<(gmultitap1_failreason_realtime_interrrupt-1))
             & (params.cfg.MultiTapFailRealTimeInterruptEnable_HIGH
             | params.cfg.MultiTapFailRealTimeInterruptEnable_LOW)) )
      {
        gmultitap_failreason_realtime_interrrupt |= gmultitap1_failreason_realtime_interrrupt;
      }
      gmultitap1_failreason_realtime_interrrupt = 0;
    }
    #if CONFIG_LPWG_DUALMULTITAP_FAILREASON_REPORT
      if(gmultitap2_failreason_realtime_interrrupt != 0)
      {
        if( ((1<<(gmultitap2_failreason_realtime_interrrupt-1))
            & (params.cfg.MultiTapFailRealTimeInterruptEnable_HIGH
            | params.cfg.MultiTapFailRealTimeInterruptEnable_LOW)) )
        {
          gmultitap_failreason_realtime_interrrupt |= gmultitap2_failreason_realtime_interrrupt << 4;
        }
        gmultitap2_failreason_realtime_interrrupt = 0;
      }
    #endif
    if(gmultitap_failreason_realtime_interrrupt != 0)
    {
      COMM_updateMultiTapFailReasonRealTimeInterrupt(gmultitap_failreason_realtime_interrrupt);
      gmultitap_failreason_realtime_interrrupt = 0;
    }
  #endif
  return;
}
#endif

//============== multitap ================

static int16 findPrimaryFinger(touchReport_t *report, int16 primaryIdx)
{
  if (primaryIdx >= 0)
  {
    if (report->touch.pos[primaryIdx].classification == hostClassification_none)
      primaryIdx = -1;
  }
  else
  {
    uint16 i;
    reportPos_t *p = &report->touch.pos[0];
    primaryIdx = -1;
    for (i = 0; i < LEN(report->touch.pos); i++)
    {
      if (p->classification != hostClassification_none)
      {
        primaryIdx = i;
        break;
      }
      p++;
    }
  }
  return primaryIdx;
}

#if !CONFIG_HAS_LPWG_MULTITAP
// dist(x0, y0, x1, y1) takes two points specified as 12.4 values in
// mm and returns the distance between them in 0.1-mm units.
static uint16 dist(int16 x0, int16 y0, int16 x1, int16 y1)
{
  float dx = ((float) x1 - x0) / 16.0F;
  float dy = ((float) y1 - y0) / 16.0F;
  float dx2 = dx * dx;
  float dy2 = dy * dy;
  float dist = sqrtf(dx2 + dy2) * 10.0F;
  return (uint16) dist;
}
#endif

// calculate integer distance.
static uint16 dist_int(int16 x0, int16 y0, int16 x1, int16 y1)
{
  float dx, dy, dx2, dy2;

  dx = ((float)x1 - x0);
  dy = ((float)y1 - y0);
  dx2 = dx * dx;
  dy2 = dy * dy;

  return (uint16)sqrtf(dx2 + dy2);
}

//-----------------------------------------------
//
// int16 arctan(int16 y, int16 x)
//
// Description: arctangent approximation
//
// Parameters: y = vertical displacement
//             x = horizontal displacement
//
// Return Values: Signed angle in radians in 8.8 fixed-point format
//
//-----------------------------------------------

static int16 arctan2(int16 y, int16 x)
{
  const int16 coeff_2 = 3*atan_pi/4;
  const int16 coeff_1 = atan_pi/4;

  // CAUTION:
  /*
   * There is a compiler bug while operating on 32bit numbers
   * The code commented below gives unexpected result if used
   */

  // local data
  int16 abs_y, r = 0, angle;
  int32 dvd;
  int32 anglePart0;
  int32 anglePart1;

  // test y, keep pos for calculation
  abs_y = abs16(y);

  // on right side of circle
  if (x>=0) {
    // test for divide by 0 case
    if (y!=0) {
      dvd = ((int32)(x - abs_y) << (int32)8);
      dvd = dvd / (int32)(x + abs_y);
      r = (int16) dvd;
      angle = coeff_1 - (int16)(((int32)coeff_1 * (int32)r)>>8);
    } else {
      angle = 0;
    }
  }
  // on left side of circle
  else {
    // test for divide by 0 case
    if (y!=0) {
      dvd = ((int32)(x + abs_y) << (int32)8);
      dvd = dvd / (int32)(abs_y - x);
      r = (int16) dvd;
      // Calculate angle
      anglePart0 = (((int32)coeff_1 * (int32)r) >> (int32)8);
      anglePart1 = (int32)coeff_2 - anglePart0;
      angle = (int16)anglePart1;
    } else {
      angle = atan_pi;
    }
  }
  // done, return result
  if (y < 0) {
    return(-angle);     // negate if in quad III or IV
  } else {
    return(angle);
  }
}

/*
   estimateMagnitude
   Estimate the vector magnitude without using the square root.
   r = sqrt(x^2 + y^2) ~= a + 3/8*b  (error is -3..7%)
   where a = max(abs(x), abs(y))
         b = min(abs(x), abs(y))
*/
static uint16 estimateMagnitude(int16 x, int16 y)
{
  uint16 a = abs16(x);
  uint16 b = abs16(y);

  // swap
  if(a < b)
  {
    uint16 tmp = a;
    a = b;
    b = tmp;
  }

  // Compute the weighted sum of sorted x and y
  return a + (3 * (uint16) b) / 8;
}

static uint16 estimateMagnitudeNoDeltas(int16 x1, int16 y1, int16 x2, int16 y2)
{
  int16 xVec = x1 - x2;
  int16 yVec = y1 - y2;
  return(estimateMagnitude(xVec, yVec));
}

static uint16 getLPWGSpeedPerFrame(uint16 unitsPerMm, uint16 minLPWGSpeed)
{
  /*
   * minLPWGSpeed is 0.1mm resolution. Now to get speed per frame we use
   * speed = distance/time, In this case time is nothing else but framerate
   */
  uint16 minSpeedPerFrameMm;

  if (state.touchReportRate == 0)
  {
    return 0;
  }

  minSpeedPerFrameMm = (minLPWGSpeed * 10 * 100) / state.touchReportRate;
  // Downscale by 100
  return ((minSpeedPerFrameMm * unitsPerMm + 50) / 100);
}

static uint16 getLPWGMinSpeed(uint16 xunitsPerMm, uint16 yunitsPerMm, uint16 minLPWGSpeed)
{
  uint16 xTmpVec = 0;
  uint16 yTmpVec = 0;

  xTmpVec = getLPWGSpeedPerFrame(xunitsPerMm, minLPWGSpeed);
  yTmpVec = getLPWGSpeedPerFrame(yunitsPerMm, minLPWGSpeed);
  return(estimateMagnitude(xTmpVec, yTmpVec));
}

static uint16 percentDeviation(uint16 actual, uint16 observed)
{
  int16 diff = (int16)actual - (int16)observed;
  if (observed == 0)
  {
    return 0xFFFF;
  }
  return((uint16)((uint32)(abs16(diff) * (uint32)100) / observed));
}

static uint16 vectorDir(int16 xVec, int16 yVec, uint16 orientation)
{
  uint16 currVecDir = DIRECTION_UNKNOWN;

  // This code was written from the point of view of (0,0) at the lower left.
  // If this sensors origin is  UPPER_xx, then flip y.
  if ((orientation == ORIGIN_UPPER_LEFT) || (orientation == ORIGIN_UPPER_RIGHT))
  {
    yVec = -yVec;
  }

  // If this sensors origin is xx_RIGHT, flip x.
  if ((orientation == ORIGIN_UPPER_RIGHT) || (orientation == ORIGIN_LOWER_RIGHT))
  {
    xVec = -xVec;
  }

  if ((xVec == 0) && (yVec == 0)) {
    return(currVecDir);
  }

  if ((xVec >= 0) && (yVec >= 0)) {
    if (xVec <= (yVec >> 1)) {
      currVecDir = DIRECTION_UP;
    } else if (yVec <= (xVec >> 1)) {
      currVecDir = DIRECTION_RIGHT;
    } else {
      currVecDir = DIRECTION_UP_RIGHT;
    }
  }
  if ((xVec >= 0) && (yVec <= 0)) {
    if (xVec <= (-yVec >> 1)) {
      currVecDir = DIRECTION_DOWN;
    } else if (-yVec <= (xVec >> 1)) {
      currVecDir = DIRECTION_RIGHT;
    } else {
      currVecDir = DIRECTION_DOWN_RIGHT;
    }
  }
  if ((xVec <= 0) && (yVec >= 0)) {
    if (-xVec <= (yVec >> 1)) {
      currVecDir = DIRECTION_UP;
    } else if (yVec <= (-xVec >> 1)) {
      currVecDir = DIRECTION_LEFT;
    } else {
      currVecDir = DIRECTION_UP_LEFT;
    }
  }
  if ((xVec <= 0) && (yVec <= 0)) {
    if (-xVec <= (-yVec >> 1)) {
      currVecDir = DIRECTION_DOWN;
    } else if (-yVec <= (-xVec >> 1)) {
      currVecDir = DIRECTION_LEFT;
    } else {
      currVecDir = DIRECTION_DOWN_LEFT;
    }
  }

  return(currVecDir);
}

/*
* Function purpose is to find number of direction changes clockwise or counter clockwise
*/
static void circleDirectionChange(circleDir_s* pCtrl, uint16 currCircleDir)
{
  uint16 oppCircleDir = (pCtrl->prevCircleDir + 4) % 8;

  if ((currCircleDir != pCtrl->prevCircleDir)
      && (pCtrl->prevCircleDir != DIRECTION_UNKNOWN))
  {
    if (oppCircleDir > pCtrl->prevCircleDir)
    {
      if ((currCircleDir < oppCircleDir)
          && (currCircleDir > pCtrl->prevCircleDir))
      {
        pCtrl->circleClkWiseNum++;
      }
      else if (currCircleDir == oppCircleDir)
      {
        //opposite direction
        pCtrl->circleTurnOppositeNum++;
      }
      else
      {
        pCtrl->circleCntClkWiseNum++;
        pCtrl->sumLastWiseClkDist = 0;
      }
    }
    else
    {
      if ((currCircleDir > oppCircleDir) &&
         (currCircleDir < pCtrl->prevCircleDir))
      {
        pCtrl->circleCntClkWiseNum++;
        pCtrl->sumLastWiseClkDist = 0;
      }
      else if (currCircleDir == oppCircleDir)
      {
        //opposite direction
        pCtrl->circleTurnOppositeNum++;
      }
      else
      {
        pCtrl->circleClkWiseNum++;
      }
    }
  }

  pCtrl->prevCircleDir = currCircleDir;
  pCtrl->circularMotion = abs16((int16)pCtrl->circleClkWiseNum - (int16)pCtrl->circleCntClkWiseNum);
}


#if !CONFIG_HAS_LPWG_MULTITAP
void detectDoubleTap(struct touch pos, gestureReport_t *pReport)
{
  uint16 detected = 0;
  doubleTapState_t nextState;
  uint16 inZone;
  uint32 dt;
  uint16 timeout;

  inZone = (pos.x >= params.cfg.doubleTapZoneX0 &&
            pos.x <= params.cfg.doubleTapZoneX1 &&
            pos.y >= params.cfg.doubleTapZoneY0 &&
            pos.y <= params.cfg.doubleTapZoneY1);

  dt = pos.ts - state.dtFirstTapTime;
  timeout = (dt >= (uint32) params.cfg.doubleTapMaxTapTime * 10000);

  // if the seocnd tap is too late, allow it to start a new double-tap
  if (state.dtState == DT_WAIT_FOR_SECOND && timeout)
    state.dtState = DT_INIT;

  nextState = state.dtState;

  switch(state.dtState)
  {
  case DT_INIT:
    if (pos.touchFlag && inZone)
    {
      nextState = DT_FIRST_TAP;
      state.dtFirstTapTx = pos.tx;
      state.dtFirstTapRx = pos.rx;
      state.dtFirstTapTime = pos.ts;
    }
    break;
  case DT_FIRST_TAP:
    if (!pos.touchFlag)
    {
      nextState = DT_WAIT_FOR_SECOND;
    }
    else if (!inZone)
    {
      nextState = DT_WAIT_FOR_LIFT;
    }
    break;
  case DT_WAIT_FOR_SECOND:
    if (pos.touchFlag)
    {
      if (inZone)
      {
        uint16 dr = dist(state.dtFirstTapTx, state.dtFirstTapRx, pos.tx, pos.rx);
        if (dr < params.cfg.doubleTapMaxTapDistance)
          detected = 1;
      }
      nextState = DT_WAIT_FOR_LIFT;
    }
    break;
  case DT_WAIT_FOR_LIFT:
    if (!pos.touchFlag)
    {
      nextState = DT_INIT;
    }
  }
  state.dtState = nextState;

  if (detected)
  {
    pReport->doubleTapDetected = 1;
    pReport->gestureProperty[0] = pos.x;
    pReport->gestureProperty[1] = pos.y;
  }

}
#endif
// This is the routine where directions are checked and made sure that current position is within tolerance window
// Returns true when direction has changed and need to restart swipe detection
// Returns false otherwise
static uint16 swipeDirectionChanged(uint16 negX, uint16 negY, int16 deltaX, int16 deltaY, uint16 xPos ATTR_UNUSED, uint16 yPos ATTR_UNUSED)
{
  uint16 returnVal = true;
  swipeCtrl_s *pSwipeCtrl = &state.swipeCtrl;
  lpwgParams_t *pLpwgCfg = &params.cfg;
  int16 toleranceX_logical = pLpwgCfg->xTolerance;
  int16 toleranceY_logical = pLpwgCfg->yTolerance;

  if ((toleranceX_logical || toleranceY_logical) && pLpwgCfg->directionFilter)
  {
    int16 currDistFromStartX = pSwipeCtrl->xSwipeStart - xPos;
    int16 currDistFromStartY = pSwipeCtrl->ySwipeStart - yPos;

    // If any one condition is satisfied, swipe detection will continue
    if (((deltaX > 0) && (abs16(currDistFromStartY) < toleranceY_logical)) ||
        ((deltaY > 0) && (abs16(currDistFromStartX) < toleranceX_logical)))
    {
      returnVal = false;
    }
  }
  else
  {
    returnVal = ((negX != pSwipeCtrl->xFlickNeg) && ((deltaX/pLpwgCfg->xUnitsPerMm) > 2)) ||
                ((negY != pSwipeCtrl->yFlickNeg) && ((deltaY/pLpwgCfg->yUnitsPerMm) > 2));
  }
  return returnVal;
}

static uint16 checkLPWG_swipe(uint16 lastXpos, uint16 lastYpos)
{
  swipeCtrl_s *pSwipeCtrl = &state.swipeCtrl;
  lpwgParams_t *pLpwgCfg = &params.cfg;
  uint16 tmpX = pLpwgCfg->xUnitsPerMm * pLpwgCfg->SwipeMinimumDistance;
  uint16 tmpY = pLpwgCfg->yUnitsPerMm * pLpwgCfg->SwipeMinimumDistance;
  uint16 estimateDistTravell;
  int16 deltaX, deltaY;

  // Now is the time to check for total distance covered
  deltaX = lastXpos - pSwipeCtrl->xSwipeStart;
  deltaY = lastYpos - pSwipeCtrl->ySwipeStart;
  estimateDistTravell = estimateMagnitude(deltaX, deltaY);

  if (estimateDistTravell < pSwipeCtrl->swipeSumSideDist)
  {
    // Is distance condition met?
    if (percentDeviation(estimateDistTravell, pSwipeCtrl->swipeSumSideDist) > pLpwgCfg->swipeCurvature) // Is swipe is strait enough?
    {
      pSwipeCtrl->swipeSideHasCurve++;
    }
  }

  if (((uint16)abs16(deltaX) >= tmpX) || ((uint16)abs16(deltaY) >= tmpY))
  {
    if ((pSwipeCtrl->SwipeEpoch > 0) && (!pSwipeCtrl->swipeSideHasCurve) && (!pSwipeCtrl->firstSwipeDetected))
    {
      return 1;
    }
  }

  return 0;
}

/*
*   static function for swipe detection.
*/
uint16 stillInZone;
void detectSwipe(struct touch pos, gestureReport_t *pReport)
{
  int16 deltaX, deltaY;
  uint16 negX = false;
  uint16 negY = false;
  uint16 xPos = pos.x;
  uint16 yPos = pos.y;
  uint16 swipeDetected = 0;
  swipeCtrl_s *pSwipeCtrl = &state.swipeCtrl;
  lpwgParams_t *pLpwgCfg = &params.cfg;

  deltaX = (int16)xPos - (int16)state.lastSeenPrimaryPos.x;
  deltaY = (int16)yPos - (int16)state.lastSeenPrimaryPos.y;

  if (deltaX < 0)
  {
    negX = DIRECTION_NEG;
    deltaX = -deltaX;
  }
  if (deltaY < 0)
  {
    negY = DIRECTION_NEG;
    deltaY = -deltaY;
  }

  if (pos.touchFlag) // currently there is finger touching
  {
    uint16 currMinSpeedPerFrame = estimateMagnitude(deltaX, deltaY);
    uint16 inZone = (xPos >= params.cfg.swipeZoneX0 &&
                     xPos <= params.cfg.swipeZoneX1 &&
                     yPos >= params.cfg.swipeZoneY0 &&
                     yPos <= params.cfg.swipeZoneY1);

    if (inZone)
    {
      stillInZone = 1;
    }
    else
    {
      stillInZone = 0;
    }

    // sum distance travelled before speed drop
    pSwipeCtrl->swipeSumSideDist += currMinSpeedPerFrame;
    // First touch for swipe
    if ((state.prevTouchFlag != 1) || (pSwipeCtrl->State == STATE_RESTART_SWIPE_DETECTION))
    {
      // Either this is the starting point OR min swipe speed was not found OR drumming was found
      // OR swipe was detected in previous frame and now is the time to restart the detection
      // Restart the detection!
      memset(pSwipeCtrl, 0, sizeof(swipeCtrl_s));
      pSwipeCtrl->xSwipeStart = xPos;
      pSwipeCtrl->ySwipeStart = yPos;
      pSwipeCtrl->State = STATE_CAPTURE_DIRECTION;
    }
    else if (currMinSpeedPerFrame > getLPWGMinSpeed(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm, pLpwgCfg->MinimumSwipeSpeed))
    {
      // next touches check if speed condition is met
      if (pSwipeCtrl->State == STATE_CAPTURE_DIRECTION)
      {
        // 2 data frames collected, direction should be noted
        // Min speed criterion satisfied
        pSwipeCtrl->xFlickNeg = negX;
        pSwipeCtrl->yFlickNeg = negY;
        pSwipeCtrl->State = STATE_CONTINUE_DETECTION;
      }
      else if (swipeDirectionChanged(negX, negY, deltaX, deltaY, xPos, yPos))
      {
        // if direction changed, block this detection until life cycle ends.
        pSwipeCtrl->firstSwipeDetected = 1;
      }
      else
      {
        // avoid drumming
        if (pSwipeCtrl->SwipeEpoch < 3)
        {
          pSwipeCtrl->SwipeEpoch++;
        }
      }
    }

    // A finger presents in this frame. If it was there in previous frame, handle swipe with no lift
    if (pLpwgCfg->swipeNoLift)
    {
      if ((state.prevTouchFlag == 1) && (pSwipeCtrl->State == STATE_CONTINUE_DETECTION))
      {
        swipeDetected = checkLPWG_swipe(xPos, yPos);

        /* only reset state when detection success because when lift is not required,
              * the initial points might not have enough speed to pass condition.
              * If reset at once then swipes will never get detected.
        */
        if (swipeDetected)
        {
          pSwipeCtrl->State = STATE_RESTART_SWIPE_DETECTION;
        }
      }
    }
  } // end of if (currFinger)
  else if (state.prevTouchFlag == 1)
  {
    // no finger at this frame, one finger in previous frame, meaning finger lift, may result in swipe
    if (!pLpwgCfg->swipeNoLift && stillInZone)
    {
      stillInZone = 0;
      swipeDetected = checkLPWG_swipe(state.lastSeenPrimaryPos.x, state.lastSeenPrimaryPos.y);
      // If no finger present on the sensor, set state to STATE_RESTART_SWIPE_DETECTION
      pSwipeCtrl->State = STATE_RESTART_SWIPE_DETECTION;
    }
  }

  // assign results
  if (swipeDetected)
  {
    deltaX = state.lastSeenPrimaryPos.x - pSwipeCtrl->xSwipeStart;
    deltaY = state.lastSeenPrimaryPos.y - pSwipeCtrl->ySwipeStart;
    // reject directions
    if (pLpwgCfg->directionFilter)
    {
      if (abs16(deltaX)> abs16(deltaY))
      {
        if((pLpwgCfg->PositiveX && (deltaX > 0)) ||
           (pLpwgCfg->NegativeX && (deltaX < 0)))
        {
          pReport->swipeDetected = 1;
          pReport->gestureProperty[0] = deltaX;
          pReport->gestureProperty[1] = deltaY;
          pReport->gestureProperty[2] = (deltaX > 0) ? LPWG_SWIPE_POS_X : LPWG_SWIPE_NEG_X;
        }
      }
      else
      {
        if((pLpwgCfg->PositiveY && (deltaY > 0)) ||
           (pLpwgCfg->NegativeY && (deltaY < 0)))
        {
          pReport->swipeDetected = 1;
          pReport->gestureProperty[0] = deltaX;
          pReport->gestureProperty[1] = deltaY;
          pReport->gestureProperty[2] = (deltaY > 0) ? LPWG_SWIPE_POS_Y : LPWG_SWIPE_NEG_Y;
        }
      }
    }
    else
    {
      pReport->swipeDetected = 1;
      pReport->gestureProperty[0] = deltaX;
      pReport->gestureProperty[1] = deltaY;
      if (abs16(deltaX)> abs16(deltaY))
      {
        pReport->gestureProperty[2] = (deltaX > 0) ? LPWG_SWIPE_POS_X : LPWG_SWIPE_NEG_X;
      }
      else
      {
        pReport->gestureProperty[2] = (deltaY > 0) ? LPWG_SWIPE_POS_Y : LPWG_SWIPE_NEG_Y;
      }
    }
  }
}

static void circleInit(uint16 xPos, uint16 yPos)
{
  lpwgParams_t *pLpwgCfg = &params.cfg;
  circleCtrl_s *pCircleCtrl = &state.circleCtrl;

  memset(pCircleCtrl, 0, sizeof(circleCtrl_s));

  pCircleCtrl->xLastSeenNmm=xPos;
  pCircleCtrl->yLastSeenNmm=yPos;
  pCircleCtrl->dirCtrl.prevCircleDir = DIRECTION_UNKNOWN;
  pCircleCtrl->xPos[0] = xPos;
  pCircleCtrl->yPos[0] = yPos;
  pCircleCtrl->minSpeedPerFrame = getLPWGMinSpeed(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm, pLpwgCfg->MinimumCircleSpeed);
  pCircleCtrl->State = LPWG_STATE_START_TRACKING;
}

/*
  * Function below handles determination of 'o' or 'circle' wakeup gesture
  */
static uint16 checkLPWG_circle (void)
{
  lpwgParams_t *pLpwgCfg = &params.cfg;
  circleCtrl_s *pCircleCtrl = &state.circleCtrl;
  circleDir_s* pdirCtrl = &(pCircleCtrl->dirCtrl);
  uint16 UnitsPerMm = estimateMagnitude(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm);

  /* this condition checks direction change based on speed.
   *   it needs to be 1 for 'o' or 'circle'
   */
  if ((0==pdirCtrl->circleTurnOppositeNum) &&
     (pdirCtrl->circularMotion >= 4) &&
     (pdirCtrl->circularMotion <= 9) && // this condition makes sure we are drawing only one circle at a time and allows shaky finger
     ((pdirCtrl->circleCntClkWiseNum < 2) || (pdirCtrl->circleClkWiseNum < 2)) &&
     (pCircleCtrl->mightBe == 1) && // this condition makes sure our start to end point is under some threshold
     (pCircleCtrl->sumTotalDist >= pLpwgCfg->circleMaxStartToEndDist*UnitsPerMm*4)) // this condition define how small a circle can be
  {
    return(1);
  }

  return(0);
}

void detectCircle(struct touch pos, uint16 frameRate, gestureReport_t *pReport)
{
  uint16 xPos = pos.x;
  uint16 yPos = pos.y;
  circleCtrl_s *pCircleCtrl = &state.circleCtrl;
  circleDir_s* pdirCtrl = &(pCircleCtrl->dirCtrl);
  lpwgParams_t *pLpwgCfg = &params.cfg;
  uint16 UnitsPerMm = estimateMagnitude(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm);

  if (pos.touchFlag)
  {
    if ((state.prevTouchFlag != 1) || (pCircleCtrl->State == LPWG_STATE_INIT))
    {
      circleInit(xPos, yPos);
    }
    else if (pCircleCtrl->State == LPWG_STATE_START_TRACKING)
    {
      uint16 currSpeedPerFrame = estimateMagnitudeNoDeltas(state.lastSeenPrimaryPos.x, state.lastSeenPrimaryPos.y, xPos, yPos);
      uint16 distStartToCurrPos = estimateMagnitudeNoDeltas(pCircleCtrl->xPos[0], pCircleCtrl->yPos[0], xPos, yPos);

      pCircleCtrl->minSpeedPerFrame = getLPWGMinSpeed(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm, pLpwgCfg->MinimumCircleSpeed);
      pdirCtrl->sumLastWiseClkDist += currSpeedPerFrame;
      //sum distance travelled from starting pos
      pCircleCtrl->sumTotalDist += currSpeedPerFrame;

      if (currSpeedPerFrame > pCircleCtrl->minSpeedPerFrame)
      {
        uint16 clkWiseDistance;

        //report speed of drawing gesture
        pCircleCtrl->reportMinSpeedPerFrameMm = currSpeedPerFrame;
        clkWiseDistance = estimateMagnitudeNoDeltas(pCircleCtrl->xLastSeenNmm, pCircleCtrl->yLastSeenNmm, xPos, yPos);
        if(clkWiseDistance > 3*UnitsPerMm)
        {
          circleDirectionChange(pdirCtrl, vectorDir((xPos - pCircleCtrl->xLastSeenNmm), (yPos - pCircleCtrl->yLastSeenNmm), 0));
          pCircleCtrl->xLastSeenNmm = xPos;
          pCircleCtrl->yLastSeenNmm = yPos;
        }
      }

      /*
         * If we are on Downhill then its possible that we are approaching starting position
         * and circle completion might be a possibility. We start tracking distance between
         * start position to current position and if its under thershold then we say the gesture
         * might be a circle
         */
      if (pdirCtrl->circularMotion >= 3)
      {
         if (distStartToCurrPos <= pLpwgCfg->circleMaxStartToEndDist*UnitsPerMm)
        {
          pCircleCtrl->mightBe = 1;
        }
      }
    }
  }
  else if (state.prevTouchFlag == 1)
  {
    // reset state machine regardless of detection result.
    pCircleCtrl->State = LPWG_STATE_INIT;

    if ((pdirCtrl->circularMotion > 11) || (pdirCtrl->circleCntClkWiseNum > 11) || (pdirCtrl->circleClkWiseNum > 11))
    {
      return;
    }

    if (checkLPWG_circle())
    {
      pReport->circleDetected = 1;
      pReport->gestureProperty[0] = (pCircleCtrl->reportMinSpeedPerFrameMm * frameRate)/(10*UnitsPerMm);
    }
  }
}

/*
 * Following function handles corner case where if the angle between two sides
 * is less than a threshold then we reject that triangle
 */
static uint16 hasTriangleCornerCase (void)
{
  triangleCtrl_s *pTriCtrl = &state.triangleCtrl;
  lpwgParams_t *pLpwgCfg = &params.cfg;
  uint16 i, j;

  // check if its rectangle or all angles are right
  if (pTriCtrl->triangleNotAlongAxis == 1) {

    int16 triangleAngle[3];
    int16 xDeltaSide;
    int16 yDeltaSide;
    int16 angle[2];
    int16 triangleAngleThreshold = ((uint32)pLpwgCfg->triangleMinAngle * atan_pi) / 180;

    for (i = 0; i < 2; i++)
    {
      for (j = 0; j < 2; j++)
      {
        xDeltaSide = pTriCtrl->xPos[i+1] - pTriCtrl->xPos[((2*j)+i)];
        yDeltaSide = pTriCtrl->yPos[i+1] - pTriCtrl->yPos[((2*j)+i)];

        angle[j] = arctan2(yDeltaSide, xDeltaSide);

        // convert angle range from -pi to pi to 0 to 2*pi
        if (angle[j] < 0)
        {
          angle[j] += (atan_pi << 1);
        }
      }
      triangleAngle[i+1] = abs16(angle[0] - angle[1]);

      if ((triangleAngle[i+1] <= triangleAngleThreshold))
      {
        return(1);
      }
    }

    triangleAngle[0] = abs16(atan_pi - (triangleAngle[1] + triangleAngle[2]));
    if (triangleAngle[0] <= triangleAngleThreshold)
    {
      return(1);
    }
    return (0);
  }
  return(1);
}

static void triangleInit(uint16 xPos, uint16 yPos)
{
  triangleCtrl_s *pTriCtrl = &state.triangleCtrl;
  lpwgParams_t *pLpwgCfg = &params.cfg;

  memset(pTriCtrl, 0, sizeof(triangleCtrl_s));

  pTriCtrl->maxSpeedPerFrame = 1;
  pTriCtrl->xPos[0] = xPos;
  pTriCtrl->yPos[0] = yPos;
  pTriCtrl->minSpeedPerFrame = getLPWGMinSpeed(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm, pLpwgCfg->MinimumTriangleSpeed);
  pTriCtrl->State = LPWG_STATE_START_TRACKING;
}

void detectTriangle(struct touch pos, uint16 frameRate, gestureReport_t *pReport)
{
  uint16 xPos = pos.x;
  uint16 yPos = pos.y;
  triangleCtrl_s *pTriCtrl = &state.triangleCtrl;
  lpwgParams_t *pLpwgCfg = &params.cfg;
  int16 deltaX, deltaY;
  uint16 negX = false;
  uint16 negY = false;
  uint16 UnitsPerMm = estimateMagnitude(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm);

  if (pos.touchFlag)
  {
    if ((state.prevTouchFlag != 1) || (pTriCtrl->State == LPWG_STATE_INIT))
    {
      triangleInit(xPos, yPos);
    }
    else if (pTriCtrl->State == LPWG_STATE_START_TRACKING)
    {
      uint16 currSpeedPerFrame;

      deltaX = xPos - state.lastSeenPrimaryPos.x;
      deltaY = yPos - state.lastSeenPrimaryPos.y;

      if (deltaX < 0)
      {
        negX = DIRECTION_NEG;
        deltaX = -deltaX;
      }
      if (deltaY < 0)
      {
        negY = DIRECTION_NEG;
        deltaY = -deltaY;
      }
      // Calculate distance between previous position and current position
      currSpeedPerFrame = estimateMagnitude(deltaX, deltaY);
      // sum distance travelled before speed drop
      pTriCtrl->sumSideDist += currSpeedPerFrame;
      //sum distance travelled from starting pos
      pTriCtrl->sumTotalDist += currSpeedPerFrame;

      // Check for minimum speed of gesture
      if (currSpeedPerFrame > pTriCtrl->minSpeedPerFrame)
      {
        if (pTriCtrl->maxSpeedPerFrame == 1)
        {
          if ((abs16((int16)xPos - (int16)pTriCtrl->xPos[pTriCtrl->mightBe]) > ((int16)pLpwgCfg->xUnitsPerMm << 1)) ||
              (abs16((int16)yPos - (int16)pTriCtrl->yPos[pTriCtrl->mightBe]) > ((int16)pLpwgCfg->yUnitsPerMm << 1)))
          {
            pTriCtrl->maxSpeedPerFrame = currSpeedPerFrame;
            if (pTriCtrl->mightBe == 0)
            {
              pTriCtrl->xTrianglePrevDir = negX;
              pTriCtrl->yTrianglePrevDir = negY;
            }
          }
        }
        else
        {
          if ((percentDeviation(pTriCtrl->maxSpeedPerFrame, currSpeedPerFrame) > 20) &&
              (pTriCtrl->maxSpeedPerFrame > currSpeedPerFrame))
          {
            pTriCtrl->maxSpeedPerFrame = currSpeedPerFrame;
          }
        }

        //report speed of drawing gesture
        pTriCtrl->reportMinSpeedPerFrameMm = currSpeedPerFrame;

        // check if Direction change happened based on delatX and deltaY
        {
          if (pTriCtrl->triangleNotAlongAxis == 0)
          {
            if ((deltaX > (deltaY >> 2)) && (deltaY > (deltaX >> 2)))
            {
              pTriCtrl->triangleNotAlongAxis = 1;
            }
          }
          if ((((negX != pTriCtrl->xTrianglePrevDir) &&
                ((uint16)abs16((int16)xPos - (int16)pTriCtrl->xPos[pTriCtrl->mightBe]) > 3*pLpwgCfg->xUnitsPerMm)) ||
               ((negY != pTriCtrl->yTrianglePrevDir) &&
                ((uint16)abs16((int16)yPos - (int16)pTriCtrl->yPos[pTriCtrl->mightBe]) > 3*pLpwgCfg->yUnitsPerMm))) &&
              (pTriCtrl->maxSpeedPerFrame > 1))
          {
            pTriCtrl->xTrianglePrevDir = negX;
            pTriCtrl->yTrianglePrevDir = negY;
            pTriCtrl->mightBe++;
            pTriCtrl->xPos[pTriCtrl->mightBe] = xPos;
            pTriCtrl->yPos[pTriCtrl->mightBe] = yPos;
            pTriCtrl->sumSideDist = 0;
            pTriCtrl->maxSpeedPerFrame = 1;
          }
        }
      }
      else if (currSpeedPerFrame < (pTriCtrl->maxSpeedPerFrame >> 1))
      {
        /*
             * Check if speed drops below 1/2 * Highest speed;
             * if it does then we are around a corner and there is a direction change happening
             * OR gesture is completed
             */
        // Check if the side had curve or it was a straight line
        if (pTriCtrl->mightBe < 3)
        {
          uint16 expectedDistTraveled = estimateMagnitudeNoDeltas(pTriCtrl->xPos[pTriCtrl->mightBe]
                                                                  , pTriCtrl->yPos[pTriCtrl->mightBe]
                                                                  , xPos
                                                                  , yPos);

          if (percentDeviation(expectedDistTraveled, pTriCtrl->sumSideDist) > 20)
          {
            pTriCtrl->sideHasCurve++;
          }
        }
      }

      // If there are more than 3 direction changes no need of tracking this gesture further
      if (pTriCtrl->mightBe > 2)
      {
        pTriCtrl->State = LPWG_STATE_STOP_TRACKING;
      }

      /*
          * If we have completed 2 direction changes and we are on third side then
          * its time to see if we are approaching start position, the code below
          * tracks the same
          */
      else if (pTriCtrl->mightBe == 2)
      {
        uint16 triangleDistStartToEndPos = estimateMagnitudeNoDeltas(pTriCtrl->xPos[0]
                                                                     , pTriCtrl->yPos[0]
                                                                     , xPos
                                                                     , yPos);

        if (triangleDistStartToEndPos <= pLpwgCfg->triangleMaxStartToEndDist*UnitsPerMm)
        {
          pTriCtrl->triangleStartToEnd = 1;
        }
      }
    }
  }
  else if (state.prevTouchFlag == 1)
  {
    pTriCtrl->xPos[3] = state.lastSeenPrimaryPos.x;
    pTriCtrl->yPos[3] = state.lastSeenPrimaryPos.y;
        // There should be exact 3 direction changes for triangle
    if ((pTriCtrl->mightBe == 2) &&
        // this condition makes sure sides of triangle are straight under 20% hysteresis
        (pTriCtrl->sideHasCurve <= 1) &&
        // this condition define how small a traingle can be
        (pTriCtrl->triangleStartToEnd == 1) &&
        // this function takes care of angles and other corner cases
        (hasTriangleCornerCase() == 0))
    {
      pReport->triangleDetected = 1;
      pReport->gestureProperty[0] = (pTriCtrl->reportMinSpeedPerFrameMm * frameRate)/(10*UnitsPerMm);
    }
    pTriCtrl->State = LPWG_STATE_INIT;
  }
}

static void veeInit(uint16 xPos, uint16 yPos)
{
  veeCtrl_s *pVeeCtrl = &state.veeCtrl;
  lpwgParams_t *pLpwgCfg = &params.cfg;

  memset(pVeeCtrl, 0, sizeof(veeCtrl_s));

  pVeeCtrl->maxSpeedPerFrame = 1;
  pVeeCtrl->xPos[0] = xPos;
  pVeeCtrl->yPos[0] = yPos;
  pVeeCtrl->minSpeedPerFrame = getLPWGMinSpeed(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm, pLpwgCfg->MinimumVeeSpeed);
  pVeeCtrl->State = LPWG_STATE_START_TRACKING;
}

/*
* Function below handles corner case of finding direction of Vee wakeup gesture
* It also takes care if the angle between Vee is too large
*/
static uint16 hasVeeCornerCase (void)
{
  veeCtrl_s *pVeeCtrl = &state.veeCtrl;
  lpwgParams_t *pLpwgCfg = &params.cfg;

  if (pVeeCtrl->veeNotAlongAxis == 1)
  {
    // The code below decides the direction of Vee: UP, DOWN, RIGHT, LEFT
    if ((pVeeCtrl->yPos[0] > pVeeCtrl->yPos[1]) && (pVeeCtrl->yPos[1] < pVeeCtrl->yPos[2]))
    {
      if (pLpwgCfg->veeDirectionEnabled & UP_VEE_ENABLE)
      {
        return (UP_VEE_DETECTED);
      }
    }
    if ((pVeeCtrl->yPos[0] < pVeeCtrl->yPos[1]) && (pVeeCtrl->yPos[1] > pVeeCtrl->yPos[2]) &&
       ((uint16)abs16((int16)pVeeCtrl->yPos[1] - (int16)pVeeCtrl->yPos[2]) >= (pLpwgCfg->yUnitsPerMm<< 1)))
    {
      if (pLpwgCfg->veeDirectionEnabled & DOWN_VEE_ENABLE) {
        return (DOWN_VEE_DETECTED);
      }
    }
    if ((pVeeCtrl->xPos[0] > pVeeCtrl->xPos[1]) && (pVeeCtrl->xPos[1] < pVeeCtrl->xPos[2]))
    {
      if (pLpwgCfg->veeDirectionEnabled & LEFT_VEE_ENABLE)
      {
        return (LEFT_VEE_DETECTED);
      }
    }
    if ((pVeeCtrl->xPos[0] < pVeeCtrl->xPos[1]) && (pVeeCtrl->xPos[1] > pVeeCtrl->xPos[2]))
    {
      if (pLpwgCfg->veeDirectionEnabled & RIGHT_VEE_ENABLE)
      {
        return (RIGHT_VEE_DETECTED);
      }
    }
  }

  return(0);
}

/* ------------------------------------------------------
*  Function: triangleHeights()
*  Input: Xpos[] and Ypos[] containing 3 coordinate data pair, in units of host coordinates.
*  Output: length of triangle heights, in units of host coordinates.
*
*                        x (x0, y0)    - Assume a triangle formed by (x0, y0)
*                      / |                  (x1, y1), (x2, y2).
*                     /  |L0            - L0: ax + b = y represents the line formed
*                    /   |                  by (x0, y0) (x2, y2).
*      (x1, y1) x--|-----       - L1: cx +d = y represents the line perpendicular
*                    \   |     L1          to L0 and pass (x1, y1).
*                     \  |                - We are trying to find the intersection (ansX, ansY)
*                      \ |                   of L0 & L1, and calculate the distance of (x1, y1)
*                       x (x2, y2)        and (ansX, ansY).
*
*-------------------------------------------------------*/
static uint16 triangleHeights(uint16* pXpos, uint16* pYpos)
{
  int32 a, b, d;
  int16 x0 = pXpos[0];
  int16 x1 = pXpos[1];
  int16 x2 = pXpos[2];
  int16 y0 = pYpos[0];
  int16 y1 = pYpos[1];
  int16 y2 = pYpos[2];
  int16 ansX, ansY;

  if ((x1 == 0 && y1 == 0) || (x0 == x2 && y0 == y2))
  {
    // if (x1, y1) == (0, 0), or (x0, y0) == (x2, y2)
    // this is not a valid triangle.
    return 0;
  }

  if (abs16(y2 - y0) < abs16(x2 - x0))
  {
    /* if y intercept is less than x intercept, rotate coordinates by
      *  90 degree so that "a" won't be zero. Since we didn't use
      *  fixed-point to record fraction in this function.
      */
    swap(x0, y0)
    swap(x1, y1)
    swap(x2, y2)
  }

  if (x2 != x0)
  {
    a = (y2 - y0)/(x2 - x0);
    b = y0 - (int32)a*x0;

    //c = -1/a;
    d = y1 + x1/a;

    ansX = (int16)(((int32)(d - b)*a)/(1 + (int32)a*a));
    ansY = (int16)(a*ansX + b);
  }
  else
  {
    // if x2 == x0, (x0, y0), (x2, y2) forms a vertical line.
    ansX = x0;
    ansY = y1;
  }

  return dist_int(ansX, ansY, x1, y1);
}

void detectVee(struct touch pos, uint16 frameRate, gestureReport_t *pReport)
{
  uint16 negX = false;
  uint16 negY = false;
  uint16 xPos = pos.x;
  uint16 yPos = pos.y;
  veeCtrl_s *pVeeCtrl = &state.veeCtrl;
  lpwgParams_t *pLpwgCfg = &params.cfg;

  if (pos.touchFlag)
  {
    if ((state.prevTouchFlag != 1) || (pVeeCtrl->State == LPWG_STATE_INIT))
    {
      veeInit(xPos, yPos);
    }
    else if (pVeeCtrl->State == LPWG_STATE_START_TRACKING)
    {
      int16 deltaX, deltaY;
      uint16 currSpeedPerFrame;

      deltaX = xPos - state.lastSeenPrimaryPos.x;
      deltaY = yPos - state.lastSeenPrimaryPos.y;

      if (deltaX < 0)
      {
        negX = DIRECTION_NEG;
        deltaX = -deltaX;
      }
      if (deltaY < 0)
      {
        negY = DIRECTION_NEG;
        deltaY = -deltaY;
      }

      // Calculate distance between previous position and current position
      currSpeedPerFrame = dist_int(xPos, yPos, state.lastSeenPrimaryPos.x, state.lastSeenPrimaryPos.y);
      //sum distance travelled from starting pos
      pVeeCtrl->sumTotalDist += currSpeedPerFrame;

      // Check for minimum speed of gesture
      if (currSpeedPerFrame > pVeeCtrl->minSpeedPerFrame)
      {
        if (pVeeCtrl->maxSpeedPerFrame == 1)
        {
          if ((abs16((int16)xPos - (int16)pVeeCtrl->xPos[pVeeCtrl->mightBe]) > (3 * (int16)pLpwgCfg->xUnitsPerMm)) ||
              (abs16((int16)yPos - (int16)pVeeCtrl->yPos[pVeeCtrl->mightBe]) > (3 * (int16)pLpwgCfg->yUnitsPerMm)))
          {
            pVeeCtrl->maxSpeedPerFrame = currSpeedPerFrame;
            if (pVeeCtrl->mightBe == 0)
            {
              pVeeCtrl->xVeePrevDir = negX;
              pVeeCtrl->yVeePrevDir = negY;
            }
          }
        }
        else
        {
          if ((percentDeviation(pVeeCtrl->maxSpeedPerFrame, currSpeedPerFrame) > 20) &&
              (pVeeCtrl->maxSpeedPerFrame > currSpeedPerFrame))
          {
            pVeeCtrl->maxSpeedPerFrame = currSpeedPerFrame;
          }
        }
        //report speed of drawing gesture
        if (currSpeedPerFrame < pVeeCtrl->reportMinSpeedPerFrameMm)
        {
          pVeeCtrl->reportMinSpeedPerFrameMm = currSpeedPerFrame;
        }

        // check if Direction change happened based on delatX and deltaY
        {
          // We need atleast one direction in 45 degrees
          if (pVeeCtrl->veeNotAlongAxis == 0)
          {
            if ((deltaX > (deltaY >> 2)) && (deltaY > (deltaX >> 2)))
            {
              pVeeCtrl->veeNotAlongAxis = 1;
            }
          }

          if ((negX != pVeeCtrl->xVeePrevDir) || (negY != pVeeCtrl->yVeePrevDir))
          {
            if (((abs16((int16)xPos - (int16)pVeeCtrl->xPos[pVeeCtrl->mightBe])/pLpwgCfg->xUnitsPerMm) >= pLpwgCfg->veeAngleTolerance) &&
                ((abs16((int16)yPos - (int16)pVeeCtrl->yPos[pVeeCtrl->mightBe])/pLpwgCfg->yUnitsPerMm) >= pLpwgCfg->veeAngleTolerance) &&
                (pVeeCtrl->maxSpeedPerFrame > 1))
            {
              pVeeCtrl->xVeePrevDir = negX;
              pVeeCtrl->yVeePrevDir = negY;
              pVeeCtrl->xPos[1] = xPos;
              pVeeCtrl->yPos[1] = yPos;
              pVeeCtrl->mightBe++;
              pVeeCtrl->maxSpeedPerFrame = 1;
            }
          }
        }
      }

      // If we ecounter more than 2 direction changes then we are looking at something
      // other than wakeup gesture vee do stop the statemachine
      if (pVeeCtrl->mightBe > 1)
      {
        pVeeCtrl->State = LPWG_STATE_STOP_TRACKING;
      }
    }
  }
  else if (state.prevTouchFlag == 1)
  {
    uint16 veeDistStartToEndPos, veeDistSide1, veeDistSide2, veeDepth;
    uint16 UnitsPerMm = dist_int(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm, 0, 0);

    pVeeCtrl->xPos[2] = state.lastSeenPrimaryPos.x;
    pVeeCtrl->yPos[2] = state.lastSeenPrimaryPos.y;

    veeDistStartToEndPos = dist_int(pVeeCtrl->xPos[0], pVeeCtrl->yPos[0],
                                                     pVeeCtrl->xPos[2], pVeeCtrl->yPos[2]);
    veeDistSide1 = dist_int(pVeeCtrl->xPos[0], pVeeCtrl->yPos[0],
                                                     pVeeCtrl->xPos[1], pVeeCtrl->yPos[1]);
    veeDistSide2 = dist_int(pVeeCtrl->xPos[1], pVeeCtrl->yPos[1],
                                                     pVeeCtrl->xPos[2], pVeeCtrl->yPos[2]);
    if ((pVeeCtrl->sumTotalDist == 0) ||
        (percentDeviation(veeDistSide1 + veeDistSide2, pVeeCtrl->sumTotalDist) > 30))
    {
      pVeeCtrl->sideHasCurve = 1;
    }

    veeDepth = triangleHeights(&pVeeCtrl->xPos[0], &pVeeCtrl->yPos[0]);

        // There should be exact 1 direction changes for vee
    if ((pVeeCtrl->mightBe == 1) &&
        // this condition makes sure our start to end point is under some threshold
        (veeDistStartToEndPos >= pLpwgCfg->veeMinStartToEndDistance*UnitsPerMm) &&
        // this condition makes sure sides of vee are straight and under 20% hysteresis
        (pVeeCtrl->sideHasCurve == 0) &&
        // Check if the depth of vee are long enough to make a vee.
        ((veeDepth) > pLpwgCfg->veeMinStartToEndDistance*UnitsPerMm/2))
    {
      uint16 veeDirection = hasVeeCornerCase();

      if (veeDirection != 0)
      {
        pReport->veeDetected = 1;
        pReport->gestureProperty[0] = (pVeeCtrl->reportMinSpeedPerFrameMm*frameRate)/10;
        pReport->gestureProperty[1] = veeDirection;
      }
    }
    // reset state machine.
    pVeeCtrl->State = LPWG_STATE_INIT;
  }
}

static void unicodeInit(unicodeCtrl_s *pUnicodeCtrl, uint16 xPos, uint16 yPos)
{
  memset(pUnicodeCtrl, 0, sizeof(unicodeCtrl_s));

  pUnicodeCtrl->xLastSeenNmm=xPos;
  pUnicodeCtrl->yLastSeenNmm=yPos;
  pUnicodeCtrl->maxSpeedPerFrame = 1;
  pUnicodeCtrl->xPos[0] = xPos;
  pUnicodeCtrl->yPos[0] = yPos;
  pUnicodeCtrl->State = LPWG_STATE_START_TRACKING;

  pUnicodeCtrl->LastDistancePosx = xPos;
  pUnicodeCtrl->LastDistancePosy = yPos;
  pUnicodeCtrl->ContactPoint[0]= 0xFFFF;
  pUnicodeCtrl->ContactPoint[7]= 0xFFFF;
  pUnicodeCtrl->unicodeXPrevPosBfr1Mm = xPos;
  pUnicodeCtrl->unicodeYPrevPosBfr1Mm = yPos;
  pUnicodeCtrl->xLastSeenNmm = xPos;
  pUnicodeCtrl->yLastSeenNmm = yPos;
}

static uint16 checkLPWG_Unicode_z (unicodeCtrl_s *pUnicodeCtrl, lpwgParams_t *pLpwgCfg, uint16 UnitsPerMm)
{
  circleDir_s *pDirCtrl = &(pUnicodeCtrl->dirCtrl);
  uint16 distStartToEndPos_z = estimateMagnitudeNoDeltas(pUnicodeCtrl->xPos[0], pUnicodeCtrl->yPos[0],
                                                        state.lastSeenPrimaryPos.x, state.lastSeenPrimaryPos.y);
      // this condition makes sure we are drawing only one 'c' at a time and allows shaky finger
  if (((pDirCtrl->circleCntClkWiseNum <= 4) && (pDirCtrl->circleCntClkWiseNum >=1)&&(pDirCtrl->circleClkWiseNum <= 4)&&(pDirCtrl->circleClkWiseNum >=1)) &&
      // this condition makes sure our start to end point is above some threshold
      (distStartToEndPos_z >= pLpwgCfg->unicodeMaxStartToEndDist*UnitsPerMm))
  {
    if (pUnicodeCtrl->mightBe_z == 2)
    {
      // this condition helps from false triggering of 'c' when 's' or '8' like shapes are drawn
      if (pDirCtrl->circularMotion <= 3)
      {
        if (pUnicodeCtrl->LastDistanceDir == DIRECTION_RIGHT)
        {
          return (1);
        }
      }
    }
  }
  return(0);
}

static uint16 checkLPWG_Unicode_s (unicodeCtrl_s *pUnicodeCtrl, lpwgParams_t *pLpwgCfg, uint16 UnitsPerMm)
{
  circleDir_s *pDirCtrl = &(pUnicodeCtrl->dirCtrl);

  // prerequisite is it should be like 'c' pattern.
  if (pUnicodeCtrl->mightBe_c != 1)
  {
    return(0);
  }

  if ((pDirCtrl->circularMotion <= 3) &&     // counter-clockwise travel aprox == clockwise travel
      (pDirCtrl->circleCntClkWiseNum >=2) && (pDirCtrl->circleCntClkWiseNum <=8) &&  // counter-clockwise travel window
      (pDirCtrl->circleClkWiseNum >=2) && (pDirCtrl->circleClkWiseNum <=8))           // clockwise travel window
  {
    uint16 vecDir2 = vectorDir((state.lastSeenPrimaryPos.x - pUnicodeCtrl->lpwgSstartCapLeftDirX)
                               , (state.lastSeenPrimaryPos.y - pUnicodeCtrl->lpwgSstartCapLeftDirY)
                               , pLpwgCfg->unicodeOrientation);
    uint16 distStartToEndPos_s = estimateMagnitudeNoDeltas(pUnicodeCtrl->xPos[0], pUnicodeCtrl->yPos[0],
                                                           state.lastSeenPrimaryPos.x, state.lastSeenPrimaryPos.y);

    // Min distance start point to end point
    if (distStartToEndPos_s >= pLpwgCfg->unicodeMaxStartToEndDist*UnitsPerMm)
    {
      // Min travel distance
      if (pUnicodeCtrl->sumTotalDist >= pLpwgCfg->unicodeMaxStartToEndDist*UnitsPerMm)
      {
        // Ending direction criteria
        if ((pUnicodeCtrl->LastDistanceDir == DIRECTION_DOWN_LEFT) || (pUnicodeCtrl->LastDistanceDir == DIRECTION_LEFT) ||
            (pUnicodeCtrl->LastDistanceDir == DIRECTION_UP_LEFT) || (pUnicodeCtrl->LastDistanceDir == DIRECTION_UP))
        {
          if ((vecDir2 >= DIRECTION_DOWN_LEFT) && (vecDir2 <= DIRECTION_UP_LEFT))
          {
            return(1);
          }
        }
      }
    }
  }

  return(0);
}

static uint16 checkLPWG_Unicode_m_w (unicodeCtrl_s *pUnicodeCtrl, lpwgParams_t *pLpwgCfg, uint16 UnitsPerMm)
{
  uint16 m_w_DistStartToEndPos = estimateMagnitudeNoDeltas(pUnicodeCtrl->xPos[0], pUnicodeCtrl->yPos[0],
                                               state.lastSeenPrimaryPos.x, state.lastSeenPrimaryPos.y);
  if ((pUnicodeCtrl->sideHasCurve <= 2) &&
      // this condition makes sure our start to end point is above some threshold
      (m_w_DistStartToEndPos >= pLpwgCfg->unicodeMaxStartToEndDist*UnitsPerMm) &&
      // this condition define how small 'm' or 'w' can be
      (pUnicodeCtrl->sumTotalDist >= pLpwgCfg->unicodeMaxStartToEndDist*UnitsPerMm))
  {
    if ((pUnicodeCtrl->mightBe_m == 2) && (pUnicodeCtrl->mightBe_w == 2) && (pUnicodeCtrl->mORwFalseTriggerCounter == 0))
    {
      if (pUnicodeCtrl->unicode_mORw == UNICODE_LOOKSLIKE_m)
      {
        return (LPWG_UNICODE_m);
      }
      else if (pUnicodeCtrl->unicode_mORw == UNICODE_LOOKSLIKE_w)
      {
        if ((pUnicodeCtrl->LastDistanceDir == DIRECTION_UP) || (pUnicodeCtrl->LastDistanceDir == DIRECTION_UP_RIGHT))
        {
          return (LPWG_UNICODE_w);
        }
      }
    }
    if ((pUnicodeCtrl->mightBe_m == 2) && (pUnicodeCtrl->mightBe_w == 3) && (pUnicodeCtrl->unicode_mORw == UNICODE_LOOKSLIKE_w))
    {
      return (LPWG_UNICODE_m);
    }
  }

  return(0);
}

static uint16 checkLPWG_Unicode_e (unicodeCtrl_s *pUnicodeCtrl, lpwgParams_t *pLpwgCfg, uint16 UnitsPerMm)
{
  circleDir_s *pDirCtrl = &(pUnicodeCtrl->dirCtrl);
  uint16 sumLastWiseClkDistLocal = pDirCtrl->sumLastWiseClkDist/UnitsPerMm;
  uint16 distStartToEndPos_e = estimateMagnitudeNoDeltas(pUnicodeCtrl->xPos[0], pUnicodeCtrl->yPos[0],
                                                        state.lastSeenPrimaryPos.x, state.lastSeenPrimaryPos.y);
  if ((pUnicodeCtrl->sideHasCurve < 2) &&
      // this condition makes sure we are drawing only one 'e' at a time and allows shaky finger
      // it also helps from false triggering when other shapes are drawn like 's' or '8', etc
      (pDirCtrl->circularMotion >= 3) && (pDirCtrl->circularMotion <= 11) &&
      (pDirCtrl->circleCntClkWiseNum >= 3) && (pDirCtrl->circleCntClkWiseNum <= 10) &&
      ((pDirCtrl->circleClkWiseNum <= 1) || ((pDirCtrl->circleClkWiseNum == 2) && (sumLastWiseClkDistLocal < 4))) &&
      (0 == pDirCtrl->circleTurnOppositeNum)&&
      (distStartToEndPos_e >= pLpwgCfg->unicodeMaxStartToEndDist*UnitsPerMm) &&
      (pUnicodeCtrl->theBottomYBeforeTurnLeft != pUnicodeCtrl->ContactPoint[3])&&
      (pUnicodeCtrl->theBottomYBeforeTurnLeft != 0)&&
      // this condition define how small 'e' can be drawn
      (pUnicodeCtrl->sumTotalDist >= pLpwgCfg->unicodeMaxStartToEndDist*UnitsPerMm))
  {
    // this condition checks direction change based on speed.
    // it needs to be 1 or 2 for 'e'
    if (pUnicodeCtrl->mightBe_e == 1)
    {
      if (// LPWG_ContactPoint[7], Y[start]> Y[min] to avoid false trigger by drawing 'w' --BBK
          (pUnicodeCtrl->yPos[0] > pUnicodeCtrl->ContactPoint[7]) &&
          // to avoid false trigger by 'l'
          ((pUnicodeCtrl->ContactPoint[3] - pUnicodeCtrl->ContactPoint[7]) * 2 < (pUnicodeCtrl->ContactPoint[4] - pUnicodeCtrl->ContactPoint[0]) * 3))
      {
        return(1);
      }
    }
  }
  return(0);
}

static uint16 checkLPWG_Unicode_c (unicodeCtrl_s *pUnicodeCtrl, lpwgParams_t *pLpwgCfg, uint16 UnitsPerMm)
{
  circleDir_s *pDirCtrl = &(pUnicodeCtrl->dirCtrl);
  uint16 sumLastWiseClkDistLocal = pDirCtrl->sumLastWiseClkDist/UnitsPerMm;
  uint16 distStartToEndPos_c = estimateMagnitudeNoDeltas(pUnicodeCtrl->xPos[0], pUnicodeCtrl->yPos[0],
                                                        state.lastSeenPrimaryPos.x, state.lastSeenPrimaryPos.y);

  // this condition checks direction change based on speed.
  // it needs to be 1 for 'c'
  if (((pDirCtrl->circleClkWiseNum == 0)||((pDirCtrl->circleClkWiseNum == 1) && (sumLastWiseClkDistLocal < 4))) &&
    // this condition makes sure we are drawing only one 'c' at a time and allows shaky finger
    ((pDirCtrl->circleCntClkWiseNum >= 3) && (pDirCtrl->circleCntClkWiseNum <= 8)) &&
    // this condition makes sure our start to end point is above some threshold
    (distStartToEndPos_c >= pLpwgCfg->unicodeMaxStartToEndDist*UnitsPerMm) &&
    // this condition define how small 'c' can be drawn
    (pUnicodeCtrl->sumTotalDist >= pLpwgCfg->unicodeMaxStartToEndDist*UnitsPerMm))
  {
    // if circle is detected then we ignore it to be 'c'
    if (pUnicodeCtrl->mightBe_c == 1)
    {
      // this condition make sure its 'c' and not elliptical or other shapes
      if ((pUnicodeCtrl->LastDistanceDir >= DIRECTION_UP) && (pUnicodeCtrl->LastDistanceDir <= DIRECTION_DOWN_RIGHT))
      {
        int16 width, height, mouthWidth, mouthHeight;

        if ((state.lastSeenPrimaryPos.x < pUnicodeCtrl->xPos[0]) && (state.lastSeenPrimaryPos.y < pUnicodeCtrl->ContactPoint[1])) //X[last]<X[start], Y[last] <Y[minX]  to avoid false trigger by '6'
        {
          return (0);
        }

        width = pUnicodeCtrl->ContactPoint[4]-pUnicodeCtrl->ContactPoint[0];
        height = pUnicodeCtrl->ContactPoint[3]-pUnicodeCtrl->ContactPoint[7];
        mouthWidth = state.lastSeenPrimaryPos.x - pUnicodeCtrl->xPos[0];
        mouthHeight = state.lastSeenPrimaryPos.y - pUnicodeCtrl->yPos[0];

        if(mouthWidth < 0)
        {
          mouthWidth = -mouthWidth;
        }

        if(mouthHeight < 0)
        {
          mouthHeight = -mouthHeight;
        }

        if(mouthWidth*2 > width || mouthHeight*3 < height)
        {
          return 0;
        }

        return (1);
      }
    }
  }
  return(0);
}

void detectUnicode(struct touch pos, uint16 frameRate, gestureReport_t *pReport)
{
  uint16 xPos = pos.x;
  uint16 yPos = pos.y;
  unicodeCtrl_s *pUnicodeCtrl = &state.unicodeCtrl;
  circleDir_s *pDirCtrl = &(pUnicodeCtrl->dirCtrl);
  lpwgParams_t *pLpwgCfg = &params.cfg;
  uint16 UnitsPerMm = estimateMagnitude(pLpwgCfg->xUnitsPerMm, pLpwgCfg->yUnitsPerMm);
  uint16 clkWiseDistance;

  if (pos.touchFlag)
  {
    if ((state.prevTouchFlag != 1) || (pUnicodeCtrl->State == LPWG_STATE_INIT))
    {
      unicodeInit(pUnicodeCtrl, xPos, yPos);
    }
    else if (pUnicodeCtrl->State == LPWG_STATE_START_TRACKING)
    {
      uint16 lastDistanceTemp;
      uint16 currSpeedPerFrame;
      uint16 distStartToCurrPos;

      lastDistanceTemp= estimateMagnitudeNoDeltas(pUnicodeCtrl->LastDistancePosx, pUnicodeCtrl->LastDistancePosy, xPos, yPos);
      lastDistanceTemp = lastDistanceTemp/UnitsPerMm;

      if (lastDistanceTemp > 4)
      {
        pUnicodeCtrl->LastDistanceDir = vectorDir((xPos - pUnicodeCtrl->LastDistancePosx), (yPos - pUnicodeCtrl->LastDistancePosy), pLpwgCfg->unicodeOrientation);
        pUnicodeCtrl->LastDistancePosx = xPos;
        pUnicodeCtrl->LastDistancePosy = yPos;

        if ((pUnicodeCtrl->LastDistanceDir >= DIRECTION_RIGHT) && (pUnicodeCtrl->LastDistanceDir <= DIRECTION_DOWN_RIGHT))
        {
          pUnicodeCtrl->lpwgSstartCapLeftDir = 1;
        }

        if (pUnicodeCtrl->lpwgSstartCapLeftDir == 1)
        {
          if ((pUnicodeCtrl->LastDistanceDir >= DIRECTION_DOWN_LEFT) && (pUnicodeCtrl->LastDistanceDir <= DIRECTION_UP_LEFT))
          {
            pUnicodeCtrl->lpwgSstartCapLeftDir =0;
            pUnicodeCtrl->lpwgSstartCapLeftDirX = pUnicodeCtrl->LastDistancePosx;
            pUnicodeCtrl->lpwgSstartCapLeftDirY = pUnicodeCtrl->LastDistancePosy;
          }
        }
      }

      if (pUnicodeCtrl->ContactPoint[0] > xPos) //MinX
      {
        pUnicodeCtrl->ContactPoint[0] = xPos;
        pUnicodeCtrl->ContactPoint[1] = yPos;
      }
      if (pUnicodeCtrl->ContactPoint[3] < yPos) // MaxY
      {
        pUnicodeCtrl->ContactPoint[2] = xPos;
        pUnicodeCtrl->ContactPoint[3] = yPos;
      }
      if (pUnicodeCtrl->ContactPoint[4] < xPos) // MaxX
      {
        pUnicodeCtrl->ContactPoint[4] = xPos;
        pUnicodeCtrl->ContactPoint[5] = yPos;
      }
      if (pUnicodeCtrl->ContactPoint[7] > yPos) // MinY
      {
        pUnicodeCtrl->ContactPoint[6] = xPos;
        pUnicodeCtrl->ContactPoint[7] = yPos;
      }

      // Calculate distance between previous position and current position
      currSpeedPerFrame = estimateMagnitudeNoDeltas(state.lastSeenPrimaryPos.x, state.lastSeenPrimaryPos.y, xPos, yPos);
      pDirCtrl->sumLastWiseClkDist += currSpeedPerFrame;
      //sum distance travelled from starting pos
      pUnicodeCtrl->sumTotalDist += currSpeedPerFrame;
      // Calculate distance between start position and current position
      distStartToCurrPos = estimateMagnitudeNoDeltas(pUnicodeCtrl->xPos[0], pUnicodeCtrl->yPos[0], xPos, yPos);

      if (currSpeedPerFrame > pLpwgCfg->MinimumUnicodeSpeed)
      {
        if (pUnicodeCtrl->circleBasedGestureDirFlag == 0)
        {
          if (distStartToCurrPos > 4*UnitsPerMm)
          {
            uint16 VectorDirFromStart = vectorDir(xPos - pUnicodeCtrl->xPos[0], yPos - pUnicodeCtrl->yPos[0], pLpwgCfg->unicodeOrientation);

            pUnicodeCtrl->circleBasedGestureDirFlag = 1;

            if ((VectorDirFromStart >= DIRECTION_UP_RIGHT) && (VectorDirFromStart <= DIRECTION_DOWN))
            {
              pUnicodeCtrl->mightBe_e++;
            }

            // This start direction is common to both c and s
            if (((VectorDirFromStart >= DIRECTION_DOWN_LEFT) && (VectorDirFromStart <= DIRECTION_UP_LEFT)) ||
                (VectorDirFromStart == DIRECTION_UP))
            {
              pUnicodeCtrl->mightBe_c++;
            }
          }
        }

        if ((abs16((int16)xPos - (int16)pUnicodeCtrl->unicodeXPrevPosBfr1Mm) > 3 * (int16)pLpwgCfg->xUnitsPerMm) ||
            (abs16((int16)yPos - (int16)pUnicodeCtrl->unicodeYPrevPosBfr1Mm) > 3 * (int16)pLpwgCfg->yUnitsPerMm))
        {
          uint16 currVectorDir = vectorDir(xPos - pUnicodeCtrl->unicodeXPrevPosBfr1Mm
                                         , yPos - pUnicodeCtrl->unicodeYPrevPosBfr1Mm
                                         , pLpwgCfg->unicodeOrientation);

          // conditions for m, w
          if (currVectorDir != pUnicodeCtrl->prevVectorDir)
          {
            if (currVectorDir == DIRECTION_LEFT)
            {
              pUnicodeCtrl->mORwFalseTriggerCounter++;
            }
            if ((currVectorDir == DIRECTION_UP) || (currVectorDir == DIRECTION_UP_LEFT) ||
                (currVectorDir == DIRECTION_UP_RIGHT))
            {
              if (pUnicodeCtrl->prevVectorDir == DIRECTION_UNKNOWN)
              {
                pUnicodeCtrl->unicode_mORw = UNICODE_LOOKSLIKE_m;
              }
              if (pUnicodeCtrl->unicode_mORw == UNICODE_LOOKSLIKE_m)
              {
                if (pUnicodeCtrl->mightBe_m == pUnicodeCtrl->mightBe_w)
                {
                  pUnicodeCtrl->mightBe_m++;
                }
              }
              else
              {
                if (pUnicodeCtrl->mightBe_m != pUnicodeCtrl->mightBe_w)
                {
                  pUnicodeCtrl->mightBe_m++;
                }
              }
            }
            else if (((currVectorDir >= DIRECTION_DOWN_RIGHT) && (currVectorDir <= DIRECTION_DOWN_LEFT)))
            {
              if (pUnicodeCtrl->prevVectorDir == DIRECTION_UNKNOWN)
              {
                pUnicodeCtrl->unicode_mORw = UNICODE_LOOKSLIKE_w;
              }
              if (pUnicodeCtrl->unicode_mORw == UNICODE_LOOKSLIKE_w)
              {
                if (pUnicodeCtrl->mightBe_m == pUnicodeCtrl->mightBe_w)
                {
                  pUnicodeCtrl->mightBe_w++;
                }
              }
              else
              {
                if (pUnicodeCtrl->mightBe_m != pUnicodeCtrl->mightBe_w)
                {
                  pUnicodeCtrl->mightBe_w++;
                }
              }
            }

            if (currVectorDir == DIRECTION_RIGHT)
            {
              if (pUnicodeCtrl->prevVectorDir == DIRECTION_UNKNOWN)
              {
                pUnicodeCtrl->mightBe_z++;
              }
              else if ((DIRECTION_DOWN_RIGHT <= pUnicodeCtrl->prevVectorDir && pUnicodeCtrl->prevVectorDir <= DIRECTION_DOWN_LEFT) &&
                       (pUnicodeCtrl->mightBe_z == 1))
              {
                pUnicodeCtrl->mightBe_z++;
              }
            }
          }

          pUnicodeCtrl->prevVectorDir = currVectorDir;
          pUnicodeCtrl->unicodeXPrevPosBfr1Mm = xPos;
          pUnicodeCtrl->unicodeYPrevPosBfr1Mm = yPos;
        }

        if (pUnicodeCtrl->maxSpeedPerFrame == 1)
        {
          if ((abs16((int16)xPos - (int16)pUnicodeCtrl->xPos[pUnicodeCtrl->mightBe]) > (3 * (int16)pLpwgCfg->xUnitsPerMm)) ||
              (abs16((int16)yPos - (int16)pUnicodeCtrl->yPos[pUnicodeCtrl->mightBe]) > (3 * (int16)pLpwgCfg->yUnitsPerMm)))
          {
            pUnicodeCtrl->maxSpeedPerFrame = currSpeedPerFrame;
          }
        }
        else
        {
          if (percentDeviation(pUnicodeCtrl->maxSpeedPerFrame, currSpeedPerFrame) > 20)
          {
            pUnicodeCtrl->maxSpeedPerFrame = (pUnicodeCtrl->maxSpeedPerFrame < currSpeedPerFrame) ? currSpeedPerFrame : pUnicodeCtrl->maxSpeedPerFrame;
          }
        }

        //report speed of drawing gesture
        pUnicodeCtrl->reportMinSpeedPerFrameMm = currSpeedPerFrame;
        clkWiseDistance = estimateMagnitudeNoDeltas(pUnicodeCtrl->xLastSeenNmm, pUnicodeCtrl->yLastSeenNmm, xPos, yPos);

        if(clkWiseDistance > 3*UnitsPerMm)
        {
          circleDirectionChange(pDirCtrl, vectorDir((xPos - state.lastSeenPrimaryPos.x), (yPos - state.lastSeenPrimaryPos.y), pLpwgCfg->unicodeOrientation));

          // condition for "e"
          if (pUnicodeCtrl->theBottomYBeforeTurnLeft == 0)
          {
              if((pDirCtrl->prevCircleDir >= DIRECTION_DOWN_LEFT) && (pDirCtrl->prevCircleDir <= DIRECTION_UP_LEFT))
              {
                  pUnicodeCtrl->theBottomYBeforeTurnLeft = pUnicodeCtrl->ContactPoint[3];// MaxY
              }
          }

          pUnicodeCtrl->xLastSeenNmm = xPos;
          pUnicodeCtrl->yLastSeenNmm = yPos;
        }

        if ((pUnicodeCtrl->mightBe < pUnicodeCtrl->mightBe_m) ||
            (pUnicodeCtrl->mightBe < pUnicodeCtrl->mightBe_w) ||
            (pUnicodeCtrl->mightBe < pUnicodeCtrl->mightBe_z))
        {
          pUnicodeCtrl->maxSpeedPerFrame = 1;
          if (pUnicodeCtrl->mightBe < 3)
          {
            pUnicodeCtrl->mightBe++;
            if (1 < pUnicodeCtrl->mightBe)
            {
              uint16 expectedDistTraveled = estimateMagnitudeNoDeltas(pUnicodeCtrl->xPos[pUnicodeCtrl->mightBe - 1]
                                                                    , pUnicodeCtrl->yPos[pUnicodeCtrl->mightBe - 1]
                                                                    , xPos
                                                                    , yPos);
              if (percentDeviation(expectedDistTraveled, pUnicodeCtrl->sumSideDist) > 50)
              {
                pUnicodeCtrl->sideHasCurve++;
              }
            }
            pUnicodeCtrl->xPos[pUnicodeCtrl->mightBe] = xPos;
            pUnicodeCtrl->yPos[pUnicodeCtrl->mightBe] = yPos;
          }
          pUnicodeCtrl->sumSideDist = 0;
        }
      }
    }
  }
  else if (state.prevTouchFlag == 1)
  {
    if ((pDirCtrl->circularMotion > 11) || (pDirCtrl->circleCntClkWiseNum > 11) || (pDirCtrl->circleClkWiseNum > 11))
    {
      return;
    }
    /*
     * Check if there is only one direction change OR only one side is not curved
     * This is based on usability tests that user might end up drawing swipes at end of circle
     * or have one side straight (20%) and remaining part (80%) to be curved of a circle
     */
    if ((!(pLpwgCfg->unicodeSwitch & LPWG_UNICODE_SWITCH_C)) && checkLPWG_Unicode_c(pUnicodeCtrl, pLpwgCfg, UnitsPerMm))
    {
      pReport->unicodeDetected = 1;
      pReport->gestureProperty[0] = (pUnicodeCtrl->reportMinSpeedPerFrameMm * frameRate)/(10*UnitsPerMm);
      pReport->gestureProperty[1] = LPWG_UNICODE_c;
    }

    if ((!(pLpwgCfg->unicodeSwitch & LPWG_UNICODE_SWITCH_S)) && checkLPWG_Unicode_s(pUnicodeCtrl, pLpwgCfg, UnitsPerMm))
    {
      pReport->unicodeDetected = 1;
      pReport->gestureProperty[0] = (pUnicodeCtrl->reportMinSpeedPerFrameMm * frameRate)/(10*UnitsPerMm);
      pReport->gestureProperty[1] = LPWG_UNICODE_s;
    }

    if ((!(pLpwgCfg->unicodeSwitch & LPWG_UNICODE_SWITCH_E)) && checkLPWG_Unicode_e(pUnicodeCtrl, pLpwgCfg, UnitsPerMm))
    {
      pReport->unicodeDetected = 1;
      pReport->gestureProperty[0] = (pUnicodeCtrl->reportMinSpeedPerFrameMm * frameRate)/(10*UnitsPerMm);
      pReport->gestureProperty[1] = LPWG_UNICODE_e;
    }

    if ((pLpwgCfg->unicodeSwitch & (LPWG_UNICODE_SWITCH_M|LPWG_UNICODE_SWITCH_W)) != (LPWG_UNICODE_SWITCH_M|LPWG_UNICODE_SWITCH_W))
    {
      uint16 mORw = checkLPWG_Unicode_m_w(pUnicodeCtrl, pLpwgCfg, UnitsPerMm);

      mORw = ((pLpwgCfg->unicodeSwitch & LPWG_UNICODE_SWITCH_M) && (mORw == LPWG_UNICODE_m)) ? 0 : mORw;
      mORw = ((pLpwgCfg->unicodeSwitch & LPWG_UNICODE_SWITCH_W) && (mORw == LPWG_UNICODE_w)) ? 0 : mORw;
      if (mORw != 0)
      {
        pReport->unicodeDetected = 1;
        pReport->gestureProperty[0] = (pUnicodeCtrl->reportMinSpeedPerFrameMm * frameRate)/(10*UnitsPerMm);
        pReport->gestureProperty[1] = mORw;
      }
    }

    if ((!(pLpwgCfg->unicodeSwitch & LPWG_UNICODE_SWITCH_Z)) && checkLPWG_Unicode_z(pUnicodeCtrl, pLpwgCfg, UnitsPerMm))
    {
      // should check the switch off here and notifiy circle detection to avoid false trigger of 'C' to 'O'
      pReport->unicodeDetected = 1;
      pReport->gestureProperty[0] = (pUnicodeCtrl->reportMinSpeedPerFrameMm * frameRate)/(10*UnitsPerMm);
      pReport->gestureProperty[1] = LPWG_UNICODE_z;
    }

    pUnicodeCtrl->State = LPWG_STATE_INIT;
  }
}

void gesture_init(calcStaticConfig_t *cfg)
{
  memset(&state, 0, sizeof(state));
  // implied by memset:
  //state.dtState = DT_INIT;
  //state.falseActivations = 0;
  //state.activeDuration = 0;
  //state.lastTimeStamp = 0;
  //state.lastTimeStampValid = 0;
  //state.enabled = 0;
  state.primaryIdx = -1;

  params.cfg = cfg->lpwgParams;
  params.txPitch_mm = cfg->ifpConfig.sensorParams.txPitch_mm;
  params.rxPitch_mm = cfg->ifpConfig.sensorParams.rxPitch_mm;

  // force ordering of double-tap zone coordinates
  if (params.cfg.doubleTapZoneX0 > params.cfg.doubleTapZoneX1)
  {
    uint16 temp = params.cfg.doubleTapZoneX1;
    params.cfg.doubleTapZoneX1 = params.cfg.doubleTapZoneX0;
    params.cfg.doubleTapZoneX0 = temp;
  }
  if (params.cfg.doubleTapZoneY0 > params.cfg.doubleTapZoneY1)
  {
    uint16 temp = params.cfg.doubleTapZoneY1;
    params.cfg.doubleTapZoneY1 = params.cfg.doubleTapZoneY0;
    params.cfg.doubleTapZoneY0 = temp;
  }
#if CONFIG_HIC_LPWG_MODE_B
  // trgtInterval is in 5ms units.
  params.lpwgFramePeriod = cfg->lpwgModeBParams.trgtInterval == 0 ? 1 : 200000/cfg->lpwgModeBParams.trgtInterval;
#else
  params.lpwgFramePeriod = cfg->lpwgParams.frameRate == 0 ? 1 : 100000/cfg->lpwgParams.frameRate;
#endif

  userDefinedGestures_init(cfg);
}


void gesture_setEnabled(uint16 enable)
{
  state.enabled = enable;

  userDefinedGestures_setEnabled(enable);
}

uint16 gesture_getLpwgFramePeriod()
{
#if CONFIG_HAS_LPWG_POWERREDUCTION
  return 1;
#else
  return params.lpwgFramePeriod;
#endif
}

uint16 gesture_getDozeRejectTime()
{
#if CONFIG_HAS_LPWG_POWERREDUCTION
  return 0;
#else
  uint16 rejectTime = 0;
  if (state.enabled)
  {
    if (state.activeDuration > (uint32) params.cfg.maxActiveDuration * 500000)
      rejectTime = params.cfg.maxActiveDurationTimeout;
    else if (state.falseActivations > params.cfg.falseActivationThreshold)
      rejectTime = params.cfg.falseActivationTimeout;

    if (rejectTime > 0)
    {
      state.activeDuration = 0;
      state.falseActivations = 0;
      state.lastTimeStampValid = 0;
      state.dtState = DT_INIT;
    }
  }
  return rejectTime;
#endif
}

void gesture_updateState(uint16 newTouch ATTR_UNUSED)
{
#if CONFIG_HAS_LPWG_POWERREDUCTION
  return;
#else
  if (!state.enabled)
    return;

  if (newTouch)
  {
    state.falseActivations++;
    state.activeDuration = 0;
    state.lastTimeStampValid = 0;
  }
#endif
}

void gesture_checkPowerReductionOptions()
{
#if CONFIG_HAS_LPWG_POWERREDUCTION
  if(state.enabled)
  {
    if (!params.cfg.startLPWGSensing)
    {
      // Start of LPWG mode, initialize all parameters here
      params.cfg.startLPWGSensing = 1;
      params.cfg.alternateDozeSensing = 0;
      params.cfg.continuousActiveCounter = 0;
      params.cfg.falseActCounter = 0;
    }
  }
  else if (params.cfg.startLPWGSensing)
  {
    params.cfg.startLPWGSensing = 0;
    params.cfg.alternateDozeSensing = 0;
  }

#if CONFIG_HIC_LPWG_MODE_B
  // F12 reported a gesture
  if (params.cfg.resetGestureCounters)
  {
    params.cfg.resetGestureCounters = 0;
    params.cfg.falseActCounter = 0;
    params.cfg.continuousActiveCounter = 0;
  }
#endif

  if (params.cfg.startLPWGSensing)
  {
    params.cfg.continuousActiveCounter++;

    // TODO: CONFIG_HIC_TRGT_MODE_B - should we do something if COMM_isForceTRGT() returns true?
    if (params.cfg.wentToSleep)
    {
      // Above flag will be set when successful transition to doze mode has been made. If this flag is not set for
      // the duration of counter, then FW has been active for too long
      // This code can also be placed where wentToSleep is set, but trying to contain all LPWG code at one place
      // Not active continuously
      params.cfg.continuousActiveCounter = 0;
    }
    if (params.cfg.falseActCounter > params.cfg.falseActivationThreshold)
    {
      // False activation found. Force to doze mode and doze for the duration of Timer1
      params.cfg.alternateDozeSensing = 1;
      params.cfg.falseActivationDueToIncompleteDoze = 1;
      params.cfg.falseActivationDueToMaxActiveTimeout = 0;
      params.cfg.continuousActiveCounter = 0;
    }
    if (params.cfg.continuousActiveCounter  >  params.cfg.maxActiveDurationInFrames)
    {
      // Switch to doze mode
      params.cfg.alternateDozeSensing = 1;
      params.cfg.falseActivationDueToMaxActiveTimeout = 1;
      params.cfg.falseActivationDueToIncompleteDoze = 0;
      params.cfg.continuousActiveCounter = 0;
      gesture_lp_decFalseActivationCounter();
      #if CONFIG_LPWG_POWERREDUCTION_FORCEDOZE_ENABLE
        params.cfg.ForceDozeLPWG_byObjectPresent_Trigger++;
      #endif
    }

    #if CONFIG_LPWG_POWERREDUCTION_FORCEDOZE_ENABLE
    if(params.cfg.ForceDozeLPWG_byObjectPresent_DoRepeatForceDoze)
    {
      // Switch to doze mode
      params.cfg.alternateDozeSensing = 1;
      // use Timer1 counter - same as false activative timer
      params.cfg.falseActivationDueToMaxActiveTimeout = 0;
      params.cfg.falseActivationDueToIncompleteDoze = 1;
      params.cfg.continuousActiveCounter = 0;
      gesture_lp_decFalseActivationCounter();
    }
    #endif
  }
#endif
}

void gesture_detect(touchReport_t *report)
{
  uint32 deltaTime;
  struct touch pos;
  gestureReport_t gestures;
  uint16 gestureType = params.cfg.gestureType;

  if (!state.enabled)
    return;

  state.touchReportRate = report->frameRate;
  if (!state.lastTimeStampValid)
  {
    state.lastTimeStamp = report->timeStamp;
    state.lastTimeStampValid = 1;
  }

  deltaTime = report->timeStamp - state.lastTimeStamp;
  state.lastTimeStamp = report->timeStamp;

  if (state.activeDuration > 0xFFFFFFFF - deltaTime)
    state.activeDuration = 0xFFFFFFFF;
  else
    state.activeDuration += deltaTime;

#if CONFIG_HIC_LPWG_MODE_B
  if (report->singleFingerTouch)
  {
    uint16 i;
    // Copy report->touch.SFReport.pos[] to report->touch.pos[] to simplify the gesture
    // code which uses report->touch.pos[]
    //
    // TODO: should this be done prior - in imageFrameProcessor_nextUltraLPWGFrame()?

    // clear touch.pos[], which fortunately also sets hostClassification_none (0)
    memset(report->touch.pos, 0, sizeof(report->touch.pos));

    for (i = 0; i < 2; i++)
    {
      report->touch.pos[i] = report->touch.SFReport.pos[i];
    }
  }
#endif

  state.primaryIdx = findPrimaryFinger(report, state.primaryIdx);

  pos.touchFlag = (state.primaryIdx != -1);
  pos.ts = report->timeStamp;
  if (pos.touchFlag)
  {
    reportPos_t *p = &report->touch.pos[state.primaryIdx];
    // FIXME: sensibly handle overflows
    pos.tx = (int16) (((int32) p->txPos * params.txPitch_mm) >> 16);
    pos.rx = (int16) (((int32) p->rxPos * params.rxPitch_mm) >> 16);
    pos.x = p->xMeas;
    pos.y = p->yMeas;
  }

  // Process every supported gesture. If any valid gesture found, stop the following gesture processing.
  memset(&gestures, 0, sizeof(gestures));
  #if CONFIG_HAS_LPWG_DOUBLETAP
  if (gestureType & LPWG_DOUBLETAP_ENABLE)
  {
    detectDoubleTap(pos, &gestures);
  }
  #endif
  #if CONFIG_HAS_LPWG_MULTITAP
  if (gestureType & LPWG_MULTITAP_ENABLE)
  {
    doGestures(report);
  }
  #endif
  #if CONFIG_HAS_LPWG_UNICODE
  if (gestureType & LPWG_UNICODE_ENABLE)
  {
    detectUnicode(pos, report->frameRate, &gestures);
  }
  #endif
  #if CONFIG_HAS_LPWG_TRIANGLE
  if ((gestureType & LPWG_TRIANGLE_ENABLE) && !(gestures.unicodeDetected ||
                                               gestures.circleDetected))
  {
    detectTriangle(pos, report->frameRate, &gestures);
  }
  #endif
  #if CONFIG_HAS_LPWG_CIRCLE
  if ((gestureType & LPWG_CIRCLE_ENABLE) && (!gestures.unicodeDetected))
  {
    detectCircle(pos, report->frameRate, &gestures);
  }
  #endif
  #if CONFIG_HAS_LPWG_VEE
  if ((gestureType & LPWG_VEE_ENABLE) && !(gestures.unicodeDetected ||
                                          gestures.circleDetected ||
                                          gestures.triangleDetected))
  {
    detectVee(pos, report->frameRate, &gestures);
  }
  #endif
  #if CONFIG_HAS_LPWG_SWIPE
  if ((gestureType & LPWG_SWIPE_ENABLE) && (!(gestures.unicodeDetected ||
                                            gestures.circleDetected ||
                                            gestures.triangleDetected ||
                                            gestures.veeDetected)))
  {
    detectSwipe(pos, &gestures);
  }
  #endif
  if (params.cfg.userDefinedGestureEnabled && !(gestures.unicodeDetected ||
                                               gestures.circleDetected ||
                                               gestures.triangleDetected ||
                                               gestures.veeDetected ||
                                               gestures.swipeDetected))
  {
    userDefinedGestures_detect(pos, &gestures);
  }

  report->gesture = gestures;
  report->setAttn = (gestures.gestureDetected != 0);

  if (report->setAttn)
  {
    state.falseActivations = 0;
    state.activeDuration = 0;
    memset(&state.lastSeenPrimaryPos, 0, sizeof(struct touch));
  }

  state.prevTouchFlag = pos.touchFlag;

  if (pos.touchFlag)
  {
    state.lastSeenPrimaryPos = pos;
  }
}

uint16 gesture_allowLowPower()
{
  if (userDefinedGestures_isDataCollectionState())
    return 0;

  return 1;
}

uint16 gesture_isAlternateDozeSensing()
{
#if CONFIG_HAS_LPWG_POWERREDUCTION
  return params.cfg.alternateDozeSensing;
#else
  return 0;
#endif
}

#endif //CONFIG_HAS_WAKEUPGESTURE

#if CONFIG_HAS_WAKEUPGESTURE && CONFIG_HAS_LPWG_POWERREDUCTION

void gesture_lp_reinit()
{
  params.cfg.frameRate = COMM_getS0ReportRateLPWG();        // 5ms units
  params.cfg.falseActivationThreshold = COMM_getS0FalseActivationThreshold();
  params.cfg.Timer1 =  COMM_getS0Timer1();
  params.cfg.maxActiveDuration =  COMM_getS0MaxActiveDuration();
  params.cfg.maxActiveDurationTimeout = COMM_getS0MaxActiveDurationTimeout();
#if CONFIG_HIC_LPWG_MODE_B
  // HIC used LPWG rate for LPWG doze interval
  params.cfg.AdjDoze = COMM_getS0ReportRateModeBLPWG();     // 0.5ms units
  // HIC uses Func12::getS0ReportRateLPWG();
  params.cfg.maxActiveDurationInFrames = (params.cfg.maxActiveDuration * COMM_getS0ReportRateLPWG())>>1;
#else
  params.cfg.AdjDoze = COMM_readReg_AdjDoze();              // 10ms
  params.cfg.maxActiveDurationInFrames = (params.cfg.maxActiveDuration * params.cfg.frameRate)>>1;
#endif
}

void gesture_lp_setWentToSleep()
{
  params.cfg.wentToSleep = 1;
}

void gesture_lp_clearWentToSleep()
{
  params.cfg.wentToSleep = 0;
}

void gesture_lp_setResetGestureCounters()
{
  params.cfg.resetGestureCounters = 1;
}

void gesture_lp_decFalseActivationCounter()
{
  if(params.cfg.falseActCounter > 0)
  {
    params.cfg.falseActCounter--;
  }
}

void gesture_lp_incFalseActivationCounter()
{
  params.cfg.falseActCounter++;
}

void gesture_lp_clearContinuousActiveCounter()
{
  params.cfg.continuousActiveCounter = 0;
}

uint16 gesture_lp_isLPWGSensing()
{
  return params.cfg.startLPWGSensing;
}

uint16 gesture_lp_isAlternateObjectDetect(uint16 objDetected)
{
  static uint16 quietTimer;
  uint16 temp = params.cfg.maxActiveDurationTimeout;
  uint16 obj = objDetected;

  quietTimer++;

  if (params.cfg.falseActivationDueToIncompleteDoze)
  {
    temp = params.cfg.Timer1;
  }
  // Above timers are in units of 100 mS. Convert them to actual ms.
  temp *= 100;

#if CONFIG_HIC_LPWG_MODE_B
  // Mode B parameter is in 0.5 ms units
  if((((quietTimer * params.cfg.AdjDoze)>>1) > temp) ||(!state.enabled))
#else
  if(((quietTimer * params.cfg.AdjDoze * 10) > temp) ||(!state.enabled))
#endif
  {
    // Quiet LP frames, object must have stopped moving OR
    // no longer in LPWG mode. When FW is in false trigger mode, it should exit quickly if host changes
    // reporting mode to something other than LPWG. This might increase the instructions in LP but safe to
    // have rather than having max delay of 1.5 second to get into active mode.
    quietTimer = 0;
    if(!obj)
    {
      params.cfg.alternateDozeSensing = 0;
    }
    // Decrement by 2 so that FW will run in active mode for 1 dozeHoldOff time
    // before triggering false activation again
    gesture_lp_decFalseActivationCounter();
    gesture_lp_decFalseActivationCounter();

    return true;
  }
  return false;
}

uint16 gesture_lp_getDoRepeatForceDoze()
{
  return params.cfg.ForceDozeLPWG_byObjectPresent_DoRepeatForceDoze;
}

#endif //CONFIG_HAS_WAKEUPGESTURE && CONFIG_HAS_LPWG_POWERREDUCTION
