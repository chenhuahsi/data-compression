// -----------------------------------------------------------------
// Knuckle
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//

#include <stddef.h>
#include "knuckle.h"
#include "./ifp/image_frame_processor.h"


#if CONFIG_IFP_KNUCKLE
// DEBUG: Set to 1 for KNUCKLE debug
# define cfg_ROI_DBG 0
# if (defined(cfg_ROI_DBG) && cfg_ROI_DBG)
  static uint16 roiDbg[30];
# endif

static uint16 roiDataOjb[ROIPEAK_HEADER];
                         // [0] Index
                         // [1] Object Status/Type
                         // [2] Peak X
                         // [3] Peak Y

static uint16 roiDataDelta[ROIP_DELTA_SIZE]; // 7 x 7 buffer
static uint16 roiFifoIndex = 0;

// KNUCKLE is required by 3rd company through our customer.
//
// Specification from 3rd company
// 1. A 7 x 7 delta matrix should be send out through RMI.
// 2. The center of the matrix will be the peak of the latest landed object.
// 3. If there are more than 1 objects detected as landing in same frame,
//    the object with highest peak's matrix should be reported.
//
// Specification from Synaptics
// 1. RT2 - delta ADC value is not open to customer.
//
void knuckleRoiCollector(reportData_t *touchData)
{
  PLCapData_t mRoiCapDeltaData;
  PLFrameData_t mRoiFrame;
  int16 *mRoiDeltaImagePtr = NULL;
  int16 roiCol, roiColEnd;
  int16 roiRow, roiRowEnd;
  int16 deltaADC;
  int16 deltaADCCnt;

  // Get the delta image from IFP
  mRoiDeltaImagePtr = imageFrameProcessor_getDelta(baselineType_trans);

  // Convert to RT2 Cap
  copy2DToFrameBuffer((deltaImage_t *)mRoiDeltaImagePtr, &mRoiFrame);
  PL_convertActiveFrameToDeltaCap(&mRoiFrame, &mRoiCapDeltaData);


  roiDataOjb[0] = touchData->peakIdx - 1;
  roiDataOjb[1] = 0;
  roiDataOjb[2] = touchData->peakRow;
  roiDataOjb[3] = touchData->peakCol;
  deltaADCCnt   = 0;
  for (
    roiCol = roiDataOjb[3] + 3, roiColEnd = roiDataOjb[3] - 3 - 1;
    roiCol > roiColEnd;
    roiCol--)
  {
    for (
      roiRow = roiDataOjb[2] + 3, roiRowEnd = roiDataOjb[2] - 3 - 1;
      roiRow > roiRowEnd;
      roiRow--)
    {
      if ((roiRow < 1) || (roiRow > MAX_TX))
      {
        deltaADC = 0;
      }
      else if ((roiCol < 1) || (roiCol > MAX_RX))
      {
        deltaADC = 0;
      }
      else
      {
        // same as RT2, report Cap value to host.
        deltaADC = mRoiCapDeltaData.image[(roiRow-1)*MAX_RX+(roiCol-1)];
      }

      roiDataDelta[deltaADCCnt] = deltaADC;
      deltaADCCnt++;
    }
  }
}

uint16 knuckleRoiFIFO()
{
  uint16 data = 0;

  if (roiFifoIndex >= ROIPEAK_HEADER)
  {
    uint16 delta_data;
    delta_data = roiDataDelta[(roiFifoIndex - ROIPEAK_HEADER)/2];
    if (roiFifoIndex & 1)
    {
      // MSB
      data = delta_data >> 8;
    }
    else
    {
      // LSB
      data = delta_data & 0x00FF;
    }
  }
  else
  {
    data = (roiDataOjb[roiFifoIndex] & 0x00FF);
  }
  roiFifoIndex++;

  if (roiFifoIndex == ROIPEAK_SIZE)
  {
    roiFifoIndex = 0;
  }

  return data;

}

// KNUCKLE is required by 3rd company through our customer.
//
// Specification from 3rd company
// 1. A 7 x 7 delta matrix should be send out through RMI.
// 2. The center of the matrix will be the peak of the latest landed object.
// 3. If there are more than 1 objects detected as landing in same frame,
//    the object with highest peak's matrix should be reported.
//
// Specification from Synaptics
// 1. RT6 - delta ADC value is not open to customer.
//
void getRoiPeak7x7Data(trackedObject_t  *trackedObjPtr   ,
                       clumps_t         *clumps          ,
                       reportData_t     *report          )
{
  int16  i;
  uint16 fingerChange;
  uint16 curFingerCnt;
  static uint16 prevFingerCnt;
  int16 *mRoiDeltaImagePtr = NULL;

  report->peakIdx  = 0;
  report->fngCnt   = 0;
  report->peakRow  = 0;
  report->peakCol  = 0;

  // get finger mask, bit [0 ~ 15]
  curFingerCnt = 0;

  // Get the delta image from IFP
  mRoiDeltaImagePtr = imageFrameProcessor_getDelta(baselineType_trans);

  for (i = 0; i < MAX_OBJECTS; i++)
  {
    if ((report->pos[i].classification == hostClassification_finger) && (report->pos[i].z > 0))
      curFingerCnt |= (1 << i);
  }

  // finger changed from previous touch?
  fingerChange = (curFingerCnt ^ prevFingerCnt);
  if (fingerChange)
  {
    // new finger touched?
    fingerChange &= curFingerCnt;
    if (fingerChange)
    {
      int16         maxPeakADC = 0;
      uint16        fingerMask = fingerChange;
      uint16       *labelImage = clumps->labelImage;
      pixelIndex_t *listImage  = clumps->listImage;

      // Loop all new touch, find the new touch with max Delta ADC if more than 1 new touch found.
      do
      {
        // Record the peak of current blob.
        uint16 peakRow = 0;
        uint16 peakCol = 0;
        int16  peakDelta= 0;

        // Get the index of "Least Index Object"
        // There must be at least 1 bit since fingerMask is not 0.
        // 'i' will be the least 1's index
        uint16 mask = (((fingerMask - 1) ^ fingerMask) + 1) >> 1;
        i = -1;
        do
        {
          i++;
          mask >>= 1;
        } while (mask);

        // Get peakADC / peakRow / peakCol
        if(trackedObjPtr != NULL){
          uint16       trackId   =  report->pos[i].trackId;
          uint16       clumpId   =  trackedObjPtr[trackId].clumpId - 1;
          uint16       blobId    =  trackedObjPtr[trackId].blobId;
          clumpInfo_t *clumpInfo = &clumps->info[clumpId];

          // Loop the clump if the new touch is a blob in it.
          if (clumpInfo->splitCount > 0)
          {
            // Get the peak value of the blob
            pixelIndex_t p;
            p = clumpInfo->firstPixel;
            peakDelta = 0;
            peakRow = 0;
            peakCol = 0;
            while (p.row != 0)
            {
              uint16 r, c, offset;
              int16  delta;
              r = p.row; c = p.col; offset = r * (MAX_RX + 1) + c;
              if ((labelImage[offset] >> 8) == blobId) // Compare blobId with lableId->blobId (higher 8 bit of lableId will record blobId.)
              {
                delta = *(mRoiDeltaImagePtr+offset);
                if (peakDelta < delta) { peakDelta = delta; peakRow = r; peakCol = c; }
              }
              p = listImage[offset];
            }
          }
          else
          {
            peakRow = clumpInfo->peakLocation.row;
            peakCol = clumpInfo->peakLocation.col;
            peakDelta = *(mRoiDeltaImagePtr + peakRow * (MAX_RX + 1) + peakCol);
          }

        # if (defined(cfg_ROI_DBG) && cfg_ROI_DBG)
          roiDbg[5]  = trackId;
          roiDbg[6]  = clumpId;
          roiDbg[7]  = blobId;
          roiDbg[8]  = clumpInfo->peakLocation.row;
          roiDbg[9]  = clumpInfo->peakLocation.col;
          roiDbg[10] = clumpInfo->splitCount;
          roiDbg[11] = clumpInfo->peakCount;
          roiDbg[12] = peakRow;
          roiDbg[13] = peakCol;
          roiDbg[14] = peakDelta;
          roiDbg[15] = (report->pos[i].xMeas + (1079 / 18) / 2) / (1079 / 18);
          roiDbg[16] = (report->pos[i].yMeas + (1919 / 30) / 2) / (1919 / 30);
          roiDbg[17] = i;
        # endif
        }

        // record max Peak
        if (maxPeakADC < peakDelta)
        {
          maxPeakADC = peakDelta;

          report->peakIdx = (i + 1) & 0xFF;
          report->fngCnt  = fingerChange;
          report->peakRow = peakRow;
          report->peakCol = peakCol;
        }

        fingerMask &= fingerMask - 1; // remove smallest bit.
      } while(fingerMask);
    }
  }

  prevFingerCnt = curFingerCnt;
}

#endif

