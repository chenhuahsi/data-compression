#ifndef GESTURE_RECOGNIZER_H
#define GESTURE_RECOGNIZER_H

// -----------------------------------------------------------------
// User Defined Gesture Recognizer
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// $Id: func_12.h,v 1.20.18.6.4.32.2.13 2014/10/03 08:48:42 yahuic Exp $
//

#include "calc2.h"


typedef struct
{
  udgFeaturePosition_t pos[CONFIG_LPWG_USERDEFINED_NUMPOINTS];
  uint16 numPts;
} udgTrace_t;


void  gestureRecognizer_boot();
void  gestureRecognizer_init(calcStaticConfig_t *cfg);
int   gestureRecognizer_registration(udgTrace_t *pData, uint16 templateIndex, uint16 *tryIndex);
float gestureRecognizer_gestureMatch(udgTrace_t *pData, uint16 *templateIndex);


#endif //#define GESTURERECOGNIZER_H
