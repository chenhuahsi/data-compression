#ifndef _CALC_HW_H
#define _CALC_HW_H
// -----------------------------------------------------------------
// Full CPU load monitor
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 2017  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA  95131
// (408) 904-1100

#if defined(__CHIMERA__)
uint32 cpuLoad_readCycles(void);

#else
uint32 cpuLoad_readCycles(void) { return 0; }
#endif

#endif // _CALC_HW_H
