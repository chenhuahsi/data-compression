/* -----------------------------------------------------------------
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Dr.
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include "calc2.h"
#include "platform.h"
#include "nsm2.h"

// static data
static rom_uint16 noiseBurstDelayCoeffs[] = {0, 297, 594, 0};
static rom_uint16 noiseScanBurstDelayCoeffs[] =
  {0, 408, 79, 278, 134, 882, 896, 324, 774, 790, 513, 370, 567, 239, 647, 0};


// The Public Functions.
//===========================
// These can be called from public wrappers in the individual NSMs.

void nsm2base_setChargerPresent(nsm_object_t *nsm_object_ptr, uint16 chargerPresent)
{
  switch (chargerPresent)
  {
    case NSM_CHARGER_BIT_LOW:
      nsm_object_ptr->nsm_internal.chargerPresent = NSM_CHARGER_BIT_LOW;
      break;
    case NSM_CHARGER_BIT_HIGH:
      nsm_object_ptr->nsm_internal.chargerPresent = NSM_CHARGER_BIT_HIGH;
      break;
  }
}

void nsm2base_setParams(nsm_object_t *nsm_object_ptr, nsm_params_t *nsmParams)
{
  uint16 transBPC;

  // Parsing parameters:
  transBPC = DAQ_readVar(TRANS_BURSTS_PER_CLUSTER);
  nsm_object_ptr->nsm_parser.transClusters = PL_getNSMTransClusters();
  nsm_object_ptr->nsm_parser.cidNorm = nsm_object_ptr->nsm_parser.transClusters * transBPC;
  nsm_object_ptr->nsm_parser.railNorm = nsm_object_ptr->nsm_parser.transClusters * transBPC;
  nsm_object_ptr->nsm_parser.noiseBursts = PL_getNSMNoiseBursts();
  nsm_object_ptr->nsm_parser.noiseScanBursts = PL_getNSMFreqScanBursts();

  // Threshold, timing, and disable parameters:
  nsm_object_ptr->nsm_params = *nsmParams;

  // The FNM Frequency Scan Density threshold is re-scaled
  // from 0-255 to 1-16.
  nsm_object_ptr->nsm_internal.fsFnmDensityScaled = (nsm_object_ptr->nsm_params.fsFnmDensity+16) >> 4;
}

void nsm2base_setCurrentFreq(nsm_object_t *nsm_object_ptr, uint16 frequency)
{
  nsm_object_ptr->nsm_statevars.currentFreq = frequency;
  DAQ_writeVar(TRANS_FREQUENCY, nsm_object_ptr->nsm_statevars.currentFreq);
#if CONFIG_NSM_GANYMEDE || CONFIG_NSM_CALLISTO
  nsm2base_setNoiseBurstDelays(nsm_object_ptr);
#endif
}


// Internal Functions.
//===========================
// These are for internal use, but can be called from public wrappers in
// the individual NSMs for debugging purposes.

uint16 nsm2base_executeFrequencyScan(nsm_object_t *nsm_object_ptr, uint16 freq_start, uint16 freq_end)
{
  uint16 k;
  DAQFrame_t *f;
  PLFrameData_t *noisescanFrame;
  uint16 disable_bit = 1 << freq_start;
  uint16 *fsimPtr = nsm_object_ptr->nsm_ims.fsim;
  uint16 best_frequency;

  nsm_object_ptr->nsm_internal.noiseScanFlag = 1;
  PL_setupFreqScanFrame();

  best_frequency = freq_start;
  fsimPtr += freq_start;
  for (k = freq_start; k < freq_end; ++k)
  {
    *fsimPtr = 0;
    if (!(nsm_object_ptr->nsm_params.disableFreq & disable_bit))
    {
      // Get the noise scan frame and parse it.
      nsm2base_setCurrentFreq(nsm_object_ptr, k);
      f = DAQ_getFrame(0);
      noisescanFrame = (PLFrameData_t *) f->buffer;

      // Calculate the fsIM.
      nsm2base_calcPowerIM(nsm_object_ptr, noisescanFrame->noiseScan);

      // Check whether we have the lowest fsIM.
      if (nsm_object_ptr->nsm_ims.fsim[best_frequency] > *fsimPtr)
      {
        best_frequency = k;
      }
      nsm_object_ptr->nsm_internal.fsTimer = f->timeStamp;
      DAQ_releaseFrame(f);
    }
    else if ((k == best_frequency) && (++best_frequency == freq_end))
    {
      best_frequency = freq_start;
    }
    disable_bit <<= 1;
    fsimPtr++;
  }
  nsm_object_ptr->nsm_internal.fsPrimed = 0;

  nsm_object_ptr->nsm_internal.noiseScanFlag = 0;
  PL_disableFreqScanFrame();

  return best_frequency;
}

void nsm2base_setCurrentState(nsm_object_t *nsm_object_ptr, uint16 state)
{
  switch (state)
  {
    case NSM_OFF_STATE:
      nsm_object_ptr->nsm_statevars.currentState = NSM_OFF_STATE;
      break;
    case NSM_HNM_STATE:
      nsm_object_ptr->nsm_statevars.currentState = NSM_HNM_STATE;
      break;
    case NSM_FNM_STATE:
      nsm_object_ptr->nsm_statevars.currentState = NSM_FNM_STATE;
      nsm_object_ptr->nsm_internal.powerimBitVector = 0;
      break;
  }
  nsm_object_ptr->nsm_internal.lowimFlag = 0;
  nsm_object_ptr->nsm_internal.lowimTime = 0;
}


// Internal Functions.
//===========================
// These are for internal use and cannot be called from public wrappers in
// the individual NSMs.

void nsm2base_measureRcvrOffsets(nsm_object_t *nsm_object_ptr)
{
  uint16 k, l;
  PLFrame_t *f;
  PLFrameData_t *offsetFrame;

  // Configure the offset frame.
  PL_setupRcvrOffsetFrame();

  // Acquire the offset frame.
  f = PL_getRcvrOffsetFrame();

  // Decode the frame into the regular frame type.
  offsetFrame = &f->data;
  for (l = 0; l < MAX_NOISE_RX; ++l)
  {
    nsm_object_ptr->rcvrOffsets[l] = 0;
  }
  for (k = 0; k < nsm_object_ptr->nsm_parser.noiseBursts; ++k)
  {
    for (l = 0; l < MAX_NOISE_RX; ++l)
    {
      nsm_object_ptr->rcvrOffsets[l] += offsetFrame->noise[l+k*MAX_NOISE_RX];
    }
  }
  for (l = 0; l < MAX_NOISE_RX; ++l)
  {
    nsm_object_ptr->rcvrOffsets[l] /= nsm_object_ptr->nsm_parser.noiseBursts;
  }

  // Release the frame.
  PL_releaseFrame(f);
  PL_disableRcvrOffsetFrame();
}

void nsm2base_calcPowerIM(nsm_object_t *nsm_object_ptr, uint16 *noisePtr)
{
  uint16 k, l;
  uint16 *rcvrOffsetsPtr = nsm_object_ptr->rcvrOffsets;
  uint16 *noiseRxPtr;
  int32 noiseScan_delta;
  uint32 noiseScan_calc;
  uint16 noiseBursts;
  uint16 *imPtr;

  if (!nsm_object_ptr->nsm_internal.noiseScanFlag)
  {
    noiseBursts = nsm_object_ptr->nsm_parser.noiseBursts;
    imPtr = &(nsm_object_ptr->nsm_ims.powerim);
  }
  else
  {
    noiseBursts = nsm_object_ptr->nsm_parser.noiseScanBursts;
    imPtr = nsm_object_ptr->nsm_ims.fsim + nsm_object_ptr->nsm_statevars.currentFreq;
  }

  *imPtr = 0;
  for (k = 0; k < MAX_NOISE_RX; ++k)
  {
    noiseRxPtr = noisePtr + k;
    noiseScan_calc = 0;
    for (l = 0; l < noiseBursts; ++l)
    {
      noiseScan_delta = (int32) *noiseRxPtr - (int32) *rcvrOffsetsPtr;
      noiseScan_calc += (uint32) (noiseScan_delta * noiseScan_delta);
      noiseRxPtr += MAX_NOISE_RX;
    }
    noiseScan_calc /= noiseBursts;

    // Write the calculated value to our pointer location, if needed.
    if (noiseScan_calc > *imPtr)
    {
      if (noiseScan_calc >= ((uint32) 1 << 16))
      {
        // If 16-bit IM is saturated, no need to continue.
        *imPtr = (uint16) (-1);
        break;
      }
      else
      {
        *imPtr = (uint16) noiseScan_calc;
      }
    }
    rcvrOffsetsPtr++;
  }
}

void nsm2base_calcCidIM(nsm_object_t *nsm_object_ptr, uint16 *hwPtr)
{
  uint16 k, l;
  uint16 *cidTxPtr;
  uint16 cidimtmp;

  nsm_object_ptr->nsm_ims.cidim = 0;
  for (k = 0; k < CONFIG_RX_MUX; ++k)
  {
    cidimtmp = 0;
    cidTxPtr = hwPtr + NSM_CID_HW_OFFSET + k * 2 * MAX_IMAGE_CLUSTERS;

    for (l = 0; l < nsm_object_ptr->nsm_parser.transClusters; ++l)
    {
      cidimtmp += *cidTxPtr;
      cidTxPtr += NSM_CID_HW_STEP;
    }
    cidimtmp /= nsm_object_ptr->nsm_parser.cidNorm;

    if (cidimtmp > nsm_object_ptr->nsm_ims.cidim)
    {
      nsm_object_ptr->nsm_ims.cidim = cidimtmp;
    }
  }
}

void nsm2base_calcRailIM(nsm_object_t *nsm_object_ptr, uint16 *hwPtr)
{
  uint16 k, l;
  uint16 *railTxPtr;
  uint16 railimtmp;

  nsm_object_ptr->nsm_ims.railim = 0;
  for (k = 0; k < CONFIG_RX_MUX; ++k)
  {
    railimtmp = 0;
    railTxPtr = hwPtr + NSM_RAIL_HW_OFFSET + k * 2 * MAX_IMAGE_CLUSTERS;

    for (l = 0; l < nsm_object_ptr->nsm_parser.transClusters; ++l)
    {
      railimtmp += *railTxPtr;
      railTxPtr += NSM_RAIL_HW_STEP;
    }
    railimtmp /= nsm_object_ptr->nsm_parser.railNorm;

    if (railimtmp > nsm_object_ptr->nsm_ims.railim)
    {
      nsm_object_ptr->nsm_ims.railim = railimtmp;
    }
  }
}

uint16 nsm2base_selectFirstFreq(nsm_object_t *nsm_object_ptr, uint16 freq_start, uint16 freq_end)
{
  uint16 k;
  uint16 disable_bit = 1 << freq_start;
  uint16 first_frequency;

  first_frequency = freq_start;
  for (k = freq_start; k < freq_end; ++k)
  {
    if (nsm_object_ptr->nsm_params.disableFreq & disable_bit)
    {
      if ((k == first_frequency) && (++first_frequency == freq_end))
      {
        first_frequency = freq_start;
      }
    }
    disable_bit <<= 1;
  }

  return first_frequency;
}

#if CONFIG_NSM_GANYMEDE || CONFIG_NSM_CALLISTO
void nsm2base_setNoiseBurstDelays(nsm_object_t *nsm_object_ptr)
{
  uint16 k;
  uint16 vals[MAX_NOISE_SCAN_BURSTS];
  uint32 burstDelay32;
  DAQVarId_t vars[MAX_NOISE_SCAN_BURSTS];
  DAQVarId_t var_addr = BURST_DELAY_ARRAY;

  if (!nsm_object_ptr->nsm_internal.noiseScanFlag)
  {
    for (k = 0; k < MAX_NOISE_BURSTS; ++k)
    {
      vars[k] = var_addr++;
      burstDelay32 = noiseBurstDelayCoeffs[k%4] * nsm_object_ptr->nsm_params.halfSensingPeriod[nsm_object_ptr->nsm_statevars.currentFreq];
      vals[k] = (uint16) (burstDelay32 >> 10);
    }
    DAQ_writeVars(vars, vals, MAX_NOISE_BURSTS);
  }
  else
  {
    for (k = 0; k < MAX_NOISE_SCAN_BURSTS; ++k)
    {
      vars[k] = var_addr++;
      burstDelay32 = noiseScanBurstDelayCoeffs[k%16] * nsm_object_ptr->nsm_params.halfSensingPeriod[nsm_object_ptr->nsm_statevars.currentFreq];
      vals[k] = (uint16) (burstDelay32 >> 10);
    }
    DAQ_writeVars(vars, vals, MAX_NOISE_SCAN_BURSTS);
  }
}
#endif
