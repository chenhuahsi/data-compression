#ifndef _GESTURE_DETECTOR_H
#define _GESTURE_DETECTOR_H 1

/* -----------------------------------------------------------------
 * Gesture Detector - Scans touch position data for gestures
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2015  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 *
 */

#include "calc2.h"

#define LPWG_DOUBLETAP_ENABLE         0x01
#define LPWG_SWIPE_ENABLE             0x02
#define LPWG_CIRCLE_ENABLE            0x08
#define LPWG_TRIANGLE_ENABLE          0x10
#define LPWG_VEE_ENABLE               0x20
#define LPWG_UNICODE_ENABLE           0x40

#define LPWG_UNICODE_SWITCH_C         0x01
#define LPWG_UNICODE_SWITCH_E         0x02
#define LPWG_UNICODE_SWITCH_W         0x04
#define LPWG_UNICODE_SWITCH_M         0x08
#define LPWG_UNICODE_SWITCH_S         0x10
#define LPWG_UNICODE_SWITCH_Z         0x20

#define LPWG_DOUBLETAP_DETECTED       0x03
#define LPWG_SWIPE_DETECTED           0x07
#define LPWG_MULTITAP_ENABLE          0x80

#define MULTITAP_FAILREASON_DISTANCE_INTERTAP 1
#define MULTITAP_FAILREASON_DISTANCE_PRESSREL 2
#define MULTITAP_FAILREASON_TIMEOUT_INTERTAP  3
#define MULTITAP_FAILREASON_MULTIFINGER       4
#define MULTITAP_FAILREASON_DELAYTIME         5
#define MULTITAP_FAILREASON_PALM_STATE        6
#define MULTITAP_FAILREASON_ACTIVE_AREA       7
#define MULTITAP_FAILREASON_TAP_COUNT         8
#define MULTITAP_FAILEDBUFFER_MAX             10

#define Flick_Swipe_Delta_Min_MM     4
#define Flick_Swipe_Delta_Min        Common2DAPI::getxMmToUnits(uint16(Flick_Swipe_Delta_Min_MM))
#define Flick_Swipe_Delta_X_Min      Common2DAPI::getxMmToUnits(uint16(Flick_Swipe_Delta_Min_MM))
#define Flick_Swipe_Delta_Y_Min      Common2DAPI::getyMmToUnits(uint16(Flick_Swipe_Delta_Min_MM))

#define  MAX_NUM_FINGER_FOR_GESTURE  2

enum {
  GESTURE_STATUS_BITORDER_MULTITAP1 = 0,
  GESTURE_STATUS_BITORDER_MULTITAP2 = 1,
  GESTURE_STATUS_BITORDER_SWIPE = 2,
};

typedef struct declGestureData
{
  uint16 numFingerPrev;
  uint16 xLastSeen;
  uint16 yLastSeen;
  uint16 xStartPos;
  uint16 yStartPos;
  #if cfg_hasLGSpecificSwipe
  uint16 xSwipeStart;
  uint16 ySwipeStart;
  #endif
  uint16 tapCnt                     : 8;
  uint16 tapTimer                   : 8;
  uint16 LPWG                       : 1;
  uint16 useWakeupGestureParameters : 1;  // For LPWG or StartupFastRelaxation parameters
  uint16 prevIndex                  : 4;
  uint16 trigTap                  : 1; // Tap:
  uint16 secondTap:        5; // Tap:
  uint16 tap                      : 3; // Tap: Holds values of type tapCode.
} GestureData;//DEFAULT_STRUCT_ALIGNMENT(struct declGestureData);

typedef struct
{
  uint16 first_tap;
  uint16 pre_xpos;
  uint16 pre_ypos;
  uint16 sum_xpos;
  uint16 sum_ypos;
  uint16 doTap_event;
} doTapInfo_t;

void clearDoTapInfo(void);
void clearDoMultiTapInfo(void);

typedef struct
{
  uint16 xPosition;
  uint16 yPosition;
  hostClassification_t classification;
}fingerPosInfo_t;

typedef enum
{
  NONE = 0,
  MISS,
  LIFT,
  TIMEOUT
}tapEvents_t;

typedef enum
{
  NO_TAP = 0,
  EARLY_TAP,
  SINGLE_TAP,
  TAP_AND_HOLD,
  DOUBLE_TAP,
  MULTI_TAP
}tapCode_t;

#if CONFIG_HAS_WAKEUPGESTURE
void gesture_init(calcStaticConfig_t *cfg);
void gesture_setEnabled(uint16 enable);
uint16 gesture_getDozeRejectTime();
void gesture_checkPowerReductionOptions();
void gesture_updateState(uint16 newTouch);
void gesture_detect(touchReport_t *report);
uint16 gesture_getLpwgFramePeriod();
uint16 gesture_allowLowPower();
uint16 gesture_isAlternateDozeSensing();
#else //CONFIG_HAS_WAKEUPGESTURE
ATTR_INLINE void gesture_init() {};
ATTR_INLINE void gesture_setEnabled(ATTR_UNUSED uint16 enable) {};
ATTR_INLINE uint16 gesture_getDozeRejectTime() { return 0; };
ATTR_INLINE void gesture_checkPowerReductionOptions() {};
ATTR_INLINE void gesture_updateState(ATTR_UNUSED uint16 newTouch) {};
ATTR_INLINE void gesture_detect(ATTR_UNUSED touchReport_t *report) {};
ATTR_INLINE uint16 gesture_getLpwgFramePeriod() { return 1; };
ATTR_INLINE uint16 gesture_allowLowPower() { return 1; };
ATTR_INLINE uint16 gesture_isAlternateDozeSensing() { return 0; };
#endif //CONFIG_HAS_WAKEUPGESTURE

#if CONFIG_HAS_WAKEUPGESTURE && CONFIG_HAS_LPWG_POWERREDUCTION
void gesture_lp_reinit();
void gesture_lp_setResetGestureCounters();
void gesture_lp_setWentToSleep();
void gesture_lp_clearWentToSleep();
void gesture_lp_decFalseActivationCounter();
void gesture_lp_incFalseActivationCounter();
void gesture_lp_clearContinuousActiveCounter();
uint16 gesture_lp_isLPWGSensing();
uint16 gesture_lp_isAlternateObjectDetect(uint16 objDetected);
uint16 gesture_lp_getDoRepeatForceDoze();
#else //CONFIG_HAS_WAKEUPGESTURE && CONFIG_HAS_LPWG_POWERREDUCTION
ATTR_INLINE void gesture_lp_reinit() {};
ATTR_INLINE void gesture_lp_setResetGestureCounters() {};
ATTR_INLINE void gesture_lp_setWentToSleep() {};
ATTR_INLINE void gesture_lp_clearWentToSleep() {};
ATTR_INLINE void gesture_lp_decFalseActivationCounter() {};
ATTR_INLINE void gesture_lp_incFalseActivationCounter() {};
ATTR_INLINE void gesture_lp_clearContinuousActiveCounter() {};
ATTR_INLINE uint16 gesture_lp_isLPWGSensing() { return 0; };
ATTR_INLINE uint16 gesture_lp_isAlternateObjectDetect(ATTR_UNUSED uint16 objDetected) { return 0; };
ATTR_INLINE uint16 gesture_lp_getDoRepeatForceDoze() { return 0; };
#endif //CONFIG_HAS_WAKEUPGESTURE && CONFIG_HAS_LPWG_POWERREDUCTION

#endif //_GESTURE_DETECTOR_H
