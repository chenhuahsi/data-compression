// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2013  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 3120 Scott Blvd
// Santa Clara, CA   95054
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: esd.h
// Description: All the esd modules, including esd detector, esd handler and esd mitigation
#include "ifp/ifp_common.h"

#ifdef __cplusplus
  extern "C"{
#endif
#if CONFIG_HAS_TDDI_ESD_DETECTOR || CONFIG_IFP_ESD_ACTIVEMODE
void esd_init(void);
#endif
#if CONFIG_HAS_TDDI_ESD_CVITIMEOUT_CHECK
void esd_detector(uint16 CVItimeout);
#else
void esd_detector(void);
#endif
#if CONFIG_HAS_TDDI_ESD_HANDLER
void esd_handler(void);
#endif
#if CONFIG_HAS_TDDI_ESD_IMAGE_CHECKER
enum
{
  ESD_NONE = 0,
  ESD_REASON_MAXDELTA = 1,
  ESD_REASON_SPIKE = 2,
  ESD_REASON_HIGHLIMIT = 3,
  ESD_REASON_LOWLIMIT = 4,
};
typedef struct
{
  int16 maximumThreshold;
  int16 spikeMax;
  int16 spikeMin;
  uint16 maxLimit;
  uint16 minLimit;
} esdDetectorConfig_t;
#define ESD_REASON_MAX 5

void esd_image_checker_init(void);
void esd_image_checker_configure(sensorParams_t *sensorParams);
uint16 esd_image_checker_detect(int16 *deltaImage, clumps_t *clumps);
void esd_image_checker_rawImage(uint16 * rawImage);
#endif
// macro
#define ESD_DETECTION_NO_FINGER 2
#define ESD_DETECTION_HAS_FINGER 1
#define ESD_DETECTION_BASELINE_ERROR 4

#if CONFIG_IFP_ESD_ACTIVEMODE
void force_exit_esdmode(uint16 value);
uint16 getEsdStartStatus(void);
void esd_activemode_init(calcStaticConfig_t *cfg, calcDynamicConfig_t *dcfg);
void esd_dynamic_params(uint16 esdModeCtrlFieldEnable,uint16 forceEnterEsdMode);
void esd_checkFirstTimeEnterESDmode(void);
void esd_calculation(uint16* rawImage,uint16 forceEnterEsdMode);
void esd_detection(void);
uint16 getESDmode(void);
int16 *ESD_getDelta(void);
#endif

#ifdef __cplusplus
}
#endif
