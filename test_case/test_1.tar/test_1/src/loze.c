/*                       COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2015 Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include "calc2.h"
#include "platform.h"
#include "loze.h"
#include <string.h>

#include "calc_print.h"

#define MAX(x, y) ((x) > (y) ? (x) : (y))

typedef enum {
  LP_ACTIVE = 0,
  LP_REJECT = 1,
  LP_RECALIBRATION = 2,
  LP_LOZE = 3,
} lozeState_t;

// static data
static lozeParams_t lozeConfig;
static struct {
  uint32 lozeHoldOffTimer;
  uint16 lozeBaseline[MAX(MAX_RX,MAX_TX)];
  uint16 firstStagePole;
  uint16 secondStagePole;
  int32 filterState;
  int32 lozeAggregateBaseline;
  uint16 profileLength;
  uint16 seedLozeStateMachine : 1;
  lozeState_t currentState;
} lozeState;

//static function definitions go here
static void loze_resetLozeHoldOffTimer(uint32 timeStamp);
static void loze_acquireLozeBaseline();
static int32 loze_calculateMean(uint16* vec, uint16 len);
static uint16 loze_lozeMode(uint16 rejectTime);
static uint16 loze_shapeDetector(uint16* profileData);
static int32 loze_bandPassFilter(int32 inputSample);
static void subArray(int16 *dst, uint16 *src1, uint16 *src2, uint16 len);
static void subFromArray(int16* vec, uint16 len, int16 val);
static uint16 loze_getBinCount(int16* vec, uint16 len, int16 intervalMin);
static int16 loze_computePeakWidth(int16* vec, int16 len);
static uint16 loze_findMaxIndexArray(int16 *pA, uint16 size);
static int16 loze_findMin (int16* pA, uint16 size);

void loze_init(lozeParams_t *lozeParams, uint16 numTx, uint16 numRx)
{
// declarations

// populate the lozeState struct
  lozeConfig = *lozeParams;
  lozeConfig.lozeBurstsPerCluster = lozeParams->lozeBurstsPerCluster;
  lozeConfig.lozeWakeUpThreshold = (lozeParams->lozeBurstsPerCluster*lozeParams->lozeWakeUpThreshold);
  lozeState.firstStagePole = 19661; //0.3 in 0p16
  lozeState.secondStagePole = 2621; //0.04 in 0p16
  lozeState.filterState = 0;
  lozeState.lozeAggregateBaseline = 0;
  lozeState.profileLength = (lozeConfig.lozeAxisSelect == 0)? numTx : numRx;
  lozeState.seedLozeStateMachine = 1;
  lozeState.currentState = LP_ACTIVE;
  lozeState.lozeHoldOffTimer = 0;
}

uint16 loze_lozeHandler(uint16 resetDoze, uint32 timeStamp, uint16 rejectTime)
{
  uint16 objDetected = 0;
  int32 deltaTime;
  if ((rejectTime == 0) && (resetDoze == 1))
  {
    if (lozeState.currentState == LP_RECALIBRATION)
    {
      PL_enterMode(mode_active);
      lozeState.currentState = LP_ACTIVE;
      lozeState.seedLozeStateMachine = 1;
    }
    else
    {
      loze_resetLozeHoldOffTimer(timeStamp);
      lozeState.seedLozeStateMachine = 1;
    }
    lozeState.seedLozeStateMachine = 1;
  }
  else
  {
    if (lozeState.lozeHoldOffTimer == 0)
      loze_resetLozeHoldOffTimer(timeStamp);
    if (rejectTime > 0)
    {
      lozeState.seedLozeStateMachine = 1;
      loze_acquireLozeBaseline();
      lozeState.currentState = LP_REJECT;
    }
    deltaTime = timeStamp - lozeState.lozeHoldOffTimer;
    if ((rejectTime == 0 ) && (deltaTime > lozeConfig.lozeHoldOff*9000)
        && (lozeState.seedLozeStateMachine == 1)) {
      loze_acquireLozeBaseline();
    }
    else if (deltaTime > (lozeConfig.lozeHoldOff*10000))
    {
      if (rejectTime == 0)
        lozeState.currentState = LP_LOZE;
      objDetected = loze_lozeMode(rejectTime);
    }
  }
  return objDetected;
}

static void loze_resetLozeHoldOffTimer(uint32 timeStamp)
{
  lozeState.lozeHoldOffTimer = timeStamp;
  lozeState.seedLozeStateMachine = 1;
  lozeState.currentState = LP_ACTIVE;
}

static void loze_acquireLozeBaseline()
{
  PLFrame_t *f;
  if (lozeState.seedLozeStateMachine == 1)
  {
    f = PL_getFrame(frame_loze);
    memcpy(lozeState.lozeBaseline, f->data.loze,
           lozeState.profileLength*sizeof(lozeState.lozeBaseline[0]));
    lozeState.filterState = loze_calculateMean(lozeState.lozeBaseline, lozeState.profileLength);
    lozeState.lozeAggregateBaseline = lozeState.filterState;
    lozeState.seedLozeStateMachine = 0;
    PL_releaseFrame(f);
  }
}

static int32 loze_calculateMean(uint16* vec, uint16 len)
{
  uint16 i;
  int32 sum32 = 0;
  for (i = 0; i < len; i++)
   sum32 += vec[i];
  sum32 /= len;
  return sum32;
}

static int32 loze_bandPassFilter(int32 inputSample)
{
  int32 difference;
  difference = inputSample - lozeState.filterState;
  lozeState.filterState += (((int32) difference*lozeState.firstStagePole)>>16);
  difference = lozeState.filterState - lozeState.lozeAggregateBaseline;
  lozeState.lozeAggregateBaseline += (((int32) difference*lozeState.secondStagePole)>>16);
  return difference;
}

static uint16 loze_lozeMode(uint16 rejectTime)
{
  uint16 objDetected = 0;
  uint32 lozeTimer, timeStamp;
  int32 deltaTime, filteredProfile;
  lozeTimer = 0;
  PL_enterMode(mode_loze);
  while(1) {
    calcDynamicConfig_t dcfg;
    commCommand_t cmd;
    PLFrame_t *f = NULL;
    uint16 profileData[MAX(MAX_TX,MAX_RX)];
    COMM_getDynamicConfig(&dcfg);
    cmd = COMM_getNextCommand();
    if (cmd.cmd != CMD_NONE || dcfg.noDoze != 0)
    {
      lozeState.currentState = LP_ACTIVE;
      PL_enterMode(mode_active);
      break;
    }
    f = PL_getFrame(frame_loze);
    timeStamp = f->timeStamp;
    if (lozeTimer == 0)
      lozeTimer = f->timeStamp;
    deltaTime = f->timeStamp - lozeTimer;
    memcpy(profileData, f->data.loze, lozeState.profileLength*sizeof(profileData[0]));
    PL_releaseFrame(f);
    if (lozeConfig.lozeAxisSelect == 1)
      COMM_postDebugReport(DBGREPORT_HYBRID_X_RAW, profileData, lozeState.profileLength);
    else
      COMM_postDebugReport(DBGREPORT_HYBRID_Y_RAW, profileData, lozeState.profileLength);
    COMM_endFrame();
    {
      int32 aggregatedProfile;
      aggregatedProfile = loze_calculateMean(profileData, lozeState.profileLength);
      filteredProfile = loze_bandPassFilter(aggregatedProfile);
    }
    filteredProfile = (filteredProfile >= 0)? filteredProfile : -1*filteredProfile;

    if (filteredProfile > lozeConfig.lozeWakeUpThreshold) {
      if ((lozeState.currentState == LP_REJECT) && (deltaTime  < rejectTime*100000))
        continue;
      else {
        if (lozeConfig.lozeEnablePocketReject == 1)
        objDetected = loze_shapeDetector(profileData);
        else
          objDetected = 1;
        if (objDetected == 1)
        {
          loze_resetLozeHoldOffTimer(timeStamp);
          lozeState.seedLozeStateMachine = 1;
          lozeState.currentState = LP_ACTIVE;
          PL_enterMode(mode_active);
          break;
        }
      }
    }
    if ((lozeState.currentState == LP_REJECT) && (deltaTime > rejectTime*100000))
      break;
    if (deltaTime > lozeConfig.lozeRecalibrationInterval*10000) {
      memcpy(lozeState.lozeBaseline, profileData, lozeState.profileLength*sizeof(profileData[0]));
      lozeState.currentState = LP_RECALIBRATION;
      break;
    }
  }
  return objDetected;
}

static uint16 loze_shapeDetector (uint16* profileData)
{
  uint16 objDetected = 0;
  uint16 binCount1, binCount2, maxInd;
  int16 peakWidth, minVal, smallObjectThreshold, largeObjectThreshold;
  int16 deltaProfile[MAX(MAX_RX,MAX_TX)];
  uint16 halfLength = (lozeState.profileLength >> 1);
  smallObjectThreshold = (int16) (lozeConfig.lozeGloveThreshold*lozeConfig.lozeBurstsPerCluster);
  largeObjectThreshold = (int16) (lozeConfig.lozeFingerThreshold*lozeConfig.lozeBurstsPerCluster);
  // remove baseline
  subArray(deltaProfile, profileData, lozeState.lozeBaseline, lozeState.profileLength);
  maxInd = loze_findMaxIndexArray(deltaProfile, lozeState.profileLength);
  if (deltaProfile[maxInd] < 0) {
    memcpy(lozeState.lozeBaseline, profileData, lozeState.profileLength*sizeof(profileData[0]));
    return objDetected;
  }

  // min correct; in case baseline is corrupted.
  minVal = loze_findMin(deltaProfile, lozeState.profileLength);
  subFromArray(deltaProfile, lozeState.profileLength, minVal);
  peakWidth = loze_computePeakWidth(deltaProfile, lozeState.profileLength);

  binCount1 = loze_getBinCount(deltaProfile, lozeState.profileLength, largeObjectThreshold);
  binCount2 = loze_getBinCount(deltaProfile, lozeState.profileLength, smallObjectThreshold);

  if (binCount1 > halfLength) {
    objDetected = 0;
  }
  else if ((binCount1 <= 3) && (binCount1 >= 1)){// && (peakWidth <= 768)) {
    // 3 in Q8.8 is 768
    objDetected = 1;
  }
  else if ((binCount2 > 0) && (binCount1 < 1) && (peakWidth >= 128) && (peakWidth <= 1024)) {
    // 0.5 in Q8.8 is 128, 4.0 in Q8.8 is 1024
    objDetected = 1;
  }

  return objDetected;
}

static void subArray(int16 *dst, uint16 *src1, uint16 *src2, uint16 len)
{
  for (; len > 0; len--)
    *dst++ = *src1++ - *src2++;
}

static void subFromArray(int16* vec, uint16 len, int16 val)
{
  while(len--)
  {
    *vec -= val;
    vec++;
  }
}

static uint16 loze_getBinCount(int16* vec, uint16 len, int16 intervalMin)
{
  uint16 i = 0;
  while (len--)
  {
    if (*vec > intervalMin)
      i += 1;
    vec++;
  }
  return i;
}

static uint16 loze_findMaxIndexArray(int16 *pA, uint16 size)
{
  int16 maxV = *pA;
  uint16 maxIndex = 0;
  uint16 index = 0;
  while (size--)
  {
    if (*pA >= maxV)
    {
      maxV = *pA;
      maxIndex = index;
    }
    index++;
    pA++;
  }
  return maxIndex;
}

static int16 loze_findMin (int16* pA, uint16 size)
{
  int16 minV = *pA;
  while (size--)
  {
    if (*pA < minV)
      minV = *pA;
    pA++;
  }
  return minV;
}

static int16 loze_computePeakWidth(int16* vec, int16 len)
{
  uint16 peakIdx;
  int16 peak, peakThreshold, peakWidth, i;
  int16 rightIdx = len - 1;
  int16 leftIdx = 0;
  int16 x1 = 0;
  int16 x2 = 0;

  peakIdx = loze_findMaxIndexArray(vec, len);
  peak = vec[peakIdx];
  peakThreshold = (peak >> 1); // peak * 0.5

  // search from either side in and find the first index that crosses
  // half-max amplitude
  for (i = 0; i < len; i++)
  {
    if (vec[i] > peakThreshold)
    {
      leftIdx = i;
      break;
    }
  }

  for (i = len-1; i >= 0; i--)
  {
    if (vec[i] > peakThreshold)
    {
      rightIdx = i;
      break;
    }
  }

  x2 = 256*leftIdx; // in Q8.8
  x1 = 256*rightIdx; // in Q8.8

  if (leftIdx != 0)
  {
    x2 -= 256;
    x2 += (int16) ((int32) 256*(peakThreshold - vec[leftIdx-1])/(vec[leftIdx] - vec[leftIdx-1]));
  }
  if (rightIdx != (int16) len - 1)
  {
    x1 += 256;
    x1 -= (int16) ((int32) 256*(peakThreshold - vec[rightIdx+1])/(vec[rightIdx]-vec[rightIdx+1]));
  }
  peakWidth = x1 - x2;

  return peakWidth;
}

uint16 loze_isInActiveMode()
{
  return lozeState.currentState == LP_ACTIVE;
}
