// -----------------------------------------------------------------
// Grip Suppression
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//


#include "grip_suppression.h"

#if CONFIG_GRIPSUPPRESSION_RULE2
Pos_SensorInfo Touch_SensorInfor[MAX_OBJECTS];
Pos_SensorInfo Touch_SensorInfor_Report[MAX_OBJECTS];
#endif

  static struct {
   gripSupresParams_t scfg;
   uint16 enabled;
  } params;

  #if CONFIG_IFP_GRIP_SUPPRESS_GLOVE
   static uint16 xOffset;
   static uint16 yOffset;
  #endif

  #if (defined(cfg_Grip_DEBUG) && cfg_Grip_DEBUG)
    int16 GripStatus[9];
  #endif

#if CONFIG_GRIPSUPPRESSION_RULE2

typedef enum {
  Grip_White =0, // suppression free
  Grip_Red   , // suppression always
  Grip_Pink  , // suppression conditonal
}POSCOLOR;


static uint16 GripPinkoffset;
static uint16 GripEnableOnXAxis;
static uint16 GripFingerWidth;
static int16  GripDebounceThreshold;
static uint16 GripJitterXMoveThreshold;
static uint16 GripJitterYMoveThreshold;
static uint16 GripTapDebounce;
static uint16 GripTapEnableBit;
static uint16 GripJitterEnableBit;
static uint16 GripIIROrder;

static uint16 GripHasFinger[MAX_OBJECTS];
static POSCOLOR GripLandedRegion[MAX_OBJECTS];
static uint16 GripLandPositionY[MAX_OBJECTS];
static uint16 GripMaxYdistance[MAX_OBJECTS];
static uint16 GripIsSuppressed[MAX_OBJECTS];
static int16 PreXpos[MAX_OBJECTS];
static int16 PreYpos[MAX_OBJECTS];
static uint16 IIRfiltercount[MAX_OBJECTS];
static uint16 Touchlife[MAX_OBJECTS];
static uint16 GripMaxXDistance[MAX_OBJECTS];
static uint16  Grip_landX[MAX_OBJECTS];
static reportPos_t PreReportinfo[MAX_OBJECTS];
static uint16 preGripstatus[MAX_OBJECTS];
static uint16 MaxRxwidth[MAX_OBJECTS];
static uint16 MaxTxwidth[MAX_OBJECTS];
//static uint16 IslandinDarkzone[MAX_OBJECTS];

//#define TX_EDGE_MAX 15
//#define RX_EDGE_MAX 28//30
uint16 TX_EDGE_MAX; //15
uint16 RX_EDGE_MAX; //28//30
#define TX_EDGE_MIN 0
#define RX_EDGE_MIN 0

uint16 HX_GripDebug[MAX_OBJECTS];
uint16 HX_GripDebug2[MAX_OBJECTS];
uint16 HX_GripDebug3[MAX_OBJECTS];
uint16 HX_GripDebug4[MAX_OBJECTS];

int16 VERTICAL_RECTANGLE_X ;//20//65
int16 VERTICAL_RECTANGLE_Y ;//260
uint16 RxTxSigRatioThr;

uint16 Tx_SigRatio;
uint16 HX_Griped_Status[MAX_OBJECTS];
uint16 Darkconerlive1;
uint16 Darkconerlive2;
uint16 Darkconerlive3;
uint16 Darkconerlive4;
uint16 TapSuppressLeft;
uint16 TapSuppressRight;
int16 GripXMaxPos;
int16 GripYMaxPos;
#define DARKCORNER_LIFE 100
#define TAPDARKZONE 100
int16 poscurrentX[MAX_OBJECTS];
int16 poscurrentY[MAX_OBJECTS];


#define IIR_ORDER 4

#endif

#if CONFIG_GRIPSUPPRESSION
  void gripSuppression_enabled(uint16 enable)
  {
    params.enabled = enable;
  }
  void gripSuppression_init(calcStaticConfig_t *cfg)
  {
    params.scfg = cfg->gripSupresParams;
#if CONFIG_IFP_GRIP_SUPPRESS_GLOVE
    xOffset = params.scfg.borderWidth;
    yOffset = params.scfg.borderWidth;
#endif
  }
#endif

#if CONFIG_IFP_GRIP_SUPPRESS_GLOVE
  void clearPositions(reportPos_t* position)
  {
    position->classification = hostClassification_none;
    position->z = 0;
    position->xMeas = 0;
    position->yMeas = 0;
    position->xWidth = 0;
    position->yWidth = 0;
  }

  uint16 gloveGripOnEdge(uint16 isGlove,int16 currX, int16 currY)
  {
    uint16 gloveGrip = 0;
    if((isGlove) && (currX <= (int16)xOffset || currX >= (int16)(params.scfg.xMax - xOffset)) && params.scfg.gloveGripEnableOnYAxis)
    {
      gloveGrip = 1;
    }
    else if((isGlove) && (currY <= (int16)yOffset || currY >= (int16)(params.scfg.yMax - yOffset)) && params.scfg.gloveGripEnableOnXAxis)
    {
      gloveGrip = 1;
    }
    return gloveGrip;
  }

  void applyGloveGripSuppression(reportData_t *reportData)
  {
    static uint16 glovedlandedInGripRegion[MAX_OBJECTS];
    static uint16 HasFinger[MAX_OBJECTS];
    reportPos_t *fingerIndex = &reportData->pos[0];
    uint16 isGlove = 0;
    uint16 i;

    for (i = 0; i < MAX_OBJECTS; i++, fingerIndex++)
    {
      if (reportData->pos[i].classification == hostClassification_glove)
      {
        isGlove = 1;
      }
      else
      {
        isGlove = 0;
      }

      if (fingerIndex->z == 0)
      {
        HasFinger[i] = 0;
      }
      else
      {
        if (HasFinger[i] == 0)
        {
          // No filter if first frame of new finger
          // (first touch position is unreliable)
          HasFinger[i] = 1;
          if(gloveGripOnEdge(isGlove, fingerIndex->xMeas, fingerIndex->yMeas))
          {
            clearPositions(fingerIndex);
            glovedlandedInGripRegion[i] = 1;
          }
          continue;
        }

        if(gloveGripOnEdge(isGlove, fingerIndex->xMeas, fingerIndex->yMeas) && glovedlandedInGripRegion[i])
        {
          // supress glove in Glove region
          clearPositions(fingerIndex);
        }
        else if(isGlove && glovedlandedInGripRegion[i])
        {
          // Landed in glove region and moved into the centre, so clear the flag
          glovedlandedInGripRegion[i] = 0;
        }
      }
    }
  }
#endif

#if CONFIG_GRIPSUPPRESSION
  void gripSuppression_apply(reportData_t *reportDataPtr)
  {
     //reportData_t *reportDataPtr = &reportTouchData->touch;

     if (reportDataPtr == NULL_PTR)
     {
        return;
     }
    #if CONFIG_IFP_GRIP_SUPPRESS_GLOVE
      applyGloveGripSuppression(reportDataPtr);
    #endif
    if (params.enabled && (params.scfg.gripInnerXmin || params.scfg.gripInnerXmax || params.scfg.gripInnerYmin || params.scfg.gripInnerYmax ||
        params.scfg.gripOuterXmin || params.scfg.gripOuterXmax || params.scfg.gripOuterYmin || params.scfg.gripOuterYmax))
    {
      reportPos_t *fingerIndex = &reportDataPtr->pos[0];
      int16 PalmXloc    = -1;
      int16 PalmYloc    = -1;
      int16 HasPalm     =  0;
      int16 HasFingers  =  0;
      int16 PalmInGreenZone = 1;  // guess palm, if any, in near center (green zone)

      int16 DynamicWyLimit = 0;
      int16 RedZoneSuppressed = 0;
      int16 FingerInPinkZone = 0;

      int16 PinkThumbSuppressed = 0;
      int16 AllFingersSuppressed = 0;
      uint16 i;

      for(i = 0; i < MAX_OBJECTS; i++)
      {
        if (fingerIndex->classification == hostClassification_palm)  // search for palm and note location
        {
          PalmXloc =  fingerIndex->xMeas;
          PalmYloc =  fingerIndex->yMeas;
          HasPalm = 1;
        }
        if (fingerIndex->classification == hostClassification_finger
#if CONFIG_IFP_GRIP_SUPPRESS_GLOVE
            || fingerIndex->classification == hostClassification_glove
#endif
        )
        {
          HasFingers++;
        }
        fingerIndex++;
      }

      if (HasPalm)  // test is palm is near edges ...
      {
        if ((PalmXloc < params.scfg.gripInnerXmin) || (PalmXloc > params.scfg.gripInnerXmax) || (PalmYloc < params.scfg.gripInnerYmin) || (PalmYloc > params.scfg.gripInnerYmax))
        {
          PalmInGreenZone = 0;
        }
      }


      if (HasPalm && PalmInGreenZone && HasFingers)  // "palm" is near middle (presume to be thigh)
      {
        AllFingersSuppressed = 1;
      }

      if (HasFingers == 0)
      {
        RedZoneSuppressed = 0;
      }

      fingerIndex = &reportDataPtr->pos[0];
      for(i = 0; i < MAX_OBJECTS; i++)
      {
          if (fingerIndex->classification == hostClassification_finger
#if CONFIG_IFP_GRIP_SUPPRESS_GLOVE
              || fingerIndex->classification == hostClassification_glove
#endif
          )
          {
            if (AllFingersSuppressed)
            {
              fingerIndex->classification = hostClassification_none;
            }
            else
            {
              int16 xPos  = fingerIndex->xMeas;
              int16 yPos  = fingerIndex->yMeas;
              int16 Wy    = fingerIndex->yWidth;
              int16 xLandPos  = reportDataPtr->land[i].x;
              int16 yLandPos  = reportDataPtr->land[i].y;
              FingerInPinkZone = 0;

              // pink zone test ... (includes red zone)
              if ((xPos < params.scfg.gripInnerXmin) || (xPos > params.scfg.gripInnerXmax) || (yPos < params.scfg.gripInnerYmin) || (yPos > params.scfg.gripInnerYmax))
              {
                int16 DynamicWyDrop = params.scfg.gripInnerWyThreshold - params.scfg.gripOuterWyThreshold;
                FingerInPinkZone = 1;
                DynamicWyLimit = params.scfg.gripInnerWyThreshold; // guess
                if (xPos < params.scfg.gripInnerXmin)
                {
                  DynamicWyLimit = params.scfg.gripOuterWyThreshold + ((DynamicWyDrop*xPos)/params.scfg.gripInnerXmin);
                }
                else if (xPos > params.scfg.gripInnerXmax)
                {
                  DynamicWyLimit = params.scfg.gripOuterWyThreshold + ((DynamicWyDrop*(params.scfg.xMax-xPos))/(params.scfg.xMax-params.scfg.gripInnerXmax));
                }
              }
              if (FingerInPinkZone && ( Wy >= DynamicWyLimit))
              {
                // If the suppressed finger is landed in non-Red region, then do not ignore it!
                if((xLandPos < params.scfg.gripOuterXmin) || (xLandPos > params.scfg.gripOuterXmax) ||
                  (yLandPos < params.scfg.gripOuterYmin) || (yLandPos > params.scfg.gripOuterYmax))
                {
                PinkThumbSuppressed = 1;
                fingerIndex->classification = hostClassification_none;
                }
              }
              // red zone test ... (red fingers suppressed if other fingers are present in pink or green zones)
              {//added for calc2forpc
              int16 ThisFingerInRedZone = 0;
              if ((xPos < params.scfg.gripOuterXmin) || (xPos > params.scfg.gripOuterXmax) || (yPos < params.scfg.gripOuterYmin) || (yPos > params.scfg.gripOuterYmax))
              {
                ThisFingerInRedZone = 1;
              }
              if ((HasFingers >= params.scfg.minFingersEnabled) && ThisFingerInRedZone)
              {
                RedZoneSuppressed = 1;
              }
              if ((HasFingers < params.scfg.minFingersEnabled) && (!ThisFingerInRedZone))
              {
                RedZoneSuppressed = 0;
              }
              if (RedZoneSuppressed && ThisFingerInRedZone)
              {
                // If the suppressed finger is landed in non-Red region, then do not ignore it!
                if((xLandPos < params.scfg.gripOuterXmin) || (xLandPos > params.scfg.gripOuterXmax) ||
                  (yLandPos < params.scfg.gripOuterYmin) || (yLandPos > params.scfg.gripOuterYmax))
                {
                  fingerIndex->classification = hostClassification_none;  // don't report this finger
                }
              }
              }//added for calc2forpc
            }
          }
        fingerIndex++;
      }
      #if (defined(cfg_Grip_DEBUG) && cfg_Grip_DEBUG)
        GripStatus[0]  = HasPalm;                  // true if palm is present
        GripStatus[1]  = PalmInGreenZone;          // true if palm is near center
        GripStatus[2]  = HasFingers;               // fingers present (count)
        GripStatus[3]  = reportDataPtr->freshData;                // bit mask of reportable objects
        GripStatus[4]  = FingerInPinkZone;         // true if finger found outside green zone
        GripStatus[5]  = PinkThumbSuppressed;      // true if thumb is suppressed
        GripStatus[6]  = RedZoneSuppressed;        // true if thumb or finger(s) in red zone is suppressed
        GripStatus[7]  = AllFingersSuppressed;     // true when palm found near center (gree zone) - with fingers present
        GripStatus[8]  = DynamicWyLimit;           // Wy limit imposed for last finger evaluated (was in pink or red zone)
      #endif
    }
  }
#endif

#if CONFIG_GRIPSUPPRESSION_RULE2
/*
This is the beginning of second grip suppression impplementation.
There is another grip suppression implementation which is totally different with the code above.
These two algorithm can't be enabled at the same time. */

void GripclearPositions(reportPos_t* position)
{
 //HX_GripDebug[0]++;
  position->classification = hostClassification_none;
  position->z = 0;
  position->xMeas = 0;
  position->yMeas = 0;
  position->xWidth = 0;
  position->yWidth = 0;
}

void GripInit ()
{
  uint16 i;

  for(i=0;i<MAX_OBJECTS ;i++)
  {
    GripHasFinger[i]=0;
    GripLandedRegion[i]=Grip_White;
    GripIsSuppressed[i]=0;
    preGripstatus[i]=0;
    GripLandPositionY[i]=0xffff;
    Grip_landX[i]=0xffff;
    poscurrentX[i]=0xffff;
    poscurrentY[i]=0xffff;
    GripMaxYdistance[i]=0;
    GripMaxXDistance[i]=0;
    PreXpos[i]=-1;
    PreYpos[i]=-1;
  }
}

#define POS_ABS(x)      (((x)<0)? -(x): (x))

void GripConfig(ifpConfig_t *ifpConfig)
{
  gripsuppressionrule2_t *ptrgrip_suppressionrule2= &ifpConfig->grip_suppressionrule2;
  GripPinkoffset =ptrgrip_suppressionrule2->gripPinkoffset;//HX_Gripconfig[1];//20;
  GripEnableOnXAxis =ptrgrip_suppressionrule2->gripConfig1&0x1; //HX_Gripconfig[2];//1;
  GripTapEnableBit = (ptrgrip_suppressionrule2->gripConfig1&0x02)>>1;
  GripJitterEnableBit = (ptrgrip_suppressionrule2->gripConfig1&0x04)>>2;//+960;
  GripFingerWidth=((ptrgrip_suppressionrule2->gripConfig1&0xF0)>>4);//8+((Func51::getGripConfig()&0xF0)>>4);
  GripDebounceThreshold=((ptrgrip_suppressionrule2->gripRedOffset &0xF0)>>4)*33;
  GripIIROrder = ((ptrgrip_suppressionrule2->gripRedOffset &0x0F)*2);
  GripJitterXMoveThreshold=((ptrgrip_suppressionrule2->gripConfig2&0xF0)>>4)*13;// 200 is limit since there is only 4 tx sensor range at corner
  GripJitterYMoveThreshold=((ptrgrip_suppressionrule2->gripConfig2&0x0F))*13;
  GripTapDebounce=((ptrgrip_suppressionrule2->gripTap&0x0f))*5;
  Tx_SigRatio = ((ptrgrip_suppressionrule2->gripTap&0xf0)>>4)*10;

  VERTICAL_RECTANGLE_X = ptrgrip_suppressionrule2->gripVDarkX*2;//20//65
  VERTICAL_RECTANGLE_Y = ptrgrip_suppressionrule2->gripVDarkY*2;//260
  RxTxSigRatioThr =  ptrgrip_suppressionrule2->gripHDarkX;


  TX_EDGE_MAX = ifpConfig->sensorParams.txCount-1;
  RX_EDGE_MAX = ifpConfig->sensorParams.rxCount-1;
  GripXMaxPos = params.scfg.xMax;
  GripYMaxPos = params.scfg.yMax;

 }

POSCOLOR GripPositionColor(hostClassification_t classification, int16 currX, int16 currY)
{
  POSCOLOR positionColor = Grip_White;
  if(classification== hostClassification_glove)
  {
    return Grip_White;
  }
  positionColor = Grip_White;
  if(currX < (int16)GripPinkoffset || currX > (int16)(GripXMaxPos - GripPinkoffset))
  {
    positionColor = Grip_Pink;
  }
  currY=currY;
  return positionColor;
}
// left bottom
uint16 IsDarkcornerzone1(int16 currX, int16 currY )
{
  uint16 result;

  if((currX<VERTICAL_RECTANGLE_X)&&(currY>(GripYMaxPos-VERTICAL_RECTANGLE_Y)))
  {
   result =1;
  }
  else
  {
   result =0;
   }

  return result;
}
// left top
uint16 IsDarkcornerzone2(int16 currX, int16 currY )
{
  uint16 result;

  if((currX<VERTICAL_RECTANGLE_X)&&(currY<VERTICAL_RECTANGLE_Y))
  {
   result =1;
  }
  else
  {
   result =0;
   }

  return result;
}
// right bottom
uint16 IsDarkcornerzone3(int16 currX, int16 currY )
{
  uint16 result;

  if(currX>(GripXMaxPos-VERTICAL_RECTANGLE_X)&&(currY>(GripYMaxPos-VERTICAL_RECTANGLE_Y)))
  {
   result =1;
  }
  else
  {
   result =0;
   }

  return result;
}
// right top
uint16 IsDarkcornerzone4(int16 currX, int16 currY )
{
  uint16 result;

  if(currX>(GripXMaxPos-VERTICAL_RECTANGLE_X)&&(currY<VERTICAL_RECTANGLE_Y))
  {
   result =1;
  }
  else
  {
   result =0;
   }

  return result;
}
void GripZIsZero( uint16 i, reportPos_t *fingerIndex)
{
  fingerIndex->classification= PreReportinfo[i].classification ;
  fingerIndex->xMeas         = PreReportinfo[i].xMeas          ;
  fingerIndex->yMeas         = PreReportinfo[i].yMeas          ;
  fingerIndex->z             = PreReportinfo[i].z              ;
  fingerIndex->xWidth        = PreReportinfo[i].xWidth         ;
  fingerIndex->yWidth        = PreReportinfo[i].yWidth         ;
  fingerIndex->txPos         = PreReportinfo[i].txPos          ;
  fingerIndex->rxPos         = PreReportinfo[i].rxPos          ;
  //HX_GripDebug[0]++;
  //HX_GripDebug[1]=(uint16)PreReportinfo[i].xMeas;
  //HX_GripDebug[2]=(uint16)PreReportinfo[i].yMeas;
  if((GripIsSuppressed[i]<1)&&(PreReportinfo[i].z>0))
  {
    if(Darkconerlive1&&(IsDarkcornerzone1(PreReportinfo[i].xMeas,PreReportinfo[i].yMeas)==1))
    {
      GripIsSuppressed[i]=GripIsSuppressed[i];
    }
    else if (Darkconerlive2&&(IsDarkcornerzone2(PreReportinfo[i].xMeas,PreReportinfo[i].yMeas)==1))
    {
      GripIsSuppressed[i]=GripIsSuppressed[i];
    }
    else if (Darkconerlive3&&(IsDarkcornerzone3(PreReportinfo[i].xMeas,PreReportinfo[i].yMeas)==1))
    {
      GripIsSuppressed[i]=GripIsSuppressed[i];
    }
    else if(Darkconerlive4&&(IsDarkcornerzone4(PreReportinfo[i].xMeas,PreReportinfo[i].yMeas)==1))
    {
      GripIsSuppressed[i]=GripIsSuppressed[i];
    }
    else if(TapSuppressLeft&&(PreReportinfo[i].xMeas<TAPDARKZONE))
    {
      GripIsSuppressed[i]=GripIsSuppressed[i];
    }
    else if(TapSuppressRight&&(PreReportinfo[i].xMeas>(GripXMaxPos-TAPDARKZONE)))
    {
      GripIsSuppressed[i]=GripIsSuppressed[i];
    }
    else
    {
      GripIsSuppressed[i]=10;
    }

    //HX_GripDebug[3]++;
  }

}

void applyGripSuppressionRule( reportData_t *reportData)
{

  reportPos_t *fingerIndex = &reportData->pos[0];
  uint16 zerofingercount =0;
  uint16 i;


    for (i = 0; i < MAX_OBJECTS; i++, fingerIndex++)
    {
      poscurrentX[i]=fingerIndex->xMeas;
      poscurrentY[i]=fingerIndex->yMeas;
      if (fingerIndex->z == 0)
      {
       zerofingercount++;

       if(zerofingercount==MAX_OBJECTS)
       {
         Darkconerlive1=0;
         Darkconerlive2=0;
         Darkconerlive3=0;
         Darkconerlive4=0;
         TapSuppressLeft =0;
         TapSuppressRight = 0;
       }

       if(GripTapEnableBit
          &&(MaxRxwidth[i]<(GripFingerWidth+2)&&MaxTxwidth[i]<(GripFingerWidth+2))
          &&(1==GripHasFinger[i])
          &&(Touchlife[i]<(GripTapDebounce)&&Touchlife[i]>0)
           &&(POS_ABS(PreReportinfo[i].xMeas-(int16)Grip_landX[i])<100)
           &&(POS_ABS(PreReportinfo[i].yMeas-(int16)GripLandPositionY[i])<100)
          )
       {
         GripZIsZero(i,fingerIndex);
       }
       else
       {

         GripIsSuppressed[i]=0;
       }

        GripHasFinger[i] = 0;
        GripLandedRegion[i]=Grip_White;

        GripLandPositionY[i]=0xffff;
        Grip_landX[i]=0xffff;
        GripMaxYdistance[i]=0;
        GripMaxXDistance[i]=0;
        PreXpos[i]=-1;
        PreYpos[i]=-1;
        IIRfiltercount[i]=0;
        Touchlife[i]=0;

        MaxRxwidth[i]=0;
        MaxTxwidth[i]=0;
        HX_Griped_Status[i]=0;

        HX_GripDebug3[i]=0;
        HX_GripDebug[i]=0;
        HX_GripDebug2[i]=0;
        HX_GripDebug4[i]=0;
        //continue;
      }
      else
      {
        int16 currX = fingerIndex->xMeas;
        int16 currY = fingerIndex->yMeas;


       if(Touchlife[i]<=0xfff0)
          Touchlife[i]++;

        if(0xffff!=GripLandPositionY[i])
        {
          uint16 deltay;

          deltay=(GripLandPositionY[i]>(uint16)currY)?(GripLandPositionY[i]-currY):(currY-GripLandPositionY[i]);
          if(deltay>GripMaxYdistance[i])
          {
            GripMaxYdistance[i]=deltay;
          }
        }
        if(0xffff!=Grip_landX[i])
        {
         uint16 deltax;

         deltax=(Grip_landX[i]>(uint16)currX)?(Grip_landX[i]-currX):(currX-Grip_landX[i]);
          if(deltax>GripMaxXDistance[i])
          {
            GripMaxXDistance[i]=deltax;
          }
        }
        // TKM_CR: Can remove?
        if (GripHasFinger[i] == 0)
        {
          GripHasFinger[i] = 1;
          GripIsSuppressed[i]=0;
          GripLandedRegion[i]=Grip_White;
          GripLandPositionY[i] =(uint16)currY;
          Grip_landX[i]=(uint16)currX;
          PreXpos[i]=currX;
          PreYpos[i]=currY;

          if(Grip_Red==GripPositionColor(reportData->pos[i].classification, currX, currY))
          {
              GripLandedRegion[i] = Grip_Red;

          }
          else if(Grip_Pink==GripPositionColor(reportData->pos[i].classification, currX, currY))
          {

            GripLandedRegion[i] = Grip_Pink;
          }

        }

    if(Grip_White!=GripLandedRegion[i])
    {
       if(0==GripIsSuppressed[i])
       {
        if((Touch_SensorInfor_Report[i].Tx_max==(TX_EDGE_MAX))||(Touch_SensorInfor_Report[i].Tx_min==(TX_EDGE_MIN)))
        {

           uint16 TxSigSizeRatio ;

           if(Touch_SensorInfor_Report[i].Rx_width>0)
           {
              TxSigSizeRatio = Touch_SensorInfor_Report[i].Tx_Ratio*10/Touch_SensorInfor_Report[i].Rx_width;
           }
           else
           {
              TxSigSizeRatio = 0;
           }

           HX_GripDebug[i]=TxSigSizeRatio;

           if((Touch_SensorInfor_Report[i].Rx_max==RX_EDGE_MAX)||(Touch_SensorInfor_Report[i].Rx_min==0))
           {
             uint16 RxSigSizeRatio;
             uint16 RxTxRatio;
             uint16 TxRxRatio=0;

             if(Touch_SensorInfor_Report[i].Tx_width>0)
             {
                 RxSigSizeRatio = Touch_SensorInfor_Report[i].Rx_Ratio*10/Touch_SensorInfor_Report[i].Tx_width;
             }
             else
             {
                 RxSigSizeRatio = 0;
             }

             HX_GripDebug2[i]= RxSigSizeRatio;

             if(TxSigSizeRatio>0)
             {
                RxTxRatio = RxSigSizeRatio*10/TxSigSizeRatio;
             }
             else
             {
                RxTxRatio=0;
             }
             HX_GripDebug3[i]= RxTxRatio;

             if(RxSigSizeRatio>0)
             {
               TxRxRatio = TxSigSizeRatio/RxSigSizeRatio;
             }

             HX_GripDebug4[i]= TxRxRatio;

              if(Touchlife[i]<GripTapDebounce)
             {
                 GripIsSuppressed[i]=0;
             }
             else
             {
                GripIsSuppressed[i]=22;

               if((MaxRxwidth[i]>(GripFingerWidth))||(MaxTxwidth[i]>(GripFingerWidth)))
               {
                   GripIsSuppressed[i]=1;
                   HX_Griped_Status[i]=3;
               }
               else if (MaxRxwidth[i]<2)
               {
                   GripIsSuppressed[i]=1;
                   HX_Griped_Status[i]=4;
               }
               else if(RxTxRatio>RxTxSigRatioThr) //15
                {
                    GripIsSuppressed[i]=1;
                    HX_Griped_Status[i]=5;
                }

             }
           }
           else
           {

               if(Touchlife[i]<GripTapDebounce)
              {
                  GripIsSuppressed[i]=0;
              }
              else
              {
                if(Touch_SensorInfor_Report[i].Tx_Ratio>0)
                {
                    if(Touch_SensorInfor_Report[i].Tx_Ratio<70)
                    {
                        GripIsSuppressed[i]=1;
                        HX_Griped_Status[i]=1;
                    }
                    else if(TxSigSizeRatio<Tx_SigRatio)
                    {
                        GripIsSuppressed[i]=1;
                        HX_Griped_Status[i]=2;
                    }
                    else
                    {
                        GripIsSuppressed[i]=21;
                    }
                }
              }

           }

       }
       else
       {
                 if(Touchlife[i]<GripTapDebounce)
                  {
                   GripIsSuppressed[i]=0;
                  }
                 else
                  {
                    GripIsSuppressed[i]=20;
                 }
        }
       }

    }
    else
    {
        GripIsSuppressed[i]=5;
    }

    if(1==GripIsSuppressed[i])
    {
      if(1==GripJitterEnableBit)
      {
        if((MaxRxwidth[i]>(GripFingerWidth))||(MaxTxwidth[i]>(GripFingerWidth)))
        {// remain suppressed
         if((GripMaxYdistance[i]>(GripJitterYMoveThreshold*3))||(GripMaxXDistance[i]>GripJitterXMoveThreshold*2))
         {
               if(((Touch_SensorInfor_Report[i].Tx_max>TX_EDGE_MAX-1)||(Touch_SensorInfor_Report[i].Tx_min<TX_EDGE_MIN+1))
                &&((Touch_SensorInfor_Report[i].Rx_max>RX_EDGE_MAX-1)||(Touch_SensorInfor_Report[i].Rx_min<RX_EDGE_MIN+1))
                 )
               {
               }
               else
               {
                 GripIsSuppressed[i]=12;
               }

          }
         else
         {}
        }
        else
        {
             if(Grip_White==GripPositionColor(reportData->pos[i].classification, currX, currY))
             {
                GripIsSuppressed[i]=7;
             }
             else if((GripMaxYdistance[i]>(GripJitterYMoveThreshold))||(GripMaxXDistance[i]>GripJitterXMoveThreshold))
             {
               if(((Touch_SensorInfor_Report[i].Tx_max>TX_EDGE_MAX-1)||(Touch_SensorInfor_Report[i].Tx_min<TX_EDGE_MIN+1))
                &&((Touch_SensorInfor_Report[i].Rx_max>RX_EDGE_MAX-1)||(Touch_SensorInfor_Report[i].Rx_min<RX_EDGE_MIN+1))
                 )
               {
               }
               else
               {
                 GripIsSuppressed[i]=8;
               }

             }
             else
             {
             }

        }
      }
      else
      {}
    }
    else if(0==GripIsSuppressed[i])
    {
     if(1==GripJitterEnableBit)
      {
        if((Touch_SensorInfor_Report[i].Rx_max<(RX_EDGE_MAX-1))&&(Touch_SensorInfor_Report[i].Rx_min>1))
        {
            if((GripMaxYdistance[i]>(GripJitterYMoveThreshold))||(GripMaxXDistance[i]>GripJitterXMoveThreshold))
            {
              GripIsSuppressed[i]=8;
            }
        }
        else
        {
            if((Touch_SensorInfor_Report[i].Tx_max<TX_EDGE_MAX-1)&&(Touch_SensorInfor_Report[i].Tx_min>TX_EDGE_MIN+1))
            {
              GripIsSuppressed[i]=11;
            }
        }
      }
      else
      {
         // remain
      }
    }
    else
    {
              // remain
    }
    if(preGripstatus[i]<2 && GripIsSuppressed[i]>1)
    {
        IIRfiltercount[i]=GripIIROrder;
    }

    if((GripIIROrder>0)&&(IIRfiltercount[i]>0))
    {
       int32 current, previous;
       int32 iirorder;
       iirorder = (int32)GripIIROrder;
       current =(int32) fingerIndex->xMeas;
       previous =(int32) PreXpos[i];

       current = (current*(iirorder-IIRfiltercount[i])+previous*IIRfiltercount[i])/iirorder;

       fingerIndex->xMeas=(int16)current;

       current =(int32) fingerIndex->yMeas;
       previous =(int32) PreYpos[i];

       current = (current*(iirorder-IIRfiltercount[i])+previous*IIRfiltercount[i])/iirorder;

       fingerIndex->yMeas=(int16)current;

       PreXpos[i]=fingerIndex->xMeas;
       PreYpos[i]=fingerIndex->yMeas;
       IIRfiltercount[i]--;
     }

   }
     PreReportinfo[i].classification=fingerIndex->classification;
     PreReportinfo[i].xMeas=fingerIndex->xMeas;
     PreReportinfo[i].yMeas=fingerIndex->yMeas;
     PreReportinfo[i].z=fingerIndex->z;
     PreReportinfo[i].xWidth=fingerIndex->xWidth;
     PreReportinfo[i].yWidth=fingerIndex->yWidth;
     PreReportinfo[i].txPos=fingerIndex->txPos;
     PreReportinfo[i].rxPos=fingerIndex->rxPos;
     if(fingerIndex->z!=0)
     {
         MaxRxwidth[i]=(MaxRxwidth[i]<Touch_SensorInfor_Report[i].Rx_width)?Touch_SensorInfor_Report[i].Rx_width:MaxRxwidth[i];
         MaxTxwidth[i]=(MaxTxwidth[i]<Touch_SensorInfor_Report[i].Tx_width)?Touch_SensorInfor_Report[i].Tx_width:MaxTxwidth[i];
     }


    }

}


void applyGripSuppressionRule2(reportData_t *reportData)
{
    reportPos_t *fingerIndex = &reportData->pos[0];
    uint16 i;

    uint16 fingercount;
    uint16 suppresscount;

    if(!GripEnableOnXAxis)
    {
        return;
    }

    fingercount = 0;

    if(Darkconerlive1>0)Darkconerlive1--;
    if(Darkconerlive2>0)Darkconerlive2--;
    if(Darkconerlive3>0)Darkconerlive3--;
    if(Darkconerlive4>0)Darkconerlive4--;
    if(TapSuppressLeft>0)TapSuppressLeft--;
    if(TapSuppressRight>0)TapSuppressRight--;


    applyGripSuppressionRule(reportData);


    for(i=0;i<MAX_OBJECTS;i++,fingerIndex++)
    {
     int16 Xshadow, Yshadow;

     if(MaxTxwidth[i]>GripFingerWidth)
     {
      Xshadow = GripDebounceThreshold/2;
     }
     else
     {
       Xshadow = GripDebounceThreshold/2;
     }
     if(MaxRxwidth[i]>GripFingerWidth)
     {
      Yshadow = GripDebounceThreshold;
     }
     else
     {
       Yshadow = GripDebounceThreshold;
     }
        if(1==GripIsSuppressed[i])
        {
          uint16 index;
          reportPos_t *fingerIndex2 = &reportData->pos[0];

          for(index=0; index<MAX_OBJECTS;index++,fingerIndex2++ )
          {
              if(i==index) continue;
              if(fingerIndex2->z==0) continue;
              if(GripIsSuppressed[index]==1)continue;
              if((poscurrentX[index]>(fingerIndex->xMeas+Xshadow))||
                  (fingerIndex->xMeas>(poscurrentX[index]+Xshadow)))
                  {
                   continue;
                  }
              if((poscurrentY[index]>(fingerIndex->yMeas+Yshadow))||
                  (fingerIndex->yMeas>(poscurrentY[index]+Yshadow)))
                  {
                    continue;
                   }
             GripIsSuppressed[index]=1;
             HX_Griped_Status[index]=7;
          }
        }

    }

    fingerIndex = &reportData->pos[0];
    suppresscount=0;
    for(i=0;i<MAX_OBJECTS;i++,fingerIndex++)
    {
       if((fingerIndex->z>0))//&&(GripIsSuppressed[i]==5))
       {
          fingercount++;
       }
       if(GripIsSuppressed[i]==5)
       {
         suppresscount++;
       }
    }

    if(!suppresscount)
    {
      fingercount=0;
    }

    fingerIndex = &reportData->pos[0];
    for(i=0;i<MAX_OBJECTS;i++,fingerIndex++)
    {
        if(((fingerIndex->z>0)))
        {
          if(IsDarkcornerzone1(fingerIndex->xMeas,fingerIndex->yMeas)&&IsDarkcornerzone1(Grip_landX[i],GripLandPositionY[i]))
          {
            if((fingercount>1)&&(!Darkconerlive2&&!Darkconerlive3&&!Darkconerlive4))//((1==GripIsSuppressed[i])||(Darkconerlive1>0))
            {
              Darkconerlive1=DARKCORNER_LIFE;
            }
          }
          else if(IsDarkcornerzone2(fingerIndex->xMeas,fingerIndex->yMeas)&&IsDarkcornerzone2(Grip_landX[i],GripLandPositionY[i]))
          {
            if((fingercount>1)&&(!Darkconerlive1&&!Darkconerlive3&&!Darkconerlive4))//(((1==GripIsSuppressed[i])||(Darkconerlive2>0))
            {
              Darkconerlive2=DARKCORNER_LIFE;
            }
          }
          else if(IsDarkcornerzone3(fingerIndex->xMeas,fingerIndex->yMeas)&&IsDarkcornerzone3(Grip_landX[i],GripLandPositionY[i]))
          {
            if((fingercount>1)&&(!Darkconerlive1&&!Darkconerlive2&&!Darkconerlive4))//(((1==GripIsSuppressed[i])||(Darkconerlive3>0))
            {
              Darkconerlive3=DARKCORNER_LIFE;
            }
          }
          else if(IsDarkcornerzone4(fingerIndex->xMeas,fingerIndex->yMeas)&&IsDarkcornerzone4(Grip_landX[i],GripLandPositionY[i]))
          {
            if((fingercount>1)&&(!Darkconerlive1&&!Darkconerlive2&&!Darkconerlive3))//(((1==GripIsSuppressed[i])||(Darkconerlive4>0))
            {
              Darkconerlive4=DARKCORNER_LIFE;
            }
          }

          if((fingerIndex->xMeas<TAPDARKZONE)&&(Grip_landX[i]<TAPDARKZONE))
          {
           if((fingercount>1)&&(!TapSuppressRight))
           {
            TapSuppressLeft=DARKCORNER_LIFE;
            }
          }
          else if((fingerIndex->xMeas>(GripXMaxPos-TAPDARKZONE))&&(Grip_landX[i]<TAPDARKZONE))
          {
           if((fingercount>1)&&(!TapSuppressLeft))
           {
            TapSuppressRight=DARKCORNER_LIFE;
           }
          }
        }

    }

    fingerIndex = &reportData->pos[0];
    for(i=0;i<MAX_OBJECTS;i++,fingerIndex++)
    {
       preGripstatus[i]=GripIsSuppressed[i];
       if(fingerIndex->z==0) continue;
       if(GripIsSuppressed[i] <= 2)
       {
          GripclearPositions(fingerIndex);
       }
       else
       {
           if(Darkconerlive1&&(IsDarkcornerzone1(fingerIndex->xMeas,fingerIndex->yMeas)==1))
           {
            GripclearPositions(fingerIndex);
           }
           else if (Darkconerlive2&&(IsDarkcornerzone2(fingerIndex->xMeas,fingerIndex->yMeas)==1))
           {
            GripclearPositions(fingerIndex);
           }
           else if (Darkconerlive3&&(IsDarkcornerzone3(fingerIndex->xMeas,fingerIndex->yMeas)==1))
           {
            GripclearPositions(fingerIndex);
           }
           else if(Darkconerlive4&&(IsDarkcornerzone4(fingerIndex->xMeas,fingerIndex->yMeas)==1))
           {
            GripclearPositions(fingerIndex);
           }
       }

    }

  }

/*
This is the end of second grip suppression impplementation.
*/
#endif


