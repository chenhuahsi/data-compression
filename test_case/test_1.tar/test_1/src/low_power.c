/*                       COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2015 Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include "calc2.h"
#include "platform.h"
#include "low_power.h"
#include "string.h"
#include "gesture_detector.h"

#include "calc_print.h"

#define LEN(x) (sizeof(x)/sizeof(x[0]))

typedef enum {
  LP_ACTIVE = 0,
  LP_REJECT = 1,
  LP_DOZE = 2,
  LP_RECALIBRATION = 3,
  LP_SUPERDOZE = 4,
} dozeState_t;

// static data
dozeParams_t dozeConfig;

static struct {
  uint32 dozeHoldOffTimer;
  int16 dozeBaseline[2*(MAX_RX+MAX_BUTTONS)];
  int16 superDozeBaseline[2];
  uint16 acquiredDozeBaseline : 1;
  uint16 acquiredSuperDozeBaseline : 1;
  int16 dozeHoldOffTimerValid : 1;
  dozeState_t currentState;
} dozeState;

#if CONFIG_LOW_POWER_DBG_BUFFER
static uint16 bu_wakeupdelta, bu_maxDozeDelta, bu_resettest, bu_dozeframe, bu_absDeltaValue;
static int16 bu_rxDozeDelta[2*MAX_RX], bu_rxDozeRaw[2*MAX_RX], bu_rxHoldBase[2*MAX_RX];
#endif

//static function definitions go here
static ATTR_INLINE void lowPower_setUpFirstDozeCluster(uint16 *imageTxes, uint16 len, uint16 *xmtr_cs_ptr, uint16 *xmtr_pl_ptr, uint16 regBank);
static ATTR_INLINE void lowPower_setUpSecondDozeCluster(uint16 *imageTxes, uint16 len, uint16 *xmtr_cs_ptr, uint16 *xmtr_pl_ptr, uint16 regBank);
static ATTR_INLINE void lowPower_findUnique(uint16 *buttonList, uint16 len, uint16 *uniqueButtonList, uint16 *numUniquePtr);
static void clearArray(uint16 *a, uint16 len);
static void acquireDozeBaselines();

void lowPower_init(dozeParams_t *dozeParams)//, uint16 *imageTxes, uint16 len, uint16 *buttonTxes, uint16 numButtons)
{
  uint16 dozeFramePeriod;

  // copy all the values into struct
  dozeConfig = *dozeParams;
  dozeState.acquiredDozeBaseline = 0;
  dozeState.acquiredSuperDozeBaseline = 0;
  dozeState.dozeHoldOffTimerValid = 0;
  dozeState.currentState = LP_ACTIVE;
  dozeFramePeriod = (dozeParams->dozeInterval*1000);

  // find unique button tx
//  lowPower_findUnique(buttonTxes, numButtons, uniqueButtonTxes, &numButtonClusters);

//  // first find cs and pl for the first burst
//  for (j = 0; j < CONFIG_XMTR_REGS; j++) // loop for the cs and pl registers
//  {
//    uint16 xmtr_cs_image = 0;
//    uint16 xmtr_cs_buttons = 0;
//    uint16 xmtr_pl_image = 0;
//    uint16 xmtr_pl_buttons = 0;
//    uint16 xmtr_cs, xmtr_pl;
//    lowPower_setUpFirstDozeCluster(imageTxes, len, &xmtr_cs_image, &xmtr_pl_image, j);
//    lowPower_setUpFirstDozeCluster(uniqueButtonTxes, numButtonClusters, &xmtr_cs_buttons, &xmtr_pl_buttons, j);
//    xmtr_cs = xmtr_cs_image | xmtr_cs_buttons;
//    xmtr_pl = ((xmtr_pl_image & (~xmtr_cs_buttons)) | xmtr_pl_buttons);// override with button pol
//    DAQ_writeVar(dozeXmtrValsAddr, xmtr_cs);
//    DAQ_writeVar(dozeXmtrValsAddr+CONFIG_XMTR_REGS, xmtr_pl);
//    dozeXmtrValsAddr++;
//  }
//  dozeXmtrValsAddr+=CONFIG_XMTR_REGS;
//  // now write cs and pl for the second burst
//  for (j = 0; j < CONFIG_XMTR_REGS; j++) // loop for the cs and pl registers
//  {
//    uint16 xmtr_cs_image = 0;
//    uint16 xmtr_cs_buttons = 0;
//    uint16 xmtr_pl_image = 0;
//    uint16 xmtr_pl_buttons = 0;
//    uint16 xmtr_cs, xmtr_pl;
//    lowPower_setUpSecondDozeCluster(imageTxes, len, &xmtr_cs_image, &xmtr_pl_image, j);
//    lowPower_setUpSecondDozeCluster(uniqueButtonTxes, numButtonClusters, &xmtr_cs_buttons, &xmtr_pl_buttons, j);
//    xmtr_cs = xmtr_cs_image | xmtr_cs_buttons;
//    xmtr_pl = ((xmtr_pl_image & (~xmtr_cs_buttons)) | xmtr_pl_buttons);// override with button pol
//    DAQ_writeVar(dozeXmtrValsAddr, xmtr_cs);
//    DAQ_writeVar(dozeXmtrValsAddr+CONFIG_XMTR_REGS, xmtr_pl);
//    dozeXmtrValsAddr++;
//  }
//  DAQ_writeVar(DOZE_BURSTS_PER_CLUSTER, dozeParams->dozeBurstsPerCluster);
//  DAQ_writeVar(DOZE_FRAME_PERIOD, dozeFramePeriod);
}

static ATTR_INLINE void diff(uint16 *dst, uint16 *v1, uint16 *v2, uint16 len)
{
  while(len--)
  {
    *dst++ = *v1++ - *v2++;
  }
}

#if CONFIG_LOW_POWER_DBG_BUFFER
static uint16 maxAbs(int16 *v, uint16 len)
{
  uint16 max = 0;
  uint16 x;
  while(len--)
  {
    x = (*v < 0) ? -*v : *v;
    max = (x > max) ? x : max;
    v++;
  }
  return max;
}
#endif

void acquireDozeBaselines()
{
  PLFrame_t *f;
  calcDynamicConfig_t dcfg;

  f = PL_getFrame(frame_doze);
  memcpy(dozeState.dozeBaseline, f->data.doze, sizeof(dozeState.dozeBaseline));
  dozeState.acquiredDozeBaseline = 1;
  PL_releaseFrame(f);

  #if CONFIG_LOW_POWER_DBG_BUFFER
  memcpy(bu_rxHoldBase, dozeState.dozeBaseline, sizeof(bu_rxHoldBase));
  #endif

  COMM_getDynamicConfig(&dcfg);
}

uint16 lowPower_dozeHandler(uint16 resetDoze, uint32 timeStamp, uint16 rejectTime)
{
  uint16 newTouch = 0;
  uint32 deltaTime = timeStamp;
  dozeState_t nextState, currentState;
  uint32 dozeTimer = 0;
  uint16 superDozeDetectedObject = 0;

  // handle various special cases that will prevent dozing

  currentState = dozeState.currentState;

  if (rejectTime == 0 && resetDoze == 1)
  {
    if (currentState == LP_RECALIBRATION)
    {
      PL_enterMode(mode_active);
      newTouch = 1;
    }
    dozeState.dozeHoldOffTimer = timeStamp;
    dozeState.dozeHoldOffTimerValid = 1;
    dozeState.acquiredDozeBaseline = 0;
    dozeState.acquiredSuperDozeBaseline = 0;
    dozeState.currentState = LP_ACTIVE;
    return newTouch;
  }

  if (!dozeState.dozeHoldOffTimerValid)
  {
    dozeState.dozeHoldOffTimer = timeStamp;
    dozeState.dozeHoldOffTimerValid = 1;
  }

  deltaTime = timeStamp - dozeState.dozeHoldOffTimer;

  if (rejectTime == 0 &&
      deltaTime > (uint32) dozeConfig.dozeHoldOff * 5000 &&
      dozeState.acquiredDozeBaseline == 0)
  {
    acquireDozeBaselines();
    return newTouch;
  }

  // figure out which state to start in

  if (rejectTime > 0)
  {
    nextState = LP_REJECT;
    printf("Entering Reject mode\n");
  }
  else if (deltaTime >= (uint32) dozeConfig.dozeHoldOff * 10000 ||
           currentState == LP_RECALIBRATION)
  {
    nextState = LP_DOZE;
  }
  else
  {
    return newTouch;
  }

  // doze main loop

  gesture_lp_clearContinuousActiveCounter(); // Reset continous active counter whenver visits doze.
  gesture_lp_setWentToSleep();  //let gesture_detector know doze state.
  dozeTimer = timeStamp;

  #if CONFIG_HAS_POWER_HISTORY_DOZE
  extern void Func01_setPowerHistoryDoze(void);
  Func01_setPowerHistoryDoze();
  #endif

  while(1)
  {
    calcDynamicConfig_t dcfg;
    commCommand_t cmd;
    uint16 threshold = 0;
    PLFrame_t *f = NULL;
    int16 deltaImage[2*(MAX_RX + MAX_BUTTONS)];
    uint16 objDetected = 0;

    // any state may transition to active if a command is received or
    // noDoze is set.
    if (nextState == LP_ACTIVE)
    {
      PL_enterMode(mode_active);
      dozeState.acquiredDozeBaseline = 0;
      dozeState.acquiredSuperDozeBaseline = 0;
      dozeState.dozeHoldOffTimerValid = 0;
    }

    // all other state transitions are handled here
    switch(currentState)
    {
    case LP_ACTIVE:
      if (nextState == LP_DOZE || nextState == LP_REJECT)
      {
        PL_enterMode(mode_doze);
        dozeTimer = timeStamp;
      }
      break;
    case LP_REJECT:
      if (nextState == LP_DOZE)
        dozeTimer = timeStamp;
      break;
    case LP_DOZE:
      if (nextState == LP_SUPERDOZE)
        PL_enterMode(mode_superdoze);
      break;
    case LP_SUPERDOZE:
      if (nextState == LP_DOZE)
        PL_enterMode(mode_doze);
      break;
    default:
      break;
    }
    currentState = nextState;

    if (currentState == LP_ACTIVE ||
        currentState == LP_RECALIBRATION)
      goto done;

    // commands or disabling doze kicks us out
    COMM_getDynamicConfig(&dcfg);
    cmd = COMM_getNextCommand();
    if (cmd.cmd != CMD_NONE || dcfg.noDoze != 0)
    {
      #if CONFIG_HAS_DOZE_DATA_REPORTING
      if((dcfg.forceDoze==0) || (dcfg.noDoze != 0) || ((cmd.cmd != CMD_DO_HYBRID_RAW_ADC_TEST) && (cmd.cmd != CMD_DO_HYBRID_RAW_CAP_TEST)))
      #endif
      {
      nextState = LP_ACTIVE;
      continue;
      }
    }

    // disabling superdoze takes effect immediately
    if (currentState == LP_SUPERDOZE)
    {
      nextState = LP_DOZE;
      continue;
    }

    // disabling wakeup gestures quits reject mode
    if (currentState == LP_REJECT && dcfg.inWakeupGestureMode == 0)
    {
      nextState = LP_DOZE;
      continue;
    }

    if (currentState == LP_DOZE || currentState == LP_REJECT)
    {
      threshold = dozeConfig.dozeWakeUpThreshold;
      f = PL_getFrame(frame_doze);
      #if CONFIG_HAS_CPU_MONITOR
      COMM_postDebugReport(DBGREPORT_CPUMONITOR, 0, 0);
      #endif
      #if CONFIG_LOW_POWER_DBG_BUFFER
      bu_dozeframe++;
      #endif
    }
    else if (currentState == LP_SUPERDOZE)
    {
      threshold = dozeConfig.dozeWakeUpThreshold; // FIXME: add superdoze threshold
      f = PL_getFrame(frame_superdoze);
    }

    // from here on, don't use "continue" without releasing the frame
    timeStamp = f->timeStamp;
    deltaTime = timeStamp - dozeTimer;

    if (currentState == LP_DOZE || currentState == LP_REJECT)
    {
      if (dozeState.acquiredDozeBaseline == 0)
      {
        memcpy(dozeState.dozeBaseline, f->data.doze, sizeof(dozeState.dozeBaseline));
        #if CONFIG_LOW_POWER_DBG_BUFFER
        memcpy(bu_rxHoldBase, dozeState.dozeBaseline, sizeof(bu_rxHoldBase));
        #endif
        dozeState.acquiredDozeBaseline = 1;
      }
      diff(deltaImage, dozeState.dozeBaseline, f->data.doze, f->length);
      COMM_postDebugReport(DBGREPORT_DOZE_DELTA, deltaImage, f->length);
    }
    else if (currentState == LP_SUPERDOZE)
    {
      if (dozeState.acquiredSuperDozeBaseline == 0)
      {
        memcpy(dozeState.superDozeBaseline, f->data.superdoze, sizeof(dozeState.superDozeBaseline));
        dozeState.acquiredSuperDozeBaseline = 1;
        // double-check for no objects in regular doze
        nextState = LP_DOZE;
      }
      diff(deltaImage, dozeState.superDozeBaseline, f->data.superdoze, f->length);
      COMM_postDebugReport(DBGREPORT_SUPERDOZE_DELTA, deltaImage, f->length);
    }

    COMM_postDebugReport(DBGREPORT_CYCLES, (uint16 *)&f->cycles, 1);
    COMM_endFrame();
    #if CONFIG_LOW_POWER_DBG_BUFFER
    memcpy(bu_rxDozeRaw, f->data.doze, sizeof(bu_rxDozeRaw));
    memcpy(bu_rxDozeDelta, deltaImage, sizeof(bu_rxDozeDelta));
    bu_absDeltaValue = maxAbs(deltaImage, f->length);
    bu_maxDozeDelta = ( bu_absDeltaValue > bu_maxDozeDelta ) ? bu_absDeltaValue : bu_maxDozeDelta;
    #endif

    // always update the baseline in reject mode so we only see motion
    if (currentState == LP_REJECT)
    {
      memcpy(dozeState.dozeBaseline, f->data.doze, sizeof(dozeState.dozeBaseline));
      #if CONFIG_LOW_POWER_DBG_BUFFER
      memcpy(bu_rxHoldBase, dozeState.dozeBaseline, sizeof(bu_rxHoldBase));
      #endif
    }
    #if CONFIG_HAS_DOZE_DATA_REPORTING
    if((dcfg.forceDoze==1) && (cmd.cmd == CMD_DO_HYBRID_RAW_ADC_TEST))
    {
      uint16 i, hybridRawAdc[MAX_RX+MAX_TX];
      for(i=0;i<MAX_RX;i++)
        hybridRawAdc[i] = f->data.doze[i];
      for(i=MAX_RX;i<(MAX_RX+MAX_TX);i++)
        hybridRawAdc[i] = 0;
      COMM_postDebugReport(IMAGE_REPORT_RAW_HYBRID_ADC_RT62, (uint16 *)hybridRawAdc, LEN(hybridRawAdc));
    }
    if((dcfg.forceDoze==1) && (cmd.cmd == CMD_DO_HYBRID_RAW_CAP_TEST))
    {
      uint16 i;
      uint32 hybridRawCap[MAX_RX+MAX_TX];
      PLCapData_t frameCapRawData;
      for(i=0;i<MAX_RX;i++)
        f->data.hybridX[i] = f->data.doze[i];
      PL_convertDozeFrameToRawCap(&f->data,&frameCapRawData);
      for(i=0;i<MAX_RX;i++)
        hybridRawCap[i] = (uint32)(frameCapRawData.hybridX[i]);
      for(i=MAX_RX;i<(MAX_RX+MAX_TX);i++)
        hybridRawCap[i] = 0;
      COMM_postDebugReport(IMAGE_REPORT_RAW_HYBRID_CAP_RT63, (uint16 *)hybridRawCap, 2*LEN(hybridRawCap));
    }
    if(dcfg.forceDoze==0)
    #endif
    if (PL_isDozeWakeUpCondition(&dozeConfig, deltaImage, f->length))
    {
      #if CONFIG_LOW_POWER_DBG_BUFFER
      bu_wakeupdelta = bu_absDeltaValue;
      #endif
      objDetected = 1;
    }

    if (gesture_lp_getDoRepeatForceDoze())
    {
      objDetected = 0;
      gesture_lp_setWentToSleep();
    }
    else if (gesture_isAlternateDozeSensing())
    {
      // Exit from forced doze state if (1) doze duration reaches timeout setting
      // or (2) host clears RMI LPWGReporting bit. Otherwise, keep the doze state.
      if (gesture_lp_isAlternateObjectDetect(objDetected))
      {
        if (objDetected)
          gesture_lp_setWentToSleep();
      }
      else
      {
        if (objDetected)
          objDetected = 0;
        gesture_lp_clearWentToSleep();
      }
    }
    else
    {
      if((objDetected) && gesture_lp_isLPWGSensing())
      {
        // Everytime object is detected, false activation counter is incremented
        // by one. If this finger performs gesture, counter will be cleared.
        gesture_lp_incFalseActivationCounter();
      }
    }

    if (objDetected)
    {
      if (currentState == LP_DOZE)
      {
        #if CONFIG_HAS_POWER_HISTORY_WAKE
        extern void Func01_setPowerHistoryWake(void);
        Func01_setPowerHistoryWake();
        #endif

        gesture_lp_clearWentToSleep();

        newTouch = 1;
        nextState = LP_ACTIVE;
      }
      else if (currentState == LP_SUPERDOZE)
      {
        nextState = LP_DOZE;

        // force re-baseline on next entry
        dozeState.acquiredSuperDozeBaseline = 0;

        // prevent re-entry if super doze is seeing objects that
        // aren't there in regular doze
        superDozeDetectedObject = 1;
      }
      else if (currentState == LP_REJECT)
      {
        dozeTimer = timeStamp;
      }
    }
    else if (currentState == LP_REJECT && deltaTime > (uint32) rejectTime * 100000)
    {
      printf("Exiting Reject mode\n");
      nextState = LP_DOZE;
    }
    else if (deltaTime > (uint32) dozeConfig.dozeRecalibrationInterval * 10000)
    {
      if (currentState == LP_SUPERDOZE)
      {
        nextState = LP_DOZE;
      }
      else if (currentState == LP_DOZE)
      {
        if (!gesture_isAlternateDozeSensing())
        {
          // Decrement this timer when alternate doze mode in LPWG is off
          // This means that FW dozed for the duration of one doze cycle, implies no moving object was detected
          gesture_lp_decFalseActivationCounter();
        }
        #if CONFIG_HAS_DOZE_DATA_REPORTING
        if(dcfg.forceDoze==0)
        #endif
        nextState = LP_RECALIBRATION;
      }
    }
    PL_releaseFrame(f);
  }
done:
  dozeState.currentState = currentState;
  #if CONFIG_LOW_POWER_DBG_BUFFER
  if( bu_resettest == 1 )
  {
      bu_resettest = 0;
      bu_wakeupdelta = 0;
      bu_maxDozeDelta = 0;
      bu_absDeltaValue = 0;
  }
  #endif
  return newTouch;
}

uint16 lowPower_isInActiveMode()
{
  return dozeState.currentState == LP_ACTIVE;
}

static ATTR_INLINE void lowPower_setUpFirstDozeCluster(uint16 *imageTxes, uint16 len, uint16 *xmtr_cs_ptr, uint16 *xmtr_pl_ptr, uint16 regBank)
{
  uint16 middleTx = (len+1)/2; // ceil(len/2)
  uint16 i, k;
  uint16 *transmittersPtr = imageTxes;
  k = 1;
  for (i = 0; i < len; i++)
  {
    if ((*transmittersPtr >= (16*regBank)) && (*transmittersPtr < (16*(regBank+1))))
    {
      *xmtr_cs_ptr |= k << ((*transmittersPtr) - 16*regBank);
      if (i >= middleTx)
        *xmtr_pl_ptr |= k << ((*transmittersPtr) - 16*regBank);
    }
    transmittersPtr++;
  }
}

static ATTR_INLINE void lowPower_setUpSecondDozeCluster(uint16 *imageTxes, uint16 len, uint16 *xmtr_cs_ptr, uint16 *xmtr_pl_ptr, uint16 regBank)
{
  uint16 numPosTx = (len+1)/2;
  uint16 i, k;
  uint16 *transmittersPtr = imageTxes;
  uint16 lowerLimit, upperLimit;
  k = 1;
  lowerLimit = (len/4);
  if (len > 1)
    lowerLimit = (len/4) > 0 ? (len/4) : 1;
  upperLimit = lowerLimit + numPosTx;
  for (i = 0; i < len; i++)
  {
    if ((*transmittersPtr >= (16*regBank)) && (*transmittersPtr < (16*(regBank+1))))
    {
      (*xmtr_cs_ptr) |= k << ((*transmittersPtr) - 16*regBank);
      if (i < lowerLimit || i >= upperLimit)
        (*xmtr_pl_ptr) |= k << ((*transmittersPtr) - 16*regBank);
    }
    transmittersPtr++;
  }
}

// Button drive during doze when each button is on a separate RX
// static ATTR_INLINE void lowPower_setUpButtonDozeCluster(uint16 *imageTxes, uint16 len, uint16 *xmtr_cs_ptr, uint16 *xmtr_pl_ptr, uint16 regBank)
// {
//   uint16 i, k;
//   uint16 *transmittersPtr = imageTxes;
//   k = 1;
//   for (i = 0; i < len; i++)
//   {
//     if ((*transmittersPtr >= (16*regBank)) && (*transmittersPtr < (16*(regBank+1))))
//     {
//       *xmtr_cs_ptr |= k << ((*transmittersPtr) - 16*regBank);
//       *xmtr_pl_ptr = 0;
//     }
//     transmittersPtr++;
//   }
// }

static ATTR_INLINE void lowPower_findUnique(uint16 *buttonList, uint16 len, uint16 *uniqueButtonList, uint16 *numUniquePtr)
{
  uint16 i, j;
  *numUniquePtr = 0;
  clearArray(uniqueButtonList, MAX_BUTTONS);
  // find the unique button transmitters
  for (i = 0; i < len; i++)
  {
    for (j = 0; j < *numUniquePtr; j++)
      if (uniqueButtonList[j] == buttonList[i])
        break;
    uniqueButtonList[j] = buttonList[i];
    if (j == *numUniquePtr)
      (*numUniquePtr) += 1;
  }
}

static void clearArray(uint16 *a, uint16 len)
{
  uint16 i;
  for (i = 0; i < len; i++){
    a[i] = 0;
  }
}
