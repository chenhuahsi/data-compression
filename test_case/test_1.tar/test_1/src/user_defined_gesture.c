// -----------------------------------------------------------------
// User Defined Gesture Recognizer
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// $Id: func_12.h,v 1.20.18.6.4.32.2.13 2014/10/03 08:48:42 yahuic Exp $
//

#include <string.h>
#include "user_defined_gesture.h"
#include "gesture_recognizer.h"


#define MAX_NUM_FINGER_FOR_USER_DEFINED_GESTURE     1

static struct {
  udgParams_t cfg;
} params;

typedef enum {
  UDG_REGISTRATION_IDLE_STATE            =  0,
  UDG_REGISTRATION_DATA_COLLECTION_STATE =  1,
  UDG_REGISTRATION_DATA_PROCESS_STATE    =  2,
  UDG_REGISTRATION_BUFFER_OVERFLOW_STATE = 14,
  UDG_REGISTRATION_TOO_MANY_FINGER_STATE = 15
} regState_t;

typedef enum {
  UDG_PROCESS_IDLE_STATE            =  0,
  UDG_PROCESS_DATA_COLLECTION_STATE =  1,
  UDG_PROCESS_DATA_PROCESS_STATE    =  2,
  UDG_PROCESS_BUFFER_OVERFLOW_STATE = 14,
  UDG_PROCESS_TOO_MANY_FINGER_STATE = 15
} procState_t;

typedef struct {
  regState_t state_tmp;
  regState_t state;
  uint16 traceIndex;
  uint16 segment;
  uint16 tryTimes;
  uint16 successTimes;
} regCtrl_t;

typedef struct {
  procState_t state;
  uint16 timer;
  uint16 segment;
  uint16 count;
  uint16 fingerLiftCount;
  uint16 traceIndex;
} procCtrl_t;

static struct {
  uint16 enabled : 1;
  udgReportPosition_t fingerPos[CONFIG_LPWG_USERDEFINED_NUMPOINTS];
  uint16 prevNumFingers;
  regCtrl_t regCtrl;
  procCtrl_t procCtrl;
} state;

//static void preloadData(udgTrace_t *data, unsigned int j) ATTR_THREAD(_thr_Calculation);
static uint16 init_at_bootup;

void userDefinedGestures_boot()
{
  gestureRecognizer_boot();
  init_at_bootup = 1;
}


void userDefinedGestures_init(calcStaticConfig_t *cfg)
{
  if (!init_at_bootup)
    userDefinedGestures_boot();

  gestureRecognizer_init(cfg);
  params.cfg = cfg->udgParams;
}


uint16 userDefinedGestures_isDataCollectionState()
{
  calcDynamicConfig_t dcfg;
  COMM_getDynamicConfig(&dcfg);
  return state.enabled && (dcfg.registrationEnable || state.procCtrl.state == UDG_PROCESS_DATA_COLLECTION_STATE);
}


void userDefinedGestures_setEnabled(uint16 enable)
{
  state.enabled = enable;
}


void userDefinedGestures_detect(struct touch pos, gestureReport_t *pReport)
{
  if (!state.enabled)
    return;

  uint16 numFingers = 0;
  uint16 i = 0;
  udgReportPosition_t tmp_fingerPos;
  udgTrace_t data;

  if (pos.touchFlag)
  {
    tmp_fingerPos.x = pos.x;
    tmp_fingerPos.y = pos.y;
    numFingers++;
  }

  calcDynamicConfig_t dcfg;
  COMM_getDynamicConfig(&dcfg);
  if ( dcfg.registrationEnable )
  {
    if ( dcfg.registrationStart )
    {
      state.regCtrl.state = UDG_REGISTRATION_DATA_COLLECTION_STATE;
    }
    else
    {
      if ( (state.regCtrl.state == UDG_REGISTRATION_DATA_COLLECTION_STATE) && (state.regCtrl.traceIndex != 0) )
      {
        if (state.regCtrl.state_tmp == 0)
        {
          state.regCtrl.state = UDG_REGISTRATION_DATA_PROCESS_STATE;

          data.numPts = state.regCtrl.traceIndex;
        }
        else
        {
          state.regCtrl.state = state.regCtrl.state_tmp;
          state.regCtrl.state_tmp = 0;
        }

        state.regCtrl.tryTimes ++;

      }
      else
      {
        state.regCtrl.state = UDG_REGISTRATION_IDLE_STATE;
      }
    }
  }
  else
  {
    state.regCtrl.state = UDG_REGISTRATION_IDLE_STATE;
    state.regCtrl.tryTimes = 0;
    state.regCtrl.successTimes = 0;
  }

  if (state.regCtrl.state == UDG_REGISTRATION_IDLE_STATE)
  {
    state.regCtrl.traceIndex = 0;
    state.regCtrl.segment = 0;
  }
  else if (state.regCtrl.state == UDG_REGISTRATION_DATA_COLLECTION_STATE)
  {
    if (numFingers == 0)
    {
      if (state.prevNumFingers == 1)
      {
        state.regCtrl.segment ++;
      }
    }
    else
    {
      if (numFingers == 1)
      {
        if (state.regCtrl.traceIndex >= CONFIG_LPWG_USERDEFINED_NUMPOINTS - 1)
        {
          state.regCtrl.state_tmp = UDG_REGISTRATION_BUFFER_OVERFLOW_STATE;
        }
        else
        {
          state.fingerPos[state.regCtrl.traceIndex].x = tmp_fingerPos.x;
          state.fingerPos[state.regCtrl.traceIndex].y = tmp_fingerPos.y;
          state.fingerPos[state.regCtrl.traceIndex].seg = state.regCtrl.segment;

          state.regCtrl.traceIndex ++;
        }
      }
      else
      {
        state.regCtrl.state_tmp = UDG_REGISTRATION_TOO_MANY_FINGER_STATE;
      }
    }
  }

  if ( !dcfg.registrationEnable )
  {
    if (state.procCtrl.state == UDG_PROCESS_IDLE_STATE)
    {
      if ( ((numFingers == 1) && (state.prevNumFingers == 0)) )
      {
        state.procCtrl.timer = CONFIG_LPWG_USERDEFINED_NUMPOINTS;
        state.procCtrl.traceIndex = 0;
        state.procCtrl.count = 0;
        state.procCtrl.fingerLiftCount = 0;
        state.procCtrl.segment = 0;
        state.procCtrl.state = UDG_PROCESS_DATA_COLLECTION_STATE;
      }
    }
    else if (state.procCtrl.state == UDG_PROCESS_DATA_COLLECTION_STATE)
    {
      state.procCtrl.count ++;
      if(state.procCtrl.count != 0)
      {
      }
      if (state.procCtrl.count > 0 && ((numFingers == 0) && (state.prevNumFingers == 1)))
      {
        state.procCtrl.fingerLiftCount = 1;
      }
      if(state.procCtrl.fingerLiftCount && numFingers == 0)
      {
        state.procCtrl.fingerLiftCount++; //On Finger lift increment the count
      }
      if ((state.procCtrl.fingerLiftCount == params.cfg.maxInterStroke && state.procCtrl.count > 0) || state.procCtrl.count >= state.procCtrl.timer)
      {
        state.procCtrl.state = UDG_PROCESS_DATA_PROCESS_STATE;
        data.numPts = state.procCtrl.traceIndex;
        state.procCtrl.fingerLiftCount = 0;
      }
    }
    else if (state.procCtrl.state >= UDG_PROCESS_DATA_PROCESS_STATE)
    {
      state.procCtrl.state = UDG_PROCESS_IDLE_STATE;
    }

    if (state.procCtrl.state == UDG_PROCESS_DATA_COLLECTION_STATE)
    {
      if (numFingers == 0)
      {
        if (state.prevNumFingers == 1)
        {
          state.procCtrl.segment ++;
        }
      }
      else if (numFingers == 1)
      {
        if (state.procCtrl.traceIndex >= CONFIG_LPWG_USERDEFINED_NUMPOINTS - 1)
        {
          state.procCtrl.state = UDG_PROCESS_BUFFER_OVERFLOW_STATE;
        }
        else
        {
          state.fingerPos[state.procCtrl.traceIndex].x = tmp_fingerPos.x;
          state.fingerPos[state.procCtrl.traceIndex].y = tmp_fingerPos.y;
          state.fingerPos[state.procCtrl.traceIndex].seg = state.procCtrl.segment;

          state.procCtrl.traceIndex ++;
        }
      }
      else
      {
        state.procCtrl.state = UDG_PROCESS_TOO_MANY_FINGER_STATE;
      }
    }
  }

  state.prevNumFingers = numFingers;

  if ( dcfg.registrationEnable )
  {
    if (state.regCtrl.state == UDG_REGISTRATION_DATA_PROCESS_STATE)
    {
      {
        //preloadData(&data, state.regCtrl.tryTimes);

        for (i = 0; i < data.numPts; i ++)
        {
          data.pos[i].x = (float)state.fingerPos[i].x / (float)params.cfg.xUnitsPerMm;
          data.pos[i].y = (float)state.fingerPos[i].y / (float)params.cfg.yUnitsPerMm;
          data.pos[i].seg = state.fingerPos[i].seg;
        }

        calcDynamicConfig_t dcfg;
        COMM_getDynamicConfig(&dcfg);
        uint16 status = gestureRecognizer_registration(&data, dcfg.registrationIndex, &state.regCtrl.successTimes);

        if (status == REGISTRATION_SUCCESS)
        {
          pReport->gestureProperty[0] = (uint16)((void*)(state.fingerPos));
        }

        pReport->gestureProperty[1] = status;
        pReport->gestureProperty[2] = state.regCtrl.traceIndex;

        pReport->userDefinedGestureRegistered = 1;
      }
    }
    else if ( (state.regCtrl.state == UDG_REGISTRATION_BUFFER_OVERFLOW_STATE) ||
              (state.regCtrl.state == UDG_REGISTRATION_TOO_MANY_FINGER_STATE) )
    {
      pReport->gestureProperty[1] = 0;
      pReport->gestureProperty[3] = state.regCtrl.state;

      pReport->userDefinedGestureRegistered = 1;
    }

    if (state.regCtrl.tryTimes == 3)
    {
      state.regCtrl.tryTimes = 0;
      state.regCtrl.successTimes = 0;
    }
  }
  else
  {
    if (state.procCtrl.state == UDG_PROCESS_DATA_PROCESS_STATE)
    {
      //preloadData(&data, 3);

      for (i = 0; i < data.numPts; i ++)
      {
        data.pos[i].x = (float)state.fingerPos[i].x / (float)params.cfg.xUnitsPerMm;
        data.pos[i].y = (float)state.fingerPos[i].y / (float)params.cfg.yUnitsPerMm;
        data.pos[i].seg = state.fingerPos[i].seg;
      }

      uint16 templateIndex;
      float metric = gestureRecognizer_gestureMatch(&data, &templateIndex);
      int16 scaled_metric = (int16)(metric * 100.0);

      if (scaled_metric > params.cfg.matchingMetricThreshold)
      {
        pReport->gestureProperty[4] = scaled_metric;
        pReport->gestureProperty[5] = templateIndex;

        pReport->gestureProperty[0] = (uint16)((void*)state.fingerPos);
        pReport->gestureProperty[2] = state.procCtrl.traceIndex;

        pReport->userDefinedGestureDetected = 1;
      }
    }
    else if ( (state.procCtrl.state == UDG_PROCESS_BUFFER_OVERFLOW_STATE) ||
              (state.procCtrl.state == UDG_PROCESS_TOO_MANY_FINGER_STATE) )
    {
      int16 tmp = (-100 - state.procCtrl.state) * 100;

      if (tmp > params.cfg.matchingMetricThreshold)
      {
        pReport->gestureProperty[2] = 0;
        pReport->gestureProperty[4] = tmp;
        pReport->gestureProperty[5] = 0;

        pReport->userDefinedGestureDetected = 1;
      }
    }
  }
}

#if 0
ROM_FLOAT x0[] =
{
    18.0259826743899f, 17.9685750862549f, 17.7389447337149f, 17.3370916167699f, 16.5333853828799f,
    15.2704184439099f, 13.7778211523999f, 12.0555935083499f, 10.4481810405699f, 8.84076857278995f,
    14.5815273862899f, 14.5815273862899f, 14.6963425625599f, 14.8685653269649f, 15.0407880913699f,
    15.0981956795049f, 15.0407880913699f, 14.8685653269649f, 14.5815273862899f, 14.2944894456149f,
    14.1222666812099f, 14.0648590930749f, 27.1537891878549f, 27.2111967759899f, 27.5556423047999f,
    28.7037940674998f, 30.3686141234148f, 32.6075100606798f, 34.6167756454048f, 36.5112260538598f,
    37.8316005809648f, 38.9797523436648f, 40.0130889300948f, 40.7019799877148f, 41.0464255165248f,
    37.6593778165598f, 37.6019702284248f, 37.4871550521548f, 37.3149322877498f, 37.0278943470748f,
    36.4538184657248f, 35.6501122318348f, 34.7315908216748f, 33.8130694115148f, 32.7797328250848f,
    31.6889886505198f, 30.8278748284948f, 30.1963913590098f, 29.6223154776598f, 29.1056471844448f,
    28.7612016556348f, 28.5315713030948f, 28.3593485386898f, 28.3593485386898f, 28.4741637149598f,
    28.6463864793648f, 28.9334244200398f, 29.4500927132548f, 30.2537989471448f, 31.4019507098448f,
    32.9519555894898f, 34.2149225284598f, 35.5352970555648f, 36.9130791708048f, 38.0038233453698f,
    39.1519751080698f, 39.8982737538248f, 40.3001268707698f, 40.3001268707698f, 39.7260509894198f,
    38.3482688741798f, 36.6834488182648f, 34.3871452928648f, 31.5741734742498f, 28.4741637149598f,
    24.9148932505899f
};

ROM_FLOAT x1[] =
{
    18.1407978506599f, 18.0259826743899f, 17.7389447337149f, 17.1074612642299f, 16.0167170896649f,
    14.6389349744249f, 13.1463376829149f, 11.4815176269999f, 9.87410515921995f, 8.43891545584495f,
    16.7630157354199f, 16.7630157354199f, 16.7630157354199f, 16.7630157354199f, 16.7630157354199f,
    16.7630157354199f, 16.7630157354199f, 16.6482005591499f, 16.4759777947449f, 16.3037550303399f,
    16.0741246777999f, 15.8444943252599f, 15.5574563845849f, 15.3852336201799f, 15.2704184439099f,
    23.8241490760249f, 23.8815566641599f, 24.5704477217799f, 25.9482298370199f, 28.2445333624198f,
    30.4834292996848f, 32.8371404132198f, 34.9038135860798f, 36.7982639945348f, 38.3482688741798f,
    39.5538282250148f, 37.3149322877498f, 37.2575246996148f, 37.2001171114798f, 37.0853019352098f,
    36.8556715826698f, 36.4538184657248f, 35.7649274081048f, 34.8464059979448f, 33.8130694115148f,
    32.6649176488148f, 31.2871355335748f, 30.0241685946048f, 28.7612016556348f, 27.6130498929349f,
    26.6371208946399f, 25.7760070726149f, 25.0871160149949f, 24.6278553099149f, 24.1685946048349f,
    23.9963718404299f, 24.0537794285649f, 24.2834097811049f, 24.7426704861849f, 25.3741539556699f,
    26.3500829539649f, 28.0723105980148f, 29.7945382420648f, 31.7463962386548f, 33.4686238827048f,
    34.7315908216748f, 35.8797425843748f, 36.7408564063998f, 37.7167854046948f, 38.3482688741798f,
    38.4630840504498f, 37.8890081690998f, 36.8556715826698f, 34.7889984098098f, 32.4352872962748f,
    29.5075003013898f, 26.2926753658299f
};

ROM_FLOAT x2[] =
{
    15.6148639727199f,  15.5574563845849f,  15.3278260320449f,  14.7537501506949f,  13.8926363286699f,
    12.5148542134299f,  10.9074417456499f,  9.35743686600495f,  7.69261681008996f,  6.20001951857997f,
    4.99446016774497f,  14.9833805032349f,  14.9833805032349f,  14.9833805032349f,  14.9259729150999f,
    14.8685653269649f,  14.6963425625599f,  14.4667122100199f,  14.2370818574799f,  14.0648590930749f,
    13.8926363286699f,  13.7204135642649f,  13.6630059761299f,  13.5481907998599f,  13.4907832117249f,
    13.4333756235899f,  24.9148932505899f,  25.1445236031299f,  25.9482298370199f,  27.6704574810699f,
    29.6797230657948f,  32.0334341793298f,  33.8130694115148f,  35.5927046436998f,  36.9130791708048f,
    37.8316005809648f,  38.4630840504498f,  38.8075295792598f,  32.6649176488148f,  32.6649176488148f,
    32.7223252369498f,  32.8371404132198f,  32.8945480013548f,  32.8371404132198f,  32.5501024725448f,
    31.9760265911948f,  31.1723203573048f,  30.3686141234148f,  29.6223154776598f,  28.6463864793648f,
    27.6704574810699f,  26.9241588353149f,  26.3500829539649f,  25.9482298370199f,  25.5463767200749f,
    25.2593387793999f,  25.2593387793999f,  25.5463767200749f,  26.0056374251549f,  26.9241588353149f,
    28.7037940674998f,  30.6556520640898f,  33.1241783538948f,  34.9612211742148f,  36.7982639945348f,
    38.1186385216398f,  39.4390130487448f,  40.4149420470398f,  40.8167951639848f,  40.7593875758498f,
    39.9556813419598f,  38.3482688741798f,  36.0519653487798f,  33.1815859420298f,  29.5649078895248f
};

ROM_FLOAT y0[] =
{
    -17.1875447592311f,  -17.2448365750953f,  -17.5885874702799f,  -18.2760892606491f,  -19.7083846572517f,
    -21.5990145807671f,  -24.1771462946518f,  -26.9271534561288f,  -29.5052851700135f,  -32.0261250680340f,
    -28.8750751955083f,  -28.9323670113724f,  -29.3334097224212f,  -30.1927869603827f,  -31.9115414363058f,
    -34.0313386232777f,  -36.6667621530264f,  -39.5886447620957f,  -42.3959437394368f,  -45.1459509009138f,
    -47.5522071672062f,  -49.2709616431293f,  -19.6510928413876f,  -19.5938010255235f,  -19.3646337620671f,
    -18.8490074192902f,  -18.1615056289209f,  -17.4167120226876f,  -16.8437938640465f,  -16.3854593371337f,
    -16.0990002578132f,  -15.9271248102209f,  -15.7552493626285f,  -15.6979575467644f,  -15.6979575467644f,
    -21.3125555014466f,  -21.3125555014466f,  -21.4844309490389f,  -21.9427654759518f,  -22.8021427139133f,
    -24.1771462946518f,  -25.6667335071185f,  -27.2709043513134f,  -28.8177833796442f,  -30.1354951445186f,
    -31.3959150935289f,  -32.3125841473546f,  -32.8855023059956f,  -33.2292532011802f,  -33.2865450170443f,
    -33.1719613853161f,  -32.8282104901315f,  -31.8542496204417f,  -30.6511214872955f,  -29.5625769858776f,
    -28.7604915637801f,  -28.2448652210032f,  -27.7865306940904f,  -27.4427797989057f,  -27.2709043513134f,
    -27.4427797989057f,  -27.8438225099545f,  -28.5313243003237f,  -29.6198688017417f,  -30.7657051190238f,
    -32.8282104901315f,  -34.8334240453751f,  -37.3542639433957f,  -39.8178120255522f,  -42.5105273711650f,
    -45.7761608754189f,  -48.9272107479447f,  -52.1355524363345f,  -55.4011859405884f,  -58.5522358131141f,
    -61.6459938697757f
};

ROM_FLOAT y1[] =
{
    -11.0000286459079f, -11.0573204617720f, -11.4583631728208f, -12.6041994901028f, -14.3229539660260f,
    -16.5573347847260f, -19.0781746827466f, -21.4844309490389f, -23.9479790311954f, -25.8959007705749f,
    -25.2656907960698f, -25.3229826119339f, -25.7240253229826f, -26.6406943768083f, -28.5313243003237f,
    -31.1094560142084f, -34.0313386232777f, -37.3542639433957f, -40.7917728952419f, -44.3438654788164f,
    -47.6667907989344f, -50.1876306969549f, -52.0209688046063f, -53.2240969377524f, -53.9115987281217f,
    -14.4948294136183f, -14.4375375977542f, -14.2656621501619f, -13.9219112549772f, -13.5208685439285f,
    -13.2344094646080f, -13.0625340170157f, -13.0625340170157f, -13.1198258328798f, -13.2917012804721f,
    -13.5781603597926f, -16.6146266005901f, -16.6146266005901f, -16.7865020481824f, -17.3594202068235f,
    -18.6198401558337f, -20.5104700793492f, -22.8594345297774f, -25.2656907960698f, -27.9011143258186f,
    -30.0782033286545f, -32.2552923314904f, -33.9167549915495f, -35.1771749405597f, -36.0938439943854f,
    -36.6094703371623f, -36.7813457847547f, -36.6094703371623f, -36.2084276261136f, -35.2344667564239f,
    -33.7448795439572f, -32.1980005156263f, -30.9948723824802f, -29.9636196969263f, -29.2188260906929f,
    -28.4740324844596f, -27.8438225099545f, -27.6146552464980f, -27.7292388782262f, -28.0729897734109f,
    -28.5886161161878f, -29.3907015382853f, -30.3073705921109f, -31.8542496204417f, -33.8594631756854f,
    -36.2084276261136f, -38.9011429717265f, -42.3386519235727f, -46.0626199547395f, -49.9011716176344f,
    -53.7397232805294f, -57.4063994958320f
};

ROM_FLOAT y2[] =
{
    -13.4635767280644f, -13.5208685439285f, -13.8073276232490f, -14.6094130453465f, -15.9271248102209f,
    -17.8750465496004f, -20.2813028158928f, -22.8594345297774f, -25.3802744277980f, -27.7865306940904f,
    -29.6771606176058f, -28.3594488527314f, -28.4167406685955f, -28.7604915637801f, -29.6198688017417f,
    -31.1094560142084f, -33.1146695694520f, -35.5209258357444f, -37.8125984703085f, -40.1615629207368f,
    -42.0521928442522f, -43.9428227677676f, -45.4324099802343f, -46.5782462975164f, -47.2657480878857f,
    -47.6094989830703f, -14.3229539660260f, -14.2083703342977f, -13.8646194391131f, -13.2917012804721f,
    -12.7187831218310f, -12.2604485949182f, -11.9739895155977f, -11.7448222521413f, -11.6875304362772f,
    -11.7448222521413f, -11.8594058838695f, -12.0312813314618f, -19.0208828668825f, -19.1927583144748f,
    -19.7083846572517f, -20.7396373428056f, -22.1146409235441f, -23.8333953994672f, -25.5521498753903f,
    -27.2136125354493f, -28.7031997479160f, -29.8490360651981f, -30.5938296714314f, -31.2240396459366f,
    -31.5677905411212f, -31.6250823569853f, -31.3959150935289f, -30.9948723824802f, -30.1354951445186f,
    -28.9896588272365f, -27.9584061416827f, -27.1563207195852f, -26.5261107450801f, -25.9531925864390f,
    -25.4375662436621f, -25.3229826119339f, -25.7813171388467f, -26.6406943768083f, -27.7865306940904f,
    -29.1042424589647f, -31.1667478300725f, -33.8594631756854f, -37.2396803116675f, -40.5626056317855f,
    -44.0574063994958f, -47.7240826147985f, -51.5626342776934f, -55.2866023088602f, -58.6668194448423f
};

ROM_FLOAT x3[] =
{
    20.8389544930049f,  20.7815469048699f,  20.5519165523299f,  19.7482103184399f,  18.4852433794699f,
    16.4759777947449f,  14.5241197981549f,  12.2852238608899f,  10.3333658642999f,  8.89817616092495f,
    7.86483957449496f,  7.29076369314496f,  7.06113334060496f,  7.00372575246996f,  7.06113334060496f,
    7.52039404568496f,  8.43891545584495f,  9.64447480667995f,  10.6778113931099f,  11.4815176269999f,
    12.1704086846199f,  12.8018921541049f,  13.3185604473199f,  13.8352287405349f,  14.2370818574799f,
    14.7537501506949f,  15.3852336201799f,  15.9593095015299f,  16.4185702066099f,  16.6482005591499f,
    16.8204233235549f,  16.8778309116899f,  16.9352384998249f,  16.9926460879599f,  17.0500536760949f,
    17.1074612642299f,  17.1648688523649f,  17.2222764404999f,  17.2796840286349f,  17.2796840286349f,
    17.3370916167699f,  17.5093143811749f,  31.5167658861148f,  31.5741734742498f,  32.2056569437348f,
    33.4686238827048f,  35.5927046436998f,  37.4871550521548f,  39.3816054606098f,  40.7593875758498f,
    41.6205013978748f,  42.1371696910898f,  40.8742027521198f,  40.8167951639848f,  40.7593875758498f,
    40.5871648114448f,  40.2427192826348f,  39.5538282250148f,  38.5778992267198f,  37.3723398758848f,
    35.9945577606448f,  34.4445528809998f,  32.7797328250848f,  30.9426900047648f,  29.1630547725798f,
    27.6130498929349f,  26.5223057183699f,  25.7185994844799f,  25.2019311912649f,  24.8574856624549f,
    24.8000780743199f,  25.1445236031299f,  25.7760070726149f,  26.9815664234499f,  29.0482395963098f,
    31.1723203573048f,  33.3538087064348f,  35.1908515267548f,  37.0278943470748f,  38.2334536979098f,
    39.0945675199348f,  40.0130889300948f,  40.8167951639848f,  41.3334634571998f,  41.3908710453348f,
    40.9316103402548f,  39.5538282250148f,  37.4297474640198f,  34.2149225284598f
};

ROM_FLOAT y3[] =
{
    -15.3542066515798f, -15.3542066515798f, -15.5260820991721f, -16.2708757054055f, -17.5885874702799f,
    -19.8229682889799f, -22.2865163711364f, -25.0938153484775f, -28.1302815892750f, -30.4792460397032f,
    -32.3125841473546f, -33.4011286487725f, -33.9740468074136f, -34.0886304391418f, -34.0313386232777f,
    -33.6302959122289f, -32.5417514108110f, -31.2813314618007f, -30.2500787762468f, -29.3907015382853f,
    -28.7604915637801f, -28.3594488527314f, -28.1875734051391f, -28.2448652210032f, -28.5313243003237f,
    -29.2761179065571f, -30.8229969348879f, -33.2865450170443f, -36.2084276261136f, -39.0157266034547f,
    -42.1667764759804f, -45.4324099802343f, -48.2397089575754f, -50.5313815921396f, -52.6511787791114f,
    -54.0834741757140f, -55.1147268612679f, -55.8022286516371f, -56.2032713626858f, -56.3751468102782f,
    -56.3751468102782f, -56.0313959150935f, -22.6302672663210f, -22.5156836345928f, -22.2292245552723f,
    -21.8281818442236f, -21.3698473173107f, -21.0260964221261f, -20.7396373428056f, -20.6250537110774f,
    -20.5677618952133f, -20.5104700793492f, -27.1563207195852f, -27.2136125354493f, -27.6146552464980f,
    -28.7604915637801f, -30.5365378555673f, -32.7709186742674f, -35.1771749405597f, -37.4688475751239f,
    -39.5886447620957f, -41.2501074221548f, -42.6824028187573f, -43.7709473201753f, -44.3438654788164f,
    -44.4011572946805f, -44.1146982153599f, -43.5990718725830f, -42.9688618980779f, -41.9949010283881f,
    -40.8490647111060f, -39.8751038414163f, -39.1303102351829f, -38.3282248130855f, -37.6407230227162f,
    -37.2969721275316f, -37.2969721275316f, -37.6407230227162f, -38.2709329972214f, -38.9584347875906f,
    -39.7032283938239f, -40.7917728952419f, -42.2813601077086f, -44.1719900312240f, -46.2917872181959f,
    -49.0417943796729f, -51.9063851728781f, -55.1720186771320f, -59.0678621558910f
};
void preloadData(udgTrace_t *data, unsigned int j)
{
  unsigned int i;

  unsigned int numPts0 = 76;
  unsigned int numPts1 = 77;
  unsigned int numPts2 = 75;
  unsigned int numPts3 = 89;

  if (j == 0)
  {
    data->numPts = numPts0;
  }
  else if (j == 1)
  {
    data->numPts = numPts1;
  }
  else if (j == 2)
  {
    data->numPts = numPts2;
  }
  else if (j == 3)
  {
    data->numPts = numPts3;
  }

  if (j == 0)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->x[i] = x0[i];
    }
  }
  else if (j == 1)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->x[i] = x1[i];
    }
  }
  else if (j == 2)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->x[i] = x2[i];
    }
  }
  else if (j == 3)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->x[i] = x3[i];
    }
  }

  if (j == 0)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->y[i] = y0[i];
    }
  }
  else if (j == 1)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->y[i] = y1[i];
    }
  }
  else if (j == 2)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->y[i] = y2[i];
    }
  }
  else if (j == 3)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->y[i] = y3[i];
    }
  }


  unsigned int seg0[] =
  {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3
  };

  unsigned int seg1[] =
  {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3
  };

  unsigned int seg2[] =
  {
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  1,  1,  1,  1,  1,  1,  1,  1,  1,
    1,  1,  1,  1,  1,  1,  2,  2,  2,  2,
    2,  2,  2,  2,  2,  2,  2,  2,  3,  3,
    3,  3,  3,  3,  3,  3,  3,  3,  3,  3,
    3,  3,  3,  3,  3,  3,  3,  3,  3,  3,
    3,  3,  3,  3,  3,  3,  3,  3,  3,  3,
    3,  3,  3,  3,  3,
  };

  unsigned int seg3[] =
  {
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  1,  1,  1,  1,  1,  1,  1,  1,
    1,  1,  2,  2,  2,  2,  2,  2,  2,  2,
    2,  2,  2,  2,  2,  2,  2,  2,  2,  2,
    2,  2,  2,  2,  2,  2,  2,  2,  2,  2,
    2,  2,  2,  2,  2,  2,  2,  2,  2
  };

  if (j == 0)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->seg[i] = seg0[i];
    }
  }
  else if (j == 1)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->seg[i] = seg1[i];
    }
  }
  else if (j == 2)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->seg[i] = seg2[i];
    }
  }
  else if (j == 3)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->seg[i] = seg3[i];
    }
  }
}
#endif
