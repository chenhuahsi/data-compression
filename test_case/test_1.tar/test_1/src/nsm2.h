/* -----------------------------------------------------------------
 * NSM2Base:  The common NSM functions of the NSM2/DAQ2 framework.
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2014  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 *
 * The Base NSM functions are defined.  Brief documentation is given
 * inline.  For more information about the DAQ2 project, see:
 *   http://usuv-conf.synaptics.com:8090/display/DAQ2/DAQ2+Project+Space
 *
 */


#ifndef _NSM_H_
#define _NSM_H_ 1

#include "calc2.h"
#include "daq2.h"

/* Define the states of the NSM. */
#define NSM_OFF_STATE 0
#define NSM_HNM_STATE 1
#define NSM_FNM_STATE 2

/* Define the charger bit states of the NSM. */
#define NSM_CHARGER_BIT_LOW 0
#define NSM_CHARGER_BIT_HIGH 1

/* Define the HW INTFR constants for CID/Rail parsing. */
#define NSM_RAIL_HW_OFFSET 0
#define NSM_RAIL_HW_STEP 2
#define NSM_CID_HW_OFFSET 1
#define NSM_CID_HW_STEP 2


/* Include the specific NSM header. */
#if CONFIG_NSM_GANYMEDE == 1
#include "nsm2ganymede.h"
#elif CONFIG_NSM_CALLISTO == 1
#include "nsm2callisto.h"
#elif CONFIG_NSM_EUROPA == 1
#include "nsm2europa.h"
#else
#warning "No C NSM header defined, using Ganymede"
#include "nsm2ganymede.h"
#endif


/* Define the NSM object structure.  This will be passed to
 * base functions.
 */
typedef struct {
  nsm_params_t nsm_params;
  nsm_ims_t nsm_ims;
  nsm_internal_t nsm_internal;
  nsm_statevars_t nsm_statevars;
  nsm_parser_t nsm_parser;
  uint16 rcvrOffsets[MAX_NOISE_RX];
} nsm_object_t;


/* NOTE: -------------------------------------------------------------- */
/* ALL functions in nsm2base.c require an nsm_object_t pointer as their
 * first input.  Therefore, they can only be called from the nsm2*.c that
 * has been selected at compile time.  They should NEVER be called from
 * anywhere else.
 * See the nsm2*.h file for the public API.
 */


/* Public functions --------------------------------------------------- */
/* These can be called from public wrappers in the individual NSMs. */

#ifdef __cplusplus
extern "C"{
#endif
/* Tells the NSM when the charger bit is toggled by the host. */
void nsm2base_setChargerPresent(nsm_object_t *nsm_object_ptr, uint16 chargerPresent);

/* Writes values to the NSM's parameters. */
void nsm2base_setParams(nsm_object_t *nsm_object_ptr, nsm_params_t *nsmParams);

/* Used to manually change the sensing frequency.  Intended for use via
 * RMI during sensor tuning.
 */
void nsm2base_setCurrentFreq(nsm_object_t *nsm_object_ptr, uint16 frequency);


/* Internal functions ------------------------------------------------- */
/* These are for internal use, but can be called from public wrappers in
 * the individual NSMs for debugging purposes.
 */

/* Executes a frequency scan and selects the quietest frequency. */
uint16 nsm2base_executeFrequencyScan(nsm_object_t *nsm_object_ptr, uint16 freq_start, uint16 freq_end);

/* Sets the current NSM state and associated internal variables. */
void nsm2base_setCurrentState(nsm_object_t *nsm_object_ptr, uint16 state);


/* Internal functions ------------------------------------------------- */
/* These are for internal use and cannot be called from public wrappers in
 * the individual NSMs.
 */

/* Measures the RX offsets for the noise bursts. */
void nsm2base_measureRcvrOffsets(nsm_object_t *nsm_object_ptr);

/* Calculates the powerIM for noise bursts and frequency scans. */
void nsm2base_calcPowerIM(nsm_object_t *nsm_object_ptr, uint16 *noisePtr);

/* Calculates the CIDIM. */
void nsm2base_calcCidIM(nsm_object_t *nsm_object_ptr, uint16 *hwPtr);

/* Calculates the RailIM. */
void nsm2base_calcRailIM(nsm_object_t *nsm_object_ptr, uint16 *hwPtr);

/* Selects the preferred frequency. */
uint16 nsm2base_selectFirstFreq(nsm_object_t *nsm_object_ptr, uint16 freq_start, uint16 freq_end);

/* Calculates the burst delays and writes to the frame program. */
void nsm2base_setNoiseBurstDelays(nsm_object_t *nsm_object_ptr);
#ifdef __cplusplus
}
#endif

#endif // _NSM_H
