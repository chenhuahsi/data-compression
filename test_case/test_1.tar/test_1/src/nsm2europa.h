/* -----------------------------------------------------------------
 * Europa NSM:  An InCell NSM within the NSM2/DAQ2 framework.
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2014  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 *
 * The Europa NSM interface is defined.  Brief documentation is given
 * inline.  For more information about the DAQ2 project, see:
 *   http://usuv-conf.synaptics.com:8090/display/DAQ2/DAQ2+Project+Space
 *
 */


#ifndef _NSM2EUROPA_H_
#define _NSM2EUROPA_H_ 1

#include "calc2.h"
#include "daq2.h"

/* Define the rates of the NSM. */
#define NSM_120_RATE 120
#define NSM_60_RATE 60

/* Define the rate controls of the NSM. */
#define NSM_RATECONTROL_DYNAMIC12060   0
#define NSM_RATECONTROL_MANUAL60       1
#define NSM_RATECONTROL_MANUAL120      2


/* Define the structs used by the NSM. */

/* The parameter struct contains thresholds, timing parameters, and
 * disable flags.
 */
typedef struct {
  uint16 powerimHighThresh;
  uint16 powerimLowThresh;
  uint16 powerimFnmHighThresh;
  uint16 railimHighThresh;
  uint16 railimLowThresh;
  uint16 cidimHighThresh;
  uint16 cidimLowThresh;
  uint16 fsFnmDensity;
  uint16 fnmTimeout;
  uint16 fsTimeout;
  uint16 enableChargerBit;
  uint16 disableFreq;
  uint16 inhibitFrequencyShift;
  uint16 fsim120Thresh;
  uint16 fsim60Thresh;
  uint16 hnm60Timeout;
  uint16 enableMultiFrameIM;
  uint16 dynamicSensingRate;
  uint16 transitionFrameCount;
  uint16 noNoiseMitigation;
} nsm_params_t;

/* The im struct contains the interference metrics. */
typedef struct {
  uint16 powerim;
  uint16 fsim[MAX_FREQUENCIES];
  uint16 cidim;
  uint16 railim;
} nsm_ims_t;

/* The internal struct contains the internal variables.  These are
 * intended for internal use, only.
 */
typedef struct {
  uint32 fsTimer;
  uint16 fsPrimed;
  uint16 powerimBitVector;
  uint16 lowimFlag;
  uint16 lowimTime;
  uint16 lowimPrimed;
  uint16 lastFreq;
  uint16 noiseScanFlag;
  uint16 fsFnmDensityScaled;
  uint16 chargerPresent;
  uint16 lastPowerIM;
  uint16 lastRate;
  uint16 gears60HzAvailable;
  uint16 gears120HzAvailable;
  uint16 frequencyTransCount;
} nsm_internal_t;

/* The statevar struct contains the public state variables.  These are
 * intended for use by the firmware's main calculation loop.
 */
typedef struct {
  uint16 currentFreq;
  uint16 currentState;
  uint16 abortFrame;
  uint16 frequencyShift;
  uint16 currentRate;
  uint16 rateShift;
  uint16 frequencyTranState;
  uint16 compLevel;
} nsm_statevars_t;

/* The parser struct contains the noise parsing parameters. */
typedef struct {
  uint16 noiseBursts;
  uint16 noiseScanBursts;
  uint16 transClusters;
  uint16 cidNorm;
  uint16 railNorm;
} nsm_parser_t;

typedef enum
{
  NO_BASELINE_COMPENSATATION = 0,
  WITH_BASELINE_COMPENSATATION,
  WITH_HIGH_BASELINE_COMPENSATATION,
} nsm_baseline_comp_t;

/* Specific Functions ------------------------------------------------- */
/* These are the functions that are individualized for each NSM
 * version.
 */
#ifdef __cplusplus
  extern "C"{
#endif

/* Used for initializing the NSM. Requires initialization parameters to
 * be passed. RX Offsets and an initial frequency scan will be performed.
 */
void nsm_init(nsm_params_t *nsmParams);

/* The work horse function. This should be called during every regular
 * frame.  Calculates the IMs and then decides on appropriate action.
 * Actions can include frequency scans and/or state changes.
 */
void nsm_evalNSM(uint16 noNoiseMitigation, DAQFrame_t *f);

/* Tell the NSM whether or not a finger was present during this frame.
 * Should be called after running IFP on each frame.
 */
void nsm_reportObjects(uint16 objectsPresent);

/* Sets the current NSM state and associated internal variables. */
void nsm_setCurrentState(uint16 state);

/* Sets the current NSM frame rate and associated internal variables. */
void nsm_setCurrentRate(uint16 rate);


/* Query Functions ---------------------------------------------------- */
/* Return internal NSM variables; for use by outside functions. */

/* Returns the current IM values. */
nsm_ims_t nsm_getIms(void);

/* Returns the current parameter values. */
nsm_params_t nsm_getParams(void);

/* Returns the current state. This should be called after nsm_evalNSM in
 * order to check its result.
 */
nsm_statevars_t nsm_getStatevars(void);

/* Returns the RX offsets. */
void nsm_getRcvrOffsets(uint16 *rcvr_offsets);


/* Base NSM Wrappers -------------------------------------------------- */
/* These are public wrappers for those functions in the base NSM which may
 * be called from outside.  They are also used when calling those base
 * functions internally in this NSM.
 */

void nsm_setChargerPresent(uint16 chargerPresent);

void nsm_setParams(nsm_params_t *nsmParams);

void nsm_setCurrentFreq(uint16 frequency);

uint16 nsm_executeFrequencyScan(uint16 freq_start, uint16 freq_end);

void nsm_resetFreqTransition(void);
#ifdef __cplusplus
}
#endif

#endif // _NSM2EUROPA_H_
