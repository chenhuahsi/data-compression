/*                       COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2016 Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA   95131
 * (408) 904-1100
 */

#include "calc2.h"
#include "platform.h"
#include "lpwg_modeb.h"
#include "string.h"
#include "gesture_detector.h"

#if CONFIG_HAS_ABS_CMNR_FILTER
  #include "ifp/image_frame_processor.h"
#endif

#include "calc_print.h"

#define LEN(x) (sizeof(x)/sizeof(x[0]))

#if CONFIG_HIC_LPWG_MODE_B

// static data
lpwgModeBParams_t lpwgModeBConfig;
static lpwgModeBState_t lpwgModeBState;

//static function definitions go here
static ATTR_INLINE void lowPower_lpwgModeB_resetBaseline(uint16 *data, uint16 len);


uint16 energyAbs(int16* v, uint16 len)
{
  uint16 energy = 0;
  uint16 x;
  uint16 num = len;

  while(len--)
  {
    x = (*v < 0) ? -*v : *v;
    energy += x;
    v++;
  }
  energy /= num;

  return energy;
}

uint16 maxAbsWithEnergyRemoved(int16* v, uint16 energy, uint16 len)
{
  uint16 max = 0;
  uint16 x;
  while(len--)
  {
    x = (*v < 0) ? -*v : *v;
    x = (x < energy) ? 0 : (x-energy);
    max = (x > max) ? x : max;
    v++;
  }
  return max;
}

uint16 maxSpatialDiffAbsWithEnergyRemoved(int16* v, uint16 energy, uint16 len)
{
  uint16 max = 0;
  uint16 x;
  uint16 diff;

  uint16 x0 = (*v < 0) ? -*v : *v;
  x0 = (x0 < energy) ? 0 : (x0-energy);
  v++;

  while(--len)
  {
    x = (*v < 0) ? -*v : *v;
    x = (x < energy) ? 0 : (x-energy);
    diff = ((int16)(x - x0) < 0) ? -(x - x0) : (x - x0);
    max = (diff > max) ? diff : max;
    x0 = x;
    v++;
  }
  return max;
}

uint16 sumAbsWithEnergyRemoved(int16* v, uint16 energy, uint16 len)
{
  uint16 sum = 0;
  uint16 x;
  while(len--)
  {
    x = (*v < 0) ? -*v : *v;
    x = (x < energy) ? 0 : (x-energy);
    sum += x;
    v++;
  }
  return sum;
}

int16 sumEnergyLiftAbs(int16* v, uint16 len)
{
  int16 sum = 0;
  while(len--)
  {
    sum += *v;
    v++;
  }
  // report negative (lift) energy
  if (sum > 0)
    sum = 0;

  return sum;
}

uint16 isLpwgModeBWakeUpCondition(lpwgModeBParams_t *lpwgModeBConfig, int16 *deltaImage, uint16 size)
{
  // checks 2D

  uint16 energy = energyAbs(deltaImage, size);

  // To report in F54 DATA24 we need to compute all parameters
  uint16 absMaxPeak     = maxAbsWithEnergyRemoved(deltaImage, energy, size);
  uint16 absXEnergy     = sumAbsWithEnergyRemoved(deltaImage, energy, size);
  uint16 maxSpatialDiff = maxSpatialDiffAbsWithEnergyRemoved(deltaImage, energy, size);

  fingerDetectionReport_t fingerDetection;
  fingerDetection.absMaxPeak     = absMaxPeak;
  fingerDetection.absXEnergy     = absXEnergy;
  fingerDetection.maxSpatialDiff = maxSpatialDiff;
  COMM_postFingerDetectionReport(&fingerDetection);

  if (absMaxPeak <= lpwgModeBConfig->lpwgWakeUpThreshold) return 0;

  if (maxSpatialDiff <= lpwgModeBConfig->lpwgSpatialThreshold) return 0;

  if ((absXEnergy >= lpwgModeBConfig->lpwgEnergyThreshold)
      && (sumEnergyLiftAbs(deltaImage, size) >= (int16)-(lpwgModeBConfig->lpwgEnergyLiftThreshold))) return 0;

  // met all conditions
  return 1;
}

void lowPower_lpwgModeB_init(lpwgModeBParams_t *lpwgModeBParams)
{
  // copy all the values into struct
  lpwgModeBConfig = *lpwgModeBParams;

  // make sure that the history size is less than the buffer
  if (lpwgModeBConfig.lpwgHistorySize > MAX_LPWG_MODE_B_HISTORY)
    lpwgModeBConfig.lpwgHistorySize = MAX_LPWG_MODE_B_HISTORY;
  else if (lpwgModeBConfig.lpwgHistorySize <= 0)
    lpwgModeBConfig.lpwgHistorySize = 1;

  // To avoid overflow and resulting confusion the number of extra baseline frames
  // is limited to fewer bits than allocated for the acquire baseline counter.
  lpwgModeBState.acquireLpwgBaseline = 1 + COMM_getS0ExtraBaselineFramesModeBLPWG();
  lpwgModeBState.acquireTrgtBaseline = 1 + COMM_getS0ExtraBaselineFramesModeBTRGT();
  lpwgModeBState.dozeHoldOffTimerValid = 0;
  lpwgModeBState.currentState = LPWG_MODE_B_ACTIVE;
}

void lowPower_lpwgModeB_resetBaseline(uint16 *data, uint16 len)
{
  uint16 i;
  lpwgModeBState.lpwgBaselineReadIdx = 0;
  lpwgModeBState.lpwgBaselineWriteIdx = lpwgModeBConfig.lpwgHistorySize - 1;

  for (i=0; i < lpwgModeBConfig.lpwgHistorySize; i++)
  {
    // history buffer allocates max(MAX_RX, MAX_TX), data array is either MAX_RX or MAX_TX
    memcpy(lpwgModeBState.lpwgBaseline[i], data, len*sizeof(lpwgModeBState.lpwgBaseline[0][0]));
  }
}

uint16 lowPower_lpwgModeB_running()
{
  return ((lpwgModeBState.currentState == LPWG_MODE_B_ACTIVE) ? 0 : 1);
}

uint16 lowPower_lpwgModeB_recal()
{
  return ((lpwgModeBState.currentState == LPWG_MODE_B_RECALIBRATION) ? 1 : 0);
}

uint16 lowPower_lpwgModeB_fingerGesture()
{
  if ((lpwgModeBState.currentState == LPWG_MODE_B_GESTURE) || (lpwgModeBState.currentState == LPWG_MODE_B_RECALIBRATION))
    return 1;

  return 0;
}

uint16 lowPower_lpwgModeB_isRezeroRequested()
{
  return ((lpwgModeBState.currentState == LPWG_MODE_B_BASELINE) ? 1 : 0);
}

static ATTR_INLINE void diff(uint16 *dst, uint16 *v1, uint16 *v2, uint16 len)
{
  while(len--)
  {
    *dst++ = *v1++ - *v2++;
  }
}

uint16 lowPower_lpwgModeB_handler(uint16 resetDoze, ATTR_UNUSED uint32 timeStamp, uint16 rejectTime)
{
  uint16 newTouch = 0;
  uint32 deltaTime = timeStamp;
  lpwgModeBStates_t nextState, currentState;
  uint32 dozeTimer = 0;
  uint16 discardFirstDozeFrame = 0;
  calcDynamicConfig_t dcfg;
  uint16* lpwgData;

  currentState = lpwgModeBState.currentState;

  //
  // handle various special cases that will prevent dozing
  //
  COMM_getDynamicConfig(&dcfg);
  if (!dcfg.inWakeupGestureMode)
  {
    lpwgModeBState.acquireTrgtBaseline = 1 + COMM_getS0ExtraBaselineFramesModeBTRGT();
    lpwgModeBState.acquireLpwgBaseline = 1 + COMM_getS0ExtraBaselineFramesModeBLPWG();
    lpwgModeBState.dozeHoldOffTimerValid = 0;
    lpwgModeBState.currentState = LPWG_MODE_B_ACTIVE;
    COMM_exitTRGT();
    return newTouch;
  }
  if (rejectTime == 0 && resetDoze == 1
    #if CONFIG_HAS_DOZE_DATA_REPORTING
    && dcfg.forceDoze == 0
    #endif
  )
  {
    if (currentState == LPWG_MODE_B_RECALIBRATION)
    {
      PL_enterMode(mode_modeB_trgt);
      newTouch = 1;
    }
    lpwgModeBState.dozeHoldOffTimer = timeStamp;
    lpwgModeBState.dozeHoldOffTimerValid = 1;
    lpwgModeBState.acquireLpwgBaseline = 1 + COMM_getS0ExtraBaselineFramesModeBLPWG();
    lpwgModeBState.currentState = LPWG_MODE_B_GESTURE;
    gesture_lp_clearWentToSleep();
    return newTouch;
  }

  if (!lpwgModeBState.dozeHoldOffTimerValid)
  {
    lpwgModeBState.dozeHoldOffTimer = timeStamp;
    lpwgModeBState.dozeHoldOffTimerValid = 1;
  }
  deltaTime = timeStamp - lpwgModeBState.dozeHoldOffTimer;

  //
  // figure out which state to start in
  //
  nextState = currentState;
  if (rejectTime > 0)
  {
    nextState = LPWG_MODE_B_REJECT;
    printf("Entering Reject mode\n");
  }
  else if (currentState == LPWG_MODE_B_ACTIVE)
  {
    #if IS_TD4353
      nextState = LPWG_MODE_B_CBC_SCAN;
      PL_storeCbcs();
    #else
      nextState = LPWG_MODE_B_BASELINE;
    #endif
  }
  else if (currentState == LPWG_MODE_B_CBC_SCAN)
  {
    nextState = LPWG_MODE_B_BASELINE;
  }
  else if (currentState == LPWG_MODE_B_BASELINE || currentState == LPWG_MODE_B_RECALIBRATION)
  {
    if (!lpwgModeBState.acquireTrgtBaseline)
      nextState = LPWG_MODE_B_DOZE;
  }
  else if (deltaTime >= (uint32) lpwgModeBConfig.dozeHoldOff * 10000)
  {
    nextState = LPWG_MODE_B_DOZE;
  }
  else
  {
    return newTouch;
  }

  // doze main loop

  gesture_lp_clearContinuousActiveCounter(); // Reset continous active counter whenver visits doze.
  gesture_lp_setWentToSleep();  //let gesture_detector know doze state.
  dozeTimer = timeStamp;

  while (1)
  {
    commCommand_t cmd;
    PLFrame_t *f = NULL;
    int16 deltaImage[MAX_MODE_B_LPWG];
    uint16 objDetected = 0;

    if (nextState == LPWG_MODE_B_DOZE)
    {
      if (COMM_isForceTRGT())
        nextState = LPWG_MODE_B_GESTURE;
    }
    if (nextState == LPWG_MODE_B_ACTIVE)
    {
      lpwgModeBState.acquireTrgtBaseline = 1 + COMM_getS0ExtraBaselineFramesModeBTRGT();
      lpwgModeBState.acquireLpwgBaseline = 1 + COMM_getS0ExtraBaselineFramesModeBLPWG();
      lpwgModeBState.dozeHoldOffTimerValid = 0;
      PL_enterMode(mode_idle); // to go to deep sleep
      #if IS_TD4353
        PL_restoreCbcs();
      #endif
      COMM_exitTRGT();
    }
    if (nextState == LPWG_MODE_B_GESTURE)
    {
      lpwgModeBState.acquireLpwgBaseline = 1 + COMM_getS0ExtraBaselineFramesModeBLPWG();
      lpwgModeBState.dozeHoldOffTimerValid = 0;
      PL_enterMode(mode_modeB_trgt);
    }
    #if IS_TD4353
    if (nextState == LPWG_MODE_B_CBC_SCAN)
    {
      COMM_setHybridCBCAutoServo();
      PL_enterMode(mode_modeB_trgt);
    }
    #endif

    // all other state transitions are handled here
    switch (currentState)
    {
    case LPWG_MODE_B_GESTURE:
    case LPWG_MODE_B_BASELINE:
    case LPWG_MODE_B_RECALIBRATION:
      if (nextState == LPWG_MODE_B_DOZE || nextState == LPWG_MODE_B_REJECT)
      {
        // wait for CVI timeout which means we have completed the display refresh
        // f->errorFlags should have the CVITIMEOUT bit set
        #if !CONFIG_REDUCE_TRGT_REFRESH
        f = PL_getFrame(frame_modeB_display_refresh);
        timeStamp = f->timeStamp;
        PL_releaseFrame(f);
        #endif
        PL_enterMode(mode_modeB_lpwg);
        dozeTimer = timeStamp;
      }
      break;
    case LPWG_MODE_B_REJECT:
      if (nextState == LPWG_MODE_B_DOZE)
        dozeTimer = timeStamp;
      break;
    default:
      break;
    }
    currentState = nextState;

    if (currentState == LPWG_MODE_B_BASELINE || currentState == LPWG_MODE_B_RECALIBRATION)
    {
      if (lpwgModeBState.acquireTrgtBaseline)
        lpwgModeBState.acquireTrgtBaseline--;

      goto done;
    }
    if (currentState == LPWG_MODE_B_GESTURE || currentState == LPWG_MODE_B_ACTIVE)
      goto done;
    #if IS_TD4353
    if (currentState == LPWG_MODE_B_CBC_SCAN)
    {
      goto done;
    }
    #endif

    // commands or disabling doze kicks us out
    COMM_getDynamicConfig(&dcfg);
    if (!dcfg.inWakeupGestureMode)
    {
      // disabling LPWG will exit the loop
      nextState = LPWG_MODE_B_ACTIVE;
      continue;
    }
    
    cmd = COMM_getNextCommand();
    if (cmd.cmd != CMD_NONE
      #if CONFIG_HAS_DOZE_DATA_REPORTING
      && !(dcfg.forceDoze==1 && (cmd.cmd == CMD_DO_HYBRID_RAW_ADC_TEST || cmd.cmd == CMD_DO_HYBRID_RAW_CAP_TEST))
      #endif
    )
    {
      // let calc mainloop handle commands
      nextState = LPWG_MODE_B_GESTURE;
      continue;
    }

    // currentState == LPWG_MODE_B_DOZE || LPWG_MODE_B_REJECT
    f = PL_getFrame(frame_modeB_lpwg);

    // from here on, don't use "continue" without releasing the frame
    timeStamp = f->timeStamp;
    deltaTime = timeStamp - dozeTimer;

    // FWTDDI-2203, discard first frame after refresh action
    if (discardFirstDozeFrame)
    {
      discardFirstDozeFrame = 0;
      PL_releaseFrame(f);
      continue;
    }

    lpwgData = lpwgModeBConfig.lpwgAxis ? f->data.hybridY : f->data.hybridX;
    if (lpwgModeBState.acquireLpwgBaseline != 0)
    {
      lowPower_lpwgModeB_resetBaseline(lpwgData, f->length);
      lpwgModeBState.acquireLpwgBaseline--;
    }

    diff(deltaImage, lpwgModeBState.lpwgBaseline[lpwgModeBState.lpwgBaselineReadIdx], lpwgData, f->length);
    if (CONFIG_HAS_ABS_CMNR_FILTER && lpwgModeBConfig.lpwgAxis)
    {
      imageFrameProcessor_absFilterApplyFilter(deltaImage, f->length, 0);
    }

    // Update baseline and history indexes
    // history buffer allocates max(MAX_RX, MAX_TX), data array is either MAX_RX or MAX_TX
    memcpy(&lpwgModeBState.lpwgBaseline[lpwgModeBState.lpwgBaselineWriteIdx], lpwgData, f->length*sizeof(lpwgModeBState.lpwgBaseline[0][0]));
    lpwgModeBState.lpwgBaselineWriteIdx++;
    if (lpwgModeBState.lpwgBaselineWriteIdx >= lpwgModeBConfig.lpwgHistorySize)
      lpwgModeBState.lpwgBaselineWriteIdx = 0;
    lpwgModeBState.lpwgBaselineReadIdx++;
    if (lpwgModeBState.lpwgBaselineReadIdx >= lpwgModeBConfig.lpwgHistorySize)
      lpwgModeBState.lpwgBaselineReadIdx = 0;

    COMM_postDebugReport(DBGREPORT_CYCLES, (uint16 *)&f->cycles, 1);
    COMM_endFrame();

    #if CONFIG_HAS_DOZE_DATA_REPORTING
    if((dcfg.forceDoze==1) && (cmd.cmd == CMD_DO_HYBRID_RAW_ADC_TEST))
    {
      uint16 i, hybridRawAdc[MAX_RX+MAX_TX];
      for(i=0;i<MAX_RX;i++)
        hybridRawAdc[i] = lpwgData[i];
      for(i=MAX_RX;i<(MAX_RX+MAX_TX);i++)
        hybridRawAdc[i] = 0;
      COMM_postDebugReport(IMAGE_REPORT_RAW_HYBRID_ADC_RT62, (uint16 *)hybridRawAdc, LEN(hybridRawAdc));
    }
    if((dcfg.forceDoze==1) && (cmd.cmd == CMD_DO_HYBRID_RAW_CAP_TEST))
    {
      uint16 i;
      uint32 hybridRawCap[MAX_RX+MAX_TX];
      PLCapData_t frameCapRawData;
      for(i=0;i<MAX_RX;i++)
        f->data.hybridX[i] = lpwgData[i];
      PL_convertDozeFrameToRawCap(&f->data,&frameCapRawData);
      for(i=0;i<MAX_RX;i++)
        hybridRawCap[i] = (uint32)(frameCapRawData.hybridX[i]);
      for(i=MAX_RX;i<(MAX_RX+MAX_TX);i++)
        hybridRawCap[i] = 0;
      COMM_postDebugReport(IMAGE_REPORT_RAW_HYBRID_CAP_RT63, (uint16 *)hybridRawCap, 2*LEN(hybridRawCap));
    }
    if(dcfg.forceDoze==0)
    #endif
    if (isLpwgModeBWakeUpCondition(&lpwgModeBConfig, deltaImage, f->length))
      objDetected = 1;

    if (gesture_lp_getDoRepeatForceDoze())
    {
      objDetected = 0;
      gesture_lp_setWentToSleep();
    }
    else if (gesture_isAlternateDozeSensing())
    {
      // Exit from forced doze state if (1) doze duration reaches timeout setting
      // or (2) host clears RMI LPWGReporting bit. Otherwise, keep the doze state.
      if (gesture_lp_isAlternateObjectDetect(objDetected))
      {
        if (objDetected)
          gesture_lp_setWentToSleep();
      }
      else
      {
        if (objDetected)
          objDetected = 0;
        gesture_lp_clearWentToSleep();
      }
    }
    else
    {
      if((objDetected) && gesture_lp_isLPWGSensing())
      {
        // Everytime object is detected, false activation counter is incremented
        // by one. If this finger performs gesture, counter will be cleared.
        gesture_lp_incFalseActivationCounter();
      }
    }

    if (objDetected)
    {
      if (currentState == LPWG_MODE_B_DOZE)
      {
        gesture_lp_clearWentToSleep();

        newTouch = 1;
        nextState = LPWG_MODE_B_GESTURE;
      }
      else if (currentState == LPWG_MODE_B_REJECT)
      {
        dozeTimer = timeStamp;
      }
    }
    else if (currentState == LPWG_MODE_B_REJECT && deltaTime > (uint32) rejectTime * 100000)
    {
      printf("Exiting Reject mode\n");
      nextState = LPWG_MODE_B_DOZE;
    }
    else if (deltaTime > (uint32) lpwgModeBConfig.dozeRecalInterval * 10000)
    {
      if (currentState == LPWG_MODE_B_DOZE)
      {
        if (!gesture_isAlternateDozeSensing())
        {
          // Decrement this timer when alternate doze mode in LPWG is off
          // This means that FW dozed for the duration of one doze cycle, implies no moving object was detected
          gesture_lp_decFalseActivationCounter();
        }
        nextState = LPWG_MODE_B_RECALIBRATION;
      }
    }
    PL_releaseFrame(f);
  }

done:
  // We only come here to collect active frames or Mode B TRGT frames.
  lpwgModeBState.currentState = currentState;
  return newTouch;
}

#endif //CONFIG_HIC_LPWG_MODE_B
