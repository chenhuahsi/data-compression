// -----------------------------------------------------------------
// Knuckle
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2016  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//

#ifndef KNUCKLE_H_
#define KNUCKLE_H_

#include "calc2.h"
#include "./ifp/ifp_common.h"

#define _thr_Calc    64
#define _thr_Comm     4

#define ROIPEAK_HEADER          (4)
#define ROIPEAK_CHANNEL         (3)
#define ROIPEAK_WIDTH           (1 + ROIPEAK_CHANNEL + ROIPEAK_CHANNEL)
#define ROIPEAK_PAYLOAD_SIZE    (ROIPEAK_WIDTH * ROIPEAK_WIDTH * 2)
#define ROIPEAK_SIZE            (ROIPEAK_HEADER + ROIPEAK_PAYLOAD_SIZE)
#define ROIP_DELTA_SIZE (49)

#ifdef __cplusplus
extern "C" {
#endif



#if CONFIG_IFP_KNUCKLE
void knuckleRoiCollector(reportData_t *touchData);
uint16 knuckleRoiFIFO() ATTR_ANYROM ATTR_THREAD(_thr_Calc | _thr_Comm);
void getRoiPeak7x7Data(trackedObject_t  *trackedObjPtr,
                       clumps_t         *clumps,
                       reportData_t     *report);
#else
ATTR_INLINE void knuckleRoiCollector(ATTR_UNUSED reportData_t *touchData) {};
ATTR_INLINE void knuckleRoiFIFO() {};
ATTR_INLINE void getRoiPeak7x7Data(ATTR_UNUSED trackedObject_t  *trackedObjPtr,
                                   ATTR_UNUSED clumps_t         *clumps,
                                   ATTR_UNUSED reportData_t     *report) {};
#endif

#ifdef __cplusplus
};
#endif

#endif /* KNUCKLE_H_ */
