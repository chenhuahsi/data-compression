// -----------------------------------------------------------------
// User Defined Gesture Recognizer
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 904-1100
//
// $Id: func_12.h,v 1.20.18.6.4.32.2.13 2014/10/03 08:48:42 yahuic Exp $
//

//#include "StdAfx.h"
//#include "math.h"
#include <string.h>
#include "calc2.h"
#include "math_func.h"
#include "gesture_recognizer.h"
#if CONFIG_LPWG_USERDEFINED_FLASHSTORAGE_EANBLE
  #include "ext_flash_cif.h"
#endif

#define MAX_RETRIES_TO_RELOAD_GESTURE 3
#define MAX_NUM_INDEX                 2

#define min(a, b)   ( (a < b) ? a : b )
#define max(a, b)   ( (a > b) ? a : b )
#define abs(a)      ( (a >= 0) ? a : -(a) )

static struct {
  udgParams_t cfg;
} params;

udgTemplate_t udgTemplates[CONFIG_LPWG_USERDEFINED_NUMTEMPLATES];


float range_of(float *values, unsigned length)
{
  //range Calculate range of values
  //
  // values - vector of values
  // length - length of x (included for C implementation)

  // calculate range;

  uint16 i;
  float minValue = values[0];
  float maxValue = values[0];

  for (i = 1; i < length; i ++)
  {
    if (minValue > values[i])
    {
      minValue = values[i];
    }

    if (maxValue < values[i])
    {
      maxValue = values[i];
    }
  }

  return(1 + maxValue - minValue);
}


void positionFeatures(udgTemplate_t *features, udgTrace_t *data, uint16 forceSingle)
{
  //positionFeatures Process position data into position features
  //
  // data - structure of gesture data with fields of:
  //         x - x position (mm)
  //         y - y position (mm)
  //         seg - segment index (zero-based)
  // forceSingle - boolean to force single stroke processing
  // features - gesture features data structure with fields of:
  //         x - x position in mm's offset by COM
  //         y - y position in mm's offset by COM
  //         segments - total number of segments (strokes) in gesture
  //         scaling - recognition cost scaling factor
  //         valid - boolean to indicate validity of value

  // initialize
  uint16 featureSize = 0;
  float cumLength = 0.0f;
  uint16 i, j, k;
  uint16 numSeg = 0;

  // check for single stroke mode
  if (forceSingle)
  {
    for (i = 0; i < data->numPts; i ++)
    {
      data->pos[i].seg = 0;  // force all points to segment 0
    }
  }

  // calculate each segment
  for (i = 0; i < data->numPts - 1; i ++)
  {
    uint16 diff = data->pos[i + 1].seg - data->pos[i].seg;
    numSeg += diff;  // total number of segments (strokes)
  }

  numSeg += 1;

  uint16 dataSegSize;
  uint16 segSize;
  uint16 indSeg[CONFIG_LPWG_USERDEFINED_NUMPOINTS];
  uint16 indSeg0;
  float difx[CONFIG_LPWG_USERDEFINED_NUMPOINTS];
  float dify[CONFIG_LPWG_USERDEFINED_NUMPOINTS];
  float segLen[CONFIG_LPWG_USERDEFINED_NUMPOINTS];
  float segLenCum[CONFIG_LPWG_USERDEFINED_NUMPOINTS];
  float spacing[CONFIG_LPWG_USERDEFINED_NUMFEATURES];
  float tmp;

  for (i = 0; i < numSeg; i ++)
  {
    // determine segment size
    //segSize = (uint16)floor( ( (float)(p.templateSize - featureSize) / (float)(numSeg - i) ) );
    segSize = ((params.cfg.templateSize - featureSize) / (numSeg - i));

    // calculate segment interpolated spacing
    k = 0;

    for (j = 0; j < data->numPts; j ++)
    {
      if (data->pos[j].seg == i)
      {
        indSeg[k] = j;  // data.seg is zero-based
        k++;
      }
    }

    dataSegSize = k;

    indSeg0 = indSeg[0];

    segLenCum[0] = 0.0f;

    if (dataSegSize == 1)
    {
      for (j = 0; j < segSize; j ++)
      {
        features->x[featureSize + j] = data->pos[indSeg0].x;
        features->y[featureSize + j] = data->pos[indSeg0].x;
      }
    }
    else
    {
      for (j = 0; j < dataSegSize - 1; j ++)
      {
        uint16 indTmp = indSeg[j];
        difx[j] = data->pos[indTmp + 1].x - data->pos[indTmp].x;  // row vector of first differences
        dify[j] = data->pos[indTmp + 1].y - data->pos[indTmp].y;  // row vector of first differences

        segLen[j] = sqrtf(difx[j]*difx[j] + dify[j]*dify[j]);  // row vector of relative euclidean distances

        segLenCum[j + 1] = segLenCum[j] + segLen[j];  // row vector of cumulative distances
      }

      for (j = 0; j < segSize; j ++)
      {
        spacing[j] = ((float)j + 0.5f) * segLenCum[dataSegSize - 1] / segSize;  // row vector of uniform template spacing distance
      }

      // interpolate segment position features
      for (j = 0; j < segSize; j ++)
      {
        // find the nearest smaller sample point
        //
        k = 0;

        while (spacing[j] > segLenCum[k])
        {
          k ++;
        }

        if (k > 0)
        {
          k -= 1;
        }

        // interpolate data positions to get position features
        //tmp = (spacing[j] - segLenCum[k]) / segLen[k];

        tmp = (spacing[j] - segLenCum[k]);
        tmp = tmp / segLen[k];

        float dx = difx[k] * tmp;
        float dy = dify[k] * tmp;

        features->x[featureSize + j] = data->pos[indSeg0 + k].x + dx;
        features->y[featureSize + j] = data->pos[indSeg0 + k].y + dy;
      }
    }

    // update cumulative length
    cumLength = cumLength + segLenCum[dataSegSize - 1];

    // update segment index
    featureSize = featureSize + segSize;
  }

  float sumx = 0.0f;
  float sumy = 0.0f;

  // translate position features by COM
  for (j = 0; j < params.cfg.templateSize; j ++)
  {
    sumx += features->x[j];
    sumy += features->y[j];
  }

  for (j = 0; j < params.cfg.templateSize; j ++)
  {
    features->x[j] = features->x[j] - sumx/params.cfg.templateSize;
    features->y[j] = features->y[j] - sumy/params.cfg.templateSize;
  }

  // set number of segments
  features->segments = numSeg;

  // set recognition cost scaling factor
  float maxSize = max ( range_of(features->x, CONFIG_LPWG_USERDEFINED_NUMFEATURES), range_of(features->y, CONFIG_LPWG_USERDEFINED_NUMFEATURES) );
  features->scaling = min(1.5f, max(0.5f, 2.0f * maxSize / cumLength) );  // scaling decreases with increasing gesture density

  // set valid flag
  features->valid = 1;
}


void angleFeatures(float *angles, float *xfeatures, float *yfeatures, uint16 length)
{
  //angleFeatures Process angle features
  //
  //xfeatures - x position in mm's offset by COM
  //yfeatures - y position in mm's offset by COM
  //length - length of features

  uint16 i;

  //determine angle between points
  for (i = 0; i < length - 1; i ++)
  {
    float xdif = xfeatures[i+1] - xfeatures[i];  // row vector of first differences (size = length-1)
    float ydif = yfeatures[i+1] - yfeatures[i];  // row vector of first differences (size = length-1)
    angles[i] = atan2f(ydif, xdif);  // row vector of relative angles in radians (size = length-1)
  }

  angles[length - 1] = 0;  // no information exists at this end of the data, so set to zero (size = length)
}


void indexFeatures(udgTemplate_t *features, udgTemplate_t *features1, udgTemplate_t *features2)
{
    //indexFeatures Calculates a partial elastic match of two gestures
    //              using only forward point shifts of second gesture
    // features1 - gesture 1 features
    // features2 - gesture 2 features
    // features  - matched gesture 2 features
    float angles1[CONFIG_LPWG_USERDEFINED_NUMFEATURES], angles2[CONFIG_LPWG_USERDEFINED_NUMFEATURES];

    // calculate angles
    angleFeatures(angles1, features1->x, features1->y, params.cfg.templateSize);
    angleFeatures(angles2, features2->x, features2->y, params.cfg.templateSize);

    // find min distance
    uint16 ind[CONFIG_LPWG_USERDEFINED_NUMFEATURES] = {0};
    uint16 i, j, k, m, n;
    float erri[MAX_NUM_INDEX + 1];
    float r[MAX_NUM_INDEX + 1];
    float rmin;

    for (i = 0; i < params.cfg.templateSize; i ++)  // 1-based index for Matlab
    {
        if (i > 0)
        {
            j = max(ind[i - 1], i);  // 1-based index for Matlab
        }
        else
        {
            j = 0;
        }

        k = min(params.cfg.templateSize, i + params.cfg.templateDisp);

        for (m = j; m <= k; m ++)
        {
            erri[m - j] = features2->x[m] - features1->x[i];  // row vector
            r[m - j] = erri[m - j] * erri[m - j];
        }

        for (m = j; m <= k; m ++)
        {
            erri[m - j] = features2->y[m] - features1->y[i];  // row vector
            r[m - j] += erri[m - j] * erri[m - j];
        }

        for (m = j; m <= k; m ++)
        {
            erri[m - j] = angles2[m] - angles1[i];  // row vector
            r[m - j] += erri[m - j]*erri[m - j];
        }

        rmin = r[0];
        n = j;
        for (m = j + 1; m <= k; m ++)
        {
            if (r[m - j] < rmin)
            {
                rmin = r[m - j];
                n = m;
            }
        }

        ind[i] = n;  // index offset by starting indice*/
    }

    // update features
    for (i = 0; i < params.cfg.templateSize; i ++)  // 1-based index for Matlab
    {
        features->x[i] = features2->x[ind[i] ];
        features->y[i] = features2->y[ind[i] ];
    }

    features->scaling = features2->scaling;
    features->segments = features2->segments;
    features->valid = features2->valid;
}


float matchFeatures(udgTemplate_t *tfeatures, udgTemplate_t *ufeatures)
{
    //matchFeatures Match user gesture against template
    //
    // tfeatures - template features structure
    // ufeatures - user gesture features structure
    //   features data structures have fields of:
    //         x - x position in mm's offset by COM
    //         y - y position in mm's offset by COM
    //         segments - total number of segments (strokes) in gesture
    //         scaling - recognition cost scaling factor
    //         valid - boolean to indicate validity of values
    // metric - feature match metric [-100 100] (>0 = match)
    // x (debug only use) - rotated x position in mm's offset by COM
    // y (debug only use) - rotated y position in mm's offset by COM

    // initialize output
    float metric = 0;  // no match
    uint16 i;
    float a, b;
    float theta;
    float x[CONFIG_LPWG_USERDEFINED_NUMFEATURES], y[CONFIG_LPWG_USERDEFINED_NUMFEATURES];
    float tangles[CONFIG_LPWG_USERDEFINED_NUMFEATURES], uangles[CONFIG_LPWG_USERDEFINED_NUMFEATURES];

    // determine angle between vectors
    a = 0;
    b = 0;
    for (i = 0; i < params.cfg.templateSize; i ++)
    {
        a += tfeatures->x[i] * ufeatures->x[i] + tfeatures->y[i] * ufeatures->y[i];  // dot products
        b += tfeatures->x[i] * ufeatures->y[i] - tfeatures->y[i] * ufeatures->x[i];  // dot products
    }

    theta = atan2f(b, a);

    // rotate template by angle to coincide
    for (i = 0; i < params.cfg.templateSize; i ++)
    {
        x[i] = cosf(theta) * tfeatures->x[i] - sinf(theta) * tfeatures->y[i];  // row vectors
        y[i] = sinf(theta) * tfeatures->x[i] + cosf(theta) * tfeatures->y[i];  // row vectors
    }

    // determine scale
    float xscale = range_of(ufeatures->x, params.cfg.templateSize)/range_of(x, params.cfg.templateSize);  // range is strictly positive
    float yscale = range_of(ufeatures->y, params.cfg.templateSize)/range_of(y, params.cfg.templateSize);  // range is strictly positive

    // check scale
    if ( (min(xscale, yscale) < 1.0f / params.cfg.scaleInvariance) || (max(xscale, yscale) > params.cfg.scaleInvariance) )
    {
        //figure(1);plot(tfeatures.x,tfeatures.y,'ko-',ufeatures.x,ufeatures.y,'rx-');grid on;xlim([-30 30]);
        //printf("the scale is bad\n");

        return -110.0;
    }

    // calculate angles
    angleFeatures(tangles, x, y, params.cfg.templateSize);
    angleFeatures(uangles, ufeatures->x, ufeatures->y, params.cfg.templateSize);

    // create angle difference
    float ang[CONFIG_LPWG_USERDEFINED_NUMFEATURES];
    float angErr = 0.0f;

    for (i = 0; i < params.cfg.templateSize; i++)
    {
        ang[i] = tangles[i] - uangles[i];  // row vector

        if (ang[i] > PIF)
        {
            ang[i] = ang[i] - 2.0f * PIF;
        }

        if (ang[i] < -PIF)
        {
            ang[i] = ang[i] + 2.0f * PIF;
        }

        angErr += ang[i]*ang[i];
    }

    // limit difference to [-pi, pi]
    //ind = find(ang > pi);  // indices where ang value is > pi
    //ang(ind) = 2*pi - ang(ind);  // shift values at those indices to [0, pi] range

    // average angular distance error
    angErr = sqrtf(angErr)/params.cfg.templateSize;

    // calculate match metric
    float vtt = 0;
    float vuu = 0;
    float vtu = 0;

    for (i = 0; i < params.cfg.templateSize; i++)
    {
        vtt += x[i]*x[i] + y[i]*y[i];  // dot product
        vuu += ufeatures->x[i]*ufeatures->x[i] + ufeatures->y[i]*ufeatures->y[i];  // dot product
        vtu += x[i]*ufeatures->x[i] + y[i]*ufeatures->y[i];  // dot product
    }

    if ( (vtt != 0) && (vuu != 0) )
    {
        float max_scaling =  max(tfeatures->scaling, ufeatures->scaling);

        // position angular error
        float tmp = vtu/sqrtf(vtt)/sqrtf(vuu);

        float posErr = acosf(max(-1.0f, min(1.0f, tmp) ) );

        // rotation angular error - hits mismatch at additional 1x the rotation invariance
        float rotErr = params.cfg.thresholdFactor / max_scaling / params.cfg.rotationInvariance * max(0, (abs(theta) - params.cfg.rotationInvariance) );

        //strErr = obj.p.thresholdFactor/max(tfeatures.scaling,ufeatures.scaling)*0.01*abs(tfeatures.segments-ufeatures.segments);
        float strErr = params.cfg.thresholdFactor / max_scaling * 0.01 * abs((int)tfeatures->segments - (int)ufeatures->segments);
        // total error
        //totalErr = min(200,100/obj.p.thresholdFactor*max(tfeatures.scaling,ufeatures.scaling) * (angErr + posErr + rotErr));
        float totalErr = min(200.0f, 100.0f / params.cfg.thresholdFactor * max_scaling * (angErr + posErr + rotErr + strErr) );

        // map to metric reange of [-100 100]
        metric = 100.0f - totalErr;
    }

    return metric;
}


uint16 registerTemplate(udgTemplate_t *features, udgTrace_t *data, uint16 sample)
{
  //registerTemplate Registers template using multiple gesture registrants
  //
  // features - gesture features data structure with fields of:
  //         x - x position in mm's offset by COM
  //         y - y position in mm's offset by COM
  //         segments - total number of segments (strokes) in gesture
  //         scaling - recognition cost scaling factor
  //         valid - boolean to indicate validity of values
  // data - structure of gesture data with fields of:
  //         x - x position (mm)
  //         y - y position (mm)
  //         seg - segment index (zero-based)
  // sample - gesture registrant sample number (one-based)
  // err - error flag (registration denied if true)

  // initialize
  uint16 err = 0;
  float metric;

  // extract new data features
  udgTemplate_t ifeatures;
  memset((void*)&ifeatures, 0, sizeof(udgTemplate_t));

  positionFeatures(&ifeatures, data, 0);

  // check for match to existing template features
  if (sample > 0)
  {
    // disallow registration if not matching number of segments
    if (features->segments != ifeatures.segments)
    {
      err = 1;
    }
    else
    {
      // check for match with prior registrants
      metric = matchFeatures(features, &ifeatures);
      // disallow registration if no match
      err = (metric <= 0);
    }
  }
  else
  {
    // initialize segments
    features->segments = ifeatures.segments;
  }

  // update template with new data features
  if (!err)
  {
    // update averages
    uint16 i;

    for (i = 0; i < params.cfg.templateSize; i ++)
    {
      features->x[i] = (float)sample/(float)(sample + 1)*features->x[i] + 1/(float)(sample + 1)*ifeatures.x[i];
      features->y[i] = (float)sample/(float)(sample + 1)*features->y[i] + 1/(float)(sample + 1)*ifeatures.y[i];
    }

    features->scaling = (float)sample/(float)(sample + 1)*features->scaling + 1/(float)(sample + 1)*ifeatures.scaling;
  }

  return err;
}


void setTemplate(udgTemplate_t *features, uint16 index)
{
  //setTemplate Sets template features at index location
  //
  // features - gesture features data structure with fields of:
  //         x - x position in mm's offset by COM
  //         y - y position in mm's offset by COM
  //         segments - total number of segments (strokes) in gesture
  //         scaling - recognition cost scaling factor
  //         valid - boolean to indicate validity of values
  // index - template index (zero-based)

  // limit index range
  if (index > params.cfg.numTemplatesMax - 1)
  {
    index = params.cfg.numTemplatesMax - 1;
  }

  // update templates
  udgTemplates[index] = *features;  // one-based index in Matlab
  udgTemplates[index].valid = 1;    // one-based index in Matlab

  // update number of templates
  //updateNumberTemplates();
  //++ p.numTemplates;
}


void loadTemplate(udgTemplate_t *features, uint16 index)
{
    //setTemplate Sets template features at index location
    //
    // features - gesture features data structure with fields of:
    //         x - x position in mm's offset by COM
    //         y - y position in mm's offset by COM
    //         segments - total number of segments (strokes) in gesture
    //         scaling - recognition cost scaling factor
    //         valid - boolean to indicate validity of values
    // index - template index (zero-based)

    // limit index range
    if (index >= (params.cfg.numTemplatesMax - 1) )
    {
      index = params.cfg.numTemplatesMax - 1;
    }

    //index = max(0, min(p.numTemplatesMax - 1, index) );

    // update templates
    *features = udgTemplates[index];  // one-based index in Matlab

    // update number of templates
    //updateNumberTemplates();
}


float gestureTest(udgTemplate_t *tfeatures, udgTemplate_t *ufeatures)
{
    udgTemplate_t features;

    // find minimum variance user index match
    indexFeatures(&features, tfeatures, ufeatures);
    // extract match metric
    float umetric = matchFeatures(tfeatures, &features);

    // find minimum variance template index match
    indexFeatures(&features, ufeatures, tfeatures);
    // extract match metric
    float tmetric = matchFeatures(&features, ufeatures);

    // set to max
    float metric = max(umetric, tmetric);

    return metric;
}


void gestureRecognizer_boot()
{
  #if CONFIG_LPWG_USERDEFINED_FLASHSTORAGE_EANBLE
    externalFlash_loadUDGTemplates(&udgTemplates[0]);
  #endif //CONFIG_LPWG_USERDEFINED_FLASHSTORAGE_EANBLE
}


void gestureRecognizer_init(calcStaticConfig_t *cfg)
{
  params.cfg = cfg->udgParams;
}


int gestureRecognizer_registration(udgTrace_t *pData, uint16 templateIndex, uint16 *tryIndex)
{
  static udgTemplate_t tfeatures;

  uint16 status = REGISTRATION_SUCCESS;

  if (templateIndex > CONFIG_LPWG_USERDEFINED_NUMTEMPLATES)
  {
    status = REGISTRATION_FAILURE_INDEX_EXCEEDED_MAXIMUM;
  }
  else
  {
    uint16 i;

    if (*tryIndex == 0)
    {
      memset((void*)&tfeatures, 0, sizeof(udgTemplate_t));
    }

    uint16 err = registerTemplate(&tfeatures, pData, *tryIndex);

    if (err)
    {
      status = REGISTRATION_FAILURE_NOT_MATCHED_PREV_TRY;
    }
    else
    {
      // check for unique gesture
      for (i = 0; i < params.cfg.numTemplatesMax; i ++)
      {
        if ( (i != templateIndex) && (udgTemplates[i].valid) )
        {
          // check for match with prior templates
          float metric;
          metric = matchFeatures(&udgTemplates[i], &tfeatures);
          // disallow registration if match
          if (metric > 0)
          {
            err = 1;
            status = REGISTRATION_FAILURE_MATCHED_OTHER_TEMPLATE;

            break;
          }
        }
      }
    }

    if (!err)
    {
      *tryIndex += 1;
    }

    if ( *tryIndex == 3)
    {
      setTemplate(&tfeatures, templateIndex);

      *tryIndex = 0;
    }
  }

  return status;
}


float gestureRecognizer_gestureMatch(udgTrace_t *pData, uint16 *templateIndex)
{
  udgTemplate_t tfeatures, ufeatures;

  memset((void*)&tfeatures, 0, sizeof(udgTemplate_t));
  memset((void*)&ufeatures, 0, sizeof(udgTemplate_t));

  uint16 i, j = 0, k;
  float tmp, metric;

  uint16 ufeatures_has_been_changed = 1;

  metric = -127.0f;

  for (i = 0; i < params.cfg.numTemplatesMax; i++)
  {
    if (udgTemplates[i].valid)
    {
      if (ufeatures_has_been_changed)
      {
        positionFeatures(&ufeatures, pData, 0);

        ufeatures_has_been_changed = 0;
      }

      loadTemplate(&tfeatures, i);

      uint16 nsegments;

      // match number of segments if necessary
      if (tfeatures.segments != ufeatures.segments)
      {
        // force template gesture to be single stroke
        if (tfeatures.segments != 1)
        {
          nsegments = tfeatures.segments;

          udgTrace_t tData;

          for (k = 0; k < params.cfg.templateSize; k ++)
          {
            tData.pos[k].x = tfeatures.x[k];
            tData.pos[k].y = tfeatures.y[k];
            tData.pos[k].seg = 0;
          }

          tData.numPts = params.cfg.templateSize;

          positionFeatures(&tfeatures, &tData, 1);

          tfeatures.segments = nsegments;
        }

        // force user gesture to be single stroke
        if (ufeatures.segments != 1)
        {
          ufeatures_has_been_changed = 1;

          nsegments = ufeatures.segments;

          positionFeatures(&ufeatures, pData, 1);

          ufeatures.segments = nsegments;
        }
      }

      tmp = gestureTest(&tfeatures, &ufeatures);

      if (metric < tmp)
      {
        metric = tmp;
        j = i;
      }
    }
  }

  *templateIndex = j;

  return metric;
}
