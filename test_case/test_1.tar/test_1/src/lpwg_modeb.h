/* -----------------------------------------------------------------
 *
 *
 *                      COMPANY CONFIDENTIAL
 *                       INTERNAL USE ONLY
 *
 * Copyright (C) 2016  Synaptics Incorporated.  All right reserved.
 *
 * This document contains information that is proprietary to Synaptics
 * Incorporated. The holder of this document shall treat all information
 * contained herein as confidential, shall use the information only for its
 * intended purpose, and shall protect the information in whole or part from
 * duplication, disclosure to any other party, or dissemination in any media
 * without the written permission of Synaptics Incorporated.
 *
 * Synaptics Incorporated
 * 1251 McKay Drive
 * San Jose, CA  95131
 * (408) 904-1100
 */
// Filename: lpwg_modeb.h
// Description: header file for lpwg_modeb.c

#ifndef _LPWG_MODEB_H_
#define _LPWG_MODEB_H_

#include "calc2.h"

#if CONFIG_HIC_LPWG_MODE_B

#if !defined(MAX_LPWG_MODE_B_HISTORY)
#define MAX_LPWG_MODE_B_HISTORY  10
#endif

#if MAX_PHY_RX > MAX_PHY_TX
  #define MAX_MODE_B_LPWG MAX_PHY_RX
#else
  #define MAX_MODE_B_LPWG MAX_PHY_TX
#endif

typedef enum {
  // HIC required firmware to control power signals, TDDI uses the video thread to manage the DDIC power states
  // If these values change update the check against LPWG_MODE_B_GESTURE in func_12.cpp
  LPWG_MODE_B_ACTIVE = 0,           // not in LPWG
  LPWG_MODE_B_BASELINE = 1,         // initial baseline collection when start ModeB
  LPWG_MODE_B_DOZE = 2,             // finger detection
  LPWG_MODE_B_GESTURE = 3,          // gesture detecton
  LPWG_MODE_B_REJECT = 4,           // gesture rejection
  LPWG_MODE_B_RECALIBRATION = 5,    // periodic baseline recalibration
  LPWG_MODE_B_CBC_SCAN = 6,         // CBC scan at the beginning
} lpwgModeBStates_t;

typedef struct {
  uint32 dozeHoldOffTimer;
  int16 lpwgBaseline[MAX_LPWG_MODE_B_HISTORY][MAX_MODE_B_LPWG];
  uint16 lpwgBaselineReadIdx;
  uint16 lpwgBaselineWriteIdx;
  uint16 acquireLpwgBaseline : 7;   // collect baseline - set to n, which ignores n-1 frame on entry
  uint16 acquireTrgtBaseline : 7;   // collect baseline - set to n, which ignores n-1 frame on entry
  uint16 dozeHoldOffTimerValid : 1;
  lpwgModeBStates_t currentState;
} lpwgModeBState_t;

extern lpwgModeBState_t lpwgModeBState;

void lowPower_lpwgModeB_init(lpwgModeBParams_t *lpwgParams);
uint16 lowPower_lpwgModeB_handler(uint16 resetDoze, uint32 timeStamp, uint16 rejectTime);
uint16 lowPower_lpwgModeB_running();
uint16 lowPower_lpwgModeB_recal();
uint16 lowPower_lpwgModeB_fingerGesture();
uint16 lowPower_lpwgModeB_isRezeroRequested();
#else
static ATTR_INLINE void lowPower_lpwgModeB_init(lpwgModeBParams_t *lpwgParams ATTR_UNUSED){};
static ATTR_INLINE uint16 lowPower_lpwgModeB_handler(uint16 resetDoze ATTR_UNUSED, uint32 timeStamp ATTR_UNUSED, uint16 rejectTime ATTR_UNUSED) { return 0;};
static ATTR_INLINE uint16 lowPower_lpwgModeB_running() { return 0;};
static ATTR_INLINE uint16 lowPower_lpwgModeB_fingerGesture() { return 0;};
static ATTR_INLINE uint16 lowPower_lpwgModeB_isRezeroRequested() { return 0;};
#endif

#endif
