#include "calc2.h"

#if CONFIG_NSM_GANYMEDE

#include "platform.h"
#include "nsm2.h"

// static data
static nsm_object_t nsm_object;

//static function definitions go here


// NSM Specific Functions.
//===========================
// These are the functions that are individualized for each NSM version.
// For Ganymede, the specific functions are:
//    nsm_init()
//    nsm_evalNSM()
//    nsm_reportObjects()

void nsm_init(nsm_params_t *nsmParams)
{
  uint16 k;
  uint16 *fsimPtr = nsm_object.nsm_ims.fsim;
  uint16 first_frequency, best_frequency;

  // Set the Parameters.
  nsm_setParams(nsmParams);

  // Initialize the IMs.
  nsm_object.nsm_ims.powerim = 0;
  nsm_object.nsm_ims.cidim = 0;
  nsm_object.nsm_ims.railim = 0;
  for (k = 0; k < MAX_FREQUENCIES; ++k)
  {
    *(fsimPtr++) = 0;
  }

  nsm_setChargerPresent(NSM_CHARGER_BIT_LOW);

  nsm_object.nsm_internal.noiseScanFlag = 0;

  first_frequency = nsm2base_selectFirstFreq(&nsm_object, 0, MAX_FREQUENCIES);
  nsm_setCurrentFreq(first_frequency);

  // Measure the RX Offsets.
  nsm2base_measureRcvrOffsets(&nsm_object);

  // Determine initial state:
  if ((nsm_object.nsm_params.inhibitFrequencyShift) ||
      ((nsm_object.nsm_params.disableFreq+1) == (1 << MAX_FREQUENCIES)))
  {
    nsm_setCurrentState(NSM_HNM_STATE);
    nsm_object.nsm_internal.fsTimer = 0;
    nsm_object.nsm_internal.fsPrimed = 1;
  }
  else
  {
    best_frequency = nsm_executeFrequencyScan(0, MAX_FREQUENCIES);
    nsm_setCurrentFreq(best_frequency);
    if (nsm_object.nsm_ims.fsim[nsm_object.nsm_statevars.currentFreq] <= nsm_object.nsm_params.fsimThresh)
    {
      nsm_setCurrentState(NSM_HNM_STATE);
    }
    else
    {
      nsm_setCurrentState(NSM_FNM_STATE);
    }
  }

  nsm_object.nsm_statevars.abortFrame = 0;
  nsm_object.nsm_statevars.frequencyShift = 0;
  nsm_object.nsm_internal.lastFreq = MAX_FREQUENCIES;
}

void nsm_evalNSM(uint16 noNoiseMitigation, DAQFrame_t *f)
{
  PLFrameData_t *frameData = (PLFrameData_t *) f->buffer;
  uint16 powerimDensity, bitShiftVector;
  uint16 powerimHigh, powerimLow, powerimDensityHigh,
    cidimHigh, cidimLow, railimHigh, railimLow, fsAllowed, chargerHigh;
  uint16 disableFreqAll = ((nsm_object.nsm_params.disableFreq+1) == (1 << MAX_FREQUENCIES));
  uint16 best_frequency;

  // Default values for this flag.
  nsm_object.nsm_statevars.abortFrame = 0;

  // Check the freq scan timing.
  if (!nsm_object.nsm_internal.fsPrimed &&
      ((f->timeStamp - nsm_object.nsm_internal.fsTimer) >= ((uint32) nsm_object.nsm_params.fsTimeout * 1000000)))
  {
    nsm_object.nsm_internal.fsPrimed = 1;
  }

  // Calculate the IMs:
  nsm2base_calcPowerIM(&nsm_object, frameData->noise);
  nsm2base_calcCidIM(&nsm_object, frameData->hwIntfr);
  nsm2base_calcRailIM(&nsm_object, frameData->hwIntfr);

  // Do the IM threshold comparisons.
  powerimHigh = nsm_object.nsm_ims.powerim > nsm_object.nsm_params.powerimHighThresh;
  powerimLow = nsm_object.nsm_ims.powerim <= nsm_object.nsm_params.powerimLowThresh;
  cidimHigh = nsm_object.nsm_ims.cidim > nsm_object.nsm_params.cidimHighThresh;
  cidimLow = nsm_object.nsm_ims.cidim <= nsm_object.nsm_params.cidimLowThresh;
  railimHigh = nsm_object.nsm_ims.railim > nsm_object.nsm_params.railimHighThresh;
  railimLow = nsm_object.nsm_ims.railim <= nsm_object.nsm_params.railimLowThresh;

  // Will a frequency scan be allowed, if called for?
  fsAllowed = (nsm_object.nsm_internal.fsPrimed &&
               !(nsm_object.nsm_params.inhibitFrequencyShift ||
                 disableFreqAll));

  // Is the charger bit high, and is it to be considered?
  chargerHigh = nsm_object.nsm_params.enableChargerBit && nsm_object.nsm_internal.chargerPresent;

  if (!noNoiseMitigation)
  {
    switch (nsm_object.nsm_statevars.currentState)
    {
      case NSM_HNM_STATE:
        if (railimHigh || ((powerimHigh || cidimHigh) && !fsAllowed) || chargerHigh)
        {
          nsm_object.nsm_statevars.abortFrame = 1;
          DAQ_releaseFrame(f);
          nsm_setCurrentState(NSM_FNM_STATE);
        }
        else if (powerimHigh)
        {
          nsm_object.nsm_statevars.abortFrame = 1;
          DAQ_releaseFrame(f);
          best_frequency = nsm_executeFrequencyScan(0, MAX_FREQUENCIES);
          nsm_setCurrentFreq(best_frequency);
          if (nsm_object.nsm_ims.fsim[nsm_object.nsm_statevars.currentFreq] <= nsm_object.nsm_params.fsimThresh)
          {
            nsm_setCurrentState(NSM_HNM_STATE);
          }
          else
          {
            nsm_setCurrentState(NSM_FNM_STATE);
          }
        }
        else if (cidimHigh)
        {
          nsm_object.nsm_statevars.abortFrame = 1;
          DAQ_releaseFrame(f);
          best_frequency = nsm_executeFrequencyScan(0, MAX_FREQUENCIES);
          nsm_setCurrentFreq(best_frequency);
          nsm_setCurrentState(NSM_FNM_STATE);
        }
        break;
      case NSM_FNM_STATE:
        // Prior to making an NSM decision, we need to check the powerIM
        // density over the past few frames.
        nsm_object.nsm_internal.powerimBitVector = ((nsm_object.nsm_internal.powerimBitVector << 1) |
          (nsm_object.nsm_ims.powerim > nsm_object.nsm_params.powerimFnmHighThresh));
        bitShiftVector = nsm_object.nsm_internal.powerimBitVector;
        for (powerimDensity = 0; bitShiftVector != 0; bitShiftVector &= (bitShiftVector-1))
        {
          powerimDensity++;
        }
        powerimDensityHigh = powerimDensity >= nsm_object.nsm_internal.fsFnmDensityScaled;
        // Now we actually make the NSM decision.
        if (powerimDensityHigh && !railimHigh && fsAllowed)
        {
          nsm_object.nsm_statevars.abortFrame = 1;
          DAQ_releaseFrame(f);
          best_frequency = nsm_executeFrequencyScan(0, MAX_FREQUENCIES);
          nsm_setCurrentFreq(best_frequency);
          nsm_setCurrentState(NSM_FNM_STATE);
        }
        else if (powerimLow && railimLow && cidimLow && !chargerHigh)
        {
          nsm_object.nsm_internal.lowimFlag = 1;
        }
        else
        {
          nsm_object.nsm_internal.lowimFlag = 0;
        }
        break;
    }
  }
  nsm_object.nsm_statevars.frequencyShift = (uint16) (nsm_object.nsm_internal.lastFreq != nsm_object.nsm_statevars.currentFreq);
  nsm_object.nsm_internal.lastFreq = nsm_object.nsm_statevars.currentFreq;
}


void nsm_reportObjects(uint16 objectsPresent)
{
  switch (nsm_object.nsm_statevars.currentState)
  {
    case NSM_FNM_STATE:
      if (objectsPresent && nsm_object.nsm_internal.lowimFlag)
      {
        if (++nsm_object.nsm_internal.lowimTime >= nsm_object.nsm_params.fnmTimeout)
        {
          nsm_setCurrentState(NSM_HNM_STATE);
        }
      }
      else if (objectsPresent)
      {
        nsm_object.nsm_internal.lowimTime = 0;
      }
      break;
  }
}


// NSM Query Functions.
//===========================
// Return internal NSM variables; for use by outside functions.

nsm_ims_t nsm_getIms()
{
  return nsm_object.nsm_ims;
}

nsm_params_t nsm_getParams()
{
  return nsm_object.nsm_params;
}

nsm_statevars_t nsm_getStatevars()
{
  return nsm_object.nsm_statevars;
}

void nsm_getRcvrOffsets(uint16 *rcvr_offsets)
{
  uint16 k;

  for (k = 0; k < MAX_RX; ++k)
  {
    rcvr_offsets[k] = nsm_object.rcvrOffsets[k];
  }
}


// Base NSM Wrappers.
//===========================
// These are public wrappers for those functions in the base NSM which may
// be called from outside.  They are also used when calling those base
// functions internally in this NSM.

void nsm_setChargerPresent(uint16 chargerPresent)
{
  nsm2base_setChargerPresent(&nsm_object, chargerPresent);
}

void nsm_setCurrentState(uint16 state)
{
  nsm2base_setCurrentState(&nsm_object, state);
}

void nsm_setParams(nsm_params_t *nsmParams)
{
  nsm2base_setParams(&nsm_object, nsmParams);
}

void nsm_setCurrentFreq(uint16 frequency)
{
  nsm2base_setCurrentFreq(&nsm_object, frequency);
}

uint16 nsm_executeFrequencyScan(uint16 freq_start, uint16 freq_end)
{
  return nsm2base_executeFrequencyScan(&nsm_object, freq_start, freq_end);
}
#endif
