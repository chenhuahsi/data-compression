// -----------------------------------------------------------------
//
//                      COMPANY CONFIDENTIAL
//                       INTERNAL USE ONLY
//
// Copyright (C) 1997 - 2015  Synaptics Incorporated.  All right reserved.
//
// This document contains information that is proprietary to Synaptics
// Incorporated. The holder of this document shall treat all information
// contained herein as confidential, shall use the information only for its
// intended purpose, and shall protect the information in whole or part from
// duplication, disclosure to any other party, or dissemination in any media
// without the written permission of Synaptics Incorporated.
//
// Synaptics Incorporated
// 1251 McKay Drive
// San Jose, CA   95131
// (408) 454-5100
//
// -----------------------------------------------------------------
//
//
// Filename: esd.c
// Description: All the esd modules, including esd detector, esd handler and esd mitigation
#include <string.h>

#include "daq2.h"
#include "calc2.h"
#include "esd.h"
#include "ifp/ifp_common.h"
#if CONFIG_IFP_ESD_ACTIVEMODE
#include "ifp/image_frame_processor.h"
#include "platform.h"
#endif

#if CONFIG_HAS_TDDI_ESD_DETECTOR || CONFIG_HAS_TDDI_ESD_HANDLER
uint16 ESD_Detected;
#endif
#if CONFIG_HAS_TDDI_ESD_IMAGE_CHECKER || CONFIG_HAS_TDDI_ESD_HANDLER
uint16 ESD_image_detected;
#endif
#if CONFIG_HAS_TDDI_ESD_SLEEP_OUT_CHECK
static uint16 SLEEPOUT_CNT;
#endif
#if CONFIG_HAS_TDDI_ESD_DETECTOR || CONFIG_IFP_ESD_ACTIVEMODE
void esd_init(){
  #if CONFIG_HAS_TDDI_ESD_DETECTOR
  DAQ_writeVar(ESD_DETECTOR, 1);
  #endif
  #if CONFIG_IFP_ESD_ACTIVEMODE
  DAQ_writeVar(ESD_DAC_IN_VAL, CONFIG_TDDI_ESD_MODE_DAC_IN);
  DAQ_writeVar(ESD_REF_HI_LO_VAL, CONFIG_TDDI_ESD_MODE_REF_HI_LO);
  DAQ_writeVar(ESD_CBC_GLOBAL_VAL, CONFIG_TDDI_ESD_MODE_CBC_GLOBAL);
  #endif
}
#endif
#if CONFIG_HAS_TDDI_ESD_DETECTOR
#if CONFIG_HAS_TDDI_ESD_CVITIMEOUT_CHECK
static uint16 CVItimeoutNum;
void esd_detector(uint16 CVItimeout){
#else
void esd_detector(){
#endif
    uint16 TMP1, TMP2;

#if CONFIG_HAS_TDDI_ESD_SLEEP_OUT_CHECK
    TMP1 = DAQ_readVar(DISP_RD_SLPOUT_VAL);
    TMP2 = DAQ_readVar(PS_SLEEP_OUT_VAL);
   //sleep out off
   if (!(TMP1&&TMP2 ))
      SLEEPOUT_CNT++;
   else
      SLEEPOUT_CNT = 0;

   if (SLEEPOUT_CNT>10)
      ESD_Detected |= 0x1;
#endif
#if CONFIG_HAS_TDDI_ESD_TAC_SYNC_CHECK
    TMP1 = DAQ_readVar(LEFT_TAC_SYNC_ERR_STATE_VAL);
    TMP2 = DAQ_readVar(RIGHT_TAC_SYNC_ERR_STATE_VAL);
   if (TMP1 != 0 || TMP2 != 0)
          ESD_Detected |= 0x2;
#endif
#if CONFIG_HAS_TDDI_ESD_DET_REG_CHECK
   TMP1 = DAQ_readVar(ESD_DET_R_P1_VAL);
   TMP2 = 0; //just to avoid compile error...
   //DISP.reg.ESD_DET_R_P1.v check
   if (TMP1 == 0xDEAD || TMP1 !=0 )
          ESD_Detected |= 0x4;
#endif
#if CONFIG_HAS_TDDI_ESD_APO_CHECK
   TMP1 = DAQ_readVar(PWR_STATUS_VAL);
   TMP2 = 0; //just to avoid compile error...
   //APO check
   if ((TMP1 & 0x08) || (TMP1 & 0x04))
          ESD_Detected |= 0x8;
#endif
#if CONFIG_HAS_TDDI_ESD_CVITIMEOUT_CHECK
   TMP1 = 0; //just to avoid compile error...
   TMP2 = 0; //just to avoid compile error...
   //CVItimeout check
   if(CVItimeout
   #if CONFIG_IGNORE_CVI_TIMEOUT_WHILE_SLEEPING
     && 1 < COMM_getPsmState()
   #endif
   ){
      CVItimeoutNum++;
   }else{
      CVItimeoutNum = 0;
   }
   if (CVItimeoutNum > CONFIG_TDDI_ESD_CVITIMEOUT_THRESHOLD)
          ESD_Detected |= 0x10;
#endif
}
#endif
#if CONFIG_HAS_TDDI_ESD_HANDLER
void esd_handler(){
    if (CONFIG_HAS_TDDI_ESD_SELF_RECOVERY & (ESD_Detected | (ESD_image_detected<<5))){
       COMM_Issue_ESD_Self_Recovery();
       COMM_wakeupVideoThread();
       COMM_Report_ESD_Self_Recovery();
    }
    if (CONFIG_HAS_TDDI_ESD_SET_DISPREG & (ESD_Detected | (ESD_image_detected<<5))){
       DAQ_writeVarAsync(SET_CMR_DBG_P2, 1);       
    }
    if (CONFIG_HAS_TDDI_ESD_Clear_DISP_EN & (ESD_Detected | (ESD_image_detected<<5))){
       DAQ_writeVarAsync(CLEAR_DISP_EN, 1); 
    }

    ESD_Detected = 0;
    ESD_image_detected = 0;
}
#endif

#if CONFIG_HAS_TDDI_ESD_IMAGE_CHECKER

/* =================================================================
   MODULE MACROS
==================================================================*/
#define get_offset(r,c) ((r)*(MAX_RX+1)+(c))

static uint16 txCount, rxCount;
static int16 detected;
static uint16 esd_reason[ESD_REASON_MAX];
static int16 esd_maximumThreshold;
static int16 esd_spikeMax;
static int16 esd_spikeMin;
static uint16 esd_maxLimit;
static uint16 esd_minLimit;
/* =================================================================
   MODULE FUNCTION DEFINITIONS
==================================================================*/

void esd_image_checker_init()
{
  uint16 i;

  detected = 0;
  for (i = 0; i < ESD_REASON_MAX; i++)
    esd_reason[i] = 0;
}

void esd_image_checker_configure(sensorParams_t *sensorParams)
{
  txCount = sensorParams->txCount;
  rxCount = sensorParams->rxCount;
  detected = 0;

  esd_maximumThreshold = CONFIG_TDDI_ESD_IMAGE_MAX_THRESHOLD;
  esd_spikeMax = CONFIG_TDDI_ESD_IMAGE_SPIKE_MAX;
  esd_spikeMin = CONFIG_TDDI_ESD_IMAGE_SPIKE_MIN;
  esd_maxLimit = CONFIG_TDDI_ESD_IMAGE_MAX_LIMIT;
  esd_minLimit = CONFIG_TDDI_ESD_IMAGE_MIN_LIMIT;
}

static uint16 isLocal8CMax(int16 *deltaPtr)
{
  int16 v;
  v = *deltaPtr;

  deltaPtr -= MAX_RX + 2;

  return (v > esd_spikeMax) &&
         (deltaPtr[0]                <= esd_spikeMin) &&
         (deltaPtr[1]                <= esd_spikeMin) &&
         (deltaPtr[2]                <= esd_spikeMin) &&
         (deltaPtr[MAX_RX + 1]       <= esd_spikeMin) &&
         (deltaPtr[MAX_RX + 3]       <= esd_spikeMin) &&
         (deltaPtr[2 * MAX_RX + 2]   <= esd_spikeMin) &&
         (deltaPtr[2 * MAX_RX + 3]   <= esd_spikeMin) &&
         (deltaPtr[2 * MAX_RX + 4]   <= esd_spikeMin);
}

uint16 esd_image_checker_detect(int16 *deltaImage, clumps_t *clumps)
{
  uint16 i;
  uint16 moistureDetected = FALSE;

  for (i = 0; i < MAX_OBJECTS; i++)
  {
    if (clumps->info[i].peakCount > 0)
    {
      int16 peakRow = clumps->info[i].peakLocation.row;
      int16 peakCol = clumps->info[i].peakLocation.col;
      uint16 peakOffset = get_offset(peakRow, peakCol);
      int16 largestPeakVal = deltaImage[peakOffset];
      if(largestPeakVal > esd_maximumThreshold)
      {
        detected = 1;
        esd_reason[ESD_REASON_MAXDELTA]++;
        break;
      }

      if(isLocal8CMax(&deltaImage[peakOffset]))
      {
        detected = 1;
        esd_reason[ESD_REASON_SPIKE]++;
        break;
      }
    }
  }

  return moistureDetected;
}

void esd_image_checker_rawImage(uint16 * rawImage)
{
  int16 idx;
  for (idx = 0; idx < (int16)( txCount * rxCount ) ; idx++,rawImage++)
  {
    if (*rawImage > esd_maxLimit)
    {
      detected = 1;
      esd_reason[ESD_REASON_HIGHLIMIT]++;
      break;
    }
    if (*rawImage < esd_minLimit)
    {
      detected = 1;
      esd_reason[ESD_REASON_LOWLIMIT]++;
      break;
    }
  }

  if (detected && (DAQ_readVar(DISP_EN_VAL)))
      ESD_image_detected |= detected;

  return;
}
#endif

#if CONFIG_IFP_SUPPRESS_METAL_HISTO
int16 metal_detection_getEsdState(void);
#else
#  define metal_detection_getEsdState() 0
#endif


#if CONFIG_IFP_ESD_ACTIVEMODE

#define ABS(x) ((x) > 0 ? (x) : -(x))
#if defined(cfg_esd_mode_debug) && (cfg_esd_mode_debug == 1)
# define ESDMODE_DEBUG_ON 1
#else
# define ESDMODE_DEBUG_ON 0
#endif

// esd mode baseline
int16 esdBaseline[MAX_TX*MAX_RX];
int16 esdDelta[(MAX_TX+2)*(MAX_RX+1)+1];

uint16 forceExitESDMode;        // F51 Cmd 0, bit 0

// esd mode baseline
uint16 esdStart;                // first frame in ESD Mode
uint16 esdStable;               // capture esd baseline
uint16 esdBaselineInitialized;

// Clean bufferTouchFlag after exit ESD MODE. (bufferTouchFlagDisableAfterEsdMode)
uint16 bufferTouchFlagDisableAfterEsdMode; // 3, will be used in classification

// switch to 120Hz ESD Mode params
uint32 esdLevel;
uint32 curLevel;

esdModeConfig_t esdModeConfig;
int16 esdMode_nTx;
int16 esdMode_nRx;

// switch frequency
uint16 activeFreq;
uint16 activeRate;

#if ESDMODE_DEBUG_ON
uint16 esdSteps[20];
uint16 CheckObject2Debug[20];
#endif

static uint32 CalcLevel(int16* rawImage)
{
  uint16 i, j;
  uint32 res = 0;
  for (i = 0; i < MAX_TX; i++)
  {
    for (j = 0; j < MAX_RX; j++)
    {
      res += rawImage[i * MAX_RX + j];
    }
  }
  return res;
}
/*
 * return value:
 * bit0 0: no object; 1: has object;
 * bit1 0: don't update baseline; 1: update baseline
 * bit2 0: have no baseline error;  1: have baseline error, need recapture baseline
*/

static int16 CheckObject(int16* rawImage)
{
  // ESD Mode slow speed switch to fast speed tuning params
  int16 esdFlatThreshold       = esdModeConfig.flatTheshold;       // 120
  uint16 esdLevelThreshold     = esdModeConfig.levelThreshold;     // 10000

  // ESD Mode, Finger detection Params
  // Finger size limitation, count Tx/Rx of Tixels which
  // is higher than maxPeak/fingerWidthAmplitudeRatio
  int16 fingerWidthThrMax      = esdModeConfig.fingerWidthThresholdMax;   // 12
  int16 fingerWidthThrMin      = esdModeConfig.fingerWidthThresholdMin;   // 1
  int16 fingerWidthAmpliRatio  = esdModeConfig.fingerWidthAmplitudeRatio; // 5

  // Delta Max should within [fingerPeakMinThreshold, fingerPeakMaxThreshold]
  int16 fingerPeakMaxThr       = esdModeConfig.fingerPeakMaxThreshold;       // 300
  int16 fingerPeakMinThr       = esdModeConfig.fingerPeakMinThreshold;       // 100

  // MaxPeak / (min in its 8C Tixels) should within [ratioPeakToMinThresholdMin, ratioPeakToMinThresholdMax]
  int16 ratioPeakToMinThrMax   = esdModeConfig.ratioPeakToMinThresholdMax;   // 1500
  int16 ratioPeakToMinThrMin   = esdModeConfig.ratioPeakToMinThresholdMin;   // 50

  int16 fingerWidthAmpliThr; // maxPeak/fingerWidthAmpliRatio

  int16 i, j, n;
  int16 maxPeak;
  int16 maxPeakTxIdx;
  int16 maxPeakRxIdx;

  int16 minPeakTxIdx;
  int16 minPeakRxIdx;

  int16 minPeak;
  int16 ratioPeakToMin;
  int16 fingerWidthInTx;
  int16 fingerWidthInRx;
  int16 negativeNum2;
  uint16 offset;
  static int32 total;
  static int16 flat, mean;
  int16 offsets[8] = { -MAX_RX - 2, 1, 1, MAX_RX - 1, 2, MAX_RX - 1, 1, 1};

  memset(esdDelta, 0, ((MAX_TX + 2) * (MAX_RX + 1) + 1) * 2);

  // get the delta image
  // find the peak
  // initialize it as the minimum
  maxPeak = 0x8000;
  maxPeakTxIdx = 0;
  maxPeakRxIdx = 0;
  negativeNum2 = 0;

  total = 0;
  for (i = 0; i < MAX_TX; i++)
  {
    for (j = 0; j < MAX_RX; j++)
    {
      offset = (i + 1) * (MAX_RX + 1) + j + 1;
      esdDelta[offset] = rawImage[i * MAX_RX + j] - esdBaseline[i * MAX_RX + j];
      if (esdDelta[offset] > maxPeak)
      {
        maxPeak = esdDelta[offset];
        maxPeakTxIdx = i;
        maxPeakRxIdx = j;
      }

      if (esdDelta[offset] < -90)
      {
        negativeNum2++;
      }
      total += esdDelta[offset];
    }
  }

  flat = 0;
  for (i = 2; i < MAX_TX; i++)
  {
    for (j = 2; j < MAX_RX - 2; j++)
    {
      offset = i * (MAX_RX + 1) + j;
      for (n = 0; n < 8; n++)
      {
        offset += offsets[n];
        if (ABS((esdDelta[i * (MAX_RX + 1) + j] - esdDelta[offset])) > flat)
        {
          flat = ABS((esdDelta[i * (MAX_RX + 1) + j] - esdDelta[offset]));
        }
      }
    }
  }

  if (flat < esdFlatThreshold)
  {
    if (curLevel < esdLevel - esdLevelThreshold)
    {
      if (DAQ_readVar(PSEUDO_VB_MODE) == 1)
      {
        DAQ_writeVarAsync(PSEUDO_VB_MODE, 0);
        //switchSensingFreq();
      }
    }
    else
    {
      if (DAQ_readVar(PSEUDO_VB_MODE) == 0)
      {
        DAQ_writeVarAsync(PSEUDO_VB_MODE, 1);
        //switchSensingFreq();
      }
    }
  }

  mean = (total - maxPeak) / (esdMode_nTx * esdMode_nTx);
  if (mean > 5)
  {
    for(i = 1; i <= esdMode_nTx; i++)
    {
      for (j = 1; j <= esdMode_nRx; j++)
      {
        esdDelta[i * (MAX_RX + 1) + j] -= mean;
      }
    }
    maxPeak -= mean;
  }


  // check baseline error
  if (negativeNum2 * 10 > (int16) (esdMode_nTx * esdMode_nRx * 7))
  {
    #if ESDMODE_DEBUG_ON
    CheckObject2Debug[0]++;
    #endif
    return ESD_DETECTION_BASELINE_ERROR;
  }
  #if ESDMODE_DEBUG_ON
  CheckObject2Debug[1] = maxPeak;
  #endif
  if ((maxPeak < fingerPeakMaxThr) && (maxPeak > fingerPeakMinThr))
  {
    #if ESDMODE_DEBUG_ON
    CheckObject2Debug[2]++;
    CheckObject2Debug[3] = maxPeakTxIdx;
    CheckObject2Debug[4] = maxPeakRxIdx;
    #endif
    minPeakTxIdx = 0;
    minPeakRxIdx = 0;

    minPeak = 0x7fff;
    if ((0 == maxPeakTxIdx) || ((esdMode_nTx - 1) == maxPeakTxIdx) ||
        (0 == maxPeakRxIdx) || ((esdMode_nRx - 1) == maxPeakRxIdx))
    {
      #if ESDMODE_DEBUG_ON
      CheckObject2Debug[5]++;
      #endif
      ratioPeakToMin = 0;
    }
    else
    {
      for (i = maxPeakTxIdx - 1; i <= (maxPeakTxIdx + 1); i++)
      {
        for (j = maxPeakRxIdx - 1; j <= (maxPeakRxIdx + 1); j++)
        {
          if (esdDelta[(i + 1) * (MAX_RX + 1) + j + 1] < minPeak)
          {
            minPeak = esdDelta[(i + 1) * (MAX_RX + 1) + j + 1];
            minPeakTxIdx  = i;
            minPeakRxIdx  = j;
          }
        }
      }
      #if ESDMODE_DEBUG_ON
      CheckObject2Debug[6] = minPeak;
      CheckObject2Debug[7] = minPeakTxIdx;
      CheckObject2Debug[8] = minPeakRxIdx;
      #endif
      if ((0 >= minPeak))
      {
        #if ESDMODE_DEBUG_ON
        CheckObject2Debug[9]++;
        #endif
        ratioPeakToMin = 0x7fff;
      }
      else
      {
        #if ESDMODE_DEBUG_ON
        CheckObject2Debug[10]++;
        #endif
        ratioPeakToMin = (maxPeak << 5) / minPeak;
      }
    }
    #if ESDMODE_DEBUG_ON
    CheckObject2Debug[11] = ratioPeakToMin;
    #endif
    // get the finger width in TX
    fingerWidthInTx = 1;
    fingerWidthAmpliThr = maxPeak / fingerWidthAmpliRatio;
    for (i = maxPeakTxIdx; i >= 0; i--)
    {
      if (esdDelta[i * (MAX_RX + 1) + maxPeakRxIdx + 1] > fingerWidthAmpliThr)
      {
        fingerWidthInTx++;
      }
      else
      {
        break;
      }
    }
    for (i = maxPeakTxIdx + 2; i <= MAX_TX + 1; i++)
    {
      if (esdDelta[i * (MAX_RX + 1) + maxPeakRxIdx + 1] > fingerWidthAmpliThr)
      {
        fingerWidthInTx++;
      }
      else
      {
        break;
      }
    }
    #if ESDMODE_DEBUG_ON
    CheckObject2Debug[12] = fingerWidthInTx;
    #endif
    // get the finger width in RX
    fingerWidthInRx = 1;
    for (j = maxPeakRxIdx; j >= 0; j--)
    {
      if (esdDelta[(maxPeakTxIdx + 1) * (MAX_RX + 1) + j] > fingerWidthAmpliThr)
      {
        fingerWidthInRx++;
      }
      else
      {
        break;
      }
    }
    for (j = maxPeakRxIdx + 2; j <= MAX_RX + 1; j++)
    {
      if (esdDelta[(maxPeakTxIdx + 1) * (MAX_RX + 1) + j] > fingerWidthAmpliThr)
      {
        fingerWidthInRx++;
      }
      else
      {
        break;
      }
    }
    #if ESDMODE_DEBUG_ON
    CheckObject2Debug[13] = fingerWidthInRx;

    CheckObject2Debug[16] = ratioPeakToMinThrMax; CheckObject2Debug[17] = ratioPeakToMinThrMin;
    CheckObject2Debug[18] = fingerWidthThrMax; CheckObject2Debug[19] = fingerWidthThrMin;
    #endif
    //judge if it is a finger
    if ((ratioPeakToMin < ratioPeakToMinThrMax) && (ratioPeakToMin > ratioPeakToMinThrMin) &&
        (fingerWidthInTx < fingerWidthThrMax) && (fingerWidthInTx >= fingerWidthThrMin) &&
        (fingerWidthInRx < fingerWidthThrMax) && (fingerWidthInRx >= fingerWidthThrMin))
    {
      #if ESDMODE_DEBUG_ON
      CheckObject2Debug[14]++;
      #endif
      // finger detected
      return ESD_DETECTION_HAS_FINGER;
    }
  }
  #if ESDMODE_DEBUG_ON
  CheckObject2Debug[15]++;
  #endif
  // no finger
  return ESD_DETECTION_NO_FINGER;
}

void force_exit_esdmode(uint16 value)
{
    forceExitESDMode = value;
}

uint16 getEsdStartStatus(void)
{
   return esdStart;
}

void esd_activemode_init(calcStaticConfig_t *cfg, calcDynamicConfig_t *dcfg)
{
    esdModeConfig = cfg->esdModeConfig;
    esdMode_nTx = cfg->ifpConfig.sensorParams.txCount;
    esdMode_nRx = cfg->ifpConfig.sensorParams.rxCount;
    DAQ_writeVarAsync(PSEUDO_VB_MODE, dcfg->esdModeCtrlField.enable);
    DAQ_writeVar(ESD_MODE, dcfg->esdModeCtrlField.enable);
    esdStable = 0;
    forceExitESDMode = 0;
}

void esd_dynamic_params(uint16 esdModeCtrlFieldEnable,uint16 forceEnterEsdMode)
{
    // Update ESD_MODE based on dynamic config params:
    //    disable: exit esd mode
    //    enable + forceEnterEsdMode: switch to esd mode. (if)
    //    enable + forceExitESDMode: exit esd mode. (else)
    if (esdModeCtrlFieldEnable && (forceEnterEsdMode || ((!forceExitESDMode) && DAQ_readVar(ESD_MODE))))
    {
        if (DAQ_readVar(ESD_MODE) == 0)
        {
            PL_setParam(PLESDMode,1);
            esdStart = 0;
        }
    }
    else
    {
        if (DAQ_readVar(ESD_MODE))
        {
            PL_setParam(PLESDMode,0);
            esdStart = 0;
        }
    }
}

void esd_checkFirstTimeEnterESDmode(void)
{
    // First frame in ESD Mode.
    if( esdStart == 0)
    {
        #if ESDMODE_DEBUG_ON
        esdSteps[0]++; // DEBUG
        #endif
        esdBaselineInitialized = 0;
        esdStable = 0;
        esdStart = 1;
        imageFrameProcessor_reinit_keepBaseline(); // clear status when enter ESD Mode
    }
}

void esd_calculation(uint16* rawImage,uint16 forceEnterEsdMode)
{
    #if ESDMODE_DEBUG_ON
    esdSteps[1]++;
    #endif
    curLevel = CalcLevel(rawImage);
    if (esdStart == 1)
    {
        #if ESDMODE_DEBUG_ON
        esdSteps[2]++;
        #endif
        esdStart = 2;
    }
    else
    {
        #if ESDMODE_DEBUG_ON
        esdSteps[3]++;
        #endif
        if (!esdBaselineInitialized)
        {
          #if ESDMODE_DEBUG_ON
          esdSteps[4]++;
          #endif
          memcpy(esdBaseline, rawImage, MAX_TX * MAX_RX * 2);
          esdLevel = curLevel;
          esdBaselineInitialized = 1;
        }
        else
        {
          #if ESDMODE_DEBUG_ON
          esdSteps[7]++;
          #endif

          int16 res = CheckObject(rawImage);
          if ( (res & ESD_DETECTION_HAS_FINGER) && (!forceEnterEsdMode))
          {
            #if ESDMODE_DEBUG_ON
            esdSteps[8]++;
            #endif
            PL_setParam(PLESDMode,0);
            //switchSensingFreq();
            esdBaselineInitialized = 0;
            esdStart = 0;
            //flags.noDoze = dcfg.noDoze;
            bufferTouchFlagDisableAfterEsdMode = esdModeConfig.touchFlagIgnoreCount;
          }
          else if (res & ESD_DETECTION_NO_FINGER)
          {
            #if ESDMODE_DEBUG_ON
            esdSteps[9]++;
            #endif
            {
              int16 txIdx;
              int16 rxIdx;
              int16 imageDelta;
              int16 esdbaselineThermal = esdModeConfig.thermalThreshold;     // 12
              for (txIdx = 0; txIdx < MAX_TX; txIdx++)
              {
                for (rxIdx = 0; rxIdx < MAX_RX; rxIdx++)
                {
                  imageDelta = rawImage[txIdx*MAX_RX + rxIdx] -
                  esdBaseline[txIdx*MAX_RX + rxIdx];
                  if (imageDelta < 0)
                  {
                    if ((-imageDelta) > (esdbaselineThermal))
                    {
                      esdBaseline[txIdx*MAX_RX + rxIdx] -= esdbaselineThermal;
                    }
                    else
                    {
                      esdBaseline[txIdx*MAX_RX + rxIdx] += imageDelta;
                    }
                  }
                  if (imageDelta > 0)
                  {
                    if ((imageDelta) > (esdbaselineThermal))
                    {
                      esdBaseline[txIdx*MAX_RX + rxIdx] += esdbaselineThermal;
                    }
                    else
                    {
                      esdBaseline[txIdx*MAX_RX + rxIdx] -= imageDelta;
                    }
                  }
                }
              }
            }
          }
          else if (res & ESD_DETECTION_BASELINE_ERROR)
          {
            #if ESDMODE_DEBUG_ON
            esdSteps[14]++;
            #endif
            memcpy(esdBaseline, rawImage, MAX_TX * MAX_RX * 2);
          }
        }
    }
}

void esd_detection(void)
{
    #if ESDMODE_DEBUG_ON
    esdSteps[10]++;
    #endif
    if (metal_detection_getEsdState())
    {
        #if ESDMODE_DEBUG_ON
        esdSteps[11]++;
        #endif
        PL_setParam(PLESDMode,1);
        //switchSensingFreq();
        esdStart = 0;
        forceExitESDMode = 0;
    }
}

uint16 getESDmode(void)
{
  uint16 temp;

  temp = DAQ_readVar(ESD_MODE);

  return temp;
}

int16 *ESD_getDelta(void)
{
    return esdDelta;
}

#endif
