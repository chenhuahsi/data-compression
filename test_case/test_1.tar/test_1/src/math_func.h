#ifndef MATH_FUNC_H
#define MATH_FUNC_H

#include "ifp_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DOMAIN      1
#define SING        2
#define OVERFLOW    3
#define UNDERFLOW   4
//#define TLOSS     5
//#define PLOSS     6

#define EDOM        33
#define ERANGE      34

#define IBMPC 1

/* Motorola IEEE, high order words come first
 * (Sun 680x0 workstation):
 */
/* #define MIEEE 1 */

/* UNKnown arithmetic, invokes coefficients given in
 * normal decimal format.  Beware of range boundary
 * problems (MACHEP, MAXLOG, etc. in const.c) and
 * roundoff problems in pow.c:
 * (Sun SPARCstation)
 */
/* #define UNK 1 */

/* If you define UNK, then be sure to set BIGENDIAN properly. */
#define BIGENDIAN 1

/* Define this `volatile' if your compiler thinks
 * that floating point arithmetic obeys the associative
 * and distributive laws.  It will defeat some optimizations
 * (but probably not enough of them).
 *
 * #define VOLATILE volatile
 */
#define VOLATILE

/* For 12-byte long doubles on an i386, pad a 16-bit short 0
 * to the end of real constants initialized by integer arrays.
 *
 * #define XPD 0,
 *
 * Otherwise, the type is 10 bytes long and XPD should be
 * defined blank (e.g., Microsoft C).
 *
 * #define XPD
 */
#define XPD 0,

/* Define to support tiny denormal numbers, else undefine. */
#define DENORMAL 0

/* Define to ask for infinity support, else undefine. */
#define INFINITIES 1

/* Define to ask for support of numbers that are Not-a-Number,
   else undefine.  This may automatically define INFINITIES in some files. */
#define NANS 1

/* Define to distinguish between -0.0 and +0.0.  */
#define MINUSZERO 1

/* Define 1 for ANSI C atan2() function
   and ANSI prototypes for float arguments.
   See atan.c and clog.c. */
#define ANSIC 1

#ifdef DEC
/* MAXNUMF = 2^127 * (1 - 2^-24) */
float MAXNUMF = 1.7014117331926442990585209174225846272e38;
float MAXLOGF = 88.02969187150841;
float MINLOGF = -88.7228391116729996; /* log(2^-128) */
#else
/* MAXNUMF = 2^128 * (1 - 2^-24) */
#define MAXNUMF  3.4028234663852885981170418348451692544e38f
#define MAXLOGF  88.72283905206835f
#define MINLOGF  -103.278929903431851103f /* log(2^-149) */
#endif

#define LOG2EF   1.44269504088896341f
#define LOGE2F   0.693147180559945309f
#define SQRTHF   0.707106781186547524f
#define PIF      3.141592653589793238f
#define PIO2F    1.5707963267948966192f
#define PIO4F    0.7853981633974483096f
#define MACHEPF  5.9604644775390625E-8f

#ifdef __CHIMERA__
    #define ATTR_ROM  __attribute__ ((rom))
    #ifndef COMMON_SILICON_H
      #ifndef _SYNA_TYPES_H
        typedef int int16;
        typedef unsigned int uint16;
        typedef long int32;
        typedef unsigned long uint32;
        //  typedef const int16  ATTR_ROM  rom_int16;
        //  typedef const uint16 ATTR_ROM  rom_uint16;
        //typedef const int32  ATTR_ROM  rom_int32;
        //typedef const uint32 ATTR_ROM  rom_uint32;
        //typedef const int32  ATTR_ROM  rom_int16p16;
      #endif
    #endif
    typedef const float ATTR_ROM   rom_float;
    typedef const float ATTR_ROM   ROM_FLOAT;
#else
  #define ATTR_ROM
  #ifndef ATTR_THREAD
    #define ATTR_THREAD(x)
  #endif
  typedef short int16;
  typedef unsigned short uint16;
  typedef int int32;
  typedef unsigned int uint32;
  typedef const int16  rom_int16;
  typedef const uint16 rom_uint16;
  typedef const int32  rom_int32;
  typedef const uint32 rom_uint32;
  typedef const int32 rom_int16p16;
  typedef const float rom_float;
  typedef const float ROM_FLOAT;
#endif // __CHIMERA__

float frexpf( float x, int *pw2 );
float ldexpf( float x, int pw2 );
float sqrtf( float xx );
float sinf( float xx );
float cosf( float xx );
float asinf( float x );
float acosf( float x );
float atanf( float xx );
float atan2f( float y, float x );

#ifdef __cplusplus
};
#endif

#endif

